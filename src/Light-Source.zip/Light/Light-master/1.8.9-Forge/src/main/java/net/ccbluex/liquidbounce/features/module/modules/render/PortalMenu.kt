package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo

@ModuleInfo(name = "PortalMenu", description = "Allows you to open a menu while being in a portal.",
        category = ModuleCategory.RENDER)
class PortalMenu : Module()