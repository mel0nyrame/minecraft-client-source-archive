
package net.ccbluex.liquidbounce.injection.forge;

import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
import org.spongepowered.asm.launch.MixinBootstrap;
import org.spongepowered.asm.mixin.MixinEnvironment;
import org.spongepowered.asm.mixin.Mixins;

import java.util.Map;

public class MixinLoader implements IFMLLoadingPlugin {

    public MixinLoader() {
        System.out.println("[Light] Injecting with IFMLLoadingPlugin.");
        MixinBootstrap.init();
        Mixins.addConfiguration("light.forge.mixins.json");
        MixinEnvironment.getDefaultEnvironment().setSide(MixinEnvironment.Side.CLIENT);
    }

    @Override
    public String[] getASMTransformerClass()
    {
        return new String[] { "net.ccbluex.liquidbounce.inputfix.InputFixTransformer" };
    }

    @Override
    public String getModContainerClass()
    {
        return "net.ccbluex.liquidbounce.inputfix.InputFixDummyContainer";
    }

    @Override
    public String getSetupClass()
    {
        return "net.ccbluex.liquidbounce.inputfix.InputFixSetup";
    }

    @Override
    public void injectData(Map<String, Object> data) {
    }

    @Override
    public String getAccessTransformerClass() {
        return null;
    }
}
