package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.aac;
import net.ccbluex.liquidbounce.event.MoveEvent;
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode;

public class AAC4 extends SpeedMode {
    public AAC4() {
        super("AACv4");
    }
    @Override
    public void onUpdate() {

    }
    @Override
    public void onMotion() {
        if(mc.thePlayer.movementInput.moveForward != 0) {
            if(mc.thePlayer.onGround) {
                mc.thePlayer.motionX *= 1.08;
                mc.thePlayer.motionZ *= 1.08;
                mc.thePlayer.jump();
                mc.timer.timerSpeed = 0.8f;
            } else if(mc.thePlayer.fallDistance != 0) {
                mc.timer.timerSpeed = 1.6f;
            }
        }
    }
    @Override
    public void onMove(MoveEvent event) {

    }
}
