package net.ccbluex.liquidbounce.inputfix.interfaces;

public interface IGuiScreenFix
{

    void handleKeyboardInput(IGuiScreen gui);

}
