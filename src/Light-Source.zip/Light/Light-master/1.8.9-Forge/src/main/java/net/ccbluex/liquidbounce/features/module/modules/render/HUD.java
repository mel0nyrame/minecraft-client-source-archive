package net.ccbluex.liquidbounce.features.module.modules.render;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.features.module.modules.world.HackerDetect;
import net.ccbluex.liquidbounce.ui.Fonts.FontManager;
import net.ccbluex.liquidbounce.ui.Fonts.UnicodeFontRenderer;
import net.ccbluex.liquidbounce.ui.client.GuiLogin;
import net.ccbluex.liquidbounce.ui.client.LightGUI.ClickGUI.LightClickGUI;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.render.Palette;
import net.ccbluex.liquidbounce.event.*;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.ui.client.hud.designer.GuiHudDesigner;
import net.ccbluex.liquidbounce.utils.EntityUtils;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import java.awt.*;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

@ModuleInfo(name = "HUD", description = "Toggles visibility of the HUD.", category = ModuleCategory.RENDER, array = false)
@SideOnly(Side.CLIENT)
public class HUD extends Module {
    public final BoolValue healthValue = new BoolValue("Health", true);
    private final BoolValue potionRenderValue = new BoolValue("PotionRender", false);
    private final BoolValue blockSpeed = new BoolValue("BlockSpeed", false);
    public final BoolValue playerBlackHotbarValue = new BoolValue("PlayerHotbar", false);
    public final BoolValue blackHotbarValue = new BoolValue("BlackHotbar", true);
    public final BoolValue inventoryParticle = new BoolValue("InventoryParticle", false);
    public static final BoolValue blurValue = new BoolValue("Blur", false);
    public final BoolValue fontChatValue = new BoolValue("FontChat", false);
    public static BoolValue notificationValue = new BoolValue("Notifications", true);
    public static ListValue Mode = new ListValue("NotificationMode", new String[]{"White", "Black", "Other"}, "White");
    private BoolValue titleValue = new BoolValue("Title", true);
    private TextValue titleTextValue = new TextValue("TitleText", "Light");
    private final ListValue titleMode = new ListValue("TitleMode", new String[]{"Normal", "GameSense"}, "GameSense");
    private static ListValue titleColorModeValue = new ListValue("TitleColorMode", new String[]{"Rainbow", "Normal"}, "Rainbow");
    private static IntegerValue rainbowCount = new IntegerValue("RainbowCount", 6, 1, 100);
    public static ColorValue color = new ColorValue("Color", -8350465);
    public static BoolValue OtherRender = new BoolValue("OtherRender", true);
    private float hue;
    private double lastDist = 0.0;
    private int textColor;

    public HUD() {
        setState(true);
    }

    private int rainbowTick = 0;
    private final SimpleDateFormat df = new SimpleDateFormat("HH:mm");

    @EventTarget
    public void onRender2D(final Render2DEvent event) {
        if (titleMode.get().equals("GameSense")) {
            if (hue < 255)
                hue++;
            else
                hue = 0;
            float h2 = hue + 85.0f;
            float h3 = hue + 170.0f;
            Color color33 = Color.getHSBColor(hue / 255.0f, 0.9f, 1.0f);
            Color color332 = Color.getHSBColor(h2 / 255.0f, 0.9f, 1.0f);
            Color color333 = Color.getHSBColor(h3 / 255.0f, 0.9f, 1.0f);
            int ping = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID()).getResponseTime();
            String pings = ping + " ms";
            UnicodeFontRenderer ffff = FontManager.GoogleSans16;
            String text = "Light\u00a72Sense\u00a7r | " + Minecraft.getDebugFPS() + " FPS | " + this.df.format(new Date()) + " | " + (mc.isSingleplayer() ? "SinglePlayer" : mc.getCurrentServerData().serverIP) + " | " + pings + " | " + mc.thePlayer.getName();
            RenderUtils.gameSense(4.0, 5.0, ffff.getStringWidth(text) + 11, 20.0, 1.0, color33.getRGB(), color332.getRGB(), color333.getRGB());
            ffff.drawCenteredStringWithColor(text, (float) (ffff.getStringWidth(text) / 2 + 8), 14.25F - (ffff.getStringHeight(text) / 2) - 0.75F + 4F, new Color(255, 255, 255).getRGB());
        }
        if (potionRenderValue.get()) {
            int x = 0;
            ScaledResolution sr = new ScaledResolution(mc);
            for (final PotionEffect effect : mc.thePlayer.getActivePotionEffects()) {
                Potion potion = Potion.potionTypes[effect.getPotionID()];
                String potionType = I18n.format(potion.getName()), d = "";
                switch (effect.getAmplifier()) {
                    case 1:
                        potionType = potionType + EnumChatFormatting.DARK_AQUA + " II";
                        break;
                    case 2:
                        potionType = potionType + EnumChatFormatting.BLUE + " III";
                        break;
                    case 3:
                        potionType = potionType + EnumChatFormatting.DARK_PURPLE + " IV";
                        break;
                    default:
                        potionType = potionType + EnumChatFormatting.DARK_PURPLE + " IV+";
                        break;
                }
                if (effect.getDuration() < 600 && effect.getDuration() > 300)
                    d = EnumChatFormatting.YELLOW + Potion.getDurationString(effect);
                else if (effect.getDuration() < 300) d = EnumChatFormatting.RED + Potion.getDurationString(effect);
                else if (effect.getDuration() > 600) d = EnumChatFormatting.WHITE + Potion.getDurationString(effect);

                int x1 = (int) ((sr.getScaledWidth() - 6) * 1.33);
                int y1 = (int) ((sr.getScaledHeight() - 32 - mc.fontRendererObj.FONT_HEIGHT + x + 5) * 1.33F);

                if (potion.hasStatusIcon()) {
                    GlStateManager.pushMatrix();
                    GlStateManager.color(1, 1, 1, 1);
                    int var10 = potion.getStatusIconIndex();
                    ResourceLocation location = new ResourceLocation("textures/gui/container/inventory.png");
                    mc.getTextureManager().bindTexture(location);
                    GlStateManager.scale(0.75, 0.75, 0.75);
                    mc.ingameGUI.drawTexturedModalRect(x1 - 9, y1 + 20, var10 % 8 * 18, 198 + var10 / 8 * 18, 18, 18);
                    GlStateManager.popMatrix();
                }
                int y = (sr.getScaledHeight() - mc.fontRendererObj.FONT_HEIGHT + x) - 5;
                int m = 15;
                mc.fontRendererObj.drawStringWithShadow(potionType, sr.getScaledWidth() - m - mc.fontRendererObj.getStringWidth(potionType) - 1, y - mc.fontRendererObj.FONT_HEIGHT - 1, potion.getLiquidColor());
                mc.fontRendererObj.drawStringWithShadow(d, sr.getScaledWidth() - m - mc.fontRendererObj.getStringWidth(d) - 1, y, -1);
                x -= 17;
            }
        }
        if (++rainbowTick > 50) {
            rainbowTick = 0;
        } else {
            rainbowTick++;
        }
        switch (titleColorModeValue.get()) {
            case "Rainbow": {
                textColor = Palette.fade(new Color(color.get()), 100, rainbowCount.get(), 2).getRGB();
                break;
            }
            case "Normal": {
                textColor = color.get();
                break;
            }
            default: {
                textColor = Palette.fade(new Color(color.get()), 100, 12, 2).getRGB();
                break;
            }
        }
        if (mc.currentScreen instanceof GuiHudDesigner) {
            if (titleValue.get() && titleMode.get().equals("Normal")) {
                Fonts.font40.drawStringWithShadow(titleTextValue.get().substring(0, 1), 10, 10, textColor);
                Fonts.font40.drawStringWithShadow(titleTextValue.get().substring(1), Fonts.font40.getStringWidth(titleTextValue.get().substring(0, 1)) + 10.5f, 10, new Color(255, 255, 255).getRGB());
            }
            return;
        }
        if (titleValue.get() && titleMode.get().equals("Normal")) {
            Fonts.font40.drawStringWithShadow(titleTextValue.get().substring(0, 1), 10, 10, textColor);
            Fonts.font40.drawStringWithShadow(titleTextValue.get().substring(1), Fonts.font40.getStringWidth(titleTextValue.get().substring(0, 1)) + 10.5f, 10, new Color(255, 255, 255).getRGB());
        }
        if (blockSpeed.get())
            Fonts.font40.drawStringWithShadow(HackerDetect.getBPS(mc.thePlayer) + " Blocks/sec", 50, 50, textColor);
        ScaledResolution res = new ScaledResolution(mc);
        int width = res.getScaledWidth();
        int height = res.getScaledHeight();
        if (healthValue.get())
            Fonts.font35.drawStringWithShadow(String.valueOf(MathHelper.ceiling_float_int(mc.thePlayer.getHealth())), width / 2 - 6, height / 2 - 13, mc.thePlayer.getHealth() <= 15 ? new Color(255, 0, 0).getRGB() : new Color(0, 255, 0).getRGB());
        if (!mc.ingameGUI.getChatGUI().getChatOpen()) {
            if (playerBlackHotbarValue.get()) {
                RenderUtils.drawRect(0, height - 24, 2000, height, new Color(0, 0, 0, 140).getRGB());
                // RenderUtils.drawFilledCircle(0, height - 28, 3, new Color(255,255,255));
                int Ping = EntityUtils.getPing(mc.thePlayer);
                Fonts.font40.drawStringWithShadow("User:", width - 100, height - 14, new Color(255, 255, 255).getRGB());
                Fonts.font40.drawStringWithShadow(mc.thePlayer.getGameProfile().getName(), width - 73, height - 14, new Color(0, 255, 0).getRGB());
                Fonts.font40.drawString("Ping:" + Ping, 18, height - 14, new Color(255, 255, 255).getRGB(), true);
            }
            if (OtherRender.get()) {
                ScaledResolution scaledResolution = new ScaledResolution(mc);
                RenderUtils.drawBorderRect(3, scaledResolution.getScaledHeight() - 25, 170, scaledResolution.getScaledHeight() - 4, 3, new Color(12, 29, 49).getRGB());
                mc.getTextureManager().bindTexture(mc.thePlayer.getLocationSkin());
                GlStateManager.color(1, 1, 1);
                Gui.drawScaledCustomSizeModalRect(6, scaledResolution.getScaledHeight() - 23, 8.0F, 8.0F, 8, 8, 16, 16, 64.0F, 64.0F);
                Fonts.font35.drawStringWithShadow("ID:" + mc.thePlayer.getName() + "  HP:" + (int) ((mc.thePlayer.getHealth() / mc.thePlayer.getMaxHealth()) * 100) + "%", 28, scaledResolution.getScaledHeight() - 22, -5);
                Fonts.font35.drawStringWithShadow("PosX:" + (int) mc.thePlayer.posX + " PosY:" + (int) mc.thePlayer.posY + " PosZ:" + (int) mc.thePlayer.posZ, 28, scaledResolution.getScaledHeight() - 13, -5);
            }
        }
        LiquidBounce.hud.render(false);
    }

    private String getArmorValue() {
        int OldArmorValue = mc.thePlayer != null ? mc.thePlayer.getTotalArmorValue() : 0;
        if (OldArmorValue != 0) {
            return OldArmorValue * 5 + "%";
        }
        return "0%";
    }

    @EventTarget
    public void onMotion(final MotionEvent event) {
        if (event.getEventState() == EventState.POST) {
            double xDist = mc.thePlayer.posX - mc.thePlayer.prevPosX;
            double zDist = mc.thePlayer.posZ - mc.thePlayer.prevPosZ;
            this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
        }
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        LiquidBounce.hud.update();
    }


    @EventTarget
    public void onKey(final KeyEvent event) {
        LiquidBounce.hud.handleKey('a', event.getKey());
    }

    @EventTarget(ignoreCondition = true)
    public void onScreen(final ScreenEvent event) {
        if (mc.theWorld == null || mc.thePlayer == null || LiquidBounce.moduleManager.getModule(MotionBlur.class).getState())
            return;
        if(mc.entityRenderer.getShaderGroup() != null && !(event.getGuiScreen() instanceof LightClickGUI))
            mc.entityRenderer.stopUseShader();
        if (getState() && blurValue.get() && !mc.entityRenderer.isShaderActive() && event.getGuiScreen() != null &&
                !(event.getGuiScreen() instanceof GuiChat || event.getGuiScreen() instanceof GuiHudDesigner))
            mc.entityRenderer.loadShader(new ResourceLocation("liquidbounce/blur.json"));
        else if (mc.entityRenderer.getShaderGroup() != null &&
                mc.entityRenderer.getShaderGroup().getShaderGroupName().contains("liquidbounce/blur.json"))
            mc.entityRenderer.stopUseShader();
    }
}
