package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.ncp;

import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.MoveEvent;
import net.ccbluex.liquidbounce.features.module.modules.movement.TargetStrafe;
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode;
import net.ccbluex.liquidbounce.utils.MovementUtils;
import net.ccbluex.liquidbounce.utils.timer.TimeHelper;
import net.ccbluex.liquidbounce.utils.timer.TimerUtil;
import net.minecraft.util.AxisAlignedBB;

import java.util.List;

public class NCP extends SpeedMode {
    private float stage;
    private float moveSpeed;
    private TargetStrafe targetStrafe = LiquidBounce.moduleManager.getModule(TargetStrafe.class);
    public NCP() {
        super("NCP");
    }

    @Override
    public void onEnable() {
        stage = 0;
        moveSpeed = 0F;
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Override
    public void onMotion() {

    }

    @Override
    public void onUpdate() {

    }
    @Override
    public void onMove(MoveEvent event) {
        if(MovementUtils.isMoving()) {
            stage += 1;
            if(mc.thePlayer.onGround) {
                event.setY(mc.thePlayer.motionY = MovementUtils.getJumpBoostModifier(0.42));
            }
            if(!mc.thePlayer.isCollidedHorizontally) {
                moveSpeed = 0.34F - (stage / 100);
            } else {
                moveSpeed *= 0.85F;
                stage = 0;
            }
            if(stage == 5)
                stage = 0;
            double speed = MovementUtils.getBaseMoveSpeed(moveSpeed);
            if(!targetStrafe.canStrafe())
                MovementUtils.setSpeed(event,speed);
            else
                targetStrafe.strafe(event, speed);
        }

    }
}
