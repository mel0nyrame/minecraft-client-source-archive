
package net.ccbluex.liquidbounce.features.module

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.Listenable
import net.ccbluex.liquidbounce.script.api.ScriptModule
import net.ccbluex.liquidbounce.ui.client.Notifications
import net.ccbluex.liquidbounce.ui.client.clickgui.AnimationHelper
import net.ccbluex.liquidbounce.utils.AutoAddModule
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.utils.render.ColorUtils.stripColor
import net.ccbluex.liquidbounce.utils.render.Translate
import net.ccbluex.liquidbounce.value.Value
import net.minecraft.client.audio.ISound
import net.minecraft.client.audio.PositionedSoundRecord
import net.minecraft.network.Packet
import net.minecraft.util.ResourceLocation
import net.minecraftforge.fml.relauncher.Side
import net.minecraftforge.fml.relauncher.SideOnly
import org.lwjgl.input.Keyboard

@SideOnly(Side.CLIENT)
open class Module() : MinecraftInstance(), Listenable {
    val animation = AnimationHelper(this)
    val translate = Translate(0F,0F)
    // Module information
    // TODO: Remove ModuleInfo and change to constructor (#Kotlin)
    var fakeName: String
    var name: String
    var description: String
    var category: ModuleCategory
    var higt = 0F
    var keyBind = Keyboard.CHAR_NONE
        set(keyBind) {
            field = keyBind

            if (!LiquidBounce.isStarting)
                LiquidBounce.fileManager.saveConfig(LiquidBounce.fileManager.modulesConfig)
        }
    var array = true
        set(array) {
            field = array

            if (!LiquidBounce.isStarting)
                LiquidBounce.fileManager.saveConfig(LiquidBounce.fileManager.modulesConfig)
        }
    private val canEnable: Boolean

    var slideStep = 0F


    // Current state of module
    var state = false
        set(value) {
            if (field == value) return

            // Call toggle
            onToggle(value)

            // Play sound and add notification
            if (!LiquidBounce.isStarting) {
                mc.soundHandler.playSound(PositionedSoundRecord.create(ResourceLocation("random.bow"), if(value) 1F else 0.5F))
                ClientUtils.sendClientMessage(if (value) "$fakeName Enabled" else "$fakeName Disabled", if (value) Notifications.Type.SUCCESS else Notifications.Type.ERROR)
            }

            // Call on enabled or disabled
            if (value) {
                onEnable()

                if (canEnable)
                    field = true
            } else {
                onDisable()
                field = false
            }

            // Save module state
            LiquidBounce.fileManager.saveConfig(LiquidBounce.fileManager.modulesConfig)
        }

    init {
        val moduleInfo = javaClass.getAnnotation(ModuleInfo::class.java)!!
        name = moduleInfo.name
        fakeName = if(moduleInfo.fakeName.isEmpty() || this is ScriptModule) moduleInfo.name else moduleInfo.fakeName
        description = moduleInfo.description
        category = moduleInfo.category
        keyBind = moduleInfo.keyBind
        array = moduleInfo.array
        canEnable = moduleInfo.canEnable
        animation.animationX = if(state) 5F else -5F
    }


    // HUD
    val hue = Math.random().toFloat()
    var slide = 0F

    // Tag
    open val tag: String?
        get() = null

//    val tagName: String
//        get() = "$fakename${if (tag == null) "" else " §7- $tag"}"
//
//    val colorlessTagName: String
//        get() = "$fakename${if (tag == null) "" else " §7- " + stripColor(tag)}"

    val tagName: String
        get() = "$fakeName${if (tag == null) "" else "§7 $tag"}"

    val colorlessTagName: String
        get() = "$fakeName${if (tag == null) "" else "§7 " + stripColor(tag)}"

    open fun tagName(nameBreak: Boolean) : String {
        if(nameBreak && !name.contains("ScriptModule") && !fakeName.contains("ScriptModule")) {
            return "$fakeName${if (tag == null) "" else "§7 - $tag"}"
        }
        return "$name${if (tag == null) "" else "§7 - $tag"}"
    }

    fun colorlessTagName(nameBreak: Boolean) : String {
        if(nameBreak) {
            return "$fakeName${if (tag == null) "" else " - " + stripColor(tag)}"
        }
        return "$name${if (tag == null) "" else "§7 - " + stripColor(tag)}"
    }

    fun fakeName(nameBreak: Boolean) : String {
        if(nameBreak && !name.contains("ScriptModule") && !fakeName.contains("ScriptModule")) {
            return fakeName
        }
        return name
    }



    fun sendPacket(packet: Packet<*>) {
        if (mc.netHandler.networkManager != null) {
            mc.netHandler.networkManager.sendPacket(packet)
        }
    }

    /**
     * Toggle module
     */
    fun toggle() {
        state = !state
    }

    /**
     * Called when module toggled
     */
    open fun onToggle(state: Boolean) {}

    /**
     * Called when module enabled
     */
    open fun onEnable() {
    }

    /**
     * Called when module disabled
     */
    open fun onDisable() {
    }

    /**
     * Get module by [valueName]
     */
    fun getValue(valueName: String) = values.find { it.name.equals(valueName, ignoreCase = true) }

    /**
     * Get all values of module
     */
    open val values: List<Value<*>>
        get() = javaClass.declaredFields.map { valueField ->
            valueField.isAccessible = true
            valueField[this]
        }.filterIsInstance<Value<*>>()

    /**
     * Events should be handled when module is enabled
     */
    override fun handleEvents() = state
}