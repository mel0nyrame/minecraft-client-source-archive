package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.RaycastUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.entity.Entity
import net.minecraft.item.ItemSnowball
import net.minecraft.item.ItemSword
import net.minecraft.network.play.client.C02PacketUseEntity
import net.minecraft.network.play.client.C07PacketPlayerDigging
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement
import net.minecraft.network.play.client.C0APacketAnimation

@ModuleInfo(name = "AutoDropSnowBall", description = "Auto throw the snowball.", category = ModuleCategory.PLAYER, fakeName = "Auto Drop SnowBall")
class AutoThrowSnowBall : Module() {
    private val swordSlot = object : IntegerValue("SwordSlot", 1, 1, 9) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            if(oldValue < minimum)
                set(minimum)
            if(newValue > maximum)
                set(maximum)
        }
    }
    private val shouldFaceEntity = BoolValue("CheckEntity", true)
    private var shit = 0
    fun swap(newSlot: Int, oldSlot: Int) {
        mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, newSlot, oldSlot, 2, mc.thePlayer)
    }
    @EventTarget
    fun onPacket(event : PacketEvent) {
        val packet = event.packet
        if(packet is C08PacketPlayerBlockPlacement) {
            if(packet.stack.item is ItemSnowball) {
                val facedTarget = RaycastUtils.raycastEntity(10.0) {
                    entity : Entity? -> EntityUtils.isSelected(entity, true)
                }
                if(facedTarget == null && shouldFaceEntity.get()) {
                    event.cancelEvent()
                    return
                }
                mc.thePlayer.inventory.currentItem = swordSlot.get() - 1
            }
            if(packet.stack.item is ItemSword) {
                event.cancelEvent()
            }
        }
        if(packet is C07PacketPlayerDigging || packet is C02PacketUseEntity || packet is C0APacketAnimation)
            if(mc.thePlayer.heldItem.item is ItemSword)
                event.cancelEvent()
    }
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (mc.thePlayer.heldItem != null && mc.thePlayer.heldItem.item is ItemSnowball) {
        } else {
            for (i in 0..8) {
                val slot = mc.thePlayer.inventoryContainer.getSlot(i + 36)
                if (slot.stack != null && slot.stack.item is ItemSnowball) {
                    shit++
                    if (shit == 5) {
                        mc.thePlayer.inventory.currentItem = i
                        shit = 0
                    }
                    break
                }
            }
        }
    }
}