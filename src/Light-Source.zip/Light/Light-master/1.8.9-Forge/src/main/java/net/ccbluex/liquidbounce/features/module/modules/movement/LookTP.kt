package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.player.Teleport
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.RaycastUtils
import net.ccbluex.liquidbounce.utils.path.CustomVec3
import net.ccbluex.liquidbounce.utils.path.PathfindingUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.entity.Entity
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.network.play.client.C03PacketPlayer

@ModuleInfo("LookTP", "tp the target player", ModuleCategory.MOVEMENT, fakeName = "Look TP")
class LookTP : Module() {
    private val modeValue = ListValue("Mode", arrayOf("Hypixel","Vanilla"), "Vanilla")
    private val shouldBeSeen = BoolValue("ShouldBeSeen", false)
    private val autoDisableValue = BoolValue("AutoDisable", true)
    private var clickTeleported = false
    override val tag: String
        get() = modeValue.value
    var teleport = false
    private var waitForNextTP = false
    var tp = false
    var x = 0.0
    var path = ArrayList<CustomVec3>()
    var y = 0.0
    var z = 0.0
    override fun onDisable() {
        clickTeleported = false
        if(modeValue.value == "Hypixel") {
            LiquidBounce.moduleManager[Teleport::class.java].state = false
            mc.timer.timerSpeed = 1.0F
            mc.thePlayer.stepHeight = 0.625F
            mc.thePlayer.motionX = 0.0
            mc.thePlayer.motionZ = 0.0
            Teleport.isTPPlayer = false
            Teleport.playername = null
        }
    }

    @EventTarget
    private fun onUpdate(updateEvent: UpdateEvent) {
        val facedEntity = RaycastUtils.raycastEntity(100.0) { racistEntity: Entity? -> EntityUtils.isSelected(racistEntity, true) && racistEntity is EntityPlayer }
        if(!mc.gameSettings.keyBindUseItem.pressed && clickTeleported)
            clickTeleported = false
        if(modeValue.value == "Vanilla") {
            if((mc.thePlayer.canEntityBeSeen(facedEntity) || !shouldBeSeen.value) && mc.gameSettings.keyBindUseItem.pressed && !clickTeleported) {
                clickTeleported = true
            }
            if(clickTeleported) {
                val topFrom = CustomVec3(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ)
                val to = CustomVec3(facedEntity.posX, facedEntity.posY, facedEntity.posZ)
                path = PathfindingUtils.computePath(topFrom, to)
                for (i in path) {
                    mc.thePlayer.sendQueue.addToSendQueue(C03PacketPlayer.C04PacketPlayerPosition(i.x, i.y, i.z, false))
                }
                if(autoDisableValue.value)
                    toggle()
            }
        }
        if (modeValue.value == "Hypixel") {
            if (mc.thePlayer.canEntityBeSeen(facedEntity) && facedEntity != null && mc.gameSettings.keyBindUseItem.pressed && !waitForNextTP) {
                x = facedEntity.posX
                y = facedEntity.posY
                z = facedEntity.posZ
                waitForNextTP = true
                val tpMod = LiquidBounce.moduleManager[Teleport::class.java] as Teleport
                tpMod.state = true
                Teleport.playername = facedEntity.name
                Teleport.isTPPlayer = true
            }
            if (waitForNextTP)
                waitForNextTP = false
        }
    }
}