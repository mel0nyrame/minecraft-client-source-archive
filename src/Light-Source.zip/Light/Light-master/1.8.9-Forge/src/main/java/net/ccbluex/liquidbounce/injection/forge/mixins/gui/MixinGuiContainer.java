/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.injection.forge.mixins.gui;
import com.google.common.collect.Sets;
import net.ccbluex.liquidbounce.features.module.modules.combat.Aura;
import net.ccbluex.liquidbounce.features.module.modules.player.InvCleaner;
import net.ccbluex.liquidbounce.features.module.modules.render.InvAnimation;
import net.ccbluex.liquidbounce.features.module.modules.world.ChestStealer;
import net.ccbluex.liquidbounce.ui.client.clickgui.AnimationUtil;
import net.ccbluex.liquidbounce.utils.render.Translate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.ccbluex.liquidbounce.LiquidBounce;
import java.awt.*;
import java.util.Set;

@Mixin(GuiContainer.class)
public abstract class MixinGuiContainer extends GuiScreen {

    @Inject(method = "initGui", at = @At("RETURN"))
    private void initGui(CallbackInfo callbackInfo) {
        if(!this.mc.isIntegratedServerRunning())
            this.buttonList.add(new GuiButton(11110, 5, 10, 120, 20, "Disable KillAura"));
        this.buttonList.add(new GuiButton(11120,5, 34, 110, 20,"Disable InvManager"));
        this.buttonList.add(new GuiButton(11130, 5, 58, 110, 20, "Disable ChestStealer"));
        this.translate = new Translate(0, 0);
    }

    Translate translate;
    public float animpos = 75f;
    @Shadow
    protected int guiLeft;
    @Shadow
    protected int guiTop;
    @Shadow
    private Slot theSlot;
    @Shadow
    public Container inventorySlots;
    @Shadow
    private ItemStack draggedStack;
    @Shadow
    private int touchUpX;
    @Shadow
    private int touchUpY;
    @Shadow
    private Slot returningStackDestSlot;
    @Shadow
    private long returningStackTime;
    @Shadow
    private ItemStack returningStack;
    @Shadow
    protected final Set<Slot> dragSplittingSlots = Sets.<Slot>newHashSet();
    @Shadow
    protected boolean dragSplitting;
    @Shadow
    private int dragSplittingLimit;
    @Shadow
    private int dragSplittingButton;
    @Shadow
    private boolean ignoreMouseUp;
    @Shadow
    private int dragSplittingRemnant;
    @Shadow
    private boolean isRightMouseClick;
    /**
     * @author
     */
    @Overwrite
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        final InvAnimation ia = LiquidBounce.moduleManager.getModule(InvAnimation.class);
        final ChestStealer st = LiquidBounce.moduleManager.getModule(ChestStealer.class);
        if (st.getSilentValue().get() && mc.currentScreen instanceof GuiChest && st.getState()) {
            Minecraft.getMinecraft().mouseHelper.grabMouseCursor();
            mc.fontRendererObj.drawStringWithShadow("Stealing", 455, 238, Color.getHSBColor(1f, 0.75f, 0.5f).getRGB());
            return;
        }
        translate.interpolate(this.width, this.height, ia.speedValue.get());
        if (ia.getState()) {
            if (ia.animationModeValue.get().equals("Fade1")) {
                animpos = AnimationUtil.moveTowards(animpos, ia.endValue.get(), ia.smoothSpeedValue.get(), ia.smoothSpeedValue.get());
                GlStateManager.translate(0, animpos, 0);
            }
            if (ia.animationModeValue.get().equals("Fade2")) {
                double xmod = this.width - (translate.getX());
                double ymod = this.height - (translate.getY());
                GlStateManager.translate(-xmod, -ymod, 0);
                GlStateManager.scale(translate.getX() / this.width, translate.getY() / this.height, 1);
            }
            if (ia.animationModeValue.get().equals("Fade3")) {
                double xmod2 = this.width / 2 - (translate.getX() / 2);
                double ymod2 = this.height / 2 - (translate.getY() / 2);
                GlStateManager.translate(xmod2, ymod2, 0);
                GlStateManager.scale(translate.getX() / this.width, translate.getY() / this.height, 1);
            }
        }
        int i = this.guiLeft;
        int j = this.guiTop;
        this.drawGuiContainerBackgroundLayer(partialTicks, mouseX, mouseY);
        GlStateManager.disableRescaleNormal();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableLighting();
        GlStateManager.disableDepth();
        super.drawScreen(mouseX, mouseY, partialTicks);
        RenderHelper.enableGUIStandardItemLighting();
        GlStateManager.pushMatrix();
        GlStateManager.translate((float) i, (float) j, 0.0F);
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.enableRescaleNormal();
        this.theSlot = null;
        int k = 240;
        int l = 240;
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float) k / 1.0F, (float) l / 1.0F);
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);

        for (int i1 = 0; i1 < this.inventorySlots.inventorySlots.size(); ++i1) {
            Slot slot = this.inventorySlots.inventorySlots.get(i1);
            this.drawSlot(slot);

            if (this.isMouseOverSlot(slot, mouseX, mouseY) && slot.canBeHovered()) {
                this.theSlot = slot;
                GlStateManager.disableLighting();
                GlStateManager.disableDepth();
                int j1 = slot.xDisplayPosition;
                int k1 = slot.yDisplayPosition;
                GlStateManager.colorMask(true, true, true, false);
                this.drawGradientRect(j1, k1, j1 + 16, k1 + 16, -2130706433, -2130706433);
                GlStateManager.colorMask(true, true, true, true);
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
            }
        }

        RenderHelper.disableStandardItemLighting();
        this.drawGuiContainerForegroundLayer(mouseX, mouseY);
        RenderHelper.enableGUIStandardItemLighting();
        InventoryPlayer inventoryplayer = this.mc.thePlayer.inventory;
        ItemStack itemstack = this.draggedStack == null ? inventoryplayer.getItemStack() : this.draggedStack;

        if (itemstack != null) {
            int j2 = 8;
            int k2 = this.draggedStack == null ? 8 : 16;
            String s = null;

            if (this.draggedStack != null && this.isRightMouseClick) {
                itemstack = itemstack.copy();
                itemstack.stackSize = MathHelper.ceiling_float_int((float) itemstack.stackSize / 2.0F);
            } else if (this.dragSplitting && this.dragSplittingSlots.size() > 1) {
                itemstack = itemstack.copy();
                itemstack.stackSize = this.dragSplittingRemnant;

                if (itemstack.stackSize == 0) {
                    s = "" + EnumChatFormatting.YELLOW + "0";
                }
            }

            this.drawItemStack(itemstack, mouseX - i - j2, mouseY - j - k2, s);
        }

        if (this.returningStack != null) {
            float f = (float) (Minecraft.getSystemTime() - this.returningStackTime) / 100.0F;

            if (f >= 1.0F) {
                f = 1.0F;
                this.returningStack = null;
            }

            int l2 = this.returningStackDestSlot.xDisplayPosition - this.touchUpX;
            int i3 = this.returningStackDestSlot.yDisplayPosition - this.touchUpY;
            int l1 = this.touchUpX + (int) ((float) l2 * f);
            int i2 = this.touchUpY + (int) ((float) i3 * f);
            this.drawItemStack(this.returningStack, l1, i2, (String) null);
        }

        GlStateManager.popMatrix();

        if (inventoryplayer.getItemStack() == null && this.theSlot != null && this.theSlot.getHasStack()) {
            ItemStack itemstack1 = this.theSlot.getStack();
            this.renderToolTip(itemstack1, mouseX, mouseY);
        }

        GlStateManager.enableLighting();
        GlStateManager.enableDepth();
        RenderHelper.enableStandardItemLighting();
    }

    @Shadow
    protected abstract void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY);
    @Shadow
    protected abstract void drawSlot(Slot slotIn);
    @Shadow
    protected abstract boolean isMouseOverSlot(Slot slotIn, int mouseX, int mouseY);
    @Shadow
    protected abstract void drawItemStack(ItemStack stack, int x, int y, String altText);
    @Shadow
    protected abstract void drawGuiContainerForegroundLayer(int mouseX, int mouseY);

    @Inject(method = "mouseClicked", at = @At("RETURN"))
    private void mouseClicked(int mouseX, int mouseY, int mouseButton,CallbackInfo callbackInfo) {
        for (Object aButtonList : this.buttonList) {
            GuiButton var52 = (GuiButton) aButtonList;
            if (var52.mousePressed(this.mc, mouseX, mouseY) && var52.id == 11110) {
                LiquidBounce.moduleManager.getModule(Aura.class).setState(false);
            }
            if (var52.mousePressed(this.mc, mouseX, mouseY) && var52.id == 11120) {
                LiquidBounce.moduleManager.getModule(InvCleaner.class).setState(false);
            }
            if (var52.mousePressed(this.mc, mouseX, mouseY) && var52.id == 11130) {
                LiquidBounce.moduleManager.getModule(ChestStealer.class).setState(false);
            }
        }
    }
}