package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.event.AttackEvent
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.item.ItemSword

@ModuleInfo(name = "ArmorBreaker", description = "Break a players' armor", category = ModuleCategory.PLAYER, fakeName = "Armor Breaker")
class ArmorBreaker : Module() {
    private val shouldOnGround = BoolValue("ShouldOnGround", true)

    @EventTarget
    private fun onAttack(event: AttackEvent) {
        if (!shouldOnGround.get() || mc.thePlayer.onGround) {
            val currentItem = mc.thePlayer.heldItem
            for(i in 0..45) {
                val nextSword = mc.thePlayer.inventoryContainer.getSlot(i).stack
                if (currentItem == null || nextSword == null || nextSword.item !is ItemSword)
                    continue
                mc.playerController.windowClick(0,i,mc.thePlayer.inventory.currentItem,2,mc.thePlayer)
            }
        }
    }
}