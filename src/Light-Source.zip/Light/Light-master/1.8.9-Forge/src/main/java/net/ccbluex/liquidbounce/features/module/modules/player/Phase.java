package net.ccbluex.liquidbounce.features.module.modules.player;
import net.ccbluex.liquidbounce.event.*;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.MovementUtils;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockHopper;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

@ModuleInfo(name = "Phase",description="Throw the wall.",category = ModuleCategory.MOVEMENT)
public final class Phase
        extends Module {
    private final ListValue mode = new ListValue("Mode", new String[] {"Hypixel","Vanilla"}, "Hypixel");
    private int moveUnder;

    public static boolean insideBlock() {
        for (int x = MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().minX); x < MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().maxX) + 1; ++x) {
            for (int y = MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().minY); y < MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().maxY) + 1; ++y) {
                for (int z = MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().minZ); z < MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().maxZ) + 1; ++z) {
                    final Block block = mc.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                    if (block != null && !(block instanceof BlockAir)) {
                        AxisAlignedBB boundingBox = block.getCollisionBoundingBox(mc.theWorld, new BlockPos(x, y, z), mc.theWorld.getBlockState(new BlockPos(x, y, z)));
                        if (block instanceof BlockHopper) {
                            boundingBox = new AxisAlignedBB(x, y, z, x + 1, y + 1, z + 1);
                        }
                        if (boundingBox != null && mc.thePlayer.getEntityBoundingBox().intersectsWith(boundingBox)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    @EventTarget
    public final void onTick(TickEvent event) {
        if (mc.thePlayer != null && this.moveUnder == 1) {
            mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY - 2.0, mc.thePlayer.posZ, false));
            mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, true));
            this.moveUnder = 0;
        }
        if (mc.thePlayer != null && this.moveUnder == 1488) {
            double mx = -Math.sin(Math.toRadians(mc.thePlayer.rotationYaw));
            double mz = Math.cos(Math.toRadians(mc.thePlayer.rotationYaw));
            double x = (double)mc.thePlayer.movementInput.moveForward * mx + (double)mc.thePlayer.movementInput.moveStrafe * mz;
            double z = (double)mc.thePlayer.movementInput.moveForward * mz - (double)mc.thePlayer.movementInput.moveStrafe * mx;
            mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX + x, mc.thePlayer.posY, mc.thePlayer.posZ + z, false));
            mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(Double.NEGATIVE_INFINITY, mc.thePlayer.posY, Double.NEGATIVE_INFINITY, true));
            this.moveUnder = 0;
        }
    }

    @EventTarget
    public final void onBB(BlockBBEvent event) {
        switch (mode.get()) {
            case "Hypixel": {
                if (!insideBlock()) break;
                event.setBoundingBox(null);
                break;
            }
            case "Vanilla": {
                if (mc.thePlayer.isCollidedHorizontally && !insideBlock()) {
                    double mx = -Math.sin(Math.toRadians(mc.thePlayer.rotationYaw));
                    double mz = Math.cos(Math.toRadians(mc.thePlayer.rotationYaw));
                    double x = (double)mc.thePlayer.movementInput.moveForward * mx + (double)mc.thePlayer.movementInput.moveStrafe * mz;
                    double z = (double)mc.thePlayer.movementInput.moveForward * mz - (double)mc.thePlayer.movementInput.moveStrafe * mx;
                    event.setBoundingBox(null);
                    mc.thePlayer.setPosition(mc.thePlayer.posX + x, mc.thePlayer.posY, mc.thePlayer.posZ + z);
                    this.moveUnder = 69;
                }
                if (!insideBlock()) break;
                event.setBoundingBox(null);
            }
        }
    }

    @EventTarget
    public final void onPushOut(PushOutEvent event) {
        event.cancelEvent();
    }

    @EventTarget
    public final void onMotion(MotionEvent event) {
        switch (mode.get()) {
            case "Hypixel": {
                if (event.getEventState() == EventState.PRE) break;
                double multiplier = 0.3;
                double mx = -Math.sin(Math.toRadians(mc.thePlayer.rotationYaw));
                double mz = Math.cos(Math.toRadians(mc.thePlayer.rotationYaw));
                double x = (double)mc.thePlayer.movementInput.moveForward * multiplier * mx + (double)mc.thePlayer.movementInput.moveStrafe * multiplier * mz;
                double z = (double)mc.thePlayer.movementInput.moveForward * multiplier * mz - (double)mc.thePlayer.movementInput.moveStrafe * multiplier * mx;
                if (!mc.thePlayer.isCollidedHorizontally || mc.thePlayer.isOnLadder()) break;
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX + x, mc.thePlayer.posY + 0.001, mc.thePlayer.posZ + z, false));
                for (int i = 1; i < 10; ++i) {
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY - 0.22, mc.thePlayer.posZ, false));
                }
                mc.thePlayer.setPosition(mc.thePlayer.posX + x, mc.thePlayer.posY, mc.thePlayer.posZ + z);
                break;
            }
            case "Vanilla": {
                if (!mc.gameSettings.keyBindSneak.isPressed() || insideBlock()) break;
                mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY - 2.0, mc.thePlayer.posZ, true));
                this.moveUnder = 2;
            }
        }
    }

    @EventTarget
    public final void onReceive(PacketEvent event) {
        if (event.getPacket() instanceof S02PacketChat && ((S02PacketChat)event.getPacket()).getChatComponent().getUnformattedText().contains("You cannot go past the border.")) {
            event.cancelEvent();
        }
        if (this.mode.get().equals("Vanilla") && event.getPacket() instanceof S08PacketPlayerPosLook && this.moveUnder == 2) {
            this.moveUnder = 1;
        }
        if (this.mode.get().equals("Vanilla") && event.getPacket() instanceof S08PacketPlayerPosLook && this.moveUnder == 69) {
            this.moveUnder = 1488;
        }
    }

    @EventTarget
    public final void onMove(MoveEvent event) {
        switch (mode.get()) {
            case "Hypixel": {
                if (!insideBlock()) break;
                if (mc.gameSettings.keyBindJump.isKeyDown()) {
                    mc.thePlayer.motionY += 0.09000000357627869;
                } else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
                    mc.thePlayer.motionY -= 0.0;
                } else {
                    mc.thePlayer.motionY = 0.0;
                }
                MovementUtils.setSpeed(event, 0.3);
                if (mc.thePlayer.ticksExisted % 2 != 0) break;
                mc.thePlayer.motionY += 0.09000000357627869;
                break;
            }
            case "Vanilla": {
                if (!insideBlock()) break;
                if (mc.gameSettings.keyBindJump.isKeyDown()) {
                    mc.thePlayer.motionY = 0.5;
                } else if (mc.gameSettings.keyBindSneak.isKeyDown()) {
                    mc.thePlayer.motionY = -0.5;
                } else {
                    mc.thePlayer.motionY = 0.0;
                }
                MovementUtils.setSpeed(event, 0.28);
            }
        }
    }
}

