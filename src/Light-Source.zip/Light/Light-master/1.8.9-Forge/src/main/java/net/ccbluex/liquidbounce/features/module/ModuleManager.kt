
package net.ccbluex.liquidbounce.features.module
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.KeyEvent
import net.ccbluex.liquidbounce.event.Listenable
import net.ccbluex.liquidbounce.features.module.modules.player.Derp
import net.ccbluex.liquidbounce.features.module.modules.player.SkinDerp
import net.ccbluex.liquidbounce.features.module.modules.combat.*
import net.ccbluex.liquidbounce.features.module.modules.misc.*
import net.ccbluex.liquidbounce.features.module.modules.movement.*
import net.ccbluex.liquidbounce.features.module.modules.player.*
import net.ccbluex.liquidbounce.features.module.modules.render.*
import net.ccbluex.liquidbounce.features.module.modules.world.*
import net.ccbluex.liquidbounce.features.module.modules.world.Timer
import net.ccbluex.liquidbounce.utils.ClientUtils
import java.util.*
import kotlin.collections.ArrayList


class ModuleManager : Listenable {

    val modules = TreeSet<Module> { module1, module2 -> module1.name.compareTo(module2.name) }
    private val moduleClassMap = hashMapOf<Class<*>, Module>()

    override fun handleEvents() = true

    init {
        LiquidBounce.eventManager.registerListener(this)
    }

    /**
     * Register all modules
     */
    fun registerModules() {
        ClientUtils.getLogger().info("[ModuleManager] Loading modules...")

        registerModules(
                InvAnimation::class.java,
                Disabler::class.java,
                AutoBreak::class.java,
                HackerDetect::class.java,
                PerfectBody::class.java,
                AutoThrowSnowBall::class.java,
                AntiSpammer::class.java,
                MotionBlur::class.java,
                Crosshair::class.java,
                PlayerESP::class.java,
                TargetStrafe::class.java,
                DuelInfo::class.java,
                CheaterCheck::class.java,
                Compass::class.java,
                Scaffold::class.java,
                WorldColor::class.java,
                Criticals::class.java,
                TargetHUD::class.java,
                EffectShow::class.java,
                LagBackCheck::class.java,
                ServerSwitcher::class.java,
                MiniMap::class.java,
                LookTP::class.java,
                PlayerEdit::class.java,
                KeepSprint::class.java,
                AttackMiss::class.java,
                LightningDectet::class.java,
                Notifier::class.java,
                NewXRay::class.java,
                ItemPhysic::class.java,
                Emoji::class.java,
                AutoAbuse::class.java,
                AirJump::class.java,
                AntiFireball::class.java,
                NameTags::class.java,
                PointerESP::class.java,
                EnchantEffect::class.java,
                AntiObbyTrap::class.java,
                AutoHeal::class.java,
                Derp::class.java,
                SkinDerp::class.java,
                Ambience::class.java,
                ItemShow::class.java,
                FightBot::class.java,
                AntiFall::class.java,
                ModCheck::class.java,
                DamageParticle::class.java,
                KeyStrokes::class.java,
                ArmorBreaker::class.java,
                AutoGG::class.java,
                AutoL::class.java,
                FakeSwing::class.java,
                AntiFire::class.java,
                Animation::class.java,
                AutoArmor::class.java,
                AutoBow::class.java,
                AutoLeave::class.java,
                AutoWeapon::class.java,
                BowAimbot::class.java,
                Aura::class.java,
                Trigger::class.java,
                AntiKnockBack::class.java,
                Flight::class.java,
                ClickGUI::class.java,
                HighJump::class.java,
                InvWalk::class.java,
                NoSlowDown::class.java,
                Jesus::class.java,
                SafeWalk::class.java,
                WallClimb::class.java,
                Strafe::class.java,
                Sprint::class.java,
                Teams::class.java,
                AntiBot::class.java,
                ChestStealer::class.java,
                Tower::class.java,
                SpeedMine::class.java,
                FastPlace::class.java,
                ESP::class.java,
                Speed::class.java,
                Tracers::class.java,
                FastEat::class.java,
                Teleport::class.java,
                Fullbright::class.java,
                ItemESP::class.java,
                StorageESP::class.java,
                Projectiles::class.java,
                Nuker::class.java,
                PingSpoof::class.java,
                FastClimb::class.java,
                Step::class.java,
                AutoRespawn::class.java,
                AutoTool::class.java,
                NoWeb::class.java,
                Spammer::class.java,
                IceSpeed::class.java,
                Regen::class.java,
                NoFall::class.java,
                Blink::class.java,
                NameProtect::class.java,
                NoHurtCam::class.java,
                Ghost::class.java,
                MidClick::class.java,
                XRay::class.java,
                Timer::class.java,
                Sneak::class.java,
                GhostHand::class.java,
                AutoWalk::class.java,
                FreeCam::class.java,
                AimAssist::class.java,
                Eagle::class.java,
                HitBox::class.java,
                AntiCactus::class.java,
                Plugins::class.java,
                LongJump::class.java,
                FastBow::class.java,
                MultiActions::class.java,
                AutoClicker::class.java,
                BlockOverlay::class.java,
                NoFriends::class.java,
                BlockESP::class.java,
                Chams::class.java,
                Phase::class.java,
                ServerCrasher::class.java,
                NoFOV::class.java,
                InvCleaner::class.java,
                TrueSight::class.java,
                LiquidChat::class.java,
                AntiBlind::class.java,
                Breadcrumbs::class.java,
                AbortBreaking::class.java,
                CameraClip::class.java,
                NoPitchLimit::class.java,
                Kick::class.java,
                Liquids::class.java,
                AirLadder::class.java,
                TPHit::class.java,
                ForceUnicodeChat::class.java,
                SuperKnockback::class.java,
                ProphuntESP::class.java,
                AutoFish::class.java,
                Reach::class.java,
                Rotations::class.java,
                HUD::class.java,
                ComponentOnHover::class.java,
                ResourcePackSpoof::class.java,
                NoSlowBreak::class.java,
                PortalMenu::class.java,
                TPAura::class.java
        )

        registerModule(NoScoreboard)
        registerModule(Fucker)
        registerModule(ChestAura)

        ClientUtils.getLogger().info("[ModuleManager] Loaded ${modules.size} modules.")
    }

    fun getModulesByName(name: String): ArrayList<Module> {
        val moduleArray = ArrayList<Module>()
        for(i in modules) {
            if(i.name.toLowerCase().contains(name.toLowerCase()))
                moduleArray.add(i)
        }
        return moduleArray
    }

    fun getEnabledModule(): TreeSet<Module> {
        val modules2: TreeSet<Module> = modules
        for (i in modules) {
            if (i.state)
                modules2.add(i)
        }
        return modules2
    }

    /**
     * Register [module]
     */
    fun registerModule(module: Module) {
        modules += module
        moduleClassMap[module.javaClass] = module

        generateCommand(module)
        LiquidBounce.eventManager.registerListener(module)
    }

    /**
     * Register [moduleClass]
     */
    fun registerModule(moduleClass: Class<out Module>) {
        try {
            registerModule(moduleClass.newInstance())
        } catch (e: Throwable) {
            ClientUtils.getLogger().error("Failed to load module: ${moduleClass.name} (${e.javaClass.name}: ${e.message})")
        }
    }

    /**
     * Register a list of modules
     */
    @SafeVarargs
    fun registerModules(vararg modules: Class<out Module>) {
        modules.forEach(this::registerModule)
    }

    /**
     * Unregister module
     */
    fun unregisterModule(module: Module) {
        modules.remove(module)
        moduleClassMap.remove(module::class.java)
        LiquidBounce.eventManager.unregisterListener(module)
    }

    /**
     * Generate command for [module]
     */
    internal fun generateCommand(module: Module) {
        val values = module.values

        if (values.isEmpty())
            return

        LiquidBounce.commandManager.registerCommand(ModuleCommand(module, values))
    }

    fun getModuleInCategory(Category: ModuleCategory): ArrayList<Module> {
        val moduleInCategory = ArrayList<Module>()
        for (i in this.modules) {
            if (i.category != Category)
                continue
            moduleInCategory.add(i)
        }
        return moduleInCategory
    }

    /**
     * Legacy stuff
     *
     * TODO: Remove later when everything is translated to Kotlin
     */

    /**
     * Get module by [moduleClass]
     */
    fun getModule1(moduleClass: Class<*>) = moduleClassMap[moduleClass]

    operator fun <T : Module>get(clazz: Class<T>) :T= getModule(clazz)

    fun <T : Module> getModule(clazz: Class<T>): T = moduleClassMap[clazz] as T



    /**
     * Get module by [moduleName]
     */
    fun getModule(moduleName: String?) = modules.find { it.name.equals(moduleName, ignoreCase = true) }

    /**
     * Module related events
     */

    /**
     * Handle incoming key presses
     */
    @EventTarget
    private fun onKey(event: KeyEvent) = modules.filter { it.keyBind == event.key }.forEach { it.toggle() }
}