
package net.ccbluex.liquidbounce.features.module.modules.player

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo

@ModuleInfo(name = "AbortBreaking", description = "Allows you to abort breaking.", category = ModuleCategory.PLAYER,fakeName = "Keep Breaking")
class AbortBreaking : Module()