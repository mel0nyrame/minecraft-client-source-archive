package net.ccbluex.liquidbounce.features.module.modules.world

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.timer.TimeUtils
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.network.Packet
import net.minecraft.network.play.client.C00PacketKeepAlive
import net.minecraft.network.play.client.C16PacketClientStatus
import java.util.*

@ModuleInfo(name = "PingSpoof", description = "Spoofs your ping to a given value.", category = ModuleCategory.PLAYER, fakeName = "Ping Spoof")
class PingSpoof : Module() {
    private val maxDelayValue: IntegerValue = object : IntegerValue("MaxDelay", 1000, 0, 5000) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val minDelayValue = minDelayValue.get()
            if (minDelayValue > newValue) set(minDelayValue)
        }
    }
    private val minDelayValue: IntegerValue = object : IntegerValue("MinDelay", 500, 0, 5000) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val maxDelayValue = maxDelayValue.get()
            if (maxDelayValue < newValue) set(maxDelayValue)
        }
    }
    private val packetsMap = HashMap<Packet<*>, Long?>()
    override fun onDisable() {
        packetsMap.clear()
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if ((packet is C00PacketKeepAlive || packet is C16PacketClientStatus) && !(mc.thePlayer.isDead || mc.thePlayer.health <= 0) && !packetsMap.containsKey(packet)) {
            event.cancelEvent()
            synchronized(packetsMap) { packetsMap.put(packet, System.currentTimeMillis() + TimeUtils.randomDelay(minDelayValue.get(), maxDelayValue.get())) }
        }
    }

    @EventTarget(ignoreCondition = true)
    fun onUpdate(event: UpdateEvent) {
        try {
            synchronized(packetsMap) {
                //val iterator: MutableIterator<Map.Entry<Packet<*>, Long?>> = packetsMap.entries.iterator()
                for(entry in packetsMap.entries)
                    if(entry.value!! < System.currentTimeMillis())
                        mc.netHandler.addToSendQueue(entry.key)
                /*while (iterator.hasNext()) {
                    val entry = iterator.next()
                    if (entry.value!! < System.currentTimeMillis()) {
                        mc.netHandler.addToSendQueue(entry.key)
                        iterator.remove()
                    }
                }*/
            }
        } catch (t: Throwable) {
            t.printStackTrace()
        }
    }
}