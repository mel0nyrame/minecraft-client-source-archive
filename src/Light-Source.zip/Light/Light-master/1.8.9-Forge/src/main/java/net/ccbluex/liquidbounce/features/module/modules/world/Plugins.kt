package net.ccbluex.liquidbounce.features.module.modules.world

import joptsimple.internal.Strings
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.timer.TickTimer
import net.minecraft.network.play.client.C14PacketTabComplete
import net.minecraft.network.play.server.S3APacketTabComplete
import java.util.*

@ModuleInfo(name = "Plugins", description = "Allows you to see which plugins the server is using.", category = ModuleCategory.WORLD)
class Plugins : Module() {
    private val tickTimer = TickTimer()
    override fun onEnable() {
        if (mc.thePlayer == null) return
        mc.netHandler.addToSendQueue(C14PacketTabComplete("/"))
        tickTimer.reset()
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        tickTimer.update()
        if (tickTimer.hasTimePassed(20)) {
            ClientUtils.displayChatMessage("§cPlugins check timed out...")
            tickTimer.reset()
            state = false
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (event.packet is S3APacketTabComplete) {
            val plugins: MutableList<String> = ArrayList()
            val commands = event.packet.func_149630_c()
            for (command1 in commands) {
                val command = command1.split(":".toRegex()).toTypedArray()
                if (command.size > 1) {
                    val pluginName = command[0].replace("/", "")
                    if (!plugins.contains(pluginName)) plugins.add(pluginName)
                }
            }
            plugins.sort()
            if (plugins.isNotEmpty()) ClientUtils.displayChatMessage("§aPlugins §7(§8" + plugins.size + "§7): §c" + Strings.join(plugins.toTypedArray(), "§7, §c")) else ClientUtils.displayChatMessage("§cNo plugins found.")
            state = false
            tickTimer.reset()
        }
    }
}