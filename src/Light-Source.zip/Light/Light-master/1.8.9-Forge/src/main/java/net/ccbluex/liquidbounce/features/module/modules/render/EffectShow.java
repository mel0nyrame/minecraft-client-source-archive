package net.ccbluex.liquidbounce.features.module.modules.render;

import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render2DEvent;
import net.ccbluex.liquidbounce.features.module.*;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.*;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.inventory.IInventory;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import java.awt.*;
import java.util.Collection;

@ModuleInfo(name = "EffectShow", description = "Show the effect", category = ModuleCategory.RENDER, fakeName = "Effect Show")
public class EffectShow extends Module {
    private void drawRectWithSmoothCorner(float paramXStart, float paramYStart, float paramXEnd,float paramYEnd, float radius,int color) {
        float xStart = paramXStart;
        float yStart = paramYStart;
        float xEnd = paramXEnd;
        float yEnd = paramYEnd;
        float x1 = xStart + radius;
        float y1 = yStart + radius;
        float x2 = xEnd - radius;
        float y2 = yEnd - radius;
        RenderUtils.drawRect(x1, y1, x2, y2, color);//中心
        RenderUtils.drawRect(x1, yStart, x2, y1, color);//上
        RenderUtils.drawRect(x1, y2, x2, yEnd, color);//下
        RenderUtils.drawRect(xStart, y1, x1, y2, color);//左
        RenderUtils.drawRect(x2, y1, xEnd, y2, color);//右
        drawSector(x2, y2, radius, 0, 90, color);
        drawSector(x2, y1, radius, 90, 180, color);
        drawSector(x1, y1, radius, 180, 270, color);
        drawSector(x1, y2, radius, 270, 360, color);
    }
    private void drawSector(float paramX, float paramY, float radius, int angleStart, float angleEnd,int color) {
        float alpha = (color >> 24 & 0xFF) / 255;
        float red = (color >> 16 & 0xFF) / 255;
        float green = (color >> 8 & 0xFF) / 255;
        float blue = (color & 0xFF) / 255;

        GL11.glColor4f(red, green, blue, alpha);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glPushMatrix();
        GL11.glLineWidth(1);
        GL11.glBegin(GL11.GL_POLYGON);
        GL11.glVertex2d(paramX, paramY);
        for (int i = angleStart; i <= angleEnd; i++)
            GL11.glVertex2d(paramX + Math.sin(i * Math.PI / 180) * radius, paramY + Math.cos(i * Math.PI / 180) * radius);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glColor4f(1, 1, 1, 1);
    }
    private void drawTexturedModalRect(double x, double y, double textureX, double textureY, double width, double height) {
        double f = 0.00390625;
        double f1 = 0.00390625;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
        worldrenderer.pos(x + 0, y + height, 0.0).tex((textureX + 0) * f, (textureY + height) * f1).endVertex();
        worldrenderer.pos(x + width, y + height, 0.0).tex((textureX + width) * f, (textureY + height) * f1).endVertex();
        worldrenderer.pos(x + width, y + 0, 0.0).tex((textureX + width) * f, (textureY + 0) * f1).endVertex();
        worldrenderer.pos(x + 0, y + 0, 0.0).tex((textureX + 0) * f, (textureY + 0) * f1).endVertex();
        tessellator.draw();
    }
    private final ScaledResolution scaledResolution = new ScaledResolution(mc);
    private final IntegerValue x = new IntegerValue("xCoord", 1, 1, scaledResolution.getScaledWidth());
    private final IntegerValue y = new IntegerValue("yCoord", 50, 1, scaledResolution.getScaledHeight());
    private final FloatValue scale = new FloatValue("Scale", 1.0F, 0.1F, 5.0F);
    private final BoolValue renderBackground = new BoolValue("RenderBackground", true);
    private final BoolValue narrow = new BoolValue("NarrowOnFull", true);
    private final BoolValue color = new BoolValue("EffectColor", true);
    private final ListValue direction = new ListValue("Direction", new String[] {"Up","Down"}, "Down");
    private final ListValue bgMode = new ListValue("BackGroundTheme", new String[]{"ResourcePack","Custom"}, "ResourcePack");
    private final IntegerValue customR = new IntegerValue("CustomTheme-R", 255, 0, 255);
    private final IntegerValue customG = new IntegerValue("CustomTheme-G", 255, 0, 255);
    private final IntegerValue customB = new IntegerValue("CustomTheme-B", 255, 0, 255);
    private final IntegerValue customAlpha = new IntegerValue("CustomTheme-Alpha", 180, 1, 255);
    private final IntegerValue space = new IntegerValue("Space", 1, 0, 10);
    private final IntegerValue customRadius = new IntegerValue("CustomTheme-CornerRadius", 3, 0, 10);
    private final ResourceLocation inventoryBackground = new ResourceLocation("textures/gui/container/inventory.png");
    @EventTarget
    private void onRender2D(Render2DEvent render2DEvent) {
        float Scale = scale.get();
        int customColor = new Color(customR.get(), customG.get(), customB.get(), customAlpha.get()).getRGB();
        if (!(mc.currentScreen instanceof IInventory)) {
            GlStateManager.pushMatrix();
            GlStateManager.scale(Scale, Scale, Scale);
            int i = x.get();
            int j = y.get();
            Collection<PotionEffect> collection = mc.thePlayer.getActivePotionEffects();
            Object[] collection1 = mc.thePlayer.getActivePotionEffects().toArray();
            if (!collection.isEmpty()) {
                GlStateManager.color(1, 1, 1, 1);
               // GlStateManager.disableLighting();
                int l = 32 + space.get();
                if (collection.size() > 5 && narrow.get()) {
                    l = 132 / (collection.size() - 1);
                }

                GlStateManager.color(1, 1, 1, 1);
                for (Object o : collection1) {
                    mc.getTextureManager().bindTexture(inventoryBackground);
                    PotionEffect potioneffect = (PotionEffect) o;
                    Potion potion = Potion.potionTypes[potioneffect.getPotionID()];
                    if (!potion.shouldRender(potioneffect)) continue;

                    if (renderBackground.get()) {
                        if (bgMode.get().equals("ResourcePack"))
                            drawTexturedModalRect(i, j, 0, 166, 140, 32);
                        else {
                            drawRectWithSmoothCorner(i, j, i + 120, j + 32, customRadius.get(), customColor);
                        }
                    }
                    if (potion.hasStatusIcon()) {
                        int i1 = potion.getStatusIconIndex();
                        drawTexturedModalRect(i + 6, j + 7, (i1 % 8) * 18, 198 + (i1 / 8) * 18, 18, 18);
                    }
                    //potion.renderInventoryEffect(i, j, potioneffect, mc);
                    if (!potion.shouldRenderInvText(potioneffect)) continue;
                    String s1 = I18n.format(potion.getName());
                    if (potioneffect.getAmplifier() == 0) s1 = s1 + " I";
                    else if (potioneffect.getAmplifier() == 1) s1 = s1 + " II";
                    else if (potioneffect.getAmplifier() == 2) s1 = s1 + " III";
                    else if (potioneffect.getAmplifier() == 3) s1 = s1 + " IV";
                    else if (potioneffect.getAmplifier() == 4) s1 = s1 + " V";
                    else if (potioneffect.getAmplifier() == 5) s1 = s1 + " VI";
                    else if (potioneffect.getAmplifier() == 6) s1 = s1 + " VII";
                    else if (potioneffect.getAmplifier() == 7) s1 = s1 + " VIII";
                    else if (potioneffect.getAmplifier() == 8) s1 = s1 + " IX";
                    else if (potioneffect.getAmplifier() == 9) s1 = s1 + " X";
                    else if (potioneffect.getAmplifier() >= 10) s1 = s1 + " X+";
                    else s1 = s1 + " Unknown level";

                    //Fonts.font40.drawString("s1", i + 10 + 18, j + 6, (color.get() ? potion.getLiquidColor() : 16777215));
                    Fonts.font35.drawStringWithShadow(s1, i + 10 + 18, j + 6, (color.get() ? potion.getLiquidColor() : 16777215));
                    String s = Potion.getDurationString(potioneffect);
                    Fonts.font35.drawStringWithShadow(s, i + 10 + 18, j + 16, 8355711);
                    if (direction.get().equals("Down"))
                        j += l;
                    else j -= l;
                }
            }
            GlStateManager.popMatrix();
        }
    }
}
