package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render3DEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.world.AntiBot
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.util.ResourceLocation
import org.lwjgl.opengl.GL11

@ModuleInfo(name = "Emoji", description = "Emoji", category = ModuleCategory.RENDER)
class Emoji : Module() {
    private val modeValue = ListValue("Mode", arrayOf("TaiJun", "Yaoer", "Ganga", "XiaoZhao", "Blake"), "Yaoer")
    private val yaoer: Meme = Meme("liquidbounce/emoji/yaoer.png")
    private val taijun: Meme = Meme("liquidbounce/emoji/taijun.png")
    private val ganga: Meme = Meme("liquidbounce/emoji/ganga.png")
    private val xiaozhao: Meme = Meme("liquidbounce/emoji/xiaozhao.png")
    private val blake: Meme = Meme("liquidbounce/emoji/blake.png")
    @EventTarget
    fun onRender(event: Render3DEvent) {
        for (p in mc.theWorld.playerEntities) {
            if (p !== mc.thePlayer && p.canEntityBeSeen(mc.thePlayer) && !AntiBot.isBot(p) && !p.isInvisible) {
                val pX = (p.lastTickPosX + (p.posX - p.lastTickPosX) * mc.timer.renderPartialTicks
                        - mc.renderManager.renderPosX)
                val pY = (p.lastTickPosY + (p.posY - p.lastTickPosY) * mc.timer.renderPartialTicks
                        - mc.renderManager.renderPosY)
                val pZ = (p.lastTickPosZ + (p.posZ - p.lastTickPosZ) * mc.timer.renderPartialTicks
                        - mc.renderManager.renderPosZ)
                GL11.glPushMatrix()
                GL11.glTranslatef(pX.toFloat(), pY.toFloat() + if (p.isSneaking) 0.8f else 1.3f, pZ.toFloat())
                GL11.glNormal3f(1.0f, 1.0f, 1.0f)
                GL11.glRotatef(-mc.renderManager.playerViewY, 0.0f, 1.0f, 0.0f)
                GL11.glRotatef(mc.renderManager.playerViewX, 1.0f, 0.0f, 0.0f)
                val scale = 0.06f
                GL11.glScalef(-scale, -scale, scale)
                GL11.glDisable(GL11.GL_LIGHTING)
                GL11.glDisable(GL11.GL_DEPTH_TEST)
                GL11.glEnable(GL11.GL_BLEND)
                GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA)
                GL11.glPushMatrix()
                GL11.glColor4f(1f, 1f, 1f, 1f)
                when (modeValue.get()) {
                    "Yaoer" -> RenderUtils.drawImage(yaoer.resourceLocation, -8, -14, 16, 16)
                    "TaiJun" -> RenderUtils.drawImage(taijun.resourceLocation, -8, -14, 16, 16)
                    "Ganga" -> RenderUtils.drawImage(ganga.resourceLocation, -8, -14, 16, 16)
                    "Blake" -> RenderUtils.drawImage(blake.resourceLocation, -8, -14, 16, 16)
                    "XiaoZhao" -> RenderUtils.drawImage(xiaozhao.resourceLocation, -8, -14, 16, 16)
                }
                GL11.glPopMatrix()
                GL11.glPopMatrix()
            }
        }
    }

    inner class Meme(var name: String) {
        var size = 8
        val resourceLocation: ResourceLocation
            get() = ResourceLocation(this.name)

    }
}