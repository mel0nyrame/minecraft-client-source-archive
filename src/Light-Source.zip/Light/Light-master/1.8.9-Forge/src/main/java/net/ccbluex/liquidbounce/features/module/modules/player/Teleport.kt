package net.ccbluex.liquidbounce.features.module.modules.player

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.TickEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.path.CustomVec3
import net.ccbluex.liquidbounce.utils.path.PathfindingUtils
import net.minecraft.entity.player.PlayerCapabilities
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition
import net.minecraft.network.play.client.C0FPacketConfirmTransaction
import net.minecraft.network.play.client.C13PacketPlayerAbilities
import net.minecraft.network.play.server.S08PacketPlayerPosLook

@ModuleInfo(name = "Teleport", description = "Allows you to teleport around.", category = ModuleCategory.PLAYER, fakeName = "Tele port")
class Teleport : Module() {
    var tp = false
    override fun onEnable() {
        if (mc.thePlayer == null) return
        tp = false
        val playerCapabilities = PlayerCapabilities()
        playerCapabilities.isFlying = true
        mc.netHandler.addToSendQueue(C13PacketPlayerAbilities(playerCapabilities))
        mc.netHandler.addToSendQueue(C0FPacketConfirmTransaction(0, (-1).toShort(), false))
        mc.netHandler.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX,
                mc.thePlayer.posY + 0.17, mc.thePlayer.posZ, true))
        mc.netHandler.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX,
                mc.thePlayer.posY + 0.06, mc.thePlayer.posZ, true))
        mc.thePlayer.stepHeight = 0.0F
        mc.thePlayer.motionX = 0.0
        mc.thePlayer.motionZ = 0.0
    }

    override fun onDisable() {
        mc.timer.timerSpeed = 1.0f
        mc.thePlayer.stepHeight = 0.625f
        mc.thePlayer.motionX = 0.0
        mc.thePlayer.motionZ = 0.0
        isTPPlayer = false
        playername = null
    }

    @EventTarget
    fun onTick(event: TickEvent) {
        if (isTPPlayer) {
            if (mc.theWorld.getPlayerEntityByName(playername) == null) {
                state = false
                return
            }
            x = mc.theWorld.getPlayerEntityByName(playername).posX.toFloat()
            y = mc.theWorld.getPlayerEntityByName(playername).posY.toFloat() + 3
            z = mc.theWorld.getPlayerEntityByName(playername).posZ.toFloat()
        }
        if (tp) {
            for (vec3 in PathfindingUtils.computePath(
                    CustomVec3(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ),
                    CustomVec3(x.toDouble(), y.toDouble(), z.toDouble()))) {
                    mc.netHandler.addToSendQueue(C04PacketPlayerPosition(vec3.x,
                            vec3.y, vec3.z, false))
            }
            //Teleported
            mc.thePlayer.setPosition(x.toDouble(), y.toDouble(), z.toDouble())
            state = false
        }
    }

    @EventTarget
    fun onMove(event: MoveEvent) {
        MovementUtils.setSpeed(event, 0.0)
        mc.thePlayer.motionY = 0.0
        event.y = 0.0
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (!tp && event.packet is C03PacketPlayer) {
            event.cancelEvent()
        }
        if (event.packet is S08PacketPlayerPosLook) {
            if (!tp) {
                tp = true
            }
        }
    }

    companion object {
        var x = 0f
        var y = 0f
        var z = 0f
        var isTPPlayer = false
        var playername: String? = null
    }
}