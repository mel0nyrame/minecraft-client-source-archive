
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other;

import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.MoveEvent;
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed;
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode;
import net.ccbluex.liquidbounce.utils.MovementUtils;

public class CustomSpeed extends SpeedMode {

    public CustomSpeed() {
        super("Custom");
    }

    @Override
    public void onMotion() {
        if(MovementUtils.isMoving()) {
            final Speed speed = (Speed) LiquidBounce.moduleManager.getModule(Speed.class);

            if(speed == null)
                return;

            mc.timer.timerSpeed = speed.getCustomTimerValue().get();

            if(mc.thePlayer.onGround) {
                MovementUtils.strafe(speed.getCustomSpeedValue().get());
                mc.thePlayer.motionY = speed.getCustomYValue().get();
            }else if(speed.getCustomStrafeValue().get())
                MovementUtils.strafe(speed.getCustomSpeedValue().get());
            else
                MovementUtils.strafe();
        }else
            mc.thePlayer.motionX = mc.thePlayer.motionZ = 0D;
    }

    @Override
    public void onEnable() {
        final Speed speed = (Speed) LiquidBounce.moduleManager.getModule(Speed.class);

        if(speed == null)
            return;

        if(speed.getResetXZValue().get()) mc.thePlayer.motionX = mc.thePlayer.motionZ = 0D;
        if(speed.getResetYValue().get()) mc.thePlayer.motionY = 0D;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        mc.timer.timerSpeed = 1F;
        super.onDisable();
    }

    @Override
    public void onUpdate() {

    }

    @Override
    public void onMove(MoveEvent event) {
    }
}
