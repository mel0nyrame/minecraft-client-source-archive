package net.ccbluex.liquidbounce.features.module.modules.render;

import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.ListValue;

@ModuleInfo(
        name = "InvAnimation",
        description = "Inventory Animation.",
        category = ModuleCategory.RENDER,
        fakeName = "Inv Animation"
)
public class InvAnimation extends Module {
    public InvAnimation() {
        setState(true);
    }
    public final ListValue animationModeValue = new ListValue("AnimationMode", new String[]{"Fade1","Fade2","Fade3"}, "Fade3");
    public final FloatValue speedValue = new FloatValue("Speed",4F,0.1F,10F);
    public final FloatValue smoothSpeedValue = new FloatValue("SmoothSpeed",1F,0.01F,1F);
    public final FloatValue endValue = new FloatValue("End", 1F,1F, 10F);
}
