package net.ccbluex.liquidbounce.features.module.modules.render;
import java.awt.Color;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render2DEvent;
import net.ccbluex.liquidbounce.event.Render3DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.features.module.modules.misc.Teams;
import net.ccbluex.liquidbounce.utils.EntityUtils;
import net.ccbluex.liquidbounce.utils.math.Vec3f;
import net.ccbluex.liquidbounce.utils.render.Colors;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.*;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;

import static net.ccbluex.liquidbounce.features.module.modules.render.TargetHUD.blendColors;

@ModuleInfo(name = "PlayerESP", description = "Show the entity.", category = ModuleCategory.RENDER, fakeName = "Player ESP")
public class PlayerESP extends Module {
    private ArrayList<Vec3f> points = new ArrayList();
    private ListValue mode = new ListValue("Mode", new String[] {"ExBox","CornerB","Split"},"ExBox");
    private BoolValue HEALTH = new BoolValue("Health" , true);
    private Map<EntityLivingBase, double[]> entityConvertedPointsMap;
    FontRenderer fr;
    @Override
    public String getTag() {
        return mode.get();
    }

    public PlayerESP() {
        for (int i2 = 0; i2 < 8; ++i2) {
            points.add(new Vec3f());
        }
        entityConvertedPointsMap = new HashMap<>();
        fr = mc.fontRendererObj;
    }

    @EventTarget
    public void onRender3D(final Render3DEvent event) {
        try {
            updatePositions();
        } catch (Exception ignored) {
        }
    }

    @EventTarget
    public void onRender2D(final Render2DEvent event) {
        GlStateManager.pushMatrix();
        for (final Entity entity : entityConvertedPointsMap.keySet()) {
            final EntityPlayer ent = (EntityPlayer) entity;
            final double[] renderPositions = entityConvertedPointsMap.get(ent);
            final double[] renderPositionsBottom = { renderPositions[4], renderPositions[5], renderPositions[6] };
            final double[] renderPositionsX = { renderPositions[7], renderPositions[8], renderPositions[9] };
            final double[] renderPositionsX2 = { renderPositions[10], renderPositions[11], renderPositions[12] };
            final double[] renderPositionsZ = { renderPositions[13], renderPositions[14], renderPositions[15] };
            final double[] renderPositionsZ2 = { renderPositions[16], renderPositions[17], renderPositions[18] };
            final double[] renderPositionsTop1 = { renderPositions[19], renderPositions[20], renderPositions[21] };
            final double[] renderPositionsTop2 = { renderPositions[22], renderPositions[23], renderPositions[24] };
            GlStateManager.pushMatrix();
            GlStateManager.scale(0.5, 0.5, 0.5);
            if (EntityUtils.isSelected(entity, true)) {
                try {
                    final double[] xValues = { renderPositions[0], renderPositionsBottom[0], renderPositionsX[0],
                            renderPositionsX2[0], renderPositionsZ[0], renderPositionsZ2[0], renderPositionsTop1[0],
                            renderPositionsTop2[0] };
                    final double[] yValues = { renderPositions[1], renderPositionsBottom[1], renderPositionsX[1],
                            renderPositionsX2[1], renderPositionsZ[1], renderPositionsZ2[1], renderPositionsTop1[1],
                            renderPositionsTop2[1] };
                    double x = renderPositions[0];
                    double y = renderPositions[1];
                    double endx = renderPositionsBottom[0];
                    double endy = renderPositionsBottom[1];
                    double[] array;
                    for (int length = (array = xValues).length, j = 0; j < length; ++j) {
                        final double bdubs = array[j];
                        if (bdubs < x) {
                            x = bdubs;
                        }
                    }
                    double[] array2;
                    for (int length2 = (array2 = xValues).length, k = 0; k < length2; ++k) {
                        final double bdubs = array2[k];
                        if (bdubs > endx) {
                            endx = bdubs;
                        }
                    }
                    double[] array3;
                    for (int length3 = (array3 = yValues).length, l = 0; l < length3; ++l) {
                        final double bdubs = array3[l];
                        if (bdubs < y) {
                            y = bdubs;
                        }
                    }
                    double[] array4;
                    for (int length4 = (array4 = yValues).length, n = 0; n < length4; ++n) {
                        final double bdubs = array4[n];
                        if (bdubs > endy) {
                            endy = bdubs;
                        }
                    }
                    final double xDiff = (endx - x) / 4.0;
                    final double x2Diff = (endx - x) / 4.0;
                    Teams teams = (Teams) LiquidBounce.moduleManager.getModule(Teams.class);
                    int color;
                    assert teams != null;
                    if (teams.isInYourTeam(ent)) {
                        color = Colors.getColor(0, 255, 0, 255);
                    } else if (ent.hurtTime > 0) {
                        color = Colors.getColor(255, 0, 0, 255);
                    } else if (ent.isInvisible()) {
                        color = Colors.getColor(255, 255, 0, 255);
                    } else {
                        color = Colors.getColor(255,255,255);
                    }
                    if (mode.get().equalsIgnoreCase("Split")) {
                        RenderUtils.rectangle(x + 0.5, y + 0.5, x + 1.5, endy - 0.5, color);
                        RenderUtils.rectangle(x - 0.5, y + 0.5, x + 0.5, endy - 0.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + 1.5, y + 2.5, x + 2.5, endy - 2.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + 1.0, y + 0.5, x + xDiff, y + 1.5, color);
                        RenderUtils.rectangle(x - 0.5, y - 0.5, x + xDiff, y + 0.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + 1.5, y + 1.5, x + xDiff, y + 2.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + xDiff, y - 0.5, x + xDiff + 1.0, y + 2.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + 1.0, endy - 0.5, x + xDiff, endy - 1.5, color);
                        RenderUtils.rectangle(x - 0.5, endy + 0.5, x + xDiff, endy - 0.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + 1.5, endy - 1.5, x + xDiff, endy - 2.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + xDiff, endy + 0.5, x + xDiff + 1.0, endy - 2.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 0.5, y + 0.5, endx - 1.5, endy - 0.5, color);
                        RenderUtils.rectangle(endx + 0.5, y + 0.5, endx - 0.5, endy - 0.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 1.5, y + 2.5, endx - 2.5, endy - 2.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 1.0, y + 0.5, endx - xDiff, y + 1.5, color);
                        RenderUtils.rectangle(endx + 0.5, y - 0.5, endx - xDiff, y + 0.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 1.5, y + 1.5, endx - xDiff, y + 2.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - xDiff, y - 0.5, endx - xDiff - 1.0, y + 2.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 1.0, endy - 0.5, endx - xDiff, endy - 1.5, color);
                        RenderUtils.rectangle(endx + 0.5, endy + 0.5, endx - xDiff, endy - 0.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 1.5, endy - 1.5, endx - xDiff, endy - 2.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - xDiff, endy + 0.5, endx - xDiff - 1.0, endy - 2.5,
                                Colors.getColor(0, 150));
                    }
                    if (mode.get().equalsIgnoreCase("ExBox")) {
                        RenderUtils.rectangleBordered(x + 0.5, y + 0.5, endx - 0.5, endy - 0.5, 1.0,
                                Colors.getColor(0, 0, 0, 0), color);
                        RenderUtils.rectangleBordered(x - 0.5, y - 0.5, endx + 0.5, endy + 0.5, 1.0,
                                Colors.getColor(0, 0), Colors.getColor(0, 150));
                        RenderUtils.rectangleBordered(x + 1.5, y + 1.5, endx - 1.5, endy - 1.5, 1.0,
                                Colors.getColor(0, 0), Colors.getColor(0, 150));
                    }
                    if (mode.get().equalsIgnoreCase("CornerB")) {
                        RenderUtils.rectangle(x + 0.5, y + 0.5, x + 1.5, y + xDiff + 0.5, color);
                        RenderUtils.rectangle(x + 0.5, endy - 0.5, x + 1.5, endy - xDiff - 0.5, color);
                        RenderUtils.rectangle(x - 0.5, y + 0.5, x + 0.5, y + xDiff + 0.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + 1.5, y + 2.5, x + 2.5, y + xDiff + 0.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x - 0.5, y + xDiff + 0.5, x + 2.5, y + xDiff + 1.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(x - 0.5, endy - 0.5, x + 0.5, endy - xDiff - 0.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + 1.5, endy - 2.5, x + 2.5, endy - xDiff - 0.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(x - 0.5, endy - xDiff - 0.5, x + 2.5, endy - xDiff - 1.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + 1.0, y + 0.5, x + x2Diff, y + 1.5, color);
                        RenderUtils.rectangle(x - 0.5, y - 0.5, x + x2Diff, y + 0.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + 1.5, y + 1.5, x + x2Diff, y + 2.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + x2Diff, y - 0.5, x + x2Diff + 1.0, y + 2.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + 1.0, endy - 0.5, x + x2Diff, endy - 1.5, color);
                        RenderUtils.rectangle(x - 0.5, endy + 0.5, x + x2Diff, endy - 0.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + 1.5, endy - 1.5, x + x2Diff, endy - 2.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(x + x2Diff, endy + 0.5, x + x2Diff + 1.0, endy - 2.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 0.5, y + 0.5, endx - 1.5, y + xDiff + 0.5, color);
                        RenderUtils.rectangle(endx - 0.5, endy - 0.5, endx - 1.5, endy - xDiff - 0.5, color);
                        RenderUtils.rectangle(endx + 0.5, y + 0.5, endx - 0.5, y + xDiff + 0.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 1.5, y + 2.5, endx - 2.5, y + xDiff + 0.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx + 0.5, y + xDiff + 0.5, endx - 2.5, y + xDiff + 1.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx + 0.5, endy - 0.5, endx - 0.5, endy - xDiff - 0.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 1.5, endy - 2.5, endx - 2.5, endy - xDiff - 0.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx + 0.5, endy - xDiff - 0.5, endx - 2.5, endy - xDiff - 1.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 1.0, y + 0.5, endx - x2Diff, y + 1.5, color);
                        RenderUtils.rectangle(endx + 0.5, y - 0.5, endx - x2Diff, y + 0.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 1.5, y + 1.5, endx - x2Diff, y + 2.5, Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - x2Diff, y - 0.5, endx - x2Diff - 1.0, y + 2.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 1.0, endy - 0.5, endx - x2Diff, endy - 1.5, color);
                        RenderUtils.rectangle(endx + 0.5, endy + 0.5, endx - x2Diff, endy - 0.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - 1.5, endy - 1.5, endx - x2Diff, endy - 2.5,
                                Colors.getColor(0, 150));
                        RenderUtils.rectangle(endx - x2Diff, endy + 0.5, endx - x2Diff - 1.0, endy - 2.5,
                                Colors.getColor(0, 150));
                    }

                    if (HEALTH.getValue()) {
                        float health = ent.getHealth();
                        float[] fractions = new float[] { 0.0f, 0.5f, 1.0f };
                        Color[] colors = new Color[] { Color.RED, Color.YELLOW, Color.GREEN };
                        float progress = health / ent.getMaxHealth();
                        Color customColor = health >= 0.0f ? blendColors(fractions, colors, progress).brighter()
                                : Color.RED;
                        double difference = y - endy + 0.5;
                        double healthLocation = endy + difference * progress;
                        RenderUtils.rectangleBordered((x - 6.5), (y - 0.5), (x - 2.5),
                                endy, 1.0,  Colors.getColor( 0,  100),
                                 Colors.getColor( 0,  150));
                        RenderUtils.rectangle((x - 5.5), (endy - 1.0), (x - 3.5),
                                healthLocation,  customColor.getRGB());
                        if (-difference > 50.0) {
                            for (int i = 1; i < 10; ++i) {
                                double dThing = difference / 10.0 * i;
                                RenderUtils.rectangle((x - 6.5), (endy - 0.5 + dThing),
                                        (x - 2.5), (endy - 0.5 + dThing - 1.0),
                                         Colors.getColor( 0));
                            }
                        }
                        if ((int) getIncremental(progress * 100.0f, 1.0) <= 40) {
                            GlStateManager.pushMatrix();
                            GlStateManager.scale( 2.0f,  2.0f,  2.0f);
                            GlStateManager.popMatrix();
                        }
                    }
                } catch (Exception ignored) {
                }
            }
            GlStateManager.popMatrix();
            GL11.glColor4f( 1.0f,  1.0f,  1.0f,  1.0f);
        }
        GL11.glScalef( 1.0f,  1.0f,  1.0f);
        GL11.glColor4f( 1.0f,  1.0f,  1.0f,  1.0f);
        GlStateManager.popMatrix();
        RenderUtils.rectangle(0.0, 0.0, 0.0, 0.0, -1);
    }

    public static double getIncremental(final double val, final double inc) {
        final double one = 1.0 / inc;
        return Math.round(val * one) / one;
    }


    private void updatePositions() {
        entityConvertedPointsMap.clear();
        final float pTicks = mc.timer.renderPartialTicks;
        for (final Entity e2 : mc.theWorld.getLoadedEntityList()) {
            if (e2 instanceof EntityPlayer) {
                final EntityPlayer ent;
                if ((ent = (EntityPlayer) e2) == mc.thePlayer) {
                    continue;
                }
                double x = ent.lastTickPosX + (ent.posX - ent.lastTickPosX) * pTicks
                        - mc.getRenderManager().viewerPosX + 0.36;
                double y = ent.lastTickPosY + (ent.posY - ent.lastTickPosY) * pTicks
                        - mc.getRenderManager().viewerPosY;
                double z = ent.lastTickPosZ + (ent.posZ - ent.lastTickPosZ) * pTicks
                        - mc.getRenderManager().viewerPosZ + 0.36;
                final double topY;
                y = (topY = y + (ent.height + 0.15));
                final double[] convertedPoints = RenderUtils.convertTo2D(x, y, z);
                final double[] convertedPoints2 = RenderUtils.convertTo2D(x - 0.36, y, z - 0.36);
                final double xd = 0.0;
                assert convertedPoints2 != null;
                if (convertedPoints2[2] < 0.0) {
                    continue;
                }
                if (convertedPoints2[2] >= 1.0) {
                    continue;
                }
                x = ent.lastTickPosX + (ent.posX - ent.lastTickPosX) * pTicks - mc.getRenderManager().viewerPosX
                        - 0.36;
                z = ent.lastTickPosZ + (ent.posZ - ent.lastTickPosZ) * pTicks - mc.getRenderManager().viewerPosZ
                        - 0.36;
                final double[] convertedPointsBottom = RenderUtils.convertTo2D(x, y, z);
                y = ent.lastTickPosY + (ent.posY - ent.lastTickPosY) * pTicks - mc.getRenderManager().viewerPosY
                        - 0.05;
                final double[] convertedPointsx = RenderUtils.convertTo2D(x, y, z);
                x = ent.lastTickPosX + (ent.posX - ent.lastTickPosX) * pTicks - mc.getRenderManager().viewerPosX
                        - 0.36;
                z = ent.lastTickPosZ + (ent.posZ - ent.lastTickPosZ) * pTicks - mc.getRenderManager().viewerPosZ
                        + 0.36;
                final double[] convertedPointsTop1 = RenderUtils.convertTo2D(x, topY, z);
                final double[] convertedPointsx2 = RenderUtils.convertTo2D(x, y, z);
                x = ent.lastTickPosX + (ent.posX - ent.lastTickPosX) * pTicks - mc.getRenderManager().viewerPosX
                        + 0.36;
                z = ent.lastTickPosZ + (ent.posZ - ent.lastTickPosZ) * pTicks - mc.getRenderManager().viewerPosZ
                        + 0.36;
                final double[] convertedPointsz = RenderUtils.convertTo2D(x, y, z);
                x = ent.lastTickPosX + (ent.posX - ent.lastTickPosX) * pTicks - mc.getRenderManager().viewerPosX
                        + 0.36;
                z = ent.lastTickPosZ + (ent.posZ - ent.lastTickPosZ) * pTicks - mc.getRenderManager().viewerPosZ
                        - 0.36;
                final double[] convertedPointsTop2 = RenderUtils.convertTo2D(x, topY, z);
                final double[] convertedPointsz2 = RenderUtils.convertTo2D(x, y, z);
                assert convertedPoints != null;
                assert convertedPointsx != null;
                assert convertedPointsTop1 != null;
                assert convertedPointsTop2 != null;
                assert convertedPointsz2 != null;
                assert convertedPointsz != null;
                assert convertedPointsx2 != null;
                assert convertedPointsBottom != null;
                entityConvertedPointsMap.put(ent,
                        new double[] { convertedPoints[0], convertedPoints[1], xd, convertedPoints[2],
                                convertedPointsBottom[0], convertedPointsBottom[1], convertedPointsBottom[2],
                                convertedPointsx[0], convertedPointsx[1], convertedPointsx[2], convertedPointsx2[0],
                                convertedPointsx2[1], convertedPointsx2[2], convertedPointsz[0], convertedPointsz[1],
                                convertedPointsz[2], convertedPointsz2[0], convertedPointsz2[1], convertedPointsz2[2],
                                convertedPointsTop1[0], convertedPointsTop1[1], convertedPointsTop1[2],
                                convertedPointsTop2[0], convertedPointsTop2[1], convertedPointsTop2[2] });
            }
        }
    }

    public static void rectangle(double left, double top, double right, double bottom, int color) {
        if (left < right) {
            double var5 = left;
            left = right;
            right = var5;
        }
        if (top < bottom) {
            double var5 = top;
            top = bottom;
            bottom = var5;
        }
        float var11 = (color >> 24 & 0xFF) / 255.0F;
        float var6 = (color >> 16 & 0xFF) / 255.0F;
        float var7 = (color >> 8 & 0xFF) / 255.0F;
        float var8 = (color & 0xFF) / 255.0F;
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tessellator.getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(var6, var7, var8, var11);
        worldRenderer.begin(7, DefaultVertexFormats.POSITION);
        worldRenderer.pos(left, bottom, 0.0D).endVertex();
        worldRenderer.pos(right, bottom, 0.0D).endVertex();
        worldRenderer.pos(right, top, 0.0D).endVertex();
        worldRenderer.pos(left, top, 0.0D).endVertex();
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void drawBorderedRect(float x, float y, float x2, float y2, float l1, int col1, int col2) {
        drawRect(x, y, x2, y2, col2);
        float f = (float) (col1 >> 24 & 255) / 255.0F;
        float f1 = (float) (col1 >> 16 & 255) / 255.0F;
        float f2 = (float) (col1 >> 8 & 255) / 255.0F;
        float f3 = (float) (col1 & 255) / 255.0F;
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GL11.glPushMatrix();
        GL11.glColor4f(f1, f2, f3, f);
        GL11.glLineWidth(l1);
        GL11.glBegin(1);
        GL11.glVertex2d(x, y);
        GL11.glVertex2d(x, y2);
        GL11.glVertex2d(x2, y2);
        GL11.glVertex2d(x2, y);
        GL11.glVertex2d(x, y);
        GL11.glVertex2d(x2, y);
        GL11.glVertex2d(x, y2);
        GL11.glVertex2d(x2, y2);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
    }

    public static void drawRect(float g, float h, float i, float j, int col1) {
        float f = (float) (col1 >> 24 & 255) / 255.0F;
        float f1 = (float) (col1 >> 16 & 255) / 255.0F;
        float f2 = (float) (col1 >> 8 & 255) / 255.0F;
        float f3 = (float) (col1 & 255) / 255.0F;
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GL11.glPushMatrix();
        GL11.glColor4f(f1, f2, f3, f);
        GL11.glBegin(7);
        GL11.glVertex2d(i, h);
        GL11.glVertex2d(g, h);
        GL11.glVertex2d(g, j);
        GL11.glVertex2d(i, j);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
    }

    private boolean isValid(EntityLivingBase entity) {
        return EntityUtils.isSelected(entity, true);
    }

}
