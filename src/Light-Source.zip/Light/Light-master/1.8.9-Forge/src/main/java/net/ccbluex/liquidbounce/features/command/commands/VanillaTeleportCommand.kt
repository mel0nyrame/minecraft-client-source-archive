package net.ccbluex.liquidbounce.features.command.commands

import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.utils.PathUtils
import net.ccbluex.liquidbounce.utils.Vec4
import net.ccbluex.liquidbounce.utils.path.CustomVec3
import net.ccbluex.liquidbounce.utils.path.PathfindingUtils
import net.minecraft.entity.EntityLivingBase
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition
import java.util.*

class VanillaTeleportCommand : Command("VanillaTeleport", arrayOf("VanillaTP")) {
    var path = ArrayList<CustomVec3>()
    override fun execute(args: Array<String>) {
        if(args.size > 1) {
            for(i in mc.theWorld.getLoadedEntityList()) {
                if(i.name == args[1]) {
                    val entity = mc.theWorld.getPlayerEntityByName(args[1])
                    if(entity is EntityPlayer) {
                        if (mc.thePlayer.canEntityBeSeen(entity)) {
                            val topFrom = CustomVec3(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ)
                            val to = CustomVec3(entity.posX, entity.posY, entity.posZ)
                            path = PathfindingUtils.computePath(topFrom, to)
                            for (i in path) {
                                mc.thePlayer.sendQueue.addToSendQueue(C04PacketPlayerPosition(i.x, i.y, i.z, false))
                            }
                        } else {
                            chat("[VanillaTeleport] You can't teleport through the wall!!!")
                        }
                    }
                }
            }
        }
    }
}