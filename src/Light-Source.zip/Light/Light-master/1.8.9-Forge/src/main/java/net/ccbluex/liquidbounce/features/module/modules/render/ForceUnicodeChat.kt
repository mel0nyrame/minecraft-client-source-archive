package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.minecraft.network.play.client.C01PacketChatMessage

@ModuleInfo(name = "ChatBypass", description = "Allows you to send unicode messages in chat.", category = ModuleCategory.RENDER, fakeName = "Chat Filer")
class ForceUnicodeChat : Module() {
    override val tag: String
        get() = "Bypass"
    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (event.packet is C01PacketChatMessage) {
            val chatMessage = event.packet
            val message = chatMessage.getMessage()
            val stringBuilder = StringBuilder()
            for (c in message.toCharArray()) if (c.toInt() in 33..128) stringBuilder.append(Character.toChars(c.toInt() + 65248)) else stringBuilder.append(c)
            chatMessage.message = stringBuilder.toString()
        }
    }
}