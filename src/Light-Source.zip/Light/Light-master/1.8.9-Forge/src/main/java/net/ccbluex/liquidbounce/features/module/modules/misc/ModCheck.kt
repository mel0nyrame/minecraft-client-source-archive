package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.ui.client.Notifications
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.network.play.server.S02PacketChat
import java.awt.Color
import java.util.*

@ModuleInfo(name = "ModCheck", description = "Check staff online.", category = ModuleCategory.RENDER)
class ModCheck : Module() {
    private val modlist = arrayOf("Sir_Cow",
            "sfarnham",
            "DI4MONDTOOL",
            "Wind1000100",
            "tjbruce17594",
            "jenus_",
            "I_Call_Hacks",
            "geckor",
            "shayk",
            "hammyplaysgames",
            "okexox",
            "pinguin_eater",
            "Flafkas",
            "franz",
            "QuantumBlue",
            "Tiliba",
            "JakeDaaBud",
            "xi6",
            "Jayavarmen",
            "LadyBleu",
            "Mitch_The_Man",
            "DetectiveAndrew",
            "Carcroft",
            "pollefeys",
            "amamimi",
            "mrcraftyketchup",
            "cherry809",
            "Pensul",
            "Herocky"
    )
    private var modname: String? = null
    private val timer = MSTimer()
    private val offlinemod = ArrayList<Any?>()
    private val onlinemod = ArrayList<Any?>()
    private val showOnline = BoolValue("ShowOnline", true)
    private val showOffline = BoolValue("ShowOffline", true)
    private val blockmessage = BoolValue("BlockWatchdogMessage", true)
    private val hackwarning = BoolValue("HackerWarning", true)
    private val debug = BoolValue("Debug", true)
    private var counter = 0
    private var isFinished = false
    @EventTarget
    fun onRender(e: Render2DEvent) {
        val font = Fonts.font35
        val listArray = listOf(*modlist)
        var Mod = 0
        var Long = 0
        if (showOnline.get()) for (mods in listArray) {
            if (onlinemod.contains(mods)) {
                Long += 10
            }
        }
        if (showOffline.get() && onlinemod.isNotEmpty()) for (mods in listArray) {
            if (offlinemod.contains(mods)) {
                Long += 10
            }
        }
        if (onlinemod.isEmpty()) {
            Long += 10
        }
        RenderUtils.drawRoundedRect(5.0f, 100.0f, 120.0f, 111.0f, Color(0, 125, 255, 255).rgb, Color(0, 125, 255, 255).rgb)
        RenderUtils.drawRoundedRect(5.0f, 110.0f, 120.0f, (110 + Long).toFloat(), Color(255, 255, 255, 155).rgb, Color(255, 255, 255, 155).rgb)
        Long = 0
        if (showOnline.get()) for (mods in listArray) {
            // 如果客服不重复在线
            if (onlinemod.contains(mods)) {
                // 客服在线 Rect自动加长
                font.drawStringWithShadow(mods, 15f, 110 + Long.toFloat(), Color.GREEN.rgb)
                Long += 10
                Mod++ // Mod数值增加
            }
        }
        if (showOffline.get() && onlinemod.isNotEmpty()) for (mods in listArray) {
            // 如果客服不重复在线
            if (offlinemod.contains(mods)) {
                // 客服在线 Rect自动加长
                font.drawStringWithShadow(mods, 15f, 110 + Long.toFloat(), Color.RED.rgb)
                Long += 10
                Mod++ // Mod数值增加
            }
        }
        if (Mod < 1) if (showOnline.get() || showOffline.get()) {
            font.drawCenteredString("No Mod", 57.5f, 110.0f, Color(75, 75, 75).rgb)
        }
        font.drawCenteredString("OnlineModList(" + Mod + "/" + listArray.size + ")", 57.5f, 100.0f, Color(255, 255, 255).rgb)
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (event.packet is S02PacketChat) {
            val e = event.packet.chatComponent.unformattedText
            if (e.contains("--------------------")) {
                if (!debug.get()) {
                    event.cancelEvent()
                }
            }
            if (e.contains("[WATCHDOG]") && blockmessage.get()) {
                if (!debug.get()) {
                    event.cancelEvent()
                }
            }
            if (hackwarning.get()) {
                for (s in hackMessage) {
                    if (e.contains(s.toLowerCase()) && !e.contains("WATCHDOG") && !e.contains("Light")) {
                        ClientUtils.sendClientMessage("Someone says you are hacker!", Notifications.Type.WARNING)
                        break
                    }
                }
            }
            if (e.contains("玩家离线，你不能邀请") || e.contains("You cannot invite that player since they're not online.")) {
                if (!debug.get()) {
                    event.cancelEvent()
                }
                if (onlinemod.contains(modname)) {
                    ClientUtils.displayChatMessage("$modname§a已下线!")
                    onlinemod.remove(modname)
                    offlinemod.add(modname)
                    return
                }
                if (!offlinemod.contains(modname)) {
                    ClientUtils.displayChatMessage("$modname§a不在线!")
                    offlinemod.add(modname)
                }
            }
            if (e.contains("你不能邀请这位玩家入队") || e.contains("You cannot invite that player.")) {
                if (!debug.get()) {
                    event.cancelEvent()
                }
                if (offlinemod.contains(modname)) {
                    ClientUtils.displayChatMessage("$modname§a已上线!")
                    offlinemod.remove(modname)
                    onlinemod.add(modname)
                    return
                }
                if (!onlinemod.contains(modname)) {
                    ClientUtils.displayChatMessage("$modname§a在线!")
                    onlinemod.add(modname)
                }
            }
            if (e.contains("找不到名为 \"$modname\" 的玩家") || e.contains("Couldn't find a player with that name!")) {
                if (!debug.get()) {
                    event.cancelEvent()
                }
            }
        }
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (timer.hasTimePassed(if (isFinished) 10000L else 2000L)) {
            if (counter >= modlist.size) {
                counter = -1
                if (!isFinished) isFinished = true
            }
            counter++
            modname = modlist[counter]
            mc.thePlayer.sendChatMessage("/p $modname")
            timer.reset()
        }
    }

    companion object {
        var hackMessage = arrayOf("外挂",
                "黑客",
                "外G",
                "外瓜",
                "挂",
                "能飞",
                "自动攻击",
                "杀戮光环",
                "杀戮",
                "hack",
                "hacker",
                "hax",
                "挂哥",
                "reach",
                "反击退",
                "飞行",
                "卡无敌方块",
                "刷资源",
                "无敌方块",
                "嘴臭",
                "骂人",
                "孤儿",
                "挂逼",
                "挂壁",
                "卡bug",
                "自动搭路",
                "bhopper",
                "bhop",
                "report",
                "loser",
                "noob"
        )
    }
}