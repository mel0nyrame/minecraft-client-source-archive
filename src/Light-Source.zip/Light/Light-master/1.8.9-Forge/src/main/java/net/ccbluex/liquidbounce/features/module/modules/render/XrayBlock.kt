package net.ccbluex.liquidbounce.features.module.modules.render

class XrayBlock(var x: Int, var y: Int, var z: Int, var type: String)