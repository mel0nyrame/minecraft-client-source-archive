package net.ccbluex.liquidbounce.features.command.commands

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.utils.misc.StringUtils
import net.minecraft.client.Minecraft

class AntiSpammerCommand : Command("AntiSpammerMessage", emptyArray()) {
    private val mc = Minecraft.getMinecraft()
    /**
     * Execute commands with provided [args]
     */
    override fun execute(args: Array<String>) {
        if (args.size > 1) {
            val friendsConfig = LiquidBounce.fileManager.antiSpammerMessageConfig

            when {
                args[1].equals("add", ignoreCase = true) -> {
                    if (args.size > 2) {
                        val name = args[2]

                        if (name.isEmpty()) {
                            chat("The message is empty.")
                            return
                        }


                        if (if (args.size > 3) friendsConfig.addMessage(name, StringUtils.toCompleteString(args, 3)) else friendsConfig.addMessage(name)) {
                            LiquidBounce.fileManager.saveConfig(friendsConfig)
                            chat("§a§l$name§3 was added to your AntiSpammerMessage list.")
                            playEdit()
                        } else
                            chat("The message is already in the list.")
                        return
                    }
                    chatSyntax("AntiSpammerMessage add <name> [alias]")
                    return
                }

                args[1].equals("remove", ignoreCase = true) -> {
                    if (args.size > 2) {
                        val name = args[2]

                        if (friendsConfig.removeFriend(name)) {
                            LiquidBounce.fileManager.saveConfig(friendsConfig)
                            chat("§a§l$name§3 was removed from your AntiSpammerMessage list.")
                            playEdit()
                        } else
                            chat("This name is not in the list.")
                        return
                    }
                    chatSyntax("AntiSpammerMessage remove <name>")
                    return
                }

                args[1].equals("clear", ignoreCase = true) -> {
                    val friends = friendsConfig.getmessage().size
                    friendsConfig.clearmessage()
                    LiquidBounce.fileManager.saveConfig(friendsConfig)
                    chat("Removed $friends message(s).")
                    return
                }

                args[1].equals("list", ignoreCase = true) -> {
                    chat("Your Messages:")

                    for (friend in friendsConfig.getmessage())
                        chat("§7> §a§l${friend.playerName} §c(§7§l${friend.alias}§c)")

                    chat("You have §c${friendsConfig.getmessage().size}§3 messages.")
                    return
                }
            }
        }

        chatSyntax("AntiSpammerMessage <add/remove/list/clear>")
    }

    override fun tabComplete(args: Array<String>): List<String> {
        if (args.isEmpty()) return emptyList()

        return when (args.size) {
            1 -> listOf("add", "remove", "list", "clear").filter { it.startsWith(args[0], true) }
            2 -> {
                when (args[0].toLowerCase()) {
                    "add" -> {
                        return mc.theWorld.playerEntities
                                .map { it.name }
                                .filter { it.startsWith(args[1], true) }
                    }
                    "remove" -> {
                        return LiquidBounce.fileManager.friendsConfig.friends
                                .map { it.playerName }
                                .filter { it.startsWith(args[1], true) }
                    }
                }
                return emptyList()
            }
            else -> emptyList()
        }
    }
}