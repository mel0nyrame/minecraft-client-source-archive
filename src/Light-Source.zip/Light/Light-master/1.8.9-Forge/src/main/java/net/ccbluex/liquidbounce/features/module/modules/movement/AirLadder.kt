
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.FloatValue

@ModuleInfo(name = "AirLadder", description = "Allows you to climb up ladders/vines without touching them.", category = ModuleCategory.MOVEMENT,fakeName = "Air Ladder")
class AirLadder : Module() {
    private val motionYValue = FloatValue("MotionY", 0.11F,0.01F,0.5F)
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if(mc.thePlayer.isOnLadder) {
            mc.thePlayer.motionY = motionYValue.get().toDouble()
        }
    }
}