package net.ccbluex.liquidbounce.inputfix;

import java.util.Arrays;
import net.minecraftforge.fml.common.DummyModContainer;
import net.minecraftforge.fml.common.LoadController;
import net.minecraftforge.fml.common.ModMetadata;
import com.google.common.eventbus.EventBus;

public class InputFixDummyContainer extends DummyModContainer
{

    public InputFixDummyContainer()
    {
        super(new ModMetadata());
        ModMetadata meta = getMetadata();
        meta.modId = "Light";
        meta.name = "Light";
        meta.version = "1.8.x-v2";
        meta.authorList = Arrays.asList("CCBluex");
        meta.description = "Light Client is a best Hacked Client for Minecraft.";
        meta.credits = "Light-Dev";
        meta.url = "QQ2806509063";
    }

    @Override
    public boolean registerBus(EventBus bus, LoadController controller)
    {
        return true;
    }

}
