package net.ccbluex.liquidbounce.libraries.slick.command;

/**
 * Marker class for abstract input controls
 * 
 * @author joverton
 */
public interface Control {
}
