package net.ccbluex.liquidbounce.features.module.modules.movement;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.*;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.MovementUtils;
import net.ccbluex.liquidbounce.utils.PlayerUtil;
import net.ccbluex.liquidbounce.utils.timer.MSTimer;
import net.ccbluex.liquidbounce.value.*;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.network.*;
import net.minecraft.client.network.*;
import net.minecraft.client.entity.*;
import java.util.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.potion.*;
import net.minecraft.util.MathHelper;

@ModuleInfo(name = "ZoomFly", description = "ZoomFly Bypass Hypixel.", category = ModuleCategory.MOVEMENT)
public class ZoomFly extends Module
{
    private double moveSpeed = 0;
    private double lastDistance = 0;
    private int boostHypixelState = 1;
    private boolean failedStart = false;
    private int counter;
    private double bypass;
    private TargetStrafe targetStrafe = LiquidBounce.moduleManager.getModule(TargetStrafe.class);
    private final MSTimer delayTimer = new MSTimer();
    private final ListValue modeValue = new ListValue("Mode", new String[]{"UHC","Normal","Hypixel"}, "Hypixel");
    private final BoolValue changeTimer = new BoolValue("ChangeTimer", false);
    private final FloatValue playerTimer = new FloatValue("PlayerTimer", 1.5F,1F, 3F) {
        @Override
        protected void onChanged(Float oldValue, Float newValue) {
            if(newValue < getMinimum())
                set(getMinimum());
        }
    };
    private final IntegerValue timerDelayValue = new IntegerValue("TimerDelay", 1000,100,5000);
    private final BoolValue bob = new BoolValue("ViewBobbing", true);
    @Override
    public String getTag() {
        return "Hypixel";
    }

    public void damage() {
        if (!mc.thePlayer.onGround) {
            return;
        }
        delayTimer.reset();
        final double x = mc.thePlayer.posX;
        final double y = mc.thePlayer.posY;
        final double z = mc.thePlayer.posZ;
        final NetHandlerPlayClient netHandler = mc.getNetHandler();
        String mode = modeValue.get();
        if (mode.equals("Normal")) {
            for (int i = 0; i < (3 + MovementUtils.getJumpEffect()) / 0.0399999986886975; ++i) {
                final Random r = new Random();
                final double rd = r.nextDouble() * 1.0E-5;
                for (final double value : new double[]{0.0399999986886975 - rd, 0.03 + rd, rd}) {
                    netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + value, z, false));
                }
            }
        } else {
            for (int i = 0; i < (PlayerUtil.getMaxFallDist() + (mode.equalsIgnoreCase("UHC") ? 1.0 : 0.0)) / 0.05510000046342611 + 1.0; ++i) {
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.060100000351667404, z, false));
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 5.000000237487257E-4, z, false));
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.004999999888241291 + 6.01000003516674E-8, z, false));
            }
        }
        netHandler.addToSendQueue(new C03PacketPlayer(true));
        PlayerCapabilities playerCapabilities = new PlayerCapabilities();
        playerCapabilities.isFlying = true;
        netHandler.addToSendQueue(new C18PacketSpectate(mc.thePlayer.getUniqueID()));
        netHandler.addToSendQueue(new C13PacketPlayerAbilities(playerCapabilities));
        mc.thePlayer.jump();
        mc.thePlayer.posY += 0.41999998688697815;
        this.boostHypixelState = 1;
        this.moveSpeed = 0.1;
        this.lastDistance = 0.0;
        this.failedStart = false;
    }
    @EventTarget
    public void onJump(final JumpEvent event) {
        event.cancelEvent();
    }

    @EventTarget
    public void onPacket(final PacketEvent event) {
        final Packet<?> packet = event.getPacket();
        if(packet instanceof S08PacketPlayerPosLook)
            failedStart = true;
        if(packet instanceof C03PacketPlayer)
            ((C03PacketPlayer)packet).onGround = true;
    }

    @Override
    public void onEnable() {
        this.damage();
        final EntityPlayerSP player = mc.thePlayer;
        mc.timer.timerSpeed = playerTimer.get();
        this.bypass = 0.0;
        this.counter = 0;
        player.stepHeight = 0.0f;
        player.motionX = 0.0;
        player.motionZ = 0.0;
    }
    public double randomDouble(double min, double max) {
        return MathHelper.clamp_double(min + new Random().nextDouble() * max, min, max);
    }
    @Override
    public void onDisable() {
        final EntityPlayerSP player = mc.thePlayer;
        mc.timer.timerSpeed = 1.0f;
        player.stepHeight = 0.625f;
        player.motionX = 0.0;
        player.motionZ = 0.0;
        player.setPosition(player.posX, player.posY, player.posZ);
    }

    @EventTarget
    public void onStep(final StepEvent e) {
        e.setStepHeight(0);
    }
    @EventTarget
    public void onMotion(final MotionEvent e) {
        if (this.bob.get()) {
            mc.thePlayer.cameraYaw = 0.04252452F;
        }
        switch(e.getEventState()) {
            case PRE:
                if(changeTimer.get() && delayTimer.hasTimePassed(timerDelayValue.get())) {
                    mc.timer.timerSpeed = 1.0F;
                }
                if (++this.counter == 1) {
                    this.bypass = 3.25E-4 + randomDouble(1.0999E-5, new Random().nextFloat() * 1.0E-6);
                }
                else if (this.counter == 2) {
                    this.bypass = -this.bypass;
                    this.counter = 0;
                }
                e.setPosY(mc.thePlayer.getEntityBoundingBox().minY + bypass);
                if (!this.failedStart) {
                    mc.thePlayer.motionY = 0.0;
                }
                break;
            case POST:
                final double xDist = mc.thePlayer.posX - mc.thePlayer.prevPosX;
                final double zDist = mc.thePlayer.posZ - mc.thePlayer.prevPosZ;
                this.lastDistance = Math.sqrt(xDist * xDist + zDist * zDist);
                break;
        }
    }

    @EventTarget
    public final void onMove(final MoveEvent e) {
        if (!MovementUtils.isMoving()) {
            e.setX(0.0);
            e.setZ(0.0);
            return;
        }
        if (this.failedStart) {
            return;
        }
        final double amplifier = 1.0 + (mc.thePlayer.isPotionActive(Potion.moveSpeed) ? (0.2 * (mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1)) : 0.0);
        final double baseSpeed = 0.29 * amplifier;
        switch (this.boostHypixelState) {
            case 1:
                this.moveSpeed = (mc.thePlayer.isPotionActive(Potion.moveSpeed) ? 1.56 : 2.034) * baseSpeed;
                this.boostHypixelState = 2;
                break;
            case 2:
                this.moveSpeed *= 2.16;
                this.boostHypixelState = 3;
                break;
            case 3:
                this.moveSpeed = this.lastDistance - ((mc.thePlayer.ticksExisted % 2 == 0) ? 0.0103 : 0.0123) * (this.lastDistance - baseSpeed);
                this.boostHypixelState = 4;
                break;
            default:
                this.moveSpeed = this.lastDistance - this.lastDistance / 159.8;
                break;
        }
        this.moveSpeed = Math.max(this.moveSpeed, 0.3);
        if(targetStrafe.canStrafe())
            targetStrafe.strafe(e,moveSpeed);
        else
            MovementUtils.setSpeed(e, this.moveSpeed);
    }
}
