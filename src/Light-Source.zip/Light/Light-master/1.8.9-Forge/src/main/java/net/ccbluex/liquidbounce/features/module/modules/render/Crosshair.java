package net.ccbluex.liquidbounce.features.module.modules.render;
import java.awt.Color;
import java.io.IOException;

import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render2DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.ui.client.GuiLogin;
import net.ccbluex.liquidbounce.utils.AutoAddModule;
import net.ccbluex.liquidbounce.utils.render.Colors;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.*;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.fml.common.FMLCommonHandler;

@ModuleInfo(name = "Crosshair", description = "Change your crosshair.", category = ModuleCategory.RENDER)
public class Crosshair
        extends Module {
    public static BoolValue DYNAMIC = new BoolValue("Dynamnic", true);
    public static FloatValue GAP = new FloatValue("Scale", 5.0F, 0.25F, 15.0F);
    public static FloatValue WIDTH = new FloatValue("X", 2.0F, 0.25F, 10.0F);
    public static FloatValue SIZE = new FloatValue("Y", 7.0F, 0.25F, 15.0F);

    @EventTarget
    public void onRender2D(Render2DEvent e) {
        int red = 255;
        int green = 255;
        int blue = 255;
        int alph = 255;
        double gap = GAP.get();
        double width = WIDTH.get();
        double size = SIZE.get();
        ScaledResolution scaledRes = new ScaledResolution(mc);
        RenderUtils.rectangleBordered(
                scaledRes.getScaledWidth() / 2 - width,
                scaledRes.getScaledHeight() / 2 - gap - size - (isMoving() ? 2 : 0),
                scaledRes.getScaledWidth() / 2 + 1.0f + width,
                scaledRes.getScaledHeight() / 2 - gap - (isMoving() ? 2 : 0),  0.5f, Colors.getColor(red, green, blue, alph),
                new Color(0, 0, 0, alph).getRGB());
        RenderUtils.rectangleBordered(
                scaledRes.getScaledWidth() / 2 - width,
                scaledRes.getScaledHeight() / 2 + gap + 1 + (isMoving() ? 2 : 0) - 0.15,
                scaledRes.getScaledWidth() / 2 + 1.0f + width,
                scaledRes.getScaledHeight() / 2 + 1 + gap + size + (isMoving() ? 2 : 0) - 0.15, 0.5f, Colors.getColor(red, green, blue, alph),
                new Color(0, 0, 0, alph).getRGB());
        RenderUtils.rectangleBordered(
                scaledRes.getScaledWidth() / 2 - gap - size - (isMoving() ? 2 : 0) + 0.15,
                scaledRes.getScaledHeight() / 2 - width,
                scaledRes.getScaledWidth() / 2 - gap - (isMoving() ? 2 : 0) + 0.15,
                scaledRes.getScaledHeight() / 2 + 1.0f + width, 0.5f, Colors.getColor(red, green, blue, alph),
                new Color(0, 0, 0, alph).getRGB());
        RenderUtils.rectangleBordered(
                scaledRes.getScaledWidth() / 2 + 1 + gap + (isMoving() ? 2 : 0),
                scaledRes.getScaledHeight() / 2 - width,
                scaledRes.getScaledWidth() / 2 + size + gap + 1 + (isMoving() ? 2 : 0),
                scaledRes.getScaledHeight() / 2 + 1.0f + width, 0.5f, Colors.getColor(red, green, blue, alph),
                new Color(0, 0, 0, alph).getRGB());
    }
    public boolean isMoving() {
        return DYNAMIC.get() && (!mc.thePlayer.isCollidedHorizontally) && (!mc.thePlayer.isSneaking()) && ((mc.thePlayer.movementInput.moveForward != 0.0F) || (mc.thePlayer.movementInput.moveStrafe != 0.0F));
    }
}
