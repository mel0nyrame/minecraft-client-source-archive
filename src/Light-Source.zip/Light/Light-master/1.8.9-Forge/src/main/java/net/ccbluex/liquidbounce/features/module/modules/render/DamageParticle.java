package net.ccbluex.liquidbounce.features.module.modules.render;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render3DEvent;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.features.module.modules.combat.Aura;
import net.ccbluex.liquidbounce.utils.Location;
import net.ccbluex.liquidbounce.utils.Particles;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.opengl.GL11;

@ModuleInfo(
        name = "DMGParticle",
        description = "Allows you to see items through walls.",
        category = ModuleCategory.RENDER,
        fakeName = "DMG Particle"
)
public class DamageParticle extends Module {
    private final IntegerValue colorRedValue = new IntegerValue("R", 255, 0, 255);
    private final IntegerValue colorGreenValue = new IntegerValue("G", 255, 0, 255);
    private final IntegerValue colorBlueValue = new IntegerValue("B", 255, 0, 255);
    private HashMap<EntityLivingBase, Float> healthMap = new HashMap<>();
    private List<Particles> particles = new ArrayList<>();

    @EventTarget
    public void onUpdate(UpdateEvent e) {
        this.particles.forEach((update) -> {
            ++update.ticks;
            if(update.ticks <= 10) {
                update.location.setY(update.location.getY() + (double)update.ticks * 0.005D);
            }

            if(update.ticks > 20) {
                this.particles.remove(update);
            }

        });
        Aura a = LiquidBounce.moduleManager.getModule(Aura.class);
        EntityLivingBase entity = a.getTarget();
        if(entity != this.mc.thePlayer) {
            if(!this.healthMap.containsKey(entity)) {
                this.healthMap.put(entity, entity.getHealth());
            }

            float floatValue = this.healthMap.get(entity);
            float health = entity.getHealth();
            if(floatValue != health) {
                String text;
                if(floatValue - health < 0.0F) {
                    text = "\u00a7a" + roundToPlace(((floatValue - health) * -1.0F), 1);
                } else {
                    text = "\u00a7e" + roundToPlace((floatValue - health), 1);
                }

                Location location = new Location(entity);
                location.setY(entity.getEntityBoundingBox().minY + (entity.getEntityBoundingBox().maxY - entity.getEntityBoundingBox().minY) / 2.0D);
                location.setX(location.getX() - 0.5D + (double)(new Random(System.currentTimeMillis())).nextInt(5) * 0.1D);
                location.setZ(location.getZ() - 0.5D + (double)(new Random(System.currentTimeMillis() + 1L)).nextInt(5) * 0.1D);
                this.particles.add(new Particles(location, text));
                this.healthMap.remove(entity);
                this.healthMap.put(entity, entity.getHealth());
            }

        }
    }

    @EventTarget
    public void onRender3D(Render3DEvent e) {
        for (Particles p : this.particles) {
            double x = p.location.getX();
            this.mc.getRenderManager();
            double n = x - this.mc.getRenderManager().renderPosX;
            double y = p.location.getY();
            this.mc.getRenderManager();
            double n2 = y - this.mc.getRenderManager().renderPosY;
            double z = p.location.getZ();
            this.mc.getRenderManager();
            double n3 = z - this.mc.getRenderManager().renderPosZ;
            GlStateManager.pushMatrix();
            GlStateManager.enablePolygonOffset();
            GlStateManager.doPolygonOffset(1.0F, -1500000.0F);
            GlStateManager.translate((float) n, (float) n2, (float) n3);
            GlStateManager.rotate(-this.mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
            float textY;
            if (this.mc.gameSettings.thirdPersonView == 2) {
                textY = -1.0F;
            } else {
                textY = 1.0F;
            }

            GlStateManager.rotate(this.mc.getRenderManager().playerViewX, textY, 0.0F, 0.0F);
            double size = 0.03;
            GlStateManager.scale(-size, -size, size);
            enableGL2D();
            disableGL2D();
            GL11.glDepthMask(false);
            this.mc.fontRendererObj.drawStringWithShadow(p.text, (float) (-(this.mc.fontRendererObj.getStringWidth(p.text) / 2)), (float) (-(this.mc.fontRendererObj.FONT_HEIGHT - 1)), 0);
            GL11.glColor4f((float) this.colorRedValue.get(), (float) this.colorGreenValue.get(), (float) (this.colorBlueValue.get()).intValue(), 1.0F);
            GL11.glDepthMask(true);
            GlStateManager.doPolygonOffset(1.0F, 1500000.0F);
            GlStateManager.disablePolygonOffset();
            GlStateManager.popMatrix();
        }

    }

    public static void enableGL2D() {
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glDepthMask(true);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glHint(3155, 4354);
    }

    public static void disableGL2D() {
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glEnable(2929);
        GL11.glDisable(2848);
        GL11.glHint(3154, 4352);
        GL11.glHint(3155, 4352);
    }

    public static double roundToPlace(double p_roundToPlace_0_, int p_roundToPlace_2_) {
        if(p_roundToPlace_2_ < 0) {
            throw new IllegalArgumentException();
        } else {
            return (new BigDecimal(p_roundToPlace_0_)).setScale(p_roundToPlace_2_, RoundingMode.HALF_UP).doubleValue();
        }
    }
}
