package net.ccbluex.liquidbounce.features.module.modules.render
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.*
import net.ccbluex.liquidbounce.utils.*
import net.ccbluex.liquidbounce.utils.render.ColorUtils
import net.ccbluex.liquidbounce.value.IntegerValue
import java.awt.Color
import java.awt.Toolkit


@ModuleInfo(name = "KeyStrokes", description = "show the KeyStrokes", category = ModuleCategory.RENDER, fakeName = "Key Strokes")
class KeyStrokes : Module() {
    private val colors = intArrayOf(0xFFFFFF, 0xFF0000, 65280, 255, 0xFFFF00, 0xAA00AA)
    private val movementKeys: Array<Key?> = arrayOfNulls(4)
    private val mouseButtons: Array<MouseButton?> = arrayOfNulls(2)
    private val x = IntegerValue("PosX", 5, 0, Toolkit.getDefaultToolkit().screenSize.width)
    private val y = IntegerValue("PosY", 150, 0, Toolkit.getDefaultToolkit().screenSize.height)
    init {
        movementKeys[0] = Key(mc.gameSettings.keyBindForward, 26, 2)
        movementKeys[1] = Key(mc.gameSettings.keyBindLeft, 2, 26)
        movementKeys[2] = Key(mc.gameSettings.keyBindBack, 26, 26)
        movementKeys[3] = Key(mc.gameSettings.keyBindRight, 50, 26)
        mouseButtons[0] = MouseButton(0, 2, 50)
        mouseButtons[1] = MouseButton(1, 38, 50)
    }

    @EventTarget
    private fun onRender2D(e: Render2DEvent) {
        val x = x.get()
        val y = y.get()
        val textColor:Int = ColorUtils.otherRainbow(Float.MAX_VALUE,0.6F)
        val showingMouseButtons = true
        this.drawMovementKeys(x, y, textColor)
        if (showingMouseButtons) {
            this.drawMouseButtons(x, y, textColor)
        }
    }
    private fun getColor(index: Int): Int {
        return if (index == 6) Color.HSBtoRGB((System.currentTimeMillis() % 1000L).toFloat() / 1000.0f, 0.8f, 0.8f) else colors[index]
    }

    private fun drawMovementKeys(x: Int, y: Int, textColor: Int) {
        for (key in movementKeys) {
            key!!.renderKey(x, y, textColor)
        }
    }

    private fun drawMouseButtons(x: Int, y: Int, textColor: Int) {
        for (button in mouseButtons) {
            button!!.renderMouseButton(x, y, textColor)
        }
    }
}