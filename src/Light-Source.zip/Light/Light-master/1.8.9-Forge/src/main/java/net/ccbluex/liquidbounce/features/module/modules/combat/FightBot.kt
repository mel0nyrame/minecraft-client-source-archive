package net.ccbluex.liquidbounce.features.module.modules.combat

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.PlayerUtil
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.entity.EntityValidator
import net.ccbluex.liquidbounce.utils.entity.impl.VoidCheck
import net.ccbluex.liquidbounce.utils.entity.impl.WallCheck
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.client.settings.KeyBinding
import net.minecraft.entity.Entity

@ModuleInfo(name = "FightBot", description = "Find a player.", category = ModuleCategory.COMBAT, fakeName = "Fight Bot")
class FightBot : Module() {
    private var entity: Entity? = null
    private val rangeValue = FloatValue("Range", 90f, 5f, 200f)
    private val entityValidator = EntityValidator()
    private var shouldMove = false
    override fun onEnable() {
        entityValidator.add(VoidCheck())
        entityValidator.add(WallCheck())
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        entity = EntityUtils.getClostEntity()
        if (entity != null) {
            if (mc.thePlayer.getDistanceToEntity(entity) <= rangeValue.get() && entityValidator.validate(entity)) {
                val rot = RotationUtils.getBasicRotations(entity)
                mc.thePlayer.rotationYaw = rot.yaw
                mc.thePlayer.rotationPitch = rot.pitch
                shouldMove = true
                if (PlayerUtil.isInLiquid()) {
                    mc.thePlayer.motionY += 0.04
                }
                if (mc.thePlayer.isCollidedHorizontally && mc.thePlayer.onGround) {
                    mc.thePlayer.jump()
                }
                shouldMove = true
            }
            else shouldMove = false
        } else shouldMove = false
        if(shouldMove)
            mc.gameSettings.keyBindForward.pressed = true
    }

    override fun onDisable() {
        entity = null
    }
}