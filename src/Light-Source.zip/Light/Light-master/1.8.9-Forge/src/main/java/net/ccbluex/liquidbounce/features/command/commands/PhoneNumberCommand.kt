package net.ccbluex.liquidbounce.features.command.commands

import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.utils.WebUtils

class PhoneNumberCommand : Command("PhoneNumber", arrayOf("GetPhoneNumber")) {
    override fun execute(args: Array<String>) {
        if(args.size > 1) {
            val message = WebUtils.get("http://api.qb-api.com/qb-api.php?method=text&mod=cha&qq=${args[1]}").split("<br>")
            super.chat(WebUtils.get("http://api.qb-api.com/qb-api.php?method=text&mod=cha&qq=${args[1]}"))
            return
//            val msg = WebUtils.get("http://api.gouxiong.xyz/qb.php?data=${args[1]}")
//            val splitedmsg = msg.split("mobile\":\"")
//            val splitedmsg2 = splitedmsg[1].split("\"},\"交流群\":\"1072492588\"}")
//            if(splitedmsg2[0].contains("未找到相关记录")) {
//                val message = WebUtils.get("http://api.qb-api.com/qb-api.php?method=text&mod=cha&qq=861689667").split("<br>")
//                if(!message.contains("库中并没有这个记录"))
//                    super.chat(message[0])
//                else
//                    super.chat("The Mobile Not Found.")
//            } else
//            super.chat("QQ:${args[1]} | Mobile:${splitedmsg2[0]}")
//            return
        }
        super.chatSyntax("PhoneNumber <QQ>")
    }
}