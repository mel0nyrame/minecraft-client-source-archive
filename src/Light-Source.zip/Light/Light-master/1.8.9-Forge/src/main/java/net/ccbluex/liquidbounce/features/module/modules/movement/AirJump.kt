package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo

@ModuleInfo(name = "AirJump", description = "Jump in the air.", category = ModuleCategory.MOVEMENT, fakeName = "Air Jump")
class AirJump : Module()