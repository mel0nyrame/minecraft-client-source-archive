package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.IntegerValue

@ModuleInfo("WorldColor", "WorldColor", ModuleCategory.RENDER, fakeName = "World Color")
class WorldColor : Module() {
    val redValue = IntegerValue("Red", 150, 0, 255)
    val greenValue = IntegerValue("Green", 0, 0, 255)
    val blueValue = IntegerValue("Blue", 0, 0, 255)
    val alphaValue = IntegerValue("Alpha", 255, 0, 255)
}