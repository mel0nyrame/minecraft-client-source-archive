package net.ccbluex.liquidbounce.injection.forge.mixins.render;

import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.BlockRenderEvent;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.*;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.client.resources.model.WeightedBakedModel;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ReportedException;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.WorldType;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.ConcurrentModificationException;

@Mixin(BlockRendererDispatcher.class)
public abstract class MixinBlockRendererDispatcher {
    @Shadow
    private BlockModelShapes blockModelShapes;

    @Final
    @Shadow
    private GameSettings gameSettings;

    @Shadow
    private final BlockFluidRenderer fluidRenderer = new BlockFluidRenderer();

    @Shadow
    private final BlockModelRenderer blockModelRenderer = new BlockModelRenderer();

    @Overwrite
    public boolean renderBlock(IBlockState state, BlockPos pos, IBlockAccess blockAccess, WorldRenderer worldRendererIn) {
        BlockRenderEvent event = new BlockRenderEvent(pos.getX(), pos.getY(), pos.getZ(), state.getBlock());
        try {
            LiquidBounce.eventManager.callEvent(event);
        } catch (ConcurrentModificationException concurrentModificationException) {
            concurrentModificationException.printStackTrace();
        }

        try
        {
            int i = state.getBlock().getRenderType();

            if (i == -1)
            {
                return false;
            }
            else
            {
                switch (i)
                {
                    case 1:

                        boolean flag1 = this.fluidRenderer.renderFluid(blockAccess, state, pos, worldRendererIn);

                        return flag1;

                    case 2:

                        return false;

                    case 3:
                        IBakedModel ibakedmodel = this.getModelFromBlockState(state, blockAccess, pos);

                        boolean flag = this.blockModelRenderer.renderModel(blockAccess, ibakedmodel, state, pos, worldRendererIn);

                        return flag;

                    default:
                        return false;
                }
            }
        }
        catch (Throwable throwable)
        {
            CrashReport crashreport = CrashReport.makeCrashReport(throwable, "Tesselating block in world");
            CrashReportCategory crashreportcategory = crashreport.makeCategory("Block being tesselated");
            CrashReportCategory.addBlockInfo(crashreportcategory, pos, state.getBlock(), state.getBlock().getMetaFromState(state));
            throw new ReportedException(crashreport);
        }
    }
    @Shadow
    public abstract IBakedModel getModelFromBlockState(IBlockState state, IBlockAccess worldIn, BlockPos pos);
}
