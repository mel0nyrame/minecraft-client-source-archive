package net.ccbluex.liquidbounce.features.module.modules.world

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.client.entity.EntityPlayerSP
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.item.ItemSword

@ModuleInfo(name = "MurderFinder", description = "Find the hitman", category = ModuleCategory.WORLD)
class HitMan : Module() {
    private val delay = IntegerValue("Delay", 10000, 1000, 1000000)
    private val msTimer = MSTimer()
    @EventTarget
    private fun onUpdate(updateEvent: UpdateEvent) {
        if (msTimer.hasTimePassed(delay.get().toLong())) {
            for (i in mc.theWorld.loadedEntityList) {
                val entityPlayer = i as EntityPlayer
                if (entityPlayer.heldItem.item is ItemSword) {
                    if(entityPlayer is EntityPlayerSP) {
                        continue
                    }
                    ClientUtils.displayChatMessage("§8[§9§lAwesome§8] Murder is " + entityPlayer.name)
                }
                msTimer.reset()
            }
        }
    }
}