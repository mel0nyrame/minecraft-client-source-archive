package net.ccbluex.liquidbounce.features.module.modules.render;
import java.awt.Color;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render2DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.render.Colors;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import org.lwjgl.input.Mouse;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
@ModuleInfo(name = "MiniMap",description = "MiniMap", category = ModuleCategory.RENDER, fakeName = "Mini Map")
public class MiniMap extends Module
{
    private boolean dragging;
    float hue;
    private FloatValue scale = new FloatValue("Scale",2, 1, 5);
    private IntegerValue x = new IntegerValue("X",650,1,1920);
    private IntegerValue y = new IntegerValue("Y", 2,0,1080);
    private IntegerValue size = new IntegerValue("Size", 125, 50, 500);

    public static Object castNumber(String newValueText, Object currentValue) {
        if (newValueText.contains(".")) {
            if (newValueText.toLowerCase().contains("f")) {
                return  Float.parseFloat(newValueText);
            }
            return Double.parseDouble(newValueText);
        }
        if (isNumeric(newValueText)) {
            return Integer.parseInt(newValueText);
        }
        return newValueText;
    }

    public static boolean isNumeric(String text) {
        try {
            Integer.parseInt(text);
            return true;
        }
        catch (NumberFormatException numberFormatException) {
            return false;
        }
    }

    @EventTarget
    public void onRender2D(Render2DEvent e) {
        ScaledResolution sr = new ScaledResolution(mc);
        int size1 = this.size.get();
        float xOffset = (this.x.get()).floatValue();
        float yOffset = (this.y.get()).floatValue();
        float playerOffsetX = (float)mc.thePlayer.posX;
        float playerOffSetZ = (float)mc.thePlayer.posZ;
        int var141 = sr.getScaledWidth();
        int var151 = sr.getScaledHeight();
        if (this.hue > 255.0f) {
            this.hue = 0.0f;
        }
        float h = this.hue;
        float h2 = this.hue + 85.0f;
        float h3 = this.hue + 170.0f;
        if (h > 255.0f) {
            h = 0.0f;
        }
        if (h2 > 255.0f) {
            h2 -= 255.0f;
        }
        if (h3 > 255.0f) {
            h3 -= 255.0f;
        }
        Color color33 = Color.getHSBColor((h / 255.0f), 0.9f, 1.0f);
        Color color332 = Color.getHSBColor((h2 / 255.0f), 0.9f, 1.0f);
        Color color333 = Color.getHSBColor((h3 / 255.0f), 0.9f, 1.0f);
        int color1 = color33.getRGB();
        int color2 = color332.getRGB();
        int color3 = color333.getRGB();
        this.hue = (this.hue + 1);
        RenderUtils.rectangleBordered(xOffset, yOffset, (xOffset + (float)size1), (yOffset + (float)size1), 0.5, Colors.getColor(90), Colors.getColor(0));
        RenderUtils.rectangleBordered((xOffset + 1.0f), (yOffset + 1.0f), (xOffset + (float)size1 - 1.0f), (yOffset + (float)size1 - 1.0f), 1.0, Colors.getColor(90), Colors.getColor(61));
        RenderUtils.rectangleBordered((xOffset + 2.5), (yOffset + 2.5), ((xOffset + (float)size1) - 2.5), ((yOffset + (float)size1) - 2.5), 0.5, Colors.getColor(61), Colors.getColor(0));
        RenderUtils.rectangleBordered((xOffset + 3.0f), (yOffset + 3.0f), (xOffset + (float)size1 - 3.0f), (yOffset + (float)size1 - 3.0f), 0.5, Colors.getColor(27), Colors.getColor(61));
        RenderUtils.drawGradientSideways((xOffset + 3.0f), (yOffset + 3.0f), (xOffset + (float)(size1 / 2)), (yOffset + 3.6), color1, color2);
        RenderUtils.drawGradientSideways((xOffset + (float)(size1 / 2)), (yOffset + 3.0f), (xOffset + (float)size1 - 3.0f), (yOffset + 3.6), color2, color3);
//        RenderUtils.rectangle((xOffset + ((size1 / 2) - 0.5)), (yOffset + 3.5), (xOffset + ((size1 / 2) + 0.5)), ((yOffset + (float)size1) - 3.5), Colors.getColor(255, 80));
//        RenderUtils.rectangle((xOffset + 3.5), (yOffset + ((size1 / 2) - 0.5)), ((xOffset + (float)size1) - 3.5), (yOffset + ((size1 / 2) + 0.5)), Colors.getColor(255, 80));
        for (Object o : mc.theWorld.getLoadedEntityList()) {
            EntityPlayer ent;
            if (!(o instanceof EntityPlayer) || !(ent = (EntityPlayer)o).isEntityAlive() || ent == mc.thePlayer || ent.isInvisible() || ent.isInvisibleToPlayer(mc.thePlayer)) continue;
            float pTicks = mc.timer.renderPartialTicks;
            float posX = (float)((ent.posX + (ent.posX - ent.lastTickPosX) * pTicks - playerOffsetX) * this.scale.get());
            float posZ = (float)((ent.posZ + (ent.posZ - ent.lastTickPosZ) * pTicks - playerOffSetZ) * this.scale.get());
            String formattedText = ent.getDisplayName().getFormattedText();
            int color = mc.thePlayer.canEntityBeSeen(ent) ? new Color(255,255,255).getRGB() : new Color(120,120,120).getRGB();
            int i = 0;
            while (i < formattedText.length()) {
                if (formattedText.charAt(i) == '§' && i + 1 < formattedText.length()) {
                    int index = "0123456789abcdefklmnorg".indexOf(Character.toLowerCase(formattedText.charAt(i + 1)));
                    if (index < 16) {
                        try {
                            Color color21 = new Color(mc.fontRendererObj.getColorCode('1'));
                            color = this.getColor(color21.getRed(), color21.getGreen(), color21.getBlue(), 255);
                        }
                        catch (ArrayIndexOutOfBoundsException ignored) {

                        }
                    }
                }
                ++i;
            }
            if(ent.hurtTime > 0) {
                color = new Color(255,0,0).getRGB();
            }
            float cos = (float)Math.cos((mc.thePlayer.rotationYaw * 0.017453292519943295));
            float sin = (float)Math.sin((mc.thePlayer.rotationYaw * 0.017453292519943295));
            float rotY = (- posZ) * cos - posX * sin;
            float rotX = (- posX) * cos + posZ * sin;
            if (rotY > (float)(size1 / 2 - 5)) {
                rotY = (float)(size1 / 2) - 5.0f;
            } else if (rotY < (float)((- size1) / 2 - 5)) {
                rotY = (- size1) / 2 - 5;
            }
            if (rotX > (float)(size1 / 2) - 5.0f) {
                rotX = size1 / 2 - 5;
            } else if (rotX < (float)((- size1) / 2 - 5)) {
                rotX = - (float)(size1 / 2) - 5.0f;
            }
            RenderUtils.rectangleBordered(((xOffset + (float)(size1 / 2) + rotX) - 1.5), ((yOffset + (float)(size1 / 2) + rotY) - 1.5), ((xOffset + (float)(size1 / 2) + rotX) + 1.5), ((yOffset + (float)(size1 / 2) + rotY) + 1.5), 0.5, color, Colors.getColor(46));
        }
    }

    public int getColor(int p_clamp_int_0_, int p_clamp_int_0_2, int p_clamp_int_0_3, int p_clamp_int_0_4) {
        return MathHelper.clamp_int(p_clamp_int_0_4, 0, 255) << 24 | MathHelper.clamp_int(p_clamp_int_0_, 0, 255) << 16 | MathHelper.clamp_int(p_clamp_int_0_2, 0, 255) << 8 | MathHelper.clamp_int(p_clamp_int_0_3, 0, 255);
    }

    private float findAngle(float x, float x2, float y, float y2) {
        return (float)(Math.atan2((y2 - y), (x2 - x)) * 180.0 / 3.141592653589793);
    }
}