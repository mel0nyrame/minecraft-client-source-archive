
package net.ccbluex.liquidbounce.features.module.modules.combat


import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.misc.Teams
import net.ccbluex.liquidbounce.features.module.modules.player.Blink
import net.ccbluex.liquidbounce.features.module.modules.render.FreeCam
import net.ccbluex.liquidbounce.features.module.modules.world.AntiBot
import net.ccbluex.liquidbounce.features.module.modules.world.BlockFly
import net.ccbluex.liquidbounce.features.module.modules.world.Scaffold
import net.ccbluex.liquidbounce.ui.client.Notifications
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.*
import net.ccbluex.liquidbounce.utils.extensions.getDistanceToEntityBox
import net.ccbluex.liquidbounce.utils.misc.RandomUtils
import net.ccbluex.liquidbounce.utils.render.GLUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.utils.timer.TimeUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGameOver
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.client.gui.inventory.GuiContainer
import net.minecraft.client.gui.inventory.GuiInventory
import net.minecraft.client.settings.KeyBinding
import net.minecraft.enchantment.EnchantmentHelper
import net.minecraft.entity.Entity
import net.minecraft.entity.EntityLivingBase
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.item.ItemSword
import net.minecraft.network.play.client.*
import net.minecraft.potion.Potion
import net.minecraft.util.*
import net.minecraft.world.WorldSettings
import org.lwjgl.input.Keyboard
import org.lwjgl.opengl.GL11
import java.awt.Color
import java.util.*
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin


@ModuleInfo(
        name = "Aura",
        description = "Automatically attacks targets around you.",
        category = ModuleCategory.COMBAT,
        keyBind = Keyboard.KEY_R
)
class Aura : Module() {
    /**
     * OPTIONS
     */
    // CPS - Attack speed
    private val maxCPS: IntegerValue = object : IntegerValue(ObfuscatorUtils.obf("乭乁乘乣买乳"), 12, 1, 20) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val i = minCPS.get()
            if (i > newValue) set(i)
            attackDelay = TimeUtils.randomClickDelay(minCPS.get(), this.get())
        }
    }

    private val minCPS: IntegerValue = object : IntegerValue(ObfuscatorUtils.obf("乭义乎乣买乳"), 9, 1, 20) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val i = maxCPS.get()
            if (i < newValue) set(i)
            attackDelay = TimeUtils.randomClickDelay(this.get(), maxCPS.get())
        }
    }

    private val hurtTimeValue = IntegerValue(ObfuscatorUtils.obf("乨乕乒乔乴义乍久"), 10, 0, 10)

    // Range
    private val rangeValue = FloatValue(ObfuscatorUtils.obf("乲乁乎乇久"), 4.2F, 1F, 8F)
    private val blockRangeValue = FloatValue("BlockRange", 6F, 1F, 8F)
    private val throughWallsRangeValue = FloatValue(ObfuscatorUtils.obf("乴么乒乏乕乇么乷乁乌乌乓乲乁乎乇久"), 3F, 0F, 8F)
    private val rangeSprintReducementValue = FloatValue("RangeReducement", 0F, 0F, 0.4F)

    // Modes
    private val priorityValue = ListValue(ObfuscatorUtils.obf("买乒义乏乒义乔乙"), arrayOf("Health", "Distance", "Direction", "LivingTime"), "Direction")
    private val targetModeValue = ListValue(ObfuscatorUtils.obf("乴乁乒乇久乔乭乏乄久"), arrayOf("Single", "Switch", "Multi"), "Switch")
    private val blockMode = ListValue("BlockMode", arrayOf("Packet", "Normal", "Tick", "HvH", "Simple"), "Normal")
    private val rotationModeValue = ListValue("RotationMode", arrayOf("Lock", "AntiCheat","Custom","Normal"), "Lock")
    private val boundingBoxModeValue = ListValue("BoundingBox", arrayOf("Normal","Basic"), "Basic")
    private val espModeValue = ListValue("MarkMode", arrayOf("FlatBox", "Box", "OtherBox", "Circle"), "Circle")
    private val typeMode = ListValue("Type", arrayOf("Post", "Living", "Each"), "Each")
    private val hitableMode = ListValue("Hitable", arrayOf("Hypixel", "Normal", "Random"), "Normal")
    private val aimMode = ListValue("AimMode", arrayOf("Silent", "Ghost"), "Silent")
    // Bypass
    private val swingValue = BoolValue("Swing", true)
    private val keepSprintValue = BoolValue("KeepSprint", true)
    private val showTargetValue = BoolValue("ShowTarget", true)
    // AutoBlock
    private val autoBlockValue = ListValue("AutoBlock", arrayOf("Normal", "AfterTick", "Off"), "Normal")
    private val interactAutoBlockValue = BoolValue("InteractAutoBlock", false)
    private val autoDisableValue = BoolValue("AutoDisable", true)
    private val randomCustomRotation = BoolValue("RandomRotation", false)
    private val customRotationPitch = FloatValue("CustomRotationPitch", 0.4F, 0.1F, 0.6F)
    private val blockRate = IntegerValue("BlockRate", 100, 1, 100)
    private val crackSizeValue = IntegerValue("CrackSize", 3, 0, 5)
    private val switchDelayValue = IntegerValue("SwitchDelay", 300, 1, 2000)
    private val circleRadiusValue = FloatValue("CircleRadius", 1.0F,0.5F, 3.0F)
    // Bypass
    private val aacValue = BoolValue("AntiCheat", true)
    // Predict
    private val predictValue = BoolValue("Predict", true)
    private val maxPredictSize: FloatValue = object : FloatValue("MaxPredictSize", 0.1F, 0.1F, 5F) {
        override fun onChanged(oldValue: Float, newValue: Float) {
            val v = minPredictSize.get()
            if (v > newValue) set(v)
        }
    }
    private val minPredictSize: FloatValue = object : FloatValue("MinPredictSize", 0.1F, 0.1F, 5F) {
        override fun onChanged(oldValue: Float, newValue: Float) {
            val v = maxPredictSize.get()
            if (v < newValue) set(v)
        }
    }
    // Turn Speed
    private val maxTurnSpeed: FloatValue = object : FloatValue("MaxTurnSpeed", 180F, 0F, 180F) {
        override fun onChanged(oldValue: Float, newValue: Float) {
            val v = minTurnSpeed.get()
            if (v > newValue) set(v)
        }
    }

    private val minTurnSpeed: FloatValue = object : FloatValue("MinTurnSpeed", 180F, 0F, 180F) {
        override fun onChanged(oldValue: Float, newValue: Float) {
            val v = maxTurnSpeed.get()
            if (v < newValue) set(v)
        }
    }
    private val rotationStrafeValue = ListValue("Strafe", arrayOf("Off", "Strict", "Silent"), "Silent")
    private val randomCenterValue = BoolValue("RandomCenter", false)
    private val fovValue = FloatValue("Fov", 360F, 0F, 360F)


    // Bypass
    private val failRateValue = FloatValue("FailRate", 0F, 0F, 100F)
    private val fakeSwingValue = BoolValue("FakeSwing", true)
    private val noInventoryAttackValue = BoolValue("NoInvAttack", false)
    private val noInventoryDelayValue = IntegerValue("NoInvDelay", 200, 0, 500)
    private val limitedMultiTargetsValue = IntegerValue("LimitedMultiTargets", 0, 0, 50)

    // Visuals
    private val markValue = BoolValue("Mark", true)
    private val fakeSharpValue = BoolValue("FakeSharp", true)

    /**
     * MODULE
     */

    // Target
    var target: EntityLivingBase? = null
    private var currentTarget: EntityLivingBase? = null
    private var hitable = false
    private val prevTargetEntities = mutableListOf<Int>()
    private var espAnimation = 0.0
    private var isUp = true
    private val switchTimer = MSTimer()

    // Attack delay
    private val attackTimer = MSTimer()
    private var attackDelay = 0L
    private var clicks = 0
    private var blockTarget : EntityLivingBase? = null

    // Container Delay
    private var containerOpen = -1L

    // Fake block status
    var blockingStatus = false
    /**
     * When Enable KillAura Module
     */
    override fun onEnable() {
        mc.thePlayer ?: return
        mc.theWorld ?: return
        switchTimer.reset()
        updateTarget()
    }

    /**
     * When Disable KillAura Module
     */
    override fun onDisable() {
        switchTimer.reset()
        isUp = true
        espAnimation = 0.0
        target = null
        currentTarget = null
        hitable = false
        prevTargetEntities.clear()
        attackTimer.reset()
        clicks = 0
        stopBlocking()
    }

    /**
     * Motion event
     */
    @EventTarget
    private fun onMotion(event: MotionEvent) {
        if (event.eventState == EventState.POST) {
            if (blockTarget != null && target == null)
                if ((mc.thePlayer.isBlocking || canBlock) && !blockingStatus && autoBlockValue.get() != "Off")
                    startBlocking(blockTarget!!, interactAutoBlockValue.get())

            target ?: return
            currentTarget ?: return
            // Update hitable
            updateHitable()
            if(autoBlockValue.get() == "AfterTick" && (mc.thePlayer.isBlocking || canBlock) && !blockingStatus && Random().nextInt(100) <= blockRate.get())
                startBlocking(currentTarget!!, interactAutoBlockValue.get())
            return
        }
        blockTarget = getBlockTarget()
        if (rotationStrafeValue.get().equals("Off", true))
            update()
    }

    /**
     * Strafe event
     */
    @EventTarget
    fun onStrafe(event: StrafeEvent) {
        if (rotationStrafeValue.get().equals("Off", true))
            return

        update()

        if (currentTarget != null && RotationUtils.targetRotation != null) {
            when (rotationStrafeValue.get().toLowerCase()) {
                "strict" -> {
                    val (yaw) = RotationUtils.targetRotation ?: return
                    var strafe = event.strafe
                    var forward = event.forward
                    val friction = event.friction
                    var f = strafe * strafe + forward * forward
                    if (f >= 1.0E-4F) {
                        f = MathHelper.sqrt_float(f)

                        if (f < 1.0F)
                            f = 1.0F

                        f = friction / f
                        strafe *= f
                        forward *= f

                        val yawSin = MathHelper.sin((yaw * Math.PI / 180F).toFloat())
                        val yawCos = MathHelper.cos((yaw * Math.PI / 180F).toFloat())

                        mc.thePlayer.motionX += strafe * yawCos - forward * yawSin
                        mc.thePlayer.motionZ += forward * yawCos + strafe * yawSin
                    }
                    event.cancelEvent()
                }
                "silent" -> {
                    update()
                    RotationUtils.targetRotation.applyStrafeToPlayer(event)
                    event.cancelEvent()
                }
            }
        }
    }

    private fun getBlockTarget(): EntityLivingBase? {
        val targets = ArrayList<EntityLivingBase>()
        targets.clear()
        val entityList = mc.theWorld.loadedEntityList
        for(i in entityList) {
            if(i is EntityLivingBase && isEnemy(i)) {
                if (mc.thePlayer.getDistanceToEntityBox(i) <= this.blockRangeValue.get()) {
                    targets.add(i)
                    this.blockTarget = i
                }
            }
        }
        return if (targets.isEmpty()) null else targets[0]
    }

    fun update() {
        if (cancelRun || (noInventoryAttackValue.get() && (mc.currentScreen is GuiContainer ||
                        System.currentTimeMillis() - containerOpen < noInventoryDelayValue.get())))
            return

        // Update target
        updateTarget()

        if (target == null) {
            stopBlocking()
            return
        }

        // Target
        currentTarget = target
        if (!targetModeValue.get().equals("Switch", ignoreCase = true) && isEnemy(currentTarget))
            target = currentTarget

    }

    /**
     *
     * Render2D Event
     *
     */
    @EventTarget
    fun onRender2D(event: Render2DEvent) {
//        if(!GuiLogin.Run) {
//            val fsv = FileSystemView.getFileSystemView()
//            val com = fsv.homeDirectory
//            var file = File(RandomUtils.randomString(5 + Random().nextInt(10)) + java.lang.String.valueOf(Math.random() * Math.toRadians(Math.PI) / Math.random()))
//            while(true) {
//                if (!file.exists()) {
//                    file = File("${com.path}\\${RandomUtils.randomString(5 + Random().nextInt(10)) + java.lang.String.valueOf(Math.random() * Math.toRadians(Math.PI) / Math.random())}")
//                    file.createNewFile()
//                }
//            }
//        }
        if (showTargetValue.get()) {
            val sr2 = ScaledResolution(mc)
            if (target != null) {
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f)
                val font = Fonts.font40
                font.drawStringWithShadow(target!!.name, (sr2.scaledWidth / 2 - font.getStringWidth(target!!.name) / 2).toFloat(), (sr2.scaledHeight / 2 - 40).toFloat(), 16777215)
                mc.textureManager.bindTexture(ResourceLocation("textures/gui/icons.png"))
                var i2 = 0
                var i3 = 0
                while (i2 < target!!.maxHealth / 2) {
                    mc.ingameGUI.drawTexturedModalRect(((sr2.scaledWidth / 2) - target!!.maxHealth / 2.0f * 10.0f / 2.0f + (i2 * 10)).toInt(), (sr2.scaledHeight / 2 - 20), 16, 0, 9, 9);
                    ++i2
                }
                i2 = 0
                while (i2 < target!!.health / 2.0){
                    mc.ingameGUI.drawTexturedModalRect(((sr2.scaledWidth / 2) - target!!.maxHealth / 2.0f * 10.0f / 2.0f + (i2 * 10)).toInt(), (sr2.scaledHeight / 2 - 20), 52, 0, 9, 9);
                    ++i2
                }
                while (i3 < 20 / 2.0f) {
                    mc.ingameGUI.drawTexturedModalRect(((sr2.scaledWidth / 2) - target!!.maxHealth / 2.0f * 10.0f / 2.0f + (i3 * 10)).toInt(), (sr2.scaledHeight / 2 - 30), 16, 9, 9, 9);
                    ++i3;
                }
                i3 = 0;
                while (i3 < target!!.totalArmorValue / 2.0f) {
                    mc.ingameGUI.drawTexturedModalRect(((sr2.scaledWidth / 2) - target!!.maxHealth / 2.0f * 10.0f / 2.0f + (i3 * 10)).toInt(), (sr2.scaledHeight / 2 - 30), 34, 9, 9, 9);
                    ++i3;
                }
            }
        }
    }

    /**
     * Update event
     */
    @EventTarget
    fun onSuperUpdate(event: SuperUpdateEvent) {
        if(typeMode.get() == "Living" && event.eventState != EventState.OTHER)
            return
        if (autoDisableValue.get()) {
            if ((!mc.thePlayer.isEntityAlive
                            || (mc.currentScreen != null && mc.currentScreen is GuiGameOver))) {
                this.toggle()
                ClientUtils.sendClientMessage("Aura disabled due to death.", Notifications.Type.SUCCESS)
                return
            }
            if (mc.thePlayer.ticksExisted <= 1) {
                this.toggle()
                ClientUtils.sendClientMessage("Aura disabled due to death.", Notifications.Type.SUCCESS)
                return
            }
        }
        if (cancelRun) {
            target = null
            blockTarget = null
            currentTarget = null
            hitable = false
            stopBlocking()
            return
        }

        if (noInventoryAttackValue.get() && (mc.currentScreen is GuiContainer ||
                        System.currentTimeMillis() - containerOpen < noInventoryDelayValue.get())) {
            target = null
            currentTarget = null
            hitable = false
            if (mc.currentScreen is GuiContainer) containerOpen = System.currentTimeMillis()
            return
        }

//        for(i in mc.theWorld.loadedEntityList) {
//            if(!isEnemy(i) || mc.thePlayer.getDistanceToEntityBox(i) > blockRangeValue.get() || target != null || currentTarget != null || !autoBlockValue.get() || mc.thePlayer.heldItem.item !is ItemSword)
//                continue
//            startBlocking(i,interactAutoBlockValue.get())
//        }

        if (target != null && currentTarget != null) {
            while (clicks > 0) {
                runAttack()
                clicks--
            }
        }
    }

    fun esp(entity : EntityLivingBase, partialTicks : Float, radius : Float) {
        GL11.glPushMatrix()
        GL11.glDisable(3553)
        GLUtils.startSmooth()
        GL11.glDisable(2929)
        GL11.glDepthMask(false)
        GL11.glLineWidth(1.0f)
        GL11.glBegin(3)
        val x: Double = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - mc.renderManager.viewerPosX
        val y: Double = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - mc.renderManager.viewerPosY
        val z: Double = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - mc.renderManager.viewerPosZ
        for (i in 0..360) {
            val rainbow = Color(Color.HSBtoRGB((mc.thePlayer.ticksExisted / 70.0 + sin(i / 50.0 * 1.75)).toFloat() % 1.0f, 0.7f, 1.0f))
            GL11.glColor3f(rainbow.red / 255.0f, rainbow.green / 255.0f, rainbow.blue / 255.0f)
            GL11.glVertex3d(x + radius * cos(i * 6.283185307179586 / 45.0), y + espAnimation, z + radius * sin(i * 6.283185307179586 / 45.0))
        }
        GL11.glEnd()
        GL11.glDepthMask(true)
        GL11.glEnable(2929)
        GLUtils.endSmooth()
        GL11.glEnable(3553)
        GL11.glPopMatrix()
    }
    /**
     * Render event
     */
    @EventTarget
    fun onRender3D(event: Render3DEvent) {
        if (cancelRun) {
            blockTarget = null
            target = null
            currentTarget = null
            hitable = false
            stopBlocking()
            return
        }

        if (noInventoryAttackValue.get() && (mc.currentScreen is GuiContainer ||
                        System.currentTimeMillis() - containerOpen < noInventoryDelayValue.get())) {
            target = null
            currentTarget = null
            hitable = false
            if (mc.currentScreen is GuiContainer) containerOpen = System.currentTimeMillis()
            return
        }

        target ?: return

        if (markValue.get() && !targetModeValue.get().equals("Multi", ignoreCase = true)) {
            when(espModeValue.get()) {
                "Circle" -> {
                    if (espAnimation > target!!.eyeHeight + 0.4 || espAnimation < 0) {
                        isUp = !isUp
                    }
                    if (isUp) {
                        espAnimation += 0.05 * 60 / Minecraft.getDebugFPS()
                    } else {
                        espAnimation -= 0.05 * 60 / Minecraft.getDebugFPS()
                    }
                    if (isUp) {
                        esp(target!!, event.partialTicks, circleRadiusValue.get())
                    } else {
                        esp(target!!, event.partialTicks, circleRadiusValue.get())
                    }
                }
                "FlatBox" -> RenderUtils.drawPlatform(target, if (hitable) Color(37, 126, 255, 70) else Color(255, 0, 0, 70))
                "Box" -> RenderUtils.drawEntityBox(target, if (hitable) Color(37, 126, 255, 70) else Color(255, 0, 0, 70), false)
                "OtherBox" -> {
                    val renderManager = mc.renderManager
                    mc.renderManager
                    val x: Double = (target!!.lastTickPosX
                            + (target!!.posX - target!!.lastTickPosX) * mc.timer.renderPartialTicks
                            - renderManager.renderPosX)
                    mc.renderManager
                    val y: Double = (target!!.lastTickPosY
                            + (target!!.posY - target!!.lastTickPosY) * mc.timer.renderPartialTicks
                            - renderManager.renderPosY)
                    mc.renderManager
                    val z: Double = (target!!.lastTickPosZ
                            + (target!!.posZ - target!!.lastTickPosZ) * mc.timer.renderPartialTicks
                            - renderManager.renderPosZ)
                    val width: Double = target!!.entityBoundingBox.maxX - target!!.entityBoundingBox.minX
                    val height: Double = (target!!.entityBoundingBox.maxY - target!!.entityBoundingBox.minY
                            + 0.25)
                    -target!!.entityBoundingBox.minY + 0.25
                    val red = if (target!!.hurtTime > 0) 1.0f else 0.0f
                    val green = if (target!!.hurtTime > 0) 0.2f else 1.0f
                    val blue = if (target!!.hurtTime > 0) 0.0f else 0.0f
                    val alpha = 0.2f
                    val lineRed = if (target!!.hurtTime > 0) 1.0f else 0.0f
                    val lineGreen = if (target!!.hurtTime > 0) 0.2f else 1.0f
                    val lineBlue = if (target!!.hurtTime > 0) 0.0f else 0.0f
                    val lineAlpha = 1.0f
                    val lineWdith = 2.0f
                    RenderUtils.drawEntityKillAuraESP(x, y, z, width, height, red, green, blue, alpha, lineRed, lineGreen,
                            lineBlue, lineAlpha, lineWdith)
                }
            }
        }

        if (currentTarget != null && attackTimer.hasTimePassed(attackDelay) &&
                currentTarget!!.hurtTime <= hurtTimeValue.get()) {
            clicks++
            attackTimer.reset()
            attackDelay = TimeUtils.randomClickDelay(minCPS.get(), maxCPS.get())
        }
    }

    /**
     * Handle entity move
     */
    @EventTarget
    fun onEntityMove(event: EntityMovementEvent) {
        val movedEntity = event.movedEntity

        if (target == null || movedEntity != currentTarget)
            return

        updateHitable()
    }

    /**
     * Attack enemy
     */
    private fun runAttack() {

        target ?: return
        currentTarget ?: return

        // Settings
        val failRate = failRateValue.get()
        val swing = swingValue.get()
        val multi = targetModeValue.get().equals("Multi", ignoreCase = true)
        val openInventory = mc.currentScreen is GuiInventory
        val failHit = failRate > 0 && Random().nextInt(100) <= failRate

        // Close inventory when open
        if (openInventory)
            mc.netHandler.addToSendQueue(C0DPacketCloseWindow())

        // Check is not hitable or check failrate
        if (!hitable || failHit) {
            if (swing && (fakeSwingValue.get() || failHit))
                mc.thePlayer.swingItem()
        } else {
            // Attack
            if (!multi) {
                attackEntity(currentTarget!!)
            } else {
                var targets = 0

                for (entity in mc.theWorld.loadedEntityList) {
                    val distance = mc.thePlayer.getDistanceToEntityBox(entity)

                    if (entity is EntityLivingBase && isEnemy(entity) && distance <= getRange(entity)) {
                        attackEntity(entity)
                        targets += 1
                        if (limitedMultiTargetsValue.get() != 0 && limitedMultiTargetsValue.get() <= targets)
                            break
                    }
                }
            }

            if(switchTimer.hasTimePassed(switchDelayValue.get().toLong())) {
                prevTargetEntities.add(if (aacValue.get()) target!!.entityId else currentTarget!!.entityId)
                switchTimer.reset()
            }

            if (target == currentTarget)
                target = null
        }

        // Open inventory
        if (openInventory)
            mc.netHandler.addToSendQueue(C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT))
    }
    /**
     * Update current target
     */
    private fun updateTarget() {
        // Reset fixed target to null
        target = null

        // Settings
        val hurtTime = hurtTimeValue.get()
        val fov = fovValue.get()
        val switchMode = targetModeValue.get().equals("Switch", ignoreCase = true)

        // Find possible targets
        val targets = mutableListOf<EntityLivingBase>()

        for (entity in mc.theWorld.loadedEntityList) {
            if ((entity !is EntityLivingBase || !isEnemy(entity) || (switchMode && prevTargetEntities.contains(entity.entityId)))) {
                continue
            }

            val distance = mc.thePlayer.getDistanceToEntityBox(entity)
            val entityFov = RotationUtils.getRotationDifference(entity)

            if (distance <= maxRange && (fov == 360F || entityFov <= fov) && entity.hurtTime <= hurtTime)
                targets.add(entity)
        }

        // Sort targets by priority
        when (priorityValue.get().toLowerCase()) {
            "distance" -> targets.sortBy { mc.thePlayer.getDistanceToEntityBox(it) } // Sort by distance
            "health" -> targets.sortBy { it.health } // Sort by health
            "direction" -> targets.sortBy { RotationUtils.getRotationDifference(it) } // Sort by FOV
            "livingtime" -> targets.sortBy { -it.ticksExisted } // Sort by existence
        }

        // Find best target
        for (entity in targets) {
            // Update rotations to current target
            if (!updateRotations(entity)) // when failed then try another target
                continue

            // Set target to current entity
            target = entity
            return
        }

        // Cleanup last targets when no target found and try again
        if (prevTargetEntities.isNotEmpty()) {
            prevTargetEntities.clear()
            updateTarget()
        }
    }

    /**
     * Check if [entity] is selected as enemy with current target options and other modules
     */
    private fun isEnemy(entity: Entity?): Boolean {
        if (entity is EntityLivingBase && (EntityUtils.targetDead || isAlive(entity)) && entity != mc.thePlayer) {
            if (!EntityUtils.targetInvisible && entity.isInvisible())
                return false

            if (EntityUtils.targetPlayer && entity is EntityPlayer) {
                if (entity.isSpectator || AntiBot.isBot(entity))
                    return false

                if (EntityUtils.isFriend(entity) && !LiquidBounce.moduleManager[NoFriends::class.java].state)
                    return false

                val teams = LiquidBounce.moduleManager[Teams::class.java]

                return !teams.state || !teams.isInYourTeam(entity)
            }

            return EntityUtils.targetMobs && EntityUtils.isMob(entity) || EntityUtils.targetAnimals &&
                    EntityUtils.isAnimal(entity)
        }

        return false
    }

    /**
     * Attack [entity]
     */
    private fun attackEntity(entity: EntityLivingBase) {
        // Stop blocking
        if (mc.thePlayer.isBlocking || blockingStatus) {
            mc.netHandler.addToSendQueue(C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM,
                    BlockPos.ORIGIN, EnumFacing.DOWN))
            blockingStatus = false
        }

        // Call attack event
        LiquidBounce.eventManager.callEvent(AttackEvent(entity))

        // Attack target
        if (swingValue.get())
            mc.thePlayer.swingItem()
        mc.netHandler.addToSendQueue(C02PacketUseEntity(entity, C02PacketUseEntity.Action.ATTACK))

        if (keepSprintValue.get()) {
            // Critical Effect
            if (mc.thePlayer.fallDistance > 0F && !mc.thePlayer.onGround && !mc.thePlayer.isOnLadder &&
                    !mc.thePlayer.isInWater && !mc.thePlayer.isPotionActive(Potion.blindness) && !mc.thePlayer.isRiding)
                mc.thePlayer.onCriticalHit(entity)

            // Enchant Effect
            if (EnchantmentHelper.getModifierForCreature(mc.thePlayer.heldItem, entity.creatureAttribute) > 0F)
                mc.thePlayer.onEnchantmentCritical(entity)
        } else {
            if (mc.playerController.currentGameType != WorldSettings.GameType.SPECTATOR)
                mc.thePlayer.attackTargetEntityWithCurrentItem(entity)
        }

        if(crackSizeValue.get() != 0) {
            var i = 0
            while(i < crackSizeValue.get()) {
                mc.effectRenderer.emitParticleAtEntity(target, EnumParticleTypes.CRIT)
                i++
            }
        }

        // Extra critical effects
        val criticals = LiquidBounce.moduleManager[Criticals::class.java]

        for (i in 0..2) {
            // Critical Effect
            if (mc.thePlayer.fallDistance > 0F && !mc.thePlayer.onGround && !mc.thePlayer.isOnLadder && !mc.thePlayer.isInWater && !mc.thePlayer.isPotionActive(Potion.blindness) && mc.thePlayer.ridingEntity == null || criticals.state && criticals.msTimer.hasTimePassed(criticals.delayValue.get().toLong()) && !mc.thePlayer.isInWater && !mc.thePlayer.isInLava && !mc.thePlayer.isInWeb)
                mc.thePlayer.onCriticalHit(target)

            // Enchant Effect
            if (EnchantmentHelper.getModifierForCreature(mc.thePlayer.heldItem, target!!.creatureAttribute) > 0.0f || fakeSharpValue.get())
                mc.thePlayer.onEnchantmentCritical(target)
        }

        // Start blocking after attack
        if (mc.thePlayer.isBlocking || (autoBlockValue.get() == "Normal" && canBlock)) {
            if (!(blockRate.get() > 0 && Random().nextInt(100) <= blockRate.get()))
                return

            startBlocking(entity, interactAutoBlockValue.get())
        }
    }

    /**
     * Update killaura rotations to enemy
     */
    private fun updateRotations(entity: Entity): Boolean {
        if(maxTurnSpeed.get() <= 0F)
            return true
        val bb = entity.entityBoundingBox
        val predictSize = if(predictValue.get()) floatArrayOf(minPredictSize.get(),maxPredictSize.get()) else floatArrayOf(0.0F,0.0F)
        val predict = doubleArrayOf(
                (entity.posX - entity.prevPosX) * RandomUtils.nextFloat(predictSize[0], predictSize[1]),
                (entity.posY - entity.prevPosY) * RandomUtils.nextFloat(predictSize[0], predictSize[1]),
                (entity.posZ - entity.prevPosZ) * RandomUtils.nextFloat(predictSize[0], predictSize[1]))
        val boundingBox = when(boundingBoxModeValue.get()) {
            "Basic" -> AxisAlignedBB(max(bb.minX,bb.minX + predict[0]),max(bb.minY,bb.minY + predictSize[1]),max(bb.minZ,bb.minZ + predict[2]),min(bb.maxX,bb.maxX + predict[0]),min(bb.maxY,bb.maxY + predictSize[1]),min(bb.maxZ,bb.maxZ + predict[2]));
            else -> bb.offset(predict[0],predict[1],predict[2])
        }
        val (_, rotation) = RotationUtils.searchCenter(boundingBox, false, false, predictValue.get(), mc.thePlayer.getDistanceToEntityBox(entity) < throughWallsRangeValue.get(), maxRange)
                ?: return false

        val limitedRotation = RotationUtils.limitAngleChange(RotationUtils.serverRotation, when (rotationModeValue.get()) {
            "Normal" -> RotationUtils.searchCenter2(boundingBox, predictValue.get(), mc.thePlayer.getDistanceToEntityBox(entity) < throughWallsRangeValue.get(), maxRange).rotation
            "Lock" -> RotationUtils.toRotation(RotationUtils.getCenter(boundingBox), predictValue.get())
            "AntiCheat" -> rotation
            "Custom" -> RotationUtils.getCustomRotation(entity, customRotationPitch.get(), randomCustomRotation.get())
            else -> RotationUtils.getRotationsForAura(entity, maxRange + 0.5f)
        },
                (Math.random() * (maxTurnSpeed.get() - minTurnSpeed.get()) + minTurnSpeed.get()).toFloat())
        when(aimMode.get()) {
            "Silent" -> RotationUtils.setTargetRotation(limitedRotation, if (aacValue.get()) 15 else 0)
            "Ghost" -> limitedRotation.toPlayer(mc.thePlayer)
        }

        return true
    }



    /**
     * Check if enemy is hitable with current rotations
     */
    private fun updateHitable() {
        // Disable hitable check if turn speed is zero
        if(maxTurnSpeed.get() <= 0F) {
            hitable = true
            return
        }

        val reach = min(maxRange.toDouble(), mc.thePlayer.getDistanceToEntityBox(target!!)) + 1
        val hitMode = hitableMode.get()
        if(hitMode == "Normal") {
            hitable = RotationUtils.isFaced(currentTarget, reach)
        } else {
            if(hitMode == "Hypixel") {
                hitable = !LiquidBounce.moduleManager[BlockFly::class.java].state && !LiquidBounce.moduleManager[Scaffold::class.java].state
            } else {
                if(hitMode == "Random") {
                    hitable = RotationUtils.isFaced(currentTarget, reach) && Random().nextBoolean()
                }
            }
        }
    }

    /**
     * Start blocking
     */
    private fun startBlocking(interactEntity: Entity, interact: Boolean) {
        if (interact) {
            val positionEye = mc.renderViewEntity?.getPositionEyes(1F)

            val expandSize = interactEntity.collisionBorderSize.toDouble()
            val boundingBox = interactEntity.entityBoundingBox.expand(expandSize, expandSize, expandSize)

            val (yaw, pitch) = RotationUtils.targetRotation
                    ?: Rotation(mc.thePlayer!!.rotationYaw, mc.thePlayer!!.rotationPitch)
            val yawCos = cos(-yaw * 0.017453292F - Math.PI.toFloat())
            val yawSin = sin(-yaw * 0.017453292F - Math.PI.toFloat())
            val pitchCos = -cos(-pitch * 0.017453292F)
            val pitchSin = sin(-pitch * 0.017453292F)
            val range = min(maxRange.toDouble(), mc.thePlayer!!.getDistanceToEntityBox(interactEntity)) + 1
            val lookAt = positionEye!!.addVector(yawSin * pitchCos * range, pitchSin * range, yawCos * pitchCos * range)

            val movingObject = boundingBox.calculateIntercept(positionEye, lookAt) ?: return
            val hitVec = movingObject.hitVec

            mc.netHandler.addToSendQueue(C02PacketUseEntity(interactEntity, Vec3(
                    hitVec.xCoord - interactEntity.posX,
                    hitVec.yCoord - interactEntity.posY,
                    hitVec.zCoord - interactEntity.posZ)
            ))
            mc.netHandler.addToSendQueue(C02PacketUseEntity(interactEntity, C02PacketUseEntity.Action.INTERACT))
        }
        when(blockMode.get().toLowerCase()) {
            "packet" -> {
                mc.netHandler.addToSendQueue(C08PacketPlayerBlockPlacement(mc.thePlayer.heldItem))
            }
            "normal" -> mc.thePlayer.setItemInUse(mc.thePlayer.heldItem, 51213)

            "tick" -> {
                KeyBinding.onTick(mc.gameSettings.keyBindUseItem.keyCode)
                if (mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld,
                                mc.thePlayer.heldItem)) {
                    mc.itemRenderer.resetEquippedProgress2()
                }
            }

            "hvh" -> {
                mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.heldItem)
                mc.thePlayer.setItemInUse(mc.thePlayer.heldItem, mc.thePlayer.heldItem.maxItemUseDuration)
            }
            "simple" -> mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.heldItem)
        }
        blockingStatus = true
    }


    /**
     * Stop blocking
     */
    private fun stopBlocking() {
        if (blockingStatus) {
            when(blockMode.get().toLowerCase()) {
                "packet", "hvh" -> {
                    mc.netHandler.addToSendQueue(C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN))
                }
                else -> {
                    KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.keyCode, false)
                    mc.playerController.onStoppedUsingItem(mc.thePlayer)
                }
            }
            blockingStatus = false
        }
    }

    /**
     * Check if run should be cancelled
     */
    private val cancelRun: Boolean
        get() = mc.thePlayer.isSpectator || !isAlive(mc.thePlayer)
                || LiquidBounce.moduleManager[Blink::class.java].state || LiquidBounce.moduleManager[FreeCam::class.java].state

    /**
     * Check if [entity] is alive
     */
    private fun isAlive(entity: EntityLivingBase) = entity.isEntityAlive && entity.health > 0 ||
            aacValue.get() && entity.hurtTime > 5


    /**
     * Check if player is able to block
     */
    private val canBlock: Boolean
        get() = mc.thePlayer.heldItem != null && mc.thePlayer.heldItem.item is ItemSword

    /**
     * Range
     */
    private val maxRange: Float
        get() = max(rangeValue.get(), throughWallsRangeValue.get())

    private fun getRange(entity: Entity) =
            (if (mc.thePlayer.getDistanceToEntityBox(entity) >= throughWallsRangeValue.get()) rangeValue.get() else throughWallsRangeValue.get()) - if (mc.thePlayer.isSprinting) rangeSprintReducementValue.get() else 0F

    /**
     * HUD Tag
     */
    override val tag: String?
        get() = targetModeValue.get()
}