package net.ccbluex.liquidbounce.injection.forge.mixins.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.util.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import java.io.IOException;
import java.io.InputStream;

@Mixin(FontRenderer.class)
public class MixinFontRenderer {
    @Shadow
    private static final ResourceLocation[] unicodePageLocations = new ResourceLocation[256];
    @Shadow
    private byte[] glyphWidth = new byte[65536];

    protected InputStream getResourceInputStream(ResourceLocation p_getResourceInputStream_1_) throws IOException {
        return Minecraft.getMinecraft().getResourceManager().getResource(p_getResourceInputStream_1_).getInputStream();
    }
//    @Overwrite
//    private void readGlyphSizes() {
//        InputStream inputstream = null;
//
//        try {
//            inputstream = this.getResourceInputStream(new ResourceLocation("liquidbounce/font/glyph_sizes.bin"));
//            inputstream.read(this.glyphWidth);
//        } catch (IOException ioexception) {
//            throw new RuntimeException(ioexception);
//        } finally {
//            IOUtils.closeQuietly(inputstream);
//        }
//    }
//    @Overwrite
//    private ResourceLocation getUnicodePageLocation(int page) {
//        if (unicodePageLocations[page] == null) {
//            unicodePageLocations[page] = new ResourceLocation(String.format((String)"liquidbounce/font/unicode_page_%02x.png", (Object[])new Object[]{page}));
//        }
//        return unicodePageLocations[page];
//    }
}
