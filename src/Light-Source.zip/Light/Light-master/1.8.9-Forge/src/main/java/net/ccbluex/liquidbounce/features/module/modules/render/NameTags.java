package net.ccbluex.liquidbounce.features.module.modules.render;
import java.awt.Color;
import java.util.ArrayList;

import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render3DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.features.module.modules.world.AntiBot;
import net.ccbluex.liquidbounce.features.module.modules.misc.Teams;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.*;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;
@ModuleInfo(name = "NameTags", description = "Show the nametags.", category = ModuleCategory.RENDER)
public class NameTags
        extends Module {
    private BoolValue armor = new BoolValue("Armor", true);
    private BoolValue prefix = new BoolValue("Prefix", false);
    private FloatValue scale = new FloatValue("Scale", 3, 1, 5);
    private BoolValue zoomMode = new BoolValue("Zoom", false);
    private BoolValue invis = new BoolValue("Invisibles", false);
    public int[] colorCode = new int[32];
    public NameTags() {
        for (int i = 0; i < 32; ++i) {
            int j = (i >> 3 & 1) * 85;
            int k = (i >> 2 & 1) * 170 + j;
            int l = (i >> 1 & 1) * 170 + j;
            int i1 = (i >> 0 & 1) * 170 + j;

            if (i == 6) {
                k += 85;
            }

            if (mc.gameSettings.anaglyph) {
                int j1 = (k * 30 + l * 59 + i1 * 11) / 100;
                int k1 = (k * 30 + l * 70) / 100;
                int l1 = (k * 30 + i1 * 70) / 100;
                k = j1;
                l = k1;
                i1 = l1;
            }

            if (i >= 16) {
                k /= 4;
                l /= 4;
                i1 /= 4;
            }
            colorCode[i] = (k & 255) << 16 | (l & 255) << 8 | i1 & 255;
        }
    }

    @EventTarget
    private void onRender(Render3DEvent render) {
        ArrayList<EntityPlayer> validEnt = new ArrayList<>();
        if (validEnt.size() > 100) {
            validEnt.clear();
        }
        for (EntityLivingBase player2 : mc.theWorld.playerEntities) {
            if (player2.isEntityAlive()) {
                if (player2.isInvisible() && !invis.get()) {
                    if (!validEnt.contains(player2)) continue;
                    validEnt.remove(player2);
                    continue;
                }
                if (player2 == mc.thePlayer) {
                    if (!validEnt.contains(player2)) continue;
                    validEnt.remove(player2);
                    continue;
                }
                if (validEnt.size() > 100) break;
                if (validEnt.contains(player2)) continue;
                validEnt.add((EntityPlayer)player2);
                continue;
            }
            if (!validEnt.contains(player2)) continue;
            validEnt.remove(player2);
        }
        validEnt.forEach(player -> {
            float x = (float)(player.lastTickPosX + (player.posX - player.lastTickPosX) * render.getPartialTicks() - mc.getRenderManager().renderPosX);
            float y = (float)(player.lastTickPosY + (player.posY - player.lastTickPosY) * render.getPartialTicks() - mc.getRenderManager().renderPosY);
            float z = (float)(player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * render.getPartialTicks() - mc.getRenderManager().renderPosZ);
            renderTag(player, x, y, z);
        });
    }

    private void drawNames(EntityPlayer player) {
        float xP = 5f;
        int n12 = new Color(175,175,175,255).getRGB();
        String formattedText = player.getDisplayName().getFormattedText();
        int i = 0;
        while (i < formattedText.length()) {
            if (formattedText.charAt(i) == '§' && i + 1 < formattedText.length()) {
                int index = "0123456789abcdefklmnorg".indexOf(Character.toLowerCase(formattedText.charAt(i + 1)));
                if (index < 16) {
                    try {
                        Color color = new Color(colorCode[index]);
                        n12 = getColor(color.getRed(), color.getGreen(), color.getBlue(), 255);
                    }
                    catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
                        arrayIndexOutOfBoundsException.printStackTrace();
                    }
                }
            }
            ++i;
        }
        float width = Math.max((float)getWidth(getPlayerName(player)) / 2.0f + xP, getWidth("Health : " + (int)player.getHealth()) / 2) + xP;
        float nw = - width - xP;
        float offset = getWidth(getPlayerName(player));
        float healthwidth = nw + (width - nw) * player.getHealth() / player.getMaxHealth();
        RenderUtils.drawRect(nw, -50, width, 0.0,  new Color(60, 60, 60, 120).getRGB());
        RenderUtils.drawRect(nw, -3.0, healthwidth, 0.0,  n12);
        GlStateManager.disableDepth();
        drawString(getPlayerName(player),width - (width - nw) / 2 - offset / 2, - 40f);
        drawString("Health : " + (int)player.getHealth(),width - (width - nw) / 2 - getWidth("Health : " + (int)player.getHealth()) / 2, - 22f);
        GlStateManager.enableDepth();
    }

    private void drawString(String text, float x, float y) {
        Fonts.font40.drawStringWithShadow(text, x, y,16777215);
    }

    private int getWidth(String text) {
        return Fonts.font40.getStringWidth(text);
    }

    private void startDrawing(float x, float y, float z, EntityPlayer player) {
        float var10001 = mc.gameSettings.thirdPersonView == 2 ? -1.0f : 1.0f;
        double size = zoomMode.get() ? (getSize(player) / 10.0f) * scale.get() * 0.5 : (getSize(player) / 10.0f) * scale.get() * 1.5;
        GL11.glPushMatrix();
        RenderUtils.startDrawing();
        GL11.glTranslatef(x, y, z);
        GL11.glNormal3f(0.0f, 1.0f, 0.0f);
        GL11.glRotatef((- mc.getRenderManager().playerViewY), 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(mc.getRenderManager().playerViewX, var10001, 0.0f, 0.0f);
        GL11.glScaled((-0.01666666753590107 * size), (-0.01666666753590107 * size), (0.01666666753590107 * size));
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int scaleFactor = scaledResolution.getScaleFactor();
        double scaling = scaleFactor / Math.pow(scaleFactor, 2.0) * 2;
        GL11.glScaled(scaling, scaling, scaling);
    }

    private void stopDrawing() {
        RenderUtils.stopDrawing();
        GlStateManager.color(1.0f, 1.0f, 1.0f);
        GlStateManager.popMatrix();
    }

    private void renderTag(EntityPlayer player, float x, float y, float z) {
        y = (float)(y + (1.55 + (player.isSneaking() ? 0.5 : 0.7)));
        startDrawing(x, y, z, player);
        drawNames(player);
        GL11.glColor4d(1.0, 1.0, 1.0, 1.0);
        if (armor.get()) {
            renderArmor(player);
        }
        stopDrawing();
    }

    public int getColor(int p_clamp_int_0_, int p_clamp_int_0_2, int p_clamp_int_0_3, int p_clamp_int_0_4) {
        return MathHelper.clamp_int(p_clamp_int_0_4, 0, 255) << 24 | MathHelper.clamp_int(p_clamp_int_0_, 0, 255) << 16 | MathHelper.clamp_int(p_clamp_int_0_2, 0, 255) << 8 | MathHelper.clamp_int(p_clamp_int_0_3, 0, 255);
    }

    private void renderArmor(EntityPlayer player) {
        GlStateManager.scale(2.0f, 2.0f, 2.0f);
        ItemStack armourStack;
        ItemStack[] renderStack = player.inventory.armorInventory;
        int xOffset = 0;
        ItemStack[] arritemStack = renderStack;
        int n = arritemStack.length;
        int n2 = 0;
        while (n2 < n) {
            ItemStack aRenderStack = arritemStack[n2];
            armourStack = aRenderStack;
            if (armourStack != null) {
                xOffset -= 8;
            }
            ++n2;
        }
        if (player.getHeldItem() != null) {
            xOffset -= 8;
            ItemStack stock = player.getHeldItem().copy();
            if (stock.hasEffect() && (stock.getItem() instanceof ItemTool || stock.getItem() instanceof ItemArmor)) {
                stock.stackSize = 1;
            }
            renderItemStack(stock, xOffset, -45);
            xOffset += 16;
        }
        renderStack = player.inventory.armorInventory;
        int index = 3;
        while (index >= 0) {
            armourStack = renderStack[index];
            if (armourStack != null) {
                renderItemStack(armourStack, xOffset, -45);
                xOffset += 16;
            }
            --index;
        }
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }

    private String getPlayerName(EntityPlayer player) {
        String name = player.getDisplayName().getFormattedText();
        String pre = "";
        if(prefix.get()) {
            Teams teams = (Teams) LiquidBounce.moduleManager.getModule(Teams.class);
            if (LiquidBounce.fileManager.friendsConfig.isFriend(player.getName())) {
                pre = pre + "§b[Friend] ";
            }
            if (teams.isInYourTeam(player)) {
                pre = pre + "§a[TEAM] ";
            }
            if (AntiBot.isBot(player)) {
                pre = pre + "§9[BOT] ";
            }
            if (!AntiBot.isBot(player) && !teams.isInYourTeam(player)) {
                if (LiquidBounce.fileManager.friendsConfig.isFriend(player.getName())) {
                    pre = "§b[Friend] §c";
                }else {
                    pre = "§c";
                }
            }
        }
        name = pre + name;
        return name;
    }

    private float getSize(EntityPlayer player) {
        return mc.thePlayer.getDistanceToEntity(player) >= 1.0 ? mc.thePlayer.getDistanceToEntity(player) / 4.0f * 1.5f : 1.0f / 4.0f * 1.5f;
    }

    private void renderItemStack(ItemStack stack, int x, int y) {
        GlStateManager.pushMatrix();
        GlStateManager.depthMask(true);
        GlStateManager.clear(256);
        RenderHelper.enableStandardItemLighting();
        mc.getRenderItem().zLevel = -150.0f;
        GlStateManager.disableDepth();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.enableLighting();
        GlStateManager.enableDepth();
        mc.getRenderItem().renderItemAndEffectIntoGUI(stack, x, y);
        mc.getRenderItem().renderItemOverlays(mc.fontRendererObj, stack, x, y);
        mc.getRenderItem().zLevel = 0.0f;
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableCull();
        GlStateManager.enableAlpha();
        GlStateManager.disableBlend();
        GlStateManager.disableLighting();
        double s = 0.5;
        GlStateManager.scale(s, s, s);
        GlStateManager.disableDepth();
        GlStateManager.enableDepth();
        GlStateManager.scale(2.0f, 2.0f, 2.0f);
        GlStateManager.popMatrix();
    }

}

