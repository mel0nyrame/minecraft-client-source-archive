package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
@ModuleInfo("PlayerSize","Edit the player's size", ModuleCategory.RENDER, fakeName = "Player Size")
class PlayerEdit : Module() {
    val playerSizeValue = FloatValue("PlayerSize", 0.5f, 0.01f, 5f)
}