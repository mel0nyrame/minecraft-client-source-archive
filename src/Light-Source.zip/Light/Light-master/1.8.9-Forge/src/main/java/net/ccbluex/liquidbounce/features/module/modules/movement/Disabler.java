package net.ccbluex.liquidbounce.features.module.modules.movement;
import net.ccbluex.liquidbounce.event.*;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.timer.TimerUtil;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
@ModuleInfo(name = "Disabler", description = "Disabler", category = ModuleCategory.MOVEMENT)
public final class Disabler extends Module {
    public static boolean packet;
    public int count;
    private int sb;
    TimerUtil disable = new TimerUtil();
    int tick = 0;
    @EventTarget
    public void onUpdate(UpdateEvent event) {
        if(mc.thePlayer.ticksExisted<= 1) {
            count = 0;
            sb = 0;
            disable.reset();
            tick = 0;
            packet = false;
        }
    }
    @EventTarget
    public void onPacket(PacketEvent event) {
        disable(event);
    }
    @Override
    public void onEnable() {
        super.onEnable();
        sb = 0;
    }


    public void disable(PacketEvent event) {
        if (event != null) {
            if (event.getPacket() instanceof C0FPacketConfirmTransaction) {
                C0FPacketConfirmTransaction c0FPacketConfirmTransaction = (C0FPacketConfirmTransaction) event.getPacket();
                count++;
                if(c0FPacketConfirmTransaction.getWindowId() == 0 && c0FPacketConfirmTransaction.getUid() < 0 && sb++ > 7)
                    event.cancelEvent();
                if(sb > 10) sb = 10;
            }
        } else
            if (mc.thePlayer.ticksExisted % 4 == 0)
                sendDisable();
    }
    public void sendDisable() {
        PlayerCapabilities playerCapabilities = new PlayerCapabilities();
        playerCapabilities.allowFlying = true;
        playerCapabilities.isFlying = true;
    }
    @Override
    public String getTag () {
        return "Hypixel";
    }
}