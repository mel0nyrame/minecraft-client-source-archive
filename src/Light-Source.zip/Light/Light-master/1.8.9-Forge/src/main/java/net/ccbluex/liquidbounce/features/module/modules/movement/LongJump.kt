package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.math.Angle.e
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition
import net.minecraft.network.play.server.S08PacketPlayerPosLook
import net.minecraft.util.EnumFacing
import net.minecraft.util.MovementInput
import java.util.*
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt


@ModuleInfo(name = "LongJump", description = "Allows you to jump further.", category = ModuleCategory.MOVEMENT, fakeName = "Long Jump")
class LongJump : Module() {
    private val modeValue = ListValue("Mode", arrayOf("NCP", "AACv1", "AACv2", "AACv3", "Mineplex", "Mineplex2", "Mineplex3", "StarBlock", "RedeSky", "Hypixel"), "RedeSky")
    private val ncpBoostValue = FloatValue("NCPBoost", 4.25f, 1f, 10f)
    private val autoJumpValue = BoolValue("AutoJump", false)
    private val autoDisableValue = BoolValue("AutoDisable", true)
    private var jumped = false
    private var canBoost = false
    private var teleported = false
    private var canMineplexBoost = false
    private var stage = 0
    private var groundTicks = 0f
    private var moveSpeed = 0.0
    private var lastDist = 0.0
    @EventTarget
    private fun onTick(e: TickEvent) {
        val xDist = mc.thePlayer.posX - mc.thePlayer.prevPosX
        val zDist = mc.thePlayer.posZ - mc.thePlayer.prevPosZ
        lastDist = sqrt(xDist * xDist + zDist * zDist)
        if (MovementUtils.isMoving() && mc.thePlayer.onGround && autoDisableValue.get()) {
            if (groundTicks > 0) {
                groundTicks = 0f
                state = false
            }
        }
    }

    override fun onEnable() {
        if (mc.thePlayer == null) return
        groundTicks = 0f
        moveSpeed = MovementUtils.getBaseMoveSpeed()
        stage = 0
        damagePlayer(modeValue.value)
    }

    private fun damagePlayer(modeName : String) {
        if(modeName != "Hypixel")
            return
        var i = 0
        while (i < (3 + MovementUtils.getJumpEffect()) / 0.0399999986886975) {
            val rd: Double = Random().nextDouble() * 1.0E-5
            for (value in doubleArrayOf(0.0399999986886975 - rd, 0.03 + rd, rd)) {
                mc.netHandler.addToSendQueue(C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + value, mc.thePlayer.posZ, false))
            }
            ++i
        }
        mc.netHandler.addToSendQueue(C03PacketPlayer(true))
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (jumped) {
            val mode = modeValue.get()
            if (mc.thePlayer.onGround || mc.thePlayer.capabilities.isFlying) {
                jumped = false
                canMineplexBoost = false
                if (mode.equals("NCP", ignoreCase = true)) {
                    mc.thePlayer.motionX = 0.0
                    mc.thePlayer.motionZ = 0.0
                }
                return
            }
            when (mode.toLowerCase()) {
                "ncp" -> {
                    MovementUtils.strafe(MovementUtils.getSpeed() * if (canBoost) ncpBoostValue.get() else 1f)
                    canBoost = false
                }
                "aacv1", "redesky" -> {
                    mc.thePlayer.motionY += 0.05999
                    MovementUtils.strafe(MovementUtils.getSpeed() * 1.08f)
                }
                "aacv2", "mineplex3" -> {
                    mc.thePlayer.jumpMovementFactor = 0.09f
                    mc.thePlayer.motionY += 0.0132099999999999999999999999999
                    mc.thePlayer.jumpMovementFactor = 0.08f
                    MovementUtils.strafe()
                }
                "starblock" -> {
                    mc.thePlayer.motionX = -Math.sin(MovementUtils.getDirection()) * 0.6
                    mc.thePlayer.motionZ = Math.cos(MovementUtils.getDirection()) * 0.6
                }
                "aacv3" -> {
                    val player = mc.thePlayer
                    if (player.fallDistance > 0.5f && !teleported) {
                        val value = 3.0
                        val horizontalFacing = player.horizontalFacing
                        var x = 0.0
                        var z = 0.0
                        when (horizontalFacing) {
                            EnumFacing.NORTH -> z = -value
                            EnumFacing.EAST -> x = +value
                            EnumFacing.SOUTH -> z = +value
                            EnumFacing.WEST -> x = -value
                        }
                        player.setPosition(player.posX + x, player.posY, player.posZ + z)
                        teleported = true
                    }
                }
                "mineplex" -> {
                    mc.thePlayer.motionY += 0.0132099999999999999999999999999
                    mc.thePlayer.jumpMovementFactor = 0.08f
                    MovementUtils.strafe()
                }
                "mineplex2" -> {
                    if (!canMineplexBoost) return
                    mc.thePlayer.jumpMovementFactor = 0.1f
                    if (mc.thePlayer.fallDistance > 1.5f) {
                        mc.thePlayer.jumpMovementFactor = 0f
                        mc.thePlayer.motionY = -10.0
                    }
                    MovementUtils.strafe()
                }
            }
        }
        if (autoJumpValue.get() && mc.thePlayer.onGround && MovementUtils.isMoving()) {
            jumped = true
            mc.thePlayer.jump()
        }
    }

    @EventTarget
    fun onMove(event: MoveEvent) {
        val mode = modeValue.get()
        if (mode.equals("mineplex3", ignoreCase = true)) {
            if (mc.thePlayer.fallDistance != 0f) mc.thePlayer.motionY += 0.037
        } else if (mode.equals("ncp", ignoreCase = true) && !MovementUtils.isMoving() && jumped) {
            mc.thePlayer.motionX = 0.0
            mc.thePlayer.motionZ = 0.0
            event.zeroXZ()
        }
        if (mode == "Hypixel") {
            if (mc.thePlayer.moveStrafing <= 0.0f && mc.thePlayer.moveForward <= 0.0f) {
                stage = 1
            }
            if (stage == 1 && (mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f)) {
                stage = 2
                moveSpeed = 3.0 * MovementUtils.getBaseMoveSpeed() - 0.01
            } else if (stage == 2) {
                stage = 3
                mc.thePlayer.motionY = 0.424
                event.y = 0.424
                moveSpeed *= 2.149802
            } else if (stage == 3) {
                stage = 4
                val difference: Double = 0.66 * (lastDist - MovementUtils.getBaseMoveSpeed())
                moveSpeed = lastDist - difference
            } else if (stage == 4) {
                if (mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.entityBoundingBox.offset(0.0, mc.thePlayer.motionY, 0.0)).size > 0 || mc.thePlayer.isCollidedVertically) {
                    stage = 5
                }
                moveSpeed = lastDist - lastDist / 159.0
            } else if (stage == 5) {
                stage = 1
            } else if (stage == 0) {
                stage = 1
            }
            moveSpeed = max(moveSpeed, MovementUtils.getBaseMoveSpeed())
            var forward: Float = mc.thePlayer.movementInput.moveForward
            var strafe: Float = mc.thePlayer.movementInput.moveStrafe
            var yaw = mc.thePlayer.rotationYaw
            if (forward == 0.0f && strafe == 0.0f) {
                event.x = 0.0
                event.z = 0.0
            } else if (forward != 0.0f) {
                if (strafe >= 1.0f) {
                    yaw += (if (forward > 0.0f) -45 else 45).toFloat()
                    strafe = 0.0f
                } else if (strafe <= -1.0f) {
                    yaw += (if (forward > 0.0f) 45 else -45).toFloat()
                    strafe = 0.0f
                }
                if (forward > 0.0f) {
                    forward = 1.0f
                } else if (forward < 0.0f) {
                    forward = -1.0f
                }
            }
            val mx = cos(Math.toRadians(yaw + 90.0))
            val mz = sin(Math.toRadians(yaw + 90.0))
            event.x = forward * moveSpeed * mx + strafe * moveSpeed * mz
            event.z = forward * moveSpeed * mz - strafe * moveSpeed * mx
            if (forward == 0.0f && strafe == 0.0f) {
                event.x = 0.0
                event.z = 0.0
            }
        }
    }

    @EventTarget(ignoreCondition = true)
    fun onJump(event: JumpEvent) {
        jumped = true
        canBoost = true
        teleported = false
        if (state) {
            when (modeValue.get().toLowerCase()) {
                "mineplex" -> event.motion = event.motion * 4.08f
                "mineplex2" -> if (mc.thePlayer.isCollidedHorizontally) {
                    event.motion = 2.31f
                    canMineplexBoost = true
                    mc.thePlayer.onGround = false
                }
            }
        }
    }

    override val tag: String
        get() = modeValue.get()
}