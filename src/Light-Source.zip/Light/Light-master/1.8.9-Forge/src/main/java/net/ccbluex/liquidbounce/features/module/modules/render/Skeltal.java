package net.ccbluex.liquidbounce.features.module.modules.render;

import java.util.HashMap;
import java.util.Map;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render3DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.Vec4;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;

@ModuleInfo(name = "Skeltal", description = "Skeltal.", category = ModuleCategory.RENDER)
public class Skeltal extends Module {
    private static final Map<EntityPlayer, float[][]> modelRotations = new HashMap<>();
    @EventTarget
    public void onRender3D(Render3DEvent event) {
        RenderUtils.setupRender(true);
        GL11.glDisable(2848);
        GlStateManager.disableLighting();
        modelRotations.keySet().removeIf(player -> {
                    return !mc.theWorld.playerEntities.contains(player);
                }
        );
        mc.theWorld.playerEntities.forEach(player -> {
            if (player == mc.thePlayer) return;
            if (player.isInvisible()) {
                return;
            }
            float[][] modelRotations = this.modelRotations.get(player);
            if (modelRotations == null) {
                return;
            }
            GL11.glPushMatrix();
            GL11.glLineWidth(1.0f);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            Vec4 interp = RenderUtils.interpolateRender(player);
            double x = interp.getX() - mc.getRenderManager().renderPosX;
            double y = interp.getY() - mc.getRenderManager().renderPosY;
            double z = interp.getZ() - mc.getRenderManager().renderPosZ;
            GL11.glTranslated(x, y, z);
            float bodyYawOffset = player.prevRenderYawOffset + (player.renderYawOffset - player.prevRenderYawOffset) * mc.timer.renderPartialTicks;
            GL11.glRotatef((- bodyYawOffset), 0.0f, 1.0f, 0.0f);
            GL11.glTranslated(0.0, 0.0, (player.isSneaking() ? -0.235 : 0.0));
            float legHeight = player.isSneaking() ? 0.6f : 0.75f;
            GL11.glPushMatrix();
            GL11.glTranslated(-0.125, legHeight, 0.0);
            if (modelRotations[3][0] != 0.0f) {
                GL11.glRotatef((modelRotations[3][0] * 57.295776f), 1.0f, 0.0f, 0.0f);
            }
            if (modelRotations[3][1] != 0.0f) {
                GL11.glRotatef((modelRotations[3][1] * 57.295776f), 0.0f, 1.0f, 0.0f);
            }
            if (modelRotations[3][2] != 0.0f) {
                GL11.glRotatef((modelRotations[3][2] * 57.295776f), 0.0f, 0.0f, 1.0f);
            }
            GL11.glBegin(3);
            GL11.glVertex3d(0.0, 0.0, 0.0);
            GL11.glVertex3d(0.0, (- legHeight), 0.0);
            GL11.glEnd();
            GL11.glPopMatrix();
            GL11.glPushMatrix();
            GL11.glTranslated(0.125, legHeight, 0.0);
            if (modelRotations[4][0] != 0.0f) {
                GL11.glRotatef((modelRotations[4][0] * 57.295776f), 1.0f, 0.0f, 0.0f);
            }
            if (modelRotations[4][1] != 0.0f) {
                GL11.glRotatef((modelRotations[4][1] * 57.295776f), 0.0f, 1.0f, 0.0f);
            }
            if (modelRotations[4][2] != 0.0f) {
                GL11.glRotatef((modelRotations[4][2] * 57.295776f), 0.0f, 0.0f, 1.0f);
            }
            GL11.glBegin(3);
            GL11.glVertex3d(0.0, 0.0, 0.0);
            GL11.glVertex3d(0.0, (- legHeight), 0.0);
            GL11.glEnd();
            GL11.glPopMatrix();
            GL11.glTranslated(0.0, 0.0, (player.isSneaking() ? 0.25 : 0.0));
            GL11.glPushMatrix();
            GL11.glTranslated(0.0, (player.isSneaking() ? -0.05 : 0.0), (player.isSneaking() ? -0.01725 : 0.0));
            GL11.glPushMatrix();
            GL11.glTranslated(-0.375, (legHeight + 0.55), 0.0);
            if (modelRotations[1][0] != 0.0f) {
                GL11.glRotatef((modelRotations[1][0] * 57.295776f), 1.0f, 0.0f, 0.0f);
            }
            if (modelRotations[1][1] != 0.0f) {
                GL11.glRotatef((modelRotations[1][1] * 57.295776f), 0.0f, 1.0f, 0.0f);
            }
            if (modelRotations[1][2] != 0.0f) {
                GL11.glRotatef(((- modelRotations[1][2]) * 57.295776f), 0.0f, 0.0f, 1.0f);
            }
            GL11.glBegin(3);
            GL11.glVertex3d(0.0, 0.0, 0.0);
            GL11.glVertex3d(0.0, -0.5, 0.0);
            GL11.glEnd();
            GL11.glPopMatrix();
            GL11.glPushMatrix();
            GL11.glTranslated(0.375, (legHeight + 0.55), 0.0);
            if (modelRotations[2][0] != 0.0f) {
                GL11.glRotatef((modelRotations[2][0] * 57.295776f), 1.0f, 0.0f, 0.0f);
            }
            if (modelRotations[2][1] != 0.0f) {
                GL11.glRotatef((modelRotations[2][1] * 57.295776f), 0.0f, 1.0f, 0.0f);
            }
            if (modelRotations[2][2] != 0.0f) {
                GL11.glRotatef(((- modelRotations[2][2]) * 57.295776f), 0.0f, 0.0f, 1.0f);
            }
            GL11.glBegin(3);
            GL11.glVertex3d(0.0, 0.0, 0.0);
            GL11.glVertex3d(0.0, -0.5, 0.0);
            GL11.glEnd();
            GL11.glPopMatrix();
            GL11.glRotatef((bodyYawOffset - player.rotationYawHead), 0.0f, 1.0f, 0.0f);
            GL11.glPushMatrix();
            GL11.glTranslated(0.0, (legHeight + 0.55), 0.0);
            if (modelRotations[0][0] != 0.0f) {
                GL11.glRotatef((modelRotations[0][0] * 57.295776f), 1.0f, 0.0f, 0.0f);
            }
            GL11.glBegin(3);
            GL11.glVertex3d(0.0, 0.0, 0.0);
            GL11.glVertex3d(0.0, 0.3, 0.0);
            GL11.glEnd();
            GL11.glPopMatrix();
            GL11.glPopMatrix();
            GL11.glRotatef((player.isSneaking() ? 25.0f : 0.0f), 1.0f, 0.0f, 0.0f);
            GL11.glTranslated(0.0, (player.isSneaking() ? -0.16175 : 0.0), (player.isSneaking() ? -0.48025 : 0.0));
            GL11.glPushMatrix();
            GL11.glTranslated(0.0, legHeight, 0.0);
            GL11.glBegin(3);
            GL11.glVertex3d(-0.125, 0.0, 0.0);
            GL11.glVertex3d(0.125, 0.0, 0.0);
            GL11.glEnd();
            GL11.glPopMatrix();
            GL11.glPushMatrix();
            GL11.glTranslated(0.0, legHeight, 0.0);
            GL11.glBegin(3);
            GL11.glVertex3d(0.0, 0.0, 0.0);
            GL11.glVertex3d(0.0, 0.55, 0.0);
            GL11.glEnd();
            GL11.glPopMatrix();
            GL11.glPushMatrix();
            GL11.glTranslated(0.0, (legHeight + 0.55), 0.0);
            GL11.glBegin(3);
            GL11.glVertex3d(-0.375, 0.0, 0.0);
            GL11.glVertex3d(0.375, 0.0, 0.0);
            GL11.glEnd();
            GL11.glPopMatrix();
            GL11.glPopMatrix();
        });
        RenderUtils.setupRender(false);
    }
}
