package net.ccbluex.liquidbounce.features.module.modules.player;

import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render3DEvent;
import net.ccbluex.liquidbounce.features.module.*;
import net.ccbluex.liquidbounce.utils.render.GLUtils;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.minecraft.client.entity.EntityPlayerSP;
import org.lwjgl.opengl.GL11;
import java.awt.Color;

@ModuleInfo(name = "PerfectBody", description = "CSGO.", category = ModuleCategory.PLAYER, fakeName = "Perfect Body")
public class PerfectBody extends Module {
    private FloatValue radiusValue = new FloatValue("Radius", 2.5F, 0.1F, 5.0F);
    @EventTarget
    public void onRender3D(Render3DEvent event) {
        drawCircle(mc.thePlayer, event.getPartialTicks(), radiusValue.get());
    }
    private void drawCircle(EntityPlayerSP entity, float partialTicks, double rad) { GL11.glPushMatrix();
        GL11.glDisable(3553);
        GLUtils.startSmooth();
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glLineWidth(1.0F);
        GL11.glBegin(3);
        double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - mc.getRenderManager().viewerPosX;
        double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - mc.getRenderManager().viewerPosY;
        double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - mc.getRenderManager().viewerPosZ;
        for (int i = 0; i <= 360; i++) {
            Color rainbow = new Color(Color.HSBtoRGB((float)(mc.thePlayer.ticksExisted / 70.0D + Math.sin(i / 50.0D * 1.75D)) % 1.0F, 0.7F, 1.0F));
            GL11.glColor3f(rainbow.getRed() / 255.0F, rainbow.getGreen() / 255.0F, rainbow.getBlue() / 255.0F);
            GL11.glVertex3d(x + rad * Math.cos(i * 6.283185307179586D / 45.0D), y, z + rad * Math.sin(i * 6.283185307179586D / 45.0D));
        }
        GL11.glEnd();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GLUtils.endSmooth();
        GL11.glEnable(3553);
        GL11.glPopMatrix();
    }
}
