package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.item.ItemBlock
import net.minecraft.network.play.client.C0APacketAnimation

@ModuleInfo(name = "FakeSwing", description = "Cancel the C0A but swing", category = ModuleCategory.RENDER, fakeName = "Fake Swing")
class FakeSwing : Module() {
    private var swing = false
    private val noSwingValue = BoolValue("NoSwing", false)
    @EventTarget
    fun onUpdate() {
        if (swing && !noSwingValue.get()) {
            mc.thePlayer.swingItem()
        }
    }

    @EventTarget
    fun onPacket(packetEvent: PacketEvent) {
        val packet = packetEvent.packet
        if (packet is C0APacketAnimation && !(mc.thePlayer.heldItem.item != null && mc.thePlayer.heldItem.item is ItemBlock)) {
            swing = true
            packetEvent.cancelEvent()
        } else {
            swing = false
        }
    }
}