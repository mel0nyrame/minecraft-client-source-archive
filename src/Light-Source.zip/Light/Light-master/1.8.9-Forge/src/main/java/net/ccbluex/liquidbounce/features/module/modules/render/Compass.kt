package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.CompassUtil

@ModuleInfo(name = "Compass", description = "Show the compass", category = ModuleCategory.RENDER)
class Compass : Module() {
    @EventTarget
    private fun onRender2D(e: Render2DEvent) {
        CompassUtil(325F, 325F, 1F, 2, true).draw()
    }
}