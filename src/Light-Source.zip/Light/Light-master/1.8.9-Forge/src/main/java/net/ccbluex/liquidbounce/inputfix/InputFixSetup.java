package net.ccbluex.liquidbounce.inputfix;

import java.util.Map;
import net.ccbluex.liquidbounce.inputfix.impl.GuiScreenFixOthers;
import net.ccbluex.liquidbounce.inputfix.impl.GuiScreenFixWindows;
import net.ccbluex.liquidbounce.inputfix.interfaces.IGuiScreenFix;
import net.ccbluex.liquidbounce.inputfix.utils.OSDetector;
import net.minecraftforge.fml.relauncher.IFMLCallHook;

public class InputFixSetup implements IFMLCallHook
{

    public static IGuiScreenFix impl;

    @Override
    public Void call() throws Exception
    {
        OSDetector.OS OS = OSDetector.detectOS();
        switch (OS)
        {
            case Windows:
                impl = new GuiScreenFixWindows();
                break;
            case Linux:
            case Mac:
                try
                {
                    impl = new GuiScreenFixOthers();
                }
                catch (Throwable t)
                {
                    impl = new GuiScreenFixWindows();
                }
                break;
            case Unknown:
            default:
                break;
        }
        return null;
    }

    @Override
    public void injectData(Map<String, Object> arg0)
    {
    }

}
