package net.ccbluex.liquidbounce.inputfix.interfaces;

public interface IGuiScreen
{

    void keyTyped(char c, int k);

}
