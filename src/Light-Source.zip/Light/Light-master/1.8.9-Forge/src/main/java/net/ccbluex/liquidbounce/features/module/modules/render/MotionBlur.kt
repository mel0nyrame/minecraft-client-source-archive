package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.ui.client.LightGUI.ClickGUI.LightClickGUI
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.util.ResourceLocation

@ModuleInfo("MotionBlur", "MotionBlur", ModuleCategory.RENDER, fakeName = "Motion Blur")
class MotionBlur : Module() {
    private val modeValue = ListValue("Mode", arrayOf("Little","Normal","Large"),"Little")

    override fun onDisable() {
        mc.entityRenderer.stopUseShader()
    }

    @EventTarget
    fun onUpdate(e: UpdateEvent) {
        if(mc.currentScreen !is LightClickGUI) {
            when (modeValue.get()) {
                "Little" -> {
                    mc.entityRenderer.loadShader(ResourceLocation("MotionBlur/Little.json"))
                }
                "Normal" -> {
                    mc.entityRenderer.loadShader(ResourceLocation("MotionBlur/Normal.json"))
                }
                "Large" -> {
                    mc.entityRenderer.loadShader(ResourceLocation("MotionBlur/Large.json"))
                }
            }
        } else
            mc.entityRenderer.stopUseShader()
    }

}