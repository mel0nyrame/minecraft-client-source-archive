package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.item.*
import java.awt.Color

@ModuleInfo(name = "ItemShow", description = "Show your held item", category = ModuleCategory.RENDER)
class ItemShow : Module() {
    private val xValue = IntegerValue("X", 125, 0, 1000)
    private val yValue = IntegerValue("Y", 125, 0, 1000)
    private val rectWidthValue = IntegerValue("RectWidth", 110, 0, 200)
    private val rectHeightValue = IntegerValue("RectHeight", 40, 0, 200)
    private var item = ""
    private fun getItem(currentItem : Item) : String {
        return if (currentItem is ItemSword) {
            "Sword"
        } else {
            if (currentItem is ItemFood || currentItem is ItemBucketMilk) {
                "Food"
            } else {
                if (currentItem is ItemBlock) {
                    "Block"
                } else {
                    if (currentItem is ItemBow) {
                        "Bow"
                    } else {
                        if (currentItem is ItemTool) {
                            "Tool"
                        } else {
                            if (currentItem is ItemPotion) {
                                "Potion"
                            } else {
                                if (currentItem is ItemMap || currentItem is ItemEmptyMap) {
                                    "Map"
                                } else {
                                    "Misc"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    @EventTarget
    private fun onRender2D(event: Render2DEvent) {
        RenderUtils.drawBorderedRect(xValue.get().toFloat(), yValue.get().toFloat(), xValue.get() + rectWidthValue.get().toFloat(), yValue.get() + rectHeightValue.get().toFloat(), 1f, Color(0, 0, 0, 255).rgb, Color(0, 0, 0, 140).rgb)
        mc.thePlayer.heldItem ?: return
        val currentItem = mc.thePlayer.heldItem.item
        item = getItem(currentItem)
        val itemName = mc.thePlayer.heldItem.displayName
        mc.fontRendererObj.drawString("Name:$itemName", xValue.get() + 4.toFloat(), yValue.get() + 5.toFloat(), Color(255, 255, 255).rgb, true)
        mc.fontRendererObj.drawString("Item:$item", xValue.get() + rectWidthValue.get() / 2.8f, yValue.get() + rectHeightValue.get() / 2.toFloat(), Color(255, 255, 255).rgb, true)
        mc.renderItem.renderItemAndEffectIntoGUI(mc.thePlayer.heldItem, xValue.get() + rectWidthValue.get() / 8, yValue.get() + rectHeightValue.get() / 3)
    }
}