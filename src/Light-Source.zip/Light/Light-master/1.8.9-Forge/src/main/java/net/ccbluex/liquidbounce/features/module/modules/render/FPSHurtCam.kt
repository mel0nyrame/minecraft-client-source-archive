package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.client.renderer.GlStateManager
import net.minecraft.client.renderer.Tessellator
import net.minecraft.client.renderer.vertex.DefaultVertexFormats
import net.minecraft.util.ResourceLocation
import org.lwjgl.opengl.GL11
@ModuleInfo("FPSHurtCam", "Like fps game.", ModuleCategory.RENDER, fakeName = "FPS Hurt Cam")
class FPSHurtCam : Module() {
    private val fps = ResourceLocation("textures/misc/vignette.png")
    @EventTarget
    private fun onRender2D(event: Render2DEvent) {
        GlStateManager.disableDepth()
        GlStateManager.depthMask(false)
        GlStateManager.tryBlendFuncSeparate(0, 769, 1, 0)
        if (mc.thePlayer.hurtTime > 0) {
            GL11.glColor4f(0.0f, 0.5f, 0.5f, mc.thePlayer.hurtTime.toFloat() / 100F)
        } else {
            GL11.glColor4f(0.0f, 0.0f, 0.0f, 0.0f)
        }
        val scaledResolution = ScaledResolution(mc)
        mc.textureManager.bindTexture(fps)
        val instance = Tessellator.getInstance()
        val worldRender = instance.worldRenderer
        worldRender.begin(7, DefaultVertexFormats.POSITION_TEX)
        worldRender.pos(0.0, scaledResolution.scaledHeight.toDouble(), -90.0).tex(0.0, 1.0).endVertex()
        worldRender.pos(scaledResolution.scaledWidth.toDouble(), scaledResolution.scaledHeight.toDouble(), -90.0).tex(1.0, 1.0).endVertex()
        worldRender.pos(scaledResolution.scaledWidth.toDouble(), 0.0, -90.0).tex(1.0, 0.0).endVertex()
        worldRender.pos(0.0, 0.0, -90.0).tex(0.0, 0.0).endVertex()
        instance.draw()
        GlStateManager.depthMask(true)
        GlStateManager.enableDepth()
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f)
        GlStateManager.tryBlendFuncSeparate(770, 772, 1, 0)
    }
}