
package net.ccbluex.liquidbounce.features.module.modules.player

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo

@ModuleInfo(name = "MultiActions", description = "Allows you to use items while breaking blocks.", category = ModuleCategory.PLAYER,fakeName = "More Actions")
class MultiActions : Module()