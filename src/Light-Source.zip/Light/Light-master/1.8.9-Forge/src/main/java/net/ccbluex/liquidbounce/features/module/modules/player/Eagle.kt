
package net.ccbluex.liquidbounce.features.module.modules.player

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.client.settings.GameSettings
import net.minecraft.init.Blocks
import net.minecraft.network.play.client.C0BPacketEntityAction
import net.minecraft.util.BlockPos

@ModuleInfo(name = "Eagle", description = "Makes you eagle (aka. FastBridge).", category = ModuleCategory.PLAYER)
class Eagle : Module() {
    private val silentValue = BoolValue("Silent", false)
    private var onSneak = false
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if(!silentValue.get()) {
            mc.gameSettings.keyBindSneak.pressed = isBlockAir()
        } else if(silentValue.get() && isBlockAir() && !onSneak) {
            mc.netHandler.addToSendQueue(C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SNEAKING))
            onSneak = true
        }
        if(onSneak && !isBlockAir()) {
            mc.netHandler.addToSendQueue(C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SNEAKING))
            onSneak = false
        }
    }

    private fun isBlockAir() : Boolean {
        return mc.theWorld.getBlockState(BlockPos(mc.thePlayer.posX,mc.thePlayer.posY - 1.0, mc.thePlayer.posZ)).block == Blocks.air
    }

    override fun onDisable() {
        if (mc.thePlayer != null)
            if (!GameSettings.isKeyDown(mc.gameSettings.keyBindSneak) || onSneak)
                mc.gameSettings.keyBindSneak.pressed = false
        onSneak = false
    }
}
