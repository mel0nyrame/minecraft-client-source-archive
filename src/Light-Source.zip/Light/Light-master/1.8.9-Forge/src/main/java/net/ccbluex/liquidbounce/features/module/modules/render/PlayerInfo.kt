package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.ui.font.GameFontRenderer
import net.ccbluex.liquidbounce.utils.ColorManager
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.render.ColorUtils
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.*
import net.minecraft.network.play.server.S08PacketPlayerPosLook
import java.awt.Color
@ModuleInfo("PlayerInfo","PlayerInfo",ModuleCategory.RENDER, fakeName = "Player Info")
class PlayerInfo : Module() {
    private val BackGroundRect = ListValue("BackGroundRect", arrayOf("Rect", "Round", "None"), "Round");
    private val TextRed = IntegerValue("TextRed", 255, 0, 255)
    private val TextGreen = IntegerValue("TextGreen", 255, 0, 255)
    private val TextBlue = IntegerValue("TextBlue", 255, 0, 255)
    private val BackGroundRed = IntegerValue("BackGroundRed", 255, 0, 255)
    private val BackGroundGreen = IntegerValue("BackGroundGreen", 255, 0, 255)
    private val BackGroundBlue = IntegerValue("BackGroundBlue", 255, 0, 255)
    private val BackGroundAlpha = IntegerValue("BackGroundAlpha", 135, 0, 255)
    private val x = IntegerValue("X", 0, 0, 1000)
    private val y = IntegerValue("Y", 0, 0, 1000)
    private val Width = FloatValue("BackGroundWidth", 70F, 0F, 300F)
    private val Height = IntegerValue("BackGroundHeight", 135, 0, 300)
    private val TextY = IntegerValue("TextY", 15, 5, 100)
    private val TextX = IntegerValue("TextX", 5, 0, 100)
    private val PingSpoof = BoolValue("PingSpoof", false)
    private val PingSpoofDelay = IntegerValue("PingSpoofDelay", 1000, 0, 100000)
    private val InfoText = TextValue("InfoText", "PlayerInfo")
    private val InfoTextX = IntegerValue("InfoTextX", 13, 0, 100)
    private val InfoTextY = IntegerValue("InfoTextY", 2, 0, 100)
    private val RainbowText = BoolValue("RainbowText", true)
    private val RainbowSpeed = FloatValue("RainbowSpeed", 0.6F, 0.1F, 1F)
    private val RainbowMode = ListValue("RainbowMode", arrayOf("Basic", "Normal"), "Normal")
    private val Font = IntegerValue("Font", 2, 1, 3)
    private var ticks = 0
    private var TextColor = 0
    private var LagBack = false
    private var sicks = 0
    private var CurrentFont : GameFontRenderer ?= null
    override fun onDisable() {
        ticks = 0
        LagBack = false
        sicks = 0
    }
    @EventTarget
    fun onRender2D(event: Render2DEvent) {
        var y = 0
        if(!RainbowText.get()) {
            TextColor = Color(TextRed.get(), TextGreen.get(), TextBlue.get()).rgb
        } else {
            when (RainbowMode.get()) {
                "Basic" -> {
                    TextColor = ColorManager.getRainbow2(2000, -y * 16)
                }
                "Normal" -> {
                    TextColor = ColorUtils.rainbow3(400000000L * y, 0.6F, 1F).rgb
                }
           }
        }
        val BackGroundColor = Color(BackGroundRed.get(), BackGroundGreen.get(), BackGroundBlue.get(), BackGroundAlpha.get()).rgb
        if(!mc.ingameGUI.chatGUI.chatOpen && !mc.gameSettings.showDebugInfo) {
            val Text = InfoText.get()
            val Name = "Name:" + mc.thePlayer.name
            val Ping = if(PingSpoof.get()) {
                "Ping:" + EntityUtils.getPing(mc.thePlayer).toString() + PingSpoofDelay.get().toString() + "ms";
            } else {
                "Ping:" + EntityUtils.getPing(mc.thePlayer).toString() + "ms";
            }
            val Timer = "Timer:" + mc.timer.timerSpeed.toInt()
            val Health = "Health:" + mc.thePlayer.health.toInt()
            val HurtTime = "HurtTime:" + mc.thePlayer.hurtTime
            val Armor = "Armor:" + getArmorValue()
            val Sprinting = "Sprinting:" + mc.thePlayer.isSprinting
            val Location = getLocation()
            val LagBackCheck = "LagBack:$LagBack"
            val infoList = arrayOf(Name,Health,HurtTime,Timer,Ping,Armor,Sprinting,Location,LagBackCheck)
            when(BackGroundRect.get()) {
                "Rect" -> RenderUtils.drawRect(x.get().toFloat(), this.y.get().toFloat(), x.get() + Width.get(), this.y.get() + Height.get().toFloat(), BackGroundColor)
                "Round" -> RenderUtils.drawRoundRect(x.get().toFloat(), this.y.get().toFloat(), x.get() + Width.get(), this.y.get() + Height.get().toFloat(), BackGroundColor)
            }

            CurrentFont?.drawStringWithShadow(Text, x.get() + InfoTextX.get().toFloat(), this.y.get() + InfoTextY.get().toFloat(), TextColor)
            var i = 0
            while(i < infoList.size) {
                i++
                CurrentFont?.drawStringWithShadow(infoList[i], x.get() + TextX.get().toFloat(), this.y.get() + TextY.get() * (i + 1).toFloat(), TextColor)
                y += 5
            }
        }
    }
    @EventTarget
    fun onUpdate(event :UpdateEvent) {
        when(Font.get()) {
            1 -> mc.fontRendererObj
            2 -> Fonts.font35
            3 -> Fonts.font40
        }
        if(LagBack) {
            sicks++
        }
        if(sicks >= 30) {
            LagBack = false
            sicks = 0
        }
        ticks++
        if(ticks >= 50) {
            ticks = 0
        }
    }
    private fun getArmorValue() : String{
        val armorValue = mc.thePlayer.totalArmorValue
        if(armorValue != 0) {
            return (armorValue * 5).toString() + "%"
        }
        return "0%"
    }
    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if(packet is S08PacketPlayerPosLook) {
            LagBack = true
        }
    }

    private fun getLocation() : String{
        if (mc.thePlayer.onGround && !mc.thePlayer.isInWater && !mc.thePlayer.isInLava) {
            return "Location:Ground"
        } else if (mc.thePlayer.speedInAir != 0f && !mc.thePlayer.isInWater && !mc.thePlayer.isInLava) {
            return "Location:Air"
        } else if (mc.thePlayer.isInWater) {
            return "Location:Water"
        } else if (mc.thePlayer.isInLava) {
            return "Location:Lava"
        }
        return "WTF? I DONT KNOW"
    }
}