package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.aac;

import net.ccbluex.liquidbounce.event.MoveEvent;
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode;

public class AAC4Hop extends SpeedMode {
    public AAC4Hop() {
        super("AAC4Hop");
    }

    @Override
    public void onMotion() {

    }

    @Override
    public void onUpdate() {
        if(mc.thePlayer.moveForward != 0) {
            if(mc.thePlayer.onGround) {
                mc.thePlayer.jump();
                mc.timer.timerSpeed = 1.6105f;
                mc.thePlayer.motionX *= 1.0708;
                mc.thePlayer.motionZ *= 1.0708;
            } else if(mc.thePlayer.fallDistance != 0 && mc.thePlayer.fallDistance < 1) {
                mc.timer.timerSpeed = 0.6f;
            } else if(mc.thePlayer.fallDistance > 7) {
                mc.timer.timerSpeed = 1.6105f;
            }
        }
    }

    @Override
    public void onMove(MoveEvent event) {

    }

}
