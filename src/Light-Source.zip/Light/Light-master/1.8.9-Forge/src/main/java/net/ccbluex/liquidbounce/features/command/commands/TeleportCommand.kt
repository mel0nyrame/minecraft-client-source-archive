package net.ccbluex.liquidbounce.features.command.commands

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.features.module.modules.player.Teleport
import java.lang.Float
class TeleportCommand : Command("Teleport", arrayOf("TP")) {
    override fun execute(args: Array<String>) {
        if (args.size >= 3) {
            try {
                Teleport.x = Float.valueOf(args[1])
                Teleport.y = Float.valueOf(args[2])
                Teleport.z = Float.valueOf(args[3])
            } catch(e: NumberFormatException) {
                chatSyntax("[Teleport] Please type numbers")
                return
            } catch(e : ArrayIndexOutOfBoundsException) {
                chatSyntax("[Teleport] Please type three numbers")
                return
            }
            LiquidBounce.moduleManager[Teleport::class.java]!!.state = true
            return
        } else {
            if(args.size > 1) {
                if(mc.theWorld.getPlayerEntityByName(args[1]) != null) {
                    Teleport.playername = args[1]
                    Teleport.isTPPlayer = true
                    LiquidBounce.moduleManager[Teleport::class.java]!!.state = true
                    return
                }
            }
            chatSyntax("Teleport <x> <y> <z> or .Teleport <name>")
        }
    }

}