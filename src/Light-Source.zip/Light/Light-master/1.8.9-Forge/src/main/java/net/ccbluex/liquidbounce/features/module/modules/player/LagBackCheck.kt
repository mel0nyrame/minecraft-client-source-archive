package net.ccbluex.liquidbounce.features.module.modules.player

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.ui.client.Notifications
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.minecraft.network.play.server.S08PacketPlayerPosLook
import java.util.*

@ModuleInfo("LagBackCheck", "Check module lagback", ModuleCategory.PLAYER, fakeName = "Lag Back Check")
class LagBackCheck : Module() {
    private val highJumpValue = BoolValue("HighJump", value = true)
    private val longJumpValue = BoolValue("LongJump", value = true)
    private val speedValue = BoolValue("Speed", value = true)
    private val zoomFlyValue = BoolValue("ZoomFly", value = true)
    private val flightValue = BoolValue("Flight", value = true)
    private val tpAuraValue = BoolValue("TPAura", value = true)
    private val autoReEnableValue = BoolValue("AutoRe-Enable", true)
    private val valueList = arrayOf(highJumpValue,longJumpValue,speedValue,zoomFlyValue,flightValue,tpAuraValue)
    @EventTarget
    fun onPacket(event: PacketEvent) {
        if(event.packet is S08PacketPlayerPosLook) {
            for(i in valueList) {
                val module = LiquidBounce.moduleManager.getModule(i.name);
                if(module!!.state) {
                    module.state = false
                    ClientUtils.sendClientMessage(module.name + " LagBack!", Notifications.Type.WARNING)
                    if(!module.name.equals("HighJump", true) && !module.name.equals("LongJump", true) && !module.name.equals("ZoomFly", true) && !module.name.equals("Flight", true) && !module.name.equals("TPAura", true))
                        if(autoReEnableValue.get())
                            Timer().schedule(object : TimerTask() {
                                override fun run() {
                                    ClientUtils.sendClientMessage("Auto Re-Enable ${module.name} After Flag.", Notifications.Type.INFO)
                                    module.state = true
                                }
                            }, 500L)

                }
            }
        }
    }
}