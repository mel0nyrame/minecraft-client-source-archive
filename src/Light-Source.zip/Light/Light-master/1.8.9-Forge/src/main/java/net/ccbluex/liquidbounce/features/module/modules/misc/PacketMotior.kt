package net.ccbluex.liquidbounce.features.module.modules.misc

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.Flight
import net.ccbluex.liquidbounce.features.module.modules.movement.ZoomFly
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.minecraft.network.play.client.C03PacketPlayer

@ModuleInfo(name = "PacketMotior", description = "PacketMotior", category = ModuleCategory.WORLD, fakeName = "Packet Motior")
class PacketMotior : Module() {
    private var ticks = 0
    private var packets = 0
    private var tags = 0

//    override fun getTag(): String {
//        return if (ticks == 20) {
//            "PPS:" + tags.toString()
//        } else {
//            "PPS:" + tags.toString()
//        }
//    }

    override val tag: String
        get() = if(ticks == 20) {
            "PPS:$tags"
        } else {
            "PPS:$tags"
        }

    @EventTarget
    fun onUpdate(e: UpdateEvent) {
        ticks++
        if (ticks == 20) {
            tags = packets
            if (packets > 22) {
                ClientUtils.displayChatMessage("§3[Light]§c Too many packets! Packets:$tag")
            }
            packets = 0
            ticks = 0
        }
    }

    @EventTarget
    fun onPacket(e: PacketEvent) {
        if (e.packet is C03PacketPlayer && !LiquidBounce.moduleManager[Flight::class.java].state) {
            ++packets
        }
    }

    override fun onDisable() {
        packets = 0
        ticks = 0
        tags = 0
    }
}