
package net.ccbluex.liquidbounce.features.module.modules.world

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BlockValue

@ModuleInfo(name = "GhostHand", description = "Allows you to interact with selected blocks through walls.", category = ModuleCategory.WORLD)
class GhostHand : Module() {

    val blockValue = BlockValue("Block", 54)

}
