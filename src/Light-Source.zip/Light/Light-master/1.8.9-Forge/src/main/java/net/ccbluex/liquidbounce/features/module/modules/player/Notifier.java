package net.ccbluex.liquidbounce.features.module.modules.player;
import java.util.ArrayList;

import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.UpdateEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.ClientUtils;
import net.minecraft.entity.player.EntityPlayer;

@ModuleInfo(name="Notifier", description="Found the players.", category=ModuleCategory.WORLD)
public class Notifier
        extends Module {
    private ArrayList<EntityPlayer> lists = new ArrayList<>();
    @Override
    public void onEnable() {
        this.lists.removeAll(lists);
    }
    @Override
    public void onDisable() {
        this.lists.removeAll(lists);
    }

    @EventTarget
    public void onUpdate(UpdateEvent event) {
        for (EntityPlayer o : mc.theWorld.playerEntities) {
            if (o == mc.thePlayer) continue;
            if (!this.lists.contains(o) && (o).getDistanceToEntity(mc.thePlayer) < 100.0f) {
                this.lists.add(o);
                ClientUtils.displayChatMessage(("\u00a77[\u00a79Notifier\u00a77] \u00a79Name: \u00a74" + (o).getName() + " \u00a79Coords \u00a7bX:\u00a7f" + Math.round((o).posX) + "\u00a7bY:\u00a7f" + Math.round((o).posY) + "\u00a7bZ:\u00a7f" + Math.round((o).posZ)));
                continue;
            }
            if (!((o).getDistanceToEntity(mc.thePlayer) > 100.0)) continue;
            this.lists.remove(o);
        }
    }
}
