package net.ccbluex.liquidbounce.features.command.commands

import net.ccbluex.liquidbounce.features.command.Command
import net.minecraft.client.entity.EntityOtherPlayerMP
import net.minecraft.entity.player.EntityPlayerMP

class IPCommand : Command("ip", arrayOf("getIP","playerIP")){
    override fun execute(args: Array<String>) {
        if(args.size > 1) {
            for(i in mc.theWorld.loadedEntityList) {
                if(i.name.equals(args[1], true)) {
                    if(mc.theWorld.getPlayerEntityByName(args[1]) is EntityPlayerMP)
                        super.chat("Entity:${args[1]} | IP: ${(mc.theWorld.getPlayerEntityByName(args[1]) as EntityPlayerMP).playerIP}")
                }
            }
        }
    }
}