package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.render.ColorUtils.rainbow
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.ColorValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.client.renderer.GlStateManager
import net.minecraft.entity.EntityLivingBase
import net.minecraft.util.MathHelper
import java.awt.Color
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

@ModuleInfo(name = "PointerESP", description = "PointerESP", category = ModuleCategory.RENDER, fakeName = "Pointer ESP")
class PointerESP : Module() {
    private val colorValue = ColorValue("Color", 0x6FD8FF)
    private val rainbow = BoolValue("RainBow", false)
    private val bb = BoolValue("Solid", true)
    private val aa = BoolValue("Line", false)
    @EventTarget
    fun onRender2D(e: Render2DEvent) {
        val color2 = colorValue.get()
        val sr = ScaledResolution(mc)
        GlStateManager.pushMatrix()
        val size = 50
        val xOffset = sr.scaledWidth / 2 - 24.5f
        val yOffset = sr.scaledHeight / 2 - 25.2f
        val playerOffsetX = mc.thePlayer.posX.toFloat()
        val playerOffSetZ = mc.thePlayer.posZ.toFloat()
        for (o in mc.theWorld.getLoadedEntityList()) {
            if (o is EntityLivingBase) {
                if (EntityUtils.isSelected(o, false)) {
                    val loaddist = 0.2f
                    val pTicks = mc.timer.renderPartialTicks
                    val posX = ((o.posX + (o.posX - o.lastTickPosX) * pTicks - playerOffsetX)
                            * loaddist).toFloat()
                    val posZ = ((o.posZ + (o.posZ - o.lastTickPosZ) * pTicks - playerOffSetZ)
                            * loaddist).toFloat()
                    val color = if (rainbow.get()) rainbow() else Color(color2)
                    val cos = cos(mc.thePlayer.rotationYaw * (Math.PI * 2 / 360)).toFloat()
                    val sin = sin(mc.thePlayer.rotationYaw * (Math.PI * 2 / 360)).toFloat()
                    val rotY = -(posZ * cos - posX * sin)
                    val rotX = -(posX * cos + posZ * sin)
                    val var7 = 0 - rotX
                    val var9 = 0 - rotY
                    if (MathHelper.sqrt_double(var7 * var7 + var9 * var9.toDouble()) < size / 2 - 4) {
                        val angle = (atan2(rotY - 0.toDouble(), rotX - 0.toDouble()) * 180 / Math.PI).toFloat()
                        val x = (size / 2 * cos(Math.toRadians(angle.toDouble()))).toFloat() + xOffset + size / 2
                        val y = (size / 2 * sin(Math.toRadians(angle.toDouble()))).toFloat() + yOffset + size / 2
                        GlStateManager.pushMatrix()
                        GlStateManager.translate(x, y, 0f)
                        GlStateManager.rotate(angle, 0f, 0f, 1f)
                        GlStateManager.scale(1.5, 1.0, 1.0)
                        if (aa.get()) {
                            RenderUtils.drawESPCircle(0f, 0f, 2.2f, 3f, Color(color2))
                            RenderUtils.drawESPCircle(0f, 0f, 1.5f, 3f, Color(color2))
                            RenderUtils.drawESPCircle(0f, 0f, 1.0f, 3f, Color(color2))
                            RenderUtils.drawESPCircle(0f, 0f, 0.5f, 3f, Color(color2))
                        }
                        if (bb.get()) {
                            RenderUtils.drawESPCircle(0f, 0f, 2.2f, 3f, color)
                            RenderUtils.drawESPCircle(0f, 0f, 1.5f, 3f, color)
                            RenderUtils.drawESPCircle(0f, 0f, 1f, 3f, color)
                            RenderUtils.drawESPCircle(0f, 0f, 0.5f, 3f, color)
                        }
                        GlStateManager.popMatrix()
                    }
                }
            }
        }
        GlStateManager.popMatrix()
    }
}