package net.ccbluex.liquidbounce.features.module.modules.player

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity

@ModuleInfo(name = "LightningDetect", description = "LightningDetect", category = ModuleCategory.PLAYER, fakeName = "Lightning Detect")
class LightningDectet : Module() {
    @EventTarget
    fun onPacket(packetEvent: PacketEvent) {
        if (packetEvent.packet is S2CPacketSpawnGlobalEntity) {
            val packetIn = packetEvent.packet
            if (packetIn.func_149053_g() == 1) {
                val x = packetIn.func_149051_d() / 32
                val y = packetIn.func_149050_e() / 32
                val z = packetIn.func_149049_f() / 32
                ClientUtils.displayChatMessage("\u00a7bDetected Lightning ! \u00a7a X : \u00a77$x \u00a7a, Y : \u00a77$y \u00a7a, Z : \u00a77$z")
            }
        }
    }
}