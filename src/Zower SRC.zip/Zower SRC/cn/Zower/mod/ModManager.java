package cn.Zower.mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import cn.Zower.mod.mods.ClickGui;
import cn.Zower.mod.mods.COMBAT.AntiBot;
import cn.Zower.mod.mods.COMBAT.AutoClicker;
import cn.Zower.mod.mods.COMBAT.AutoHeal;
import cn.Zower.mod.mods.COMBAT.AutoPot;

import cn.Zower.mod.mods.COMBAT.AutoSword;
import cn.Zower.mod.mods.COMBAT.BowAimbot;
import cn.Zower.mod.mods.COMBAT.Criticals;
import cn.Zower.mod.mods.COMBAT.FastBow;
import cn.Zower.mod.mods.COMBAT.Hitbox;
import cn.Zower.mod.mods.COMBAT.KeepSprint;
import cn.Zower.mod.mods.COMBAT.Killaura;
import cn.Zower.mod.mods.COMBAT.Reach;
import cn.Zower.mod.mods.COMBAT.Velocity;
import cn.Zower.mod.mods.MOVEMENT.AntiFall;
import cn.Zower.mod.mods.MOVEMENT.Disabler;
import cn.Zower.mod.mods.MOVEMENT.Fly;
import cn.Zower.mod.mods.MOVEMENT.InvMove;
import cn.Zower.mod.mods.MOVEMENT.Jesus;
import cn.Zower.mod.mods.MOVEMENT.LongJump;
import cn.Zower.mod.mods.MOVEMENT.NoFall;
import cn.Zower.mod.mods.MOVEMENT.NoSlow;
import cn.Zower.mod.mods.MOVEMENT.Safewalk;
import cn.Zower.mod.mods.MOVEMENT.Scaffold;
import cn.Zower.mod.mods.MOVEMENT.Speed;
import cn.Zower.mod.mods.MOVEMENT.Sprint;
import cn.Zower.mod.mods.MOVEMENT.Strafe;
import cn.Zower.mod.mods.MOVEMENT.TargetStrafe;
import cn.Zower.mod.mods.MOVEMENT.ZoomFly;
import cn.Zower.mod.mods.PLAYER.AntiObf;
import cn.Zower.mod.mods.PLAYER.AutoArmor;
import cn.Zower.mod.mods.PLAYER.AutoTool;
import cn.Zower.mod.mods.PLAYER.Blink;
import cn.Zower.mod.mods.PLAYER.Freecam;
import cn.Zower.mod.mods.PLAYER.Fucker;
import cn.Zower.mod.mods.PLAYER.Lobby;
import cn.Zower.mod.mods.PLAYER.NoRotate;
import cn.Zower.mod.mods.PLAYER.Regen;
import cn.Zower.mod.mods.PLAYER.Respawn;
import cn.Zower.mod.mods.PLAYER.Step;
import cn.Zower.mod.mods.PLAYER.Timer;
import cn.Zower.mod.mods.PLAYER.Title;
import cn.Zower.mod.mods.RENDER.Animation;
import cn.Zower.mod.mods.RENDER.BlockESP;
import cn.Zower.mod.mods.RENDER.BlockOverlay;
import cn.Zower.mod.mods.RENDER.Chams;
import cn.Zower.mod.mods.RENDER.ChestESP;
import cn.Zower.mod.mods.RENDER.Crosshair;
import cn.Zower.mod.mods.RENDER.DMGParticle;
import cn.Zower.mod.mods.RENDER.ESP;
import cn.Zower.mod.mods.RENDER.Emote;
import cn.Zower.mod.mods.RENDER.EnchantEffect;
import cn.Zower.mod.mods.RENDER.EveryThingBlock;
import cn.Zower.mod.mods.RENDER.FullBright;
import cn.Zower.mod.mods.RENDER.HUD;
import cn.Zower.mod.mods.RENDER.Health;
import cn.Zower.mod.mods.RENDER.ItemESP;
import cn.Zower.mod.mods.RENDER.ItemPhysic;
import cn.Zower.mod.mods.RENDER.Keyrender;
import cn.Zower.mod.mods.RENDER.NameTag;
import cn.Zower.mod.mods.RENDER.NoFov;
import cn.Zower.mod.mods.RENDER.Projectiles;
import cn.Zower.mod.mods.RENDER.Radar;
import cn.Zower.mod.mods.RENDER.SetScoreboard;
import cn.Zower.mod.mods.RENDER.Skeletal;
import cn.Zower.mod.mods.RENDER.TargetHUD;
import cn.Zower.mod.mods.RENDER.ViewClip;
import cn.Zower.mod.mods.RENDER.Xray;
import cn.Zower.mod.mods.WORLD.AutoL;
import cn.Zower.mod.mods.WORLD.ChestStealer;
import cn.Zower.mod.mods.WORLD.Eagle;
import cn.Zower.mod.mods.WORLD.FastPlace;
import cn.Zower.mod.mods.WORLD.HideAndSeek;
import cn.Zower.mod.mods.WORLD.InvCleaner;
import cn.Zower.mod.mods.WORLD.ModCheck;
import cn.Zower.mod.mods.WORLD.NameProtect;
import cn.Zower.mod.mods.WORLD.NoHurtcam;
import cn.Zower.mod.mods.WORLD.Penshen;
import cn.Zower.mod.mods.WORLD.Phase;
import cn.Zower.mod.mods.WORLD.Spammer;
import cn.Zower.mod.mods.WORLD.SpeedMine;
import cn.Zower.mod.mods.WORLD.Teams;
import cn.Zower.mod.mods.WORLD.TeleportBedFucker;
import cn.Zower.mod.mods.WORLD.Tracers;
import cn.Zower.mod.mods.WORLD.XuanChuan;

public class ModManager {
	public static ArrayList<Mod> modList = new ArrayList();
    public static ArrayList<Mod> sortedModList = new ArrayList();
    public static List<Mod> modules = new ArrayList<Mod>();
    public ModManager() {
    	//NOTHING
    	this.addMod(new ClickGui());
    	
    	//COMBAT
    	this.addMod(new Reach());
    	this.addMod(new Hitbox());
    	this.addMod(new FastBow());
    	this.addMod(new AntiBot());
    	this.addMod(new AutoPot());
    	this.addMod(new AutoHeal());
    	this.addMod(new Killaura());
    	this.addMod(new Velocity());
    	this.addMod(new Criticals());
    	this.addMod(new BowAimbot());
    	this.addMod(new AutoSword());
    	this.addMod(new KeepSprint());
    	this.addMod(new AutoClicker());
    	
    	//MOVEMENT
    	this.addMod(new Fly());
    	this.addMod(new Speed());
    	this.addMod(new Jesus()); 
    	this.addMod(new Strafe());
    	this.addMod(new Disabler());
    	this.addMod(new NoFall());
    	this.addMod(new Sprint());
    	this.addMod(new NoSlow());
    	this.addMod(new Scaffold());
    	this.addMod(new ZoomFly());
    	this.addMod(new InvMove());
    	this.addMod(new AntiFall());
    	this.addMod(new LongJump());
    	this.addMod(new Safewalk());
    	this.addMod(new TargetStrafe());
    	
    	//RENDER
    	this.addMod(new HUD());
    	this.addMod(new ESP());
    	this.addMod(new Emote());
    	this.addMod(new Xray());
    	this.addMod(new Chams());
    	this.addMod(new NoFov());
    	this.addMod(new Radar());  
    	this.addMod(new SetScoreboard());
    	this.addMod(new Health());
    	this.addMod(new ItemESP());
    	this.addMod(new NameTag());
    	this.addMod(new Tracers());
    	this.addMod(new Skeletal());
    	this.addMod(new TeleportBedFucker());
    	this.addMod(new ViewClip());
    	this.addMod(new DMGParticle());
    	this.addMod(new TargetHUD());
    	this.addMod(new BlockESP());
    	this.addMod(new ChestESP()); 
    	this.addMod(new NoHurtcam());
    	this.addMod(new EveryThingBlock());
    	this.addMod(new Animation());
    	this.addMod(new FullBright());
    	this.addMod(new ItemPhysic());
    	this.addMod(new Projectiles());
    	this.addMod(new BlockOverlay());
    	this.addMod(new EnchantEffect());
    	this.addMod(new Keyrender());
    	this.addMod(new Crosshair());
    	
    	//PLAYER
    	this.addMod(new Title());
    	this.addMod(new Step());
     	this.addMod(new Lobby());
    	this.addMod(new Blink());
    	this.addMod(new Timer());
    	this.addMod(new AntiObf());
    	this.addMod(new Regen());
    	this.addMod(new Fucker());
    	this.addMod(new Freecam());
        this.addMod(new Respawn());
    	this.addMod(new AutoTool());
    	this.addMod(new NoRotate());
    	this.addMod(new AutoArmor());

        
        
    	//WORLD
    	this.addMod(new Eagle());
    	this.addMod(new Teams());  	
    	this.addMod(new AutoL());
    	this.addMod(new Phase());
    	this.addMod(new HideAndSeek());
    	this.addMod(new Penshen());
    	this.addMod(new Spammer());
    	this.addMod(new ModCheck());
    	this.addMod(new XuanChuan());
    	this.addMod(new FastPlace());	
    	this.addMod(new SpeedMine());
    	this.addMod(new InvCleaner());
    	this.addMod(new NameProtect());
    	this.addMod(new ChestStealer());

    }
    
    public void addMod(Mod m) {
    	modList.add(m);
    }
    
    public static ArrayList<Mod> getToggled() {
		ArrayList<Mod> toggled = new ArrayList();
		for(Mod m : modList) {
			if(m.isEnabled()) {
				toggled.add(m);
			}
		}
		return toggled;
	}
   

    public static Mod getModuleByClass(Class<? extends Mod> cls) {
        for (Mod m : modList) {
            if (m.getClass() != cls) continue;
            return m;
        }
        return null;
    }
    
    public static Mod getModByName(String mod) {
        for (Mod m : modList) {
            if (!m.getName().equalsIgnoreCase(mod)) continue;
            return m;
        }
        return null;
    }

	public static ArrayList<Mod> getModList() {
		return modList;
	}

	public static List getModsInCategory(Category category) {
	      List modList = new ArrayList();
	      Iterator var3 = ModManager.getModList().iterator();

	      while(var3.hasNext()) {
	         Mod mod = (Mod)var3.next();
	         if (mod.getCategory() == category) {
	            modList.add(mod);
	         }
	      }
	      return modList;
	   }
	public static ArrayList<Mod> getInType(Category type) {
		ArrayList<Mod> typed = new ArrayList();
		for(Mod m : modList) {
			if(m.getCategory() == type) {
				typed.add(m);
			}
		}
		return typed;
	}
    
}
