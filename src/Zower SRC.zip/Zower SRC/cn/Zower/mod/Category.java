package cn.Zower.mod;

public enum Category {
	
	COMBAT,RENDER,MOVEMENT,PLAYER,WORLD;
	
}

