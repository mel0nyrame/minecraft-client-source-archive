package cn.Zower.mod.mods.COMBAT;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.darkmagician6.eventapi.EventTarget;

import cn.Zower.Value;
import cn.Zower.events.EventPacket;
import cn.Zower.events.EventUpdate;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;
import cn.Zower.mod.ModManager;
import cn.Zower.util.PlayerUtil;
import cn.Zower.util.timeUtils.TimeHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.S14PacketEntity;
import net.minecraft.potion.PotionEffect;

    public class AntiBot extends Mod {
       private static Value mode = new Value("AntiBot", "Mode", 0);
       private TimeHelper timer = new TimeHelper();
       public static List invalid = new ArrayList();
       private static List whitelist = new ArrayList();
       private static List hurtTimeCheck = new ArrayList();
       private static List playerList = new ArrayList();
       public Value remove = new Value("AntiBot_Remove", Boolean.valueOf(true));
       public static Value hurttime = new Value("AntiBot_HTimeCheckTime", Double.valueOf(10000.0D), Double.valueOf(5000.0D), Double.valueOf(20000.0D), 100.0D);
       public static Value touchedGround = new Value("AntiBot_Ground", Boolean.valueOf(true));
       public static Value toolCheck = new Value("AntiBot_ToolCheck", Boolean.valueOf(true));
       public static ArrayList bots = new ArrayList();
       private static ArrayList playersInGame = new ArrayList();
       private static List removed = new ArrayList();
       public TimeHelper lastRemoved = new TimeHelper();
       public TimeHelper timer2 = new TimeHelper();
       public TimeHelper timer3 = new TimeHelper();
       public static List onAirInvalid = new ArrayList();

       public AntiBot() {
          super("AntiBot", Category.COMBAT);
          mode.addValue("Hypixel");
          mode.addValue("Name");
          mode.addValue("Mineplex");
          mode.addValue("HuaYuTing");
       }

       public static List getTabPlayerList() {
          new GuiPlayerTabOverlay(Minecraft.getMinecraft(), Minecraft.getMinecraft().ingameGUI);
          return GuiPlayerTabOverlay.getPlayerList();
       }

       @EventTarget
       public void onUpdate(EventUpdate e) {
          Minecraft var10000;
          if(mode.isCurrentMode("Hypixel")) {
             var10000 = mc;
             Iterator var3 = Minecraft.theWorld.playerEntities.iterator();

             Minecraft var10001;
             while(var3.hasNext()) {
                EntityPlayer o = (EntityPlayer)var3.next();
                var10001 = mc;
                if(o != Minecraft.thePlayer && o != null && o instanceof EntityLivingBase) {
                   var10001 = mc;
                   if(o != Minecraft.thePlayer && o instanceof EntityPlayer && !isInTablist(o) && !o.getDisplayName().getFormattedText().toLowerCase().contains("[npc") && o.getDisplayName().getFormattedText().startsWith("��")) {
                      var10000 = mc;
                      Minecraft.theWorld.removeEntity(o);
                   }
                }
             }

             if(((Boolean)this.remove.getValueState()).booleanValue() && !removed.isEmpty() && this.lastRemoved.isDelayComplete(1000L)) {
                PlayerUtil.tellPlayer("��b[AzureWare]��Removed" + removed.size() + "Bots");
                this.lastRemoved.reset();
                removed.clear();
             }

             if(!hurtTimeCheck.isEmpty() && this.timer3.isDelayComplete(((Double)hurttime.getValueState()).longValue())) {
                hurtTimeCheck.clear();
                this.timer3.reset();
             }

             if(!whitelist.isEmpty() && this.timer2.isDelayComplete(3000L)) {
                whitelist.clear();
                this.timer2.reset();
             }

             if(!invalid.isEmpty() && this.timer.isDelayComplete(1000L)) {
                invalid.clear();
                this.timer.reset();
             }

             var10000 = mc;
             var3 = Minecraft.theWorld.getLoadedEntityList().iterator();

             while(var3.hasNext()) {
                Object o1 = var3.next();
                if(o1 instanceof EntityPlayer) {
                   EntityPlayer ent = (EntityPlayer)o1;
                   var10001 = mc;
                   if(ent != Minecraft.thePlayer && !invalid.contains(ent)) {
                      String formated = ent.getDisplayName().getFormattedText();
                      String custom = ent.getCustomNameTag();
                      String name = ent.getName();
                      if(ent.isInvisible() && !formated.startsWith("��c") && formated.endsWith("��r") && custom.equals(name)) {
                         var10001 = mc;
                         double diffX = Math.abs(ent.posX - Minecraft.thePlayer.posX);
                         var10001 = mc;
                         double diffY = Math.abs(ent.posY - Minecraft.thePlayer.posY);
                         var10001 = mc;
                         double diffZ = Math.abs(ent.posZ - Minecraft.thePlayer.posZ);
                         double diffH = Math.sqrt(diffX * diffX + diffZ * diffZ);
                         if(diffY < 13.0D && diffY > 10.0D && diffH < 3.0D) {
                            List list = getTabPlayerList();
                            if(!list.contains(ent)) {
                               if(((Boolean)this.remove.getValueState()).booleanValue()) {
                                  this.lastRemoved.reset();
                                  removed.add(ent);
                                  var10000 = mc;
                                  Minecraft.theWorld.removeEntity(ent);
                               }

                               invalid.add(ent);
                            }
                         }
                      }

                      if(!formated.startsWith("��") && formated.endsWith("��r")) {
                         invalid.add(ent);
                      }

                      if(!isInTablist(ent)) {
                         invalid.add(ent);
                      }

                      if(ent.hurtTime > 0) {
                         hurtTimeCheck.add(ent);
                      }

                      if(hurtTimeCheck.contains(ent) && !whitelist.contains(ent)) {
                         whitelist.add(ent);
                      }

                      if(ent.getHeldItem() != null) {
                         whitelist.add(ent);
                      }

                      if(ent.getHeldItem() == null && !whitelist.contains(ent) && ((Boolean)toolCheck.getValueState()).booleanValue()) {
                         invalid.add(ent);
                      }

                      if(ent.isInvisible() && !custom.equalsIgnoreCase("") && custom.toLowerCase().contains("��c��c") && name.contains("��c")) {
                         if(((Boolean)this.remove.getValueState()).booleanValue()) {
                            this.lastRemoved.reset();
                            removed.add(ent);
                            var10000 = mc;
                            Minecraft.theWorld.removeEntity(ent);
                         }

                         invalid.add(ent);
                      }

                      if(!custom.equalsIgnoreCase("") && custom.toLowerCase().contains("��c") && custom.toLowerCase().contains("��r")) {
                         if(((Boolean)this.remove.getValueState()).booleanValue()) {
                            this.lastRemoved.reset();
                            removed.add(ent);
                            var10000 = mc;
                            Minecraft.theWorld.removeEntity(ent);
                         }

                         invalid.add(ent);
                      }

                      if(formated.contains("��8[NPC]")) {
                         invalid.add(ent);
                      }

                      if(!formated.contains("��c") && !custom.equalsIgnoreCase("")) {
                         invalid.add(ent);
                      }
                   }
                }
             }

             this.setDisplayName("Hypixel");
          }

          if(mode.isCurrentMode("Name")) {
             this.setDisplayName("Debug");
             var10000 = mc;
             Minecraft.theWorld.playerEntities.forEach((entity) -> {
                Minecraft var10001 = mc;
                if(entity != Minecraft.thePlayer && isBot(entity)) {
                   invalid.add(entity);
                }

             });
          }

          if(mode.isCurrentMode("Mineplex")) {
             this.setDisplayName("Mineplex");
          }

          if(mode.isCurrentMode("HuaYuTing")) {
             this.setDisplayName("HuaYuTing");
          }

       }

       public void onEnable() {
          onAirInvalid.clear();
          super.onEnable();
       }

       public void onDisable() {
          onAirInvalid.clear();
          super.onDisable();
       }

       @EventTarget
       public void onReceivePacket(EventPacket event) {
          if(event.getPacket() instanceof S14PacketEntity) {
             S14PacketEntity packet = (S14PacketEntity)event.getPacket();
             Minecraft var10001 = mc;
             Entity entity;
             if((entity = packet.getEntity(Minecraft.theWorld)) instanceof EntityPlayer && !packet.getOnGround() && !onAirInvalid.contains(Integer.valueOf(entity.getEntityId()))) {
                onAirInvalid.add(Integer.valueOf(entity.getEntityId()));
             }
          }

       }

       public static boolean isInTablist(EntityPlayer player) {
          if(Minecraft.getMinecraft().isSingleplayer()) {
             return true;
          } else {
             Minecraft.getMinecraft();
             Iterator var2 = Minecraft.getNetHandler().getPlayerInfoMap().iterator();

             while(var2.hasNext()) {
                Object o = var2.next();
                NetworkPlayerInfo playerInfo = (NetworkPlayerInfo)o;
                if(playerInfo.getGameProfile().getName().equalsIgnoreCase(player.getName())) {
                   return true;
                }
             }

             return false;
          }
       }

       public static boolean isBot(Entity entity) {
           if (ModManager.getModByName("AntiBot").isEnabled() && mode.isCurrentMode("Hypixel")) {
               if (entity.getDisplayName().getFormattedText().startsWith("\u00a7") && !entity.getDisplayName().getFormattedText().toLowerCase().contains("[npc]")) {
                   return false;
               }
               return true;
           }
           return false;
       }
   }


