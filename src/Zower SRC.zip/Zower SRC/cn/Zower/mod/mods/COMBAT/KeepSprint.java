package cn.Zower.mod.mods.COMBAT;

import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;

public class KeepSprint extends Mod {

	public KeepSprint() {
		super("KeepSprint", Category.COMBAT);
	}

}
