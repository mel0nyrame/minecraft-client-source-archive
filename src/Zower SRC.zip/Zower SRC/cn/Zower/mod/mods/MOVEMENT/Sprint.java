package cn.Zower.mod.mods.MOVEMENT;

import com.darkmagician6.eventapi.EventTarget;

import cn.Zower.Value;
import cn.Zower.events.EventUpdate;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;

public class Sprint extends Mod {
	
	public Value<Boolean> omni = new Value("Sprint_Omni", false);
	
	public Sprint() {
		super("Sprint", Category.MOVEMENT);
	}
	
	@EventTarget
	public void onUpdate(EventUpdate event) {
		if (this.mc.thePlayer.getFoodStats().getFoodLevel() > 6 && this.omni.getValueState().booleanValue() != false ? this.mc.thePlayer.moving() : this.mc.thePlayer.moveForward > 0.0f) {
		 this.mc.thePlayer.setSprinting(true);
		}
	}
	
	@Override
	public void onDisable() {
		mc.thePlayer.setSprinting(false);
		super.onDisable();
	}
}
