
package cn.Zower.mod.mods.MOVEMENT;


import java.awt.Color;
import java.util.Random;

import com.darkmagician6.eventapi.EventTarget;
import com.ibm.icu.text.Normalizer.Mode;

import cn.Zower.Value;
import cn.Zower.events.EventPostMotion;
import cn.Zower.events.EventPreMotion;
import cn.Zower.events.EventPreUpdate;
import cn.Zower.events.EventRender2D;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;

import cn.Zower.ui.font.FontLoaders;
import cn.Zower.util.Helper;
import cn.Zower.util.MoveUtils;
import cn.Zower.util.PlayerUtil;
import cn.Zower.util.RotationUtil;
import cn.Zower.util.RotationUtils;
import cn.Zower.util.timeUtils.TimeHelper;
import ibxm.Module;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSnow;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class Scaffold
        extends Mod {
	Value<String> mode = new Value<String>("Scaffold", "Mode", 0);

  public static Value<Boolean> tower = new Value("Scaffold_tower", Boolean.valueOf(true));
	 public static Value<Boolean> towermove = new Value("Scaffold_BetterTower", Boolean.valueOf(false));
	   private final Value safeWalkValue = new Value("Scaffold_SafeWalk", Boolean.valueOf(true));
	   private final Value swingValue = new Value("Scaffold_Swing", Boolean.valueOf(true));
    BlockData blockData;
    int blockSlot;
    boolean isSneaking;
    TimeHelper towerTimer = new TimeHelper();
    private int delay;

    public Scaffold() {
        super("Scaffold", Category.COMBAT);
        mode.addValue("Hypixel");
        mode.addValue("HypixelGlobal");
    }
    public void onEnable() {
        if(Helper.onServer("hypixel.net")){
            if(mode.isCurrentMode("Hypixel")){
                Helper.sendMessageWithoutPrefix("§4[Warnning]Hypixel Mode can't bypass HypixelGlobal");
            }
          
        }else if(Helper.onServer("59.111.137.84")&&Helper.onServer("x19hypixel.net.netease.com")){
            if(mode.isCurrentMode("HypixelGlobal")){
                Helper.sendMessageWithoutPrefix("§4[Warnning]Hypixel Mode can't bypass HypixelNetease");
            }
        }
        super.onEnable();
    }

    public void swap(int slot1, int hotbarSlot){
        mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot1, hotbarSlot, 2, mc.thePlayer);
    }
    @EventTarget
    public void onRender2D(EventRender2D event) {
        ScaledResolution sr = new ScaledResolution(mc);
        String Info = (Object)EnumChatFormatting.WHITE + " block";
        FontLoaders.kiona18.drawStringWithShadow(String.valueOf((Object)Integer.toString((int)this.getBlocksAmount())) + Info, (double)(sr.getScaledWidth() / 2 + 1 - Minecraft.fontRendererObj.getStringWidth(Integer.toString((int)this.getBlocksAmount())) / 2), (double)(sr.getScaledHeight() / 2 + 12), this.getBlockColor(this.getBlocksAmount()));
    }

    private int getBlockColor(int count) {
        float f = count;
        float f1 = 64.0f;
        float f2 = Math.max((float)0.0f, (float)(Math.min((float)f, (float)f1) / f1));
        return Color.HSBtoRGB((float)(f2 / 3.0f), (float)1.0f, (float)1.0f) | -16777216;
    }
    private int getBlocksAmount() {
        int amount = 0;

        for(int i = 0; i < 45; i++) {
            final ItemStack itemStack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();

            if(itemStack != null && itemStack.getItem() instanceof ItemBlock&&isuseful(itemStack))
                amount += itemStack.stackSize;
        }

        return amount;
    }

    
    @EventTarget
    public void onPreMotion(EventPreMotion e) {
        if (getBlockSlot() == -1) {
            for (int i = 9; i < 45; i++) {
                if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                    ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                    if (is.getItem() instanceof ItemBlock && isuseful(is)) {
                        swap(i, 8);
                    }
                }
            }
            return;
        }
       
        if (this.tower.getValueState() && !PlayerUtil.isMoving2()) {
    		tower();
    	
    	
    } 
       
        this.blockSlot = getBlockSlot();

        BlockPos tempPos = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1.0D - (this.isSneaking ? 0.01D : 0.0D), mc.thePlayer.posZ);
        this.blockData = getBlockData(tempPos);
        float[] rotate = RotationUtils.getRotationFromPosition(this.blockData.pos.getX(), this.blockData.pos.getZ(),
                this.blockData.pos.getY());
        if (mode.isCurrentMode("Hypixel")) {
            e.pitch = 80 + (int) Math.random();
            //e.yaw = rotate[0];
            //e.pitch = rotate[1];
        } else if (mode.isCurrentMode("HypixelGlobal")) {
            e.pitch = 80 + (int) Math.random();
        }
        mc.thePlayer.rotationYawHead = e.yaw;

    }

    public boolean isuseful(ItemStack is) {
        ItemBlock Blockitem;
        if(is.getItem() instanceof ItemBlock){
            Blockitem = (ItemBlock)is.getItem();
        }else{
            return false;
        }
        Block block = Blockitem.getBlock();
        if(block.isFullCube() && !InvUtils.BLOCK_BLACKLIST.contains(block)){
            return true;
        }

        return false;
    }


    @EventTarget
    public void onPostMotion(EventPostMotion e) {
        if(getBlocksAmount()<=0){
            return;
        }


      
            delay = 0;
        


		Vec3 Power = getVec3(blockData.pos, blockData.face);
        if (this.blockData != null && isuseful(mc.thePlayer.inventory.getStackInSlot(this.blockSlot))) {
            mc.thePlayer.sendQueue.addToSendQueue((Packet) new C09PacketHeldItemChange(this.blockSlot));
            if (mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld,
                    mc.thePlayer.inventory.getStackInSlot(this.blockSlot), this.blockData.pos, this.blockData.face,
                    Power) ) {
                if(PlayerUtil.isOnGround(0.1)) {
                   // mc.thePlayer.motionY=0;
                }
                if(mc.thePlayer.onGround) {
                  //  mc.thePlayer.jump();
                }

            }

           mc.thePlayer.sendQueue.addToSendQueue((Packet) new C0APacketAnimation());
            mc.thePlayer.sendQueue.addToSendQueue((Packet) new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));

        }

           if(((Boolean)this.swingValue.getValueState()).booleanValue()) {

              Minecraft.thePlayer.swingItem();
           } else {

              Minecraft.getNetHandler().addToSendQueue(new C0APacketAnimation());
           }
  
  }

    
    
    public void tower() {
    	// TODO 锟皆讹拷锟斤拷锟缴的凤拷锟斤拷锟斤拷锟�
        BlockPos underPos = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ);
        Block underBlock = mc.theWorld.getBlockState(underPos).getBlock();
        BlockData data = getBlockData(underPos);
        if(!mc.gameSettings.keyBindJump.isKeyDown()){
        	if((this.towermove.getValueState() && PlayerUtil.isMoving2())){
        		if (MoveUtils.isOnGround(0.76) && !MoveUtils.isOnGround(0.75) && mc.thePlayer.motionY > 0.23 && mc.thePlayer.motionY < 0.25) {
                    mc.thePlayer.motionY = (Math.round(mc.thePlayer.posY) - mc.thePlayer.posY);
                }
                if (MoveUtils.isOnGround(0.0001)) {   

                }else if(mc.thePlayer.motionY > 0.1 && mc.thePlayer.posY >= Math.round(mc.thePlayer.posY) - 0.0001 && mc.thePlayer.posY <= Math.round(mc.thePlayer.posY) + 0.0001){
                   
                	mc.thePlayer.motionY = 0;
                }
        	}
        	return;
        }
    	if(PlayerUtil.isMoving2()){
            if (MoveUtils.isOnGround(0.76) && !MoveUtils.isOnGround(0.75) && mc.thePlayer.motionY > 0.23 && mc.thePlayer.motionY < 0.25) {
                mc.thePlayer.motionY = (Math.round(mc.thePlayer.posY) - mc.thePlayer.posY);
            }
            if (MoveUtils.isOnGround(0.0001)) {            	
                mc.thePlayer.motionY = 0.42;
                mc.thePlayer.motionX *= 0.9;
                mc.thePlayer.motionZ *= 0.9;          	
            }else if(mc.thePlayer.posY >= Math.round(mc.thePlayer.posY) - 0.0001 && mc.thePlayer.posY <= Math.round(mc.thePlayer.posY) + 0.0001){
                mc.thePlayer.motionY = 0;
            }
    	}else{
    		mc.thePlayer.motionX = 0;
    		mc.thePlayer.motionZ = 0;
    		mc.thePlayer.jumpMovementFactor = 0;
    		if (isAirBlock(underBlock) && data != null) {
                mc.thePlayer.motionY = 0.4196;
                mc.thePlayer.motionX *= 0.75;
                mc.thePlayer.motionZ *= 0.75;
            }
    	}
    }
    public boolean isAirBlock(Block block) {
        if (block.getMaterial().isReplaceable()) {
            if (block instanceof BlockSnow && block.getBlockBoundsMaxY() > 0.125) {
                return false;
            }
            return true;
        }

        return false;
    }
    public float[] getRotationFromPosition(double x, double y, double z, EnumFacing face) {
        double xDiff = x - mc.thePlayer.posX + (face.getFrontOffsetX() / 2) + 0.5D;
        double zDiff = z - mc.thePlayer.posZ + (face.getFrontOffsetZ() / 2) + 0.5D;
        double yDiff = y - mc.thePlayer.posY + 0.5D;
        double yPlayer = mc.thePlayer.posY + mc.thePlayer.getEyeHeight() - yDiff;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float) (Math.atan2(zDiff, xDiff) * 180.0D / 3.14D) - 90.0F;
        float pitch = (float) (-Math.atan2(yPlayer, dist) * 180.0D / 3.14D);
        if (yaw < 0.0F)
            yaw += 360.0F;
        return new float[]
                {
                        yaw, pitch
                };

    }


    public int getBlockSlot() {
        for (int i = 0; i < 9; i++) {
            Slot slot = mc.thePlayer.inventoryContainer.getSlot(i + 36);
            if (slot.getHasStack() && slot.getStack().getItem() instanceof net.minecraft.item.ItemBlock&&isuseful(slot.getStack())) {
                return i;

            }

        }
        if (mc.thePlayer != null)
            if (mc.theWorld != null) {
                return -1;
            }

        return -1;

    }

    public Vec3 getVec3ByBlockData(BlockData data) {
        /* 135 */
        EnumFacing face = data.face;
        /* 136 */
        BlockPos pos = data.pos;
        /* 137 */
        Random rand = new Random();

        Boolean isKeepY = Boolean.valueOf(!(face != EnumFacing.UP && face != EnumFacing.DOWN));
        Boolean isKeepXY = Boolean.valueOf(!(face != EnumFacing.WEST && face != EnumFacing.EAST));
        Boolean isKeepYZ = Boolean.valueOf(!(face != EnumFacing.SOUTH && face != EnumFacing.NORTH));

        double x = pos.getX() + 0.5D + (face.getFrontOffsetX() / 2) + (isKeepY.booleanValue() ? (rand.nextDouble() * 0.6D - 0.3D) : 0.0D) + (isKeepYZ.booleanValue() ? (rand.nextDouble() * 0.6D - 0.3D) : 0.0D);
        double y = pos.getY() + 0.5D + (face.getFrontOffsetY() / 2) + (isKeepY.booleanValue() ? 0.0D : (rand.nextDouble() * 0.6D - 0.3D));
        double z = pos.getZ() + 0.5D + (face.getFrontOffsetZ() / 2) + (isKeepY.booleanValue() ? (rand.nextDouble() * 0.6D - 0.3D) : 0.0D) + (isKeepXY.booleanValue() ? (rand.nextDouble() * 0.6D - 0.3D) : 0.0D);
        return new Vec3(x, y, z);

    }
    public static Vec3 getVec3(BlockPos pos, EnumFacing face) {
        double x = pos.getX() + 0.5;
        double y = pos.getY() + 0.5;
        double z = pos.getZ() + 0.5;
        x += (double) face.getFrontOffsetX() / 2;
        z += (double) face.getFrontOffsetZ() / 2;
        y += (double) face.getFrontOffsetY() / 2;
        if (face == EnumFacing.UP || face == EnumFacing.DOWN) {
            x += randomNumber(0.3, -0.3);
            z += randomNumber(0.3, -0.3);
        } else {
            y += randomNumber(0.3, -0.3);
        }
        if (face == EnumFacing.WEST || face == EnumFacing.EAST) {
            z += randomNumber(0.3, -0.3);
        }
        if (face == EnumFacing.SOUTH || face == EnumFacing.NORTH) {
            x += randomNumber(0.3, -0.3);
        }
        return new Vec3(x, y, z);
    }
	
    
    public static double randomNumber(double max, double min) {
        return (Math.random() * (max - min)) + min;
    }
	
    public BlockData getBlockData(BlockPos pos) {
        BlockData tempData = null;
        int times = 0;
        while (tempData == null &&
                times < 2) {

            if (!isBlockPosAir(pos.add(0, 0, 1))) {
                tempData = new BlockData(pos.add(0, 0, 1), EnumFacing.NORTH);
                break;

            }
            if (!isBlockPosAir(pos.add(0, 0, -1))) {
                tempData = new BlockData(pos.add(0, 0, -1), EnumFacing.SOUTH);
                break;

            }
            if (!isBlockPosAir(pos.add(1, 0, 0))) {
                tempData = new BlockData(pos.add(1, 0, 0), EnumFacing.WEST);
                break;

            }
            if (!isBlockPosAir(pos.add(-1, 0, 0))) {
                tempData = new BlockData(pos.add(-1, 0, 0), EnumFacing.EAST);
                break;

            }
            if (!isBlockPosAir(pos.add(0, -1, 0))) {
                tempData = new BlockData(pos.add(0, -1, 0), EnumFacing.UP);
                break;

            }
            if (!isBlockPosAir(pos.add(0, 1, 0)) && this.isSneaking) {
                tempData = new BlockData(pos.add(0, 1, 0), EnumFacing.DOWN);
                break;

            }
            if (!isBlockPosAir(pos.add(0, 1, 1)) && this.isSneaking) {
                tempData = new BlockData(pos.add(0, 1, 1), EnumFacing.DOWN);
                break;

            }
            if (!isBlockPosAir(pos.add(0, 1, -1)) && this.isSneaking) {
                tempData = new BlockData(pos.add(0, 1, -1), EnumFacing.DOWN);
                break;

            }
            if (!isBlockPosAir(pos.add(1, 1, 0)) && this.isSneaking) {
                tempData = new BlockData(pos.add(1, 1, 0), EnumFacing.DOWN);
                break;

            }
            if (!isBlockPosAir(pos.add(-1, 1, 0)) && this.isSneaking) {
                tempData = new BlockData(pos.add(-1, 1, 0), EnumFacing.DOWN);
                break;

            }
            if (!isBlockPosAir(pos.add(1, 0, 1))) {
                tempData = new BlockData(pos.add(1, 0, 1), EnumFacing.NORTH);
                break;

            }
            if (!isBlockPosAir(pos.add(-1, 0, -1))) {
                tempData = new BlockData(pos.add(-1, 0, -1), EnumFacing.SOUTH);
                break;

            }
            if (!isBlockPosAir(pos.add(1, 0, 1))) {
                tempData = new BlockData(pos.add(1, 0, 1), EnumFacing.WEST);
                break;

            }
            if (!isBlockPosAir(pos.add(-1, 0, -1))) {
                tempData = new BlockData(pos.add(-1, 0, -1), EnumFacing.EAST);
                break;

            }
            /* 200 */
            if (!isBlockPosAir(pos.add(-1, 0, 1))) {
                /* 201 */
                tempData = new BlockData(pos.add(-1, 0, 1), EnumFacing.NORTH);
                break;

            }
            /* 203 */
            if (!isBlockPosAir(pos.add(1, 0, -1))) {
                /* 204 */
                tempData = new BlockData(pos.add(1, 0, -1), EnumFacing.SOUTH);
                break;

            }
            /* 206 */
            if (!isBlockPosAir(pos.add(1, 0, -1))) {
                /* 207 */
                tempData = new BlockData(pos.add(1, 0, -1), EnumFacing.WEST);
                break;

            }
            /* 209 */
            if (!isBlockPosAir(pos.add(-1, 0, 1))) {
                /* 210 */
                tempData = new BlockData(pos.add(-1, 0, 1), EnumFacing.EAST);

                break;

            }
            /* 213 */
            pos = pos.down();
            /* 214 */
            times++;

        }
        /* 216 */
        return tempData;

    }


    public boolean isBlockPosAir(BlockPos pos) {
        /* 220 */
        if (getBlockByPos(pos) == Blocks.air) {
            /* 221 */
            return true;

        }
        /* 223 */
        return false;

    }


    /* 227 */
    public Block getBlockByPos(BlockPos pos) {
        return mc.theWorld.getBlockState(pos).getBlock();
    }

}