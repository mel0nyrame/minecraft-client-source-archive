/*
 * Decompiled with CFR 0.149.
 */
package cn.Zower.mod.mods.MOVEMENT;

import java.util.ArrayList;
import java.util.List;

import com.darkmagician6.eventapi.EventTarget;

import cn.Zower.Value;
import cn.Zower.events.EventPacket;
import cn.Zower.events.EventPacket2;
import cn.Zower.events.EventPreMotion;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;
import net.minecraft.client.Minecraft;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.MovementInput;

public class Disabler
extends Mod {
    private boolean laggedback;
    private boolean felldown;
    private float[] lastrot = new float[2];
    int lastKey;
    boolean startBlink = false;
    private List<Packet> packets = new ArrayList<Packet>();
    private final Value<Boolean> Flight = new Value<Boolean>("Disabler_Flight", true);
    public static Value<Double> SpeedValue = new Value<Double>("Disabler_Speed", 1.0, 1.0, 5.0, 0.25);

    public Disabler() {
        super("Disabler", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        if (Minecraft.theWorld == null) {
            return;
        }
        if (Minecraft.thePlayer != null) {
            this.laggedback = false;
            this.felldown = false;
            this.startBlink = false;
            this.lastrot[0] = Minecraft.thePlayer.rotationYaw;
            this.lastrot[1] = Minecraft.thePlayer.rotationPitch;
            if (Minecraft.thePlayer.onGround) {
                Minecraft.thePlayer.jump();
            }
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        NetworkManager var1 = Minecraft.thePlayer.sendQueue.getNetworkManager();
        if (Minecraft.theWorld != null) {
            for (Packet packet : this.packets) {
                var1.sendPacketNoEvent(packet);
            }
        }
        this.packets.clear();
        this.startBlink = false;
        if (Minecraft.thePlayer != null) {
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
        }
        super.onDisable();
    }

    @EventTarget
    public void onEvent(EventPreMotion event) {
        if (this.felldown) {
            Minecraft.thePlayer.motionY = 0.0;
            if (this.laggedback) {
                if (Minecraft.thePlayer.movementInput.jump) {
                    Minecraft.thePlayer.motionY = 2.0;
                } else if (Minecraft.thePlayer.movementInput.sneak) {
                    Minecraft.thePlayer.motionY = -2.0;
                }
                this.setMoveSpeed(SpeedValue.getValueState());
            } else {
                Minecraft.thePlayer.rotationYaw = this.lastrot[0];
                Minecraft.thePlayer.rotationPitch = this.lastrot[1];
                Minecraft.thePlayer.motionX = 0.0;
                Minecraft.thePlayer.motionZ = 0.0;
            }
        } else if ((double)Minecraft.thePlayer.fallDistance > 0.0) {
            this.felldown = true;
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
        }
    }

    @EventTarget
    public void onPacket(EventPacket2 event) {
        if (event.getType() == EventPacket2.EventPacketType.RECEIVE) {
            if (this.felldown && !mc.isSingleplayer()) {
                if (Minecraft.theWorld != null && event.getPacket() instanceof S08PacketPlayerPosLook) {
                    S08PacketPlayerPosLook packet = (S08PacketPlayerPosLook)event.getPacket();
                    if (Minecraft.thePlayer.posY > packet.getY()) {
                        if (!this.Flight.getValueState().booleanValue()) {
                            this.set(false);
                            return;
                        }
                        this.laggedback = true;
                        this.startBlink = true;
                    }
                }
            }
        } else if (event.getType() == EventPacket2.EventPacketType.SEND) {
            Packet packet = event.getPacket();
            if (this.startBlink) {
                if (packet instanceof C03PacketPlayer) {
                    ((C03PacketPlayer)packet).onGround = true;
                }
                if (packet instanceof C03PacketPlayer.C04PacketPlayerPosition || packet instanceof C03PacketPlayer.C06PacketPlayerPosLook || packet instanceof C08PacketPlayerBlockPlacement || packet instanceof C0APacketAnimation || packet instanceof C0BPacketEntityAction || packet instanceof C02PacketUseEntity) {
                    this.packets.add(packet);
                    event.setSendcancel(true);
                }
            }
        }
    }

    private void setMoveSpeed(double speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            Minecraft.thePlayer.motionX = forward * speed * -Math.sin(Math.toRadians(yaw)) + strafe * speed * Math.cos(Math.toRadians(yaw));
            Minecraft.thePlayer.motionZ = forward * speed * Math.cos(Math.toRadians(yaw)) - strafe * speed * -Math.sin(Math.toRadians(yaw));
        }
    }
}

