/*     */ package cn.Zower.mod.mods.MOVEMENT;
/*     */
/*     */ import net.minecraft.util.BlockPos;
/*     */ import net.minecraft.util.EnumFacing;
/*     */ public class BlockData
        /*     */ {
    /*     */   public static BlockPos pos;
    /*     */   public static EnumFacing face;
    /*     */
    /*     */   public BlockData(BlockPos pos, EnumFacing face) {
        /* 237 */     this.pos = pos;
        /* 238 */     this.face = face;
        /*     */   }
    /*     */
    /*     */
    /*     */
    /* 243 */   public String toString() { return "Pos:" + this.pos.getX() + ", " + this.pos.getY() + ", " + this.pos.getZ() + ". Face:" + this.face; }
    /*     */ }


/* Location:              G:\��ʷ����\AzureWare.jar!\net\AzureWare\mod\mods\WORLD\BlockData.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.2
 */