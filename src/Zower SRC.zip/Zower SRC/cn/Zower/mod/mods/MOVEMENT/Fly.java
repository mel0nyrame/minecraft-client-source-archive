package cn.Zower.mod.mods.MOVEMENT;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import com.darkmagician6.eventapi.EventTarget;

import cn.Zower.Value;
import cn.Zower.events.EventAttack.EventPacketType;
import cn.Zower.events.EventMove;
import cn.Zower.events.EventPacket;
import cn.Zower.events.EventPacket2;
import cn.Zower.events.EventPreMotion;
import cn.Zower.events.EventPullback;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;
import cn.Zower.ui.ClientNotification.Type;
import cn.Zower.util.ClientUtil;
import cn.Zower.util.PlayerUtil;
import cn.Zower.util.timeUtils.TimeHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition;
import net.minecraft.network.play.client.C03PacketPlayer.C06PacketPlayerPosLook;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovementInput;
import net.minecraft.util.Timer;

public class Fly extends Mod {
   public static Value mode = new Value("Fly", "Mode", 0);
   public static Value MotionSpeed = new Value("Fly_MotionSpeed", Double.valueOf(1.0D), Double.valueOf(1.0D), Double.valueOf(10.0D), 0.25D);
   public static Value damage = new Value("Fly_Damage", Boolean.valueOf(true));
   public static Value uhc = new Value("Fly_uhc", Boolean.valueOf(true));
   public static Value lagback = new Value("Fly_LagBackChecks", Boolean.valueOf(true));
   private Value Watting = new Value("Fly_Waitting", Boolean.valueOf(false));
   private static Value WattingTime = new Value("Fly_WaittingTime", Double.valueOf(2.1D), Double.valueOf(1.0D), Double.valueOf(5.0D), 0.1D);
   private static Value zoomboost = new Value("Fly_BoostTime", Double.valueOf(5.0D), Double.valueOf(0.0D), Double.valueOf(20.0D), 0.1D);
   private static Value timerboost = new Value("Fly_timerboost", Double.valueOf(0.0D), Double.valueOf(0.0D), Double.valueOf(5.0D), 0.1D);
   private static Value groundboost = new Value("Fly_Boost", Double.valueOf(2.1D), Double.valueOf(1.0D), Double.valueOf(5.0D), 0.1D);
   TimeHelper BoostTimer = new TimeHelper();
   TimeHelper SlowTimer = new TimeHelper();
   private int FlyCounter;
   private int zoom;
   double moveSpeed;
   private boolean failedStart;
   private double lastDistance;
   private int boostHypixelState;
   boolean hurtted = false;
   private ArrayList packets = new ArrayList();

   public Fly() {
      super("Fly", Category.MOVEMENT);
      mode.addValue("Hypixel");
      mode.addValue("HypixelZoom");
      mode.addValue("NewMotion");
      mode.addValue("Motion");
   }

   @EventTarget
   public void onMove(EventMove event) {
      if(this.mode.isCurrentMode("Hypixel")) {
         PlayerUtil.setMotion(event, this.getBaseMoveSpeed());
      }

      if(this.mode.isCurrentMode("HypixelZoom")) {
         if(!this.hurtted) {
            return;
         }

         if(this.failedStart) {
            return;
         }

         if(!PlayerUtil.isMoving2()) {
            event.setX(0.0D);
            event.setZ(0.0D);
            return;
         }

         Minecraft var10001 = mc;
         Minecraft var10002;
         double var8;
         if(Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            var10002 = mc;
            var8 = 0.2D * (double)(Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1);
         } else {
            var8 = 0.0D;
         }

         double amplifier = 1.0D + var8;
         double baseSpeed = 0.29D * amplifier;
         switch(this.boostHypixelState) {
         case 1:
            var10001 = mc;
            this.moveSpeed = (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)?1.56D:2.034D) * baseSpeed;
            this.boostHypixelState = 2;
            break;
         case 2:
            this.moveSpeed *= ((Double)groundboost.getValueState()).doubleValue();
            this.boostHypixelState = 3;
            break;
         case 3:
            var10002 = mc;
            this.moveSpeed = this.lastDistance - (Minecraft.thePlayer.ticksExisted % 2 == 0?0.0103D:0.0123D) * (this.lastDistance - baseSpeed);
            this.boostHypixelState = 4;
            break;
         default:
            this.moveSpeed = this.lastDistance - this.lastDistance / 159.8D;
         }

         this.moveSpeed = Math.max(this.moveSpeed, 0.3D);
         double yaw = (double)PlayerUtil.getDirection();
         event.setX(-Math.sin(yaw) * this.moveSpeed);
         event.setZ(Math.cos(yaw) * this.moveSpeed);
         Minecraft var10000 = mc;
         Minecraft.thePlayer.motionX = event.getX();
         var10000 = mc;
         Minecraft.thePlayer.motionZ = event.getZ();
      }

   }

   @EventTarget
   public void onPacket(EventPacket2 e) {
      if(e.getType() == cn.Zower.events.EventPacket2.EventPacketType.SEND) {
         Packet packet = e.getPacket();
         if(packet instanceof C03PacketPlayer) {
            ((C03PacketPlayer)packet).onGround = true;
         }

         if((this.mode.isCurrentMode("Hypixel") || this.mode.isCurrentMode("HypixelZoom") && this.hurtted || this.mode.isCurrentMode("NewMotion") && (packet instanceof C04PacketPlayerPosition || packet instanceof C06PacketPlayerPosLook || packet instanceof C08PacketPlayerBlockPlacement || packet instanceof C0APacketAnimation || packet instanceof C0BPacketEntityAction || packet instanceof C02PacketUseEntity))) {
            this.packets.add(packet);
            e.setSendcancel(true);
         }
      }

   }

   @EventTarget
   public void onPreUpdate(EventPreMotion event) {
      Minecraft var10000;
      if(this.mode.isCurrentMode("Motion") || this.mode.isCurrentMode("NewMotion")) {
         var10000 = mc;
         Minecraft.thePlayer.motionY = 0.0D;
         var10000 = mc;
         if(Minecraft.thePlayer.movementInput.jump) {
            var10000 = mc;
            Minecraft.thePlayer.motionY = 2.0D;
         } else {
            var10000 = mc;
            if(Minecraft.thePlayer.movementInput.sneak) {
               var10000 = mc;
               Minecraft.thePlayer.motionY = -2.0D;
            }
         }

         this.setMoveSpeed(((Double)MotionSpeed.getValueState()).doubleValue());
      }

      Minecraft var10001;
      Minecraft var10002;
      Minecraft var10003;
      double var8;
      if(this.mode.isCurrentMode("Hypixel")) {
         var10000 = mc;
         if(Minecraft.thePlayer.isMoving() && !PlayerUtil.isOnGround(0.001D)) {
            ++this.FlyCounter;
            if(this.FlyCounter == 3) {
               var10000 = mc;
               EntityPlayerSP var7 = Minecraft.thePlayer;
               var10001 = mc;
               double var6 = Minecraft.thePlayer.posX;
               var10002 = mc;
               var8 = Minecraft.thePlayer.posY + 1.0E-8D * (new Random()).nextDouble();
               var10003 = mc;
               var7.setPosition(var6, var8, Minecraft.thePlayer.posZ);
               this.FlyCounter = 0;
            }
         }

         var10000 = mc;
         Minecraft.thePlayer.motionY = 0.0D;
      }

      if(this.mode.isCurrentMode("HypixelZoom")) {
         if(!this.hurtted) {
            return;
         }

         var10000 = mc;
         var10001 = mc;
         double xDist = Minecraft.thePlayer.posX - Minecraft.thePlayer.prevPosX;
         var10000 = mc;
         var10001 = mc;
         double zDist = Minecraft.thePlayer.posZ - Minecraft.thePlayer.prevPosZ;
         this.lastDistance = Math.sqrt(xDist * xDist + zDist * zDist);
         Timer var9;
         if(this.BoostTimer.hasReached(((Double)zoomboost.getValueState()).doubleValue() * 1000.0D)) {
            var9 = mc.timer;
            Timer.timerSpeed = 1.0F;
         } else {
            var9 = mc.timer;
            Timer.timerSpeed = 1.0F + ((Double)timerboost.getValueState()).floatValue();
         }

         var10000 = mc;
         if(Minecraft.thePlayer.isMoving() && !PlayerUtil.isOnGround(0.001D)) {
            ++this.FlyCounter;
            if(this.FlyCounter == 3) {
               var10000 = mc;
               var10001 = mc;
               var10002 = mc;
               var8 = Minecraft.thePlayer.posY + 1.0E-5D;
               var10003 = mc;
               Minecraft.thePlayer.setPosition(Minecraft.thePlayer.posX, var8, Minecraft.thePlayer.posZ);
               this.FlyCounter = 0;
            }
         }

         if(!this.failedStart) {
            var10000 = mc;
            Minecraft.thePlayer.motionY = 0.0D;
         }
      }

   }

   public void onEnable() {
      this.FlyCounter = 0;
      Minecraft var10000;
      if(this.mode.isCurrentMode("Hypixel")) {
         var10000 = mc;
      }

      if(this.mode.isCurrentMode("HypixelZoom")) {
         this.BoostTimer.reset();
         this.SlowTimer.reset();
         this.hurtted = false;
         if(((Boolean)damage.getValueState()).booleanValue()) {
            this.damagePlayer();
         }

         if(((Boolean)this.Watting.getValueState()).booleanValue()) {
            (new Thread(() -> {
               try {
                  Thread.sleep(((Double)WattingTime.getValueState()).longValue() * 100L);
               } catch (InterruptedException var2) {
                  var2.printStackTrace();
               }
               Minecraft.thePlayer.jump();
               this.hurtted = true;
            })).start();
         } else {
            var10000 = mc;
            Minecraft.thePlayer.jump();
            this.hurtted = true;
         }

         this.boostHypixelState = 1;
         this.moveSpeed = 0.1D;
         this.lastDistance = 0.0D;
         this.failedStart = false;
      }

      super.onEnable();
   }

   public void onDisable() {
      Minecraft var10000;
      if(this.mode.isCurrentMode("Hypixel") || this.mode.isCurrentMode("HypixelZoom") || this.mode.isCurrentMode("NewMotion")) {
         var10000 = mc;
         NetworkManager var1 = Minecraft.thePlayer.sendQueue.getNetworkManager();
         var10000 = mc;
         if(Minecraft.theWorld != null) {
            Iterator var3 = this.packets.iterator();

            while(var3.hasNext()) {
               Packet packet = (Packet)var3.next();
               var1.sendPacketNoEvent(packet);
            }
         }

         this.packets.clear();
      }

      var10000 = mc;
      Minecraft.thePlayer.motionX = 0.0D;
      var10000 = mc;
      Minecraft.thePlayer.motionZ = 0.0D;
      Timer var4 = mc.timer;
      Timer.timerSpeed = 1.0F;
      super.onDisable();
   }

   public void damagePlayer() {
      Minecraft var10000 = mc;
      if(Minecraft.thePlayer.onGround) {
         NetworkManager var2;
         Minecraft var10003;
         Minecraft var10004;
         Minecraft var10005;
         for(int index = 0; index <= 67 + 23 * (((Boolean)uhc.getValueState()).booleanValue()?1:0); ++index) {
            var10000 = mc;
            var2 = Minecraft.thePlayer.sendQueue.getNetworkManager();
            var10003 = mc;
            var10004 = mc;
            double var3 = Minecraft.thePlayer.posY + 2.535E-9D;
            var10005 = mc;
            var2.sendPacket(new C04PacketPlayerPosition(Minecraft.thePlayer.posX, var3, Minecraft.thePlayer.posZ, false));
            var10000 = mc;
            var2 = Minecraft.thePlayer.sendQueue.getNetworkManager();
            var10003 = mc;
            var10004 = mc;
            var3 = Minecraft.thePlayer.posY + 1.05E-10D;
            var10005 = mc;
            var2.sendPacket(new C04PacketPlayerPosition(Minecraft.thePlayer.posX, var3, Minecraft.thePlayer.posZ, false));
            var10000 = mc;
            var2 = Minecraft.thePlayer.sendQueue.getNetworkManager();
            var10003 = mc;
            var10004 = mc;
            var3 = Minecraft.thePlayer.posY + 0.0448865D;
            var10005 = mc;
            var2.sendPacket(new C04PacketPlayerPosition(Minecraft.thePlayer.posX, var3, Minecraft.thePlayer.posZ, false));
         }

         var10000 = mc;
         var2 = Minecraft.getNetHandler().getNetworkManager();
         var10003 = mc;
         var10004 = mc;
         var10005 = mc;
         var2.sendPacket(new C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ, true));
      }

   }

   private double getBaseMoveSpeed() {
      double baseSpeed = 0.2873D;
      Minecraft var10000 = mc;
      if(Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
         var10000 = mc;
         int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
         baseSpeed *= 1.0D + 0.2D * (double)(amplifier + 1);
      }

      return baseSpeed;
   }

   @EventTarget
   public void onPullback(EventPullback e) {
      if(((Boolean)lagback.getValueState()).booleanValue()) {
         ClientUtil.sendClientMessage("(LagBackCheck) Fly Disabled", Type.WARNING);
         this.set(false);
      }

   }

   private void setMoveSpeed(double speed) {
      Minecraft var10000 = mc;
      MovementInput var8 = Minecraft.thePlayer.movementInput;
      double forward = (double)MovementInput.moveForward;
      var10000 = mc;
      var8 = Minecraft.thePlayer.movementInput;
      double strafe = (double)MovementInput.moveStrafe;
      var10000 = mc;
      float yaw = Minecraft.thePlayer.rotationYaw;
      if(forward == 0.0D && strafe == 0.0D) {
         var10000 = mc;
         Minecraft.thePlayer.motionX = 0.0D;
         var10000 = mc;
         Minecraft.thePlayer.motionZ = 0.0D;
      } else {
         if(forward != 0.0D) {
            if(strafe > 0.0D) {
               yaw += (float)(forward > 0.0D?-45:45);
            } else if(strafe < 0.0D) {
               yaw += (float)(forward > 0.0D?45:-45);
            }

            strafe = 0.0D;
            if(forward > 0.0D) {
               forward = 1.0D;
            } else if(forward < 0.0D) {
               forward = -1.0D;
            }
         }

         var10000 = mc;
         Minecraft.thePlayer.motionX = forward * speed * -Math.sin(Math.toRadians((double)yaw)) + strafe * speed * Math.cos(Math.toRadians((double)yaw));
         var10000 = mc;
         Minecraft.thePlayer.motionZ = forward * speed * Math.cos(Math.toRadians((double)yaw)) - strafe * speed * -Math.sin(Math.toRadians((double)yaw));
      }

   }
}
