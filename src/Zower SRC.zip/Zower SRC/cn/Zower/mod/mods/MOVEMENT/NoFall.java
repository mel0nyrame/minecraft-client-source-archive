package cn.Zower.mod.mods.MOVEMENT;

import com.darkmagician6.eventapi.EventTarget;

import cn.Zower.Value;
import cn.Zower.events.EventPacket;
import cn.Zower.events.EventPreMotion;
import cn.Zower.events.EventUpdate;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;
import cn.Zower.mod.ModManager;
import cn.Zower.util.PlayerUtil;
import cn.Zower.util.timeUtils.TimeHelper;
import net.minecraft.block.BlockAir;
import net.minecraft.client.Minecraft;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;

public class NoFall extends Mod {
   private float b = 1.0F;
   private boolean c = true;
   public static boolean Set = false;
   public double ticks = 0.0D;
   private int d;
   private Value mode = new Value("NoFall", "Mode", 0);
   public TimeHelper timer = new TimeHelper();
   public TimeHelper NoFallDelay = new TimeHelper();
   private int times;
   private float lastFall;
   private boolean showed;
   private boolean showed2;
   private int ongroundtick;

   public NoFall() {
      super("NoFall", Category.PLAYER);
      this.mode.mode.add("Hypixel");
      this.showValue = this.mode;
   }

   @EventTarget
   private void onUpdate(EventPreMotion e2) {
       if (this.mode.isCurrentMode("Hypixel")) {
           this.setDisplayName("Hypixel");
           if (Minecraft.thePlayer.fallDistance > 2.0f) {
               Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
               Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
               Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
               Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
               Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
           }
         
       }
   }

   private boolean isBlockUnder() {
       for (int i = (int)Minecraft.thePlayer.posY; i > 0; --i) {
           BlockPos pos = new BlockPos(Minecraft.thePlayer.posX, (double)i, Minecraft.thePlayer.posZ);
           if (Minecraft.theWorld.getBlockState(pos).getBlock() instanceof BlockAir) continue;
           return true;
       }
       return false;
   }
   public void onMove(EventUpdate event) {
       if (Minecraft.thePlayer.fallDistance > 2.0f || PlayerUtil.getDistanceToFall() > 2.0) {
           event.onGround = true;
       }
   }

   public void onEnable() {
      super.onEnable();
   }

   public void onDisable() {
      super.onDisable();
   }
}
