package cn.Zower.mod.mods.RENDER;

import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;

public class NoFov
extends Mod {
    public NoFov() {
    	super("NoFov", Category.MOVEMENT);

    }
    @Override
    public void onDisable() {
        super.onDisable();

    }
    public void onEnable() {
    	super.isEnabled();

    }
}