package cn.Zower.mod.mods.RENDER;

import java.awt.Color;

import com.darkmagician6.eventapi.EventTarget;

import cn.Zower.events.EventRender2D;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;
import cn.Zower.util.ClientUtil;
import cn.Zower.util.ColorUtils;
import cn.Zower.util.Colors;
import cn.Zower.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

public class Quickbar extends Mod {
    public static Minecraft mc = Minecraft.getMinecraft();

    public Quickbar() {
        super("Quickbar", Category.RENDER);
    }

    @EventTarget
    public void onUpdate(EventRender2D e) {
            Minecraft mc = Minecraft.getMinecraft();
            FontRenderer fr = mc.fontRendererObj;
            ScaledResolution sr = new ScaledResolution(this.mc);
            String name = mc.thePlayer.getName();
            sr.getScaledHeight();
            sr.getScaledWidth();
            int right = sr.getScaledWidth();
            int ping;
            int index = 0;
            long x = 0;
            if (mc.isSingleplayer()) {
                ping = 0;
            } else {
                ping = mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID()).getResponseTime();
            }
            Gui.drawRect(0, sr.getScaledHeight() - 23, sr.getScaledWidth(), sr.getScaledHeight(), new Color(0, 0, 0, 100).getRGB());

            int i = 8;

            if (mc.thePlayer.inventory.currentItem == 0) {
              /*  Gui.drawRect((sr.getScaledWidth() / 2) - 91 + mc.thePlayer.inventory.currentItem * 20,
                        sr.getScaledHeight() - 23, (sr.getScaledWidth() / 2) + 91 - 20 * i, sr.getScaledHeight(),
                        Integer.MAX_VALUE);*/
            } else {
               /* Gui.drawRect((sr.getScaledWidth() / 2) - 91 + mc.thePlayer.inventory.currentItem * 20,
                        sr.getScaledHeight() - 23,
                        (sr.getScaledWidth() / 2) + 91 - 20 * (8 - mc.thePlayer.inventory.currentItem),
                        sr.getScaledHeight(), Integer.MAX_VALUE);*/
            }
   
          /*  fr.drawString("FPS:", 2, sr.getScaledHeight() - 20,
                    ColorUtils.rainbowEffekt(index, 1.0F).getRGB());
            fr.drawString("" + Minecraft.debugFPS, 25, sr.getScaledHeight() - 20, 0xFFFAFA);*/

            
        /*    fr.drawString("X:", 2, sr.getScaledHeight() - 10,
                    ColorUtils.rainbowEffekt(index, 1.0F).getRGB());
            fr.drawString(
                     String.valueOf(Math.round(mc.thePlayer.posX)),
                    13, sr.getScaledHeight() - 10, 0xFFFAFA);
            
            fr.drawString("Y:", 45, sr.getScaledHeight() - 10,
                    ColorUtils.rainbowEffekt(index, 1.0F).getRGB());
            fr.drawString(
                     String.valueOf(Math.round(mc.thePlayer.posY)),
                    56, sr.getScaledHeight() - 10, 0xFFFAFA);
            
            fr.drawString("Z:", 75, sr.getScaledHeight() - 10,
                    ColorUtils.rainbowEffekt(index, 1.0F).getRGB());
            fr.drawString(
                     String.valueOf(Math.round(mc.thePlayer.posZ)),
                   86, sr.getScaledHeight() - 10, 0xFFFAFA);*/
            
            
            fr.drawString("Name: " , sr.getScaledWidth() - 120,
                    sr.getScaledHeight() - 20, ColorUtils.rainbowEffekt(index + x * 20000000L, 1.0F).getRGB());
            fr.drawString("" + name, sr.getScaledWidth() -90, sr.getScaledHeight() - 20, 0xFFFAFA);
            
            
            String var1 = "IP: ";
            fr.drawString(var1, right - 120, sr.getScaledHeight() - 10,
                    ColorUtils.rainbowEffekt(index + x * 20000000L, 1.0F).getRGB());
            fr.drawString(
                    mc.isSingleplayer() ? " NONE" : mc.getCurrentServerData().serverIP.toLowerCase(), right - 105,
                    sr.getScaledHeight() - 10, 0xFFFAFA);

           /* fr.drawString("Ping:", 51, sr.getScaledHeight() - 20,
                    ColorUtils.rainbowEffekt(index + x * 20000000L, 1.0F).getRGB());
            fr.drawString(ping + "ms", 76, sr.getScaledHeight() - 20, 0xFFFAFA);*/

            String info = "\247bX: \247r" + (int)mc.thePlayer.posX + " "  + "\247bY: \247r" + (int)mc.thePlayer.posY + " "  + "\247bZ: \247r" + (int)mc.thePlayer.posZ;
    		String fps = "\247bFPS: \247r" + (int)Minecraft.getDebugFPS() + (mc.isSingleplayer() ? " \247bPing: \247r0ms" : " \247bPing: \247r" + mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID()).getResponseTime() + "ms");
    		

            if(!(mc.currentScreen instanceof GuiChat)) {
				if(mc.fontRendererObj.getStringWidth(info) > mc.fontRendererObj.getStringWidth(fps)) {

				fr.drawString(info, 2, sr.getScaledHeight() - 10, 0xffffff);
				fr.drawString(fps, 2, sr.getScaledHeight() - 20, 0xffffff);
				
			
			}
			GlStateManager.color(1, 1, 1);
			//Coords Render END
			
			
			
		}	
            
		
            

    
    }
}

