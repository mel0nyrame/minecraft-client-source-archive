package cn.Zower.mod.mods.RENDER;

import java.awt.Color;

import com.darkmagician6.eventapi.EventTarget;

import cn.Zower.Value;
import cn.Zower.events.EventRender2D;
//import cn.Zower.events.value.Numbers;
import cn.Zower.mod.Mod;
import cn.Zower.mod.Category;
import cn.Zower.util.fontRenderer.CFont.CFontRenderer;
import cn.Zower.ui.font.FontLoaders;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;

public class Keyrender extends Mod{


	int anima;
	int anima2;
	int anima3;
	int anima4;
	int anima5;
	int anima6;
  //  private Numbers<Double> x = new Numbers<Double>("X", "X", 500.0, 1.0, 1920.0, 5.0);
//	public Value<String> mode = new Value("Keyrender", "Mode", 0);
//    private Value<Double> x = new Value<Double>("x_change", 500.0, 500.0, 1920.0, 5.0);
 //   private Value<Double> y = new Value<Double>("y_change", 1.0,1.0,1080.0, 5.0);
	private Value<Double> x = new Value<Double>("Keyrender_X", Double.valueOf(500D), Double.valueOf(1D), Double.valueOf(1920D), 5D);
	private Value<Double> y = new Value<Double>("Keyrender_Y", Double.valueOf(2D), Double.valueOf(1D), Double.valueOf(1080D), 5D);
//	public static Value<Double> b = new Value("EnchantEffect_Blue",255d, 0d, 255d, 1d);
    private double rainbowTick;
    public Keyrender() {
    	super("Keyrender", Category.RENDER);
    	
 //   	this.x.mode.add("x");
 //   	this.y.mode.add("y");
  //      this.setRemoved(true);
    }
    private void setRemoved(boolean b) {
		// TODO Auto-generated method stub
		
	}
	@EventTarget
    public void onGui(EventRender2D e) {
        CFontRenderer font = FontLoaders.kiona18;
		Color rainbow = new Color(Color.HSBtoRGB((float) ((double) Minecraft.thePlayer.ticksExisted / 250.0
				+ Math.sin((double) rainbowTick / 100.0 * 1.5)) % 1.0f, 0.8f, 0.9f));
 //       float xOffset = ((Double)this.x.getDefaultValue()).floatValue();
        
 //       float yOffset = ((Double)this.y.getDefaultValue()).floatValue();
        float xOffset;
	    float yOffset;
        xOffset = x.getValueState().floatValue();
        yOffset = y.getValueState().floatValue();
        Gui.drawRect((double)xOffset+26, (double)yOffset, (double)(xOffset + 51), (double)(yOffset +25),new Color(0,0,0,150).getRGB());//w
        Gui.drawRect((double)xOffset+26, (double)yOffset+26, (double)(xOffset +51), (double)(yOffset+51),new Color(0,0,0,150).getRGB());//s
        Gui.drawRect((double)xOffset, (double)yOffset+26, (double)(xOffset +25), (double)(yOffset+51),new Color(0,0,0,150).getRGB());//a
        Gui.drawRect((double)xOffset+52, (double)yOffset+26, (double)(xOffset +77), (double)(yOffset+51),new Color(0,0,0,150).getRGB());//d
        Gui.drawRect((double)xOffset+1+77/2 ,(double)yOffset+52, (double)(xOffset +77), (double)(yOffset+77),new Color(0,0,0,150).getRGB());//LMB
        Gui.drawRect((double)xOffset, (double)yOffset+52, (double)(xOffset +77/2), (double)(yOffset+77),new Color(0,0,0,150).getRGB());//RMB
        font.drawStringWithShadow("W", xOffset+(float)34.5, yOffset+9, rainbow.getRGB());
        font.drawStringWithShadow("S", xOffset+(float)36, yOffset+35, rainbow.getRGB());
        font.drawStringWithShadow("A", xOffset+(float)10, yOffset+35, rainbow.getRGB());
        font.drawStringWithShadow("D", xOffset+(float)62, yOffset+35, rainbow.getRGB());
        font.drawStringWithShadow("LMB", xOffset+(float)10, yOffset+60, rainbow.getRGB());
        font.drawStringWithShadow("RMB", xOffset+(float)50, yOffset+60, rainbow.getRGB());
		if (++rainbowTick > 10000) {
			rainbowTick = 0;		
		}
        //w
        if(mc.gameSettings.keyBindForward.pressed) {
            if (this.anima < 25) {
               this.anima=this.anima+5;
            } 
        }else if (this.anima > 0) {
            this.anima=this.anima-5;
        }
        //s
        if(mc.gameSettings.keyBindBack.pressed) {
            if (this.anima2 < 25) {
                this.anima2=this.anima2+5;
            } 
        }else if (this.anima2 > 0) {
            this.anima2=this.anima2-5;
        }
        //a
        if(mc.gameSettings.keyBindLeft.pressed) {
            if (this.anima3 < 25) {
                this.anima3=this.anima3+5;
            } 
        }else if (this.anima3 > 0) {
            this.anima3=this.anima3-5;
        }
        //d
        if(mc.gameSettings.keyBindRight.pressed) {
            if (this.anima4 < 25) {
                this.anima4=this.anima4+5;
            } 
        }else if (this.anima4 > 0) {
            this.anima4=this.anima4-5;
        }
        //LMB
        if(mc.gameSettings.keyBindUseItem.pressed) {
            if (this.anima5 < 25) {
                this.anima5=this.anima5+5;
            } 
        }else if (this.anima5 > 0) {
            this.anima5=this.anima5-5;
        }
        //RMB
        if(mc.gameSettings.keyBindAttack.pressed) {
            if (this.anima6 < 25) {
                this.anima6=this.anima6+5;
            } 
        }else if (this.anima6 > 0) {
            this.anima6=this.anima6-5;
        }
            Gui.drawRect((double)xOffset+26, (double)yOffset+25, (double)(xOffset + 51), (double)(yOffset +25-anima),new Color(255,255,255,120).getRGB());//w
            Gui.drawRect((double)xOffset+26, (double)yOffset+51, (double)(xOffset +51), (double)(yOffset+51-anima2),new Color(255,255,255,120).getRGB());//s
            Gui.drawRect((double)xOffset, (double)yOffset+51, (double)(xOffset +25), (double)(yOffset+51-anima3),new Color(255,255,255,120).getRGB());//a
            Gui.drawRect((double)xOffset+52, (double)yOffset+51, (double)(xOffset +77), (double)(yOffset+51-anima4),new Color(255,255,255,120).getRGB());//d
            Gui.drawRect((double)xOffset+1+77/2 ,(double)yOffset+77, (double)(xOffset +77), (double)(yOffset+77-anima5),new Color(255,255,255,120).getRGB());//LMB
            Gui.drawRect((double)xOffset, (double)yOffset+77, (double)(xOffset +77/2), (double)(yOffset+77-anima6),new Color(255,255,255,120).getRGB());//RMB
    }
    public void onDisable() {
    	this.anima=0;
    	this.anima2=0;
    	this.anima3=0;
    	this.anima4=0;
    	this.anima5=0;
    	this.anima6=0;
        super.onDisable();
    }
    public void onEnable() {
        super.isEnabled();
    }

}
