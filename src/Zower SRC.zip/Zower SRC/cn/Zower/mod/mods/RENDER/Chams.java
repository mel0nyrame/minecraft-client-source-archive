package cn.Zower.mod.mods.RENDER;

import org.lwjgl.opengl.GL11;

import com.darkmagician6.eventapi.EventTarget;

import cn.Zower.Value;
import cn.Zower.events.EventPostRenderPlayer;
import cn.Zower.events.EventPreRenderPlayer;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;


public class Chams extends Mod{
	public Chams() {
		super("Chams", Category.RENDER);
		
	}
	
	@EventTarget
	  private void preRenderPlayer(EventPreRenderPlayer e) {
		   GL11.glEnable(32823);
         GL11.glPolygonOffset(0.0F, -1100000.0F);
      
  }
	
	@EventTarget
  private void postRenderPlayer(EventPostRenderPlayer e) {
		GL11.glDisable(32823);
       GL11.glPolygonOffset(1.0F, 1100000.0F);
  }
	
}
