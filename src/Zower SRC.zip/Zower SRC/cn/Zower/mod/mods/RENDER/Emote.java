package cn.Zower.mod.mods.RENDER;

import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;

public class Emote extends Mod {

	public Emote() {
		super("Emote", Category.RENDER);
	}

}
