/*
 * Decompiled with CFR 0.136.
 */
package cn.Zower.mod.mods.RENDER;



import java.awt.Color;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import org.lwjgl.opengl.GL11;

import com.darkmagician6.eventapi.EventTarget;
import com.ibm.icu.text.NumberFormat;

import cn.Zower.Value;
import cn.Zower.events.EventRender2D;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;
import cn.Zower.mod.mods.COMBAT.Killaura;
import cn.Zower.ui.font.FontLoaders;
import cn.Zower.util.Colors;
import cn.Zower.util.RenderUtil;
import cn.Zower.util.RenderUtils;
import cn.Zower.util.fontRenderer.CFont.CFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.EnumChatFormatting;

public class TargetHUD
extends Mod {
    public static boolean shouldMove;
    public static boolean useFont;
	public static float AnimotaiX;
	public static float AnimotaiSpeed;
	 private Value<Boolean> black = new Value<Boolean>("TargetHUD_Black", false);
	public TargetHUD() {
		super("TargetHUD", Category.RENDER);
	}
    Colors hurtcolor;
    String hurtrender;
    String linehealth = null;
	@EventTarget
    public void onRender(EventRender2D event) {
        
		ScaledResolution res1 = new ScaledResolution(this.mc);	 
		int x = res1.getScaledWidth() /2 + 10;
		int y = res1.getScaledHeight() - 90;
        final EntityLivingBase player = (EntityLivingBase) Killaura.target;
         if (player != null) {
            GlStateManager.pushMatrix();
            //BackGround
            

            Gui.drawRect(x+1.0, y+1.0, x+123.0, y+35.0,this.black.getValueState().booleanValue() ? Integer.MIN_VALUE : new Color(240,238,225,150).getRGB() );
            
            RenderUtil.drawBorderedRect(x, (float)y, x+124, y+36, 2,this.black.getValueState().booleanValue() ? new Color(240,238,225).getRGB() : new Color(0,0,0).getRGB(), 1);
            
            Gui.drawRect(x+35.0, y+1.0, x+123.0, y+35.0,this.black.getValueState().booleanValue() ? Integer.MIN_VALUE : new Color(240,238,225,150).getRGB() );

           // Minecraft.fontRendererObj.drawString(player.getName(), x+38.0f, y+4.0f,this.black.getValueState().booleanValue() ? -1 : 1,false);
            BigDecimal bigDecimal = new BigDecimal((double)player.getHealth());
    		bigDecimal = bigDecimal.setScale(1, RoundingMode.HALF_UP);
    		double HEALTH = bigDecimal.doubleValue();
            BigDecimal DT = new BigDecimal((double)mc.thePlayer.getDistanceToEntity(player));
    		DT = DT.setScale(1, RoundingMode.HALF_UP);
    		double Dis = DT.doubleValue();
            final float health = player.getHealth();
            final float[] fractions = { 0.0f, 0.5f, 1.0f };
            final Color[] colors = { Color.RED, Color.YELLOW, Color.GREEN };
            final float progress = health / player.getMaxHealth();
            final Color customColor = (health >= 0.0f) ? blendColors(fractions, colors, progress).brighter() : Color.RED;
            double width = (double)mc.fontRendererObj.getStringWidth(player.getName());
            width = getIncremental(width, 10.0);
            if (width < 50.0) {
                width = 50.0;
            }
            final double healthLocation = width * progress;
            //health bar
            Gui.drawRect(x+ 37.5, y+ 22.5, x+48.0 + healthLocation + 0.5, y+14.5, customColor.getRGB());
            RenderUtil.rectangleBordered(x+37.0, y + 22.0, x+49.0 + width, y+15.0, 0.5, Colors.getColor(0, 0), Colors.getColor(1));
           
            String COLOR1;
            if (health > 20.0D) {
               COLOR1 = " \2479";
            } else if (health >= 10.0D) {
               COLOR1 = " \247a";
            } else if (health >= 3.0D) {
               COLOR1 = " \247e";
            } else {
               COLOR1 = " \2474";
            }
            
            GlStateManager.scale(0.5, 0.5, 0.5);
            final String str3 = String.format("HP: %s HURT: %s", Math.round(player.getHealth()), player.hurtTime);
            FontLoaders.Backs28.drawStringWithShadow(str3, x*2+76.0f, y*2+49.0f, this.black.getValueState().booleanValue() ? -1 : 1);
//          GuiInventory.drawEntityOnScreen(x*2-500s , 32, 25 , 2.0f, 2.0f, KillAura.target);

            GlStateManager.scale(2.0f, 2.0f, 2.0f);
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.enableAlpha();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            
            if(player instanceof EntityPlayer) {
            final List var5 = GuiPlayerTabOverlay.field_175252_a.sortedCopy((Iterable)mc.thePlayer.sendQueue.getPlayerInfoMap());
            for (final Object aVar5 : var5) {
                final NetworkPlayerInfo var6 = (NetworkPlayerInfo)aVar5;
                if (mc.theWorld.getPlayerEntityByUUID(var6.getGameProfile().getId()) == player) {
                    mc.getTextureManager().bindTexture(var6.getLocationSkin());
                    Gui.drawScaledCustomSizeModalRect(x+2, y+2, 8.0f, 8.0f, 8, 8, 32, 32, 64.0f, 64.0f);
                    if (((EntityPlayer)player).isWearing(EnumPlayerModelParts.HAT)) {
                        Gui.drawScaledCustomSizeModalRect(x+2, y+2, 40.0f, 8.0f, 8, 8, 35, 32, 74.0f, 74.0f);
                    }
                    GlStateManager.bindTexture(0);
                    break;
                }
            }
            
            }
            
            GlStateManager.popMatrix();
        }
	}

 private void renderStuffStatus(ScaledResolution scaledRes) {
		int yOffset = 15;
		for (int slot = 3, xOffset = 0; slot >= 0; slot--) {
			ItemStack stack = mc.thePlayer.inventory.armorItemInSlot(slot);
			GuiIngame gi = new GuiIngame(mc);
			if (stack != null) {
				GL11.glDisable(GL11.GL_DEPTH_TEST);
				GL11.glScalef(0.5F, 0.5F, 0.5F);
				mc.fontRendererObj.drawStringWithShadow(stack.getMaxDamage() - stack.getItemDamage() + "", scaledRes.getScaledWidth() + 32 - xOffset * 2 + (stack.getMaxDamage() - stack.getItemDamage() >= 100 ? 4 : (stack.getMaxDamage() - stack.getItemDamage() <= 100 && stack.getMaxDamage() - stack.getItemDamage() >= 10  ? 7 : 11)), scaledRes.getScaledHeight() * 2 - 147 - yOffset + 30, 0xFFFFFF);
				GL11.glScalef(2F, 2F, 2F);
				GL11.glEnable(GL11.GL_DEPTH_TEST);
				mc.getRenderItem().renderItemIntoGUI(stack, scaledRes.getScaledWidth() / 2 + 25 - xOffset, scaledRes.getScaledHeight() - 70 - (yOffset / 2) + 15);
				xOffset -= 18;
			}
		}
	}
 	
// @EventHandler
// private void drawMoon(EventRender2D e) {
//	 ScaledResolution res = new ScaledResolution(this.mc);	 
//	 if(KillAura.curTarget != null){
//	 
//	 final float health;
//	 double width;
//	 EntityPlayer entityPlayer;
//	 if (KillAura.curTarget !=null){
//		 entityPlayer = (EntityPlayer) KillAura.curTarget;
//	 }else{
//		 entityPlayer = null;
//	 }
//		 health = ((EntityLivingBase) KillAura.curTarget).getHealth();
//		 width = (double)mc.fontRendererObj.getStringWidth(KillAura.curTarget.getName());
//	 final float progress = health / ((EntityLivingBase) KillAura.curTarget).getMaxHealth();
//	 int x = res.getScaledWidth();
//	 int y = res.getScaledHeight();
//	 final double healthLocation = width * progress;
//	 CFontRenderer font = FontLoaders.kiona16;
//	 String dire = Direction.values()[MathHelper.floor_double(KillAura.curTarget.rotationYaw * 4.0f / 180.0f + 0.5) & 0x7].name();
//	 final EntityLivingBase player = (EntityLivingBase) KillAura.curTarget;
//	 NetworkPlayerInfo playerInfo = Minecraft.getMinecraft().thePlayer.sendQueue.getPlayerInfo(player.getName());
//	 int playerPing = playerInfo != null ? playerInfo.getResponseTime() : -1;
//	 FontRenderer font2 = this.mc.fontRendererObj;
//	 if(this.mode.getValue() == rendermode.Moon){
//	 RenderUtil.drawBorderedRect(new ScaledResolution(this.mc).getScaledWidth() - 100, new ScaledResolution(this.mc).getScaledHeight() - 30, new ScaledResolution(this.mc).getScaledWidth() - 340, new ScaledResolution(this.mc).getScaledHeight() - 80, 1.0f, new Color(35, 35, 35, 0).getRGB(), new Color(35, 35, 35, 180).getRGB());
//	 R3DUtil.drawEntityOnScreen(new ScaledResolution(this.mc).getScaledWidth() - 325, new ScaledResolution(this.mc).getScaledHeight() - 45, 15, 2.0f, 15.0f, (EntityLivingBase)KillAura.curTarget);
//	 font2.drawString("Name:"+"\247b"+KillAura.curTarget.getName() + "      " + "\247fHurt:" + "\247c"+(KillAura.curTarget.hurtResistantTime > 0), new ScaledResolution(this.mc).getScaledWidth() -300, new ScaledResolution(this.mc).getScaledHeight() - 75, 16777215);
//	 font2.drawString("Ping:"+ "\247c"+playerPing+ "      " + "\247fDirection:" + dire, new ScaledResolution(this.mc).getScaledWidth() -300, new ScaledResolution(this.mc).getScaledHeight() - 65, 16777215);
//	 if (KillAura.curTarget.getName() != entityPlayer.getName()){
//	 RenderUtil.drawBorderedRect(x/2+150 +30, y -49, x/2+150 + healthLocation *3.86 +30, y - 35, 3.0f, Colors.GREEN.c,Colors.GREEN.c);
//	 }
//	 else{
//		 RenderUtil.drawBorderedRect(x/2+150 +30, y -49, x/2+150 + healthLocation *2.3 +30, y - 35, 3.0f, Colors.GREEN.c,Colors.GREEN.c);
//	 }
//	 font.drawString("\247f" + (int)((EntityLivingBase)KillAura.curTarget).getHealth()*5 +"%", new ScaledResolution(this.mc).getScaledWidth() - 208, new ScaledResolution(this.mc).getScaledHeight() - 43, 1677721);
//	 } 
//	 }
//	 }
 
 public static int[] getFractionIndicies(float[] fractions, float progress) {
     int[] range = new int[2];

     int startPoint;
     for(startPoint = 0; startPoint < fractions.length && fractions[startPoint] <= progress; ++startPoint) {
        ;
     }

     if(startPoint >= fractions.length) {
        startPoint = fractions.length - 1;
     }

     range[0] = startPoint - 1;
     range[1] = startPoint;
     return range;
  }

  public static Color blendColors(float[] fractions, Color[] colors, float progress) {
     Color color = null;
     if(fractions == null) {
        throw new IllegalArgumentException("Fractions can\'t be null");
     } else if(colors == null) {
        throw new IllegalArgumentException("Colours can\'t be null");
     } else if(fractions.length == colors.length) {
        int[] indicies = getFractionIndicies(fractions, progress);
        float[] range = new float[]{fractions[indicies[0]], fractions[indicies[1]]};
        Color[] colorRange = new Color[]{colors[indicies[0]], colors[indicies[1]]};
        float max = range[1] - range[0];
        float value = progress - range[0];
        float weight = value / max;
        color = blend(colorRange[0], colorRange[1], (double)(1.0F - weight));
        return color;
     } else {
        throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
     }
  }

  public static Color blend(Color color1, Color color2, double ratio) {
     float r = (float)ratio;
     float ir = 1.0F - r;
     float[] rgb1 = new float[3];
     float[] rgb2 = new float[3];
     color1.getColorComponents(rgb1);
     color2.getColorComponents(rgb2);
     float red = rgb1[0] * r + rgb2[0] * ir;
     float green = rgb1[1] * r + rgb2[1] * ir;
     float blue = rgb1[2] * r + rgb2[2] * ir;
     if(red < 0.0F) {
        red = 0.0F;
     } else if(red > 255.0F) {
        red = 255.0F;
     }

     if(green < 0.0F) {
        green = 0.0F;
     } else if(green > 255.0F) {
        green = 255.0F;
     }

     if(blue < 0.0F) {
        blue = 0.0F;
     } else if(blue > 255.0F) {
        blue = 255.0F;
     }

     Color color3 = null;

     try {
        color3 = new Color(red, green, blue);
     } catch (IllegalArgumentException var14) {
        NumberFormat nf = NumberFormat.getNumberInstance();
        System.out.println(nf.format((double)red) + "; " + nf.format((double)green) + "; " + nf.format((double)blue));
        var14.printStackTrace();
     }

     return color3;
  }

  private double getIncremental(double val, double inc) {
     double one = 1.0D / inc;
     return (double)Math.round(val * one) / one;
  }

  



    
    
	static enum rendermode {
		Rainbowline,
		HTB,
		Mikov,
		Flat,
		BLC, 
		New,
    }
	public enum Direction {
        S("S", 0), 
        SW("SW", 1), 
        W("W", 2), 
        NW("NW", 3), 
        N("N", 4), 
        NE("NE", 5), 
        E("E", 6), 
        SE("SE", 7);
        private Direction(final String s, final int n) {}
    }

}
