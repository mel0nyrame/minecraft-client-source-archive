package cn.Zower.mod.mods.RENDER;

import cn.Zower.Value;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;

public class SetScoreboard extends Mod{

	public static Value<Boolean> hideboard = new Value<Boolean>("Scoreboard_hideboard",false);
	public static Value<Boolean> fastbord = new Value<Boolean>("Scoreboard_fastbord",false);
	public static Value<Boolean> Norednumber = new Value<Boolean>("Scoreboard_Norednumber",false);
	public static Value<Boolean> noServername = new Value<Boolean>("Scoreboard_noServername",false);
	public static Value<Boolean> noanyfont = new Value<Boolean>("Scoreboard_noanyfont",false);
	public static Value<Double> X = new Value<Double>("Scoreboard_X", 4.5, 0.0, 1000.0, 1.0);
	public static Value<Double> Y = new Value<Double>("Scoreboard_Y", 4.5, -300.0, 300.0, 1.0);
	public SetScoreboard() {
		super("Scoreboard", Category.RENDER);
		
	}
	
	

}
