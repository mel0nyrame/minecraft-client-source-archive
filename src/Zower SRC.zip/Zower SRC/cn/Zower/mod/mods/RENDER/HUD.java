	package cn.Zower.mod.mods.RENDER;

import java.awt.Color;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import com.darkmagician6.eventapi.EventTarget;

import cn.Zower.Client;
import cn.Zower.Value;
import cn.Zower.events.EventKeyboard;
import cn.Zower.events.EventRender2D;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;
import cn.Zower.mod.ModManager;
import cn.Zower.ui.ClientNotification;
import cn.Zower.ui.font.FontLoaders;
import cn.Zower.util.ClientUtil;
import cn.Zower.util.Colors;
import cn.Zower.util.FlatColors;
import cn.Zower.util.RenderUtil;
import cn.Zower.util.RenderUtils;
import cn.Zower.util.fontRenderer.CFont.CFontRenderer;
import cn.Zower.util.timeUtils.TimeHelper;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StatCollector;

public class HUD extends Mod {

	private static Value<Double> rainbow = new Value<Double>("HUD_rainbow", 200.0, 0.0, 2000.0, 100.0);
	private Value<Double> bg = new Value<Double>("HUD_background", 100.0, 0.0, 255.0, 1);
	public Value<String> logo_mode = new Value("HUD", "Logo", 0);
	public Value<String> Tabui_mode = new Value("HUD", "TabUI", 0);
	public static Value<String> Rainbow = new Value("HUD", "Rainbow", 0);
	public static Value<String> Array_mode = new Value("HUD", "Array", 0);
	public Value<String> Effect_mode = new Value("HUD", "Effect", 0);
	public Value<Boolean> logo = new Value("HUD_Logo", true);
	public static Value<Boolean> hotbar = new Value("HUD_Hotbar", false);
	public static Value<Boolean> FPS = new Value("HUD_GUI", false);
	public static Value<Boolean> TabGui = new Value("HUD_TabGui", true);
	public Value<Boolean> array = new Value("HUD_ArrayList", true);
	 public static Value<Double> red = new Value<Double> ("HUD_Red", 0.0, 0.0, 255.0, 1.0);
	  public static Value<Double> green = new Value<Double>("HUD_Green", 125.0, 0.0, 255.0 ,1.0);
	  public static Value<Double> blue = new Value<Double>("HUD_Blue", 255.0, 0.0, 255.0, 1.0);
	public static Value<Boolean> ArmorHUD = new Value("HUD_ArmorHUD", true);
	public static Value<Boolean> info = new Value("HUD_info", true);
	public static Value<Boolean> score = new Value("HUD_score", true);
	public Value<Boolean> arrayrainbow = new Value("HUD_ArrayListRainbow", true);
	
	
	
	TimeHelper time = new TimeHelper();
    public int debug;
	
	//閼筋垱鎸夐弰鍓с仛
    public Minecraft mc = Minecraft.getMinecraft();
    CFontRenderer font = FontLoaders.kiona16;
    CFontRenderer font1 = FontLoaders.kiona28;
    CFontRenderer font2 = FontLoaders.kiona26;
    CFontRenderer Sigma = FontLoaders.kiona16;
    CFontRenderer BLC = FontLoaders.Backs16;
    CFontRenderer Power = FontLoaders.kiona16;
    private int s = 0;
    int x = 0;
	
	   public static float YPort;
	   
	   public ArrayList categoryValues = new ArrayList();
	   public int currentCategoryIndex = 0;
	   public int currentModIndex = 0;
	   public int currentSettingIndex = 0;
	   public int screen = 0;
    
    
    
    public int etb_color = new Color(105, 180, 255).getRGB();
	
	public HUD() {
		super("HUD", Category.RENDER);
		this.categoryValues.addAll(Arrays.asList(Category.values()));
		this.logo_mode.mode.add("Font3");
		this.logo_mode.mode.add("Font2");
		this.logo_mode.mode.add("Font");
		this.logo_mode.mode.add("Novoline");
		this.Rainbow.mode.add("White");
		this.Rainbow.mode.add("Red");
		this.Rainbow.mode.add("Yellow");
		this.Rainbow.mode.add("Green");
		this.Rainbow.mode.add("Blue");
		this.Rainbow.mode.add("Purple");
		this.Rainbow.mode.add("Cyan");
		this.Rainbow.mode.add("Rainbow");
		this.Array_mode.mode.add("SIGMA");
		this.Array_mode.mode.add("Backs");
		this.Array_mode.mode.add("BLC");
		this.Array_mode.mode.add("Zower");
		this.Tabui_mode.mode.add("TabUI1");
		this.Tabui_mode.mode.add("TabUI2");
		this.Tabui_mode.mode.add("Novoline");
		
		this.Effect_mode.mode.add("NONE");
		this.Effect_mode.mode.add("BLC");

		
		

	}
	static int rainbow1 = rainbow.getValueState().intValue();
	FontRenderer fr = mc.fontRendererObj;
	boolean lowhealth = false;
	public static boolean toggledlyric = false;
	public static int getColor(){
		 if(Rainbow.isCurrentMode("White")) {
			 return  ClientUtil.reAlpha(FlatColors.WHITE.c, 1.0F);
			}else if (Rainbow.isCurrentMode("Red")) {
			return Colors.getColor(Color.red);
			}else if(Rainbow.isCurrentMode("Yellow")) {
				return  Colors.getColor(Color.yellow);
			}else if(Rainbow.isCurrentMode("Green")) {
				return  Colors.getColor(Color.green);
			}else if(Rainbow.isCurrentMode("Blue")) {
				return  new Color(0, 100, 242).getRGB();
			}else if(Rainbow.isCurrentMode("Purple")) {
				return Colors.getColor(Color.magenta);
			}else if(Rainbow.isCurrentMode("Cyan")) {
				return new Color(0, 226, 207).getRGB();
			}else if(Rainbow.isCurrentMode("Rainbow")) {
				return  RenderUtil.rainbow(rainbow1);
			}
		return rainbow1 ;
	}
	
	
	
	@EventTarget
	public void onRender2D(EventRender2D event) {
		
		
		
		 
		//Health low warning
		ScaledResolution sr = new ScaledResolution(mc);
		if(mc.thePlayer.getHealth() < 6 && !lowhealth) {
			ClientUtil.sendClientMessage("Your Health is Low!", ClientNotification.Type.WARNING);
			lowhealth = true;
		}
		if(mc.thePlayer.getHealth() > 6 && lowhealth) {lowhealth = false;}
		
		this.renderToggled(sr);
		
		this.renderPotionStatus(sr);
		if(this.logo.getValueState().booleanValue()) {
			this.renderLogo();
		}
		if(this.TabGui.getValueState().booleanValue()) {
			if(this.Tabui_mode.isCurrentMode("TabUI1")) {
				renderTabgui();
			}
			if(this.Tabui_mode.isCurrentMode("TabUI2")) {
				renderTabgui2();
			}
			if(this.Tabui_mode.isCurrentMode("Novoline")) {
				renderTabgui21();
			}
		 }
	

		
		//Coords Render START
		//("FPS:" + Minecraft.getDebugFPS()
		//String info = "\247bCoords: \247r" + (int)mc.thePlayer.posX + " " + (int)mc.thePlayer.posY + " " + (int)mc.thePlayer.posZ;
		String info = "\247bX: \247r" + (int)mc.thePlayer.posX + " "  + "\247bY: \247r" + (int)mc.thePlayer.posY + " "  + "\247bZ: \247r" + (int)mc.thePlayer.posZ;
		String fps = "\247bFPS: \247r" + (int)Minecraft.getDebugFPS() + (mc.isSingleplayer() ? " \247bPing: \247r0ms" : " \247bPing: \247r" + mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID()).getResponseTime() + "ms");
		String Dev = "\247bUser: \247r" + "Dev" + (mc.isSingleplayer() ? " \247bPing: \247r0ms" : " \247bPing: \247r" + mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID()).getResponseTime() + "ms");
		String Other = "\247bUser: \247r" + "Other" + (mc.isSingleplayer() ? " \247bPing: \247r0ms" : " \247bPing: \247r" + mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID()).getResponseTime() + "ms");

		 
	String text = (Object)((Object)EnumChatFormatting.GRAY) + "X" + (Object)((Object)EnumChatFormatting.WHITE) + ": " + MathHelper.floor_double(this.mc.thePlayer.posX) + " " + (Object)((Object)EnumChatFormatting.GRAY) + "Y" + (Object)((Object)EnumChatFormatting.WHITE) + ": " + MathHelper.floor_double(this.mc.thePlayer.posY) + " " + (Object)((Object)EnumChatFormatting.GRAY) + "Z" + (Object)((Object)EnumChatFormatting.WHITE) + ": " + MathHelper.floor_double(this.mc.thePlayer.posZ);
	String FPS = (Object)((Object)EnumChatFormatting.GRAY) + "FPS" + (Object)((Object)EnumChatFormatting.WHITE) + ": " + Minecraft.getDebugFPS() + " " + (Object)((Object)EnumChatFormatting.GRAY) + "PING" + (Object)((Object)EnumChatFormatting.WHITE) + ": " + mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID()).getResponseTime() + "ms" ;
	
	if(this.info.getValueState().booleanValue()) {
		 int ychat;
		 int ychat1;
		 int zchat;
		 
         int n = ychat = this.mc.ingameGUI.getChatGUI().getChatOpen() ? 22 : 8;
         
         int n1 = ychat1 = this.mc.ingameGUI.getChatGUI().getChatOpen() ? 12 : 8;
         
         int n3 = zchat = this.mc.ingameGUI.getChatGUI().getChatOpen() ? 120 : 4;
         
         String xd = "\2477" +"Zower X build" + " - \247f"+Client.CLIENT_Bulid + " \2477- " + "\247a";
         
				
         font.drawStringWithShadow(text, (float) 4.0, new ScaledResolution(this.mc).getScaledHeight() - ychat, new Color(11, 12, 17).getRGB());
         font.drawStringWithShadow(FPS, (float) zchat, new ScaledResolution(this.mc).getScaledHeight() - ychat1-10, new Color(11, 12, 17).getRGB());
			
         mc.fontRendererObj.drawStringWithShadow(xd, (float)sr.getScaledWidth() - mc.fontRendererObj.getStringWidth(xd) - 10.0F, (float)(sr.getScaledHeight() - (11)), Colors.getColor(255, 220));
			}

			GlStateManager.color(1, 1, 1);
			//Coords Render END
			

		}	
		

	
	
	public void renderLogo() {
		 

		
		if(this.logo_mode.isCurrentMode("Font2")) {
			String dire = Direction.values()[MathHelper.floor_double(mc.thePlayer.rotationYaw * 4.0f / 180.0f + 0.5) & 0x7].name();
			String text =Client.CLIENT_name ;
			String text_b = text.substring(1) + " " + Client.CLIENT_VER;
			fr.drawStringWithShadow(Client.CLIENT_name.toUpperCase(), 2, 1, etb_color);
			fr.drawStringWithShadow(Client.CLIENT_VER, 5 + fr.getStringWidth(Client.CLIENT_name.toUpperCase()), 1, 0x989898);
			fr.drawStringWithShadow("[" + dire + "]", fr.getStringWidth(Client.CLIENT_name.toUpperCase()) + fr.getStringWidth(Client.CLIENT_VER) + 9, 1, etb_color);
			if(this.FPS.getValueState().booleanValue()) {
				fr.drawStringWithShadow("FPS:" + Minecraft.getDebugFPS(), 2, 9, etb_color);
			}

		}
		if(this.logo_mode.isCurrentMode("Font")) {
			YPort = 16.0F;
			DateFormat dft = new SimpleDateFormat("HH:mm:ss");
            Date time = Calendar.getInstance().getTime();
            String rendertime = dft.format(time);
            Gui.drawRect(2, 1, 48, 17, new Color(10,10,10,140).getRGB());
	          Gui.drawRect(2, 1, 3, 17, (new Color(((Double)red.getValueState()).intValue(), ((Double)green.getValueState()).intValue(), ((Double)blue.getValueState()).intValue())).getRGB());
            font1.drawCenteredString("Z", 9.0f, 4.0f, new Color(red.getValueState().intValue(),green.getValueState().intValue(),blue.getValueState().intValue()).getRGB());
            font1.drawCenteredString("ower", 29.0f, 4.0f, -1);
       
            
		}
		if(this.logo_mode.isCurrentMode("Font3")) {
			YPort = 16.0F;
			DateFormat dft = new SimpleDateFormat("HH:mm:ss");
            Date time = Calendar.getInstance().getTime();
            String rendertime = dft.format(time);
          
            font1.drawCenteredString("Z", 9.0f, 4.0f, new Color(red.getValueState().intValue(),green.getValueState().intValue(),blue.getValueState().intValue()).getRGB());
            font1.drawCenteredString("ower", 29.0f, 4.0f, -1);
       
           
			
		}
		if(this.logo_mode.isCurrentMode("Novoline")) {
			YPort = 16.0F;
			DateFormat dft = new SimpleDateFormat("HH:mm");
            Date time = Calendar.getInstance().getTime();
            String rendertime = dft.format(time);
            String Info = EnumChatFormatting.GRAY + "["+EnumChatFormatting.WHITE + rendertime+EnumChatFormatting.GRAY + "]";
            font2.drawCenteredString("Z", 7.0f, 3.0f, new Color(red.getValueState().intValue(),green.getValueState().intValue(),blue.getValueState().intValue()).getRGB());
            font2.drawCenteredString("ower", 26.0f, 3.0f, -1);
            Client.instance.fontMgrs.kiona22.drawCenteredString(Info, 63.0f, 4.0f, -1);
       
           
			
		}
		if(this.logo_mode.isCurrentMode("Zower")) {
			YPort =  40.0F;
	        	  RenderUtil.drawImage(new ResourceLocation("Zower/logo/Zower.png"), 0, 0, 120, 40);	          		 
		}
		
		if(this.logo_mode.isCurrentMode("Zower2")) {
			YPort =  55.0F;
			 if(this.time.isDelayComplete(60)) {
	        	  debug++;
	        	  this.time.reset(); 
	          }
	           
	          if (debug >= 61) {
	        	  debug = 0;
	          }else {
	        	  RenderUtil.drawImage(new ResourceLocation("Zower/logo/Zower/"+debug+".png"), -6, -10, 80, 70);
	          } 	          		 
			
		}
	}

    
	private void renderToggled(ScaledResolution sr) {
		int rainbow = this.rainbow.getValueState().intValue();
		int bg = this.bg.getValueState().intValue();
	      
			

		if(this.array.getValueState().booleanValue()) {
			ArrayList<Mod> mods = new ArrayList(Client.instance.modMgr.getToggled());
			int counter[] = {0};
		
			//mods.sort((m1, m2) ->this.mc.fontRendererObj.getStringWidth(String.valueOf(m2.getName()) + m2.getDisplayName()) - this.mc.fontRendererObj.getStringWidth(String.valueOf(m1.getName()) + m1.getDisplayName()));
			if(this.Array_mode.isCurrentMode("BLC")) {
				mods.sort((m1, m2) ->font.getStringWidth(String.valueOf(m2.getName()) + m2.getDisplayName()) - font.getStringWidth(String.valueOf(m1.getName()) + m1.getDisplayName()));
			}
			if(this.Array_mode.isCurrentMode("Zower")) {
				mods.sort((m1, m2) ->font.getStringWidth(String.valueOf(m2.getName()) + m2.getDisplayName()) - font.getStringWidth(String.valueOf(m1.getName()) + m1.getDisplayName()));
			}
			if(this.Array_mode.isCurrentMode("Backs")) {
				mods.sort((m1, m2) ->font.getStringWidth(String.valueOf(m2.getName()) + m2.getDisplayName()) - font.getStringWidth(String.valueOf(m1.getName()) + m1.getDisplayName()));
			}
			if(this.Array_mode.isCurrentMode("SIGMA")) {
				mods.sort((m1, m2) ->font.getStringWidth(String.valueOf(m2.getName()) + m2.getDisplayName()) - font.getStringWidth(String.valueOf(m1.getName()) + m1.getDisplayName()));
			}
			//mods.sort((o1, o2) -> font.getStringWidth(o2.getDisplayName().isEmpty() ? o2.getName() : String.format("%s %s", o2.getName(), o2.getDisplayName())) - font.getStringWidth(o1.getDisplayName().isEmpty() ? o1.getName() : String.format("%s %s", o1.getName(), o1.getDisplayName())));
			//mods.sort((o1, o2) -> this.mc.fontRendererObj.getStringWidth(o2.getDisplayName().isEmpty() ? o2.getName() : String.format("%s %s", o2.getName(), o2.getDisplayName())) - this.mc.fontRendererObj.getStringWidth(o1.getDisplayName().isEmpty() ? o1.getName() : String.format("%s %s", o1.getName(), o1.getDisplayName())));
			int yStart = 0;
			int right = sr.getScaledWidth();
			
			for(Mod module : mods) {
				 int countMod = 0;
				    
			  		int rainbowCol = rainbow(System.nanoTime(), (float) counter[0], 1F).getRGB();
			  	   ++countMod;
					int c = rainbowCol;
					Color col = new Color(c);
					int Ranbow = (new Color(col.getBlue() / 255.0F, col.getBlue()  / 255.0F, col.getBlue()   / 255.0F))
							.getRGB();
				 if(Rainbow.isCurrentMode("White")) {
					 Ranbow =  (new Color(col.getBlue() / 255.0F, col.getBlue()  / 255.0F, col.getBlue()   / 255.0F)).getRGB();
					}else if (Rainbow.isCurrentMode("Red")) {
						Ranbow =  (new Color(col.getRed() / 255.0F, 0 / 255.0F, 0 / 255.0F)).getRGB();
					}else if(Rainbow.isCurrentMode("Yellow")) {
						Ranbow =  (new Color(col.getRed() / 255.0F, col.getRed() / 255.0F, 0 / 255.0F)).getRGB();
					}else if(Rainbow.isCurrentMode("Green")) {
						Ranbow =  (new Color(0, col.getGreen() / 255.0F, 0 / 255.0F)).getRGB();
					}else if(Rainbow.isCurrentMode("Blue")) {
						Ranbow = new Color(0, col.getGreen() / 3 + 40, col.getGreen() / 2 + 100).getRGB();
					}else if(Rainbow.isCurrentMode("Purple")) {
						Ranbow =  new Color(col.getRed() / 2 + 100, 0 , col.getRed() / 2 + 100).getRGB();
					}else if(Rainbow.isCurrentMode("Cyan")) {
						Ranbow =  new Color(0, col.getRed() / 2 + 110 , col.getRed() / 2 + 90).getRGB();
					}else if(Rainbow.isCurrentMode("Rainbow")) {
						Ranbow =  (new Color(col.getRed() / 255.0F, col.getGreen()  / 255.0F, col.getBlue()   / 255.0F)).getRGB();
					}
			String name = module.getDisplayName().isEmpty() ? module.getName() : String.format("%s %s", module.getName(),module.getDisplayName());

			if(this.Array_mode.isCurrentMode("BLC")) {
			
				Gui.drawRect(right - 1, yStart - 2, right, yStart + 9,  arrayrainbow.getValueState()? RenderUtil.rainbow(countMod * rainbow): Ranbow);
	          
				if(module.getDisplayName() != "") {
					Gui.drawRect(right - font.getStringWidth( module.getDisplayName() + module.getName()) - 3, yStart, right - 1, yStart + 9, new Color(0, 0, 0,bg).getRGB());
				} else {
					Gui.drawRect(right - font.getStringWidth(module.getName()) - 3, yStart, right - 1, yStart + 9, new Color(0, 0, 0,bg).getRGB());

				}
				Sigma.drawString(name, right - font.getStringWidth(module.getName() + module.getDisplayName() )- 2, (float)((double)yStart + 1.5),  arrayrainbow.getValueState()? RenderUtil.rainbow(countMod * rainbow): Ranbow);
			}
			if(this.Array_mode.isCurrentMode("Zower")) {
				
			//	Gui.drawRect(right - 1, yStart - 2, right, yStart + 9,  arrayrainbow.getValueState()? RenderUtil.rainbow(countMod * rainbow): Ranbow);
	          
				if(module.getDisplayName() != "") {
				//	Gui.drawRect(right - font.getStringWidth( module.getDisplayName() + module.getName()) - 3, yStart, right - 1, yStart + 9, new Color(0, 0, 0,bg).getRGB());
				} else {
				//	Gui.drawRect(right - font.getStringWidth(module.getName()) - 3, yStart, right - 1, yStart + 9, new Color(0, 0, 0,bg).getRGB());

				}
				font.drawStringWithShadow(name, right - font.getStringWidth(module.getName() + module.getDisplayName() )- 2, (float)((double)yStart + 1.5),  arrayrainbow.getValueState()? RenderUtil.rainbow(countMod * rainbow): Ranbow);
			}

			if(this.Array_mode.isCurrentMode("SIGMA")) {	
				
				 RenderUtils.drawBorderRect2(right - Sigma.getStringWidth(String.valueOf(module.getName()) + module.getDisplayName()) - 4, yStart, right, yStart + 10, 1, new Color(40, 40, 40).getRGB(),  arrayrainbow.getValueState()? RenderUtil.rainbow(countMod * rainbow): Ranbow);
				
				 Gui.drawRect(right - Sigma.getStringWidth(String.valueOf(module.getName()) + module.getDisplayName()) - 3, yStart-1, right - 1, yStart + 1, new Color(41, 40, 40).getRGB());
				 
				 Sigma.drawString(name, right - Sigma.getStringWidth(module.getName() + module.getDisplayName() )- 2, (float)((double)yStart + 2.0),   arrayrainbow.getValueState()? RenderUtil.rainbow(countMod * rainbow): Ranbow);
			}
			
			if(this.Array_mode.isCurrentMode("Backs")) {
				
				Gui.drawRect(right - BLC.getStringWidth( module.getDisplayName() + module.getName()) - 4, yStart - 0, right- BLC.getStringWidth( module.getDisplayName() + module.getName()) - 3, yStart + 9,   arrayrainbow.getValueState()? RenderUtil.rainbow(countMod * rainbow): Ranbow);
				
				if(module.getDisplayName() != "") {
					Gui.drawRect(right - BLC.getStringWidth( module.getDisplayName() + module.getName()) - 3, yStart, right + 2, yStart + 9, new Color(0, 0, 0,bg).getRGB());
				} else {
					Gui.drawRect(right - BLC.getStringWidth(module.getName()) - 3, yStart, right + 2, yStart + 9, new Color(0, 0, 0,bg).getRGB());

				}
				font.drawString( name, right - BLC.getStringWidth(module.getName() + module.getDisplayName() )-1.0, (float)((double)yStart + 1.0),   arrayrainbow.getValueState()? RenderUtil.rainbow(countMod * rainbow): Ranbow);

			}
			
			
				
					//  fr.drawStringWithShadow(String.valueOf(module.getName()) + "鎼�7 " + module.getDisplayName(), right - this.mc.fontRendererObj.getStringWidth(String.valueOf(module.getName()) + module.getDisplayName()) - 2, y + 2, RenderUtil.rainbow(counter[0] * 200));
				//}
			
				
				yStart += 9;
				counter[0]++;
			}
			}
		}
	

public  void renderTabgui(){
		
        int[] var12 = new int[1];
        byte var14;
        var14 = 0;
        byte var15 = 2;
        int var16 = (int)YPort + 2;
        RenderUtils.drawBorderedRect((float)var15, (float)var16, (float)(var15 + this.getWidestCategory() + 3), (float)(var16 + this.categoryValues.size() * 11), 0.1F, Integer.MIN_VALUE, (new Color(0, 0, 0, 255)).getRGB());
        for(Iterator var19 = this.categoryValues.iterator(); var19.hasNext(); ++var12[0]) {
       	 Category var17 = (Category)var19.next();
       	 int var13;
            var13 = -1;

       	 if(this.getCurrentCategorry().equals(var17)) {
       		 RenderUtils.drawGradientSideways((float)var15+0.3, (float)var16+0.3, (float)(var15 + this.getWidestCategory() + 3)-0.3, (float)(var16 + 9 + 2)-0.3,ClientUtil.reAlpha(getColor(), 0.8F),  ClientUtil.reAlpha(getColor(), 0.2F));
       	 }

       	 String var21 = var17.name();
       	 Client.instance.fontMgrs.kiona18.drawStringWithShadow1(var21.substring(0, 1).toUpperCase() + var21.substring(1, var21.length()).toLowerCase(), (float)(var15 + 2), (float)var16 + (float)var14 * 1.5F+1.5, var13);
            var16 += 11;
        }
        
        if(this.screen == 1 || this.screen == 2) {
            int var18 = var15 + this.getWidestCategory() + 6 ;
            int var20 = 21 + this.currentCategoryIndex * 11;
            
            RenderUtils.drawRect((float)var18, (float)var20, (float)(var18 + this.getWidestMod() + 3), (float)(var20 + this.getModsForCurrentCategory().size() * 11), Integer.MIN_VALUE);

            for(Iterator var23 = this.getModsForCurrentCategory().iterator(); var23.hasNext(); var20 += 11) {
           	 Mod var22 = (Mod)var23.next();
           	 if(this.getCurrentModule().equals(var22)) {
           		 RenderUtils.drawGradientSideways((float)var18+0.3, (float)var20+0.3, (float)(var18 + this.getWidestMod() + 3)-0.3, (float)(var20 + 9 + 2)-0.3, ClientUtil.reAlpha(getColor(), 0.8F),  ClientUtil.reAlpha(getColor(), 0.2F));
           		
           	 }
           	 Client.instance.fontMgrs.kiona18.drawStringWithShadow1(var22.getName(), (float)(var18 + 1), (float)var20 + (float)var14 * 1.5F+1.5, var22.isEnabled()?-1:11184810);//Color.GRAY.getRGB());
            }

        }

	}
public  void renderTabgui2(){
	
    int[] var12 = new int[1];
    byte var14;
    var14 = 0;
    byte var15 = 2;
    int var16 = (int)YPort + 2;
    RenderUtils.drawBorderedRect((float)var15, (float)var16, (float)(var15 + this.getWidestCategory() + 3), (float)(var16 + this.categoryValues.size() * 11), 0.1F, Integer.MIN_VALUE, (new Color(0, 0, 0, 255)).getRGB());
    for(Iterator var19 = this.categoryValues.iterator(); var19.hasNext(); ++var12[0]) {
   	 Category var17 = (Category)var19.next();
   	 int var13;
        var13 = -1;

   	 if(this.getCurrentCategorry().equals(var17)) {
   		 RenderUtils.drawGradientSideways((float)var15+0.3, (float)var16+0.3, (float)(var15 + this.getWidestCategory() + 3)-0.3, (float)(var16 + 9 + 2)-0.3,getColor(),  getColor());
   	 }

   	 String var21 = var17.name();
   	 Client.instance.fontMgrs.kiona18.drawStringWithShadow1(var21.substring(0, 1).toUpperCase() + var21.substring(1, var21.length()).toLowerCase(), (float)(var15 + 2), (float)var16 + (float)var14 * 1.5F+1.5, var13);
        var16 += 11;
    }
    
    if(this.screen == 1 || this.screen == 2) {
        int var18 = var15 + this.getWidestCategory() + 6 ;
        int var20 = 21 + this.currentCategoryIndex * 11;
        
        RenderUtils.drawRect((float)var18, (float)var20, (float)(var18 + this.getWidestMod() + 3), (float)(var20 + this.getModsForCurrentCategory().size() * 11), Integer.MIN_VALUE);

        for(Iterator var23 = this.getModsForCurrentCategory().iterator(); var23.hasNext(); var20 += 11) {
       	 Mod var22 = (Mod)var23.next();
       	 if(this.getCurrentModule().equals(var22)) {
       		 RenderUtils.drawGradientSideways((float)var18+0.3, (float)var20+0.3, (float)(var18 + this.getWidestMod() + 3)-0.3, (float)(var20 + 9 + 2)-0.3, getColor(),  getColor());
       		
       	 }
       	 Client.instance.fontMgrs.kiona18.drawStringWithShadow1(var22.getName(), (float)(var18 + 1), (float)var20 + (float)var14 * 1.5F+1.5, var22.isEnabled()?-1:11184810);//Color.GRAY.getRGB());
        }

    }

}
public  void renderTabgui21(){
	
    int[] var12 = new int[1];
    byte var14;
    var14 = 0;
    byte var15 = 2;
    int var16 = (int)YPort + 2;
    RenderUtils.drawBorderedRect((float)var15, (float)var16-3, (float)(var15 + this.getWidestCategory() + 3)+8, (float)(var16 + this.categoryValues.size() * 11), 0.1F, Integer.MIN_VALUE, (new Color(10, 10, 10, 255)).getRGB());
    for(Iterator var19 = this.categoryValues.iterator(); var19.hasNext(); ++var12[0]) {
   	 Category var17 = (Category)var19.next();
   	 int var13;
        var13 = -1;

   	 if(this.getCurrentCategorry().equals(var17)) {
   		 RenderUtils.drawGradientSideways((float)var15, (float)var16-3, (float)(var15 + this.getWidestCategory() + 3)+8, (float)(var16 + 9 + 2),new Color(red.getValueState().intValue(),green.getValueState().intValue(),blue.getValueState().intValue()).getRGB(),  new Color(red.getValueState().intValue(),green.getValueState().intValue(),blue.getValueState().intValue()).getRGB());
   	 }

   	 String var21 = var17.name();
   	 Client.instance.fontMgrs.kiona18.drawStringWithShadow1(var21.substring(0, 1).toUpperCase() + var21.substring(1, var21.length()).toLowerCase(), (float)(var15 + 2), (float)var16 + (float)var14 * 1.5F+1.5, var13);
        var16 += 11;
    }
    
    if(this.screen == 1 || this.screen == 2) {
        int var18 = var15 + this.getWidestCategory() + 6 ;
        int var20 = 21 + this.currentCategoryIndex * 11;
        
        RenderUtils.drawRect((float)var18, (float)var20-3, (float)(var18 + this.getWidestMod() + 3)+8, (float)(var20 + this.getModsForCurrentCategory().size() * 11), Integer.MIN_VALUE);

        for(Iterator var23 = this.getModsForCurrentCategory().iterator(); var23.hasNext(); var20 += 11) {
       	 Mod var22 = (Mod)var23.next();
       	 if(this.getCurrentModule().equals(var22)) {
       		 RenderUtils.drawGradientSideways((float)var18, (float)var20, (float)(var18 + this.getWidestMod() + 3), (float)(var20 + 9 + 2), new Color(red.getValueState().intValue(),green.getValueState().intValue(),blue.getValueState().intValue()).getRGB(),  new Color(red.getValueState().intValue(),green.getValueState().intValue(),blue.getValueState().intValue()).getRGB());
       		
       	 }
       	 Client.instance.fontMgrs.kiona18.drawStringWithShadow1(var22.getName(), (float)(var18 + 1), (float)var20 + (float)var14 * 1.5F+1.5, var22.isEnabled()?-1:11184810);//Color.GRAY.getRGB());
        }

    }

}
	@EventTarget
    public void onKey(EventKeyboard e) {
        switch (e.getKey()) {
            case Keyboard.KEY_UP:
                this.up();
                break;
            case Keyboard.KEY_DOWN:
                this.down();
                break;
            case Keyboard.KEY_RIGHT:
                this.right(Keyboard.KEY_RIGHT);
                break;
            case Keyboard.KEY_LEFT:
                this.left();
                break;
            case Keyboard.KEY_RETURN:
                this.ok(Keyboard.KEY_RETURN);
                break;
        }
    }
	
    
	public void up() {
	      if(this.currentCategoryIndex > 0 && this.screen == 0) {
	         --this.currentCategoryIndex;
	      } else if(this.currentCategoryIndex == 0 && this.screen == 0) {
	         this.currentCategoryIndex = this.categoryValues.size() - 1;
	      } else if(this.currentModIndex > 0 && this.screen == 1) {
	         --this.currentModIndex;
	      } else if(this.currentModIndex == 0 && this.screen == 1) {
	         this.currentModIndex = this.getModsForCurrentCategory().size() - 1;
	      } else if(this.currentSettingIndex > 0 && this.screen == 2) {
	         --this.currentSettingIndex;
	      }

	   }

	   public void down() {
	      if(this.currentCategoryIndex < this.categoryValues.size() - 1 && this.screen == 0) {
	         ++this.currentCategoryIndex;
	      } else if(this.currentCategoryIndex == this.categoryValues.size() - 1 && this.screen == 0) {
	         this.currentCategoryIndex = 0;
	      } else if(this.currentModIndex < this.getModsForCurrentCategory().size() - 1 && this.screen == 1) {
	         ++this.currentModIndex;
	      } else if(this.currentModIndex == this.getModsForCurrentCategory().size() - 1 && this.screen == 1) {
	         this.currentModIndex = 0;
	      }

	   }

	   public void right(int var1) {
	      if(this.screen == 0) {
	         this.screen = 1;
	      } 
	   }

	   public void ok(int var1) {
		   if(this.screen == 1 && this.getCurrentModule() != null) {
		         this.getCurrentModule().toggle();
		      }

		   }
	   
	   public void left() {
	      if(this.screen == 1) {
	         this.screen = 0;
	         this.currentModIndex = 0;
	      } else if(this.screen == 2) {
	         this.screen = 1;
	         this.currentSettingIndex = 0;
	      }

	   }

	   
	   public Category getCurrentCategorry() {
		   return (Category)this.categoryValues.get(this.currentCategoryIndex);
	   }
	   
	   public Mod getCurrentModule() {
		   return (Mod)this.getModsForCurrentCategory().get(this.currentModIndex);
	   }
	   
	   public ArrayList getModsForCurrentCategory() {
		      ArrayList var1 = new ArrayList();
		      Category  var2 = this.getCurrentCategorry();
		      Iterator var4 = ModManager.getModList().iterator();
		      while(var4.hasNext()) {
		    	  Mod var3 = (Mod)var4.next();
		    	  if(var3.getCategory().equals(var2)) {
		              var1.add(var3);
		           }
		      }
		      return var1;
	   }
	   
	   public int getWidestCategory() {
		      int var1 = 0;
		      Iterator var3 = this.categoryValues.iterator();

		      while(var3.hasNext()) {
		         Category var2 = (Category)var3.next();
		         String var4 = var2.name();
		         String p = ">";
	             if(this.screen == 1 || this.screen == 2) {
	            	 p = "<";
	             } else {
	            	 p = ">";
	             }
		         int var5 = Client.instance.fontMgrs.kiona16.getStringWidth(var4.substring(0, 1).toUpperCase() + var4.substring(1, var4.length()).toLowerCase()) + 3;
		         if(var5 > var1) {
		            var1 = var5;
		         }
		      }

		      return var1 + 2;
		   }



	   public int getWidestMod() {
		   int var1 = 0;
		   Iterator var3 = ModManager.getModList().iterator();
		   
		   while(var3.hasNext()) {
			   Mod var2 = (Mod)var3.next();
			   int var4 = Client.instance.fontMgrs.Backs16.getStringWidth(var2.getName());
		         if(var4 > var1) {
		            var1 = var4;
		         }
		   }
		   
		   return var1;
	   }
			
//閼筋垱鎸夐弰鍓с仛

	 @EventTarget
	    public void o(EventRender2D e) {

		 
		 
		 if(this.ArmorHUD.getValueState().booleanValue()) {
				ScaledResolution sr = new ScaledResolution(mc);
				renderStuffStatus3(sr);
				
			}
		
	            ScaledResolution sr = new ScaledResolution(mc);
	            renderPotionStatus(sr);
	            renderPotionStatus1(sr);

	            
	    }
	 
	   public void renderPotionStatus1(ScaledResolution sr2) {
		   if(!this.Effect_mode.isCurrentMode("NONE")) {
			if(this.Effect_mode.isCurrentMode("Backs")) {
	            return;
	        }
	        this.x = 0;
	        for (PotionEffect effect : Minecraft.thePlayer.getActivePotionEffects()) {
	            Potion potion = Potion.potionTypes[effect.getPotionID()];
	            String PType = I18n.format(potion.getName(), new Object[0]);
	            String d2 = "";
	            switch (effect.getAmplifier()) {
	                case 1: {
	                    PType = String.valueOf(PType) + (EnumChatFormatting.DARK_AQUA) + " II";
	                    break;
	                }
	                case 2: {
	                    PType = String.valueOf(PType) + (EnumChatFormatting.BLUE) + " III";
	                    break;
	                }
	                case 3: {
	                    PType = String.valueOf(PType) + (EnumChatFormatting.DARK_PURPLE) + " IV";
	                    break;
	                }
	            }
	            if (effect.getDuration() < 600 && effect.getDuration() > 300) {
	                d2 = (EnumChatFormatting.YELLOW) + Potion.getDurationString(effect);
	            } else if (effect.getDuration() < 300) {
	                d2 = (EnumChatFormatting.RED) + Potion.getDurationString(effect);
	            } else if (effect.getDuration() > 600) {
	                d2 = (EnumChatFormatting.WHITE) + Potion.getDurationString(effect);
	            }
	            final int ychat = -2;
	            int y2 = sr2.getScaledHeight() - this.mc.fontRendererObj.FONT_HEIGHT + this.x - 5;
	            int m2 = 30;
	            this.mc.fontRendererObj.drawStringWithShadow(PType+" : "+d2, sr2.getScaledWidth() - m2 - this.mc.fontRendererObj.getStringWidth(PType) - 1, y2 - this.mc.fontRendererObj.FONT_HEIGHT - 1 - ychat, Colors.BLUE.c);
	            
	            this.x -= 12;
	        }
		   }
	    }
	   
	 
	  
	   
	    public void renderPotionStatus(ScaledResolution sr) {

	    	 if(!this.Effect_mode.isCurrentMode("NONE")) {
	    	if(this.Effect_mode.isCurrentMode("BLC")) {	
				return;
			}
	        int var1 = 1;
	        int var2 = 1;
	        Collection c = this.mc.thePlayer.getActivePotionEffects();
	        if (!c.isEmpty()) {
	            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	            GL11.glDisable(2896);
	            int var6 = -10;
	            int xcount = 0;
	            int ycount = 0;
	            Iterator i = this.mc.thePlayer.getActivePotionEffects().iterator();
	            while (i.hasNext()) {
	                if (xcount >= 3) {
	                    ++ycount;
	                    xcount = 0;
	                }
	                PotionEffect pe = (PotionEffect) i.next();
	                Potion var9 = Potion.potionTypes[pe.getPotionID()];
	                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
	                String thingy = "no";
	                double minutes = -1.0;
	                double seconds = -2.0;
	                try {
	                    minutes = Integer.parseInt((String)Potion.getDurationString((PotionEffect)pe).split(":")[0]);
	                    seconds = Integer.parseInt((String)Potion.getDurationString((PotionEffect)pe).split(":")[1]);
	                } catch (Exception e) {
	                    thingy = "**:**";
	                }
	                double total = minutes * 60.0 + seconds;
	                if (var9.maxtimer == 0 || total > (double)var9.maxtimer) {
	                    var9.maxtimer = (int)total;
	                }
	                double max = 0.0;
	                double percentofmax = 0.0;
	                double percentof360 = 360.0;
	                if (total >= 0.0) {
	                    max = var9.maxtimer;
	                    percentofmax = total / max * 100.0;
	                    percentof360 = 360.0;
	                    if (percentofmax < 100.0) {
	                        percentof360 = 3.6 * percentofmax;
	                    }
	                }
	                if (var9.hasStatusIcon()) {
	                    int n = var9.getStatusIconIndex();
	                }
	                String var12 = StatCollector.translateToLocal((String)var9.getName());
	                String amount = "";
	                if (pe.getAmplifier() == 1) {
	                    var12 = String.valueOf((Object)var12) + " II";
	                    amount = "II";
	                } else if (pe.getAmplifier() == 2) {
	                    var12 = String.valueOf((Object)var12) + " III";
	                    amount = "III";
	                } else if (pe.getAmplifier() == 3) {
	                    var12 = String.valueOf((Object)var12) + " IV";
	                    amount = "IV";
	                } else if(pe.getAmplifier() == 4) {
	                    var12 = String.valueOf((Object)var12) + " V";
	                    amount = "V";
	                } else if(pe.getAmplifier() == 5) {
	                    var12 = String.valueOf((Object)var12) + " VI";
	                    amount = "VI";
	                } else if(pe.getAmplifier() == 6) {
	                    var12 = String.valueOf((Object)var12) + " VII";
	                    amount = "VII";
	                } else if(pe.getAmplifier() == 7) {
	                    var12 = String.valueOf((Object)var12) + " VIII";
	                    amount = "VIII";
	                } else if(pe.getAmplifier() == 8) {
	                    var12 = String.valueOf((Object)var12) + " VIIII";
	                    amount = "VIIII";
	                } else if(pe.getAmplifier() == 9) {
	                    var12 = String.valueOf((Object)var12) + " X";
	                    amount = "X";
	                } else if(pe.getAmplifier() >= 10) {
	                    var12 = String.valueOf((Object)var12) + " X+";
	                    amount = "X+";
	                }
	                int var14 = this.x - this.mc.fontRendererObj.getStringWidth(var12) / 2 - 21;
	                String var11 = Potion.getDurationString((PotionEffect)pe);
	                String name = String.valueOf((Object)var12) + " ?(?" + var11 + "?)";
	                this.s = this.transitionTo(this.s, 11);
	                int color = new Color(0,255,255).getRGB();
	                int xpe = 41 * xcount;
	                int ype = 41 * ycount;
	                if(total <= 10) {
	                    color = new Color(255,0,0).getRGB();
	                } else if (total <= 0.0) {
	                    var9.maxtimer = 0;
	                    color = new Color(255,0,0).getRGB();
	                }
	                if (thingy == "**:**") {
	                    color = new Color(0,255,0).getRGB();
	                }
	                drawFullCircle(sr.getScaledWidth() - 20 - xpe, sr.getScaledHeight() - 45 - (this.s - 10) - ype, 17.5, Integer.MIN_VALUE);
	                drawArc(sr.getScaledWidth() - 20 - xpe, sr.getScaledHeight() - 45 - (this.s - 10) - ype, 18.0, color, 180, 180 + (int)percentof360, 3);
	                GL11.glPushMatrix();
	                GL11.glScaled((double)0.8, (double)0.8, (double)0.8);
	                mc.fontRendererObj.drawStringWithShadow(Potion.getDurationString(pe), (float)(sr.getScaledWidth() - 27 - xpe) / 0.8f, (float)(sr.getScaledHeight() - 47 - (this.s - 10) - ype + 4) / 0.8f, -1);
	                GL11.glPopMatrix();
	                GL11.glPushMatrix();
	                GL11.glScaled((double)0.6, (double)0.6, (double)0.6);
	                mc.fontRendererObj.drawStringWithShadow(amount, ((float)sr.getScaledWidth() - 22f - (float)xpe) / 0.6f, (float)(sr.getScaledHeight() - 32 - (this.s - 10) - ype - 4) / 0.6f, -1);
	                GL11.glPopMatrix();
	                if (var9.hasStatusIcon()) {
	                    int var10 = var9.getStatusIconIndex();
	                    int x1 = sr.getScaledWidth() - 20 - xpe;
	                    int y1 = sr.getScaledHeight() - 45 - (this.s - 10) - ype;
	                    ResourceLocation effect = new ResourceLocation("textures/gui/container/inventory.png");
	                    mc.getTextureManager().bindTexture(effect);
	                    mc.ingameGUI.drawTexturedModalRect(x1 - 9, y1 - 16, 0 + var10 % 8 * 18, 198 + var10 / 8 * 18, 18, 18);
	                }
	                ++xcount;
	                var2 += var6;
	            }
	        }
	        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
	    }
			
	   }
	    //閻╂梻鏁抽弰鍓с仛
	    private void renderStuffStatus3(ScaledResolution scaledRes){
	   		int yOffset = mc.thePlayer.isInsideOfMaterial(Material.water) ? 0 : 0;
	   		for (int slot = 3, xOffset = 0; slot >= 0; slot--) {
	   			ItemStack stack = mc.thePlayer.inventory.armorItemInSlot(slot);
	   			
	   			GuiIngame gi = new GuiIngame(mc);
	   			if (stack != null) {
	   				mc.getRenderItem().renderItemIntoGUI(stack, scaledRes.getScaledWidth() / 2 + 10 - xOffset, scaledRes.getScaledHeight() - 70 - (yOffset / 2) + 15);
	   				GL11.glDisable(GL11.GL_DEPTH_TEST);
	   				GL11.glScalef(0.5F, 0.5F, 0.5F);
	   				mc.fontRendererObj.drawStringWithShadow(stack.getMaxDamage() - stack.getItemDamage() + "", scaledRes.getScaledWidth() + 29 - xOffset * 2 + (stack.getMaxDamage() - stack.getItemDamage() >= 100 ? 4 : (stack.getMaxDamage() - stack.getItemDamage() <= 100 && stack.getMaxDamage() - stack.getItemDamage() >= 10  ? 7 : 11)), scaledRes.getScaledHeight() * 2 - 112 - yOffset + 28, 0xFFFFFF);
	   				GL11.glScalef(2F, 2F, 2F);
	   				GL11.glEnable(GL11.GL_DEPTH_TEST);
	   				xOffset -= 18;
	   			}
	   			

	   			
	   		}
	   		/*ItemStack item = mc.thePlayer.getHeldItem();
	   		int xOffset = 0;
	   		if (item != null) {
   				Object renderStack;
				xOffset -= 8;
				renderStack = item.copy();
				if ((((ItemStack) renderStack).hasEffect())
						&& (((((ItemStack) renderStack).getItem() instanceof ItemTool))
								|| ((((ItemStack) renderStack).getItem() instanceof ItemArmor))))
					((ItemStack) renderStack).stackSize = 1;
				mc.getRenderItem().renderItemIntoGUI((ItemStack) renderStack,scaledRes.getScaledWidth() / 2 - 15 - xOffset, scaledRes.getScaledHeight() - 60 - (yOffset / 2) + 15);
				
				xOffset += 20;
			}*/

	   	}

//閸掑棗澹婄痪锟�
	    public void drawFullCircle(int cx, int cy, double r, int c) {
	    	
	        r *= 2.0;
	        cx *= 2;
	        cy *= 2;
	        float f = (float)(c >> 24 & 255) / 255.0f;
	        float f1 = (float)(c >> 16 & 255) / 255.0f;
	        float f2 = (float)(c >> 8 & 255) / 255.0f;
	        float f3 = (float)(c & 255) / 255.0f;
	        RenderUtils.R2DUtils.enableGL2D();
	        GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
	        GL11.glColor4f((float)f1, (float)f2, (float)f3, (float)f);
	        GL11.glBegin((int)6);
	        int i = 0;
	        while (i <= 360) {
	            double x = Math.sin((double)((double)i * 3.141592653589793 / 180.0)) * r;
	            double y = Math.cos((double)((double)i * 3.141592653589793 / 180.0)) * r;
	            GL11.glVertex2d((double)((double)cx + x), (double)((double)cy + y));
	            ++i;
	        }
	        GL11.glEnd();
	        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
	        RenderUtils.R2DUtils.disableGL2D();
	    }

	    public void drawArc(float cx, float cy, double r, int c, int startpoint, double arc, int linewidth) {
	    
	        r *= 2.0;
	        cx *= 2.0f;
	        cy *= 2.0f;
	        float f = (float)(c >> 24 & 255) / 255.0f;
	        float f1 = (float)(c >> 16 & 255) / 255.0f;
	        float f2 = (float)(c >> 8 & 255) / 255.0f;
	        float f3 = (float)(c & 255) / 255.0f;
	        RenderUtils.R2DUtils.enableGL2D();
	        GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
	        GL11.glLineWidth((float)linewidth);
	        GL11.glEnable((int)2848);
	        GL11.glColor4f((float)f1, (float)f2, (float)f3, (float)f);
	        GL11.glBegin((int)3);
	        int i = startpoint;
	        while ((double)i <= arc) {
	            double x = Math.sin((double)((double)i * 3.141592653589793 / 180.0)) * r;
	            double y = Math.cos((double)((double)i * 3.141592653589793 / 180.0)) * r;
	            GL11.glVertex2d((double)((double)cx + x), (double)((double)cy + y));
	            ++i;
	        }
	        GL11.glEnd();
	        GL11.glDisable((int)2848);
	        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
	        RenderUtils.R2DUtils.disableGL2D();
	    }

	    public int transitionTo(int from, int to) {
	        int i;
	        if (from < to && Minecraft.getDebugFPS() >= 60) {
	            i = 0;
	            while (i < 3) {
	                ++from;
	                ++i;
	            }
	        }
	        if (from > to && Minecraft.getDebugFPS() >= 60) {
	            i = 0;
	            while (i < 3) {
	                --from;
	                ++i;
	            }
	        }
	        if (from < to && Minecraft.getDebugFPS() >= 40 && Minecraft.getDebugFPS() <= 59) {
	            i = 0;
	            while (i < 4) {
	                ++from;
	                ++i;
	            }
	        }
	        if (from > to && Minecraft.getDebugFPS() >= 40 && Minecraft.getDebugFPS() <= 59) {
	            i = 0;
	            while (i < 4) {
	                --from;
	                ++i;
	            }
	        }
	        if (from < to && Minecraft.getDebugFPS() >= 0 && Minecraft.getDebugFPS() <= 39) {
	            i = 0;
	            while (i < 6) {
	                ++from;
	                ++i;
	            }
	        }
	        if (from > to && Minecraft.getDebugFPS() >= 0 && Minecraft.getDebugFPS() <= 39) {
	            i = 0;
	            while (i < 6) {
	                --from;
	                ++i;
	            }
	        }
	        return from;
	    }
	
	
	public enum Direction {
        S("S", 0), 
        SW("SW", 1), 
        W("W", 2), 
        NW("NW", 3), 
        N("N", 4), 
        NE("NE", 5), 
        E("E", 6), 
        SE("SE", 7);
        private Direction(final String s, final int n) {}
    }
    
	public static Color rainbow(long time, float count, float fade) {
        float hue = ((float)time + (10.0E-10F + count) * 4.0E8F) / (8.75f * 0.2E10F)* 3;
        long color = Long.parseLong(Integer.toHexString(Integer.valueOf(Color.HSBtoRGB(hue, 0.5F, 1F)).intValue()), 16);
        Color c = new Color((int)color);
        return new Color((float)c.getRed() / 255.0F * fade, (float)c.getGreen() / 255.0F * fade, (float)c.getBlue() / 255.0F * fade, (float)c.getAlpha() / 255.0F);
    }

    
    
  
    
    
    
    
    
}
