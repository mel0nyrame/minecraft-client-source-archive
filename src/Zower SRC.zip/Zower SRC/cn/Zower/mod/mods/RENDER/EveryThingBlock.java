/*
 * Decompiled with CFR 0_132.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.Zower.mod.mods.RENDER;

import java.awt.Color;
import org.lwjgl.opengl.GL11;


import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;

public class EveryThingBlock
extends Mod {
	public EveryThingBlock() {
		super("EveryThingBlock", Category.RENDER);
    }
}

