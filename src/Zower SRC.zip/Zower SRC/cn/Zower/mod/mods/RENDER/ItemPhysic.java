package cn.Zower.mod.mods.RENDER;

import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;

public class ItemPhysic extends Mod {

	public ItemPhysic() {
		super("ItemPhysic", Category.RENDER);
	}

}
