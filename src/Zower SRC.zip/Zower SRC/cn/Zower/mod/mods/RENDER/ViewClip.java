package cn.Zower.mod.mods.RENDER;

import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;

public class ViewClip extends Mod{
	
	public ViewClip() {
		super("ViewClip", Category.RENDER);
	}
}
