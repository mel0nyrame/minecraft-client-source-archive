package cn.Zower.mod.mods.WORLD;

import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;

public class NameProtect extends Mod {

	public NameProtect() {
		super("NameProtect", Category.RENDER);
	}

}
