package cn.Zower.mod.mods.WORLD;

import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;

public class NoHurtcam extends Mod {
	
	private Object color;

	public NoHurtcam() {
		super("NoHurtcam", Category.RENDER);

	}
		
}


