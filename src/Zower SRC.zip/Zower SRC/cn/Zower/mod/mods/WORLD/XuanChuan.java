package cn.Zower.mod.mods.WORLD;
	import java.util.Random;

import com.darkmagician6.eventapi.EventTarget;

import cn.Zower.Value;
import cn.Zower.events.EventUpdate;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;
import cn.Zower.util.timeUtils.TimeHelper;



	public class XuanChuan extends Mod {
		
		TimeHelper delay = new TimeHelper();
		   public Value<Double> spammerdelay1 = new Value("XuanChuan_Delay", 30d, 0d, 1000d, 1d);
		   		 
		 String intcihui[] = {"[Zower]Ⱥ:1043748943���ȶ��ƹ�Hypixel�����ף�������Ľ�������ƨ����ô�࣡"};
		 
		 
		public XuanChuan() {
			 super("XuanChuan", Category.WORLD);

		}	
		
		   @EventTarget
		   public void onUpdate(EventUpdate event) {
		      Random r = new Random();
		      if(this.delay.isDelayComplete(((Double)this.spammerdelay1.getValueState()).longValue() * 100L)) {
		    	  String fuck = intcihui[r.nextInt(12)];
					mc.thePlayer.sendChatMessage( "[Zower Client] " + fuck);
					delay.reset(); 
		      }
		    	  
		      }
		   
		   
		

	}


