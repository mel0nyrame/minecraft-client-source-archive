/*
 * Decompiled with CFR 0.149.
 */
package cn.Zower.mod.mods.WORLD;

import java.util.ArrayList;

import com.darkmagician6.eventapi.EventTarget;

import cn.Zower.Value;
import cn.Zower.events.EventPacket;
import cn.Zower.events.EventRender;
import cn.Zower.events.EventUpdate;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;
import cn.Zower.ui.Vec3;
import cn.Zower.util.AStarCustomPathFinder;
import cn.Zower.util.NukerUtil;
import cn.Zower.util.PlayerUtil;
import cn.Zower.util.RenderUtil;
import cn.Zower.util.Wrapper;
import cn.Zower.util.timeUtils.TimeHelper;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBed;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;


public class TeleportBedFucker
extends Mod {
    public BlockPos playerBed;
    public BlockPos fuckingBed;
    public ArrayList<BlockPos> posList;
    TimeHelper timer = new TimeHelper();
    public Value<Double> delay = new Value<Double>("TP2Bed_Delay", 600.0, 200.0, 3000.0, 100.0);
    private ArrayList<Vec3> path = new ArrayList();

    public TeleportBedFucker() {
        super("TP2Bed", Category.PLAYER);
    }

    @Override
    public void onEnable() {
        try {
            this.posList = new ArrayList<BlockPos>(NukerUtil.list);
            this.posList.sort((o1, o2) -> {
                double distance1 = this.getDistanceToBlock((BlockPos)o1);
                double distance2 = this.getDistanceToBlock((BlockPos)o2);
                return (int)(distance1 - distance2);
            });
            if (this.posList.size() < 3) {
                this.set(false);
            }
            ArrayList<BlockPos> posListFor = new ArrayList<BlockPos>(this.posList);
            int index = 1;
            for (BlockPos kid : posListFor) {
                if (++index % 2 != 1) continue;
                this.posList.remove(kid);
            }
            this.playerBed = this.posList.get(0);
            this.posList.remove(0);
            if (Minecraft.thePlayer.onGround) {
                if (Minecraft.thePlayer.isCollidedVertically && PlayerUtil.isOnGround(0.01)) {
                    for (int i = 0; i < 49; ++i) {
                        Minecraft.thePlayer.sendQueue.getNetworkManager().sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + 0.06249, Minecraft.thePlayer.posZ, false));
                        Minecraft.thePlayer.sendQueue.getNetworkManager().sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ, false));
                    }
                    Minecraft.thePlayer.onGround = false;
                    PlayerUtil.setMotion(0.0);
                    Minecraft.thePlayer.jumpMovementFactor = 0.0f;
                }
            }
            this.fuckingBed = this.posList.get(0);
        }
        catch (Throwable e) {
            this.set(false);
        }
        super.onEnable();
    }

    @EventTarget
    public void onPacket(EventPacket e) {
        boolean cfr_ignored_0 = e.getPacket() instanceof C03PacketPlayer;
    }

    @Override
    public void onDisable() {
        Wrapper.canSendMotionPacket = true;
        super.onDisable();
    }

    @EventTarget
    public void onRender(EventRender e) {
        try {
            for (Vec3 vec3 : this.path) {
                mc.getRenderManager();
                double x = vec3.getX() - mc.getRenderManager().getRenderPosX();
                mc.getRenderManager();
                double y = vec3.getY() - mc.getRenderManager().getRenderPosY();
                mc.getRenderManager();
                double z = vec3.getZ() - mc.getRenderManager().getRenderPosZ();
                double width = Minecraft.thePlayer.getEntityBoundingBox().maxX - Minecraft.thePlayer.getEntityBoundingBox().minX;
                double height = Minecraft.thePlayer.getEntityBoundingBox().maxY - Minecraft.thePlayer.getEntityBoundingBox().minY + 0.25;
                RenderUtil.drawEntityESP(x, y, z, width, height, 0.0f, 1.0f, 0.0f, 0.2f, 0.0f, 0.0f, 0.0f, 1.0f, 2.0f);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate e) {
        for (BlockPos pos : this.posList) {
            if (Minecraft.theWorld.getBlockState(pos).getBlock() instanceof BlockBed) continue;
            PlayerUtil.tellPlayer("\u00a7b[AzureWare]Destory!" + pos);
            this.posList.remove(pos);
            this.posList.sort((o1, o2) -> {
                double distance1 = this.getDistanceToBlock((BlockPos)o1);
                double distance2 = this.getDistanceToBlock((BlockPos)o2);
                return (int)(distance1 - distance2);
            });
            this.fuckingBed = this.posList.get(0);
        }
        if (Minecraft.thePlayer.getDistance(this.fuckingBed.getX(), this.fuckingBed.getY(), this.fuckingBed.getZ()) < 4.0) {
            Wrapper.canSendMotionPacket = true;
            PlayerUtil.tellPlayer("\u00a7b[AzureWare]Teleported! :3");
            this.set(false);
        }
        if (this.timer.isDelayComplete(this.delay.getValueState())) {
            Vec3 topFrom = new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ);
            Vec3 to = new Vec3(this.fuckingBed.getX() + 1, this.fuckingBed.getY(), this.fuckingBed.getZ() + 1);
            this.path = this.computePath(topFrom, to);
            if (Minecraft.thePlayer.getDistance(this.fuckingBed.getX(), this.fuckingBed.getY(), this.fuckingBed.getZ()) > 4.0) {
                PlayerUtil.tellPlayer("\u00a7b[Hanabi]Trying to teleport...");
                Wrapper.canSendMotionPacket = false;
                for (Vec3 pathElm : this.path) {
                    Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(pathElm.getX(), pathElm.getY(), pathElm.getZ(), true));
                }
            }
            this.timer.reset();
        }
        if (this.posList.size() == 0) {
            this.set(false);
        }
    }

    public double getDistanceToBlock(BlockPos pos) {
        return Minecraft.thePlayer.getDistance(pos.getX(), pos.getY(), pos.getZ());
    }

    private boolean canPassThrow(BlockPos pos) {
        Minecraft.getMinecraft();
        Block block = Minecraft.theWorld.getBlockState(new BlockPos(pos.getX(), pos.getY(), pos.getZ())).getBlock();
        return block.getMaterial() == Material.air || block.getMaterial() == Material.plants || block.getMaterial() == Material.vine || block == Blocks.ladder || block == Blocks.water || block == Blocks.flowing_water || block == Blocks.wall_sign || block == Blocks.standing_sign;
    }

    private ArrayList<Vec3> computePath(Vec3 topFrom, Vec3 to) {
        if (!this.canPassThrow(new BlockPos(topFrom.mc()))) {
            topFrom = topFrom.addVector(0.0, 1.0, 0.0);
        }
        AStarCustomPathFinder pathfinder = new AStarCustomPathFinder(topFrom, to);
        pathfinder.compute();
        int i = 0;
        Vec3 lastLoc = null;
        Vec3 lastDashLoc = null;
        ArrayList<Vec3> path = new ArrayList<Vec3>();
        ArrayList<Vec3> pathFinderPath = pathfinder.getPath();
        for (Vec3 pathElm : pathFinderPath) {
            if (i == 0 || i == pathFinderPath.size() - 1) {
                if (lastLoc != null) {
                    path.add(lastLoc.addVector(0.5, 0.0, 0.5));
                }
                path.add(pathElm.addVector(0.5, 0.0, 0.5));
                lastDashLoc = pathElm;
            } else {
                boolean canContinue = true;
                if (pathElm.squareDistanceTo(lastDashLoc) > 25.0) {
                    canContinue = false;
                } else {
                    double smallX = Math.min(lastDashLoc.getX(), pathElm.getX());
                    double smallY = Math.min(lastDashLoc.getY(), pathElm.getY());
                    double smallZ = Math.min(lastDashLoc.getZ(), pathElm.getZ());
                    double bigX = Math.max(lastDashLoc.getX(), pathElm.getX());
                    double bigY = Math.max(lastDashLoc.getY(), pathElm.getY());
                    double bigZ = Math.max(lastDashLoc.getZ(), pathElm.getZ());
                    int x = (int)smallX;
                    block1 : while ((double)x <= bigX) {
                        int y = (int)smallY;
                        while ((double)y <= bigY) {
                            int z = (int)smallZ;
                            while ((double)z <= bigZ) {
                                if (!AStarCustomPathFinder.checkPositionValidity(x, y, z, false)) {
                                    canContinue = false;
                                    break block1;
                                }
                                ++z;
                            }
                            ++y;
                        }
                        ++x;
                    }
                }
                if (!canContinue) {
                    path.add(lastLoc.addVector(0.5, 0.0, 0.5));
                    lastDashLoc = lastLoc;
                }
            }
            lastLoc = pathElm;
            ++i;
        }
        return path;
    }
}

