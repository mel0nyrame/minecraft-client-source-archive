package cn.Zower.mod.mods.PLAYER;

import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;

public class Title extends Mod{
	
	public Title() {
		super("Title", Category.PLAYER);
	}
}
