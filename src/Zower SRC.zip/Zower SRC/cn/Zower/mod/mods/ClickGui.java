package cn.Zower.mod.mods;

import org.lwjgl.input.Keyboard;

import cn.Zower.Client;
import cn.Zower.Value;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;
import cn.Zower.ui.Novoline.NClickGui;
import cn.Zower.ui.Worst.WorstClickGui;




public class ClickGui extends Mod {
	public static Value<Boolean> snowflake = new Value("ClickGui_snowflake", false);
	public static Value<Boolean> Sound = new Value("ClickGui_Sound", true);
	public static Value<Boolean> Open = new Value("ClickGui_Prompt", true);
	public static Value<Boolean> Cape = new Value("ClickGui_Cape", true);
	 public static Value<Double> red = new Value<Double> ("ClickGui_Red", 0.0, 0.0, 255.0, 1.0);
	  public static Value<Double> green = new Value<Double>("ClickGui_Green", 125.0, 0.0, 255.0 ,1.0);
	  public static Value<Double> blue = new Value<Double>("ClickGui_Blue", 255.0, 0.0, 255.0, 1.0);
      private static Value mode = new Value("ClickGui", "Mode", 0);
	public ClickGui() {
		super("ClickGui", Category.RENDER);
		this.setKey(Keyboard.KEY_RSHIFT);
		mode.addValue("Zower");
        mode.addValue("Novoline");
	}
	
	@Override
	public void onEnable() {
		  if(mode.isCurrentMode("Zower")) {
		this.mc.displayGuiScreen(new WorstClickGui());
		this.set(false);
	}
		  if(mode.isCurrentMode("Backs")) {
				this.mc.displayGuiScreen(Client.instance.showClickGui());
				this.set(false);
			}
		  if(mode.isCurrentMode("Novoline")) {
				this.mc.displayGuiScreen(new NClickGui());
				this.set(false);
			}
	}
}
