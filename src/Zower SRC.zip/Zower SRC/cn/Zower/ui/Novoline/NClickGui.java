package cn.Zower.ui.Novoline;

import java.awt.Color;

import org.lwjgl.input.Mouse;

import cn.Zower.Client;
import cn.Zower.Value;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;
import cn.Zower.mod.ModManager;
import cn.Zower.ui.Worst.RenderUtil;
import cn.Zower.ui.font.FontLoaders;
import cn.Zower.util.fontRenderer.UnicodeFontRenderer;
import cn.Zower.util.fontRenderer.CFont.CFontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiYesNoCallback;

public class NClickGui extends GuiScreen implements GuiYesNoCallback {
	public static Category currentModuleType = Category.COMBAT;
	public static Mod currentModule = ModManager.getInType(currentModuleType).size() != 0
			? ModManager.getInType(currentModuleType).get(0)
			: null;
	public static float startX = 100, startY = 100;
	public int moduleStart = 0;
	public int valueStart = 0;

	boolean previousmouse = true;
	boolean mouse;
	public int opacityx = 255;
	public float moveX = 0, moveY = 0;

	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		if (isHovered(startX, startY - 25, startX + 400, startY + 25, mouseX, mouseY) && Mouse.isButtonDown(0)) {
			if (moveX == 0 && moveY == 0) {
				moveX = mouseX - startX;
				moveY = mouseY - startY;
			} else {
				startX = mouseX - moveX;
				startY = mouseY - moveY;
			}
			this.previousmouse = true;
		} else if (moveX != 0 || moveY != 0) {
			moveX = 0;
			moveY = 0;
		}
	
		RenderUtil.drawRoundedRect(startX, startY, startX + 340, startY + 305,3F,
				new Color(32, 34, 37, 255).getRGB());
		RenderUtil.drawRect(startX+50, startY+12, startX + 165, startY + 304,
				new Color(47, 49, 54, 255).getRGB());
		RenderUtil.drawRect(startX+165, startY+12, startX + 340, startY + 304,
				new Color(54, 57, 62, 255).getRGB());
		FontLoaders.Parke12.drawString("Zower X", startX + 10, startY + 5,(new Color(255, 255, 255)).getRGB());        
		for (int i = 0; i < Category.values().length; i++) {
			Category[] iterator = Category.values();
			if (iterator[i] != currentModuleType) {
				RenderUtil.drawFilledCircle(startX + 25, startY + 70 + i * 35, 15,
						new Color(56, 56, 56, 255).getRGB(), 5);
			} else {
				RenderUtil.drawFilledCircle(startX + 25, startY + 70 + i * 35, 15,
						new Color(101, 81, 255, 255).getRGB(), 5);
			}
			try {
				if (this.isCategoryHovered(startX +10, startY + 55 + i * 35, startX + 40, startY + 85 + i * 35, mouseX,
						mouseY) && Mouse.isButtonDown((int) 0)) {
					currentModuleType = iterator[i];
					currentModule = ModManager.getInType(currentModuleType).size() != 0
							? ModManager.getInType(currentModuleType).get(0)
							: null;
					moduleStart = 0;
				}
			} catch (Exception e) {
				System.err.println(e);
			}
		}

		//System.out.println(currentModule.getValues().size());

		int m = Mouse.getDWheel();
		if (this.isCategoryHovered(startX + 60, startY, startX + 200, startY + 320, mouseX, mouseY)) {
			if (m < 0 && moduleStart < ModManager.getInType(currentModuleType).size() - 1) {
				moduleStart++;
			}
			if (m > 0 && moduleStart > 0) {
				moduleStart--;
			}
		}
		if (this.isCategoryHovered(startX + 200, startY, startX + 420, startY + 320, mouseX, mouseY)) {
			if (m < 0 && valueStart < currentModule.getValues().size() - 1) {
				valueStart++;
			}
			if (m > 0 && valueStart > 0) {
				valueStart--;
			}
		}
		Client.fontManager.tahoma15.drawString(
				currentModule == null ? currentModuleType.toString()
						: currentModuleType.toString() + "/" + currentModule.getName(),
				startX + 70, startY + 15, new Color(248, 248, 248).getRGB(), false);
		if (currentModule != null) {
			float mY = startY + 30;
			for (int i = 0; i < ModManager.getInType(currentModuleType).size(); i++) {
				Mod module = ModManager.getInType(currentModuleType).get(i);
				if (mY > startY + 300)
					break;
				if (i < moduleStart) {
					continue;
				}

				
				Client.fontManager.tahoma15.drawString(module.getName(), startX + 90, mY + 8,
						new Color(248, 248, 248, 255).getRGB(), false);
				if (!module.isEnabled()) {
					RenderUtil.drawFilledCircle(startX + 75, mY + 13, 2,
							new Color(255, 0, 0, 255).getRGB(), 5);
				} else {
					RenderUtil.drawFilledCircle(startX + 75, mY + 13, 2,
							new Color(0, 255, 0, 255).getRGB(), 5);
				}
				if (isSettingsButtonHovered(startX + 90, mY,
						startX + 100 + (Client.fontManager.tahoma20.getStringWidth(module.getName())),
						mY + 8 + Client.fontManager.tahoma20.FONT_HEIGHT, mouseX, mouseY)) {
					if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
						if (module.isEnabled()) {
							module.set(false);
						} else {
							module.set(true);
						}
						previousmouse = true;
					}
					if (!this.previousmouse && Mouse.isButtonDown((int) 1)) {
						previousmouse = true;
					}
				}

				if (!Mouse.isButtonDown((int) 0)) {
					this.previousmouse = false;
				}
				if (isSettingsButtonHovered(startX + 90, mY,
						startX + 100 + (Client.fontManager.tahoma20.getStringWidth(module.getName())),
						mY + 8 + Client.fontManager.tahoma20.FONT_HEIGHT, mouseX, mouseY) && Mouse.isButtonDown((int) 1)) {
					currentModule = module;
					valueStart = 0;
				}
				mY += 25;
			}
			mY = startY + 30;
			for (int i = 0; i < currentModule.getValues().size(); i++) {
				if (mY > startY + 300)
					break;
				if (i < valueStart) {
					continue;
				}
				UnicodeFontRenderer font = Client.fontManager.tahoma15;
				Value value = currentModule.getValues().get(i);
				if (value.isValueDouble||value.isValueByte||value.isValueFloat||value.isValueInteger||value.isValueLong) {
					float x = startX + 300;
					double state = (double) value.getValueState();
					double min = (double) value.getValueMin();
					double max = (double) value.getValueMax();
					double render =  (68.0F * ((state - min) / (max - min)));
					RenderUtil.drawRect((float) x - 6, mY + 2, (float) ((double) x + 75), mY + 3,
							(new Color(50, 50, 50, 255)).getRGB());
					RenderUtil.drawRect((float) x - 6, mY + 2, (float) ((double) x + render + 6.5D), mY + 3,
							(new Color(61, 141, 255, 255)).getRGB());
					RenderUtil.drawRect((float) ((double) x + render + 2D), mY, (float) ((double) x + render + 7D),
							mY + 5, (new Color(61, 141, 255, 255)).getRGB());
					font.drawStringWithShadow(value.getDisplayTitle() + ": " + value.getValueState(), startX + 210, mY, -1);

					if (!Mouse.isButtonDown((int) 0)) {
						this.previousmouse = false;
					}

					if (this.isButtonHovered(x, mY - 2, x + 100, mY + 7, mouseX, mouseY)
							&& Mouse.isButtonDown((int) 0)) {
						if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
							render = (double) value.getValueMin();
							max = (double) value.getValueMax();
							double inc = 0.1;
							double valAbs = (double) mouseX - ((double) x + 1.0D);
							double perc = valAbs / 68.0D;
							perc = Math.min(Math.max(0.0D, perc), 1.0D);
							double valRel = (max - render) * perc;
							double val = render + valRel;
							val = (double) Math.round(val * (1.0D / inc)) / (1.0D / inc);
							double num =Double.valueOf(val);
							value.setValueState((double)num);
						}
						if (!Mouse.isButtonDown((int) 0)) {
							this.previousmouse = false;
						}
					}
					mY += 20;
				}


				if (value.isValueBoolean) {
					float x = startX + 300;
					font.drawStringWithShadow(value.getDisplayTitle(), startX + 210, mY, -1);
					RenderUtil.drawRect(x + 56, mY, x + 76, mY + 1,
							new Color(255, 255, 255, 255).getRGB());
					RenderUtil.drawRect(x + 56, mY + 8, x + 76, mY + 9,
							new Color(255, 255, 255, 255).getRGB());
					RenderUtil.drawRect(x + 56, mY, x + 57, mY + 9,
							new Color(255, 255, 255, 255).getRGB());
					RenderUtil.drawRect(x + 77, mY, x + 76, mY + 9,
							new Color(255, 255, 255, 255).getRGB());
					if ((boolean) value.getValueState()) {
						RenderUtil.drawRect(x + 67, mY + 2, x + 75, mY + 7,
								new Color(61, 141, 255, 255).getRGB());
					} else {
						RenderUtil.drawRect(x + 58, mY + 2, x + 65, mY + 7,
								new Color(150, 150, 150, 255).getRGB());
					}
					if (this.isCheckBoxHovered(x + 56, mY, x + 76, mY + 9, mouseX, mouseY)) {
						if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
							this.previousmouse = true;
							this.mouse = true;
						}

						if (this.mouse) {
							value.setValueState(!(boolean) value.getValueState());
							this.mouse = false;
						}
					}
					if (!Mouse.isButtonDown((int) 0)) {
						this.previousmouse = false;
					}
					mY += 20;
				}
				if (value.isValueMode) {
					float x = startX + 300;
					font.drawStringWithShadow(value.getDisplayTitle(), startX + 210, mY, -1);
					RenderUtil.drawRect(x - 5, mY - 5, x + 90, mY + 15,
							new Color(56, 56, 56, 255).getRGB());
					RenderUtil.drawRect(x - 5, mY - 5, x + 90, mY + 15,
							new Color(101, 81, 255, 255).getRGB());
					font.drawStringWithShadow(value.getModeAt((value).getCurrentMode()),
							(float) (x + 40 - font.getStringWidth(value.getModeAt((value).getCurrentMode())) / 2), mY, -1);
					if (this.isStringHovered(x, mY - 5, x + 100, mY + 15, mouseX, mouseY)) {
						if (Mouse.isButtonDown((int) 0) && !this.previousmouse) {
							String current = value.getModeAt((value).getCurrentMode());
							int next = 0;
							if((value).getCurrentMode()+1<(value).listModes().size()){
								next = (value).getCurrentMode()+1;
							}
							value.setCurrentMode(next);
							this.previousmouse = true;
						}
						if (!Mouse.isButtonDown((int) 0)) {
							this.previousmouse = false;
						}

					}
					mY += 25;
				}
			}
		}

	}

	public boolean isStringHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
		if (mouseX >= f && mouseX <= g && mouseY >= y && mouseY <= y2) {
			return true;
		}

		return false;
	}

	public boolean isSettingsButtonHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
		if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
			return true;
		}

		return false;
	}

	public boolean isButtonHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
		if (mouseX >= f && mouseX <= g && mouseY >= y && mouseY <= y2) {
			return true;
		}

		return false;
	}

	public boolean isCheckBoxHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
		if (mouseX >= f && mouseX <= g && mouseY >= y && mouseY <= y2) {
			return true;
		}

		return false;
	}

	public boolean isCategoryHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
		if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
			return true;
		}

		return false;
	}

	public boolean isHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
		if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
			return true;
		}

		return false;
	}

}
