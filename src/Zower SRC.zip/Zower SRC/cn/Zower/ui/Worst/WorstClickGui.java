package cn.Zower.ui.Worst;

import java.awt.Color;
import java.util.ArrayList;

import org.lwjgl.input.Mouse;

import cn.Zower.Client;
import cn.Zower.Value;
import cn.Zower.mod.Category;
import cn.Zower.mod.Mod;
import cn.Zower.mod.ModManager;
import cn.Zower.mod.mods.ClickGui;
import cn.Zower.ui.Particle;
import cn.Zower.ui.click.buttons.UIPopUPButton;
import cn.Zower.ui.font.FontLoaders;
import cn.Zower.util.RenderUtils;
import cn.Zower.util.fontRenderer.FontManager;
import cn.Zower.util.fontRenderer.UnicodeFontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;

public class WorstClickGui extends GuiScreen implements GuiYesNoCallback {
	public static Category currentModuleType = Category.COMBAT;
    private UIPopUPButton uiPopUPButton;
    private ScaledResolution res;
    public boolean initialized;
    private ArrayList<Particle> particles;
	public static Mod currentModule = ModManager.getInType(currentModuleType).size() != 0
			? ModManager.getInType(currentModuleType).get(0)
			: null;
	public static float startX = 100, startY = 100;
	public int moduleStart = 0;
	public int valueStart = 0;
	boolean previousmouse = true;
	public Opacity opacity = new Opacity(0);
	boolean mouse;
	public int opacityx = 255;
	public float moveX = 0, moveY = 0;
	public Mod bmod;

	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		
		if (isHovered(startX, startY - 25, startX + 400, startY + 25, mouseX, mouseY) && Mouse.isButtonDown(0)) {
			if (moveX == 0 && moveY == 0) {
				moveX = mouseX - startX;
				moveY = mouseY - startY;
			} else {
				startX = mouseX - moveX;
				startY = mouseY - moveY;
			}
			this.previousmouse = true;
		} else if (moveX != 0 || moveY != 0) {
			moveX = 0;
			moveY = 0;
		}
		 RenderUtil.drawRoundedRect(this.startX - 1, this.startY - 1, this.startX + 370 + 1, this.startY + 230 + 1,  3F,new Color(11, 84, 150,150).getRGB());
	        RenderUtil.drawRoundedRect(this.startX, this.startY, this.startX + 370, this.startY + 230,2F, new Color(240, 240, 240).getRGB());
	        RenderUtil.drawRect(this.startX, this.startY+20.5, this.startX + 370, this.startY + 20, new Color(230, 230, 230,140).getRGB());
	        RenderUtil.drawRect(this.startX, this.startY+23, this.startX + 370, this.startY + 20, new Color(230, 230, 230,130).getRGB());
	        RenderUtil.drawRect(this.startX+80, this.startY+20.3, this.startX + 180, this.startY + 230, new Color(230, 230, 230).getRGB());
	        RenderUtil.drawRect(this.startX+80, this.startY+20.3, this.startX + 80.8, this.startY + 230, new Color(221, 221, 221,200).getRGB());
	        RenderUtil.drawRect(this.startX+80.8, this.startY+20.3, this.startX + 81.6, this.startY + 230, new Color(222, 222, 222,200).getRGB());
	        RenderUtil.drawRect(this.startX+81.6, this.startY+20.3, this.startX + 82.4, this.startY + 230, new Color(223, 223, 223,200).getRGB());
	        RenderUtil.drawRect(this.startX+82.4, this.startY+20.3, this.startX + 83.2, this.startY + 230, new Color(224, 224, 224,200).getRGB());
	        RenderUtil.drawRect(this.startX+83.2, this.startY+20.3, this.startX + 84, this.startY + 230, new Color(225, 225, 225,200).getRGB());
	        RenderUtil.drawRect(this.startX+84, this.startY+20.3, this.startX + 84.8, this.startY + 230, new Color(226, 226, 226,200).getRGB());
	        RenderUtil.drawRect(this.startX+84.8, this.startY+20.3, this.startX + 85.8, this.startY + 230, new Color(227, 227, 227,190).getRGB());
	        RenderUtil.drawRect(this.startX+85.8, this.startY+20.3, this.startX + 90, this.startY + 230, new Color(228, 228, 228,110).getRGB());
	        
	        Client.fontManager.tahoma20.drawString("Zower X", startX + 20, startY + 5,(new Color(152, 152, 152)).getRGB());        
		for (int i = 0; i < Category.values().length; i++) {
			Category[] iterator = Category.values();
			if (iterator[i] != currentModuleType) {
				RenderUtil.circle(startX + 30, startY + 50 + i * 20, 6,new Color(255, 255, 255,0).getRGB());
			} else {
				//RenderUtil.drawBorderedRect(startX+1, startY+1, startX+30, startY+30, 3, new Color(255, 255, 255,100).getRGB(), new Color(255, 255, 255 ,180).getRGB());
				//RenderUtils.circle(startX + 30, startY + 50 + i * 20, 6,new Color(255, 255, 250, (int) opacity.getOpacity()).getRGB());
			}
			try {
				if (this.isCategoryHovered(startX + 15, startY + 40 + i * 20, startX + 60, startY + 50 + i * 20, mouseX,
						mouseY) && Mouse.isButtonDown((int) 0)) {
					currentModuleType = iterator[i];
					currentModule = ModManager.getInType(currentModuleType).size() != 0
							? ModManager.getInType(currentModuleType).get(0)
							: null;
					moduleStart = 0;
				}
			} catch (Exception e) {
				System.err.println(e);
			}
		}

		//System.out.println(currentModule.getValues().size());

		int m = Mouse.getDWheel();
		if (this.isCategoryHovered(startX + 60, startY, startX + 200, startY + 320, mouseX, mouseY)) {
			if (m < 0 && moduleStart < ModManager.getInType(currentModuleType).size() - 1) {
				moduleStart++;
			}
			if (m > 0 && moduleStart > 0) {
				moduleStart--;
			}
		}
		if (this.isCategoryHovered(startX + 200, startY, startX + 420, startY + 320, mouseX, mouseY)) {
			if (m < 0 && valueStart < currentModule.getValues().size() - 1) {
				valueStart++;
			}
			if (m > 0 && valueStart > 0) {
				valueStart--;
			}
		}
		
		Client.fontManager.tahoma20.drawString(
				currentModule == null ? currentModuleType.toString()
						: currentModuleType.toString() ,
				startX + 85, startY + 5, new Color(152,152,152).getRGB());
		Client.fontManager.tahoma20.drawString(
				currentModule == null ? currentModuleType.toString()
						: "Module:"+ currentModule.getName(),
				startX + 185, startY + 5, new Color(152,152,152).getRGB());
		if (currentModule != null) {
			float mY = startY + 30;
			for (int i = 0; i < ModManager.getInType(currentModuleType).size(); i++) {
				Mod module = ModManager.getInType(currentModuleType).get(i);
				if (mY > startY + 200)
					break;
				if (i < moduleStart) {
					continue;
				}

				RenderUtil.drawRoundedRect(startX +88, mY+8 , startX + 175, mY + 25,8F, new Color(220, 220, 220).getRGB());
				Client.fontManager.tahoma20.drawString(module.getName(), startX + 108, mY + 11,
						new Color(130,130,130, (int) opacity.getOpacity()).getRGB());
				RenderUtil.circle(startX +95, mY+16 , 2, new Color(152,152,152).getRGB());
				if (module.isEnabled()) {
					RenderUtil.drawRoundedRect(startX +88, mY+8 , startX + 175, mY + 25,8F, new Color(210, 210, 210).getRGB());
					Client.fontManager.tahoma20.drawString(module.getName(), startX + 108, mY + 11,
							new Color(152,152,152, (int) opacity.getOpacity()).getRGB());
					RenderUtil.circle(startX +95, mY+16 , 2, new Color(0, 100, 237).getRGB());
				}
			
				if (isSettingsButtonHovered(startX + 90, mY,
						startX + 100 + (Client.fontManager.tahoma20.getStringWidth(module.getName())),
						mY + 8 + Client.fontManager.tahoma20.FONT_HEIGHT, mouseX, mouseY)) {
					if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
						
						if (module.isEnabled()) {
							module.set(false);
						} else {
							module.set(true);
						}
						previousmouse = true;
					}
					if (!this.previousmouse && Mouse.isButtonDown((int) 1)) {
						previousmouse = true;
					}
				}

				if (!Mouse.isButtonDown((int) 0)) {
					this.previousmouse = false;
				}
				if(module.getValues().size()>0) {
	    			Client.fontManager.tahoma18.drawString("+", startX +167, mY+10 , new Color(150,150,150).getRGB());
	    		}
				if (isSettingsButtonHovered(startX + 90, mY,
						startX + 100 + (Client.fontManager.tahoma20.getStringWidth(module.getName())),
						mY + 8 + Client.fontManager.tahoma20.FONT_HEIGHT, mouseX, mouseY) && Mouse.isButtonDown((int) 1)) {
					currentModule = module;
					valueStart = 0;
				}
				mY += 18;
			}
			mY = startY + 25;
			for (int i = 0; i < currentModule.getValues().size(); i++) {
				if (mY > startY + 215)
					break;
				if (i < valueStart) {
					continue;
				}
				UnicodeFontRenderer font = Client.fontManager.tahoma17;
				Value value = currentModule.getValues().get(i);
				if (value.isValueDouble||value.isValueByte||value.isValueFloat||value.isValueInteger||value.isValueLong) {
					float x = startX + 280;
					double state = (double) value.getValueState();
					double min = (double) value.getValueMin();
					double max = (double) value.getValueMax();
					double render =  (68.0F * ((state - min) / (max - min)));
					RenderUtil.drawRect((float) x - 6, mY + 2, (float) ((double) x + 75), mY + 3,
							(new Color(50, 50, 50, 255)).getRGB());
					RenderUtil.drawRect((float) x - 6, mY + 2, (float) ((double) x + render + 6.5D), mY + 3,
							(new Color(0, 100, 237, 255)).getRGB());
					RenderUtil.circle((float)(x + render + 4), (float)mY+2, 2F, new Color(0, 100, 237).getRGB());
					font.drawString(value.getDisplayTitle() + ": " + value.getValueState(), startX + 190, mY,new Color(152,152,152).getRGB());
					if (!Mouse.isButtonDown((int) 0)) {
						this.previousmouse = false;
					}

					if (this.isButtonHovered(x, mY - 2, x + 100, mY + 7, mouseX, mouseY)
							&& Mouse.isButtonDown((int) 0)) {
						if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
							render = (double) value.getValueMin();
							max = (double) value.getValueMax();
							double inc = 0.1;
							double valAbs = (double) mouseX - ((double) x + 1.0D);
							double perc = valAbs / 68.0D;
							perc = Math.min(Math.max(0.0D, perc), 1.0D);
							double valRel = (max - render) * perc;
							double val = render + valRel;
							val = (double) Math.round(val * (1.0D / inc)) / (1.0D / inc);
							double num =Double.valueOf(val);
							value.setValueState((double)num);
						}
						if (!Mouse.isButtonDown((int) 0)) {
							this.previousmouse = false;
						}
					}
					mY += 20;
				}


				if (value.isValueBoolean) {
					float x = startX + 230;
					font.drawString(value.getDisplayTitle(), startX + 190, mY, new Color(152,152,152).getRGB());
					//RenderUtil.drawRect(x + 56, mY , x + 76, mY + 9,
						//	new Color(240, 240, 240, (int) opacity.getOpacity()).getRGB());
					
					if ((boolean) value.getValueState()) {
						RenderUtil.drawRoundedRect(x + 56, mY-1 , x + 76, mY + 9,4F, new Color(58, 58, 58).getRGB());
						//RenderUtil.drawRect(x + 56, mY-1 , x + 76, mY + 9,
							//	new Color(220, 220, 255, (int) opacity.getOpacity()).getRGB());
						RenderUtil.circle(x+72, mY+4, 4, new Color(0, 100, 237).getRGB());
					} else {
						RenderUtil.drawRoundedRect(x + 56, mY-1 , x + 76, mY + 9,4F, new Color(58, 58, 58).getRGB());
						RenderUtil.circle(x+60, mY+4, 4, new Color(152,152,152).getRGB());
					}
					if (this.isCheckBoxHovered(x + 56, mY, x + 76, mY + 9, mouseX, mouseY)) {
						if (!this.previousmouse && Mouse.isButtonDown((int) 0)) {
							this.previousmouse = true;
							this.mouse = true;
						}

						if (this.mouse) {
							value.setValueState(!(boolean) value.getValueState());
							this.mouse = false;
						}
					}
					if (!Mouse.isButtonDown((int) 0)) {
						this.previousmouse = false;
					}
					mY += 20;
				}
				if (value.isValueMode) {
					float x = startX + 280;
					font.drawString(value.getDisplayTitle(), startX + 190, mY, new Color(152, 152, 152, (int) opacity.getOpacity()).getRGB() );

					RenderUtil.drawRect(x +20, mY, x + 65, mY + 10,
							new Color(120, 120, 120, (int) opacity.getOpacity()).getRGB() );
					RenderUtil.drawRect(x+5, mY, x+15, mY + 10,
							new Color(0, 100, 237, (int) opacity.getOpacity()).getRGB() );
					RenderUtil.drawRect(x+70, mY, x+80, mY + 10,
							new Color(0, 100, 237, (int) opacity.getOpacity()).getRGB() );
					font.drawStringWithShadow("<",x +8, mY, new Color(152, 152, 152, (int) opacity.getOpacity()).getRGB() );
					font.drawStringWithShadow(">",x +72, mY, new Color(152, 152, 152, (int) opacity.getOpacity()).getRGB() );
					font.drawStringWithShadow(value.getModeAt((value).getCurrentMode()),
							(float) (x + 40 - font.getStringWidth(value.getModeAt((value).getCurrentMode())) / 2), mY, -1);
					if (this.isStringHovered(x, mY - 5, x + 100, mY + 15, mouseX, mouseY)) {
						if (Mouse.isButtonDown((int) 0) && !this.previousmouse) {
							String current = value.getModeAt((value).getCurrentMode());
							int next = 0;
							if((value).getCurrentMode()+1<(value).listModes().size()){
								next = (value).getCurrentMode()+1;
							}
							value.setCurrentMode(next);
							this.previousmouse = true;
						}
						if (!Mouse.isButtonDown((int) 0)) {
							this.previousmouse = false;
						}

					}
					mY += 25;
				}
				 
				
			
			}
			switch(currentModuleType.name()) {
		  	case "COMBAT":
		  		Client.fontManager.tahoma25.drawString("Render", startX + 25, startY + 60,(new Color(152, 152, 152)).getRGB());        
				 Client.fontManager.tahoma25.drawString("Combot", startX + 25, startY + 40,(new Color(9, 157, 227)).getRGB());
		       Client.fontManager.tahoma25.drawString("Move", startX + 25, startY + 80,(new Color(152, 152, 152)).getRGB());
		       Client.fontManager.tahoma25.drawString("Player", startX + 25, startY + 100,(new Color(152, 152, 152)).getRGB());
		       Client.fontManager.tahoma25.drawString("World", startX + 25, startY + 120,(new Color(152, 152, 152)).getRGB());
		   	RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/"+currentModuleType+2+".png"), (int)startX+5, (int)startY+40,14,14);
			RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Render.png"), (int)startX+5, (int)startY+60,14,14);
			RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Movement.png"), (int)startX+5, (int)startY+80,14,14);
			RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Player.png"), (int)startX+5, (int)startY+100,14,14);
			RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/World.png"), (int)startX+5, (int)startY+120,14,14);
		  		break;
		  	case "RENDER":
		  		Client.fontManager.tahoma25.drawString("Render", startX + 25, startY + 60,(new Color(0, 100, 237)).getRGB());        
				 Client.fontManager.tahoma25.drawString("Combot", startX + 25, startY + 40,(new Color(152, 152, 152)).getRGB());    
		       Client.fontManager.tahoma25.drawString("Move", startX + 25, startY + 80,(new Color(152, 152, 152)).getRGB());
		       Client.fontManager.tahoma25.drawString("Player", startX + 25, startY + 100,(new Color(152, 152, 152)).getRGB());
		       Client.fontManager.tahoma25.drawString("World", startX + 25, startY + 120,(new Color(152, 152, 152)).getRGB());
			RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Combat.png"), (int)startX+5, (int)startY+40,14,14);
			RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/"+currentModuleType+2+".png"), (int)startX+5, (int)startY+60,14,14);
			RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Movement.png"), (int)startX+5, (int)startY+80,14,14);
			RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Player.png"), (int)startX+5, (int)startY+100,14,14);
			RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/World.png"), (int)startX+5, (int)startY+120,14,14);
		  		break;
		  	case "MOVEMENT":
		  		Client.fontManager.tahoma25.drawString("Render", startX + 25, startY + 60,(new Color(152, 152, 152)).getRGB());        
		  		 Client.fontManager.tahoma25.drawString("Combot", startX + 25, startY + 40,(new Color(152, 152, 152)).getRGB());
		       Client.fontManager.tahoma25.drawString("Move", startX + 25, startY + 80,(new Color(0, 100, 237)).getRGB());  
		       Client.fontManager.tahoma25.drawString("Player", startX + 25, startY + 100,(new Color(152, 152, 152)).getRGB());
		       Client.fontManager.tahoma25.drawString("World", startX + 25, startY + 120,(new Color(152, 152, 152)).getRGB());
		     
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Combat.png"), (int)startX+5, (int)startY+40,14,14);
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Render.png"), (int)startX+5, (int)startY+60,14,14);
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/"+currentModuleType+2+".png"), (int)startX+5, (int)startY+80,14,14);
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Player.png"), (int)startX+5, (int)startY+100,14,14);
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/World.png"), (int)startX+5, (int)startY+120,14,14);
		  		break;
		  	case "PLAYER":
		  		Client.fontManager.tahoma25.drawString("Render", startX + 25, startY + 60,(new Color(152, 152, 152)).getRGB());        
				 Client.fontManager.tahoma25.drawString("Combot", startX + 25, startY + 40,(new Color(152, 152, 152)).getRGB());
		       Client.fontManager.tahoma25.drawString("Move", startX + 25, startY + 80,(new Color(152, 152, 152)).getRGB());
		       Client.fontManager.tahoma25.drawString("Player", startX + 25, startY + 100,(new Color(0, 100, 237)).getRGB());
		       Client.fontManager.tahoma25.drawString("World", startX + 25, startY + 120,(new Color(152, 152, 152)).getRGB());
		
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Combat.png"), (int)startX+5, (int)startY+40,14,14);
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Render.png"), (int)startX+5, (int)startY+60,14,14);
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Movement.png"), (int)startX+5, (int)startY+80,14,14);
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/"+currentModuleType+2+".png"), (int)startX+5, (int)startY+100,14,14);
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/World.png"), (int)startX+5, (int)startY+120,14,14);
		  		break;
		  	case "WORLD":
		  		Client.fontManager.tahoma25.drawString("Render", startX + 25, startY + 60,(new Color(152, 152, 152)).getRGB());        
		 		 Client.fontManager.tahoma25.drawString("Combot", startX + 25, startY + 40,(new Color(152, 152, 152)).getRGB());
		        Client.fontManager.tahoma25.drawString("Move", startX + 25, startY + 80,(new Color(152, 152, 152)).getRGB());
		        Client.fontManager.tahoma25.drawString("Player", startX + 25, startY + 100,(new Color(152, 152, 152)).getRGB());
		        Client.fontManager.tahoma25.drawString("World", startX + 25, startY + 120,(new Color(0, 100, 237)).getRGB());
		    					RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Combat.png"), (int)startX+5, (int)startY+40,14,14);
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Render.png"), (int)startX+5, (int)startY+60,14,14);
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Movement.png"), (int)startX+5, (int)startY+80,14,14);
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/Player.png"), (int)startX+5, (int)startY+100,14,14);
				RenderUtil.drawImage(new ResourceLocation("Zower/Clickui/"+currentModuleType+2+".png"), (int)startX+5, (int)startY+120,14,14);
		  		break;
		}
		}

	}
	  @Override
	    public void drawScreen1(int mouseX, int mouseY, float partialTicks) {
	        this.uiPopUPButton.draw(mouseX, mouseY);
	        if(ClickGui.snowflake.getValueState().booleanValue()) {
	        for (Particle particle : this.particles) {
	            particle.drawScreen(mouseX, mouseY, res.getScaledHeight());
	         }
	    }
	    }
	public boolean isStringHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
		if (mouseX >= f && mouseX <= g && mouseY >= y && mouseY <= y2) {
			return true;
		}

		return false;
	}

	public boolean isSettingsButtonHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
		if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
			return true;
		}

		return false;
	}

	public boolean isButtonHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
		if (mouseX >= f && mouseX <= g && mouseY >= y && mouseY <= y2) {
			return true;
		}

		return false;
	}

	public boolean isCheckBoxHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
		if (mouseX >= f && mouseX <= g && mouseY >= y && mouseY <= y2) {
			return true;
		}

		return false;
	}

	public boolean isCategoryHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
		if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
			return true;
		}

		return false;
	}

	public boolean isHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
		if (mouseX >= x && mouseX <= x2 && mouseY >= y && mouseY <= y2) {
			return true;
		}

		return false;
	}

	@Override
	public void onGuiClosed() {
		this.opacity.setOpacity(0);
	}
}
