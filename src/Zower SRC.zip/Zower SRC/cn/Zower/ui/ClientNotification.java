package cn.Zower.ui;

import org.lwjgl.opengl.GL11;

import cn.Zower.Client;
import cn.Zower.mod.mods.ClickGui;
import cn.Zower.ui.font.FontLoaders;
import cn.Zower.util.ClientUtil;
import cn.Zower.util.FlatColors;
import cn.Zower.util.RenderUtil;
import cn.Zower.util.fontRenderer.UnicodeFontRenderer;
import cn.Zower.util.fontRenderer.CFont.CFontRenderer;
import cn.Zower.util.timeUtils.TimeHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.util.ResourceLocation;



	public class ClientNotification
	{
	    private String message;
	    private TimeHelper timer;
	    private double lastY;
	    private double posY;
	    private double width;
	    private double height;
	    private double animationX;
	    private int color;
	    private int imageWidth;
	    private ResourceLocation image;
	    private long stayTime;
	    Minecraft mc = Minecraft.getMinecraft();

	    
	    public ClientNotification(final String message, final Type type) {
	        this.message = message;
	        (this.timer = new TimeHelper()).reset();
	        CFontRenderer font = FontLoaders.Backs18;
	        this.width = font.getStringWidth(message) + 35;
	        this.height = 20.0;
	        this.animationX = this.width;
	        this.stayTime = 2000L;
	        this.imageWidth = 13;
	        this.posY = -1.0;
	        if (type.equals(Type.INFO)) {
	            this.color = ClientUtil.reAlpha(FlatColors.BLUE.c, 0.6F);
	            if(ClickGui.Sound.getValueState().booleanValue()) {
	            Minecraft.getMinecraft().thePlayer.playSound("random.click", 20.0F, 20.0F);
	            }
	        }
	        else if (type.equals(Type.ERROR)) {
	            this.color = ClientUtil.reAlpha(FlatColors.RED.c, 0.6F);
	            if(ClickGui.Sound.getValueState().booleanValue()) {
	            	 Minecraft.getMinecraft().thePlayer.playSound("random.click", 1.0F,0.8F);
	            }
	        }
	        else if (type.equals(Type.SUCCESS)) {
	            this.color = ClientUtil.reAlpha(FlatColors.BLUE.c, 0.6F);
	            if(ClickGui.Sound.getValueState().booleanValue()) {
	            	 Minecraft.getMinecraft().thePlayer.playSound("random.click", 1.0F, 1.0F);
	        }
	        }
	        else if (type.equals(Type.WARNING)) {
	            this.color = ClientUtil.reAlpha(FlatColors.YELLOW.c, 0.6F);
	            if(ClickGui.Sound.getValueState().booleanValue()) {
	            Minecraft.getMinecraft().thePlayer.playSound("random.orb", 1.0F, 1.0F);
	        }
	   }
	    }
	    
	    public void draw(final double getY, final double lastY) {
	        this.lastY = lastY;
	        this.animationX = RenderUtil.getAnimationState(this.animationX, this.isFinished() ? this.width : 0.0, Math.max(this.isFinished() ? 200 : 30, Math.abs(this.animationX - (this.isFinished() ? this.width : 0.0)) * 3.0));
	        if (this.posY == -1.0) {
	            this.posY = getY;
	        }
	        else {
	            this.posY = RenderUtil.getAnimationState(this.posY, getY, 200.0);
	        }
	        final ScaledResolution res = new ScaledResolution(Minecraft.getMinecraft());
	        final int x1 = (int)(res.getScaledWidth() - this.width + this.animationX);
	        final int x2 = (int)(res.getScaledWidth() + this.animationX);
	        final int y1 = (int)this.posY;
	        final int y2 = (int)(y1 + this.height);
	        Gui.drawRect(x1, y1, x2, y2, ClientUtil.reAlpha(1, 0.6F));
	        Gui.drawRect(x1, y2-2, x2, y2, color);
	        CFontRenderer font = FontLoaders.Backs18;
	        font.drawCenteredString(this.message, (float)(x1 + this.width / 2.0) + 0.0f, (float)(y1 + this.height / 3.5), -1);
	    }
	    
	    public boolean shouldDelete() {
	        return this.isFinished() && this.animationX >= this.width;
	    }
	    
	    private boolean isFinished() {
	        return this.timer.isDelayComplete(this.stayTime) && this.posY == this.lastY;
	    }
	    
	    public double getHeight() {
	        return this.height;
	    }
	    
	    public enum Type
	    {
	        SUCCESS("SUCCESS", 0), 
	        INFO("INFO", 1), 
	        WARNING("WARNING", 2), 
	        ERROR("ERROR", 3);
	        
	        private Type(final String s, final int n) {
	        }
	    }
	}

