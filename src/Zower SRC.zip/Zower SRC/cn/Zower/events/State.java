package cn.Zower.events;

public enum State {
	   PRE,
	   POST;
	}