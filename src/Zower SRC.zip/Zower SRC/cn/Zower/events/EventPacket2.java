/*
 * Decompiled with CFR 0.149.
 */
package cn.Zower.events;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.events.Event;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;

public class EventPacket2
implements Event {
    private EventPacketType type;
    public static boolean sendcancel;
    public EntityLivingBase target;
    private boolean cancelled;
    public static boolean recievecancel;
    public Packet packet;
    private boolean isPre;
    private Entity ent;

    public EventPacket2(EventPacketType type, Packet packet) {
        this.type = type;
        this.packet = packet;
        sendcancel = false;
        recievecancel = false;
        boolean cfr_ignored_0 = this.packet instanceof C03PacketPlayer;
        if (this.packet instanceof S08PacketPlayerPosLook) {
            EventManager.call(new EventPullback());
        }
    }

    public EventPacket2(Entity e) {
        this.ent = e;
    }

    public EventPacketType getType() {
        return this.type;
    }

    public void setType(EventPacketType type) {
        this.type = type;
    }

    public boolean isSendcancel() {
        return sendcancel;
    }

    public void setSendcancel(boolean sendcancel) {
        EventPacket2.sendcancel = sendcancel;
    }

    public EntityLivingBase getTarget() {
        return this.target;
    }

    public void setTarget(EntityLivingBase target) {
        this.target = target;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public boolean isRecievecancel() {
        return recievecancel;
    }

    public void setRecievecancel(boolean recievecancel) {
        EventPacket2.recievecancel = recievecancel;
    }

    public Packet getPacket() {
        return this.packet;
    }

    public void setPacket(Packet packet) {
        this.packet = packet;
    }

    public boolean isPre() {
        return this.isPre;
    }

    public boolean isPost() {
        return !this.isPre;
    }

    public Entity getEntity() {
        return this.ent;
    }

    public static enum EventPacketType {
        SEND,
        RECEIVE;

    }
}

