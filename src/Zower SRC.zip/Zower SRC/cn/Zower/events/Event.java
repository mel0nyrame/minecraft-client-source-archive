package cn.Zower.events;

public abstract class Event {
	   protected boolean cancelled;
	    public static byte type;
	private boolean onGround;

	   public void fire() {
	      this.cancelled = false;
	   }

	   public void setCancelled(boolean cancelled) {
	      this.cancelled = cancelled;
	   }

	   public boolean isCancelled() {
	      return this.cancelled;
	   }

	    public void setOnGround(boolean onGround) {
	        this.onGround = onGround;
	    }
	    public static byte getType() {
	        return type;
	     }


	    public void setType(byte type) {
	        this.type = type;
	    }

	    
	}
