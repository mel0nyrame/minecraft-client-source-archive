/*
 * Decompiled with CFR 0.149.
 */
package cn.Zower.events;

import com.darkmagician6.eventapi.events.Event;

public class EventPullback
implements Event {
}

