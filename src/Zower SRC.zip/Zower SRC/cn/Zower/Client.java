
package cn.Zower;

import cn.Zower.command.CommandManager;
import cn.Zower.mod.ModManager;
import cn.Zower.ui.click.UIClick;
import cn.Zower.ui.font.FontLoaders;
import cn.Zower.util.FileUtil;
import cn.Zower.util.fontRenderer.FontManager;
import net.minecraft.client.Minecraft;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.logging.Logger;
import org.lwjgl.opengl.Display;

public class Client {
    public static final boolean INSTANCE = false;
    public static String CLIENT_name = "Ampere";
    public static String CLIENT_VER = "v1";
    public static String CLIENT_Bulid = "20200516";
    public static boolean isClientLoading;
    public static Client instance;
    public static Logger LOGGER;
    public FileUtil fileUtil;
    public static ModManager modMgr;
    public FileUtil fileMgr;
    public FontManager fontMgr;
    public static FontLoaders fontMgrs;
    public static FontManager fontManager;
    public static Minecraft mc;
    public static int taskbarprogress;
    public static boolean paiduser;
	public static String Server;
	public static float Yaw;
    public UIClick clickface;
    public CommandManager cmdMgr;

    static {
        LOGGER = Logger.getLogger((String)CLIENT_name);
    }

    public Client() {
        instance = this;
        isClientLoading = true;
    }

    public UIClick showClickGui() {
        return this.clickface;
    }

    public void onClientStart() {
        this.clickface = new UIClick();
        this.modMgr = new ModManager();
        fontManager = this.fontMgr = new FontManager();
        this.fileMgr = new FileUtil();
        this.cmdMgr = new CommandManager();
        Display.setTitle((String)(String.valueOf((Object)CLIENT_name) + " " + CLIENT_VER));
        isClientLoading = false;
    }

    public void onClientStop() {
    }

    public static Client getInstance() {
        return instance;
    }

    public FileUtil getFileUtil() {
        return this.fileUtil;
    }

    public static String sendGet(String url) throws MalformedURLException, IOException {
        String inputLine;
        HttpURLConnection con = (HttpURLConnection)new URL(url).openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        BufferedReader in = new BufferedReader((Reader)new InputStreamReader(con.getInputStream()));
        StringBuilder response = new StringBuilder();
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
            response.append("\n");
        }
        in.close();
        return response.toString();
    }
}
