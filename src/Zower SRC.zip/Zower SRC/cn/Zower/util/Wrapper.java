/*
 * Decompiled with CFR 0.149.
 */
package cn.Zower.util;

import java.awt.Color;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.world.World;

public class Wrapper {
    static Minecraft mc = Minecraft.getMinecraft();
    public static final String INSTANCE = null;
    public static boolean canSendMotionPacket = true;

    public static Minecraft getMinecraft() {
        return Minecraft.getMinecraft();
    }

    public static EntityPlayerSP getPlayer() {
        Wrapper.getMinecraft();
        return Minecraft.thePlayer;
    }

    public static World getWorld() {
        Wrapper.getMinecraft();
        return Minecraft.theWorld;
    }

    public static void addChat(String msg) {
        Wrapper.getPlayer().addChatComponentMessage(new ChatComponentText(msg));
    }

    public static FontRenderer getFontRenderer() {
        return Wrapper.getMinecraft().fontRendererObj;
    }

    public static void drawCenteredString(String s, int x, int y, int colour) {
        Wrapper.getMinecraft().fontRendererObj.drawStringWithShadow(s, x -= Wrapper.getMinecraft().fontRendererObj.getStringWidth(s) / 2, y, colour);
    }

    public static int getIntFromColor(int r, int g, int b) {
        r = r << 16 & 0xFF0000;
        g = g << 8 & 0xFF00;
        return 0xFF000000 | r | g | (b &= 0xFF);
    }

    public static int getIntFromColor(Color color) {
        return color.getRGB();
    }

    public static Color getColorFromHex(int hex) {
        int r = (hex & 0xFF0000) >> 16;
        int g = (hex & 0xFF00) >> 8;
        int b = hex & 0xFF;
        return new Color(r, g, b);
    }

    public static void setLook(float rotationYaw, float rotationPitch) {
        if (Wrapper.mc.gameSettings.thirdPersonView > 0) {
            Minecraft.thePlayer.rotationPitchHead = rotationPitch;
            Minecraft.thePlayer.rotationYawHead = rotationYaw;
            Minecraft.thePlayer.renderYawOffset = rotationYaw;
        }
    }

    public static double getDoubleRandom(double min, double max) {
        return ThreadLocalRandom.current().nextDouble(min, max);
    }

    public static double getRandomLong(long min, long max) {
        return ThreadLocalRandom.current().nextLong(min, max);
    }

    public void multiply(double speed) {
        Minecraft.thePlayer.motionX *= speed;
        Minecraft.thePlayer.motionZ *= speed;
    }
}

