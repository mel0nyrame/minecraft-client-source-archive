/*
 * Decompiled with CFR 0.149.
 */
package cn.Zower.util;

import java.util.ArrayList;

import com.darkmagician6.eventapi.EventTarget;

import cn.Zower.events.EventBlockRender;
import cn.Zower.events.EventUpdate;
import net.minecraft.block.BlockBed;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

public class NukerUtil {
    public static ArrayList<BlockPos> list = new ArrayList();

    public static void update() {
        Minecraft.getMinecraft().renderGlobal.loadRenderers();
        list.clear();
    }

    @EventTarget
    public void onRenderBlock(EventBlockRender e) {
        BlockPos pos = new BlockPos(e.x, e.y, e.z);
        if (!list.contains(pos) && e.block instanceof BlockBed) {
            list.add(pos);
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate e) {
        list.removeIf(pos -> {
            Minecraft.getMinecraft();
            return !(Minecraft.theWorld.getBlockState((BlockPos)pos).getBlock() instanceof BlockBed);
        });
    }
}

