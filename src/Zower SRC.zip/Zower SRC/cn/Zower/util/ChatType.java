package cn.Zower.util;

public enum ChatType {
	INFO,WARN,ERROR;
}
