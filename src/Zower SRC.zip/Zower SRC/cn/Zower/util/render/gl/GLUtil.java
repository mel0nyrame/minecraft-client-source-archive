package cn.Zower.util.render.gl;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.lwjgl.opengl.GL11;

public class GLUtil {
    private static final Map<Integer, Boolean> glCapMap = new HashMap();

    public static void setGLCap(int cap, boolean flag) {
    	glCapMap.put(Integer.valueOf(cap), Boolean.valueOf(GL11.glGetBoolean(cap)));


        if (flag) {
            GL11.glEnable((int)cap);
        } else {
            GL11.glDisable((int)cap);
        }
    }


    public static void revertGLCap(int cap) {
        Boolean origCap = (Boolean)glCapMap.get((Object)cap);
        if (origCap != null) {
            if (origCap.booleanValue()) {
                GL11.glEnable((int)cap);
            } else {
                GL11.glDisable((int)cap);
            }
        }
    }

    public static void glEnable(int cap) {
        GLUtil.setGLCap(cap, true);
    }

    public static void glDisable(int cap) {
        GLUtil.setGLCap(cap, false);
    }

    public static void revertAllCaps() {
        for (Integer cap : glCapMap.keySet()) {
            GLUtil.revertGLCap(cap);
        }
    }
}
