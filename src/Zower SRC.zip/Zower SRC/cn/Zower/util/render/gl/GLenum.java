/*
 * Decompiled with CFR 0_132.
 */
package cn.Zower.util.render.gl;

public interface GLenum {
    public String getName();

    public int getCap();
}

