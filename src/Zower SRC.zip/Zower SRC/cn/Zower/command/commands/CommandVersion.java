package cn.Zower.command.commands;

import cn.Zower.Client;
import cn.Zower.command.Command;
import cn.Zower.ui.ClientNotification;
import cn.Zower.util.ClientUtil;

public class CommandVersion extends Command {

	public CommandVersion(String[] commands) {
		super(commands);
	}

	@Override
	public void onCmd(String[] args) {
		ClientUtil.sendClientMessage(Client.CLIENT_name + " v" + Client.CLIENT_VER + " by SaoManTou <3", ClientNotification.Type.INFO);
	}
	
}
