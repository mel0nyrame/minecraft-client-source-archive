package cn.Zower.command.commands;

import cn.Zower.Tiplan;
import cn.Zower.command.Command;
import cn.Zower.util.ChatType;
import cn.Zower.util.ClientUtil;

public class CommandTiplan extends Command {

	public CommandTiplan(String[] commands) {
		super(commands);
	}

	@Override
	public void onCmd(String[] args) {
		ClientUtil.sendChatMessage("Changing tiplan...", ChatType.INFO);
		new Tiplan();
	}
}
