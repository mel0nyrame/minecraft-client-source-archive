/*
 * Decompiled with CFR 0.151.
 */
package com.darkmagician6.eventapi.events;

public interface Typed {
    public byte getType();
}

