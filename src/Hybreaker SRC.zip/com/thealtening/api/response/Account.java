/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.gson.annotations.SerializedName
 */
package com.thealtening.api.response;

import com.google.gson.annotations.SerializedName;
import com.thealtening.api.response.AccountDetails;

public class Account {
    @SerializedName(value="username")
    private String username;
    @SerializedName(value="password")
    private String password;
    @SerializedName(value="token")
    private String token;
    @SerializedName(value="limit")
    private boolean limit;
    @SerializedName(value="info")
    private AccountDetails info;

    public Account(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getToken() {
        return this.token;
    }

    public String getPassword() {
        return this.password;
    }

    public String getUsername() {
        return this.username;
    }

    public boolean isLimit() {
        return this.limit;
    }

    public AccountDetails getInfo() {
        return this.info;
    }

    public String toString() {
        return String.format("Account[%s:%s:%s:%s]", this.token, this.username, this.password, this.limit);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Account)) {
            return false;
        }
        Account other = (Account)obj;
        return other.getUsername().equals(this.username) && other.getToken().equals(this.token);
    }
}

