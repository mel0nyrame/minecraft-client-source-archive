/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package cn.M1N3S3NS3.UI.Verify;

import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.UI.Login.GuiPasswordField;
import cn.M1N3S3NS3.UI.Render.UIFlatButton;
import cn.M1N3S3NS3.UI.Verify.LoginThread;
import cn.M1N3S3NS3.Util.Render.RenderUtil;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;

public class GuiLogin
extends GuiScreen {
    private final Minecraft mc = Minecraft.getMinecraft();
    private final TimerUtil timer = new TimerUtil();
    private int logocount;
    private GuiPasswordField password;
    public GuiTextField username;
    private UIFlatButton loginButton;

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution sr = new ScaledResolution(this.mc);
        int centerX = ScaledResolution.getScaledWidth() / 2;
        int centerY = ScaledResolution.getScaledHeight() / 2;
        int iconWidth = (int)((double)ScaledResolution.getScaledWidth() * 0.04);
        int logoWidth = (int)((double)ScaledResolution.getScaledWidth() * 0.185);
        int loginBoxWidth = 120;
        int startX = centerX - loginBoxWidth / 2;
        int startY = (int)((double)ScaledResolution.getScaledHeight() * 0.38 + 4.0);
        int height = (int)((double)ScaledResolution.getScaledHeight() * 0.042);
        int boxHeight = (int)Math.min((double)ScaledResolution.getScaledHeight() * 0.27, 120.0);
        RenderUtil.drawRoundedRect(centerX - loginBoxWidth / 2, (float)((double)ScaledResolution.getScaledHeight() * 0.38 + 2.0), loginBoxWidth, 2.0f, 1.0f, new Color(185, 0, 185).getRGB());
        RenderUtil.drawRect(centerX - loginBoxWidth / 2, (float)((double)ScaledResolution.getScaledHeight() * 0.38 + 4.0), loginBoxWidth, boxHeight, new Color(0, 0, 0, 120).getRGB());
        FontLoaders.Comfortaa22.drawCenteredStringWithShadow("Login", (double)centerX, (double)ScaledResolution.getScaledHeight() * 0.33, new Color(224, 223, 225, 255).getRGB());
        iconWidth = Math.min(24, 24);
        this.username.drawTextBox();
        this.password.drawTextBox();
        RenderUtil.drawRoundedRect(this.username.xPosition, (float)((double)(this.username.yPosition + this.username.height) - (double)ScaledResolution.getScaledHeight() * 0.01), this.username.width, 1.0f, 1.0f, this.username.isFocused() ? new Color(97, 63, 96).getRGB() : new Color(151, 150, 151).getRGB());
        RenderUtil.drawRoundedRect(this.password.x, (float)((double)(this.password.y + this.password.height) - (double)ScaledResolution.getScaledHeight() * 0.01), this.password.width, 1.0f, 1.0f, this.password.isFocused() ? new Color(97, 63, 96).getRGB() : new Color(151, 150, 151).getRGB());
        RenderUtil.drawImage(new ResourceLocation("Distance/ICON/username.png"), centerX + loginBoxWidth / 2 - 2 - iconWidth / 2 - 4, (int)((double)this.username.yPosition - (double)ScaledResolution.getScaledHeight() * 0.008), iconWidth / 2, iconWidth / 2);
        RenderUtil.drawImage(new ResourceLocation("Distance/ICON/password.png"), centerX + loginBoxWidth / 2 - 2 - iconWidth / 2 - 4, (int)((double)this.password.y - (double)ScaledResolution.getScaledHeight() * 0.008), iconWidth / 2, iconWidth / 2);
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void initGui() {
        String oldUsername = "";
        String oldPassword = "";
        if (this.username != null) {
            oldUsername = this.username.getText();
            oldPassword = this.password.getText();
        }
        ScaledResolution sr = new ScaledResolution(this.mc);
        int centerX = ScaledResolution.getScaledWidth() / 2;
        int centerY = ScaledResolution.getScaledHeight() / 2;
        int loginBoxWidth = 120;
        int startX = centerX - loginBoxWidth / 2;
        int startY = (int)((double)ScaledResolution.getScaledHeight() * 0.38 + 4.0);
        int logoWidth = (int)((double)ScaledResolution.getScaledWidth() * 0.185);
        int iconWidth = (int)((double)ScaledResolution.getScaledWidth() * 0.04);
        int width = loginBoxWidth - 14;
        int height = (int)((double)ScaledResolution.getScaledHeight() * 0.042);
        this.username = new GuiTextField(1, Minecraft.fontRendererObj, startX + 7, startY + 10, width, height);
        this.password = new GuiPasswordField(Minecraft.fontRendererObj, startX + 7, startY + height + 22, width, height);
        this.username.setEnableBackgroundDrawing(false);
        this.password.field_146215_m = false;
        this.username.setText(oldUsername);
        this.password.setText(oldPassword);
        Keyboard.enableRepeatEvents((boolean)true);
        int boxHeight = (int)Math.min((double)ScaledResolution.getScaledHeight() * 0.27, 120.0);
        int loginButtonHeight = (int)Math.min((double)ScaledResolution.getScaledHeight() * 0.06, 29.0);
        this.loginButton = new UIFlatButton(0, startX + 7, (int)((double)ScaledResolution.getScaledHeight() * 0.38 + 4.0 + (double)boxHeight - (double)loginButtonHeight - 8.0) + 2, width, loginButtonHeight, "Login", new Color(255, 0, 255, 80).getRGB());
        this.buttonList.add(this.loginButton);
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        String username = this.username.getText();
        String password = this.password.getText();
        if (!username.trim().equals("") && !password.trim().equals("")) {
            new LoginThread(username, password).run();
        }
    }

    @Override
    protected void keyTyped(char var1, int var2) throws IOException {
        if (var1 == '\t') {
            if (!this.username.isFocused()) {
                this.username.setFocused(true);
            } else {
                this.username.setFocused(this.username.isFocused());
                this.password.setFocused(!this.username.isFocused());
            }
        }
        if (var1 == '\r') {
            this.actionPerformed((GuiButton)this.buttonList.get(0));
        }
        this.username.textboxKeyTyped(var1, var2);
        this.password.textboxKeyTyped(var1, var2);
    }

    @Override
    protected void mouseClicked(int var1, int var2, int var3) {
        try {
            super.mouseClicked(var1, var2, var3);
        }
        catch (IOException var5) {
            var5.printStackTrace();
        }
        this.username.mouseClicked(var1, var2, var3);
        this.password.mouseClicked(var1, var2, var3);
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents((boolean)false);
    }

    @Override
    public void updateScreen() {
        this.username.updateCursorCounter();
        this.password.updateCursorCounter();
    }
}

