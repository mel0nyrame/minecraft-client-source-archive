/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.apache.commons.codec.binary.Base64
 */
package cn.M1N3S3NS3.UI.Verify;

import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Util.HWID.HWIDUtil;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import org.apache.commons.codec.binary.Base64;

public class VerifyThread
extends Thread {
    @Override
    public void run() {
        String username = Client.Users;
        String password = Client.Pass;
        String webdata = Client.webdata;
        StringBuilder salt = new StringBuilder("SunnyNormal");
        int i = 0;
        while (i < 9) {
            salt.append(Integer.toHexString(~(i & 0xFF | 0x1C42) & 0xD63));
            ++i;
        }
        String userCheck = null;
        try {
            userCheck = salt + username + password + HWIDUtil.getHWID();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        try {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] byArray = new byte[162];
            byArray[0] = 48;
            byArray[1] = -127;
            byArray[2] = -97;
            byArray[3] = 48;
            byArray[4] = 13;
            byArray[5] = 6;
            byArray[6] = 9;
            byArray[7] = 42;
            byArray[8] = -122;
            byArray[9] = 72;
            byArray[10] = -122;
            byArray[11] = -9;
            byArray[12] = 13;
            byArray[13] = 1;
            byArray[14] = 1;
            byArray[15] = 1;
            byArray[16] = 5;
            byArray[18] = 3;
            byArray[19] = -127;
            byArray[20] = -115;
            byArray[22] = 48;
            byArray[23] = -127;
            byArray[24] = -119;
            byArray[25] = 2;
            byArray[26] = -127;
            byArray[27] = -127;
            byArray[29] = -123;
            byArray[30] = -120;
            byArray[31] = -114;
            byArray[32] = 13;
            byArray[33] = -106;
            byArray[34] = -112;
            byArray[35] = -45;
            byArray[36] = -7;
            byArray[37] = -5;
            byArray[38] = -61;
            byArray[39] = -64;
            byArray[40] = -32;
            byArray[41] = -120;
            byArray[42] = 100;
            byArray[43] = -60;
            byArray[44] = 62;
            byArray[45] = 72;
            byArray[46] = 78;
            byArray[47] = 64;
            byArray[48] = -116;
            byArray[49] = -37;
            byArray[50] = 26;
            byArray[51] = 4;
            byArray[52] = 34;
            byArray[53] = 70;
            byArray[54] = -56;
            byArray[55] = -9;
            byArray[56] = -70;
            byArray[57] = 107;
            byArray[58] = -29;
            byArray[59] = -8;
            byArray[60] = 15;
            byArray[61] = -57;
            byArray[62] = 79;
            byArray[63] = -53;
            byArray[64] = -28;
            byArray[65] = 33;
            byArray[66] = -115;
            byArray[67] = 46;
            byArray[68] = -93;
            byArray[69] = -70;
            byArray[70] = 108;
            byArray[71] = -45;
            byArray[72] = 32;
            byArray[73] = -67;
            byArray[74] = -57;
            byArray[75] = -13;
            byArray[76] = 32;
            byArray[77] = 109;
            byArray[78] = -1;
            byArray[79] = 111;
            byArray[80] = -22;
            byArray[81] = 122;
            byArray[82] = -108;
            byArray[83] = 58;
            byArray[84] = 72;
            byArray[85] = -79;
            byArray[86] = -86;
            byArray[87] = -58;
            byArray[88] = -84;
            byArray[89] = 91;
            byArray[90] = -68;
            byArray[91] = -99;
            byArray[92] = -121;
            byArray[93] = 49;
            byArray[94] = -52;
            byArray[95] = -23;
            byArray[96] = 64;
            byArray[97] = -71;
            byArray[98] = -84;
            byArray[99] = -78;
            byArray[100] = 31;
            byArray[101] = 66;
            byArray[102] = 43;
            byArray[103] = 84;
            byArray[104] = -59;
            byArray[105] = 78;
            byArray[106] = 68;
            byArray[107] = 93;
            byArray[108] = 81;
            byArray[109] = 6;
            byArray[110] = 89;
            byArray[111] = -100;
            byArray[112] = 43;
            byArray[113] = -24;
            byArray[114] = 123;
            byArray[115] = -81;
            byArray[116] = -34;
            byArray[117] = 68;
            byArray[118] = 104;
            byArray[119] = -36;
            byArray[120] = 55;
            byArray[121] = -109;
            byArray[122] = 89;
            byArray[123] = 86;
            byArray[124] = -89;
            byArray[125] = 75;
            byArray[126] = 1;
            byArray[127] = -22;
            byArray[128] = -103;
            byArray[129] = 105;
            byArray[130] = -17;
            byArray[131] = 106;
            byArray[132] = 124;
            byArray[133] = -58;
            byArray[134] = -65;
            byArray[135] = -30;
            byArray[136] = 92;
            byArray[137] = 72;
            byArray[138] = -108;
            byArray[139] = -50;
            byArray[140] = -95;
            byArray[141] = 74;
            byArray[142] = -6;
            byArray[143] = 106;
            byArray[144] = 80;
            byArray[145] = 100;
            byArray[146] = 87;
            byArray[147] = -23;
            byArray[148] = 95;
            byArray[149] = -80;
            byArray[150] = 112;
            byArray[151] = 45;
            byArray[152] = -74;
            byArray[153] = -93;
            byArray[154] = -72;
            byArray[155] = -64;
            byArray[156] = 39;
            byArray[157] = 2;
            byArray[158] = 3;
            byArray[159] = 1;
            byArray[161] = 1;
            PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec(byArray));
            Signature signature = Signature.getInstance("SHA1WithRSA");
            signature.initVerify(pubKey);
            signature.update(userCheck.getBytes());
            boolean bverify = signature.verify(Base64.decodeBase64((String)webdata));
            if (!bverify) {
                System.exit(-1);
            }
        }
        catch (Exception e) {
            System.exit(-1);
        }
    }
}

