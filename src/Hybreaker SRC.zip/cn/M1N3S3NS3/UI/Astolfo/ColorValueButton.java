/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.UI.Astolfo;

import cn.M1N3S3NS3.UI.Astolfo.Limitation;
import cn.M1N3S3NS3.UI.Astolfo.ValueButton;
import java.awt.Color;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class ColorValueButton
extends ValueButton {
    private float[] hue = new float[]{0.0f};
    private int position;
    private int color = new Color(125, 125, 125).getRGB();

    public ColorValueButton(int x, int y) {
        super(null, x, y);
        this.custom = true;
        this.position = -1111;
    }

    @Override
    public void render(int mouseX, int mouseY, Limitation limitation) {
        float[] huee = new float[]{this.hue[0]};
        int i = this.x - 7;
        GL11.glEnable((int)3089);
        limitation.cut();
        Gui.drawRect(this.x - 10, this.y - 4, this.x + 80, this.y + 11, new Color(0, 0, 0, 100).getRGB());
        while (i < this.x + 79) {
            Color color = Color.getHSBColor(huee[0] / 255.0f, 0.7f, 1.0f);
            if (mouseX > i - 1 && mouseX < i + 1 && mouseY > this.y - 6 && mouseY < this.y + 12 && Mouse.isButtonDown((int)0)) {
                this.color = color.getRGB();
                this.position = i;
            }
            if (this.color == color.getRGB()) {
                this.position = i;
            }
            Gui.drawRect(i - 1, this.y, i, this.y + 8, color.getRGB());
            float[] arrf = huee;
            arrf[0] = arrf[0] + 4.0f;
            if (huee[0] > 255.0f) {
                huee[0] = huee[0] - 255.0f;
            }
            ++i;
        }
        Gui.drawRect(this.position, this.y, this.position + 1, this.y + 8, -1);
        if (this.hue[0] > 255.0f) {
            this.hue[0] = this.hue[0] - 255.0f;
        }
        GL11.glDisable((int)3089);
    }

    @Override
    public void key(char typedChar, int keyCode) {
    }

    @Override
    public void click(int mouseX, int mouseY, int button) {
    }
}

