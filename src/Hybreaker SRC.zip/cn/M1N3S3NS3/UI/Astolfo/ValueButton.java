/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.UI.Astolfo;

import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.UI.Astolfo.Limitation;
import cn.M1N3S3NS3.UI.Font.CFontRenderer;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class ValueButton {
    public Value value;
    public String name;
    public boolean custom = false;
    public boolean change;
    public int x;
    public int y;
    public double opacity = 0.0;
    public ModuleType category;

    public ValueButton(Value value, int x, int y) {
        this.value = value;
        this.x = x;
        this.y = y;
        this.name = "";
        if (this.value instanceof Option) {
            this.change = (Boolean)((Option)this.value).getValue();
        } else if (this.value instanceof Mode) {
            this.name = "" + ((Mode)this.value).getValue();
        } else if (value instanceof Numbers) {
            Numbers v = (Numbers)value;
            this.name = String.valueOf(String.valueOf(this.name)) + (v.isInteger() ? (double)((Number)v.getValue()).intValue() : ((Number)v.getValue()).doubleValue());
        }
        this.opacity = 0.0;
    }

    public void render(int mouseX, int mouseY, Limitation limitation) {
        CFontRenderer font = FontLoaders.Comfortaa18;
        CFontRenderer mfont = FontLoaders.Comfortaa16;
        if (!this.custom) {
            this.opacity = mouseX > this.x - 7 && mouseX < this.x + 85 && mouseY > this.y - 6 && mouseY < this.y + FontLoaders.Comfortaa18.getStringHeight(this.value.getName()) + 6 ? (this.opacity + 10.0 < 200.0 ? (this.opacity += 10.0) : 200.0) : (this.opacity - 6.0 > 0.0 ? (this.opacity -= 6.0) : 0.0);
            if (this.value instanceof Option) {
                this.change = (Boolean)((Option)this.value).getValue();
            } else if (this.value instanceof Mode) {
                this.name = "" + ((Mode)this.value).getValue();
            } else if (this.value instanceof Numbers) {
                Numbers v = (Numbers)this.value;
                this.name = "" + (v.isInteger() ? (double)((Number)v.getValue()).intValue() : ((Number)v.getValue()).doubleValue());
                if (mouseX > this.x - 7 && mouseX < this.x + 85 && mouseY > this.y + FontLoaders.Comfortaa18.getStringHeight(this.value.getName()) - 10 && mouseY < this.y + mfont.getStringHeight(this.value.getName()) + 2 && Mouse.isButtonDown((int)0)) {
                    double min = ((Number)v.getMinimum()).doubleValue();
                    double max = ((Number)v.getMaximum()).doubleValue();
                    double inc = ((Number)v.getIncrement()).doubleValue();
                    double valAbs = (double)mouseX - ((double)this.x + 1.0);
                    double perc = valAbs / 68.0;
                    perc = Math.min(Math.max(0.0, perc), 1.0);
                    double valRel = (max - min) * perc;
                    double val = min + valRel;
                    val = (double)Math.round(val * (1.0 / inc)) / (1.0 / inc);
                    v.setValue(val);
                }
            }
            int staticColor = new Color(182, 182, 182).getRGB();
            GL11.glEnable((int)3089);
            limitation.cut();
            Gui.drawRect(this.x - 10, this.y - 4, this.x + 80, this.y + 11, new Color(39, 39, 39).getRGB());
            if (this.value instanceof Option) {
                mfont.drawStringWithShadow(this.value.getName(), this.x - 7, this.y + 2, (Boolean)((Option)this.value).getValue() != false ? new Color(255, 255, 255).getRGB() : new Color(108, 108, 108).getRGB());
            }
            ScaledResolution res = new ScaledResolution(Minecraft.getMinecraft());
            if (this.value instanceof Mode) {
                mfont.drawStringWithShadow(this.value.getName(), this.x - 7, this.y + 3, new Color(255, 255, 255).getRGB());
                mfont.drawStringWithShadow(this.name, this.x + 77 - mfont.getStringWidth(this.name), this.y + 3, new Color(182, 182, 182).getRGB());
            }
            if (this.value instanceof Numbers) {
                Numbers v = (Numbers)this.value;
                double render = 82.0f * (((Number)v.getValue()).floatValue() - ((Number)v.getMinimum()).floatValue()) / (((Number)v.getMaximum()).floatValue() - ((Number)v.getMinimum()).floatValue());
                Gui.drawRect((double)(this.x - 8), (double)(this.y + mfont.getStringHeight(this.value.getName()) + 2), (double)(this.x + 78), (double)(this.y + mfont.getStringHeight(this.value.getName()) - 9), new Color(50, 50, 50, 180).getRGB());
                Gui.drawRect((double)(this.x - 8), (double)(this.y + mfont.getStringHeight(this.value.getName()) + 2), (float)((double)(this.x - 4) + render), (double)(this.y + mfont.getStringHeight(this.value.getName()) - 9), staticColor);
            }
            if (this.value instanceof Numbers) {
                mfont.drawStringWithShadow(this.value.getName(), this.x - 7, this.y, new Color(255, 255, 255).getRGB());
                mfont.drawStringWithShadow(this.name, this.x + mfont.getStringWidth(this.value.getName()), this.y, -1);
            }
            GL11.glDisable((int)3089);
        }
    }

    public void key(char typedChar, int keyCode) {
    }

    private boolean isHovering(int n, int n2) {
        boolean b = n >= this.x && n <= this.x - 7 && n2 >= this.y && n2 <= this.y + FontLoaders.Comfortaa18.getStringHeight(this.value.getName());
        return b;
    }

    public void click(int mouseX, int mouseY, int button) {
        if (!this.custom && mouseX > this.x - 7 && mouseX < this.x + 85 && mouseY > this.y - 6 && mouseY < this.y + FontLoaders.Comfortaa18.getStringHeight(this.value.getName())) {
            if (this.value instanceof Option) {
                Option v;
                v.setValue((Boolean)(v = (Option)this.value).getValue() == false);
                return;
            }
            if (this.value instanceof Mode) {
                Mode m = (Mode)this.value;
                Enum current = (Enum)m.getValue();
                int next = current.ordinal() + 1 >= m.getModes().length ? 0 : current.ordinal() + 1;
                this.value.setValue(m.getModes()[next]);
            }
        }
    }
}

