/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.UI.Astolfo;

import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.UI.Astolfo.Limitation;
import cn.M1N3S3NS3.UI.Astolfo.ValueButton;
import cn.M1N3S3NS3.UI.Astolfo.asClickgui;
import cn.M1N3S3NS3.UI.Font.CFontRenderer;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import java.awt.Color;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class KeyBindButton
extends ValueButton {
    public Module cheat;
    public double opacity = 0.0;
    public boolean bind;

    public KeyBindButton(Module cheat, int x, int y) {
        super(null, x, y);
        this.custom = true;
        this.bind = false;
        this.cheat = cheat;
    }

    @Override
    public void render(int mouseX, int mouseY, Limitation limitation) {
        CFontRenderer mfont = FontLoaders.Comfortaa17;
        GL11.glEnable((int)3089);
        limitation.cut();
        Gui.drawRect(0.0, 0.0, 0.0, 0.0, 0);
        mfont.drawStringWithShadow("Bind", this.x - 7, this.y + 2, new Color(108, 108, 108).getRGB());
        mfont.drawStringWithShadow(String.valueOf(String.valueOf(this.bind ? "" : "")) + Keyboard.getKeyName((int)this.cheat.getKey()), this.x + 77 - mfont.getStringWidth(Keyboard.getKeyName((int)this.cheat.getKey())), this.y + 2, new Color(108, 108, 108).getRGB());
        GL11.glDisable((int)3089);
    }

    @Override
    public void key(char typedChar, int keyCode) {
        if (this.bind) {
            this.cheat.setKey(keyCode);
            if (keyCode == 1) {
                this.cheat.setKey(0);
            }
            asClickgui.binding = false;
            this.bind = false;
        }
        super.key(typedChar, keyCode);
    }

    @Override
    public void click(int mouseX, int mouseY, int button) {
        if (mouseX > this.x - 7 && mouseX < this.x + 85 && mouseY > this.y - 6 && mouseY < this.y + FontLoaders.Comfortaa17.getStringHeight(this.cheat.getName()) + 5 && button == 0) {
            this.bind = !this.bind;
            asClickgui.binding = this.bind;
        }
        super.click(mouseX, mouseY, button);
    }
}

