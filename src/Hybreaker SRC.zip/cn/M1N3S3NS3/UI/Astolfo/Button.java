/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.UI.Astolfo;

import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.Astolfo.ColorValueButton;
import cn.M1N3S3NS3.UI.Astolfo.KeyBindButton;
import cn.M1N3S3NS3.UI.Astolfo.Limitation;
import cn.M1N3S3NS3.UI.Astolfo.ValueButton;
import cn.M1N3S3NS3.UI.Astolfo.Window;
import cn.M1N3S3NS3.UI.Font.CFontRenderer;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import com.google.common.collect.Lists;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

public class Button {
    public Module cheat;
    public Window parent;
    public int x;
    public int y;
    CFontRenderer font = FontLoaders.Comfortaa18;
    public int enable;
    public int arrow;
    public int index;
    public int remander;
    private int valueY;
    public double opacity = 0.0;
    public ArrayList<ValueButton> buttons = Lists.newArrayList();
    public boolean expand;
    int staticColor;

    public Button(Module cheat, int x, int y) {
        CFontRenderer font = FontLoaders.Comfortaa18;
        CFontRenderer mfont = FontLoaders.Comfortaa16;
        CFontRenderer bigfont = FontLoaders.Comfortaa18;
        this.cheat = cheat;
        this.x = x;
        this.y = y;
        int y2 = y + 15;
        this.valueY = 0;
        for (Value<?> v : cheat.getValues()) {
            this.buttons.add(new ValueButton(v, x + 5, y2));
            y2 += 15;
        }
        Client.instance.getModuleManager();
        if (cheat == ModuleManager.getModuleByClass(HUD.class)) {
            this.buttons.add(new ColorValueButton(x + 15, y2));
        }
        this.buttons.add(new KeyBindButton(cheat, x + 5, y2));
    }

    public static void doGlScissor(int x, int y, int width, int height) {
        Minecraft mc = Minecraft.getMinecraft();
        int scaleFactor = 1;
        int k = mc.gameSettings.guiScale;
        if (k == 0) {
            k = 1000;
        }
        while (scaleFactor < k && mc.displayWidth / (scaleFactor + 1) >= 320 && mc.displayHeight / (scaleFactor + 1) >= 240) {
            ++scaleFactor;
        }
        GL11.glScissor((int)(x * scaleFactor), (int)(mc.displayHeight - (y + height) * scaleFactor), (int)(width * scaleFactor), (int)(height * scaleFactor));
    }

    public void render(int mouseX, int mouseY, Limitation limitation) {
        CFontRenderer font = FontLoaders.Comfortaa17;
        CFontRenderer mfont = FontLoaders.Comfortaa18;
        CFontRenderer bigfont = FontLoaders.Comfortaa18;
        if (this.index != 0) {
            Button b2 = this.parent.buttons.get(this.index - 1);
            this.y = b2.y + 15 + (b2.expand ? 15 * b2.buttons.size() : 0);
        }
        int i = 0;
        while (i < this.buttons.size()) {
            this.buttons.get((int)i).y = this.y + 14 + 15 * i;
            this.buttons.get((int)i).x = this.x + 5;
            ++i;
        }
        if (this.parent.category.equals("Combat")) {
            this.staticColor = new Color(231, 76, 60).getRGB();
        } else if (this.parent.category.name().equals("Visual")) {
            this.staticColor = new Color(54, 1, 205).getRGB();
        } else if (this.parent.category.name().equals("Movement")) {
            this.staticColor = new Color(45, 203, 113).getRGB();
        } else if (this.parent.category.name().equals("Player")) {
            this.staticColor = new Color(141, 68, 173).getRGB();
        } else if (this.parent.category.name().equals("Other")) {
            this.staticColor = new Color(38, 154, 255).getRGB();
        }
        int staticColor = new Color(182, 182, 182).getRGB();
        GL11.glPushMatrix();
        GL11.glEnable((int)3089);
        Button.doGlScissor(this.x - 5, this.y - 5, 90, font.getStringHeight(this.cheat.getName().toLowerCase()) + 5);
        limitation.cut();
        Gui.drawRect(this.x - 5, this.y - 5, this.x + 85, this.y + 5 + font.getStringHeight(this.cheat.getName().toLowerCase()), new Color(39, 39, 39).getRGB());
        if (this.cheat.isEnabled()) {
            limitation.cut();
            Gui.drawRect(this.x - 4, this.y - 5, this.x + 84, this.y + 10, staticColor);
        }
        if (this.cheat.isEnabled()) {
            if (this.enable < 180) {
                this.enable += 10;
            }
            limitation.cut();
            mfont.drawStringWithShadow(this.cheat.getName().toLowerCase(), this.x + 81 - mfont.getStringWidth(this.cheat.getName().toLowerCase()), this.y, new Color(220, 220, 220).getRGB());
        } else {
            if (this.enable > 0) {
                this.enable -= 10;
            }
            limitation.cut();
            mfont.drawStringWithShadow(this.cheat.getName().toLowerCase(), this.x + 81 - mfont.getStringWidth(this.cheat.getName().toLowerCase()), this.y, new Color(220, 220, 220).getRGB());
        }
        if (this.cheat.getValues().size() > 0) {
            GlStateManager.pushMatrix();
            GlStateManager.translate(this.x + 78, this.y + 2, 0.0f);
            GlStateManager.rotate(this.arrow, 0.0f, 0.0f, 1.0f);
            if (this.expand && this.arrow < 180) {
                this.arrow += 10;
            } else if (!this.expand && this.arrow > 0) {
                this.arrow -= 10;
            }
            GlStateManager.translate(-(this.x + 78), -(this.y + 2), 0.0f);
            GlStateManager.popMatrix();
        }
        GL11.glDisable((int)3089);
        GL11.glPopMatrix();
        if (this.expand) {
            this.buttons.forEach(component -> component.render(mouseX, mouseY, limitation));
        }
    }

    public void key(char typedChar, int keyCode) {
        this.buttons.forEach(b -> b.key(typedChar, keyCode));
    }

    private boolean isHovering(int n, int n2) {
        boolean b = n >= this.x && n <= this.x - 7 && n2 >= this.y && n2 <= this.y + this.font.getStringHeight(this.cheat.getName());
        return b;
    }

    public void click(int mouseX, int mouseY, int button) {
        if (mouseX > this.x - 7 && mouseX < this.x + 85 && mouseY > this.y - 6 && mouseY < this.y + this.font.getStringHeight(this.cheat.getName())) {
            if (button == 0) {
                this.cheat.setEnabled(!this.cheat.isEnabled());
            }
            if (button == 1 && !this.buttons.isEmpty()) {
                this.expand = !this.expand;
                boolean bl = this.expand;
            }
        }
        if (this.expand) {
            this.buttons.forEach(b -> b.click(mouseX, mouseY, button));
        }
    }

    public void setParent(Window parent) {
        this.parent = parent;
        int i = 0;
        while (i < this.parent.buttons.size()) {
            if (this.parent.buttons.get(i) == this) {
                this.index = i;
                this.remander = this.parent.buttons.size() - i;
                break;
            }
            ++i;
        }
    }
}

