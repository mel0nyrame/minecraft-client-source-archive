/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.Render;

import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.Util.RenderUtil;
import java.awt.Color;

public class ColorSettings {
    static int x;
    static int y;
    public static int color;
    static int ticks;

    static {
        y = 0;
    }

    public ColorSettings() {
        color = ((Double)HUD.color.getValue()).intValue();
    }

    public void render(int x, int y, int mouseX, int mouseY, boolean isKeyDown) {
        ColorSettings.x = x;
        ColorSettings.y = y;
        ticks = 0;
        while (ticks < 50) {
            Color rainbowcolor = new Color(Color.HSBtoRGB((float)((double)ticks / 50.0 + Math.sin(1.6)) % 1.0f, 0.5f, 1.0f));
            if (mouseX > x && mouseX < x + 50 && mouseY > y && mouseY < y + 9 && isKeyDown) {
                color = new Color(Color.HSBtoRGB((float)((double)(mouseX - x) / 50.0 + Math.sin(1.6)) % 1.0f, 0.5f, 1.0f)).getRGB();
                HUD.color.setValue(Double.valueOf(color));
                RenderUtil.drawRect(mouseX - 1, mouseY - 1, mouseX + 1, mouseY + 1, new Color(100, 100, 100, 100).getRGB());
            }
            if (mouseX > x && mouseX < x + 50 && mouseY > y && mouseY < y + 9) {
                RenderUtil.drawRect(mouseX - 1, mouseY - 1, mouseX + 1, mouseY + 1, new Color(100, 100, 100, 100).getRGB());
            }
            if (mouseX > x && mouseX < x + 50 && mouseY > y + 10 && mouseY < y + 13 && isKeyDown) {
                HUD.color.setValue(-1.0);
            }
            if (mouseX > x && mouseX < x + 50 && mouseY > y + 10 && mouseY < y + 13) {
                RenderUtil.drawRect(mouseX - 1, mouseY - 1, mouseX + 1, mouseY + 1, new Color(100, 100, 100, 100).getRGB());
            }
            RenderUtil.drawRect(x + ticks, y, x + ticks + 1, y + 9, rainbowcolor.getRGB());
            RenderUtil.drawRect(x + 55, y, x + 68, y + 13, color);
            RenderUtil.drawRect(x + ticks, y + 10, x + ticks + 1, y + 13, -1);
            ++ticks;
        }
        if (++ticks > 50) {
            ticks = 0;
        }
    }
}

