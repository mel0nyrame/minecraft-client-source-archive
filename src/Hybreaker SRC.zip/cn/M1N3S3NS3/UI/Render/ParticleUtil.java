/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.UI.Render;

import cn.M1N3S3NS3.particle.ParticleGenerator;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

public class ParticleUtil {
    private static final ParticleGenerator particleGenerator = new ParticleGenerator(100);

    public static void drawParticles(int mouseX, int mouseY, int color) {
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GL11.glEnable((int)2881);
        particleGenerator.draw(mouseX, mouseY, color);
        GL11.glDisable((int)2881);
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }
}

