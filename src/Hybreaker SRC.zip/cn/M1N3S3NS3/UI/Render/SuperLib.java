/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.UI.Render;

import cn.M1N3S3NS3.Util.PlayerUtil;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class SuperLib {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static String removeColorCode(String text) {
        String finalText = text;
        if (text.contains("\u00a7")) {
            int i = 0;
            while (i < finalText.length()) {
                if (Character.toString(finalText.charAt(i)).equals("\u00a7")) {
                    try {
                        String part1 = finalText.substring(0, i);
                        String part2 = finalText.substring(Math.min(i + 2, finalText.length()));
                        finalText = String.valueOf(part1) + part2;
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
                ++i;
            }
        }
        return finalText;
    }

    public static int reAlpha(int color, float alpha) {
        Color c = new Color(color);
        float r = 0.003921569f * (float)c.getRed();
        float g = 0.003921569f * (float)c.getGreen();
        float b = 0.003921569f * (float)c.getBlue();
        return new Color(r, g, b, alpha).getRGB();
    }

    public static void drawImage(ResourceLocation image, int x, int y, int width, int height) {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        Minecraft.getMinecraft();
        Minecraft.getTextureManager().bindTexture(image);
        Gui.drawModalRectWithCustomSizedTexture(x, y, 0.0f, 0.0f, width, height, (float)width, (float)height);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
    }

    public static double getAnimationState(double animation, double finalState, double speed) {
        float add = (float)(0.01 * speed);
        animation = animation < finalState ? (animation + (double)add < finalState ? (animation += (double)add) : finalState) : (animation - (double)add > finalState ? (animation -= (double)add) : finalState);
        return animation;
    }

    public static double getAnimationState2(double animation, double finalState, double speed) {
        float add = (float)(0.01 * speed);
        animation = animation < finalState ? finalState : (animation - (double)add > finalState ? (animation -= (double)add) : finalState);
        return animation;
    }

    public static void setSpeed(double speed) {
        Minecraft.thePlayer.motionX = -Math.sin(PlayerUtil.getDirection()) * speed;
        Minecraft.thePlayer.motionZ = Math.cos(PlayerUtil.getDirection()) * speed;
    }

    public static double getSpeed() {
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        return Math.sqrt(Minecraft.thePlayer.motionX * Minecraft.thePlayer.motionX + Minecraft.thePlayer.motionZ * Minecraft.thePlayer.motionZ);
    }

    public static enum Colors {
        BLACK(-16711423),
        BLUE(-12028161),
        DARKBLUE(-12621684),
        GREEN(-9830551),
        DARKGREEN(-9320847),
        WHITE(-65794),
        AQUA(-7820064),
        DARKAQUA(-12621684),
        GREY(-9868951),
        DARKGREY(-14342875),
        RED(-65536),
        DARKRED(-8388608),
        ORANGE(-29696),
        DARKORANGE(-2263808),
        YELLOW(-256),
        DARKYELLOW(-2702025),
        MAGENTA(-18751),
        DARKMAGENTA(-2252579);

        public int c;

        private Colors(int co) {
            this.c = co;
        }
    }
}

