/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL20
 */
package cn.M1N3S3NS3.UI.Render;

import cn.M1N3S3NS3.UI.Render.GLSLShader;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL20;

public class MainSandBox
extends GLSLShader {
    private long lastMS = System.currentTimeMillis();
    private float time;

    public MainSandBox() {
        super("sandbox.frag");
    }

    @Override
    public void setupUniforms() {
        this.setupUniform("resolution");
        this.setupUniform("time");
    }

    @Override
    public void updateUniforms() {
        int timeID;
        long currentMS = System.currentTimeMillis();
        long delta = currentMS - this.lastMS;
        this.lastMS = currentMS;
        ScaledResolution scaledResolution = new ScaledResolution(mc);
        int resolutionID = this.getUniform("resolution");
        if (resolutionID > -1) {
            GL20.glUniform2f((int)resolutionID, (float)((float)ScaledResolution.getScaledWidth() * 2.0f), (float)((float)ScaledResolution.getScaledHeight() * 2.0f));
        }
        if ((timeID = this.getUniform("time")) > -1) {
            GL20.glUniform1f((int)timeID, (float)this.time);
        }
        this.time += 0.002f * (float)delta;
    }
}

