/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.UI.Render;

import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.Util.Render.RenderUtil;
import cn.M1N3S3NS3.Util.timer.TimeHelper;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StringUtils;
import org.lwjgl.opengl.GL11;

public class UIFlatButton
extends GuiButton {
    private TimeHelper time = new TimeHelper();
    public String displayString;
    public int id;
    public boolean enabled;
    public boolean visible;
    protected boolean hovered;
    private int color;
    private float opacity;

    public UIFlatButton(int buttonId, int x, int y, int widthIn, int heightIn, String buttonText, int color) {
        super(buttonId, x, y, 10, 12, buttonText);
        this.width = widthIn;
        this.height = heightIn;
        this.enabled = true;
        this.visible = true;
        this.id = buttonId;
        this.xPosition = x;
        this.yPosition = y;
        this.displayString = buttonText;
        this.color = color;
    }

    @Override
    protected int getHoverState(boolean mouseOver) {
        int i = 1;
        if (!this.enabled) {
            i = 0;
        } else if (mouseOver) {
            i = 2;
        }
        return i;
    }

    @Override
    public void drawButton(Minecraft mc, int mouseX, int mouseY) {
        if (this.visible) {
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            this.hovered = mouseX >= this.xPosition && mouseY >= this.yPosition && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
            int var5 = this.getHoverState(this.hovered);
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            GlStateManager.blendFunc(770, 771);
            if (!this.hovered) {
                this.time.reset();
                this.opacity = 0.0f;
            }
            if (this.hovered) {
                this.opacity += 0.5f;
                if (this.opacity > 1.0f) {
                    this.opacity = 1.0f;
                }
            }
            float radius = (float)this.height / 2.0f;
            RenderUtil.drawFastRoundedRect((int)((float)this.xPosition - this.opacity * 0.1f), (float)this.yPosition - this.opacity, (int)((float)(this.xPosition + this.width) + this.opacity * 0.1f), (float)this.yPosition + radius * 2.0f + this.opacity, 1.0f, this.color);
            GL11.glColor3f((float)2.55f, (float)2.55f, (float)2.55f);
            this.mouseDragged(mc, mouseX, mouseY);
            GL11.glPushMatrix();
            GL11.glPushAttrib((int)1048575);
            GL11.glScaled((double)1.0, (double)1.0, (double)1.0);
            boolean var6 = true;
            float var10000 = FontLoaders.Comfortaa16.getStringHeight(StringUtils.stripControlCodes(this.displayString));
            FontLoaders.Comfortaa16.drawCenteredString(this.displayString, this.xPosition + this.width / 2, (float)this.yPosition + (float)(this.height - FontLoaders.Comfortaa16.FONT_HEIGHT) / 2.0f + 4.0f, this.hovered ? -1 : -1);
            GL11.glPopAttrib();
            GL11.glPopMatrix();
        }
    }

    private Color darkerColor(Color c, int step) {
        int n;
        int red = c.getRed();
        int blue = c.getBlue();
        int green = c.getGreen();
        if (red >= step) {
            n = red - step;
        }
        if (blue >= step) {
            n = blue - step;
        }
        if (green >= step) {
            n = green - step;
        }
        return c.darker();
    }

    @Override
    protected void mouseDragged(Minecraft mc, int mouseX, int mouseY) {
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY) {
    }

    @Override
    public boolean mousePressed(Minecraft mc, int mouseX, int mouseY) {
        return this.enabled && this.visible && mouseX >= this.xPosition && mouseY >= this.yPosition && mouseX < this.xPosition + this.width && mouseY < this.yPosition + this.height;
    }

    @Override
    public boolean isMouseOver() {
        return this.hovered;
    }

    @Override
    public void drawButtonForegroundLayer(int mouseX, int mouseY) {
    }

    @Override
    public void playPressSound(SoundHandler soundHandlerIn) {
        soundHandlerIn.playSound(PositionedSoundRecord.create(new ResourceLocation("gui.button.press"), 1.0f));
    }

    @Override
    public int getButtonWidth() {
        return this.width;
    }

    @Override
    public void setWidth(int width) {
        this.width = width;
    }
}

