/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.Render;

import cn.M1N3S3NS3.UI.shader.shaders.RainbowBackground;

public class BGrender {
    public static final RainbowBackground background = new RainbowBackground();

    public static void render() {
        try {
            background.startShader();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void end() {
        background.stopShader();
    }
}

