/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.LWJGLException
 *  org.lwjgl.input.Cursor
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.Display
 */
package cn.M1N3S3NS3.UI;

import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Render.ClickGui;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.Util.Chat.ChatUtil;
import cn.M1N3S3NS3.Util.Color.ColorUtil;
import cn.M1N3S3NS3.Util.MathUtils;
import cn.M1N3S3NS3.Util.Render.RenderUtil2;
import cn.M1N3S3NS3.Util.Render.TranslateUtil;
import java.awt.Color;
import java.io.IOException;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Cursor;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;

public class ClickGuiScreen
extends GuiScreen {
    private static boolean exiting;
    private int guiWidth;
    private int guiHeight;
    private static int x;
    private static int y;
    private static int dragX;
    private static int dragY;
    private boolean dragging;
    private boolean scale;
    private final TranslateUtil startAnimation = new TranslateUtil(0.0f, 0.0f);
    private final TranslateUtil wheelAnimation = new TranslateUtil(0.0f, 0.0f);
    private static float wheel;
    private static ModuleType currentCategory;
    private static ArrayList<Module> extendedModuleList;
    Cursor emptyCursor;

    static {
        extendedModuleList = new ArrayList();
    }

    public ClickGuiScreen() {
        this.startAnimation.setX(0.0f);
        this.startAnimation.setY(0.0f);
        this.guiWidth = Client.instance.getClickGuiWidth();
        this.guiHeight = Client.instance.getClickGuiHeight();
        this.dragging = false;
        this.scale = false;
        dragX = 0;
        dragY = 0;
        this.hideCursor();
    }

    @Override
    public void initGui() {
        super.initGui();
        if (x + this.guiWidth > this.width) {
            x = 5;
        }
        if (y + this.guiHeight > this.height) {
            y = 5;
        }
        if (x + this.guiWidth > this.width) {
            this.guiWidth = 310;
        }
        if (y + this.guiHeight > this.height) {
            this.guiHeight = 200;
        }
        this.dragging = false;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        int onceHeight;
        int debugging;
        super.drawScreen(mouseX, mouseY, partialTicks);
        if (!Mouse.isButtonDown((int)0) && this.dragging) {
            this.dragging = false;
        }
        if (!Mouse.isButtonDown((int)0) && this.scale) {
            this.scale = false;
        }
        if (this.dragging) {
            x = mouseX - dragX;
            y = mouseY - dragY;
        } else if (this.scale) {
            this.guiWidth = Math.max(mouseX - x, 310);
            this.guiHeight = Math.max(mouseY - y, 200);
        }
        if (((Boolean)ClickGui.getBottomValue().getValue()).booleanValue()) {
            int value2 = 31 - ((Number)ClickGui.getGradientValue().getValue()).intValue();
            int rainbowTick = 0;
            while (rainbowTick < this.width) {
                Color c = ColorUtil.getRainbow(10.0f, 1.0f, 0.5f, (long)rainbowTick * (long)(31 - value2));
                RenderUtil2.drawVerticalGradientSideways(rainbowTick, (float)this.height - this.wheelAnimation.getX(), rainbowTick + value2, this.height, 15, new Color(c.getRed(), c.getGreen(), c.getBlue(), 130).getRGB());
                rainbowTick += value2;
            }
        }
        int roundedScissorW = Math.round(this.startAnimation.getX());
        int roundedScissorH = Math.round(this.startAnimation.getY());
        RenderUtil2.startGlScissor(x, y, roundedScissorW, roundedScissorH);
        ClickGuiScreen.drawRect(x, y, x + this.guiWidth, y + this.guiHeight, new Color(15, 15, 15).getRGB());
        switch ((ClickGui.grilleEnums)((Object)ClickGui.getGrilleValue().getValue())) {
            case HUD: {
                int i = 0;
                while (i < this.guiWidth) {
                    ClickGuiScreen.drawRect(x + i, y, x + i + 1, y + this.guiHeight, ColorUtil.reAlpha(HUD.getCustomColor(), 30).getRGB());
                    i += 3;
                }
                break;
            }
            case Rainbow: {
                int i = 0;
                while (i < this.guiWidth) {
                    ClickGuiScreen.drawRect(x + i, y, x + i + 1, y + this.guiHeight, ColorUtil.getRainbow(7.0f, 1.0f, 0.1f, (long)i * 2L).getRGB());
                    i += 3;
                }
                break;
            }
        }
        int moduleY = (int)this.wheelAnimation.getY();
        for (Module m : Client.instance.getModuleManager().getModuleList()) {
            if (m.getType() != currentCategory) continue;
            debugging = extendedModuleList.contains(m);
            ClickGuiScreen.drawRect(x + 95, y + 15 + moduleY, x + this.guiWidth - 5, y + 39 + moduleY, new Color(15, 15, 15).getRGB());
            ClickGuiScreen.drawRect(x + 95, y + 15 + moduleY, x + 97, y + 45 + moduleY, m.isEnabled() ? -1 : new Color(130, 130, 130).getRGB());
            Client.instance.getFontManager().Tahoma18.drawString(m.getName(), x + 100, y + 20 + moduleY, m.isEnabled() ? -1 : new Color(130, 130, 130).getRGB());
            if (debugging != 0) {
                onceHeight = 20;
                ClickGuiScreen.drawRect(x + 97, y + 39 + moduleY, x + this.guiWidth - 7, y + 42 + moduleY + m.getValues().size() * onceHeight, new Color(15, 15, 15).getRGB());
                RenderUtil2.drawVerticalGradientSideways(x + 97, y + 39 + moduleY, x + this.guiWidth - 7, y + 44 + moduleY, new Color(0, 0, 0, 100).getRGB(), 15);
                for (Value<?> value : m.getValues()) {
                    Value s;
                    Client.instance.getFontManager().Tahoma16.drawString(value.getDisplayName(), x + 100, y + 45 + moduleY, -1);
                    Client.instance.getFontManager().Tahoma14.drawString(value.getName(), x + 100, y + 53 + moduleY, -1);
                    if (value instanceof Mode) {
                        s = (Mode)value;
                        boolean hoverOnEnum = MathUtils.inRange(mouseX, mouseY, x + this.guiWidth - 10, y + 54 + moduleY, x + this.guiWidth - 90, y + 44 + moduleY);
                        ClickGuiScreen.drawRect(x + this.guiWidth - 90, y + 44 + moduleY, x + this.guiWidth - 10, y + 54 + moduleY, new Color(0, 0, 0, 150).getRGB());
                        Client.instance.getFontManager().Tahoma14.drawCenteredString(((Mode)s).getModeAsString(), x + this.guiWidth - 50, y + 48 + moduleY, -1);
                        if (hoverOnEnum) {
                            ClickGuiScreen.drawRect(x + this.guiWidth - 90, y + 44 + moduleY, x + this.guiWidth - 10, y + 54 + moduleY, new Color(0, 0, 0, 80).getRGB());
                        }
                    }
                    if (value instanceof Option) {
                        boolean hoverOnBool = MathUtils.inRange(mouseX, mouseY, x + this.guiWidth - 10, y + 54 + moduleY, x + this.guiWidth - 20, y + 44 + moduleY);
                        ClickGuiScreen.drawRect(x + this.guiWidth - 20, y + 44 + moduleY, x + this.guiWidth - 10, y + 54 + moduleY, new Color(0, 0, 0, 150).getRGB());
                        if (((Boolean)value.getValue()).booleanValue()) {
                            ClickGuiScreen.drawRect(x + this.guiWidth - 19, y + 45 + moduleY, x + this.guiWidth - 11, y + 53 + moduleY, HUD.getCustomColor().getRGB());
                        }
                        if (hoverOnBool) {
                            ClickGuiScreen.drawRect(x + this.guiWidth - 20, y + 44 + moduleY, x + this.guiWidth - 10, y + 54 + moduleY, new Color(0, 0, 0, 80).getRGB());
                        }
                    }
                    if (value instanceof Numbers) {
                        s = (Numbers)value;
                        double inc = ((Number)((Numbers)s).getIncrement()).doubleValue();
                        double max = ((Number)((Numbers)s).getMaximum()).doubleValue();
                        double min = ((Number)((Numbers)s).getMinimum()).doubleValue();
                        double now = ((Number)s.getValue()).doubleValue();
                        Client.instance.getFontManager().Tahoma14.drawString(String.valueOf(now), x + this.guiWidth - 109, y + 45 + moduleY, -1);
                        int rectWidth = x + this.guiWidth - 10 - (x + this.guiWidth - 110);
                        ClickGuiScreen.drawRect(x + this.guiWidth - 110, y + 52 + moduleY, x + this.guiWidth - 10, y + 56 + moduleY, new Color(0, 0, 0, 150).getRGB());
                        ClickGuiScreen.drawRect(x + this.guiWidth - 110, y + 52 + moduleY, (int)((double)(x + this.guiWidth - 110) + (double)rectWidth * (now - min) / (max - min)), y + 56 + moduleY, HUD.getCustomColor().getRGB());
                        boolean hoverOnNum = MathUtils.inRange(mouseX, mouseY, x + this.guiWidth - 10 + 4, y + 56 + moduleY + 4, x + this.guiWidth - 110 - 4, y + 51 + moduleY - 4);
                        if (hoverOnNum) {
                            ClickGuiScreen.drawRect(x + this.guiWidth - 110, y + 52 + moduleY, x + this.guiWidth - 10, y + 56 + moduleY, new Color(0, 0, 0, 80).getRGB());
                            if (Mouse.isButtonDown((int)0)) {
                                double valAbs = mouseX - (x + this.guiWidth - 110);
                                double perc = valAbs / ((double)rectWidth * Math.max(Math.min(now / max, 0.0), 1.0));
                                perc = Math.min(Math.max(0.0, perc), 1.0);
                                double valRel = (max - min) * perc;
                                double val = min + valRel;
                                val = (double)Math.round(val * (1.0 / inc)) / (1.0 / inc);
                                s.setValue(val);
                            }
                        }
                    }
                    moduleY += onceHeight;
                }
            }
            moduleY += 27;
        }
        ClickGuiScreen.drawRect(x, y, x + this.guiWidth, y + 10, new Color(15, 15, 15).getRGB());
        RenderUtil2.drawVerticalGradientSideways(x + 90, y + 10, x + this.guiWidth, y + 15, new Color(20, 20, 20, 100).getRGB(), 15);
        ClickGuiScreen.drawRect(x, y, x + 90, y + this.guiHeight, new Color(15, 15, 15).getRGB());
        RenderUtil2.drawHorizontalGradientSideways(x + 90, y, x + 95, y + this.guiHeight, new Color(20, 20, 20, 100).getRGB(), 15);
        Client.instance.getFontManager().logo32.drawCenteredString("MineSense", x + 45, y + 20, new Color(200, 200, 200).getRGB());
        int categoryHeight = 0;
        ModuleType[] moduleTypeArray = ModuleType.values();
        onceHeight = moduleTypeArray.length;
        debugging = 0;
        while (debugging < onceHeight) {
            ModuleType category = moduleTypeArray[debugging];
            String name = String.valueOf(currentCategory == category ? "\u00a7f" : "") + category.name();
            boolean onCategory = MathUtils.inRange(mouseX, mouseY, (float)(x + 47) + (float)Client.instance.getFontManager().Tahoma18.getStringWidth(name) / 2.0f, (float)y + (float)this.guiHeight / 2.0f - 35.0f + 5.0f + (float)categoryHeight + 8.0f, (float)(x + 43) - (float)Client.instance.getFontManager().Tahoma18.getStringWidth(name) / 2.0f, (float)y + (float)this.guiHeight / 2.0f - 35.0f + 1.0f + (float)categoryHeight);
            Client.instance.getFontManager().Tahoma18.drawCenteredString(name, x + 45, (float)y + (float)this.guiHeight / 2.0f - 35.0f + 5.0f + (float)categoryHeight, new Color(onCategory ? 130 : 150, onCategory ? 130 : 150, onCategory ? 130 : 150).getRGB());
            categoryHeight += 14;
            ++debugging;
        }
        if (((Boolean)ClickGui.getBorderValue().getValue()).booleanValue()) {
            ClickGuiScreen.drawRect(x, y, x + 1, y + this.guiHeight, HUD.getCustomColor().getRGB());
            ClickGuiScreen.drawRect(x, y, x + this.guiWidth, y + 1, HUD.getCustomColor().getRGB());
            ClickGuiScreen.drawRect(x + this.guiWidth - 1, y, x + this.guiWidth, y + this.guiHeight, HUD.getCustomColor().getRGB());
            ClickGuiScreen.drawRect(x, y + this.guiHeight - 1, x + this.guiWidth, y + this.guiHeight, HUD.getCustomColor().getRGB());
        }
        RenderUtil2.stopGlScissor();
        int real = Mouse.getDWheel();
        float moduleHeight = (float)moduleY - this.wheelAnimation.getY();
        if (Mouse.hasWheel() && MathUtils.inRange(mouseX, mouseY, x + this.guiWidth, y + this.guiHeight, x, y)) {
            int i;
            if (real > 0 && wheel < 0.0f) {
                i = 0;
                while (i < 5) {
                    if (wheel < 0.0f) {
                        wheel += 5.0f;
                        ++i;
                        continue;
                    }
                    break;
                }
            } else {
                i = 0;
                while (i < 5) {
                    if (real < 0 && moduleHeight > (float)this.guiHeight && Math.abs(wheel) < moduleHeight - (float)(this.guiHeight - 12)) {
                        wheel -= 5.0f;
                        ++i;
                        continue;
                    }
                    break;
                }
            }
        }
        this.startAnimation.interpolate(exiting ? 0 : this.guiWidth, exiting ? 0 : this.guiHeight, this.scale ? 1.0f : (exiting ? 0.4f : 0.2f));
        this.wheelAnimation.interpolate(exiting ? 0 : 120, wheel, exiting ? 0.4f : 0.2f);
        if (exiting) {
            if (ClickGui.memoriseX != x) {
                Client.instance.setClickGuiX(x);
            }
            if (ClickGui.memoriseY != y) {
                Client.instance.setClickGuiY(y);
            }
            if (Client.instance.getClickGuiWidth() != x) {
                Client.instance.setClickGuiWidth(this.guiWidth);
            }
            if (Client.instance.getClickGuiHeight() != y) {
                Client.instance.setClickGuiHeight(this.guiHeight);
            }
            if ((float)ClickGui.memoriseWheel != wheel) {
                ClickGuiScreen.setWheel((int)wheel);
            }
            if (ClickGui.memoriseCatecory != currentCategory) {
                ClickGuiScreen.setCategory(currentCategory);
            }
            ClickGuiScreen.setInSetting(extendedModuleList);
            if (Display.isActive() && !this.mc.inGameHasFocus) {
                this.mc.inGameHasFocus = true;
                this.mc.mouseHelper.grabMouseCursor();
            }
            if (this.startAnimation.getX() == this.startAnimation.getY() && this.startAnimation.getX() == 0.0f) {
                this.mc.displayGuiScreen(null);
            }
        } else {
            boolean onScale = MathUtils.inRange(mouseX, mouseY, x + this.guiWidth, y + this.guiHeight, x + this.guiWidth - 7, y + this.guiHeight - 7);
            GlStateManager.pushMatrix();
            GlStateManager.enableBlend();
            Minecraft.getTextureManager().bindTexture(new ResourceLocation("ZenithAssets/arrow.png"));
            int n = 16;
            Color c = onScale ? ColorUtil.getDarker(HUD.getCustomColor(), 50, 255) : HUD.getCustomColor();
            GlStateManager.color((float)c.getRed() * 0.003921569f, (float)c.getGreen() * 0.003921569f, (float)c.getBlue() * 0.003921569f);
            ClickGuiScreen.drawModalRectWithCustomSizedTexture(mouseX, mouseY, 0.0f, 0.0f, n, n, (float)n, (float)n);
            GlStateManager.resetColor();
            GlStateManager.disableBlend();
            GlStateManager.popMatrix();
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        boolean onMove = MathUtils.inRange(mouseX, mouseY, x + this.guiWidth, y + 10, x, y);
        boolean onScale = MathUtils.inRange(mouseX, mouseY, x + this.guiWidth, y + this.guiHeight, x + this.guiWidth - 7, y + this.guiHeight - 7);
        if (onMove) {
            if (mouseButton == 0) {
                dragX = mouseX - x;
                dragY = mouseY - y;
                this.dragging = true;
            }
        } else if (onScale) {
            if (mouseButton == 0) {
                this.scale = true;
            }
        } else {
            if (mouseButton == 0) {
                int categoryHeight = 0;
                ModuleType[] moduleTypeArray = ModuleType.values();
                int n = moduleTypeArray.length;
                int n2 = 0;
                while (n2 < n) {
                    ModuleType category = moduleTypeArray[n2];
                    String name = String.valueOf(currentCategory == category ? "> " : "") + category.name();
                    boolean onCategory = MathUtils.inRange(mouseX, mouseY, (float)(x + 47) + (float)Client.instance.getFontManager().Tahoma18.getStringWidth(name) / 2.0f, (float)y + (float)this.guiHeight / 2.0f - 35.0f + 5.0f + (float)categoryHeight + 8.0f, (float)(x + 43) - (float)Client.instance.getFontManager().Tahoma18.getStringWidth(name) / 2.0f, (float)y + (float)this.guiHeight / 2.0f - 35.0f + 1.0f + (float)categoryHeight);
                    if (currentCategory != category && onCategory) {
                        currentCategory = category;
                        this.wheelAnimation.setY(0.0f);
                        wheel = 0.0f;
                        return;
                    }
                    categoryHeight += 14;
                    ++n2;
                }
            }
            int moduleY = (int)this.wheelAnimation.getY();
            for (Module m : Client.instance.getModuleManager().getModuleList()) {
                if (m.getType() != currentCategory) continue;
                boolean debugging = extendedModuleList.contains(m);
                boolean hoverOnM = MathUtils.inRange(mouseX, mouseY, x + this.guiWidth - 5, y + 39 + moduleY, x + 95, y + 15 + moduleY);
                if (hoverOnM) {
                    if (mouseButton == 0) {
                        m.toggle();
                    } else if (mouseButton == 1) {
                        if (extendedModuleList.contains(m)) {
                            extendedModuleList.remove(m);
                        } else {
                            extendedModuleList.add(m);
                        }
                    }
                }
                if (debugging) {
                    int onceHeight = 20;
                    ClickGuiScreen.drawRect(x + 97, y + 39 + moduleY, x + this.guiWidth - 7, y + 42 + moduleY + m.getValues().size() * onceHeight, new Color(40, 40, 40).getRGB());
                    RenderUtil2.drawVerticalGradientSideways(x + 97, y + 39 + moduleY, x + this.guiWidth - 7, y + 44 + moduleY, new Color(0, 0, 0, 100).getRGB(), 15);
                    for (Value<?> value : m.getValues()) {
                        Client.instance.getFontManager().Tahoma16.drawString(value.getDisplayName(), x + 100, y + 45 + moduleY, -1);
                        Client.instance.getFontManager().Tahoma14.drawString(value.getName(), x + 100, y + 53 + moduleY, -1);
                        if (value instanceof Mode) {
                            Mode s = (Mode)value;
                            boolean hoverOnEnum = MathUtils.inRange(mouseX, mouseY, x + this.guiWidth - 10, y + 54 + moduleY, x + this.guiWidth - 90, y + 44 + moduleY);
                            if (hoverOnEnum) {
                                Enum current;
                                if (mouseButton == 1) {
                                    current = (Enum)s.getValue();
                                    s.setValue(s.getModes()[current.ordinal() - 1 < 0 ? s.getModes().length - 1 : current.ordinal() - 1]);
                                }
                                if (mouseButton == 0) {
                                    current = (Enum)s.getValue();
                                    int next = current.ordinal() + 1 >= s.getModes().length ? 0 : current.ordinal() + 1;
                                    s.setValue(s.getModes()[next]);
                                }
                            }
                        }
                        if (value instanceof Option) {
                            Option bool = (Option)value;
                            boolean hoverOnBool = MathUtils.inRange(mouseX, mouseY, x + this.guiWidth - 10, y + 54 + moduleY, x + this.guiWidth - 20, y + 44 + moduleY);
                            if (hoverOnBool) {
                                bool.setValue((Boolean)bool.getValue() == false);
                            }
                        }
                        moduleY += onceHeight;
                    }
                }
                moduleY += 27;
            }
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        boolean onMove = MathUtils.inRange(mouseX, mouseY, x + this.guiWidth, y + 10, x, y);
        boolean onScale = MathUtils.inRange(mouseX, mouseY, x + this.guiWidth, y + this.guiHeight, x + this.guiWidth - 7, y + this.guiHeight - 7);
        if (onMove) {
            if (state == 0) {
                dragX = mouseX - x;
                dragY = mouseY - y;
                this.dragging = false;
            }
        } else if (onScale && state == 0) {
            this.scale = false;
        }
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
        ClickGui.memoriseX = x;
        ClickGui.memoriseY = y;
        ClickGui.memoriseWheel = (int)wheel;
        ClickGui.memoriseML = extendedModuleList;
        ClickGui.memoriseCatecory = currentCategory;
        exiting = false;
        try {
            Mouse.setNativeCursor(null);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private void hideCursor() {
        if (this.emptyCursor == null) {
            if (Mouse.isCreated()) {
                int min = Cursor.getMinCursorSize();
                IntBuffer tmp = BufferUtils.createIntBuffer((int)(min * min));
                try {
                    this.emptyCursor = new Cursor(min, min, min / 2, min / 2, 1, tmp, null);
                }
                catch (LWJGLException e) {
                    e.printStackTrace();
                }
            } else {
                ChatUtil.printChat("Could not create empty cursor before Mouse object is created");
            }
        }
        try {
            Mouse.setNativeCursor((Cursor)(Mouse.isInsideWindow() ? this.emptyCursor : null));
        }
        catch (LWJGLException e) {
            e.printStackTrace();
        }
    }

    public static void setX(int state) {
        x = state;
    }

    public static void setY(int state) {
        y = state;
    }

    public static void setCategory(ModuleType state) {
        currentCategory = state;
    }

    public static void setInSetting(List<Module> moduleList) {
        extendedModuleList = (ArrayList)moduleList;
    }

    public static void setWheel(int state) {
        wheel = state;
    }

    public static boolean isExiting() {
        return exiting;
    }

    public static void setExiting(boolean exiting) {
        ClickGuiScreen.exiting = exiting;
    }
}

