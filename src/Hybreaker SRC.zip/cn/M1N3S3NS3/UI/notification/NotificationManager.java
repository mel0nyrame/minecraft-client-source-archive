/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.notification;

import cn.M1N3S3NS3.API.EventBus;
import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.notification.Notification;
import cn.M1N3S3NS3.UI.notification.NotificationType;
import cn.M1N3S3NS3.Util.RenderUtil;
import cn.M1N3S3NS3.font.cfont.CFontRenderer;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.gui.ScaledResolution;

public class NotificationManager {
    private final ArrayList<Notification> notifications = new ArrayList();

    public NotificationManager() {
        EventBus.getInstance().register(this);
    }

    @EventHandler
    void onRenderOverlay(EventRender2D event) {
        ScaledResolution sr = event.getSR();
        int yy = 30;
        for (Notification notification : this.notifications) {
            CFontRenderer font = Client.instance.getFontManager().Tahoma18;
            CFontRenderer small = Client.instance.getFontManager().Tahoma16;
            String typeR = String.valueOf(notification.getType().name().charAt(0)) + notification.getType().name().substring(1).toLowerCase();
            int targetWid = Math.max(font.getStringWidth(typeR), small.getStringWidth(String.valueOf(notification.getMessage()) + 4));
            int color = notification.getType() == NotificationType.ERROR ? Color.RED.getRGB() : (notification.getType() == NotificationType.WARN ? new Color(252, 216, 0).getRGB() : new Color(255, 255, 255).getRGB());
            float y = notification.getScissor().getY();
            float targetWidth = notification.getScissor().getX();
            int staticColor = new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue()).getRGB();
            RenderUtil.drawRect((float)ScaledResolution.getScaledWidth() - targetWidth, (float)ScaledResolution.getScaledHeight() - y - 23.0f, ScaledResolution.getScaledWidth(), (float)ScaledResolution.getScaledHeight() - y, new Color(7, 7, 7, 120).getRGB());
            RenderUtil.drawRect((float)ScaledResolution.getScaledWidth() - Math.max(targetWidth * (float)(notification.getTime() - notification.getAnimationTimer().getDifference()) / (float)notification.getTime(), 0.0f), (float)ScaledResolution.getScaledHeight() - y - 23.0f, ScaledResolution.getScaledWidth(), (float)ScaledResolution.getScaledHeight() - y, new Color(7, 7, 7, 150).getRGB());
            RenderUtil.drawRect((float)ScaledResolution.getScaledWidth() - targetWidth, (float)ScaledResolution.getScaledHeight() - y - 23.0f, ScaledResolution.getScaledWidth(), (float)ScaledResolution.getScaledHeight() - y - 22.0f, staticColor);
            font.drawString(typeR, (float)ScaledResolution.getScaledWidth() - targetWidth + 2.0f, (float)ScaledResolution.getScaledHeight() - y - 18.0f, -1);
            small.drawString(notification.getMessage(), (float)ScaledResolution.getScaledWidth() - targetWidth + 2.0f, (float)ScaledResolution.getScaledHeight() - y - 10.0f + 3.0f, -1);
            if (notification.getAnimationTimer().hasPassed(notification.getTime())) {
                notification.getScissor().interpolate(0.0f, 0.0f, 0.15f);
            } else {
                notification.getScissor().interpolate(targetWid, yy, 0.15f);
                yy += 23;
            }
            if (!notification.getRemoveTimer().hasPassed(notification.getTime() + 500L)) continue;
            this.notifications.remove(notification);
        }
    }

    public ArrayList<Notification> getNotifications() {
        return this.notifications;
    }
}

