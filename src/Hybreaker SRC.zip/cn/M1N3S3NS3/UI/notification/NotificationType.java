/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.notification;

public enum NotificationType {
    INFO,
    WARN,
    ERROR;

}

