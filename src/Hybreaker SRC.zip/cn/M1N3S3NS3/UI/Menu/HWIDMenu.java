/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package cn.M1N3S3NS3.UI.Menu;

import cn.M1N3S3NS3.UI.Menu.GuiClientMainMenu;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import org.lwjgl.input.Keyboard;

public class HWIDMenu
extends GuiScreen {
    public static GuiTextField hwid;
    public static int user;
    static String status;

    static {
        status = "";
    }

    private void setStatus(String s) {
        status = s;
    }

    public static String getStatus() {
        return status;
    }

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents((boolean)true);
        hwid = new GuiTextField(user, Minecraft.fontRendererObj, this.width / 2 - 100, this.width / 2 - 20 - 100, 200, 20);
        hwid.setMaxStringLength(16);
        this.buttonList.add(new GuiButton(1001, this.width / 2 - 100, this.width / 2 + 20 - 100, "Start"));
        this.buttonList.add(new GuiButton(154, this.width / 2 - 100, this.width / 2 + 50 - 100, "Copy Hwid"));
    }

    public static void lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII(String v) {
        StringSelection stringSelection = new StringSelection(v);
        Clipboard clpbrd = Toolkit.getDefaultToolkit().getSystemClipboard();
        clpbrd.setContents(stringSelection, null);
    }

    @Override
    public void actionPerformed(GuiButton button) {
        switch (button.id) {
            case 154: {
                try {
                    HWIDMenu.lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII(String.valueOf(new StringBuilder(String.valueOf(HWIDMenu.getHWID()))));
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            case 1001: {
                try {
                    String[] strings = HWIDMenu.requestURLSRC("https://hybreakerclient.coding.net/p/Client/d/HWID/git/raw/master/HWID?download=false").split("!");
                    boolean contains = false;
                    String[] stringArray = strings;
                    int n = strings.length;
                    int n2 = 0;
                    while (n2 < n) {
                        String s = stringArray[n2];
                        if (!s.equalsIgnoreCase(String.valueOf(HWIDMenu.getHWID()) + ":" + hwid.getText())) {
                            System.out.print("Hwid-Login Activated");
                            this.mc.displayGuiScreen(new GuiClientMainMenu());
                        }
                        ++n2;
                    }
                    break;
                }
                catch (Exception e) {
                    this.mc.shutdownMinecraftApplet();
                }
            }
        }
    }

    public static String getHWID() throws NoSuchAlgorithmException, UnsupportedEncodingException {
        String s = "";
        String main = String.valueOf(System.getenv("PROCESSOR_IDENTIFIER")) + System.getenv("COMPUTERNAME") + System.getProperty("user.name").trim();
        byte[] bytes = main.getBytes("UTF-8");
        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        byte[] md5 = messageDigest.digest(bytes);
        int i = 0;
        byte[] byArray = md5;
        int n = md5.length;
        int n2 = 0;
        while (n2 < n) {
            byte b = byArray[n2];
            s = String.valueOf(s) + Integer.toHexString(b & 0xFF | 0x300).substring(0, 3);
            if (i != md5.length - 1) {
                s = String.valueOf(s) + "-";
            }
            ++i;
            ++n2;
        }
        return s;
    }

    public static String requestURLSRC(String BLviCHHy76v5Ch39PB3hpcX7W2qe45YaBPQyn285Dcg27) throws IOException {
        URL urlObject = new URL(BLviCHHy76v5Ch39PB3hpcX7W2qe45YaBPQyn285Dcg27);
        URLConnection urlConnection = urlObject.openConnection();
        urlConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
        return HWIDMenu.AP2iKAwcS2gFL8cX8z944ZiJp2zS54T68Tp39nr2rJAwh(urlConnection.getInputStream());
    }

    private static String AP2iKAwcS2gFL8cX8z944ZiJp2zS54T68Tp39nr2rJAwh(InputStream L58C336iNBkwz86u4QV3HcDJ94i34gWv4gpzbqBC5ZCdG) throws IOException {
        Throwable throwable = null;
        Object var2_3 = null;
        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(L58C336iNBkwz86u4QV3HcDJ94i34gWv4gpzbqBC5ZCdG, "UTF-8"));){
            String inputLine;
            StringBuilder stringBuilder = new StringBuilder();
            while ((inputLine = bufferedReader.readLine()) != null) {
                stringBuilder.append(inputLine);
            }
            return stringBuilder.toString();
        }
        catch (Throwable throwable2) {
            if (throwable == null) {
                throwable = throwable2;
            } else if (throwable != throwable2) {
                throwable.addSuppressed(throwable2);
            }
            throw throwable;
        }
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents((boolean)false);
    }

    @Override
    public void drawScreen(int x2, int y2, float z2) {
        this.drawDefaultBackground();
        hwid.drawTextBox();
        super.drawScreen(x2, y2, z2);
    }

    @Override
    public void mouseClicked(int x2, int y2, int z2) {
        try {
            super.mouseClicked(x2, y2, z2);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        hwid.mouseClicked(x2, y2, z2);
    }

    @Override
    protected void keyTyped(char character, int key) {
        hwid.textboxKeyTyped(character, key);
        if (character == '\r') {
            this.actionPerformed((GuiButton)this.buttonList.get(0));
        }
    }
}

