/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.UI.Menu;

import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Module.Modules.Render.CustomColor;
import cn.M1N3S3NS3.UI.Login.GuiAltManager;
import cn.M1N3S3NS3.UI.Render.ParticleUtil;
import cn.M1N3S3NS3.Util.Math.MathUtil;
import cn.M1N3S3NS3.Util.Render.Colors;
import cn.M1N3S3NS3.Util.Render.TranslateUtil;
import cn.M1N3S3NS3.Util.RenderUtil;
import cn.M1N3S3NS3.font.cfont.CFontRenderer;
import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

public class GuiClientMainMenu
extends GuiScreen {
    private int alpha;
    private boolean inChangeLog = false;
    private TranslateUtil translate = new TranslateUtil(0.0f, 0.0f);
    private static String verChecks = "\u00a7cChecking...";
    private float translateX;
    private float translateY;

    public GuiClientMainMenu() {
        this.alpha = Client.instance.isAnimated() ? 0 : 255;
        this.translate.setY(0.0f);
        this.translate.setX(0.0f);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        super.drawScreen(mouseX, mouseY, partialTicks);
        this.drawDefaultBackground();
        ScaledResolution sr = new ScaledResolution(this.mc);
        GlStateManager.pushMatrix();
        this.translateX += ((float)mouseX - (float)this.width / 2.0f - this.translateX) / (float)sr.getScaleFactor() * 0.5f;
        this.translateY += ((float)mouseY - (float)this.height / 2.0f - this.translateY) / (float)sr.getScaleFactor() * 0.5f;
        GlStateManager.translate(this.translateX / 50.0f, this.translateY / 50.0f, 0.0f);
        ParticleUtil.drawParticles(mouseX, mouseY, CustomColor.getRainbow(6000, -15));
        CFontRenderer font = Client.instance.getFontManager().arial18;
        CFontRenderer small = Client.instance.getFontManager().arial14;
        int trans = 0;
        int i = 0;
        while (i < 5) {
            boolean inIt = !this.inChangeLog && MathUtil.inRange(mouseX, mouseY, (float)this.width / 2.0f + 70.0f, (float)this.height / 2.0f - 21.5f + (float)trans, (float)this.width / 2.0f - 70.0f, (float)this.height / 2.0f - 37.5f + (float)trans);
            RenderUtil.drawRect((float)this.width / 2.0f - 70.0f, (float)this.height / 2.0f - 37.5f + (float)trans, (float)this.width / 2.0f + 70.0f, (float)this.height / 2.0f - 21.5f + (float)trans, new Color(0, 0, 0, inIt ? 200 : 150).getRGB());
            switch (i) {
                case 0: {
                    font.drawCenteredString("Single Player", (float)this.width / 2.0f, (float)this.height / 2.0f - 37.0f + 5.0f + (float)trans, -1);
                    break;
                }
                case 1: {
                    font.drawCenteredString("Multi Player", (float)this.width / 2.0f, (float)this.height / 2.0f - 37.0f + 5.0f + (float)trans, -1);
                    break;
                }
                case 2: {
                    font.drawCenteredString("Alt Manager", (float)this.width / 2.0f, (float)this.height / 2.0f - 37.0f + 5.0f + (float)trans, -1);
                    break;
                }
                case 3: {
                    font.drawCenteredString("Options", (float)this.width / 2.0f, (float)this.height / 2.0f - 37.0f + 5.0f + (float)trans, -1);
                    break;
                }
                case 4: {
                    font.drawCenteredString("Exit", (float)this.width / 2.0f, (float)this.height / 2.0f - 37.0f + 5.0f + (float)trans, -1);
                }
            }
            trans += 18;
            ++i;
        }
        GlStateManager.popMatrix();
        RenderUtil.drawRect(0.0, 0.0, this.width, this.height, new Color(0, 0, 0, (int)this.translate.getX()).getRGB());
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glScaled((double)0.5, (double)0.5, (double)0.5);
        int color = Colors.getColor(255, 255, 255, 170);
        int add = Colors.getColor(0, 255, 0, 170);
        int imp = Colors.getColor(0, 255, 255, 170);
        int del = Colors.getColor(255, 0, 0, 170);
        Minecraft.fontRendererObj.drawStringWithShadow("ChangLog:", 5.0f, 2.0f, new Color(255, 255, 255, 255).getRGB());
        Minecraft.fontRendererObj.drawStringWithShadow("Build #080621", 5.0f, 14.0f, color);
        Minecraft.fontRendererObj.drawStringWithShadow("[X]Cracked:nivalc", 5.0f, 24.0f, del);
        Minecraft.fontRendererObj.drawStringWithShadow("[X]Copyer:SovietSevneLLLL.", 5.0f, 36.0f, del);
        Minecraft.fontRendererObj.drawStringWithShadow("[+]Adds New Xray[PowerX 9X9].", 5.0f, 48.0f, del);
        Minecraft.fontRendererObj.drawStringWithShadow("Build #081221", 5.0f, 60.0f, color);
        Minecraft.fontRendererObj.drawStringWithShadow("[+]Adds NoJumpDelay.", 5.0f, 72.0f, add);
        Minecraft.fontRendererObj.drawStringWithShadow("[+]New Speed Bypass Watchdoging (Mode New).", 5.0f, 84.0f, add);
        Minecraft.fontRendererObj.drawStringWithShadow("[+]Fixed NoSlow (No Packet).", 5.0f, 96.0f, add);
        Minecraft.fontRendererObj.drawStringWithShadow("[\u221a]Fixed Criticals (Packet).", 5.0f, 108.0f, add);
        Minecraft.fontRendererObj.drawStringWithShadow("[\u221a]Fixed Scaffold Tower Lag.", 5.0f, 120.0f, add);
        GL11.glPopMatrix();
        this.alpha = Math.max(this.alpha -= 5, 0);
        GuiClientMainMenu.drawRect(0, 0, this.width, this.height, new Color(0, 0, 0, this.alpha).getRGB());
        if (!Client.instance.isAnimated()) {
            Client.instance.setAnimated(true);
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (mouseButton == 0) {
            int trans = 0;
            int i = 0;
            while (i < 5) {
                boolean inIt = MathUtil.inRange(mouseX, mouseY, (float)this.width / 2.0f + 70.0f, (float)this.height / 2.0f - 21.5f + (float)trans, (float)this.width / 2.0f - 70.0f, (float)this.height / 2.0f - 37.5f + (float)trans);
                if (i == 0 && inIt) {
                    this.mc.displayGuiScreen(new GuiSelectWorld(this));
                    break;
                }
                if (i == 1 && inIt) {
                    this.mc.displayGuiScreen(new GuiMultiplayer(this));
                    break;
                }
                if (i == 2 && inIt) {
                    this.mc.displayGuiScreen(new GuiAltManager());
                    break;
                }
                if (i == 3 && inIt) {
                    this.mc.displayGuiScreen(new GuiOptions(this, this.mc.gameSettings));
                    break;
                }
                if (i == 4 && inIt) {
                    this.mc.shutdown();
                    break;
                }
                trans += 18;
                ++i;
            }
        }
    }

    public static void setVerChecks(String ver) {
        verChecks = ver;
    }
}

