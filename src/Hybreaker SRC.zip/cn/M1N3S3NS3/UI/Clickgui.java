/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.UI;

import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.Font.CFontRenderer;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.UI.Render.ColorSettings;
import cn.M1N3S3NS3.UI.Render.Render2D;
import cn.M1N3S3NS3.Util.Render.Colors;
import cn.M1N3S3NS3.Util.RenderUtil;
import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiYesNoCallback;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class Clickgui
extends GuiScreen
implements GuiYesNoCallback {
    public static ModuleType currentModuleType = ModuleType.Combat;
    public static Module currentModule = ModuleManager.getModulesInType(currentModuleType).size() != 0 ? ModuleManager.getModulesInType(currentModuleType).get(0) : null;
    public static float startX = 100.0f;
    public static float startY = 100.0f;
    int i1 = 0;
    public int moduleStart = 0;
    public int valueStart = 0;
    boolean previousmouse = true;
    float x;
    float mY;
    boolean a = false;
    String inmode = null;
    String nowinmode = null;
    String inmodule = null;
    String sx = null;
    boolean mouseinmode = false;
    boolean mouse;
    boolean modulemouse;
    public int opacityx = 255;
    public float moveX = 0.0f;
    public float moveY = 0.0f;
    int rainbowTick = 0;
    int addY = 0;
    public static CFontRenderer titlefont = FontLoaders.Comfortaa20;
    Color rainbow1;

    public Clickgui() {
        this.rainbow1 = new Color(Color.HSBtoRGB((float)((double)Minecraft.thePlayer.ticksExisted / 50.0 + Math.sin((double)this.rainbowTick / 50.0 * 1.6)) % 1.0f, 0.7f, 1.0f));
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (this.isHovered(startX, startY - 25.0f, startX + 400.0f, startY + 25.0f, mouseX, mouseY) && Mouse.isButtonDown((int)0)) {
            if (this.moveX == 0.0f && this.moveY == 0.0f) {
                this.moveX = (float)mouseX - startX;
                this.moveY = (float)mouseY - startY;
            } else {
                startX = (float)mouseX - this.moveX;
                startY = (float)mouseY - this.moveY;
            }
            this.previousmouse = true;
        } else if (this.moveX != 0.0f || this.moveY != 0.0f) {
            this.moveX = 0.0f;
            this.moveY = 0.0f;
        }
        Render2D.drawRect((double)startX, (double)startY, (double)(startX + 450.0f), (double)(startY + 300.0f), new Color(5, 5, 5).getRGB());
        Render2D.drawBorderedRect((double)startX + 0.5, (double)startY + 0.5, (double)(startX + 450.0f) - 0.5, (double)(startY + 300.0f) - 0.5, 0.5, new Color(40, 40, 40).getRGB(), new Color(60, 60, 60).getRGB(), true);
        Render2D.drawBorderedRect(startX + 2.0f, startY + 2.0f, startX + 450.0f - 2.0f, startY + 300.0f - 2.0f, 0.5, new Color(22, 22, 22).getRGB(), new Color(60, 60, 60).getRGB(), true);
        Render2D.drawBorderedRect(startX + 2.0f, startY + 2.0f, startX + 50.0f - 2.0f, startY + 300.0f - 2.0f, 0.5, new Color(15, 15, 15).getRGB(), new Color(60, 60, 60).getRGB(), true);
        Render2D.drawRect((double)startX + 2.5, (double)startY + 2.5, (double)(startX + 450.0f) - 2.5, (double)startY + 4.5, new Color(9, 9, 9).getRGB());
        Render2D.drawGradientSideways(startX + 3.0f, startY + 3.0f, (double)(startX + 450.0f) - 2.5, startY + 4.0f, Colors.getColor(55, 177, 218), Colors.getColor(204, 77, 198), Colors.getColor(204, 221, 59));
        Render2D.drawBorderedRect(startX + 190.0f, startY + 20.0f, startX + 440.0f, startY + 280.0f - 2.0f, 0.5, new Color(15, 15, 15).getRGB(), new Color(60, 60, 60).getRGB(), true);
        Render2D.drawRect((double)(startX + 195.0f), (double)(startY + 20.0f), (double)(startX + 222.0f), (double)(startY + 25.0f), new Color(15, 15, 15).getRGB());
        FontLoaders.Comfortaa16.drawString("Settings", startX + 197.0f, startY + 20.0f, -1);
        int i = 0;
        while (i < ModuleType.values().length) {
            ModuleType[] iterator = ModuleType.values();
            GL11.glPushMatrix();
            FontLoaders.Comfortaa16.drawStringWithShadow("N", startX + 6.0f + 3.0f, startY + 7.0f, new Color(((Double)HUD.color.getValue()).intValue()).getRGB());
            FontLoaders.Comfortaa16.drawStringWithShadow("iko", startX + 6.0f + (float)FontLoaders.Comfortaa16.getStringWidth("N") + 3.0f, startY + 7.0f, -1);
            if (iterator[i] == currentModuleType) {
                if (iterator[i].name() == "Combat") {
                    Render2D.drawBorderedRect(startX + 2.0f, startY + 20.0f, startX + 50.0f - 2.0f, startY + 65.0f - 2.0f, 0.5, new Color(22, 22, 22).getRGB(), new Color(50, 50, 50).getRGB(), true);
                    Gui.drawRect(startX + 47.0f, (double)(startY + 20.0f + 1.0f) - 0.5, startX + 50.0f, (double)(startY + 65.0f) - 2.5, new Color(22, 22, 22).getRGB());
                }
                if (iterator[i].name() == "Render") {
                    Render2D.drawBorderedRect(startX + 2.0f, startY + 62.0f, startX + 50.0f - 2.0f, startY + 103.0f, 0.5, new Color(22, 22, 22).getRGB(), new Color(50, 50, 50).getRGB(), true);
                    Gui.drawRect(startX + 47.0f, (double)(startY + 62.0f) + 0.5, startX + 50.0f, (double)(startY + 103.0f) - 0.5, new Color(22, 22, 22).getRGB());
                }
                if (iterator[i].name() == "Move") {
                    Render2D.drawBorderedRect(startX + 2.0f, startY + 103.0f, startX + 50.0f - 2.0f, startY + 143.0f, 0.5, new Color(22, 22, 22).getRGB(), new Color(50, 50, 50).getRGB(), true);
                    Gui.drawRect(startX + 47.0f, (double)(startY + 103.0f) + 0.5, startX + 50.0f, (double)(startY + 143.0f) - 0.5, new Color(22, 22, 22).getRGB());
                }
                if (iterator[i].name() == "Player") {
                    Render2D.drawBorderedRect(startX + 2.0f, startY + 143.0f, startX + 50.0f - 2.0f, startY + 183.0f - 2.0f, 0.5, new Color(22, 22, 22).getRGB(), new Color(50, 50, 50).getRGB(), true);
                    Gui.drawRect(startX + 47.0f, (double)(startY + 143.0f) + 0.5, startX + 50.0f, (double)(startY + 181.0f) - 0.5, new Color(22, 22, 22).getRGB());
                }
                if (iterator[i].name() == "MegaWalls") {
                    Render2D.drawBorderedRect(startX + 2.0f, startY + 183.0f, startX + 50.0f - 2.0f, startY + 223.0f - 2.0f, 0.5, new Color(22, 22, 22).getRGB(), new Color(50, 50, 50).getRGB(), true);
                    Gui.drawRect(startX + 47.0f, (double)(startY + 183.0f) + 0.5, startX + 50.0f, (double)(startY + 221.0f) - 0.5, new Color(22, 22, 22).getRGB());
                }
            }
            if (iterator[i].name() == "Combat") {
                FontLoaders.NovICON46.drawString("J", startX + 15.0f, startY + 33.0f, iterator[i] == currentModuleType ? -1 : new Color(200, 200, 200).getRGB());
            }
            if (iterator[i].name() == "Render") {
                FontLoaders.NovICON40.drawString("C", startX + 15.0f, startY + 73.0f, iterator[i] == currentModuleType ? -1 : new Color(200, 200, 200).getRGB());
            }
            if (iterator[i].name() == "Move") {
                FontLoaders.NovICON40.drawString("E", startX + 15.0f, startY + 115.0f, iterator[i] == currentModuleType ? -1 : new Color(200, 200, 200).getRGB());
            }
            if (iterator[i].name() == "Player") {
                FontLoaders.NovICON36.drawString("F", startX + 15.0f, startY + 155.0f, iterator[i] == currentModuleType ? -1 : new Color(200, 200, 200).getRGB());
            }
            if (iterator[i].name() == "MegaWalls") {
                FontLoaders.NovICON36.drawString("I", startX + 15.0f, startY + 195.0f, iterator[i] == currentModuleType ? -1 : new Color(200, 200, 200).getRGB());
            }
            GL11.glPopMatrix();
            try {
                if (this.isCategoryHovered(startX, startY + 15.0f + (float)(titlefont.getStringHeight("Nino-") + 3) + (float)(i * 40), startX + 45.0f, startY + 45.0f + (float)(titlefont.getStringHeight("Nino-") + 3) + (float)(i * 40), mouseX, mouseY) && Mouse.isButtonDown((int)0)) {
                    currentModuleType = iterator[i];
                    currentModule = ModuleManager.getModulesInType(currentModuleType).size() != 0 ? ModuleManager.getModulesInType(currentModuleType).get(0) : null;
                    this.moduleStart = 0;
                }
            }
            catch (Exception e) {
                System.err.println(e);
            }
            ++i;
        }
        int m = Mouse.getDWheel();
        if (this.isCategoryHovered(startX + 60.0f, startY + (float)(titlefont.getStringHeight("Nino-") + 3), startX + 200.0f, startY + (float)(titlefont.getStringHeight("Nino-") + 3) + 320.0f, mouseX, mouseY)) {
            if (m < 0 && this.moduleStart < ModuleManager.getModulesInType(currentModuleType).size() - 12) {
                ++this.moduleStart;
            }
            if (m > 0 && this.moduleStart > 0) {
                --this.moduleStart;
            }
        }
        if (this.isCategoryHovered(startX + 200.0f, startY + (float)(titlefont.getStringHeight("Nino-") + 3), startX + 420.0f, startY + (float)(titlefont.getStringHeight("Nino-") + 3) + 320.0f, mouseX, mouseY)) {
            if (m < 0 && this.valueStart < currentModule.getValues().size() - 14) {
                ++this.valueStart;
            }
            if (m > 0 && this.valueStart > 0) {
                --this.valueStart;
            }
        }
        FontLoaders.Comfortaa16.drawStringWithShadow(currentModule == null ? currentModuleType.toString() : String.valueOf(currentModuleType.toString()) + "-" + currentModule.getName(), startX + 430.0f - (float)FontLoaders.Comfortaa16.getStringWidth(currentModule == null ? currentModuleType.toString() : String.valueOf(currentModuleType.toString()) + "-" + currentModule.getName()), startY + 8.0f, new Color(((Double)HUD.color.getValue()).intValue()).getRGB());
        if (currentModule != null) {
            this.mY = startY + 20.0f;
            int i2 = 0;
            while (i2 < ModuleManager.getModulesInType(currentModuleType).size()) {
                Module module = ModuleManager.getModulesInType(currentModuleType).get(i2);
                if (this.mY > startY + 280.0f) break;
                if (i2 >= this.moduleStart) {
                    if (!module.isEnabled()) {
                        Render2D.drawBorderedRect(startX + 65.0f, this.mY + 2.0f, startX + 175.0f, this.mY + 20.0f, 0.5, new Color(22, 22, 22).getRGB(), new Color(60, 60, 60).getRGB(), true);
                        Render2D.drawBorderedRect(startX + 161.0f, this.mY + 4.0f + 5.0f, startX + 165.0f, this.mY + 13.0f, 0.5, new Color(22, 22, 22).getRGB(), new Color(60, 60, 60).getRGB(), true);
                    } else {
                        Render2D.drawBorderedRect(startX + 65.0f, this.mY + 2.0f, startX + 175.0f, this.mY + 20.0f, 0.5, new Color(22, 22, 22).getRGB(), new Color(60, 60, 60).getRGB(), true);
                        Render2D.drawBorderedRect(startX + 161.0f, this.mY + 4.0f + 5.0f, startX + 165.0f, this.mY + 13.0f, 0.5, new Color(225, 225, 225).getRGB(), new Color(60, 60, 60).getRGB(), true);
                    }
                    FontLoaders.Comfortaa16.drawStringWithShadow(module.getName(), startX + 75.0f, this.mY + 9.0f, module.isEnabled() ? new Color(((Double)HUD.color.getValue()).intValue()).getRGB() : new Color(200, 200, 200).getRGB());
                    this.inmodule = module.getName();
                    if (this.isSettingsButtonHovered(startX + 80.0f, this.mY - 5.0f, startX + 140.0f + (float)FontLoaders.Comfortaa20.getStringWidth(module.getName()), this.mY + 8.0f + (float)FontLoaders.Comfortaa20.getHeight() + 5.0f, mouseX, mouseY)) {
                        if (!this.previousmouse && Mouse.isButtonDown((int)0)) {
                            if (module.isEnabled()) {
                                module.setEnabled(false);
                            } else {
                                module.setEnabled(true);
                            }
                            this.previousmouse = true;
                        }
                        if (!this.previousmouse && Mouse.isButtonDown((int)1)) {
                            this.previousmouse = true;
                        }
                    }
                    if (!Mouse.isButtonDown((int)0)) {
                        this.previousmouse = false;
                    }
                    if (this.isSettingsButtonHovered(startX + 90.0f, this.mY, startX + 100.0f + (float)FontLoaders.Comfortaa20.getStringWidth(module.getName()), this.mY + 8.0f + (float)FontLoaders.Comfortaa20.getHeight(), mouseX, mouseY) && Mouse.isButtonDown((int)1)) {
                        currentModule = module;
                        this.valueStart = 0;
                    }
                    this.mY += 22.0f;
                }
                ++i2;
            }
            this.mY = startY + 30.0f;
            i2 = 0;
            while (i2 < currentModule.getValues().size() && !(this.mY > startY + 265.0f)) {
                if (i2 >= this.valueStart) {
                    Value<?> value = currentModule.getValues().get(i2);
                    if (value instanceof Numbers) {
                        this.x = startX + 205.0f;
                        if (value.getName().equals("Colors")) {
                            FontLoaders.Comfortaa16.drawStringWithShadow(value.getName(), startX + 200.0f, this.mY + 4.0f, -1);
                            new ColorSettings().render((int)startX + 250, (int)this.mY, mouseX, mouseY, Mouse.isButtonDown((int)0));
                            this.mY += 18.0f;
                        } else {
                            this.x = startX + 205.0f;
                            double render = 68.0f * (((Number)value.getValue()).floatValue() - ((Number)((Numbers)value).getMinimum()).floatValue()) / (((Number)((Numbers)value).getMaximum()).floatValue() - ((Number)((Numbers)value).getMinimum()).floatValue());
                            Render2D.drawBorderedRect(this.x - 6.0f - 1.0f, this.mY + 2.0f + 5.0f - 1.0f, (float)((double)this.x + 75.0), this.mY + 5.0f + 5.0f + 1.0f, 0.5, new Color(22, 22, 22).getRGB(), new Color(12, 12, 12).getRGB(), true);
                            RenderUtil.drawRect(this.x - 6.0f, this.mY + 2.0f + 5.0f, (float)((double)this.x + render + 6.5), this.mY + 5.0f + 5.0f, -1);
                            FontLoaders.Comfortaa16.drawStringWithShadow(value.getName(), startX + 200.0f, this.mY, -1);
                            FontLoaders.Comfortaa16.drawStringWithShadow("" + value.getValue(), startX + 290.0f, this.mY + 6.0f, -1);
                            if (!Mouse.isButtonDown((int)0)) {
                                this.previousmouse = false;
                            }
                            if (this.isButtonHovered(this.x, this.mY - 2.0f + 5.0f, this.x + 100.0f, this.mY + 7.0f + 5.0f, mouseX, mouseY) && Mouse.isButtonDown((int)0)) {
                                if (!this.previousmouse && Mouse.isButtonDown((int)0)) {
                                    render = ((Number)((Numbers)value).getMinimum()).doubleValue();
                                    double max = ((Number)((Numbers)value).getMaximum()).doubleValue();
                                    double inc = ((Number)((Numbers)value).getIncrement()).doubleValue();
                                    double valAbs = (double)mouseX - ((double)this.x + 1.0);
                                    double perc = valAbs / 68.0;
                                    perc = Math.min(Math.max(0.0, perc), 1.0);
                                    double valRel = (max - render) * perc;
                                    double val = render + valRel;
                                    val = (double)Math.round(val * (1.0 / inc)) / (1.0 / inc);
                                    ((Numbers)value).setValue(val);
                                }
                                if (!Mouse.isButtonDown((int)0)) {
                                    this.previousmouse = false;
                                }
                            }
                            this.mY += 17.0f;
                        }
                    }
                    if (value instanceof Option) {
                        this.x = startX + 120.0f;
                        FontLoaders.Comfortaa16.drawStringWithShadow(value.getName(), startX + 200.0f, this.mY + 3.0f, -1);
                        if (((Boolean)value.getValue()).booleanValue()) {
                            Render2D.drawBorderedRect(this.x + 182.0f, (int)this.mY + 2, this.x + 188.0f, this.mY + 8.0f, 0.5, new Color(((Double)HUD.color.getValue()).intValue()).getRGB(), new Color(60, 60, 60).getRGB(), true);
                        } else {
                            Render2D.drawBorderedRect(this.x + 182.0f, (int)this.mY + 2, this.x + 188.0f, this.mY + 8.0f, 0.5, new Color(22, 22, 22).getRGB(), new Color(60, 60, 60).getRGB(), true);
                        }
                        if (this.isCheckBoxHovered(this.x + 80.0f, this.mY, this.x + 76.0f + 140.0f, this.mY + 9.0f, mouseX, mouseY)) {
                            if (!this.previousmouse && Mouse.isButtonDown((int)0)) {
                                this.previousmouse = true;
                                this.mouse = true;
                            }
                            if (this.mouse) {
                                value.setValue((Boolean)value.getValue() == false);
                                this.mouse = false;
                            }
                        }
                        if (!Mouse.isButtonDown((int)0)) {
                            this.previousmouse = false;
                        }
                        this.mY += 18.0f;
                    }
                    if (value instanceof Mode) {
                        int next;
                        this.x = startX + 300.0f;
                        FontLoaders.Comfortaa16.drawStringWithShadow(value.getName(), startX + 200.0f, this.mY + 1.0f, -1);
                        if (this.isStringHovered(this.x - 15.0f, this.mY, this.x + 100.0f - 25.0f, this.mY + 15.0f, mouseX, mouseY)) {
                            Render2D.drawBorderedRect(this.x - 5.0f, this.mY - 3.0f, this.x + 80.0f, this.mY + 10.0f, 0.5, new Color(40, 40, 40).getRGB(), new Color(60, 60, 60).getRGB(), true);
                        } else {
                            Render2D.drawBorderedRect(this.x - 5.0f, this.mY - 3.0f, this.x + 80.0f, this.mY + 10.0f, 0.5, new Color(40, 40, 40).getRGB(), new Color(0, 0, 0).getRGB(), true);
                        }
                        FontLoaders.Comfortaa16.drawString(((Mode)value).getModeAsString(), this.x, this.mY + 1.0f, -1);
                        this.nowinmode = String.valueOf(this.inmodule) + value.getName();
                        if (this.isStringHovered(this.x - 15.0f, this.mY, this.x + 100.0f - 25.0f, this.mY + 15.0f, mouseX, mouseY)) {
                            if (Mouse.isButtonDown((int)0) && !this.previousmouse) {
                                if (this.inmode.equals(String.valueOf(this.inmodule) + value.getName())) {
                                    this.inmode = "heshang";
                                } else {
                                    this.a = true;
                                    this.inmode = this.nowinmode;
                                }
                                this.previousmouse = true;
                            }
                            if (Mouse.isButtonDown((int)0) && !this.previousmouse) {
                                Enum current = (Enum)((Mode)value).getValue();
                                next = current.ordinal() + 1 >= ((Mode)value).getModes().length ? 0 : current.ordinal() + 1;
                                this.i1 = 0;
                                this.previousmouse = true;
                            }
                            if (!Mouse.isButtonDown((int)0)) {
                                this.previousmouse = false;
                            }
                        }
                        if (this.a) {
                            if (this.inmode.equals(String.valueOf(this.inmodule) + value.getName())) {
                                FontLoaders.Comfortaa16.drawString("\u25b6", (int)this.x + 70, (int)this.mY - 1, -1);
                                Render2D.drawBorderedRect((int)this.x + 81, (int)this.mY - 3, (int)this.x + 70 + 60, (int)this.mY - 1 + 10 * ((Mode)value).getModes().length, 0.5, new Color(22, 22, 22).getRGB(), new Color(60, 60, 60).getRGB(), true);
                                Enum current = (Enum)((Mode)value).getValue();
                                next = ((Mode)value).getModes().length - 1;
                                if (next == 0) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 1) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 2) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 3) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 4) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 5) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 6) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 7) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 8) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 9) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[9].name(), startX + 384.0f, this.mY + 1.0f + 90.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 10) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[9].name(), startX + 384.0f, this.mY + 1.0f + 90.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[10].name(), startX + 384.0f, this.mY + 1.0f + 100.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 11) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[9].name(), startX + 384.0f, this.mY + 1.0f + 90.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[10].name(), startX + 384.0f, this.mY + 1.0f + 100.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[11].name(), startX + 384.0f, this.mY + 1.0f + 110.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 12) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[9].name(), startX + 384.0f, this.mY + 1.0f + 90.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[10].name(), startX + 384.0f, this.mY + 1.0f + 100.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[11].name(), startX + 384.0f, this.mY + 1.0f + 110.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[12].name(), startX + 384.0f, this.mY + 1.0f + 120.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 13) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[9].name(), startX + 384.0f, this.mY + 1.0f + 90.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[10].name(), startX + 384.0f, this.mY + 1.0f + 100.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[11].name(), startX + 384.0f, this.mY + 1.0f + 110.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[12].name(), startX + 384.0f, this.mY + 1.0f + 120.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[13].name(), startX + 384.0f, this.mY + 1.0f + 130.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 14) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[9].name(), startX + 384.0f, this.mY + 1.0f + 90.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[10].name(), startX + 384.0f, this.mY + 1.0f + 100.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[11].name(), startX + 384.0f, this.mY + 1.0f + 110.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[12].name(), startX + 384.0f, this.mY + 1.0f + 120.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[13].name(), startX + 384.0f, this.mY + 1.0f + 130.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[14].name(), startX + 384.0f, this.mY + 1.0f + 140.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 15) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[9].name(), startX + 384.0f, this.mY + 1.0f + 90.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[10].name(), startX + 384.0f, this.mY + 1.0f + 100.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[11].name(), startX + 384.0f, this.mY + 1.0f + 110.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[12].name(), startX + 384.0f, this.mY + 1.0f + 120.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[13].name(), startX + 384.0f, this.mY + 1.0f + 130.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[14].name(), startX + 384.0f, this.mY + 1.0f + 140.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[15].name(), startX + 384.0f, this.mY + 1.0f + 150.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 16) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[9].name(), startX + 384.0f, this.mY + 1.0f + 90.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[10].name(), startX + 384.0f, this.mY + 1.0f + 100.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[11].name(), startX + 384.0f, this.mY + 1.0f + 110.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[12].name(), startX + 384.0f, this.mY + 1.0f + 120.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[13].name(), startX + 384.0f, this.mY + 1.0f + 130.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[14].name(), startX + 384.0f, this.mY + 1.0f + 140.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[15].name(), startX + 384.0f, this.mY + 1.0f + 150.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[16].name(), startX + 384.0f, this.mY + 1.0f + 160.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 17) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[9].name(), startX + 384.0f, this.mY + 1.0f + 90.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[10].name(), startX + 384.0f, this.mY + 1.0f + 100.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[11].name(), startX + 384.0f, this.mY + 1.0f + 110.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[12].name(), startX + 384.0f, this.mY + 1.0f + 120.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[13].name(), startX + 384.0f, this.mY + 1.0f + 130.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[14].name(), startX + 384.0f, this.mY + 1.0f + 140.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[15].name(), startX + 384.0f, this.mY + 1.0f + 150.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[16].name(), startX + 384.0f, this.mY + 1.0f + 160.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[17].name(), startX + 384.0f, this.mY + 1.0f + 170.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 18) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[9].name(), startX + 384.0f, this.mY + 1.0f + 90.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[10].name(), startX + 384.0f, this.mY + 1.0f + 100.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[11].name(), startX + 384.0f, this.mY + 1.0f + 110.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[12].name(), startX + 384.0f, this.mY + 1.0f + 120.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[13].name(), startX + 384.0f, this.mY + 1.0f + 130.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[14].name(), startX + 384.0f, this.mY + 1.0f + 140.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[15].name(), startX + 384.0f, this.mY + 1.0f + 150.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[16].name(), startX + 384.0f, this.mY + 1.0f + 160.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[17].name(), startX + 384.0f, this.mY + 1.0f + 170.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[18].name(), startX + 384.0f, this.mY + 1.0f + 180.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 19) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[9].name(), startX + 384.0f, this.mY + 1.0f + 90.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[10].name(), startX + 384.0f, this.mY + 1.0f + 100.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[11].name(), startX + 384.0f, this.mY + 1.0f + 110.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[12].name(), startX + 384.0f, this.mY + 1.0f + 120.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[13].name(), startX + 384.0f, this.mY + 1.0f + 130.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[14].name(), startX + 384.0f, this.mY + 1.0f + 140.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[15].name(), startX + 384.0f, this.mY + 1.0f + 150.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[16].name(), startX + 384.0f, this.mY + 1.0f + 160.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[17].name(), startX + 384.0f, this.mY + 1.0f + 170.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[18].name(), startX + 384.0f, this.mY + 1.0f + 180.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[19].name(), startX + 384.0f, this.mY + 1.0f + 190.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (next == 20) {
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[0].name(), startX + 384.0f, this.mY + 1.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[1].name(), startX + 384.0f, this.mY + 1.0f + 10.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[2].name(), startX + 384.0f, this.mY + 1.0f + 20.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[3].name(), startX + 384.0f, this.mY + 1.0f + 30.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[4].name(), startX + 384.0f, this.mY + 1.0f + 40.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[5].name(), startX + 384.0f, this.mY + 1.0f + 50.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[6].name(), startX + 384.0f, this.mY + 1.0f + 60.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[7].name(), startX + 384.0f, this.mY + 1.0f + 70.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[8].name(), startX + 384.0f, this.mY + 1.0f + 80.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[9].name(), startX + 384.0f, this.mY + 1.0f + 90.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[10].name(), startX + 384.0f, this.mY + 1.0f + 100.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[11].name(), startX + 384.0f, this.mY + 1.0f + 110.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[12].name(), startX + 384.0f, this.mY + 1.0f + 120.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[13].name(), startX + 384.0f, this.mY + 1.0f + 130.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[14].name(), startX + 384.0f, this.mY + 1.0f + 140.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[15].name(), startX + 384.0f, this.mY + 1.0f + 150.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[16].name(), startX + 384.0f, this.mY + 1.0f + 160.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[17].name(), startX + 384.0f, this.mY + 1.0f + 170.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[18].name(), startX + 384.0f, this.mY + 1.0f + 180.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[19].name(), startX + 384.0f, this.mY + 1.0f + 190.0f, new Color(225, 225, 225).getRGB());
                                    FontLoaders.Comfortaa16.drawStringWithShadow(((Mode)value).getModes()[20].name(), startX + 384.0f, this.mY + 1.0f + 200.0f, new Color(225, 225, 225).getRGB());
                                }
                                if (Mouse.isButtonDown((int)0)) {
                                    if (next >= 0 && this.isStringHovered((int)this.x + 81, (int)this.mY, (int)this.x + 70 + 60, (int)this.mY + 5, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[0]);
                                    }
                                    if (next >= 1 && this.isStringHovered((int)this.x + 81, (int)this.mY + 10, (int)this.x + 70 + 60, (int)this.mY + 5 + 10, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[1]);
                                    }
                                    if (next >= 2 && this.isStringHovered((int)this.x + 81, (int)this.mY + 20, (int)this.x + 70 + 60, (int)this.mY + 5 + 20, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[2]);
                                    }
                                    if (next >= 3 && this.isStringHovered((int)this.x + 81, (int)this.mY + 30, (int)this.x + 70 + 60, (int)this.mY + 5 + 30, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[3]);
                                    }
                                    if (next >= 4 && this.isStringHovered((int)this.x + 81, (int)this.mY + 40, (int)this.x + 70 + 60, (int)this.mY + 5 + 40, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[4]);
                                    }
                                    if (next >= 5 && this.isStringHovered((int)this.x + 81, (int)this.mY + 50, (int)this.x + 70 + 60, (int)this.mY + 5 + 50, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[5]);
                                    }
                                    if (next >= 6 && this.isStringHovered((int)this.x + 81, (int)this.mY + 60, (int)this.x + 70 + 60, (int)this.mY + 5 + 60, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[6]);
                                    }
                                    if (next >= 7 && this.isStringHovered((int)this.x + 81, (int)this.mY + 70, (int)this.x + 70 + 60, (int)this.mY + 5 + 70, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[7]);
                                    }
                                    if (next >= 8 && this.isStringHovered((int)this.x + 81, (int)this.mY + 80, (int)this.x + 70 + 60, (int)this.mY + 5 + 80, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[8]);
                                    }
                                    if (next >= 9 && this.isStringHovered((int)this.x + 81, (int)this.mY + 90, (int)this.x + 70 + 60, (int)this.mY + 5 + 90, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[9]);
                                    }
                                    if (next >= 10 && this.isStringHovered((int)this.x + 81, (int)this.mY + 100, (int)this.x + 70 + 60, (int)this.mY + 5 + 100, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[10]);
                                    }
                                    if (next >= 11 && this.isStringHovered((int)this.x + 81, (int)this.mY + 110, (int)this.x + 70 + 60, (int)this.mY + 5 + 110, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[11]);
                                    }
                                    if (next >= 12 && this.isStringHovered((int)this.x + 81, (int)this.mY + 120, (int)this.x + 70 + 60, (int)this.mY + 5 + 120, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[12]);
                                    }
                                    if (next >= 13 && this.isStringHovered((int)this.x + 81, (int)this.mY + 130, (int)this.x + 70 + 60, (int)this.mY + 5 + 130, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[13]);
                                    }
                                    if (next >= 14 && this.isStringHovered((int)this.x + 81, (int)this.mY + 140, (int)this.x + 70 + 60, (int)this.mY + 5 + 140, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[14]);
                                    }
                                    if (next >= 15 && this.isStringHovered((int)this.x + 81, (int)this.mY + 150, (int)this.x + 70 + 60, (int)this.mY + 5 + 150, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[15]);
                                    }
                                    if (next >= 16 && this.isStringHovered((int)this.x + 81, (int)this.mY + 160, (int)this.x + 70 + 60, (int)this.mY + 5 + 160, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[16]);
                                    }
                                    if (next >= 17 && this.isStringHovered((int)this.x + 81, (int)this.mY + 170, (int)this.x + 70 + 60, (int)this.mY + 5 + 170, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[17]);
                                    }
                                    if (next >= 18 && this.isStringHovered((int)this.x + 81, (int)this.mY + 180, (int)this.x + 70 + 60, (int)this.mY + 5 + 180, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[18]);
                                    }
                                    if (next >= 19 && this.isStringHovered((int)this.x + 81, (int)this.mY + 190, (int)this.x + 70 + 60, (int)this.mY + 5 + 190, mouseX, mouseY)) {
                                        value.setValue(((Mode)value).getModes()[19]);
                                    }
                                    if (next >= 20) {
                                        if (this.isStringHovered((int)this.x + 81, (int)this.mY + 200, (int)this.x + 70 + 60, (int)this.mY + 5 + 200, mouseX, mouseY)) {
                                            value.setValue(((Mode)value).getModes()[20]);
                                        }
                                        this.previousmouse = true;
                                    }
                                }
                            } else {
                                FontLoaders.Comfortaa16.drawString("\u25b2", (int)this.x + 70, (int)this.mY - 1, -1);
                            }
                        } else {
                            this.inmode = "START";
                            this.sx = "START";
                        }
                        this.mY += 17.0f;
                    }
                }
                ++i2;
            }
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
    }

    public boolean isStringHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= f && (float)mouseX <= g && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isSettingsButtonHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= x && (float)mouseX <= x2 && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isButtonHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= f && (float)mouseX <= g && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isCheckBoxHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= f && (float)mouseX <= g && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isCategoryHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= x && (float)mouseX <= x2 && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= x && (float)mouseX <= x2 && (float)mouseY >= y && (float)mouseY <= y2;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}

