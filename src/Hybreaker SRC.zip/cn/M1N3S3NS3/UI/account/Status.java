/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.account;

public class Status {
    public static String STATUS = "Idle";
}

