/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.account;

import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.Util.Theing.FieldType;
import cn.M1N3S3NS3.Util.Theing.MenuButton;
import cn.M1N3S3NS3.Util.Theing.Render2DUtil;
import cn.M1N3S3NS3.Util.Theing.TextField;
import java.io.IOException;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

public class ChangeTokenGui
extends GuiScreen {
    private GuiScreen parentScreen;
    public TextField tokenField;

    public ChangeTokenGui(GuiScreen parentScreen) {
        this.parentScreen = parentScreen;
    }

    @Override
    public void initGui() {
        this.tokenField = new TextField(FontLoaders.Comfortaa16, this.width / 2 - 75, this.height / 2 - 20, 150, 20);
        this.tokenField.setType(FieldType.NUMBERS_LETTERS_SPECIAL);
        this.tokenField.setDefaultContent("TheAltening API Token");
        this.buttonList.add(new MenuButton(2, this.width / 2 - 90, this.height / 2 + 29, 180, 20, "Back"));
        this.buttonList.add(new MenuButton(5, this.width / 2 - 90, this.height / 2 + 7, 180, 20, "Save"));
        super.initGui();
    }

    @Override
    public void updateScreen() {
        this.tokenField.updateTextField();
        super.updateScreen();
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        this.tokenField.keyTyped(typedChar, keyCode);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        this.tokenField.mouseClicked(mouseX, mouseY, mouseButton);
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 2: {
                this.mc.displayGuiScreen(this.parentScreen);
                break;
            }
            case 5: {
                Client.instance.setAlteningToken(this.tokenField.getTypedContent().replaceAll("\n", ""));
                Client.instance.saveGeneralSettings();
            }
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution scaledResolution = new ScaledResolution(this.mc);
        GlStateManager.pushMatrix();
        GlStateManager.color(1.0f, 1.0f, 1.0f);
        Render2DUtil.drawMenuBackground(scaledResolution);
        GlStateManager.popMatrix();
        this.tokenField.drawTextField();
        super.drawScreen(mouseX, mouseY, partialTicks);
    }
}

