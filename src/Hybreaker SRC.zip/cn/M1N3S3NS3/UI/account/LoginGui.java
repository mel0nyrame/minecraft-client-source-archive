/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.account;

import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.UI.account.ChangeTokenGui;
import cn.M1N3S3NS3.UI.account.Status;
import cn.M1N3S3NS3.Util.Theing.FieldType;
import cn.M1N3S3NS3.Util.Theing.LoginUtil;
import cn.M1N3S3NS3.Util.Theing.MenuButton;
import cn.M1N3S3NS3.Util.Theing.Render2DUtil;
import cn.M1N3S3NS3.Util.Theing.TextField;
import com.thealtening.api.TheAltening;
import com.thealtening.api.response.Account;
import com.thealtening.api.retriever.BasicDataRetriever;
import com.thealtening.auth.service.AlteningServiceType;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

public class LoginGui
extends GuiScreen {
    private GuiScreen parentScreen;
    private GuiButton b1;
    private TextField userpassField;
    private TextField usernameField;
    private TextField passwordField;
    private TextField tokenField;
    private BasicDataRetriever basicDataRetriever = TheAltening.newBasicRetriever(Client.instance.getAlteningToken());
    private MenuButton selector = null;

    public LoginGui(GuiScreen parentScreen) {
        this.parentScreen = parentScreen;
    }

    @Override
    public void updateScreen() {
        this.parentScreen.updateScreen();
        if (this.selector.getButtonText().equalsIgnoreCase("Switch Service")) {
            this.b1.enabled = !this.usernameField.getTypedContent().isEmpty();
            this.usernameField.updateTextField();
            this.passwordField.updateTextField();
            this.userpassField.setHidden(true);
            this.usernameField.setHidden(false);
            this.passwordField.setHidden(false);
            this.tokenField.setHidden(true);
        } else if (this.selector.getButtonText().equalsIgnoreCase("Email:Pass")) {
            this.b1.enabled = !this.userpassField.getTypedContent().isEmpty();
            this.userpassField.updateTextField();
            this.userpassField.setHidden(false);
            this.usernameField.setHidden(true);
            this.tokenField.setHidden(true);
            this.passwordField.setHidden(true);
        } else if (this.selector.getButtonText().equalsIgnoreCase("TheAltening")) {
            this.b1.enabled = !this.tokenField.getTypedContent().isEmpty();
            this.tokenField.updateTextField();
            this.userpassField.setHidden(true);
            this.usernameField.setHidden(true);
            this.tokenField.setHidden(false);
            this.passwordField.setHidden(true);
        }
    }

    @Override
    public void initGui() {
        this.usernameField = new TextField(FontLoaders.Comfortaa16, this.width / 2 - 75, this.height / 2 - 42, 150, 20);
        this.passwordField = new TextField(FontLoaders.Comfortaa16, this.width / 2 - 75, this.height / 2 - 20, 150, 20);
        this.userpassField = new TextField(FontLoaders.Comfortaa16, this.width / 2 - 75, this.height / 2 - 20, 150, 20);
        this.tokenField = new TextField(FontLoaders.Comfortaa16, this.width / 2 - 75, this.height / 2 - 20, 150, 20);
        this.usernameField.setType(FieldType.NUMBERS_LETTERS_SPECIAL);
        this.usernameField.setDefaultContent("Username/Email");
        this.passwordField.setType(FieldType.NUMBERS_LETTERS_SPECIAL);
        this.passwordField.setDefaultContent("Password");
        this.passwordField.setReplaceAll("*");
        this.userpassField.setType(FieldType.NUMBERS_LETTERS_SPECIAL);
        this.userpassField.setDefaultContent("Email:Password");
        this.tokenField.setType(FieldType.NUMBERS_LETTERS_SPECIAL);
        this.tokenField.setDefaultContent("TheAltening Token");
        this.b1 = new MenuButton(1, this.width / 2 - 90, this.height / 2 + 7, 180, 20, "Login");
        this.buttonList.add(this.b1);
        this.buttonList.add(new MenuButton(4, this.width / 2 - 90, this.height / 2 + 29, 180, 20, "Generate"));
        this.selector = new MenuButton(5, this.width / 2 - 90, this.height / 2 + 29 + 22, 180, 20, "Switch Service");
        this.buttonList.add(this.selector);
        this.buttonList.add(new MenuButton(7, -28, this.height - 22, 180, 20, "Change Api Token"));
        this.buttonList.add(new MenuButton(6, this.width / 2 - 90, this.height - 24, 180, 20, "Back"));
        super.initGui();
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        switch (button.id) {
            case 1: {
                this.loginAccount();
                break;
            }
            case 4: {
                this.generateAccount();
                break;
            }
            case 5: {
                if (this.selector.getButtonText().equalsIgnoreCase("Switch Service")) {
                    this.selector = new MenuButton(5, this.width / 2 - 90, this.height / 2 + 29 + 22, 180, 20, "TheAltening");
                    break;
                }
                if (this.selector.getButtonText().equalsIgnoreCase("TheAltening")) {
                    this.selector = new MenuButton(5, this.width / 2 - 90, this.height / 2 + 29 + 22, 180, 20, "Email:Pass");
                    break;
                }
                if (!this.selector.getButtonText().equalsIgnoreCase("Email:Pass")) break;
                this.selector = new MenuButton(5, this.width / 2 - 90, this.height / 2 + 29 + 22, 180, 20, "Switch Service");
                break;
            }
            case 6: {
                Minecraft.getMinecraft().displayGuiScreen(this.parentScreen);
                break;
            }
            case 7: {
                this.mc.displayGuiScreen(new ChangeTokenGui(this));
            }
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.basicDataRetriever = TheAltening.newBasicRetriever(Client.instance.getAlteningToken());
        ScaledResolution scaledResolution = new ScaledResolution(this.mc);
        GlStateManager.pushMatrix();
        GlStateManager.color(1.0f, 1.0f, 1.0f);
        Render2DUtil.drawMenuBackground(scaledResolution);
        FontLoaders.Comfortaa16.drawCenteredStringWithShadow(Status.STATUS, this.width / 2, this.height - 44, -1);
        this.usernameField.drawTextField();
        this.passwordField.drawTextField();
        this.userpassField.drawTextField();
        this.tokenField.drawTextField();
        GlStateManager.popMatrix();
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        if (keyCode == 28) {
            this.loginAccount();
        }
        if (this.selector.getButtonText().equalsIgnoreCase("Switch Service")) {
            if (keyCode == 15) {
                if (this.usernameField.isFocused()) {
                    this.usernameField.setFocused(false);
                    this.passwordField.setFocused(true);
                } else if (this.passwordField.isFocused()) {
                    this.passwordField.setFocused(false);
                    this.usernameField.setFocused(true);
                }
            }
            this.usernameField.keyTyped(typedChar, keyCode);
            this.passwordField.keyTyped(typedChar, keyCode);
        } else if (this.selector.getButtonText().equalsIgnoreCase("Email:Pass")) {
            this.userpassField.keyTyped(typedChar, keyCode);
        } else if (this.selector.getButtonText().equalsIgnoreCase("TheAltening")) {
            this.tokenField.keyTyped(typedChar, keyCode);
        }
        if (keyCode == 1) {
            return;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (this.selector.getButtonText().equalsIgnoreCase("Switch Service")) {
            this.usernameField.mouseClicked(mouseX, mouseY, mouseButton);
            this.passwordField.mouseClicked(mouseX, mouseY, mouseButton);
        } else if (this.selector.getButtonText().equalsIgnoreCase("Email:Pass")) {
            this.userpassField.mouseClicked(mouseX, mouseY, mouseButton);
        } else if (this.selector.getButtonText().equalsIgnoreCase("TheAltening")) {
            this.tokenField.mouseClicked(mouseX, mouseY, mouseButton);
        }
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    private void loginAccount() {
        if (this.selector.getButtonText().equalsIgnoreCase("Switch Service")) {
            Client.instance.theAlteningAuth.updateService(AlteningServiceType.MOJANG);
            Account account = new Account(this.usernameField.getTypedContent(), this.passwordField.getTypedContent());
            LoginUtil.login(account);
        } else if (this.selector.getButtonText().equalsIgnoreCase("Email:Pass")) {
            Client.instance.theAlteningAuth.updateService(AlteningServiceType.MOJANG);
            String[] userpass = this.userpassField.getTypedContent().split(":");
            Account account = new Account(userpass[0], userpass[1]);
            LoginUtil.login(account);
        } else if (this.selector.getButtonText().equalsIgnoreCase("TheAltening")) {
            Client.instance.theAlteningAuth.updateService(AlteningServiceType.THEALTENING);
            Account account = new Account(this.tokenField.getTypedContent(), "1");
            LoginUtil.login(account);
        }
    }

    private void generateAccount() {
        try {
            Client.instance.theAlteningAuth.updateService(AlteningServiceType.THEALTENING);
            LoginUtil.login(new Account(this.basicDataRetriever.getAccount().getToken(), "1"));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}

