/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.particles;

import cn.M1N3S3NS3.UI.particles.particle.Particle;
import cn.M1N3S3NS3.UI.particles.particle.ParticleSnow;
import java.util.ArrayList;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

public class ParticleManager {
    private Particle particle;
    private int amount;
    public ArrayList particles = new ArrayList();
    private Random random = new Random();

    public ParticleManager(Particle particle, int amount) {
        this.particle = particle;
        this.amount = amount;
        this.init();
    }

    private void init() {
        this.particles.clear();
        ScaledResolution res = new ScaledResolution(Minecraft.getMinecraft());
        int i = 0;
        while (i < this.amount) {
            ParticleSnow particle = new ParticleSnow();
            if (particle instanceof ParticleSnow) {
                particle = new ParticleSnow();
            }
            particle.vector.x = this.random.nextInt(ScaledResolution.getScaledWidth() + 1);
            particle.vector.y = this.random.nextInt(ScaledResolution.getScaledHeight() + 1);
            this.particles.add(particle);
            ++i;
        }
    }

    public void draw(int xAdd) {
        for (Particle particle : this.particles) {
            particle.draw(xAdd);
        }
    }
}

