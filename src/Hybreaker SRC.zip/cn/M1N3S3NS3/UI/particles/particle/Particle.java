/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.util.vector.Vector2f
 */
package cn.M1N3S3NS3.UI.particles.particle;

import org.lwjgl.util.vector.Vector2f;

public class Particle {
    public Vector2f vector = new Vector2f();

    public void draw(int xAdd) {
    }
}

