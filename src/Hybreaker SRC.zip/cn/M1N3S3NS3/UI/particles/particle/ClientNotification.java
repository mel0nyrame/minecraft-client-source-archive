/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.particles.particle;

import java.awt.Color;

public class ClientNotification {
    public static int reAlpha(int n, float n2) {
        Color color = new Color(n);
        return new Color(0.003921569f * (float)color.getRed(), 0.003921569f * (float)color.getGreen(), 0.003921569f * (float)color.getBlue(), n2).getRGB();
    }
}

