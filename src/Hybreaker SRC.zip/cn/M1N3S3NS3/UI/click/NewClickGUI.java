/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.click;

import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.UI.click.NewPanel;
import cn.M1N3S3NS3.UI.click.elements.NewElement;
import cn.M1N3S3NS3.UI.click.elements.NewModuleButton;
import cn.M1N3S3NS3.Util.RenderUtil;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;

public class NewClickGUI
extends GuiScreen {
    public static final int WIDTH = 330;
    public static final int HEIGHT = 290;
    public static int x = RenderUtil.width() / 1 - 165;
    public static int y = RenderUtil.height() / 1 - 145;
    public static final int MOD_WIDTH = 100;
    public static int fontColor = -1;
    public static int selectedFontColor = new Color(((Double)HUD.color.getValue()).intValue()).getRGB();
    public static int bgColor = new Color(25, 25, 25).getRGB();
    private boolean td = false;
    private int lastMouseX = 0;
    private int lastMouseY = 0;
    public List<NewPanel> panels = new ArrayList<NewPanel>();

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        super.drawScreen(mouseX, mouseY, partialTicks);
        ScaledResolution sr = new ScaledResolution(this.mc);
        if (this.td) {
            // empty if block
        }
        Gui.drawRect(0, 0, 0, 0, 0);
        RenderUtil.drawYBrect2(x += mouseX - this.lastMouseX, (y += mouseY - this.lastMouseY) - 10, 330.0f, 290 + 14, 0.0f, bgColor);
        RenderUtil.drawYBrect2(x, y - 10, 330.0f, 40.0f, 0.0f, new Color(25, 25, 25).getRGB());
        RenderUtil.drawRect(x, y + 31, (float)(x + 100) - 1.0f, y + 290 + 4, new Color(25, 25, 25).getRGB());
        Gui.drawRect(0, 0, 0, 0, 0);
        int x = NewClickGUI.x + 7;
        int i = 0;
        while (i < this.panels.size()) {
            NewPanel panel = this.panels.get(i);
            panel.x = x + 7;
            panel.y = y + 10;
            panel.drawScreen(mouseX, mouseY, partialTicks);
            x += FontLoaders.Comfortaa18.getStringWidth(panel.title) + 40;
            ++i;
        }
        Gui.drawRect(0, 0, 0, 0, 0);
        FontLoaders.Comfortaa18.drawString("ClickGui.exe", NewClickGUI.x + 330 / 2 - FontLoaders.Comfortaa18.getStringWidth("CLICKGUI.EXE") / 2, y - 6, new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue()).getRGB());
        Calendar cal = Calendar.getInstance();
        int h = cal.get(11);
        int m = cal.get(12);
        int s = cal.get(13);
        Gui.drawRect(0, 0, 0, 0, 0);
        this.lastMouseX = mouseX;
        this.lastMouseY = mouseY;
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (mouseButton == 0 && mouseX >= x && mouseX <= x + 330 && mouseY >= y - 10 && mouseY <= y) {
            this.td = true;
            return;
        }
        int i = 0;
        while (i < this.panels.size()) {
            NewPanel panel = this.panels.get(i);
            if (panel.mouseClicked(mouseX, mouseY, mouseButton)) {
                return;
            }
            ++i;
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        this.td = false;
        for (NewPanel panel : this.panels) {
            if (!panel.extended || panel.Elements.isEmpty()) continue;
            for (NewModuleButton mb : panel.Elements) {
                if (!mb.extended || mb.Elements.isEmpty()) continue;
                for (NewElement e : mb.Elements) {
                    e.mouseReleased(mouseX, mouseY, state);
                }
            }
        }
        super.mouseReleased(mouseX, mouseY, state);
    }

    public NewClickGUI() {
        int x = NewClickGUI.x + 2;
        this.panels.add(new NewPanel(x, y + 10, ModuleType.Combat, this){

            @Override
            public void setUp() {
                Client.instance.getModuleManager();
                for (Module mod : ModuleManager.getModules()) {
                    if (!mod.getType().equals((Object)this.moduleType)) continue;
                    this.Elements.add(new NewModuleButton(mod, this));
                }
            }
        });
        this.panels.add(new NewPanel(x += FontLoaders.Comfortaa18.getStringWidth(ModuleType.Combat.name()) + 25, y + 10, ModuleType.Render, this){

            @Override
            public void setUp() {
                Client.instance.getModuleManager();
                for (Module mod : ModuleManager.getModules()) {
                    if (!mod.getType().equals((Object)this.moduleType)) continue;
                    this.Elements.add(new NewModuleButton(mod, this));
                }
            }
        });
        this.panels.add(new NewPanel(x += FontLoaders.Comfortaa18.getStringWidth(ModuleType.Render.name()) + 25, y + 10, ModuleType.Move, this){

            @Override
            public void setUp() {
                Client.instance.getModuleManager();
                for (Module mod : ModuleManager.getModules()) {
                    if (!mod.getType().equals((Object)this.moduleType)) continue;
                    this.Elements.add(new NewModuleButton(mod, this));
                }
            }
        });
        this.panels.add(new NewPanel(x += FontLoaders.Comfortaa18.getStringWidth(ModuleType.Move.name()) + 25, y + 10, ModuleType.Player, this){

            @Override
            public void setUp() {
                Client.instance.getModuleManager();
                for (Module mod : ModuleManager.getModules()) {
                    if (!mod.getType().equals((Object)this.moduleType)) continue;
                    this.Elements.add(new NewModuleButton(mod, this));
                }
            }
        });
        this.panels.add(new NewPanel(x += FontLoaders.Comfortaa18.getStringWidth(ModuleType.Player.name()) + 15, y + 10, ModuleType.Ghost, this){

            @Override
            public void setUp() {
                Client.instance.getModuleManager();
                for (Module mod : ModuleManager.getModules()) {
                    if (!mod.getType().equals((Object)this.moduleType)) continue;
                    this.Elements.add(new NewModuleButton(mod, this));
                }
            }
        });
    }

    @Override
    public void updateScreen() {
        int i = 0;
        while (i < this.panels.size()) {
            this.panels.get(i).update();
            ++i;
        }
    }
}

