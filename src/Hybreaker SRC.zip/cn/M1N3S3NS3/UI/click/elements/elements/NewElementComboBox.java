/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.click.elements.elements;

import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.UI.click.elements.NewElement;
import cn.M1N3S3NS3.UI.click.elements.NewModuleButton;
import cn.M1N3S3NS3.Util.RenderUtil;
import java.awt.Color;
import net.minecraft.client.gui.Gui;

public class NewElementComboBox
extends NewElement {
    private Mode set;
    private boolean me;

    public NewElementComboBox(NewModuleButton parent, Mode set) {
        this.visible = true;
        this.level = 1;
        this.parent = parent;
        this.set = set;
        ((NewElement)this).set = set;
        this.setstrg = String.valueOf(set.getDisplayName().substring(0, 1).toUpperCase()) + set.getDisplayName().substring(1, set.getDisplayName().length());
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (!this.visible) {
            return;
        }
        int color = -12490271;
        Gui.drawRect(0, 0, 0, 0, 0);
        FontLoaders.Comfortaa18.drawString(this.setstrg, this.x + this.width / 2.0f - (float)(FontLoaders.Comfortaa18.getStringWidth(this.setstrg) / 2), this.y + 3.0f, -1);
        int clr1 = color;
        int clr2 = color;
        RenderUtil.drawRectWH(this.x, this.y + 15.0f, this.width, FontLoaders.Comfortaa18.getHeight() + 2, new Color(25, 25, 25).getRGB());
        Gui.drawRect(0, 0, 0, 0, 0);
        String str = "<" + String.valueOf(((Enum)this.set.getValue()).ordinal() + 1) + "/" + this.set.getModes().length + ">";
        FontLoaders.Comfortaa18.drawString(str, this.x + (this.width - (float)FontLoaders.Comfortaa18.getStringWidth(str)) / 2.0f, this.y + 25.0f + 7.0f - (float)(FontLoaders.Comfortaa18.getHeight() / 2) - 1.0f, -1);
        FontLoaders.Comfortaa18.drawString(((Enum)this.set.getValue()).name(), this.x + this.width / 2.0f - (float)(FontLoaders.Comfortaa18.getStringWidth(((Enum)this.set.getValue()).name()) / 2), this.y + 13.0f + 7.0f - (float)(FontLoaders.Comfortaa18.getHeight() / 2) - 1.0f, -1);
    }

    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (!this.visible) {
            return false;
        }
        if (mouseButton == 0 && this.isButtonHovered(mouseX, mouseY)) {
            Mode m = this.set;
            Enum current = (Enum)m.getValue();
            int next = current.ordinal() + 1 >= m.getModes().length ? 0 : current.ordinal() + 1;
            this.set.setValue(m.getModes()[next]);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    public boolean isButtonHovered(int mouseX, int mouseY) {
        return (float)mouseX >= this.x && (float)mouseX <= this.x + this.width && (float)mouseY >= this.y + 15.0f && (float)mouseY <= this.y + 15.0f + (float)FontLoaders.Comfortaa18.getHeight() + 2.0f;
    }
}

