/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.click.elements.elements;

import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.UI.click.elements.NewElement;
import cn.M1N3S3NS3.UI.click.elements.NewModuleButton;
import java.awt.Color;
import net.minecraft.client.gui.Gui;

public class NewElementCheckBox
extends NewElement {
    private Option set;
    public int moveX;
    public static final int MAX_X = 15;

    public NewElementCheckBox(NewModuleButton parent, Option set) {
        this.level = 3;
        this.visible = true;
        this.parent = parent;
        this.set = set;
        ((NewElement)this).set = set;
        this.moveX = 0;
        this.setstrg = String.valueOf(set.getDisplayName().substring(0, 1).toUpperCase()) + set.getDisplayName().substring(1, set.getDisplayName().length());
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (!this.visible) {
            return;
        }
        int color = -12490271;
        if (((Boolean)this.set.getValue()).booleanValue() && this.moveX < 9) {
            ++this.moveX;
        } else if (!((Boolean)this.set.getValue()).booleanValue() && this.moveX > 0) {
            --this.moveX;
        }
        Gui.drawRect(this.x - 1.0f, this.y, this.x + this.width, this.y + 16.0f, new Color(25, 25, 25, 255).getRGB());
        Gui.drawRect(this.x + this.width - 21.0f, this.y + 4.0f, this.x + this.width - 5.0f, this.y + 11.0f, new Color(25, 25, 25, 255).getRGB());
        Gui.drawRect(this.x + this.width - 21.0f + (float)this.moveX, this.y + 4.0f, this.x + this.width - 14.0f + (float)this.moveX, this.y + 11.0f, (Boolean)this.set.getValue() != false ? new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue()).getRGB() : new Color(35, 35, 35).getRGB());
        Gui.drawRect(0, 0, 0, 0, 0);
        FontLoaders.Comfortaa18.drawString(this.setstrg, this.x + 2.0f, this.y + 5.0f, -1);
    }

    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (!this.visible) {
            return false;
        }
        if (mouseButton == 0 && this.isCheckHovered(mouseX, mouseY)) {
            this.set.setValue((Boolean)this.set.getValue() == false);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    public boolean isCheckHovered(int mouseX, int mouseY) {
        return (float)mouseX >= this.x + this.width - 22.0f && (float)mouseX <= this.x + this.width - 4.0f && (float)mouseY >= this.y + 3.0f && (float)mouseY <= this.y + 12.0f;
    }
}

