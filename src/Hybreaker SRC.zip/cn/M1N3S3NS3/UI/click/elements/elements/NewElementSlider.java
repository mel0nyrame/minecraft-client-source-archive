/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.click.elements.elements;

import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.UI.click.elements.NewElement;
import cn.M1N3S3NS3.UI.click.elements.NewModuleButton;
import cn.M1N3S3NS3.Util.RenderUtil;
import java.awt.Color;
import net.minecraft.client.gui.Gui;

public class NewElementSlider
extends NewElement {
    private Numbers set;
    public boolean dragging;

    public NewElementSlider(NewModuleButton parent, Numbers set) {
        this.level = 2;
        this.visible = true;
        this.parent = parent;
        this.set = set;
        ((NewElement)this).set = set;
        this.setstrg = String.valueOf(set.getDisplayName().substring(0, 1).toUpperCase()) + set.getDisplayName().substring(1, set.getDisplayName().length());
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (!this.visible) {
            return;
        }
        String displayval = "" + (double)Math.round((Double)this.set.getValue() * 100.0) / 100.0;
        boolean hoveredORdragged = this.isSliderHovered(mouseX, mouseY) || this.dragging;
        double percentBar = ((Double)this.set.getValue() - ((Number)this.set.getMinimum()).doubleValue()) / (((Number)this.set.getMaximum()).doubleValue() - ((Number)this.set.getMinimum()).doubleValue());
        Gui.drawRect(0, 0, 0, 0, 0);
        FontLoaders.Comfortaa18.drawString(this.setstrg, this.x + 1.0f, this.y - 1.0f + 3.0f, -1);
        Gui.drawRect(0, 0, 0, 0, 0);
        FontLoaders.Comfortaa18.drawString(displayval, this.x + this.width - (float)FontLoaders.Comfortaa18.getStringWidth(displayval) - 2.0f, this.y - 1.0f + 3.0f, -1);
        RenderUtil.drawRect(this.x, this.y + 12.0f, this.x + this.width, this.y + 13.5f, new Color(20, 20, 20).getRGB());
        RenderUtil.drawRect(this.x, this.y + 12.0f, (float)((double)this.x + percentBar * (double)this.width), this.y + 13.5f, new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue()).getRGB());
        Gui.drawRect(0, 0, 0, 0, 0);
        if (this.dragging) {
            double min = ((Number)this.set.getMinimum()).doubleValue();
            double max = ((Number)this.set.getMaximum()).doubleValue();
            double inc = ((Number)this.set.getIncrement()).doubleValue();
            double valAbs = (double)mouseX - ((double)this.x + 1.0);
            double perc = valAbs / (double)this.width;
            perc = Math.min(Math.max(0.0, perc), 1.0);
            double valRel = (max - min) * perc;
            double val = min + valRel;
            val = (double)Math.round(val * (1.0 / inc)) / (1.0 / inc);
            this.set.setValue(val);
        }
    }

    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (!this.visible) {
            return false;
        }
        if (mouseButton == 0 && this.isSliderHovered(mouseX, mouseY)) {
            this.dragging = true;
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        this.dragging = false;
    }

    public boolean isSliderHovered(int mouseX, int mouseY) {
        return (float)mouseX >= this.x && (float)mouseX <= this.x + this.width && (float)mouseY >= this.y + 11.0f && (float)mouseY <= this.y + 14.0f;
    }
}

