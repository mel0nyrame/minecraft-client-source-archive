/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.click.elements;

import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.UI.click.elements.NewModuleButton;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

public class NewElement {
    public Value set;
    public NewModuleButton parent;
    public float x;
    public float y;
    public float width;
    public float height;
    public float offset;
    public String setstrg;
    public boolean comboextended;
    public boolean visible;
    public int level;

    public void update() {
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        if (this.set != null) {
            String sname = this.set.getDisplayName();
            this.setstrg = String.valueOf(sname.substring(0, 1).toUpperCase()) + sname.substring(1, sname.length());
            if (this.set instanceof Mode) {
                Mode mode2 = (Mode)this.set;
                this.height = this.comboextended ? mode2.getModes().length * (FontLoaders.Comfortaa18.getHeight() + 2) + 30 + 3 : 30;
            } else {
                this.height = 15.0f;
            }
        }
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
    }

    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        return this.isHovered(mouseX, mouseY);
    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
    }

    public boolean isHovered(int mouseX, int mouseY) {
        return (float)mouseX >= this.x && (float)mouseX <= this.x + this.width && (float)mouseY >= this.y && (float)mouseY <= this.y + this.height;
    }
}

