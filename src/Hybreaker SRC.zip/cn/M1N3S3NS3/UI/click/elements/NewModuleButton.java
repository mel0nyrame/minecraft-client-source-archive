/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.UI.click.elements;

import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.UI.click.NewClickGUI;
import cn.M1N3S3NS3.UI.click.NewPanel;
import cn.M1N3S3NS3.UI.click.elements.NewElement;
import cn.M1N3S3NS3.UI.click.elements.elements.NewElementCheckBox;
import cn.M1N3S3NS3.UI.click.elements.elements.NewElementComboBox;
import cn.M1N3S3NS3.UI.click.elements.elements.NewElementSlider;
import cn.M1N3S3NS3.Util.RenderUtil;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class NewModuleButton {
    public Module mod;
    public NewPanel parent;
    public float x;
    public float y;
    public float GDy;
    public boolean extended;
    public boolean visible;
    public List<NewElement> Elements;
    public boolean hasElements;
    public int moveX;
    public static final int MAX_X = 15;
    private int angle = 1;

    public NewModuleButton(Module mod, NewPanel parent) {
        this.mod = mod;
        this.parent = parent;
        this.Elements = new ArrayList<NewElement>();
        this.GDy = 0.0f;
        this.moveX = 0;
        this.visible = true;
        if (!mod.getValues().isEmpty()) {
            for (Value<?> v : mod.getValues()) {
                if (v instanceof Option) {
                    Option option = (Option)v;
                    this.Elements.add(new NewElementCheckBox(this, option));
                    continue;
                }
                if (v instanceof Numbers) {
                    Numbers numbers = (Numbers)v;
                    this.Elements.add(new NewElementSlider(this, numbers));
                    continue;
                }
                if (!(v instanceof Mode)) continue;
                Mode mode2 = (Mode)v;
                this.Elements.add(new NewElementComboBox(this, mode2));
            }
            Collections.sort(this.Elements, new Comparator<NewElement>(){

                @Override
                public int compare(NewElement m, NewElement m2) {
                    if (m.level > m2.level) {
                        return -1;
                    }
                    if (m.level == m2.level) {
                        return 0;
                    }
                    if (m.level < m2.level) {
                        return 1;
                    }
                    return 0;
                }
            });
            this.hasElements = true;
        } else {
            this.hasElements = false;
        }
    }

    public void update() {
    }

    /*
     * Unable to fully structure code
     */
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        block39: {
            sr = new ScaledResolution(Minecraft.getMinecraft());
            scaleFactor = 1;
            flag = Minecraft.getMinecraft().isUnicode();
            i2 = Minecraft.getMinecraft().gameSettings.guiScale;
            if (i2 == 0) {
                i2 = 1000;
            }
            while (scaleFactor < i2 && Minecraft.getMinecraft().displayWidth / (scaleFactor + 1) >= 320 && Minecraft.getMinecraft().displayHeight / (scaleFactor + 1) >= 240) {
                ++scaleFactor;
            }
            if (flag && scaleFactor % 2 != 0 && scaleFactor != 1) {
                --scaleFactor;
            }
            lastElement = null;
            GL11.glEnable((int)3089);
            GL11.glScissor((int)((NewClickGUI.x + 100) * scaleFactor), (int)((ScaledResolution.getScaledHeight() - NewClickGUI.y - 290) * scaleFactor), (int)((330 - 100) * scaleFactor), (int)((290 - 31) * scaleFactor));
            if (this.mod.isEnabled() && this.moveX < 15) {
                ++this.moveX;
            } else if (!this.mod.isEnabled() && this.moveX > 0) {
                --this.moveX;
            }
            if (this.extended) {
            }
            if (!this.hasElements || !this.extended) break block39;
            kY = 2;
            y = NewClickGUI.y + 35 + kY;
            comboX = NewClickGUI.x + 100 + 5;
            checkX = NewClickGUI.x + 100 + 5;
            sliderX = NewClickGUI.x + 100 + 5;
            y2 = -(290 - 31) - y + kY;
            maxComboHeight = 0;
            lastX = 0;
            Gui.drawRect(0, 0, 0, 0, 0);
            i = 0;
            while (i < this.Elements.size()) {
                element = this.Elements.get(i);
                element.drawScreen(mouseX, mouseY, partialTicks);
                element.update();
                if (lastElement != null && element != null && lastElement.getClass() != element.getClass()) {
                    if (!(lastElement.width * 2.0f + (float)lastX + 10.0f > (float)(NewClickGUI.x + 330))) {
                        y = (int)((float)y + (lastElement.height + 3.0f));
                    }
                }
                element.y = (float)y + this.GDy;
                if (element.y > (float)(NewClickGUI.y + 290)) ** GOTO lbl-1000
                if (element.y < (float)(NewClickGUI.y + 31) - element.height) lbl-1000:
                // 2 sources

                {
                    element.visible = false;
                } else {
                    element.visible = true;
                }
                if (element instanceof NewElementSlider) {
                    element.x = sliderX;
                    element.width = 220.0f;
                    lastX = (int)element.x;
                    sliderX = (int)((float)sliderX + (element.width + 10.0f));
                    if ((float)sliderX + element.width > (float)NewClickGUI.x) {
                        sliderX = NewClickGUI.x + 100 + 5;
                        y = (int)((float)y + (element.height + 4.0f));
                    }
                } else if (element instanceof NewElementComboBox) {
                    element.x = comboX;
                    element.width = 60.0f;
                    lastX = (int)element.x;
                    comboX = (int)((float)comboX + (element.width + 10.0f));
                    if ((float)comboX + element.width > (float)(NewClickGUI.x + 330)) {
                        comboX = NewClickGUI.x + 100 + 5;
                        y = (int)((float)y + (element.height + 9.0f));
                    }
                    if (element.height > (float)maxComboHeight) {
                        maxComboHeight = (int)element.height;
                    }
                } else if (element instanceof NewElementCheckBox) {
                    element.x = checkX;
                    element.width = 220.0f;
                    lastX = (int)element.x;
                    checkX = (int)((float)checkX + (element.width + 10.0f));
                    if ((float)checkX + element.width > (float)NewClickGUI.x) {
                        checkX = NewClickGUI.x + 100 + 5;
                        y = (int)((float)y + (element.height + 4.0f));
                    }
                }
                lastElement = element;
                ++i;
            }
            y2 += y + maxComboHeight;
            if (this.extended) {
                if (mouseX > NewClickGUI.x + 74) {
                    if (mouseX <= NewClickGUI.x + 330) {
                        if (mouseY >= NewClickGUI.y + 30) {
                            if (mouseY <= NewClickGUI.y + 290) {
                                this.GDy += (float)(Mouse.getDWheel() / 20);
                                if (this.Elements != null && y2 > 0) {
                                    if (this.GDy > 0.0f) {
                                        this.GDy = 0.0f;
                                    }
                                    if (this.GDy < (float)(-y2 - 3)) {
                                        this.GDy = -y2 - 3;
                                    }
                                } else if (y2 <= 0 && this.GDy != 0.0f) {
                                    this.GDy = 0.0f;
                                }
                            }
                        }
                    }
                }
            }
            if (y2 > 0) {
                max = y2 + 2;
                gdHeight = (int)((float)(290 - 31) / (float)max * 10.0f);
                if (gdHeight < 7) {
                    gdHeight = 7;
                }
            }
        }
        GL11.glDisable((int)3089);
        if (!this.visible) {
            return;
        }
        Gui.drawRect(0, 0, 0, 0, 0);
        GL11.glEnable((int)3089);
        GL11.glScissor((int)(NewClickGUI.x * scaleFactor), (int)((ScaledResolution.getScaledHeight() - NewClickGUI.y - 290) * scaleFactor), (int)(100 * scaleFactor), (int)((290 - 31) * scaleFactor));
        Gui.drawRect(this.x, (double)this.y - 4.5, this.x + 95.0f, (double)(this.y + (float)FontLoaders.Comfortaa18.getHeight()) + 4.5, this.extended != false ? new Color(26, 26, 26).getRGB() : new Color(26, 26, 26).getRGB());
        if (this.extended || this.isHovered(mouseX, mouseY)) {
            this.angle += 2;
        } else if (this.angle > 0) {
            this.angle -= 2;
        }
        if (this.hasElements) {
            if (this.angle >= 360) {
                this.angle = 1;
            }
            RenderUtil.drawTexture((int)this.x + 80, (int)this.y - 1, 10, 10, this.angle, new ResourceLocation("ZenithAssets/settings.png"));
        }
        Gui.drawRect(this.x + 3.0f, this.y, this.x + 9.0f, this.y + 6.0f, new Color(25, 25, 25).getRGB());
        Gui.drawRect(this.x + 4.0f, this.y + 1.0f, this.x + 8.0f, this.y + 5.0f, this.mod.isEnabled() != false ? new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue()).getRGB() : new Color(25, 25, 25).getRGB());
        FontLoaders.Comfortaa18.drawString(this.mod.getName(), this.x + 16.0f, this.y, this.isHovered(mouseX, mouseY) != false ? new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue()).getRGB() : (this.mod.isEnabled() != false ? new Color(255, 255, 255).getRGB() : new Color(120, 120, 120).getRGB()));
        GL11.glDisable((int)3089);
    }

    public boolean keyTyped(char typedChar, int keyCode) throws IOException {
        if (this.extended) {
            return false;
        }
        return false;
    }

    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        if (this.extended) {
            for (NewElement element : this.Elements) {
                if (!element.mouseClicked(mouseX, mouseY, mouseButton)) continue;
                return true;
            }
        }
        if (!this.visible) {
            return false;
        }
        if (mouseButton == 1 && !this.extended && this.isHovered(mouseX, mouseY)) {
            int i = 0;
            while (i < this.parent.Elements.size()) {
                this.parent.Elements.get((int)i).extended = false;
                ++i;
            }
            this.extended = true;
        }
        if (mouseButton == 0 && this.isHovered(mouseX, mouseY)) {
            this.mod.setEnabled(!this.mod.isEnabled());
        }
        return false;
    }

    public boolean isHovered(int mouseX, int mouseY) {
        return (float)mouseX >= this.x && (float)mouseX <= this.x + 95.0f && (double)mouseY >= (double)this.y - 4.5 && (double)mouseY <= (double)(this.y + (float)FontLoaders.Comfortaa18.getHeight()) + 4.5;
    }
}

