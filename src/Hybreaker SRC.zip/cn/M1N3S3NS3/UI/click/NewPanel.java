/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 */
package cn.M1N3S3NS3.UI.click;

import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.UI.click.NewClickGUI;
import cn.M1N3S3NS3.UI.click.elements.NewModuleButton;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;

public class NewPanel {
    public float x;
    public float y;
    private float GDy;
    public String title;
    public boolean visible;
    public boolean extended;
    private NewClickGUI parent;
    public ModuleType moduleType;
    public List<NewModuleButton> Elements = new ArrayList<NewModuleButton>();
    private static final Minecraft mc = Minecraft.getMinecraft();

    public NewPanel(float x, float y, ModuleType moduleType, NewClickGUI parent) {
        this.x = x;
        this.y = y;
        this.GDy = 0.0f;
        this.visible = true;
        this.parent = parent;
        this.moduleType = moduleType;
        this.setUp();
        Collections.sort(this.Elements, new Comparator<NewModuleButton>(){

            @Override
            public int compare(NewModuleButton m, NewModuleButton m2) {
                if (m.hasElements && !m2.hasElements) {
                    return -1;
                }
                if (m2.hasElements && !m.hasElements) {
                    return 1;
                }
                return 0;
            }
        });
        this.title = this.moduleType.name();
    }

    public void update() {
    }

    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (!this.visible) {
            return false;
        }
        if (this.extended) {
            int i = 0;
            while (i < this.Elements.size()) {
                if (this.Elements.get(i).mouseClicked(mouseX, mouseY, mouseButton)) {
                    return true;
                }
                ++i;
            }
        } else if (this.isHovered(mouseX, mouseY) && mouseButton == 0) {
            int i = 0;
            while (i < Client.instance.newClickgui.panels.size()) {
                Client.instance.newClickgui.panels.get((int)i).extended = false;
                ++i;
            }
            this.extended = true;
            return true;
        }
        return false;
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        Gui.drawRect(0, 0, 0, 0, 0);
        FontLoaders.Comfortaa18.drawString(this.title, this.x, this.y, this.isHovered(mouseX, mouseY) || this.extended ? new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue()).getRGB() : NewClickGUI.fontColor);
        if (this.extended) {
            int max;
            int gdHeight;
            int y = NewClickGUI.y + 35;
            int y2 = -(290 - 31);
            int i = 0;
            while (i < this.Elements.size()) {
                NewModuleButton mb = this.Elements.get(i);
                mb.x = NewClickGUI.x + 3;
                mb.y = (float)y + this.GDy;
                mb.visible = !(mb.y > (float)(NewClickGUI.y + 290)) && !(mb.y < (float)(NewClickGUI.y + 31 - FontLoaders.Comfortaa18.getHeight()));
                mb.drawScreen(mouseX, mouseY, partialTicks);
                y += FontLoaders.Comfortaa18.getHeight() + 10;
                y2 += FontLoaders.Comfortaa18.getHeight() + 10;
                ++i;
            }
            if (this.extended) {
                if (mouseX >= NewClickGUI.x) {
                    if (mouseX <= NewClickGUI.x + 74) {
                        if (mouseY >= NewClickGUI.y + 30) {
                            if (mouseY <= NewClickGUI.y + 290) {
                                this.GDy += (float)(Mouse.getDWheel() / 20);
                                if (this.Elements != null && y2 > 0) {
                                    if (this.GDy > 0.0f) {
                                        this.GDy = 0.0f;
                                    }
                                    if (this.GDy < (float)(-y2 - 3)) {
                                        this.GDy = -y2 - 3;
                                    }
                                } else if (y2 <= 0 && this.GDy != 0.0f) {
                                    this.GDy = 0.0f;
                                }
                            }
                        }
                    }
                }
            }
            if (y2 > 0 && (gdHeight = (int)((float)(290 - 31) / (float)(max = y2 + 2) * 10.0f)) < 7) {
                gdHeight = 7;
            }
        }
    }

    public void setUp() {
    }

    public boolean isHovered(int mouseX, int mouseY) {
        return (float)mouseX >= this.x && (float)mouseX <= this.x + (float)FontLoaders.Comfortaa18.getStringWidth(this.title) && (float)mouseY >= this.y && (float)mouseY <= this.y + (float)FontLoaders.Comfortaa18.getHeight();
    }
}

