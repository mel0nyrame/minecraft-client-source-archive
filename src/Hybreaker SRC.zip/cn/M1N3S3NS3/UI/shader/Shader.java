/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.ARBShaderObjects
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.opengl.GL20
 */
package cn.M1N3S3NS3.UI.shader;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public abstract class Shader {
    private int program;
    private final Minecraft mc = Minecraft.getMinecraft();
    private Map<String, Integer> uniformsMap;

    public Shader(String fragmentShader) {
        int fragmentShaderID;
        int vertexShaderID;
        String vertexString = "#version 120 \n\nvoid main(void) {\n    //Map gl_MultiTexCoord0 to index zero of gl_TexCoord\n    gl_TexCoord[0] = gl_MultiTexCoord0;\n\n    //Calculate position by multiplying model, view and projection matrix by the vertex vector\n    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n}\n";
        String fragmentString = "#version 120\n\nuniform float iTime;\nuniform vec2 iResolution;\n\n// Mellow purple flow background - Del 16/06/2018\n\nconst float pi = 3.14159;\n\nvec4 MellowPurple(vec2 pos)\n{\n    pos *= 0.5;\n    vec4 col = vec4(0.32,0.19,0.35,1.0);\n    float d = length(pos);\n    float tt = iTime*0.08;\n    float iter = (pos.x*pos.y);\n    iter *= 0.5+sin(pos.x*0.5+tt*0.95)+0.5;\n    float r = sin(sin(tt)*pos.y);\n    r += .4;\n    float d1 = sin(tt+pos.x+pos.y);\n    float val = sin(tt+iter*pi );\n    float brightness = 0.25 / abs( d1 * val - r);\n//    brightness +=  0.25 /abs( d1+0.1 * val - r);\n//    brightness += 0.25 / abs( d1-0.1 * val - r);\n    brightness +=  0.25 /abs( d1+0.4 * val - r);\n    brightness += 0.25 / abs( d1-0.4 * val - r);\n    brightness *= 0.05;\n    brightness = brightness/(brightness + 1.);\n    brightness*=0.75-d;\n    col += brightness;\n    return col;\n}\n\n\nvoid mainImage( out vec4 fragColor, in vec2 fragCoord )\n{\n\tvec2 pos = ( fragCoord - .5 * iResolution.xy ) / iResolution.y;     \n    fragColor = MellowPurple(pos);\n}\n\nvoid main() {\n    mainImage(gl_FragColor, gl_FragCoord.xy);\n}";
        try {
            vertexShaderID = this.createShader(vertexString, 35633);
            fragmentShaderID = this.createShader(fragmentString, 35632);
        }
        catch (Exception e) {
            e.printStackTrace();
            return;
        }
        if (vertexShaderID == 0 || fragmentShaderID == 0) {
            return;
        }
        this.program = ARBShaderObjects.glCreateProgramObjectARB();
        if (this.program == 0) {
            return;
        }
        ARBShaderObjects.glAttachObjectARB((int)this.program, (int)vertexShaderID);
        ARBShaderObjects.glAttachObjectARB((int)this.program, (int)vertexShaderID);
        ARBShaderObjects.glAttachObjectARB((int)this.program, (int)fragmentShaderID);
        ARBShaderObjects.glLinkProgramARB((int)this.program);
        ARBShaderObjects.glValidateProgramARB((int)this.program);
    }

    public void startShader() {
        GL11.glPushMatrix();
        GL20.glUseProgram((int)this.program);
        if (this.uniformsMap == null) {
            this.uniformsMap = new HashMap<String, Integer>();
            this.setupUniforms();
        }
        this.updateUniforms();
    }

    public void stopShader() {
        GL20.glUseProgram((int)0);
        GL11.glPopMatrix();
    }

    public abstract void setupUniforms();

    public abstract void updateUniforms();

    private int createShader(String shaderSource, int shaderType) {
        int shader;
        block4: {
            shader = 0;
            try {
                shader = ARBShaderObjects.glCreateShaderObjectARB((int)shaderType);
                if (shader != 0) break block4;
                return 0;
            }
            catch (Exception e) {
                ARBShaderObjects.glDeleteObjectARB((int)shader);
                throw e;
            }
        }
        ARBShaderObjects.glShaderSourceARB((int)shader, (CharSequence)shaderSource);
        ARBShaderObjects.glCompileShaderARB((int)shader);
        if (ARBShaderObjects.glGetObjectParameteriARB((int)shader, (int)35713) == 0) {
            throw new RuntimeException("Error creating shader: " + this.getLogInfo(shader));
        }
        return shader;
    }

    private String getLogInfo(int i) {
        return ARBShaderObjects.glGetInfoLogARB((int)i, (int)ARBShaderObjects.glGetObjectParameteriARB((int)i, (int)35716));
    }

    public void setUniform(String uniformName, int location) {
        this.uniformsMap.put(uniformName, location);
    }

    public void setupUniform(String uniformName) {
        this.setUniform(uniformName, GL20.glGetUniformLocation((int)this.program, (CharSequence)uniformName));
    }

    public int getUniform(String uniformName) {
        return this.uniformsMap.get(uniformName);
    }
}

