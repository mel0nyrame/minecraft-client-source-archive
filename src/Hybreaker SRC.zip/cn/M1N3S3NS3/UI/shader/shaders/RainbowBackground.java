/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL20
 */
package cn.M1N3S3NS3.UI.shader.shaders;

import cn.M1N3S3NS3.UI.shader.Shader;
import cn.M1N3S3NS3.Util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.opengl.GL20;

public class RainbowBackground
extends Shader {
    private float time;
    public static final RainbowBackground RAINBOW_BACKGROUND = new RainbowBackground();

    public RainbowBackground() {
        super("rainbowBackground.frag");
    }

    @Override
    public void setupUniforms() {
        this.setupUniform("iResolution");
        this.setupUniform("iTime");
    }

    @Override
    public void updateUniforms() {
        int timeID;
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
        int resolutionID = this.getUniform("iResolution");
        if (resolutionID > -1) {
            GL20.glUniform2f((int)resolutionID, (float)(1.5f * (float)ScaledResolution.getScaledWidth()), (float)(1.5f * (float)ScaledResolution.getScaledHeight()));
        }
        if ((timeID = this.getUniform("iTime")) > -1) {
            GL20.glUniform1f((int)timeID, (float)this.time);
        }
        this.time = (float)((double)this.time + (double)RenderUtil.deltaTime * 1.5);
        this.time %= 3600.0f;
        this.time += 5.0E-6f * RenderUtil.deltaTime;
    }
}

