/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.BufferUtils
 *  org.lwjgl.LWJGLException
 *  org.lwjgl.input.Cursor
 *  org.lwjgl.input.Mouse
 */
package cn.M1N3S3NS3.UI;

import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Render.ClickGui;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.UI.Render.RenderUtil;
import cn.M1N3S3NS3.Util.Render.TranslateUtil;
import cn.M1N3S3NS3.font.cfont.CFontRenderer;
import java.awt.Color;
import java.io.IOException;
import java.nio.IntBuffer;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Cursor;
import org.lwjgl.input.Mouse;

public class GuiClickUI
extends GuiScreen {
    private static List<Module> inSetting = new CopyOnWriteArrayList<Module>();
    private static ModuleType currentCategory;
    private static int x;
    private static int y;
    private static int wheel;
    private boolean need2move;
    private int dragX;
    private int dragY;
    private TranslateUtil translate = new TranslateUtil(0.0f, 0.0f);
    CFontRenderer font1;
    CFontRenderer font2;
    CFontRenderer font3;
    Cursor emptyCursor;

    public GuiClickUI() {
        this.font1 = Client.instance.getFontManager().arial18;
        this.font2 = Client.instance.getFontManager().arial16;
        this.font3 = Client.instance.getFontManager().arial14;
        this.need2move = false;
        this.dragX = 0;
        this.dragY = 0;
        this.translate.setX(0.0f);
        this.translate.setY(0.0f);
    }

    @Override
    public void initGui() {
        super.initGui();
        if (x > this.width) {
            x = 30;
        }
        if (y > this.height) {
            y = 30;
        }
        this.need2move = false;
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        int staticColor = new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue()).getRGB();
        super.drawScreen(mouseX, mouseY, partialTicks);
        if (this.need2move) {
            x = mouseX - this.dragX;
            y = mouseY - this.dragY;
        }
        if (!Mouse.isButtonDown((int)0) && this.need2move) {
            this.need2move = false;
        }
        RenderUtil.drawBorderedRect(x, y, x + 273, y + 198, 3.0f, new Color(20, 20, 20).getRGB(), staticColor);
        RenderUtil.drawBorderedRect(x + 2, y + 2, x + 273 - 2, y + 198 - 2, 1.0f, staticColor, new Color(20, 20, 20).getRGB());
        Gui.drawRect(x + 70, y + 35, x + 269, y + 195, new Color(0, 0, 0).getRGB());
        FontLoaders.NovICON42.drawString("G", x + 5, y + 8, staticColor);
        Client.instance.getFontManager().arial28.drawStringWithShadow(Client.name, x + 28, y + 8, new Color(180, 180, 180).getRGB());
        this.font2.drawStringWithShadow(Client.version, x + 30, y + 24, new Color(180, 180, 180).getRGB());
        RenderUtil.drawGradientSideways(x + 70, y + 35, x + 80, y + 195, new Color(20, 20, 20).getRGB(), new Color(0, 0, 0, 0).getRGB());
        RenderUtil.drawGradientSidewaysV(x + 3, y + 35, x + 273 - 3, y + 45, new Color(0, 0, 0, 0).getRGB(), new Color(0, 0, 0).getRGB());
        int cateY = 0;
        ModuleType[] moduleTypeArray = ModuleType.values();
        int n = moduleTypeArray.length;
        int n2 = 0;
        while (n2 < n) {
            ModuleType category = moduleTypeArray[n2];
            int strX = x + 40;
            int strY = y + 55 + cateY;
            boolean hover = mouseX > x + 5 && mouseX < x + 65 && mouseY > strY && mouseY < strY + 20;
            Client.instance.getFontManager().arial20.drawCenteredStringWithShadow(category.name(), strX - 1, strY + 6, category == currentCategory ? staticColor : new Color(hover ? 255 : 140, hover ? 255 : 140, hover ? 255 : 140).getRGB());
            cateY += 20;
            ++n2;
        }
        int startX = x + 80 + 2;
        int startY = y + 9 + 2 + 28;
        int length = 185;
        float moduleY = this.translate.getY();
        RenderUtil.startGlScissor(startX, startY + 14, length, 140);
        Client.instance.getModuleManager();
        for (Module m : ModuleManager.getModules()) {
            if (m.getType() != currentCategory) continue;
            RenderUtil.drawRoundRect(startX, (float)startY + moduleY, startX + length, (float)startY + moduleY + 24.0f, 3, new Color(20, 20, 20).getRGB());
            this.font1.drawStringWithShadow(m.getName(), startX + 8, (float)(startY + 9) + moduleY, -1);
            RenderUtil.drawRoundRect(startX + length - 25, (float)startY + moduleY + 7.0f, startX + length - 5, (float)startY + moduleY + 17.0f, 5, new Color(0, 0, 0).getRGB());
            boolean onToggleButton = mouseX > startX + length - 25 && mouseX < startX + length - 5 && (float)mouseY > (float)startY + moduleY + 7.0f && (float)mouseY < (float)startY + moduleY + 17.0f;
            int left = m.isEnabled() ? startX + length - 14 : startX + length - 24;
            int right = m.isEnabled() ? startX + length - 6 : startX + length - 16;
            RenderUtil.drawRoundRect(left, (float)startY + moduleY + 8.0f, right, (float)startY + moduleY + 16.0f, 4, staticColor);
            RenderUtil.drawRoundRect(startX + length - 24, (float)startY + moduleY + 8.0f, startX + length - 16, (float)startY + moduleY + 16.0f, 4, new Color(0, 0, 0, 150).getRGB());
            if (onToggleButton) {
                RenderUtil.drawRoundRect(startX + length - 25, (float)startY + moduleY + 7.0f, startX + length - 5, (float)startY + moduleY + 17.0f, 5, new Color(0, 0, 0, 100).getRGB());
            }
            boolean showSetting = inSetting.contains(m);
            int valueSizeY = m.getValues().size() * 20 + 5;
            float valueY = moduleY + 35.0f;
            if (showSetting) {
                RenderUtil.drawRect(startX + 3, (float)startY + moduleY + 24.0f, startX + length - 3, (float)startY + moduleY + 30.0f, new Color(30, 30, 30).getRGB());
                RenderUtil.drawRoundRect(startX + 3, (float)startY + moduleY + 24.0f, startX + length - 3, (float)startY + moduleY + 24.0f + (float)valueSizeY, 3, new Color(30, 30, 30).getRGB());
                for (Value<?> setting : m.getValues()) {
                    Value s;
                    if (setting instanceof Mode) {
                        boolean hover;
                        s = (Mode)setting;
                        this.font2.drawStringWithShadow(s.getDisplayName(), startX + 10, (float)startY + valueY - 1.0f, -1);
                        RenderUtil.drawRoundRect(startX + length - 85, (float)startY + valueY - 4.0f, startX + length - 6, (float)startY + valueY + 8.0f, 3, new Color(10, 10, 10).getRGB());
                        int longValue = (startX + length - 6 - (startX + length - 85)) / 2;
                        this.font2.drawCenteredStringWithShadow(((Mode)s).getModeAsString(), startX + length - 6 - longValue, (float)startY + valueY - 0.5f, staticColor);
                        boolean bl = hover = mouseX > startX + length - 85 && mouseX < startX + length - 6 && (float)mouseY > (float)startY + valueY - 4.0f && (float)mouseY < (float)startY + valueY + 8.0f;
                        if (hover) {
                            RenderUtil.drawRoundRect(startX + length - 85, (float)startY + valueY - 4.0f, startX + length - 6, (float)startY + valueY + 8.0f, 3, new Color(0, 0, 0, 100).getRGB());
                        }
                    }
                    if (setting instanceof Numbers) {
                        boolean hover;
                        s = (Numbers)setting;
                        this.font2.drawStringWithShadow(s.getDisplayName(), startX + 10, (float)startY + valueY - 3.0f, -1);
                        double inc = ((Number)((Numbers)s).getIncrement()).doubleValue();
                        double max = ((Number)((Numbers)s).getMaximum()).doubleValue();
                        double min = ((Number)((Numbers)s).getMinimum()).doubleValue();
                        double valn = ((Number)s.getValue()).doubleValue();
                        int longValue = startX + length - 6 - (startX + length - 83);
                        this.font3.drawStringWithShadow(String.valueOf(((Number)s.getValue()).doubleValue()), startX + length - 84, (float)startY + valueY - 2.0f, -1);
                        RenderUtil.drawRoundRect(startX + length - 85, (float)startY + valueY + 5.0f, startX + length - 6, (float)startY + valueY + 7.0f, 1, new Color(10, 10, 10).getRGB());
                        RenderUtil.drawRoundRect(startX + length - 85, (float)startY + valueY + 5.0f, (double)(startX + length - 85) + (double)longValue * (valn - min) / (max - min) + 2.0, (float)startY + valueY + 7.0f, 1, staticColor);
                        boolean bl = hover = mouseX > startX + length - 88 && mouseX < startX + length - 3 && (float)mouseY > (float)startY + valueY + 2.0f && (float)mouseY < (float)startY + valueY + 11.0f;
                        if (hover) {
                            RenderUtil.drawRoundRect(startX + length - 85, (float)startY + valueY + 5.0f, startX + length - 6, (float)startY + valueY + 7.0f, 1, new Color(0, 0, 0, 100).getRGB());
                            if (Mouse.isButtonDown((int)0)) {
                                double valAbs = mouseX - (startX + length - 85);
                                double perc = valAbs / ((double)longValue * Math.max(Math.min(valn / max, 0.0), 1.0));
                                perc = Math.min(Math.max(0.0, perc), 1.0);
                                double valRel = (max - min) * perc;
                                double val = min + valRel;
                                val = (double)Math.round(val * (1.0 / inc)) / (1.0 / inc);
                                s.setValue(val);
                            }
                        }
                    }
                    if (setting instanceof Option) {
                        s = (Option)setting;
                        this.font2.drawStringWithShadow(s.getDisplayName(), startX + 10, (float)startY + valueY - 3.0f, -1);
                        boolean hover = mouseX > startX + length - 18 && mouseX < startX + length - 6 && (float)mouseY > (float)startY + valueY - 4.0f && (float)mouseY < (float)startY + valueY + 8.0f;
                        RenderUtil.drawRoundRect(startX + length - 18, (float)startY + valueY - 4.0f, startX + length - 6, (float)startY + valueY + 8.0f, 2, new Color(10, 10, 10).getRGB());
                        if (((Boolean)s.getValue()).booleanValue()) {
                            FontLoaders.other24.drawString("v", startX + length - 18, (float)startY + valueY - 1.0f, staticColor);
                        }
                        if (hover) {
                            RenderUtil.drawRoundRect(startX + length - 18, (float)startY + valueY - 4.0f, startX + length - 6, (float)startY + valueY + 8.0f, 2, new Color(0, 0, 0, 100).getRGB());
                        }
                    }
                    valueY += 20.0f;
                }
            }
            moduleY += (float)(showSetting ? 26 + valueSizeY : 26);
        }
        RenderUtil.stopGlScissor();
        int real = Mouse.getDWheel();
        float moduleHeight = moduleY - this.translate.getY();
        if (Mouse.hasWheel() && mouseX > startX && mouseY > startY && mouseX < startX + 270 && mouseY < startY + 237) {
            int i;
            if (real > 0 && wheel < 0) {
                i = 0;
                while (i < 5) {
                    if (wheel < 0) {
                        wheel += 5;
                        ++i;
                        continue;
                    }
                    break;
                }
            } else {
                i = 0;
                while (i < 5) {
                    if (real < 0 && moduleHeight > 158.0f && (float)Math.abs(wheel) < moduleHeight - 154.0f) {
                        wheel -= 5;
                        ++i;
                        continue;
                    }
                    break;
                }
            }
        }
        this.translate.interpolate(0.0f, wheel, 0.15f);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        boolean hover2top;
        super.mouseClicked(mouseX, mouseY, mouseButton);
        boolean bl = hover2top = mouseX > x && mouseX < x + 273 && mouseY > y && mouseY < y + 35;
        if (hover2top && mouseButton == 0) {
            this.dragX = mouseX - x;
            this.dragY = mouseY - y;
            this.need2move = true;
        } else {
            int cateY = 0;
            ModuleType[] moduleTypeArray = ModuleType.values();
            int n = moduleTypeArray.length;
            int n2 = 0;
            while (n2 < n) {
                boolean hover;
                ModuleType category = moduleTypeArray[n2];
                int strX = x + 40;
                int strY = y + 55 + cateY;
                boolean bl2 = hover = mouseX > x + 5 && mouseX < x + 65 && mouseY > strY && mouseY < strY + 20;
                if (hover && mouseButton == 0) {
                    currentCategory = category;
                    wheel = 0;
                    this.translate.setY(0.0f);
                    break;
                }
                cateY += 20;
                ++n2;
            }
            int startX = x + 80 + 2;
            int startY = y + 9 + 2 + 25;
            int length = 185;
            float moduleY = this.translate.getY();
            Client.instance.getModuleManager();
            for (Module m : ModuleManager.getModules()) {
                boolean onModuleRect;
                if (m.getType() != currentCategory) continue;
                boolean onToggleButton = mouseX > startX + length - 25 && mouseX < startX + length - 5 && (float)mouseY > (float)startY + moduleY + 7.0f && (float)mouseY < (float)startY + moduleY + 20.0f && mouseY < startY + 14 + 140 && mouseY > startY;
                boolean bl3 = onModuleRect = mouseX > startX && mouseX < startX + length && (float)mouseY > (float)startY + moduleY && (float)mouseY < (float)startY + moduleY + 28.0f && mouseY < startY + 14 + 140 && mouseY > startY;
                if (onToggleButton && mouseButton == 0) {
                    m.setEnabled(!m.isEnabled());
                }
                if (onModuleRect && mouseButton == 1) {
                    if (inSetting.contains(m)) {
                        inSetting.remove(m);
                    } else if (!m.getValues().isEmpty()) {
                        inSetting.add(m);
                    }
                }
                boolean showSetting = inSetting.contains(m);
                int valueSizeY = m.getValues().size() * 20 + 5;
                float valueY = moduleY + 35.0f;
                if (showSetting) {
                    RenderUtil.drawRect(startX + 3, (float)startY + moduleY + 24.0f, startX + length - 3, (float)startY + moduleY + 24.0f + (float)valueSizeY, new Color(30, 30, 30).getRGB());
                    for (Value<?> setting : m.getValues()) {
                        boolean hover;
                        Value s;
                        if (setting instanceof Mode) {
                            s = (Mode)setting;
                            boolean bl4 = hover = mouseX > startX + length - 85 && mouseX < startX + length - 6 && (float)mouseY > (float)startY + valueY - 4.0f && (float)mouseY < (float)startY + valueY + 11.0f && mouseY < startY + 14 + 140 && mouseY > startY;
                            if (hover) {
                                Enum current;
                                if (mouseButton == 1) {
                                    current = (Enum)s.getValue();
                                    s.setValue(s.getModes()[current.ordinal() - 1 < 0 ? s.getModes().length - 1 : current.ordinal() - 1]);
                                }
                                if (mouseButton == 0) {
                                    current = (Enum)s.getValue();
                                    int next = current.ordinal() + 1 >= s.getModes().length ? 0 : current.ordinal() + 1;
                                    s.setValue(s.getModes()[next]);
                                }
                            }
                        }
                        if (setting instanceof Option) {
                            s = (Option)setting;
                            boolean bl5 = hover = mouseX > startX + length - 18 && mouseX < startX + length - 6 && (float)mouseY > (float)startY + valueY - 4.0f && (float)mouseY < (float)startY + valueY + 11.0f && mouseY < startY + 14 + 140 && mouseY > startY;
                            if (hover && (mouseButton == 0 || mouseButton == 2)) {
                                s.setValue((Boolean)s.getValue() == false);
                            }
                        }
                        valueY += 20.0f;
                    }
                }
                moduleY += (float)(showSetting ? 26 + valueSizeY : 26);
            }
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        boolean hover2top;
        super.mouseReleased(mouseX, mouseY, state);
        int startY = y + 9 + 2 + 28;
        boolean bl = hover2top = mouseX > x + 1 && mouseX < x + 349 && mouseY > y + 1 && mouseY < y + 9 && mouseY < startY + 14 + 140 && mouseY > startY;
        if (hover2top && state == 0) {
            this.dragX = mouseX - x;
            this.dragY = mouseY - y;
            this.need2move = false;
        }
    }

    @Override
    public void onGuiClosed() {
        super.onGuiClosed();
        ClickGui.memoriseX = x;
        ClickGui.memoriseY = y;
        ClickGui.memoriseWheel = wheel;
        ClickGui.memoriseML = inSetting;
        ClickGui.memoriseCatecory = currentCategory;
        try {
            Mouse.setNativeCursor(null);
        }
        catch (Throwable throwable) {
            // empty catch block
        }
    }

    private void hideCursor() {
        if (this.emptyCursor == null) {
            if (Mouse.isCreated()) {
                int min = Cursor.getMinCursorSize();
                IntBuffer tmp = BufferUtils.createIntBuffer((int)(min * min));
                try {
                    this.emptyCursor = new Cursor(min, min, min / 2, min / 2, 1, tmp, null);
                }
                catch (LWJGLException e) {
                    e.printStackTrace();
                }
            } else {
                System.out.println("Could not create empty cursor before Mouse object is created");
            }
        }
        try {
            Mouse.setNativeCursor((Cursor)(Mouse.isInsideWindow() ? this.emptyCursor : null));
        }
        catch (LWJGLException e) {
            e.printStackTrace();
        }
    }

    public static void setX(int state) {
        x = state;
    }

    public static void setY(int state) {
        y = state;
    }

    public static void setCategory(ModuleType state) {
        currentCategory = state;
    }

    public static void setInSetting(List<Module> moduleList) {
        inSetting = moduleList;
    }

    public static void setWheel(int state) {
        wheel = state;
    }

    public static int getColor() {
        return new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue(), 255).getRGB();
    }
}

