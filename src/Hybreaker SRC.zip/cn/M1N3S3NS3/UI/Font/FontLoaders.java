/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.UI.Font;

import cn.M1N3S3NS3.UI.Font.CFontRenderer;
import java.awt.Font;
import java.io.InputStream;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

public abstract class FontLoaders {
    public static CFontRenderer other24 = new CFontRenderer(FontLoaders.getother(24), true, true);
    public static CFontRenderer Comfortaa40 = new CFontRenderer(FontLoaders.getComfortaa(40), true, true);
    public static CFontRenderer Comfortaa14 = new CFontRenderer(FontLoaders.getComfortaa(14), true, true);
    public static CFontRenderer Comfortaa12 = new CFontRenderer(FontLoaders.getComfortaa(12), true, true);
    public static CFontRenderer Comfortaa15 = new CFontRenderer(FontLoaders.getComfortaa(15), true, true);
    public static CFontRenderer Comfortaa16 = new CFontRenderer(FontLoaders.getComfortaa(16), true, true);
    public static CFontRenderer Comfortaa17 = new CFontRenderer(FontLoaders.getComfortaa(17), true, true);
    public static CFontRenderer Comfortaa18 = new CFontRenderer(FontLoaders.getComfortaa(18), true, true);
    public static CFontRenderer Comfortaa19 = new CFontRenderer(FontLoaders.getComfortaa(19), true, true);
    public static CFontRenderer Comfortaa20 = new CFontRenderer(FontLoaders.getComfortaa(20), true, true);
    public static CFontRenderer Comfortaa22 = new CFontRenderer(FontLoaders.getComfortaa(22), true, true);
    public static CFontRenderer Comfortaa24 = new CFontRenderer(FontLoaders.getComfortaa(24), true, true);
    public static CFontRenderer Comfortaa26 = new CFontRenderer(FontLoaders.getComfortaa(26), true, true);
    public static CFontRenderer Comfortaa28 = new CFontRenderer(FontLoaders.getComfortaa(28), true, true);
    public static CFontRenderer NOTIFICATION = new CFontRenderer(FontLoaders.getfonts(45, "notif", true), true, true);
    public static CFontRenderer GoogleSans12 = new CFontRenderer(FontLoaders.getGoogleSans(12), true, true);
    public static CFontRenderer GoogleSans14 = new CFontRenderer(FontLoaders.getGoogleSans(14), true, true);
    public static CFontRenderer GoogleSans15 = new CFontRenderer(FontLoaders.getGoogleSans(15), true, true);
    public static CFontRenderer GoogleSans16 = new CFontRenderer(FontLoaders.getGoogleSans(16), true, true);
    public static CFontRenderer GoogleSans18 = new CFontRenderer(FontLoaders.getGoogleSans(18), true, true);
    public static CFontRenderer GoogleSans19 = new CFontRenderer(FontLoaders.getGoogleSans(19), true, true);
    public static CFontRenderer GoogleSans20 = new CFontRenderer(FontLoaders.getGoogleSans(20), true, true);
    public static CFontRenderer GoogleSans22 = new CFontRenderer(FontLoaders.getGoogleSans(22), true, true);
    public static CFontRenderer GoogleSans24 = new CFontRenderer(FontLoaders.getGoogleSans(24), true, true);
    public static CFontRenderer GoogleSans26 = new CFontRenderer(FontLoaders.getGoogleSans(26), true, true);
    public static CFontRenderer GoogleSans28 = new CFontRenderer(FontLoaders.getGoogleSans(28), true, true);
    public static CFontRenderer GoogleSans35 = new CFontRenderer(FontLoaders.getGoogleSans(35), true, true);
    public static CFontRenderer NovICON11 = new CFontRenderer(FontLoaders.getNovICON(10), true, true);
    public static CFontRenderer NovICON12 = new CFontRenderer(FontLoaders.getNovICON(12), true, true);
    public static CFontRenderer NovICON13 = new CFontRenderer(FontLoaders.getNovICON(13), true, true);
    public static CFontRenderer NovICON14 = new CFontRenderer(FontLoaders.getNovICON(14), true, true);
    public static CFontRenderer NovICON15 = new CFontRenderer(FontLoaders.getNovICON(15), true, true);
    public static CFontRenderer NovICON16 = new CFontRenderer(FontLoaders.getNovICON(16), true, true);
    public static CFontRenderer NovICON18 = new CFontRenderer(FontLoaders.getNovICON(18), true, true);
    public static CFontRenderer NovICON20 = new CFontRenderer(FontLoaders.getNovICON(20), true, true);
    public static CFontRenderer NovICON22 = new CFontRenderer(FontLoaders.getNovICON(22), true, true);
    public static CFontRenderer NovICON24 = new CFontRenderer(FontLoaders.getNovICON(24), true, true);
    public static CFontRenderer NovICON26 = new CFontRenderer(FontLoaders.getNovICON(26), true, true);
    public static CFontRenderer NovICON28 = new CFontRenderer(FontLoaders.getNovICON(28), true, true);
    public static CFontRenderer NovICON30 = new CFontRenderer(FontLoaders.getNovICON(30), true, true);
    public static CFontRenderer NovICON32 = new CFontRenderer(FontLoaders.getNovICON(32), true, true);
    public static CFontRenderer NovICON34 = new CFontRenderer(FontLoaders.getNovICON(34), true, true);
    public static CFontRenderer NovICON36 = new CFontRenderer(FontLoaders.getNovICON(36), true, true);
    public static CFontRenderer NovICON38 = new CFontRenderer(FontLoaders.getNovICON(38), true, true);
    public static CFontRenderer NovICON40 = new CFontRenderer(FontLoaders.getNovICON(40), true, true);
    public static CFontRenderer NovICON42 = new CFontRenderer(FontLoaders.getNovICON(42), true, true);
    public static CFontRenderer NovICON44 = new CFontRenderer(FontLoaders.getNovICON(44), true, true);
    public static CFontRenderer NovICON46 = new CFontRenderer(FontLoaders.getNovICON(46), true, true);
    public static CFontRenderer NovICON80 = new CFontRenderer(FontLoaders.getNovICON(80), true, true);

    public static Font getComfortaa(int size) {
        Font font;
        try {
            InputStream is = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("ZenithAssets/FONT/Comfortaa.ttf")).getInputStream();
            font = Font.createFont(0, is);
            font = font.deriveFont(0, size);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        return font;
    }

    private static Font getother(int size) {
        Font font;
        try {
            InputStream is = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("ZenithAssets/FONT/other.ttf")).getInputStream();
            font = Font.createFont(0, is);
            font = font.deriveFont(0, size);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        return font;
    }

    private static Font getNovICON(int size) {
        Font font;
        try {
            InputStream is = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("ZenithAssets/FONT/NovICON.ttf")).getInputStream();
            font = Font.createFont(0, is);
            font = font.deriveFont(0, size);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        return font;
    }

    private static Font getfonts(int size, String fontname, boolean ttf) {
        Font font;
        try {
            InputStream is = ttf ? Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("ZenithAssets/" + fontname + ".ttf")).getInputStream() : Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("ZenithAssets/" + fontname + ".otf")).getInputStream();
            font = Font.createFont(0, is);
            font = font.deriveFont(0, size);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        return font;
    }

    private static Font getGoogleSans(int size) {
        Font font;
        try {
            InputStream is = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("ZenithAssets/FONT/GoogleSans.ttf")).getInputStream();
            font = Font.createFont(0, is);
            font = font.deriveFont(0, size);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        return font;
    }
}

