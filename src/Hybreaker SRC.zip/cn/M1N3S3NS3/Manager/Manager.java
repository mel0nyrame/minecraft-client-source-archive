/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Manager;

public interface Manager {
    public void init();
}

