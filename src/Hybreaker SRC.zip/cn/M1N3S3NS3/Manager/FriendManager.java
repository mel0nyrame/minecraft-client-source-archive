/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Manager;

import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.FileManager;
import cn.M1N3S3NS3.Manager.FriendManager$1;
import cn.M1N3S3NS3.Manager.Manager;
import java.util.HashMap;
import java.util.List;

public class FriendManager
implements Manager {
    private static HashMap friends;

    @Override
    public void init() {
        friends = new HashMap();
        List<String> frriends = FileManager.read("Friends.txt");
        for (String v : frriends) {
            if (v.contains(":")) {
                String name = v.split(":")[0];
                String alias = v.split(":")[1];
                friends.put(name, alias);
                continue;
            }
            friends.put(v, v);
        }
        Client.instance.getCommandManager().add(new FriendManager$1(this, "f", new String[]{"friend", "fren", "fr"}, "add/del/list name alias", "Manage client friends"));
    }

    public static boolean isFriend(String name) {
        return friends.containsKey(name);
    }

    public static String getAlias(Object friends2) {
        return (String)friends.get(friends2);
    }

    public static HashMap getFriends() {
        return friends;
    }

    static HashMap access$0() {
        return friends;
    }
}

