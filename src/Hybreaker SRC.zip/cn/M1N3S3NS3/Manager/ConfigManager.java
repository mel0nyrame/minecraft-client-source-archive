/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package cn.M1N3S3NS3.Manager;

import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.FileManager;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.Modules.Render.ClickGui;
import cn.M1N3S3NS3.Util.Chat.ChatUtil;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Iterator;
import java.util.List;
import org.lwjgl.input.Keyboard;

public class ConfigManager {
    public static void SaveConfig(String dirs) {
        ChatUtil.printChat("\u5c1d\u8bd5\u4fdd\u5b58\u914d\u7f6e:" + dirs);
        File dir = new File(FileManager.dir, dirs);
        if (!dir.exists()) {
            dir.mkdir();
        }
        String values = "";
        for (Module m : ModuleManager.getModules()) {
            for (Value<?> value : m.getValues()) {
                values = String.valueOf(String.valueOf(values)) + String.format("%s:%s:%s%s", m.getName(), value.getName(), value.getValue(), System.lineSeparator());
            }
        }
        FileManager.save(dir, "Values.txt", values, false);
        String content = "";
        for (Module m : ModuleManager.getModules()) {
            content = String.valueOf(content) + String.format("%s:%s%s", m.getName(), Keyboard.getKeyName((int)m.getKey()), System.lineSeparator());
        }
        FileManager.save(dir, "Binds.txt", content, false);
        String enabled = "";
        for (Module module : ModuleManager.getModules()) {
            if (!module.isEnabled()) continue;
            enabled = String.valueOf(enabled) + String.format("%s%s", module.getName(), System.lineSeparator());
        }
        FileManager.save(dir, "Enabled.txt", enabled, false);
        String string = String.format("%s:%s%s", dirs, Client.Users, System.lineSeparator());
        FileManager.save(dir, "Config.MineSenseConfigInfo", string, false);
        ChatUtil.printChat("\u4fdd\u5b58\u914d\u7f6e:" + dirs + " \u5b8c\u6210");
    }

    public static void LoadConfig(String dirs) {
        File dir = new File(FileManager.dir, dirs);
        if (!dir.exists()) {
            ChatUtil.printChat("\u60a8\u52a0\u8f7d\u7684\u914d\u7f6e\u4e0d\u5b58\u5728!");
            return;
        }
        try {
            File info = new File(dir, "Config.MineSenseConfigInfo");
            BufferedReader bufferedReader = new BufferedReader(new FileReader(info));
            String s = bufferedReader.readLine();
            String[] s2 = s.split(":");
            ChatUtil.printChat("\u914d\u7f6e:" + s2[0] + " \u4f5c\u8005:" + s2[1]);
        }
        catch (Exception info) {
            // empty catch block
        }
        List<String> binds = FileManager.read(dir, "Binds.txt");
        for (String v : binds) {
            Iterator<String> name = v.split(":")[0];
            String bind = v.split(":")[1];
            Module m = ModuleManager.getModuleByName(name);
            if (m == null) continue;
            m.setKey(Keyboard.getKeyIndex((String)bind.toUpperCase()));
        }
        if (ModuleManager.getModuleByClass(ClickGui.class).getKey() == 0) {
            ModuleManager.getModuleByClass(ClickGui.class).setKey(Keyboard.getKeyIndex((String)"RSHIFT"));
        }
        List<String> enabled = FileManager.read(dir, "Enabled.txt");
        for (Module i : ModuleManager.modules) {
            if (!i.isEnabled()) continue;
            i.setEnabled(false);
        }
        for (String v2 : enabled) {
            Module j = ModuleManager.getModuleByName(v2);
            if (j == null || j.isEnabled()) continue;
            j.setEnabled(true);
        }
        List<String> vals = FileManager.read(dir, "Values.txt");
        for (String v3 : vals) {
            String name2 = v3.split(":")[0];
            String values = v3.split(":")[1];
            Module k = ModuleManager.getModuleByName(name2);
            if (k == null) continue;
            for (Value<?> value : k.getValues()) {
                if (!value.getName().equalsIgnoreCase(values)) continue;
                if (value instanceof Option) {
                    value.setValue(Boolean.parseBoolean(v3.split(":")[2]));
                    continue;
                }
                if (value instanceof Numbers) {
                    value.setValue(Double.parseDouble(v3.split(":")[2]));
                    continue;
                }
                ((Mode)value).setMode(v3.split(":")[2]);
            }
        }
    }

    public static void RemoveConfig(String dirs) {
        File dir = new File(FileManager.dir, dirs);
        if (!dir.exists()) {
            ChatUtil.printChat("\u60a8\u5c1d\u8bd5\u5220\u9664\u7684\u914d\u7f6e\u4e0d\u5b58\u5728!");
        } else {
            ConfigManager.deleteFile(dir);
            ChatUtil.printChat("\u914d\u7f6e" + dirs + "\u5df2\u5220\u9664!");
        }
    }

    public static void deleteFile(File file) {
        if (file.exists()) {
            if (file.isFile()) {
                file.delete();
            } else {
                File[] listFiles2;
                File[] listFiles = listFiles2 = file.listFiles();
                File[] fileArray = listFiles2;
                int n = listFiles2.length;
                int n2 = 0;
                while (n2 < n) {
                    File file2 = fileArray[n2];
                    ConfigManager.deleteFile(file2);
                    ++n2;
                }
            }
            file.delete();
        } else {
            System.err.println("\u8def\u5f84\u4e0d\u5b58\u5728?");
        }
    }
}

