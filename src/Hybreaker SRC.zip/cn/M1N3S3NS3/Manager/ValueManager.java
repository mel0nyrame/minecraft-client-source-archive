/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Manager;

import cn.M1N3S3NS3.API.Value.Value;
import java.util.ArrayList;
import java.util.List;

public class ValueManager {
    public static ArrayList values = new ArrayList();

    public static Value getValue(String name) {
        for (Value value : values) {
            if (!value.getName().equalsIgnoreCase(name)) continue;
            return value;
        }
        return null;
    }

    public static List getValueByModName(String modName) {
        ArrayList<Value> result = new ArrayList<Value>();
        for (Value value : values) {
            if (!value.getValue().equals(modName)) continue;
            result.add(value);
        }
        return result;
    }
}

