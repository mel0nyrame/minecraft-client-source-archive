/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package cn.M1N3S3NS3.Manager;

import cn.M1N3S3NS3.API.EventBus;
import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Misc.EventKey;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Events.Render.EventRender3D;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.FileManager;
import cn.M1N3S3NS3.Manager.Manager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.AntiBot;
import cn.M1N3S3NS3.Module.Modules.Combat.AutoPot;
import cn.M1N3S3NS3.Module.Modules.Combat.BowAimbot;
import cn.M1N3S3NS3.Module.Modules.Combat.Criticals;
import cn.M1N3S3NS3.Module.Modules.Combat.KillAura;
import cn.M1N3S3NS3.Module.Modules.Combat.TargetStrafe;
import cn.M1N3S3NS3.Module.Modules.Combat.Velocity;
import cn.M1N3S3NS3.Module.Modules.Legit.AutoClicker;
import cn.M1N3S3NS3.Module.Modules.Legit.DelayRemover;
import cn.M1N3S3NS3.Module.Modules.Legit.HitBox;
import cn.M1N3S3NS3.Module.Modules.Legit.KeepSprint;
import cn.M1N3S3NS3.Module.Modules.Legit.NoJumpDelay;
import cn.M1N3S3NS3.Module.Modules.Legit.Reach;
import cn.M1N3S3NS3.Module.Modules.Legit.Strafe;
import cn.M1N3S3NS3.Module.Modules.Misc.AutoArmor;
import cn.M1N3S3NS3.Module.Modules.Misc.AutoKill;
import cn.M1N3S3NS3.Module.Modules.Misc.AutoMine;
import cn.M1N3S3NS3.Module.Modules.Misc.AutoRejoin;
import cn.M1N3S3NS3.Module.Modules.Misc.AutoTool;
import cn.M1N3S3NS3.Module.Modules.Misc.ChatFilter;
import cn.M1N3S3NS3.Module.Modules.Misc.ChestStealer;
import cn.M1N3S3NS3.Module.Modules.Misc.Disabler;
import cn.M1N3S3NS3.Module.Modules.Misc.FastPlace;
import cn.M1N3S3NS3.Module.Modules.Misc.InvCleaner;
import cn.M1N3S3NS3.Module.Modules.Misc.MCF;
import cn.M1N3S3NS3.Module.Modules.Misc.NoCommand;
import cn.M1N3S3NS3.Module.Modules.Misc.NoFall;
import cn.M1N3S3NS3.Module.Modules.Misc.SpeedMine;
import cn.M1N3S3NS3.Module.Modules.Misc.Teams;
import cn.M1N3S3NS3.Module.Modules.Misc.Timer;
import cn.M1N3S3NS3.Module.Modules.Move.AntiFall;
import cn.M1N3S3NS3.Module.Modules.Move.Blink;
import cn.M1N3S3NS3.Module.Modules.Move.Flight;
import cn.M1N3S3NS3.Module.Modules.Move.InvMove;
import cn.M1N3S3NS3.Module.Modules.Move.Jesus;
import cn.M1N3S3NS3.Module.Modules.Move.LagBackCheck;
import cn.M1N3S3NS3.Module.Modules.Move.NoSlow;
import cn.M1N3S3NS3.Module.Modules.Move.PlayerFinderModule;
import cn.M1N3S3NS3.Module.Modules.Move.Scaffold;
import cn.M1N3S3NS3.Module.Modules.Move.Speed;
import cn.M1N3S3NS3.Module.Modules.Move.Sprint;
import cn.M1N3S3NS3.Module.Modules.Move.Step;
import cn.M1N3S3NS3.Module.Modules.Render.Animations;
import cn.M1N3S3NS3.Module.Modules.Render.Cape;
import cn.M1N3S3NS3.Module.Modules.Render.Chams;
import cn.M1N3S3NS3.Module.Modules.Render.ClickGui;
import cn.M1N3S3NS3.Module.Modules.Render.Crosshair;
import cn.M1N3S3NS3.Module.Modules.Render.CustomColor;
import cn.M1N3S3NS3.Module.Modules.Render.ESP2D;
import cn.M1N3S3NS3.Module.Modules.Render.Freecam;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.Module.Modules.Render.ItemPhysic;
import cn.M1N3S3NS3.Module.Modules.Render.LowFire;
import cn.M1N3S3NS3.Module.Modules.Render.MotionBlur;
import cn.M1N3S3NS3.Module.Modules.Render.NameTags;
import cn.M1N3S3NS3.Module.Modules.Render.PointFinder;
import cn.M1N3S3NS3.Module.Modules.Render.Radar;
import cn.M1N3S3NS3.Module.Modules.Render.Scoreboard;
import cn.M1N3S3NS3.Module.Modules.Render.TargetHUD;
import cn.M1N3S3NS3.Module.Modules.Render.TargetHUD2;
import cn.M1N3S3NS3.Module.Modules.Render.ViewClip;
import cn.M1N3S3NS3.Module.Modules.Render.Waypoint;
import cn.M1N3S3NS3.Module.Modules.Render.Xray;
import cn.M1N3S3NS3.Module.assist.NetWorkAssist;
import cn.M1N3S3NS3.Module.assist.ScaffoldAssist;
import cn.M1N3S3NS3.Util.Render.gl.GLUtils;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;

public class ModuleManager
implements Manager {
    public static ArrayList<Module> modules = new ArrayList();
    public static Map<Module, Object> pluginModsList = new HashMap<Module, Object>();
    public static Map<Module, Object> disabledPluginList = new HashMap<Module, Object>();
    public static boolean loaded = false;
    private boolean enabledNeededMod = true;
    public boolean nicetry = true;
    private NetWorkAssist netWorkAssist;
    private ScaffoldAssist scaffoldAssist;

    @Override
    public void init() {
        modules.add(new KillAura());
        modules.add(new Velocity());
        modules.add(new AntiBot());
        modules.add(new Criticals());
        modules.add(new BowAimbot());
        modules.add(new KeepSprint());
        modules.add(new Freecam());
        modules.add(new NameTags());
        modules.add(new TargetHUD());
        modules.add(new TargetHUD2());
        modules.add(new ChatFilter());
        modules.add(new Animations());
        modules.add(new TargetStrafe());
        modules.add(new HUD());
        modules.add(new Disabler());
        modules.add(new ClickGui());
        modules.add(new ViewClip());
        modules.add(new Chams());
        modules.add(new Waypoint());
        modules.add(new PlayerFinderModule());
        modules.add(new Xray());
        modules.add(new PointFinder());
        modules.add(new ESP2D());
        modules.add(new LowFire());
        modules.add(new Jesus());
        modules.add(new MotionBlur());
        modules.add(new ChestStealer());
        modules.add(new InvCleaner());
        modules.add(new AntiFall());
        modules.add(new Cape());
        modules.add(new CustomColor());
        modules.add(new Scoreboard());
        modules.add(new Radar());
        modules.add(new TargetHUD());
        modules.add(new Sprint());
        modules.add(new Speed());
        modules.add(new LagBackCheck());
        modules.add(new Step());
        modules.add(new NoSlow());
        modules.add(new Crosshair());
        modules.add(new ItemPhysic());
        modules.add(new InvMove());
        modules.add(new NoJumpDelay());
        modules.add(new AutoMine());
        modules.add(new Scaffold());
        modules.add(new Blink());
        modules.add(new Strafe());
        modules.add(new NoFall());
        modules.add(new AutoTool());
        modules.add(new FastPlace());
        modules.add(new NoCommand());
        modules.add(new Teams());
        modules.add(new AutoArmor());
        modules.add(new AutoPot());
        modules.add(new SpeedMine());
        modules.add(new AutoRejoin());
        modules.add(new AutoKill());
        modules.add(new MCF());
        modules.add(new Timer());
        modules.add(new Flight());
        modules.add(new DelayRemover());
        modules.add(new Reach());
        modules.add(new HitBox());
        modules.add(new AutoClicker());
        this.readSettings();
        for (Module m : modules) {
            m.makeCommand();
        }
        Collections.sort(modules, new Comparator<Module>(){

            @Override
            public int compare(Module o1, Module o2) {
                int flag = o1.getName().compareTo(o2.getName());
                return flag;
            }
        });
        for (Module m : modules) {
            System.out.println(m.getName());
        }
        this.scaffoldAssist = new ScaffoldAssist();
        this.scaffoldAssist.init();
        this.netWorkAssist = new NetWorkAssist();
        this.netWorkAssist.init();
        EventBus.getInstance().register(this);
        loaded = true;
    }

    public static List<Module> getModules() {
        return modules;
    }

    public static Module getModuleByClass(Class<? extends Module> cls) {
        for (Module m : modules) {
            if (m.getClass() != cls) continue;
            return m;
        }
        return null;
    }

    public static Module getModuleByName(String name) {
        for (Module m : modules) {
            if (!m.getName().equalsIgnoreCase(name)) continue;
            return m;
        }
        return null;
    }

    public Module getAlias(String name) {
        for (Module f : modules) {
            if (f.getName().equalsIgnoreCase(name)) {
                return f;
            }
            String[] alias = f.getAlias();
            int length = alias.length;
            int i = 0;
            while (i < length) {
                String s = alias[i];
                if (s.equalsIgnoreCase(name)) {
                    return f;
                }
                ++i;
            }
        }
        return null;
    }

    public static List<Module> getModulesInType(ModuleType t) {
        ArrayList<Module> output = new ArrayList<Module>();
        for (Module m : modules) {
            if (m.getType() != t) continue;
            output.add(m);
        }
        return output;
    }

    @EventHandler
    private void onKeyPress(EventKey e) {
        for (Module m : modules) {
            if (m.getKey() != e.getKey()) continue;
            m.setEnabled(!m.isEnabled());
        }
    }

    @EventHandler
    private void onGLHack(EventRender3D e) {
        GlStateManager.getFloat(2982, (FloatBuffer)GLUtils.MODELVIEW.clear());
        GlStateManager.getFloat(2983, (FloatBuffer)GLUtils.PROJECTION.clear());
        GlStateManager.glGetInteger(2978, (IntBuffer)GLUtils.VIEWPORT.clear());
    }

    @EventHandler
    private void on2DRender(EventRender2D e) {
        if (this.enabledNeededMod) {
            this.enabledNeededMod = false;
            for (Module m : modules) {
                if (!m.enabledOnStartup) continue;
                m.setEnabled(true);
            }
        }
    }

    private void readSettings() {
        Module m;
        List<String> binds = FileManager.read("Binds.txt");
        for (String v : binds) {
            String name = v.split(":")[0];
            String bind = v.split(":")[1];
            Module m2 = ModuleManager.getModuleByName(name);
            if (m2 == null) continue;
            m2.setKey(Keyboard.getKeyIndex((String)bind.toUpperCase()));
        }
        Client.instance.getModuleManager();
        if (ModuleManager.getModuleByClass(ClickGui.class).getKey() == 0) {
            Client.instance.getModuleManager();
            ModuleManager.getModuleByClass(ClickGui.class).setKey(Keyboard.getKeyIndex((String)"RSHIFT"));
        }
        List<String> enabled = FileManager.read("Enabled.txt");
        for (String v : enabled) {
            Module m3 = ModuleManager.getModuleByName(v);
            if (m3 == null) continue;
            m3.enabledOnStartup = true;
        }
        List<String> vals = FileManager.read("Values.txt");
        for (String v : vals) {
            String name = v.split(":")[0];
            String values = v.split(":")[1];
            m = ModuleManager.getModuleByName(name);
            if (m == null) continue;
            for (Value<?> value : m.getValues()) {
                if (!value.getName().equalsIgnoreCase(values)) continue;
                if (value instanceof Option) {
                    value.setValue(Boolean.parseBoolean(v.split(":")[2]));
                    continue;
                }
                if (value instanceof Numbers) {
                    value.setValue(Double.parseDouble(v.split(":")[2]));
                    continue;
                }
                ((Mode)value).setMode(v.split(":")[2]);
            }
        }
        List<String> names = FileManager.read("CustomName.txt");
        for (String v : names) {
            String name = v.split(":")[0];
            String cusname = v.split(":")[1];
            Module m4 = ModuleManager.getModuleByName(name);
            if (m4 == null) continue;
            m4.setCustomName(cusname);
        }
        List<String> names1 = FileManager.read("Hidden.txt");
        for (String v : names1) {
            m = ModuleManager.getModuleByName(v);
            if (m == null) continue;
            m.setRemoved(true);
        }
    }

    public void saveConfig() {
        StringBuilder values = new StringBuilder();
        for (Module m : ModuleManager.getModules()) {
            for (Value<?> value : m.getValues()) {
                values.append(String.format("%s:%s:%s%s", m.getName(), value.getName(), value.getValue(), System.lineSeparator()));
            }
        }
        FileManager.save("Values.txt", values.toString(), false);
        StringBuilder enabled = new StringBuilder();
        for (Module m : ModuleManager.getModules()) {
            if (!m.isEnabled()) continue;
            enabled.append(String.format("%s%s", m.getName(), System.lineSeparator()));
        }
        FileManager.save("Enabled.txt", enabled.toString(), false);
        String bind = "";
        for (Module module : ModuleManager.getModules()) {
            bind = String.valueOf(bind) + String.format("%s:%s%s", module.getName(), Keyboard.getKeyName((int)module.getKey()), System.lineSeparator());
        }
        FileManager.save("Binds.txt", bind, false);
        String Hiddens = "";
        for (Module m2 : ModuleManager.getModules()) {
            if (!m2.wasRemoved()) continue;
            Hiddens = String.valueOf(String.valueOf(Hiddens)) + m2.getName() + System.lineSeparator();
        }
        FileManager.save("Hidden.txt", Hiddens, false);
    }

    public NetWorkAssist getNetWorkAssist() {
        return this.netWorkAssist;
    }

    public ArrayList<Module> getModuleList() {
        return modules;
    }

    public void addPluginModule(Module mod, Object plugin) {
        pluginModsList.put(mod, plugin);
        modules.add(mod);
    }
}

