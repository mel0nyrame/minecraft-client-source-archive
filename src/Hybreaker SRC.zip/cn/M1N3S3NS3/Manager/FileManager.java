/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Manager;

import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.UI.Login.Alt;
import cn.M1N3S3NS3.UI.Login.AltManager;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import net.minecraft.client.Minecraft;

public class FileManager {
    public static File dir = new File(Minecraft.getMinecraft().mcDataDir, "MineSense");
    private static final File ALT = FileManager.getConfigFile("Alts");
    private static final File LASTALT = FileManager.getConfigFile("LastAlt");

    public static void loadLastAlt() {
        try {
            if (!LASTALT.exists()) {
                PrintWriter printWriter = new PrintWriter(new FileWriter(LASTALT));
                printWriter.println();
                printWriter.close();
            } else if (LASTALT.exists()) {
                String s;
                BufferedReader bufferedReader = new BufferedReader(new FileReader(LASTALT));
                while ((s = bufferedReader.readLine()) != null) {
                    if (s.contains("\t")) {
                        s = s.replace("\t", "    ");
                    }
                    if (s.contains("    ")) {
                        String[] parts = s.split("    ");
                        String[] account = parts[1].split(":");
                        if (account.length == 2) {
                            Client.instance.getAltManager().setLastAlt(new Alt(account[0], account[1], parts[0]));
                            continue;
                        }
                        String pw = account[1];
                        int i = 2;
                        while (i < account.length) {
                            pw = String.valueOf(pw) + ":" + account[i];
                            ++i;
                        }
                        Client.instance.getAltManager().setLastAlt(new Alt(account[0], pw, parts[0]));
                        continue;
                    }
                    String[] account2 = s.split(":");
                    if (account2.length == 1) {
                        Client.instance.getAltManager().setLastAlt(new Alt(account2[0], ""));
                        continue;
                    }
                    if (account2.length == 2) {
                        Client.instance.getAltManager().setLastAlt(new Alt(account2[0], account2[1]));
                        continue;
                    }
                    String pw2 = account2[1];
                    int j = 2;
                    while (j < account2.length) {
                        pw2 = String.valueOf(pw2) + ":" + account2[j];
                        ++j;
                    }
                    Client.instance.getAltManager().setLastAlt(new Alt(account2[0], pw2));
                }
                bufferedReader.close();
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    public static void saveLastAlt() {
        try {
            PrintWriter printWriter = new PrintWriter(LASTALT);
            Alt alt = Client.instance.getAltManager().getLastAlt();
            if (alt != null) {
                if (alt.getMask().equals("")) {
                    printWriter.println(String.valueOf(alt.getUsername()) + ":" + alt.getPassword());
                } else {
                    printWriter.println(String.valueOf(alt.getMask()) + "    " + alt.getUsername() + ":" + alt.getPassword());
                }
            }
            printWriter.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void loadAlts() {
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(ALT));
            if (!ALT.exists()) {
                PrintWriter printWriter = new PrintWriter(new FileWriter(ALT));
                printWriter.println();
                printWriter.close();
            } else if (ALT.exists()) {
                String s;
                while ((s = bufferedReader.readLine()) != null) {
                    if (s.contains("\t")) {
                        s = s.replace("\t", "    ");
                    }
                    if (s.contains("    ")) {
                        String[] parts = s.split("    ");
                        String[] account = parts[1].split(":");
                        if (account.length == 2) {
                            Client.instance.getAltManager();
                            AltManager.getAlts().add(new Alt(account[0], account[1], parts[0]));
                            continue;
                        }
                        String pw = account[1];
                        int i = 2;
                        while (i < account.length) {
                            pw = String.valueOf(pw) + ":" + account[i];
                            ++i;
                        }
                        Client.instance.getAltManager();
                        AltManager.getAlts().add(new Alt(account[0], pw, parts[0]));
                        continue;
                    }
                    String[] account2 = s.split(":");
                    if (account2.length == 1) {
                        Client.instance.getAltManager();
                        AltManager.getAlts().add(new Alt(account2[0], ""));
                        continue;
                    }
                    if (account2.length == 2) {
                        try {
                            Client.instance.getAltManager();
                            AltManager.getAlts().add(new Alt(account2[0], account2[1]));
                        }
                        catch (Exception e) {
                            e.printStackTrace();
                        }
                        continue;
                    }
                    String pw2 = account2[1];
                    int j = 2;
                    while (j < account2.length) {
                        pw2 = String.valueOf(pw2) + ":" + account2[j];
                        ++j;
                    }
                    Client.instance.getAltManager();
                    AltManager.getAlts().add(new Alt(account2[0], pw2));
                }
            }
            bufferedReader.close();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void saveAlts() {
        try {
            PrintWriter printWriter = new PrintWriter(ALT);
            Client.instance.getAltManager();
            for (Alt alt : AltManager.getAlts()) {
                if (alt.getMask().equals("")) {
                    printWriter.println(String.valueOf(alt.getUsername()) + ":" + alt.getPassword());
                    continue;
                }
                printWriter.println(String.valueOf(alt.getMask()) + "    " + alt.getUsername() + ":" + alt.getPassword());
            }
            printWriter.close();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static File getConfigFile(String name) {
        File file = new File(dir, String.format("%s.txt", name));
        if (!file.exists()) {
            try {
                file.createNewFile();
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        return file;
    }

    public static void init() {
        if (!dir.exists()) {
            dir.mkdir();
        }
        FileManager.loadLastAlt();
        FileManager.loadAlts();
    }

    /*
     * Exception decompiling
     */
    public static List<String> read(String file) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[TRYBLOCK], 9[CATCHBLOCK]], but top level block is 6[TRYBLOCK]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static List<String> read(File dir, String file) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [10[CATCHBLOCK], 1[TRYBLOCK]], but top level block is 7[TRYBLOCK]
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.processEndingBlocks(Op04StructuredStatement.java:435)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:484)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:845)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1042)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:929)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:73)
         *     at org.benf.cfr.reader.Main.main(Main.java:49)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public static void save(String file, String content, boolean append) {
        try {
            File f = new File(dir, file);
            if (!f.exists()) {
                f.createNewFile();
            }
            Throwable t = null;
            try (FileWriter writer = new FileWriter(f, append);){
                writer.write(content);
            }
            finally {
                if (t == null) {
                    Object t2 = null;
                    t = t2;
                } else {
                    Throwable t2 = null;
                    if (t != t2) {
                        t.addSuppressed(t2);
                    }
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void save(File dir, String file, String content, boolean append) {
        try {
            File f = new File(dir, file);
            if (!f.exists()) {
                f.createNewFile();
            }
            Throwable t = null;
            try (FileWriter writer = new FileWriter(f, append);){
                writer.write(content);
            }
            finally {
                if (t == null) {
                    Object t2 = null;
                    t = t2;
                } else {
                    Throwable t2 = null;
                    if (t != t2) {
                        t.addSuppressed(t2);
                    }
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}

