/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Manager;

import cn.M1N3S3NS3.API.EventBus;
import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Command.Commands.Bind;
import cn.M1N3S3NS3.Command.Commands.ConfigManagerCommand;
import cn.M1N3S3NS3.Command.Commands.Help;
import cn.M1N3S3NS3.Command.Commands.Hidden;
import cn.M1N3S3NS3.Command.Commands.Say;
import cn.M1N3S3NS3.Command.Commands.Target;
import cn.M1N3S3NS3.Command.Commands.Teleport;
import cn.M1N3S3NS3.Command.Commands.Title;
import cn.M1N3S3NS3.Command.Commands.Toggle;
import cn.M1N3S3NS3.Command.Commands.VClip;
import cn.M1N3S3NS3.Command.Commands.Waypoint;
import cn.M1N3S3NS3.Command.Commands.setName;
import cn.M1N3S3NS3.Manager.Manager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class CommandManager
implements Manager {
    public static Map<Command, Object> pluginCommands = new HashMap<Command, Object>();
    public static List<Command> commands;
    public static Map<Command, Object> disabledPluginCommands;

    static {
        disabledPluginCommands = new HashMap<Command, Object>();
    }

    @Override
    public void init() {
        commands = new ArrayList<Command>();
        commands.add(new Help());
        commands.add(new Toggle());
        commands.add(new Bind());
        commands.add(new VClip());
        commands.add(new Hidden());
        commands.add(new Teleport());
        commands.add(new setName());
        commands.add(new Waypoint());
        commands.add(new Say());
        commands.add(new Title());
        commands.add(new Target());
        commands.add(new ConfigManagerCommand());
        EventBus.getInstance().register(this);
    }

    public List<Command> getCommands() {
        return commands;
    }

    public static Optional<Command> getCommandByName(String name) {
        return commands.stream().filter(c2 -> {
            boolean isAlias = false;
            String[] arrstring = c2.getAlias();
            int n = arrstring.length;
            int n2 = 0;
            while (n2 < n) {
                String str = arrstring[n2];
                if (str.equalsIgnoreCase(name)) {
                    isAlias = true;
                    break;
                }
                ++n2;
            }
            return c2.getName().equalsIgnoreCase(name) || isAlias;
        }).findFirst();
    }

    public void add(Command command) {
        commands.add(command);
    }
}

