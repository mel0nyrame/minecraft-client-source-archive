/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Manager;

import cn.M1N3S3NS3.Util.Management;
import cn.M1N3S3NS3.Util.Math.Vec3f;
import java.util.HashMap;
import java.util.Map;

public class TagManager
extends Management {
    public Map<String, Vec3f> mapping = new HashMap<String, Vec3f>();

    public Map<String, Vec3f> getMapping() {
        return this.mapping;
    }
}

