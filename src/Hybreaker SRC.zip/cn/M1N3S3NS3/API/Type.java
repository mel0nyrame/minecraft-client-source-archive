/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API;

public class Type {
    public static final byte PRE = 0;
    public static final byte POST = 1;
    public static final byte OUTGOING = 2;
    public static final byte INCOMING = 3;
}

