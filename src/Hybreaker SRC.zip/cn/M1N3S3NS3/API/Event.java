/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API;

public abstract class Event {
    private boolean cancelled;
    public byte type;

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public byte getType() {
        return this.type;
    }

    public void setCancelled() {
        this.cancelled = true;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public static enum State {
        PRE("PRE", 0),
        POST("POST", 1);


        private State(String string2, int number) {
        }
    }
}

