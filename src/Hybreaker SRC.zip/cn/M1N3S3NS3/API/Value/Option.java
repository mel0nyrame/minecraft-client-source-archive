/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Value;

import cn.M1N3S3NS3.API.Value.Value;

public class Option<V>
extends Value<V> {
    public int anim;

    public Option(String displayName, String name, V enabled) {
        super(displayName, name);
        this.setValue(enabled);
    }

    public Option(String displayName, V enabled) {
        super(displayName, displayName);
        this.setValue(enabled);
    }
}

