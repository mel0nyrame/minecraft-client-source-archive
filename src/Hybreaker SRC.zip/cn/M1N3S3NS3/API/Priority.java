/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API;

public class Priority {
    public static final byte HIGH = 0;
    public static final byte NORMAL = 1;
    public static final byte LOW = 2;
}

