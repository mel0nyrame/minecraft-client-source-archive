/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.Render;

import cn.M1N3S3NS3.API.Event;
import net.optifine.shaders.Shaders;

public class EventRender3D
extends Event {
    public static float ticks;
    private boolean isUsingShaders;

    public EventRender3D() {
        this.isUsingShaders = Shaders.getShaderPackName() != null;
    }

    public EventRender3D(float ticks) {
        EventRender3D.ticks = ticks;
        this.isUsingShaders = Shaders.getShaderPackName() != null;
    }

    public float getPartialTicks() {
        return ticks;
    }

    public void setPartialTicks(float ticks) {
        EventRender3D.ticks = ticks;
    }

    public boolean isUsingShaders() {
        return this.isUsingShaders;
    }
}

