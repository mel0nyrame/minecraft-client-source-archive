/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.Render;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.client.gui.ScaledResolution;

public class EventRender2D
extends Event {
    public ScaledResolution sr;
    private float pt;

    public EventRender2D(ScaledResolution sr, float pt) {
        this.sr = sr;
        this.pt = pt;
    }

    public ScaledResolution getSR() {
        return this.sr;
    }

    public float getPartialTicks() {
        return this.pt;
    }

    public float getPT() {
        return this.pt;
    }
}

