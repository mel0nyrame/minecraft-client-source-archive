/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.Render;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.client.gui.GuiScreen;

public class GuiCloseEvent
extends Event {
    private final GuiScreen screen;

    public GuiCloseEvent(GuiScreen screen) {
        this.screen = screen;
    }

    public GuiScreen getScreen() {
        return this.screen;
    }
}

