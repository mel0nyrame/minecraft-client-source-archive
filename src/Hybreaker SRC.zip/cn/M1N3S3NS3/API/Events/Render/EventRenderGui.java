/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.Render;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.client.gui.ScaledResolution;

public class EventRenderGui
extends Event {
    public ScaledResolution sr;

    public EventRenderGui(ScaledResolution sr2) {
        this.sr = sr2;
    }

    public ScaledResolution getResolution() {
        return this.sr;
    }
}

