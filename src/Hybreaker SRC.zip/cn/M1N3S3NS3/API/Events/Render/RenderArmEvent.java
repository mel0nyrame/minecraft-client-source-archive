/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.Render;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.entity.Entity;

public class RenderArmEvent
extends Event {
    private Entity entity;
    private boolean pre;

    public RenderArmEvent(Entity entity, boolean pre) {
        this.entity = entity;
        this.pre = pre;
    }

    public boolean isPre() {
        return this.pre;
    }

    public boolean isPost() {
        return !this.pre;
    }

    public Entity getEntity() {
        return this.entity;
    }
}

