/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.Render;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

public class RenderCapeEvent
extends Event {
    private ResourceLocation capeLocation;
    private final EntityPlayer player;

    public RenderCapeEvent(ResourceLocation capeLocation, EntityPlayer player) {
        this.capeLocation = capeLocation;
        this.player = player;
    }

    public ResourceLocation getLocation() {
        return this.capeLocation;
    }

    public void setLocation(ResourceLocation location) {
        this.capeLocation = location;
    }

    public EntityPlayer getPlayer() {
        return this.player;
    }
}

