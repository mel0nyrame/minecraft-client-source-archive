/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.Render;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.entity.Entity;

public class RenderNameEvent
extends Event {
    private final Entity entity;

    public RenderNameEvent(Entity entityIn) {
        this.entity = entityIn;
    }

    public Entity getEntity() {
        return this.entity;
    }
}

