/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.World;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.network.Packet;

public class SendPacketEvent
extends Event {
    private EventPacketType type;
    private final Packet<?> packet;

    public SendPacketEvent(Packet<?> packet) {
        this.packet = packet;
    }

    public Packet<?> getPacket() {
        return this.packet;
    }

    public boolean isSending() {
        boolean b = this.type == EventPacketType.SEND;
        return b;
    }

    public static enum EventPacketType {
        SEND,
        RECEIVE;

    }
}

