/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.World;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.network.Packet;

public class EventPacketReceive
extends Event {
    public static Packet packet;

    public EventPacketReceive(Packet packet) {
        EventPacketReceive.packet = packet;
    }

    public static Packet getPacket() {
        return packet;
    }

    public void setPacket(Packet packet) {
        EventPacketReceive.packet = packet;
    }
}

