/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.World;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.client.Minecraft;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovementInput;

public class EventMove
extends Event {
    public static double x;
    public static double y;
    public static double z;
    private double motionX;
    private double motionY;
    private double motionZ;
    private static final Minecraft mc;

    static {
        mc = Minecraft.getMinecraft();
    }

    public EventMove(double x, double y, double z) {
        EventMove.x = x;
        EventMove.y = y;
        EventMove.z = z;
        this.motionX = x;
        this.motionY = y;
        this.motionZ = z;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        EventMove.x = x;
    }

    public double getY() {
        return y;
    }

    public static void setY(double y) {
        EventMove.y = y;
    }

    public double getZ() {
        return z;
    }

    public void setZ(double z) {
        EventMove.z = z;
    }

    public void setSpeed(double moveSpeed) {
        Minecraft.getMinecraft();
        float forward = MovementInput.moveForward;
        Minecraft.getMinecraft();
        float strafe = MovementInput.moveStrafe;
        Minecraft.getMinecraft();
        float yaw = Minecraft.thePlayer.rotationYaw;
        if ((double)forward == 0.0 && (double)strafe == 0.0) {
            Minecraft.getMinecraft();
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.getMinecraft();
            Minecraft.thePlayer.motionZ = 0.0;
        } else {
            if ((double)forward != 0.0) {
                if (strafe > 0.0f) {
                    yaw += (float)((double)forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0f) {
                    yaw += (float)((double)forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0f;
                if (forward > 0.0f) {
                    forward = 1.0f;
                } else if (forward < 0.0f) {
                    forward = -1.0f;
                }
            }
            double xDist = (double)forward * moveSpeed * Math.cos(Math.toRadians(yaw + 90.0f)) + (double)strafe * moveSpeed * Math.sin(Math.toRadians(yaw + 90.0f));
            double zDist = (double)forward * moveSpeed * Math.sin(Math.toRadians(yaw + 90.0f)) - (double)strafe * moveSpeed * Math.cos(Math.toRadians(yaw + 90.0f));
            Minecraft.getMinecraft();
            Minecraft.thePlayer.motionX = xDist;
            Minecraft.getMinecraft();
            Minecraft.thePlayer.motionZ = zDist;
            this.setX(xDist);
            this.setZ(zDist);
        }
    }

    public double getMovementSpeed() {
        double baseSpeed = 0.2873;
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            Minecraft.getMinecraft();
            int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return baseSpeed;
    }
}

