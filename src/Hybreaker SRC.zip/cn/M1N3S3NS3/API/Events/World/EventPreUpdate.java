/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.World;

import cn.M1N3S3NS3.API.Event;

public class EventPreUpdate
extends Event {
    public static float yaw;
    public static float pitch;
    public double x;
    public static double y;
    public double z;
    public static boolean ground;
    private boolean alwaysSend;
    private boolean isPre;
    private static float RENDERPREVYAW;
    private static float RENDERYAW;
    private static float RENDERPREVPITCH;
    private static float RENDERPITCH;
    public static float lastYaw;
    public static float lastPitch;

    public EventPreUpdate(float yaw, float pitch, float lastYaw, float lastPitch, double x, double y, double z, boolean ground) {
        this.isPre = true;
        EventPreUpdate.yaw = yaw;
        EventPreUpdate.pitch = pitch;
        this.x = x;
        EventPreUpdate.y = y;
        this.z = z;
        EventPreUpdate.ground = ground;
        EventPreUpdate.lastYaw = lastYaw;
        EventPreUpdate.lastPitch = lastPitch;
    }

    public static float getRenderYaw() {
        return RENDERYAW;
    }

    public static float getRenderPitch() {
        return RENDERPITCH;
    }

    public static float getPrevRenderYaw() {
        return RENDERPREVYAW;
    }

    public static float getPrevRenderPitch() {
        return RENDERPREVPITCH;
    }

    public float getYaw() {
        return yaw;
    }

    public EventPreUpdate(float yaw, float pitch) {
        RENDERPREVYAW = RENDERYAW;
        RENDERYAW = yaw;
        RENDERPREVPITCH = RENDERPITCH;
        RENDERPITCH = pitch;
        this.isPre = false;
    }

    public void setYaw(float yaw) {
        EventPreUpdate.yaw = yaw;
    }

    public float getPitch() {
        return pitch;
    }

    public void setPitch(float pitch) {
        EventPreUpdate.pitch = pitch;
    }

    public double getZ() {
        return this.z;
    }

    public void setZ(double z) {
        this.z = z;
    }

    public double getX() {
        return this.x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public static void setY(double y2) {
        y = y2;
    }

    public EventPreUpdate setAlwaysSend(boolean alwaysSend) {
        this.alwaysSend = alwaysSend;
        return this;
    }

    public boolean isOnground() {
        return ground;
    }

    public static void setOnground(boolean ground2) {
        ground = ground2;
    }

    public float getLastYaw() {
        return lastYaw;
    }

    public void setLastYaw(float lastYaw) {
        EventPreUpdate.lastYaw = lastYaw;
    }

    public float getLastPitch() {
        return lastPitch;
    }

    public void setLastPitch(float lastPitch) {
        EventPreUpdate.lastPitch = lastPitch;
    }
}

