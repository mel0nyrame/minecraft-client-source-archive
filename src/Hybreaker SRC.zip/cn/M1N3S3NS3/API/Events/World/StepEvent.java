/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.World;

import cn.M1N3S3NS3.API.Event;

public class StepEvent
extends Event {
    private double stepHeight;
    private boolean pre;

    public StepEvent(double stepHeight, boolean pre) {
        this.stepHeight = stepHeight;
        this.pre = pre;
    }

    public double getStepHeight() {
        return this.stepHeight;
    }

    public void setStepHeight(double stepHeight) {
        this.stepHeight = stepHeight;
    }

    public boolean isPre() {
        return this.pre;
    }

    public boolean isPost() {
        return !this.pre;
    }
}

