/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.World;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.network.Packet;

public class EventPacket
extends Event {
    public Packet<?> packet;
    private boolean outgoing;
    private boolean pre;

    public EventPacket(Packet<?> packet, boolean outgoing) {
        this.packet = packet;
        this.outgoing = outgoing;
        this.pre = true;
    }

    public EventPacket(Packet<?> packet) {
        this.packet = packet;
        this.pre = false;
    }

    public boolean isPre() {
        return this.pre;
    }

    public boolean isPost() {
        return !this.pre;
    }

    public Packet getPacket() {
        return this.packet;
    }

    public void setPacket(Packet packet) {
        this.packet = packet;
    }

    public boolean isOutgoing() {
        return this.outgoing;
    }

    public boolean isIncoming() {
        return !this.outgoing;
    }
}

