/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.World;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.client.multiplayer.WorldClient;

public class WorldReloadEvent
extends Event {
    private final WorldClient world;

    public WorldReloadEvent(WorldClient world) {
        this.world = world;
    }

    public WorldClient getWorld() {
        return this.world;
    }
}

