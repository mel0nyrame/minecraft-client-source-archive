/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.World;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.network.Packet;

public class EventPacketSend
extends Event {
    public static Packet packet;
    private boolean sendPacketInEvent;

    public EventPacketSend(Packet packet) {
        EventPacketSend.packet = packet;
        this.sendPacketInEvent = false;
    }

    public static Packet getPacket() {
        return packet;
    }

    public void setPacket(Packet packet) {
        EventPacketSend.packet = packet;
    }

    public void sendPacketInEvent() {
        this.sendPacketInEvent = true;
    }

    public boolean isSendPacketInEvent() {
        return this.sendPacketInEvent;
    }
}

