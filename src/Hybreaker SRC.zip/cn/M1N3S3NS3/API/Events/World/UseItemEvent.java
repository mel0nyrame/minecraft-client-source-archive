/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.World;

import cn.M1N3S3NS3.API.Event;

public final class UseItemEvent
extends Event {
}

