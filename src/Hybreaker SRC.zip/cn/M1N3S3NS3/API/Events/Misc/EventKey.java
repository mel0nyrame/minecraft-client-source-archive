/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.Misc;

import cn.M1N3S3NS3.API.Event;

public class EventKey
extends Event {
    private int key;

    public EventKey(int key) {
        this.key = key;
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }
}

