/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.Misc;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.entity.Entity;

public class EventLivingUpdate
extends Event {
    public Entity entity;

    public EventLivingUpdate(Entity targetEntity) {
        this.entity = targetEntity;
    }

    public Entity getEntity() {
        return this.entity;
    }
}

