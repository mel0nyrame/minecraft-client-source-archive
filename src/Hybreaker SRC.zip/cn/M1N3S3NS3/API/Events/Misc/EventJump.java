/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.Misc;

import cn.M1N3S3NS3.API.Event;

public class EventJump
extends Event {
    private double motionY;
    private boolean pre;

    public EventJump(double motionY, boolean pre) {
        this.motionY = motionY;
        this.pre = pre;
    }

    public double getMotionY() {
        return this.motionY;
    }

    public void setMotionY(double motiony) {
        this.motionY = motiony;
    }

    public boolean isPre() {
        return this.pre;
    }

    public boolean isPost() {
        return !this.pre;
    }
}

