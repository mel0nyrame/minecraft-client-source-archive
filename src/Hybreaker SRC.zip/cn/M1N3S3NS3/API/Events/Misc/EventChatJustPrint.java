/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.Misc;

import cn.M1N3S3NS3.API.Event;

public class EventChatJustPrint
extends Event {
    private static String msg;

    public EventChatJustPrint(String s) {
        msg = s;
    }

    public String getMessage() {
        return msg;
    }
}

