/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events.Misc;

import cn.M1N3S3NS3.API.Event;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class EventRenderEntity
extends Event {
    Entity entity;
    Event.State state;

    public EventRenderEntity(Entity entity, Event.State state) {
        this.entity = entity;
        this.state = state;
    }

    public Entity getEntity() {
        return this.entity;
    }

    public void setEntity(EntityLivingBase entity) {
        this.entity = entity;
    }

    public Event.State getState() {
        return this.state;
    }

    public void setState(Event.State state) {
        this.state = state;
    }
}

