/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.API.Events;

import cn.M1N3S3NS3.API.Event;

public class EventGetBlockReach
extends Event {
    public float reach = -1.0f;
}

