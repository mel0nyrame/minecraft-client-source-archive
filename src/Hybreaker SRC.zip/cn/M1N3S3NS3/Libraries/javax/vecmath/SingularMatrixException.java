/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Libraries.javax.vecmath;

public class SingularMatrixException
extends RuntimeException {
    public SingularMatrixException() {
    }

    public SingularMatrixException(String str) {
        super(str);
    }
}

