/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Libraries.javax.vecmath;

public class MismatchedSizeException
extends RuntimeException {
    public MismatchedSizeException() {
    }

    public MismatchedSizeException(String str) {
        super(str);
    }
}

