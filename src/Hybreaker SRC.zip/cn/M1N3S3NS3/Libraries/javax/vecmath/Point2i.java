/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Libraries.javax.vecmath;

import cn.M1N3S3NS3.Libraries.javax.vecmath.Tuple2i;
import java.io.Serializable;

public class Point2i
extends Tuple2i
implements Serializable {
    static final long serialVersionUID = 9208072376494084954L;

    public Point2i(int x, int y) {
        super(x, y);
    }

    public Point2i(int[] t) {
        super(t);
    }

    public Point2i(Tuple2i t1) {
        super(t1);
    }

    public Point2i() {
    }
}

