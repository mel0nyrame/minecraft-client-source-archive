/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  org.lwjgl.opengl.Display
 */
package cn.M1N3S3NS3;

import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.Manager.CommandManager;
import cn.M1N3S3NS3.Manager.FileManager;
import cn.M1N3S3NS3.Manager.FriendManager;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.Login.AltManager;
import cn.M1N3S3NS3.UI.Menu.HWIDMenu;
import cn.M1N3S3NS3.UI.Render.MainSandBox;
import cn.M1N3S3NS3.UI.click.NewClickGUI;
import cn.M1N3S3NS3.UI.notification.NotificationManager;
import cn.M1N3S3NS3.Util.Render.FKCounter;
import cn.M1N3S3NS3.font.FontManager;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.thealtening.auth.TheAlteningAuthentication;
import de.Hero.clickgui.ClickGUI;
import java.awt.Color;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.Display;

public class Client {
    public static float Yaw;
    public static float Pitch;
    private final String NAME = "Astolfo";
    public static String name;
    public static String player;
    public static String version;
    public static String build;
    public static final String Lbuild;
    public static Color color;
    public static boolean publicMode;
    public static Client instance;
    public boolean pass_1;
    public boolean pass_2;
    public boolean RPC = true;
    public String alteningToken;
    private MainSandBox blob;
    public File directory;
    public static ModuleManager modulemanager;
    public static Minecraft mc;
    public static HWIDMenu hwid;
    public static CommandManager commandmanager;
    private AltManager altmanager;
    private FriendManager friendmanager;
    public boolean LoadedWorld = false;
    private int backgroundAlpha = 200;
    public TheAlteningAuthentication theAlteningAuth;
    public NewClickGUI newClickgui;
    private final boolean isInDebugMode = true;
    public static String Users;
    public static String Pass;
    public static String UID;
    public static String Group;
    public static FKCounter killCounter;
    public static String webdata;
    private NotificationManager notificationManager;
    public static int flag;
    public static boolean needReload;
    public static final String MW_GAME_START_MESSAGE = "       You have 6 minutes until the walls fall down!";
    public static final String MW_GAME_END_MESSAGE = "                                 Mega Walls";
    public ClickGUI clickgui;
    private FontManager fontManager;
    private float clickWheel;
    private ModuleType clickCategory;
    private ArrayList<Module> clickModuleList = new ArrayList();
    private int clickGuiX;
    private int clickGuiY;
    private int clickGuiWidth;
    private int clickGuiHeight;
    private boolean animated = false;

    static {
        name = "Astolfo";
        player = "\u987e\u5c0f";
        version = "Beta";
        Lbuild = build = "DevCode";
        color = new Color(255, 255, 255);
        publicMode = false;
        instance = new Client();
        mc = Minecraft.getMinecraft();
        killCounter = null;
        flag = -666;
        needReload = false;
    }

    public void initiate() {
        this.blob = new MainSandBox();
        this.clickgui = new ClickGUI();
        this.theAlteningAuth = TheAlteningAuthentication.mojang();
        commandmanager = new CommandManager();
        commandmanager.init();
        this.friendmanager = new FriendManager();
        this.friendmanager.init();
        modulemanager = new ModuleManager();
        modulemanager.init();
        killCounter = new FKCounter();
        this.altmanager = new AltManager();
        this.fontManager = new FontManager();
        this.clickCategory = ModuleType.Combat;
        this.clickGuiX = 5;
        this.clickGuiY = 5;
        this.clickGuiWidth = 310;
        this.clickGuiHeight = 200;
        AltManager.init();
        AltManager.setupAlts();
        this.notificationManager = new NotificationManager();
        FileManager.init();
        Display.setTitle((String)(String.valueOf(name) + " " + version));
        this.newClickgui = new NewClickGUI();
    }

    public MainSandBox getBlob() {
        return this.blob;
    }

    public static String getModuleName(Module mod) {
        String ModuleName = mod.getName();
        String CustomName = mod.getCustomName();
        if (CustomName != null) {
            return CustomName;
        }
        return ModuleName;
    }

    public NotificationManager getNotificationManager() {
        return this.notificationManager;
    }

    public static void RenderRotate(float yaw) {
        Minecraft.getMinecraft();
        Minecraft.thePlayer.renderYawOffset = yaw;
        Minecraft.getMinecraft();
        Minecraft.thePlayer.rotationYawHead = yaw;
    }

    public FKCounter getKillCounter() {
        return killCounter;
    }

    public static ModuleManager getModuleManager() {
        return modulemanager;
    }

    public FriendManager getFriendManager() {
        return this.friendmanager;
    }

    public CommandManager getCommandManager() {
        return commandmanager;
    }

    public AltManager getAltManager() {
        return this.altmanager;
    }

    /*
     * WARNING - void declaration
     */
    public void shutDown() {
        void var4_9;
        String values = "";
        for (Module m : ModuleManager.getModules()) {
            for (Value<?> value : m.getValues()) {
                values = String.valueOf(String.valueOf(values)) + String.format("%s:%s:%s%s", m.getName(), value.getName(), value.getValue(), System.lineSeparator());
            }
        }
        FileManager.save("Values.txt", values, false);
        new File(FileManager.dir + "/CustomName.txt").delete();
        String name = "";
        for (Module m : ModuleManager.getModules()) {
            if (m.getCustomName() == null) continue;
            name = String.valueOf(String.valueOf(name)) + String.format("%s:%s%s", m.getName(), m.getCustomName(), System.lineSeparator());
        }
        FileManager.save("CustomName.txt", name, false);
        String enabled = "";
        for (Module module : ModuleManager.getModules()) {
            if (!module.isEnabled()) continue;
            enabled = String.valueOf(String.valueOf(enabled)) + String.format("%s%s", module.getName(), System.lineSeparator());
        }
        FileManager.save("Enabled.txt", enabled, false);
        String string = "";
        for (Module m : ModuleManager.getModules()) {
            if (!m.wasRemoved()) continue;
            String string2 = String.valueOf(String.valueOf(var4_9)) + m.getName() + System.lineSeparator();
        }
        FileManager.save("Hidden.txt", (String)var4_9, false);
    }

    public String getAlteningToken() {
        return this.alteningToken;
    }

    public void setAlteningToken(String alteningToken) {
        this.alteningToken = alteningToken;
    }

    public void setRPC(boolean RPC) {
        this.RPC = RPC;
    }

    public void loadGeneralSettings() {
        block17: {
            File f = new File(Client.instance.directory, "client.json");
            if (f.exists()) {
                try {
                    Throwable throwable = null;
                    Object var3_6 = null;
                    try (FileReader reader = new FileReader(f);){
                        JsonElement element = new JsonParser().parse((Reader)reader);
                        if (!element.isJsonObject()) break block17;
                        JsonObject object = element.getAsJsonObject();
                        if (object.has("altening-token")) {
                            this.setAlteningToken(object.get("altening-token").getAsString());
                        }
                        if (object.has("RPC")) {
                            this.setRPC(object.get("RPC").getAsBoolean());
                        }
                    }
                    catch (Throwable throwable2) {
                        if (throwable == null) {
                            throwable = throwable2;
                        } else if (throwable != throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                        throw throwable;
                    }
                }
                catch (Exception exception) {}
            } else {
                try {
                    f.createNewFile();
                }
                catch (IOException iOException) {
                    // empty catch block
                }
            }
        }
    }

    public void saveGeneralSettings() {
        File f = new File(Client.instance.directory, "client.json");
        if (!f.exists()) {
            try {
                f.createNewFile();
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        if (f.exists()) {
            JsonObject object = new JsonObject();
            object.addProperty("altening-token", this.alteningToken);
            object.addProperty("RPC", Boolean.valueOf(this.RPC));
            try {
                Throwable throwable = null;
                Object var4_7 = null;
                try (FileWriter writer = new FileWriter(f);){
                    writer.write(new GsonBuilder().setPrettyPrinting().create().toJson((JsonElement)object));
                }
                catch (Throwable throwable2) {
                    if (throwable == null) {
                        throwable = throwable2;
                    } else if (throwable != throwable2) {
                        throwable.addSuppressed(throwable2);
                    }
                    throw throwable;
                }
            }
            catch (IOException e) {
                f.delete();
            }
        }
    }

    public static int clientcolor() {
        return color.getRGB();
    }

    public static void setColor(Color color) {
        Client.color = color;
    }

    public static int getClientColor() {
        Color color = new Color(((Double)HUD.color.getValue()).intValue());
        return color.getRGB();
    }

    public static int getClientColor(int Alpha) {
        Color color = new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue(), Alpha);
        return color.getRGB();
    }

    public static Color getClientColor(boolean RGBcolor) {
        Color color = new Color(((Double)HUD.color.getValue()).intValue());
        return color;
    }

    public static int getBlueColor() {
        return new Color(47, 154, 241).getRGB();
    }

    public static Color getBlueColor(int fa) {
        return new Color(47, 154, 241);
    }

    public static int getBBlueColor() {
        return new Color(0, 125, 255).getRGB();
    }

    public boolean isInDebugMode() {
        return true;
    }

    public static void PlayerYaw(EventPreUpdate event, float yaw) {
        Minecraft.thePlayer.rotationYawHead = yaw;
        EventPreUpdate.yaw = yaw;
    }

    public static void PlayerPitch(EventPreUpdate event, float pitch) {
        Minecraft.thePlayer.rotationPitchHead = pitch;
        EventPreUpdate.pitch = pitch;
    }

    public boolean isAnimated() {
        return this.animated;
    }

    public void setAnimated(boolean animated) {
        this.animated = animated;
    }

    public String getName() {
        return "Astolfo";
    }

    public FontManager getFontManager() {
        return this.fontManager;
    }

    public int getClickGuiX() {
        return this.clickGuiX;
    }

    public int getClickGuiY() {
        return this.clickGuiY;
    }

    public void setClickGuiX(int clickGuiX) {
        this.clickGuiX = clickGuiX;
    }

    public void setClickGuiY(int clickGuiY) {
        this.clickGuiY = clickGuiY;
    }

    public int getClickGuiWidth() {
        return this.clickGuiWidth;
    }

    public void setClickGuiWidth(int clickGuiWidth) {
        this.clickGuiWidth = clickGuiWidth;
    }

    public int getClickGuiHeight() {
        return this.clickGuiHeight;
    }

    public void setClickGuiHeight(int clickGuiHeight) {
        this.clickGuiHeight = clickGuiHeight;
    }

    public ModuleType getClickCategory() {
        return this.clickCategory;
    }

    public void setClickCategory(ModuleType clickCategory) {
        this.clickCategory = clickCategory;
    }

    public ArrayList<Module> getClickModuleList() {
        return this.clickModuleList;
    }

    public void setClickModuleList(ArrayList<Module> clickModuleList) {
        this.clickModuleList = clickModuleList;
    }

    public float getClickWheel() {
        return this.clickWheel;
    }

    public void setClickWheel(float clickWheel) {
        this.clickWheel = clickWheel;
    }
}

