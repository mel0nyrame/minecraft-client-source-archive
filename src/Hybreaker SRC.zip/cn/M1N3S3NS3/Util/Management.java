/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util;

import cn.M1N3S3NS3.Manager.CommandManager;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Manager.TagManager;
import cn.M1N3S3NS3.font.FontManager;

public class Management {
    private static FontManager fontManager = new FontManager();
    private static ModuleManager moduleManager = new ModuleManager();
    private static CommandManager commandManager = new CommandManager();
    private static TagManager tagManager = new TagManager();

    public static CommandManager getCommandManager() {
        return commandManager;
    }

    public static ModuleManager getModuleManager() {
        return moduleManager;
    }

    public static FontManager getFontManager() {
        return fontManager;
    }

    public static TagManager getTagManager() {
        return tagManager;
    }
}

