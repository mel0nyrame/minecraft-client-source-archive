/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util;

import cn.M1N3S3NS3.API.Events.Misc.EventRotation;
import cn.M1N3S3NS3.API.Events.World.EventPacket;
import cn.M1N3S3NS3.Util.Math.Rotation;
import cn.M1N3S3NS3.Util.Math.VecRotation;
import cn.M1N3S3NS3.Util.PlayerUtil;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

public class RotationUtil {
    private static Minecraft mc = Minecraft.getMinecraft();
    public static Random random = new Random();
    public static double x = random.nextDouble();
    public static double y = random.nextDouble();
    public static double z = random.nextDouble();
    public static float[] prevRotations = new float[2];

    public static VecRotation searchCenter(AxisAlignedBB bb, boolean outborder, boolean random, boolean predict, boolean throughWalls, float distance) {
        if (outborder) {
            Vec3 vec3 = new Vec3(bb.minX + (bb.maxX - bb.minX) * (x * 0.3 + 1.0), bb.minY + (bb.maxY - bb.minY) * (y * 0.3 + 1.0), bb.minZ + (bb.maxZ - bb.minZ) * (z * 0.3 + 1.0));
            return new VecRotation(vec3, RotationUtil.toRotation(vec3, predict));
        }
        Vec3 randomVec = new Vec3(bb.minX + (bb.maxX - bb.minX) * x * 0.8, bb.minY + (bb.maxY - bb.minY) * y * 0.8, bb.minZ + (bb.maxZ - bb.minZ) * z * 0.8);
        cn.M1N3S3NS3.Util.Rotation randomRotation = RotationUtil.toRotation(randomVec, predict);
        Vec3 eyes = Minecraft.thePlayer.getPositionEyes(1.0f);
        VecRotation vecRotation = null;
        double xSearch = 0.15;
        while (xSearch < 0.85) {
            double ySearch = 0.15;
            while (ySearch < 1.0) {
                double zSearch = 0.15;
                while (zSearch < 0.85) {
                    Vec3 vec3 = new Vec3(bb.minX + (bb.maxX - bb.minX) * xSearch, bb.minY + (bb.maxY - bb.minY) * ySearch, bb.minZ + (bb.maxZ - bb.minZ) * zSearch);
                    cn.M1N3S3NS3.Util.Rotation rotation = RotationUtil.toRotation(vec3, predict);
                    double vecDist = eyes.distanceTo(vec3);
                    if (!(vecDist > (double)distance) && (throughWalls || RotationUtil.isVisible(vec3))) {
                        VecRotation currentVec = new VecRotation(vec3, rotation);
                        if (vecRotation == null || !(random ? !(RotationUtil.getRotationDifference(currentVec.getRotation(), randomRotation) < RotationUtil.getRotationDifference(vecRotation.getRotation(), randomRotation)) : !(RotationUtil.getRotationDifference(currentVec.getRotation()) < RotationUtil.getRotationDifference(vecRotation.getRotation())))) {
                            vecRotation = currentVec;
                        }
                    }
                    zSearch += 0.1;
                }
                ySearch += 0.1;
            }
            xSearch += 0.1;
        }
        return vecRotation;
    }

    public static VecRotation faceBlock(BlockPos blockPos) {
        if (blockPos == null) {
            return null;
        }
        VecRotation vecRotation = null;
        double xSearch = 0.1;
        while (xSearch < 0.9) {
            double ySearch = 0.1;
            while (ySearch < 0.9) {
                double zSearch = 0.1;
                while (zSearch < 0.9) {
                    Vec3 eyesPos = new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.getEntityBoundingBox().minY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
                    Vec3 posVec = new Vec3(blockPos).addVector(xSearch, ySearch, zSearch);
                    double dist = eyesPos.distanceTo(posVec);
                    double diffX = posVec.xCoord - eyesPos.xCoord;
                    double diffY = posVec.yCoord - eyesPos.yCoord;
                    double diffZ = posVec.zCoord - eyesPos.zCoord;
                    double diffXZ = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
                    cn.M1N3S3NS3.Util.Rotation rotation = new cn.M1N3S3NS3.Util.Rotation(MathHelper.wrapAngleTo180_float((float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f), MathHelper.wrapAngleTo180_float((float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)))));
                    Vec3 rotationVector = RotationUtil.getVectorForRotation(rotation);
                    Vec3 vector = eyesPos.addVector(rotationVector.xCoord * dist, rotationVector.yCoord * dist, rotationVector.zCoord * dist);
                    MovingObjectPosition obj = Minecraft.theWorld.rayTraceBlocks(eyesPos, vector, false, false, true);
                    if (obj.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
                        VecRotation currentVec = new VecRotation(posVec, rotation);
                        if (vecRotation == null || RotationUtil.getRotationDifference(currentVec.getRotation()) < RotationUtil.getRotationDifference(vecRotation.getRotation())) {
                            vecRotation = currentVec;
                        }
                    }
                    zSearch += 0.1;
                }
                ySearch += 0.1;
            }
            xSearch += 0.1;
        }
        return vecRotation;
    }

    public static Vec3 getVectorForRotation(cn.M1N3S3NS3.Util.Rotation rotation) {
        float yawCos = MathHelper.cos(-rotation.getYaw() * ((float)Math.PI / 180) - (float)Math.PI);
        float yawSin = MathHelper.sin(-rotation.getYaw() * ((float)Math.PI / 180) - (float)Math.PI);
        float pitchCos = -MathHelper.cos(-rotation.getPitch() * ((float)Math.PI / 180));
        float pitchSin = MathHelper.sin(-rotation.getPitch() * ((float)Math.PI / 180));
        return new Vec3(yawSin * pitchCos, pitchSin, yawCos * pitchCos);
    }

    public static double getRotationDifference(cn.M1N3S3NS3.Util.Rotation a, cn.M1N3S3NS3.Util.Rotation b) {
        return Math.hypot(RotationUtil.getAngleDifference(a.getYaw(), b.getYaw()), a.getPitch() - b.getPitch());
    }

    private static float getAngleDifference(float a, float b) {
        return ((a - b) % 360.0f + 540.0f) % 360.0f - 180.0f;
    }

    public static double getRotationDifference(cn.M1N3S3NS3.Util.Rotation rotation) {
        return prevRotations == null ? 0.0 : RotationUtil.getRotationDifference(rotation, new cn.M1N3S3NS3.Util.Rotation(prevRotations[0], prevRotations[1]));
    }

    public static boolean isVisible(Vec3 vec3) {
        Vec3 eyesPos = new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.getEntityBoundingBox().minY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
        return Minecraft.theWorld.rayTraceBlocks(eyesPos, vec3) == null;
    }

    public static Vec3 getCenter(AxisAlignedBB bb) {
        return new Vec3(bb.minX + (bb.maxX - bb.minX) * 0.5, bb.minY + (bb.maxY - bb.minY) * 0.5, bb.minZ + (bb.maxZ - bb.minZ) * 0.5);
    }

    public static double getRotationDifference(Entity entity) {
        cn.M1N3S3NS3.Util.Rotation rotation = RotationUtil.toRotation(RotationUtil.getCenter(entity.getEntityBoundingBox()), true);
        return RotationUtil.getRotationDifference(rotation, new cn.M1N3S3NS3.Util.Rotation(Minecraft.thePlayer.rotationYaw, Minecraft.thePlayer.rotationPitch));
    }

    public static cn.M1N3S3NS3.Util.Rotation limitAngleChange(cn.M1N3S3NS3.Util.Rotation currentRotation, cn.M1N3S3NS3.Util.Rotation targetRotation, float turnSpeed) {
        float yawDifference = RotationUtil.getAngleDifference(targetRotation.getYaw(), currentRotation.getYaw());
        float pitchDifference = RotationUtil.getAngleDifference(targetRotation.getPitch(), currentRotation.getPitch());
        return new cn.M1N3S3NS3.Util.Rotation(currentRotation.getYaw() + (yawDifference > turnSpeed ? turnSpeed : Math.max(yawDifference, -turnSpeed)), currentRotation.getPitch() + (pitchDifference > turnSpeed ? turnSpeed : Math.max(pitchDifference, -turnSpeed)));
    }

    public static cn.M1N3S3NS3.Util.Rotation toRotation(Vec3 vec, boolean predict) {
        Vec3 eyesPos = new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.getEntityBoundingBox().minY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
        if (predict) {
            eyesPos.addVector(Minecraft.thePlayer.motionX, Minecraft.thePlayer.motionY, Minecraft.thePlayer.motionZ);
        }
        double diffX = vec.xCoord - eyesPos.xCoord;
        double diffY = vec.yCoord - eyesPos.yCoord;
        double diffZ = vec.zCoord - eyesPos.zCoord;
        return new cn.M1N3S3NS3.Util.Rotation(MathHelper.wrapAngleTo180_float((float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f), MathHelper.wrapAngleTo180_float((float)(-Math.toDegrees(Math.atan2(diffY, Math.sqrt(diffX * diffX + diffZ * diffZ))))));
    }

    public static boolean isFacingEntity(EntityLivingBase entityLivingBase, float[] lastRotate) {
        float yaw = RotationUtil.getNeededRotations(entityLivingBase)[0];
        float pitch = RotationUtil.getNeededRotations(entityLivingBase)[1];
        float playerPitch = lastRotate[1];
        float boudingBoxSize = 20.0f + entityLivingBase.getCollisionBorderSize();
        float playerYaw = lastRotate[0];
        while (playerYaw < 0.0f) {
            playerYaw += 360.0f;
        }
        while (yaw < 0.0f) {
            yaw += 360.0f;
        }
        while (playerYaw > 360.0f) {
            playerYaw -= 360.0f;
        }
        while (yaw > 360.0f) {
            yaw -= 360.0f;
        }
        if (playerYaw >= yaw - boudingBoxSize && playerYaw <= yaw + boudingBoxSize) {
            return playerPitch >= pitch - boudingBoxSize && playerPitch <= pitch + boudingBoxSize;
        }
        return false;
    }

    public static float getAngleChange(EntityLivingBase entityIn) {
        float yaw = RotationUtil.getNeededRotations(entityIn)[0];
        float pitch = RotationUtil.getNeededRotations(entityIn)[1];
        float playerYaw = Minecraft.thePlayer.rotationYaw;
        float playerPitch = Minecraft.thePlayer.rotationPitch;
        if (playerYaw < 0.0f) {
            playerYaw += 360.0f;
        }
        if (playerPitch < 0.0f) {
            playerPitch += 360.0f;
        }
        if (yaw < 0.0f) {
            yaw += 360.0f;
        }
        if (pitch < 0.0f) {
            pitch += 360.0f;
        }
        float yawChange = Math.max(playerYaw, yaw) - Math.min(playerYaw, yaw);
        float pitchChange = Math.max(playerPitch, pitch) - Math.min(playerPitch, pitch);
        return yawChange + pitchChange;
    }

    public static float[] getNeededRotations(EntityLivingBase entityIn) {
        double d0 = entityIn.posX - Minecraft.thePlayer.posX;
        double d1 = entityIn.posZ - Minecraft.thePlayer.posZ;
        double d2 = entityIn.posY + (double)entityIn.getEyeHeight() * 0.925 - (Minecraft.thePlayer.getEntityBoundingBox().minY + (double)Minecraft.thePlayer.getEyeHeight());
        double d3 = MathHelper.sqrt_double(d0 * d0 + d1 * d1);
        float f = (float)(MathHelper.atan2(d1, d0) * 180.0 / Math.PI) - 90.0f;
        float f1 = (float)(-(MathHelper.atan2(d2, d3) * 180.0 / Math.PI));
        return new float[]{f, f1};
    }

    public static float[] getNeededRotations(BlockPos BlockPosIn, float test) {
        double d0 = (double)BlockPosIn.getX() + 0.5 - Minecraft.thePlayer.posX;
        double d1 = (double)BlockPosIn.getZ() + 0.5 - Minecraft.thePlayer.posZ;
        double d2 = (double)BlockPosIn.getY() + 0.5 - (Minecraft.thePlayer.getEntityBoundingBox().minY + (double)Minecraft.thePlayer.getEyeHeight());
        double d3 = MathHelper.sqrt_double(d0 * d0 + d1 * d1);
        float f = (float)(MathHelper.atan2(d1, d0) * 180.0 / Math.PI) - test;
        float f1 = (float)(-(MathHelper.atan2(d2, d3) * 180.0 / Math.PI));
        return new float[]{f, f1};
    }

    public static float[] getRotations(EntityLivingBase entityIn, float speed, float[] lastRotate) {
        float yaw = RotationUtil.updateRotation(lastRotate[0], RotationUtil.getNeededRotations(entityIn)[0] + (PlayerUtil.isMoving() ? RotationUtil.randomNumber(5.0f, -5.0f) : 0.0f), speed);
        float pitch = RotationUtil.updateRotation(lastRotate[1], RotationUtil.getNeededRotations(entityIn)[1] + (PlayerUtil.isMoving() ? RotationUtil.randomNumber(5.0f, -5.0f) : 0.0f), speed);
        return new float[]{yaw, pitch};
    }

    public static float[] getRotations(BlockPos BlockInput, float speed, float[] lastRotate, float test) {
        float yaw = RotationUtil.updateRotation(lastRotate[0], RotationUtil.getNeededRotations(BlockInput, test)[0], speed);
        float pitch = RotationUtil.updateRotation(lastRotate[1], RotationUtil.getNeededRotations(BlockInput, test)[1], speed);
        return new float[]{yaw, pitch};
    }

    public static float randomNumber(float max, float min) {
        return (float)Math.random() * (max - min) + min;
    }

    public static float[] getRotationFromPosition(double x, double z, double y) {
        Minecraft.getMinecraft();
        double xDiff = x - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double zDiff = z - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        double yDiff = y - Minecraft.thePlayer.posY;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    private static float updateRotation(float currentRotation, float intendedRotation, float increment) {
        float f = MathHelper.wrapAngleTo180_float(intendedRotation - currentRotation);
        if (f > increment) {
            f = increment;
        }
        if (f < -increment) {
            f = -increment;
        }
        return currentRotation + f;
    }

    public static boolean serverRotate(EventPacket event, Rotation rotation) {
        Packet packet = event.getPacket();
        if (event.isIncoming() && packet instanceof S08PacketPlayerPosLook) {
            S08PacketPlayerPosLook s08PacketPlayerPosLook = (S08PacketPlayerPosLook)packet;
            s08PacketPlayerPosLook.yaw = rotation.getYaw();
            s08PacketPlayerPosLook.pitch = rotation.getPitch();
            event.setPacket(s08PacketPlayerPosLook);
            return true;
        }
        return false;
    }

    public static float[] getRotationBlock(BlockPos pos) {
        return RotationUtil.getRotationsByVec(Minecraft.thePlayer.getPositionVector().addVector(0.0, Minecraft.thePlayer.getEyeHeight(), 0.0), new Vec3((double)pos.getX() + 0.5, (double)pos.getY() + 0.5, (double)pos.getZ() + 0.5));
    }

    private static float[] getRotationsByVec(Vec3 origin, Vec3 position) {
        Vec3 difference = position.subtract(origin);
        double distance = difference.flat().lengthVector();
        float yaw = (float)Math.toDegrees(Math.atan2(difference.zCoord, difference.xCoord)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(difference.yCoord, distance)));
        return new float[]{yaw, pitch};
    }

    public static float[] getRotations(Entity entity) {
        double diffY;
        if (entity == null) {
            return null;
        }
        double diffX = entity.posX - Minecraft.thePlayer.posX;
        double diffZ = entity.posZ - Minecraft.thePlayer.posZ;
        if (entity instanceof EntityLivingBase) {
            EntityLivingBase elb = (EntityLivingBase)entity;
            diffY = elb.posY + ((double)elb.getEyeHeight() - 0.4) - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        } else {
            diffY = (entity.boundingBox.minY + entity.boundingBox.maxY) / 2.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        }
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-Math.atan2(diffY, dist) * 180.0 / Math.PI);
        return new float[]{yaw, pitch};
    }

    private static EventRotation smoothAngle(EventRotation e, EventRotation e2, float turnSpeed) {
        EventRotation angle = new EventRotation(e2.getYaw() - e.getYaw(), e2.getPitch() - e.getPitch()).getAngle();
        angle.setYaw(e2.getYaw() - angle.getYaw() / 100.0f * turnSpeed);
        angle.setPitch(e2.getPitch() - angle.getPitch() / 100.0f * turnSpeed);
        return angle.getAngle();
    }

    public static float[] getRotateForScaffold(float needYaw, float needPitch, float yaw, float pitch) {
        EventRotation smoothAngle = RotationUtil.smoothAngle(new EventRotation(needYaw, needPitch), new EventRotation(yaw, pitch), 60.0f);
        return new float[]{Minecraft.thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(smoothAngle.getYaw() - Minecraft.thePlayer.rotationYaw), smoothAngle.getPitch()};
    }
}

