/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Util;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.opengl.GL11;

public class HealthUtil {
    public float randomX = this.randomNumber(5, -5);
    public float moveY;
    public float maxY;
    public double posX;
    public double posY;
    public double posZ;
    public int livingTime;
    public boolean isDead;
    public float health;
    public int color;

    public HealthUtil(EntityLivingBase entity, float health) {
        this.posX = entity.posX;
        this.posY = entity.posY;
        this.posZ = entity.posZ;
        this.maxY = 30.0f;
        this.livingTime = 0;
        this.health = health;
        this.isDead = false;
        int n = this.color = this.health < 0.0f ? -1 : -16711936;
        if (this.health < 0.0f) {
            this.health = -this.health;
        }
    }

    private int randomNumber(int max, int min) {
        return (int)(Math.random() * (double)(max - min)) + min;
    }

    public void render(float renderPartialTicks) {
        if (!this.isDead) {
            ++this.livingTime;
            if (this.livingTime >= 300) {
                this.isDead = true;
                return;
            }
            if (this.moveY < this.maxY) {
                this.moveY += 0.3f;
            }
            double x = this.posX - RenderManager.renderPosX;
            double y = this.posY - RenderManager.renderPosY;
            double z = this.posZ - RenderManager.renderPosZ;
            Minecraft.getMinecraft();
            FontRenderer fontrenderer = Minecraft.fontRendererObj;
            float f = 1.5f;
            float f1 = 0.016666668f * f;
            GlStateManager.pushMatrix();
            GlStateManager.translate((float)x, (float)y + 0.9f, (float)z);
            GL11.glNormal3f((float)0.0f, (float)1.0f, (float)0.0f);
            Minecraft.getMinecraft().getRenderManager();
            GlStateManager.rotate(-RenderManager.playerViewY, 0.0f, 1.0f, 0.0f);
            Minecraft.getMinecraft().getRenderManager();
            GlStateManager.rotate(RenderManager.playerViewX, Minecraft.getMinecraft().gameSettings.thirdPersonView == 2 ? -1.0f : 1.0f, 0.0f, 0.0f);
            GlStateManager.scale(-f1, -f1, f1);
            GL11.glEnable((int)32823);
            GL11.glDisable((int)2929);
            GL11.glPolygonOffset((float)1.0f, (float)-1100000.0f);
            fontrenderer.drawStringWithShadow(String.valueOf(String.valueOf((double)Math.round(this.health * 10.0f) / 10.0)) + "\u2764", (float)(-fontrenderer.getStringWidth(String.valueOf(this.health)) / 2) + this.randomX, -this.moveY, this.color);
            GL11.glEnable((int)2929);
            GL11.glDisable((int)32823);
            GL11.glPolygonOffset((float)1.0f, (float)1100000.0f);
            GlStateManager.popMatrix();
        }
    }
}

