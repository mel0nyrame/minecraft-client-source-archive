/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Chat;

import cn.M1N3S3NS3.Client;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

public final class Logger {
    protected static final Minecraft mc = Minecraft.getMinecraft();

    public static void log(String msg) {
        if (Minecraft.thePlayer != null && Minecraft.theWorld != null) {
            StringBuilder tempMsg = new StringBuilder();
            String[] stringArray = msg.split("\n");
            int n = stringArray.length;
            int n2 = 0;
            while (n2 < n) {
                String line = stringArray[n2];
                tempMsg.append(line).append("\u00a77");
                ++n2;
            }
            Minecraft.thePlayer.addChatMessage(new ChatComponentText("\u00a7c[" + Client.name + "]\u00a77: " + tempMsg.toString()));
        }
    }
}

