/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Chat;

public class PlayerListList {
    public String name;
    public int killed;

    public PlayerListList(String n, int k) {
        this.name = n;
        this.killed = k + this.killed;
    }
}

