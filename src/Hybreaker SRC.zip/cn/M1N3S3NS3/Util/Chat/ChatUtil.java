/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Chat;

import cn.M1N3S3NS3.Client;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

public class ChatUtil {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static void printChat(String message) {
        ChatUtil.mc.ingameGUI.getChatGUI().printChatMessage(new ChatComponentText(message));
    }

    public static void printChatClientName(String message) {
        ChatUtil.mc.ingameGUI.getChatGUI().printChatMessage(new ChatComponentText("\u00a78[\u00a77" + Client.name + "\u00a78]\u00a7f " + message));
    }

    public static void debug(String message) {
        if (!Client.instance.isInDebugMode()) {
            return;
        }
        ChatUtil.mc.ingameGUI.getChatGUI().printChatMessage(new ChatComponentText("\u00a78<\u00a77/\u00a78>\u00a7f " + message));
    }

    public static void printIRCChat(String message) {
        if (Minecraft.thePlayer != null) {
            Minecraft.thePlayer.playSound("random.pop", 0.7f, 1.0f);
        }
        ChatUtil.mc.ingameGUI.getChatGUI().printChatMessage(new ChatComponentText("\u00a7dIRC\u00a78 > \u00a7r" + message));
    }
}

