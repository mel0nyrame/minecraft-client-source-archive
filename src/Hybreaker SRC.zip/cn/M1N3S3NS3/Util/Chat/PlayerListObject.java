/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Chat;

public class PlayerListObject {
    public String name;
    public int kills;

    public PlayerListObject(String name, int kills) {
        this.name = name;
        this.kills = kills;
    }
}

