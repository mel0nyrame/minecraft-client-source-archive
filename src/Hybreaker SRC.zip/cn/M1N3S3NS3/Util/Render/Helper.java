/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Render;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;

public class Helper {
    public static Minecraft mc = Minecraft.getMinecraft();
    public static boolean xray = false;
    public static Boolean DIF;
    public static HashSet blockIDs;
    public static int opacity;
    public static Boolean bypass;
    public static List<Block> dimblock;
    public static ArrayList<BlockPos> glow;

    static {
        blockIDs = new HashSet();
        bypass = true;
        dimblock = new ArrayList<Block>();
        glow = new ArrayList();
    }

    protected static List<Entity> getLoadedEntities() {
        Minecraft.getMinecraft();
        return Minecraft.theWorld.loadedEntityList;
    }

    public static boolean hasArmor(EntityPlayer player) {
        if (player.inventory == null) {
            return false;
        }
        ItemStack boots = player.inventory.armorInventory[0];
        ItemStack pants = player.inventory.armorInventory[1];
        ItemStack chest = player.inventory.armorInventory[2];
        ItemStack head = player.inventory.armorInventory[3];
        return boots != null || pants != null || chest != null || head != null;
    }

    public static boolean containsID(int id) {
        return blockIDs.contains(id);
    }

    public static Minecraft mc() {
        return Minecraft.getMinecraft();
    }

    public static EntityPlayerSP player() {
        Helper.mc();
        return Minecraft.thePlayer;
    }

    public static WorldClient world() {
        Helper.mc();
        return Minecraft.theWorld;
    }

    public static boolean onServer(String server) {
        return !mc.isSingleplayer() && Helper.mc.getCurrentServerData().serverIP.toLowerCase().contains(server);
    }
}

