/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.util.glu.GLU
 */
package cn.M1N3S3NS3.Util.Render;

import cn.M1N3S3NS3.Util.Render.LockedResolution;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GLAllocation;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

public final class OGLUtils {
    private static final FloatBuffer windowPosition = GLAllocation.createDirectFloatBuffer(4);
    private static final IntBuffer viewport = GLAllocation.createDirectIntBuffer(16);
    private static final FloatBuffer modelMatrix = GLAllocation.createDirectFloatBuffer(16);
    private static final FloatBuffer projectionMatrix = GLAllocation.createDirectFloatBuffer(16);
    private static final float[] BUFFER = new float[3];

    private OGLUtils() {
    }

    public static void enableBlending() {
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
    }

    public static void disableTexture2D() {
        GL11.glDisable((int)3553);
    }

    public static void enableTexture2D() {
        GL11.glEnable((int)3553);
    }

    public static void enableDepth() {
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2929);
    }

    public static void disableDepth() {
        GL11.glDepthMask((boolean)false);
        GL11.glDisable((int)2929);
    }

    public static void preDraw(int color, int mode2) {
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        OGLUtils.color(color);
        GL11.glBegin((int)mode2);
    }

    public static void postDraw() {
        GL11.glEnd();
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3553);
    }

    public static void color(int color) {
        GL11.glColor4ub((byte)((byte)(color >> 16 & 0xFF)), (byte)((byte)(color >> 8 & 0xFF)), (byte)((byte)(color & 0xFF)), (byte)((byte)(color >> 24 & 0xFF)));
    }

    public static void disableBlending() {
        GL11.glDisable((int)3042);
    }

    public static void startScissorBox(ScaledResolution sr, int x, int y, int width, int height) {
        int sf = sr.getScaleFactor();
        GL11.glScissor((int)(x * sf), (int)((ScaledResolution.getScaledHeight() - (y + height)) * sf), (int)(width * sf), (int)(height * sf));
    }

    public static void startScissorBox(LockedResolution lr, int x, int y, int width, int height) {
        GL11.glScissor((int)(x * 2), (int)((lr.getHeight() - (y + height)) * 2), (int)(width * 2), (int)(height * 2));
    }

    public static float[] project2D(float x, float y, float z, int scaleFactor) {
        GL11.glGetFloat((int)2982, (FloatBuffer)modelMatrix);
        GL11.glGetFloat((int)2983, (FloatBuffer)projectionMatrix);
        GL11.glGetInteger((int)2978, (IntBuffer)viewport);
        if (GLU.gluProject((float)x, (float)y, (float)z, (FloatBuffer)modelMatrix, (FloatBuffer)projectionMatrix, (IntBuffer)viewport, (FloatBuffer)windowPosition)) {
            OGLUtils.BUFFER[0] = windowPosition.get(0) / (float)scaleFactor;
            OGLUtils.BUFFER[1] = ((float)Display.getHeight() - windowPosition.get(1)) / (float)scaleFactor;
            OGLUtils.BUFFER[2] = windowPosition.get(2);
            return BUFFER;
        }
        return null;
    }
}

