/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Render;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.IChatComponent;

public class FKCounter {
    private static final String RED_WITHER_DEATH = "The Red Wither has died!";
    private static final String GREEN_WITHER_DEATH = "The Green Wither has died!";
    private static final String YELLOW_WITHER_DEATH = "The Yellow Wither has died!";
    private static final String BLUE_WITHER_DEATH = "The Blue Wither has died!";
    private static final String OWN_WITHER_DEATH = "Your wither has died. You can no longer respawn!";
    private static final String DEATHMATCH = "All withers are dead! 10 seconds till deathmatch!";
    private static final String PREP_PHASE = "Prepare your defenses!";
    private static final String[] KILL_MESSAGES = new String[]{"(\\w+) was shot and killed by (\\w+).*", "(\\w+) was snowballed to death by (\\w+).*", "(\\w+) was killed by (\\w+).*", "(\\w+) was killed with a potion by (\\w+).*", "(\\w+) was killed with an explosion by (\\w+).*", "(\\w+) was killed with magic by (\\w+).*", "(\\w+) was filled full of lead by (\\w+).*", "(\\w+) was iced by (\\w+).*", "(\\w+) met their end by (\\w+).*", "(\\w+) lost a drinking contest with (\\w+).*", "(\\w+) was killed with dynamite by (\\w+).*", "(\\w+) lost the draw to (\\w+).*", "(\\w+) was struck down by (\\w+).*", "(\\w+) was turned to dust by (\\w+).*", "(\\w+) was turned to ash by (\\w+).*", "(\\w+) was melted by (\\w+).*", "(\\w+) was incinerated by (\\w+).*", "(\\w+) was vaporized by (\\w+).*", "(\\w+) was struck with Cupid's arrow by (\\w+).*", "(\\w+) was given the cold shoulder by (\\w+).*", "(\\w+) was hugged too hard by (\\w+).*", "(\\w+) drank a love potion from (\\w+).*", "(\\w+) was hit by a love bomb from (\\w+).*", "(\\w+) was no match for (\\w+).*", "(\\w+) was smote from afar by (\\w+).*", "(\\w+) was justly ended by (\\w+).*", "(\\w+) was purified by (\\w+).*", "(\\w+) was killed with holy water by (\\w+).*", "(\\w+) was dealt vengeful justice by (\\w+).*", "(\\w+) was returned to dust by (\\w+).*", "(\\w+) be shot and killed by (\\w+).*", "(\\w+) be snowballed to death by (\\w+).*", "(\\w+) be sent to Davy Jones' locker by (\\w+).*", "(\\w+) be killed with rum by (\\w+).*", "(\\w+) be shot with cannon by (\\w+).*", "(\\w+) be killed with magic by (\\w+).*", "(\\w+) was glazed in BBQ sauce by (\\w+).*", "(\\w+) was sprinked in chilli poweder by (\\w+).*", "(\\w+) was sliced up by (\\w+).*", "(\\w+) was overcooked by (\\w+).*", "(\\w+) was deep fried by (\\w+).*", "(\\w+) was boiled by (\\w+).*", "(\\w+) was injected with malware by (\\w+).*", "(\\w+) was DDoS'd by (\\w+).*", "(\\w+) was deleted by (\\w+).*", "(\\w+) was purged by an antivirus owned by (\\w+).*", "(\\w+) was fragmented by (\\w+).*", "(\\w+) was corrupted by (\\w+).*"};
    private static final int TEAMS = 4;
    public static final int RED_TEAM = 0;
    public static final int GREEN_TEAM = 1;
    public static final int YELLOW_TEAM = 2;
    public static final int BLUE_TEAM = 3;
    private static final String[] SCOREBOARD_PREFIXES = new String[]{"[R]", "[G]", "[Y]", "[B]"};
    private static final String[] DEFAULT_PREFIXES = new String[]{"c", "a", "e", "9"};
    private boolean[] deadWithers = new boolean[4];
    private String[] prefixes = new String[4];
    private HashMap<String, Integer>[] teamKills = new HashMap[4];
    private ArrayList<String> deadPlayers = new ArrayList();

    public FKCounter() {
        int team = 0;
        while (team < 4) {
            this.prefixes[team] = DEFAULT_PREFIXES[team];
            this.teamKills[team] = new HashMap();
            ++team;
        }
    }

    public void onChatMessage(IChatComponent event) {
        String rawMessage = event.getUnformattedText();
        String colorMessage = event.getFormattedText();
        if (rawMessage.equals(PREP_PHASE)) {
            this.setTeamPrefixes();
        }
        switch (rawMessage) {
            case "The Red Wither has died!": {
                this.deadWithers[0] = true;
                return;
            }
            case "The Green Wither has died!": {
                this.deadWithers[1] = true;
                return;
            }
            case "The Yellow Wither has died!": {
                this.deadWithers[2] = true;
                return;
            }
            case "The Blue Wither has died!": {
                this.deadWithers[3] = true;
                return;
            }
            case "Your wither has died. You can no longer respawn!": {
                Minecraft.getMinecraft();
                String teamColor = Minecraft.theWorld.getScoreboard().getObjectiveInDisplaySlot(1).getDisplayName().split("\u00a7")[1].substring(0, 1);
                this.setWitherDead(teamColor);
                return;
            }
            case "All withers are dead! 10 seconds till deathmatch!": {
                int team = 0;
                while (team < 4) {
                    this.deadWithers[team] = true;
                    ++team;
                }
                return;
            }
        }
        String[] stringArray = KILL_MESSAGES;
        int n = KILL_MESSAGES.length;
        int n2 = 0;
        while (n2 < n) {
            String p = stringArray[n2];
            Matcher killMessageMatcher = Pattern.compile(p).matcher(rawMessage);
            if (killMessageMatcher.matches()) {
                String killed = killMessageMatcher.group(1);
                String killer = killMessageMatcher.group(2);
                String killedTeam = colorMessage.split("\u00a7")[2].substring(0, 1);
                String killerTeam = colorMessage.split("\u00a7")[8].substring(0, 1);
                this.removeKilledPlayer(killed, killedTeam);
                if (!this.getWitherDead(killedTeam)) break;
                this.addKill(killer, killerTeam);
                break;
            }
            ++n2;
        }
    }

    public int getKills(int team) {
        if (!this.isValidTeam(team)) {
            return 0;
        }
        int kills = 0;
        for (int k : this.teamKills[team].values()) {
            kills += k;
        }
        return kills;
    }

    public HashMap<String, Integer> getPlayers(int team) {
        if (!this.isValidTeam(team)) {
            return new HashMap<String, Integer>();
        }
        return this.teamKills[team];
    }

    private void setWitherDead(String color) {
        int team = this.getTeamFromColor(color);
        if (this.isValidTeam(team)) {
            this.deadWithers[team] = true;
        }
    }

    private boolean getWitherDead(String color) {
        int team = this.getTeamFromColor(color);
        if (!this.isValidTeam(team)) {
            return false;
        }
        return this.deadWithers[team];
    }

    private void setTeamPrefixes() {
        for (String line : FKCounter.getScoreboardNames()) {
            int team = 0;
            while (team < 4) {
                if (line.contains(SCOREBOARD_PREFIXES[team])) {
                    this.prefixes[team] = line.split("\u00a7")[1].substring(0, 1);
                }
                ++team;
            }
        }
    }

    private void removeKilledPlayer(String player, String color) {
        int team = this.getTeamFromColor(color);
        if (!this.isValidTeam(team)) {
            return;
        }
        if (this.deadWithers[team]) {
            this.teamKills[team].remove(player);
            this.deadPlayers.add(player);
        }
    }

    private void addKill(String player, String color) {
        int team = this.getTeamFromColor(color);
        if (!this.isValidTeam(team)) {
            return;
        }
        if (this.deadPlayers.contains(player)) {
            return;
        }
        if (this.teamKills[team].containsKey(player)) {
            this.teamKills[team].put(player, this.teamKills[team].get(player) + 1);
        } else {
            this.teamKills[team].put(player, 1);
        }
        this.sortTeamKills(team);
    }

    private void sortTeamKills(int team) {
        if (!this.isValidTeam(team)) {
            return;
        }
        this.teamKills[team] = this.teamKills[team].entrySet().stream().sorted(Map.Entry.comparingByValue().reversed()).collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
    }

    private int getTeamFromColor(String color) {
        int team = 0;
        while (team < 4) {
            if (this.prefixes[team].equalsIgnoreCase(color)) {
                return team;
            }
            ++team;
        }
        return -1;
    }

    private boolean isValidTeam(int team) {
        return team >= 0 && team < 4;
    }

    private static ArrayList<String> getScoreboardNames() {
        ArrayList<String> scoreboardNames = new ArrayList<String>();
        try {
            Minecraft.getMinecraft();
            Scoreboard scoreboard = Minecraft.theWorld.getScoreboard();
            ScoreObjective sidebarObjective = scoreboard.getObjectiveInDisplaySlot(1);
            Collection<Score> scores = scoreboard.getSortedScores(sidebarObjective);
            for (Score score : scores) {
                ScorePlayerTeam team = scoreboard.getPlayersTeam(score.getPlayerName());
                scoreboardNames.add(ScorePlayerTeam.formatPlayerName(team, score.getPlayerName()));
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return scoreboardNames;
    }
}

