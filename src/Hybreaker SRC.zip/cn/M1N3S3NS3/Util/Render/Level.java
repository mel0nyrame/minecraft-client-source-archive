/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Render;

public enum Level {
    INFO("Info:"),
    WARNING("Warning:"),
    ERROR("ERROR:"),
    NONE("");

    private String header;

    private Level(String s) {
        this.header = s;
    }

    public String getHeader() {
        return this.header;
    }
}

