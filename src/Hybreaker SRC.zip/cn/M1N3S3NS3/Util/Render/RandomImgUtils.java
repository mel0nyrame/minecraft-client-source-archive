/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Render;

import java.util.Random;
import net.minecraft.util.ResourceLocation;

public class RandomImgUtils {
    private static long startTime = 0L;
    static Random random = new Random();
    static int count = random.nextInt(4);
    public static int count2 = random.nextInt(4);

    public static ResourceLocation getBackGround() {
        return new ResourceLocation("ZenithAssets/BACKGROUND/" + count + ".png");
    }

    public static ResourceLocation getGirl() {
        if (startTime == 0L) {
            startTime = System.currentTimeMillis();
        }
        if (startTime + 20000L <= System.currentTimeMillis()) {
            count2 = random.nextInt(4);
            startTime = System.currentTimeMillis();
        }
        return new ResourceLocation("ZenithAssets/Girls/" + count2 + ".png");
    }
}

