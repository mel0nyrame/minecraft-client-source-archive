/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Render;

public class AnimationUtil {
    private static float defaultSpeed = 0.125f;
    private static double slowSpeed;

    public static float mvoeUD(float current, float end, float minSpeed) {
        return AnimationUtil.moveUD(current, end, defaultSpeed, minSpeed);
    }

    public static float moveUD(float current, float end, float smoothSpeed, float minSpeed) {
        float movement = (end - current) * smoothSpeed;
        if (movement > 0.0f) {
            movement = Math.max(minSpeed, movement);
            movement = Math.min(end - current, movement);
        } else if (movement < 0.0f) {
            movement = Math.min(-minSpeed, movement);
            movement = Math.max(end - current, movement);
        }
        return current + movement;
    }

    public static double Ease(double start, double end, double speed) {
        double addspeed = speed * 0.01;
        double slow = end / 4.0 * 1.0;
        double fast = end / 4.0 * 2.0;
        double slow2 = end / 4.0 * 3.0;
        if (start < slow) {
            addspeed = speed * 0.01;
        }
        if (start > slow && start < fast) {
            addspeed = speed * 0.1;
        }
        if (start > slow2 && start < end) {
            addspeed = speed * 0.01;
        }
        if (start < end) {
            start += addspeed;
        }
        if (start > end) {
            start -= addspeed;
        }
        return start;
    }

    public static double Easeout() {
        return 0.0;
    }

    public static double Easein() {
        return 0.0;
    }

    public static float calculateCompensation(float target, float current, long delta, int speed) {
        float diff = current - target;
        if (delta < 1L) {
            delta = 1L;
        }
        if (diff > (float)speed) {
            double xD = (double)((long)speed * delta / 16L) < 0.25 ? 0.5 : (double)((long)speed * delta / 16L);
            if ((current = (float)((double)current - xD)) < target) {
                current = target;
            }
        } else if (diff < (float)(-speed)) {
            double xD = (double)((long)speed * delta / 16L) < 0.25 ? 0.5 : (double)((long)speed * delta / 16L);
            if ((current = (float)((double)current + xD)) > target) {
                current = target;
            }
        } else {
            current = target;
        }
        return current;
    }

    public static float calculateCompensation(float target, float current, long delta, double speed) {
        float diff = current - target;
        if (delta < 1L) {
            delta = 1L;
        }
        if (delta > 1000L) {
            delta = 16L;
        }
        if ((double)diff > speed) {
            double xD = speed * (double)delta / 16.0 < 0.5 ? 0.5 : speed * (double)delta / 16.0;
            if ((current = (float)((double)current - xD)) < target) {
                current = target;
            }
        } else if ((double)diff < -speed) {
            double xD = speed * (double)delta / 16.0 < 0.5 ? 0.5 : speed * (double)delta / 16.0;
            if ((current = (float)((double)current + xD)) > target) {
                current = target;
            }
        } else {
            current = target;
        }
        return current;
    }
}

