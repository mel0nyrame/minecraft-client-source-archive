/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Render;

public class Animationutils {
    private static float defaultSpeed = 0.125f;

    public static float mvoeUD(float current, float end, float minSpeed) {
        return Animationutils.moveUD(current, end, defaultSpeed, minSpeed);
    }

    public static float moveUD(float current, float end, float smoothSpeed, float minSpeed) {
        float movement = (end - current) * smoothSpeed;
        if (movement > 0.0f) {
            movement = Math.max(minSpeed, movement);
            movement = Math.min(end - current, movement);
        } else if (movement < 0.0f) {
            movement = Math.min(-minSpeed, movement);
            movement = Math.max(end - current, movement);
        }
        return current + movement;
    }

    public static double animate(double target, double current, double speed) {
        boolean bl = target > current;
        boolean larger = bl;
        if (speed < 0.0) {
            speed = 0.0;
        } else if (speed > 1.0) {
            speed = 1.0;
        }
        double dif = Math.max(target, current) - Math.min(target, current);
        double factor = dif * speed;
        if (factor < 0.1) {
            factor = 0.1;
        }
        current = larger ? current + factor : current - factor;
        current = current;
        return current;
    }
}

