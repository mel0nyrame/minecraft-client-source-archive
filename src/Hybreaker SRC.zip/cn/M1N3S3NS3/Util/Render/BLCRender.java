/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Util.Render;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;

public class BLCRender {
    private static final Frustum frustum = new Frustum();

    public static double interpolate(double newPos, double oldPos) {
        return oldPos + (newPos - oldPos) * (double)Minecraft.getMinecraft().timer.renderPartialTicks;
    }

    public static boolean isInFrustumView(Entity ent) {
        Entity current = Minecraft.getMinecraft().getRenderViewEntity();
        double x = BLCRender.interpolate(current.posX, current.lastTickPosX);
        double y = BLCRender.interpolate(current.posY, current.lastTickPosY);
        double z = BLCRender.interpolate(current.posZ, current.lastTickPosZ);
        frustum.setPosition(x, y, z);
        return frustum.isBoundingBoxInFrustum(ent.getEntityBoundingBox()) || ent.ignoreFrustumCheck;
    }

    public static void pre() {
        GL11.glDisable((int)2929);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
    }

    public static void post() {
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glColor3d((double)1.0, (double)1.0, (double)1.0);
    }

    public static int getHexRGB(int hex) {
        return 0xFF000000 | hex;
    }

    public static void drawBordered1(double x, double y, double width, double height, double length, int innerColor, int outerColor) {
        Gui.drawRect(x, y, x + width, y + height, innerColor);
        Gui.drawRect(x, y, x, y, outerColor);
    }

    public static int withTransparency(int rgb, float alpha) {
        float r = (float)(rgb >> 16 & 0xFF) / 255.0f;
        float g = (float)(rgb >> 8 & 0xFF) / 255.0f;
        float b = (float)(rgb >> 0 & 0xFF) / 255.0f;
        return new Color(r, g, b, alpha).getRGB();
    }

    public static void drawRect(int x, int y, int x1, int y1, int color) {
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        Gui.drawRect((double)x, (double)y, (double)x1, (double)y1, color);
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static void drawRect(double x1, double y1, double x2, double y2, int color) {
        Gui.drawRect(x1, y1, x2, y2, color);
    }

    public static void drawBorderRect2(double left, double top, double right, double bottom, int bwidth, int icolor, int bcolor) {
        Gui.drawRect(left + (double)bwidth, top + (double)bwidth, right - (double)bwidth, bottom - (double)bwidth, icolor);
        Gui.drawRect(left, top, left + (double)bwidth, bottom, bcolor);
        Gui.drawRect(left + (double)bwidth, top, right, top + (double)bwidth, bcolor);
        Gui.drawRect(left + (double)bwidth, bottom - (double)bwidth, right, bottom, bcolor);
        Gui.drawRect(right - (double)bwidth, top + (double)bwidth, right, bottom - (double)bwidth, bcolor);
    }

    public static void rectangleBordered(double x, double y, double x1, double y1, double width, int internalColor, int borderColor) {
        BLCRender.drawRect(x + width, y + width, x1 - width, y1 - width, internalColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        BLCRender.drawRect(x + width, y, x1 - width, y + width, borderColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        BLCRender.drawRect(x, y, x + width, y1, borderColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        BLCRender.drawRect(x1 - width, y, x1, y1, borderColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        BLCRender.drawRect(x + width, y1 - width, x1 - width, y1, borderColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }

    public static Vec3 interpolateRender(EntityPlayer player) {
        float part = Minecraft.getMinecraft().timer.renderPartialTicks;
        double interpX = player.lastTickPosX + (player.posX - player.lastTickPosX) * (double)part;
        double interpY = player.lastTickPosY + (player.posY - player.lastTickPosY) * (double)part;
        double interpZ = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * (double)part;
        return new Vec3(interpX, interpY, interpZ);
    }
}

