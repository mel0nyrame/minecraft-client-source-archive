/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Render.gl;

public interface GLenum {
    public String getName();

    public int getCap();
}

