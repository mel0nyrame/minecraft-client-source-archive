/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  org.lwjgl.opengl.ARBShaderObjects
 *  org.lwjgl.opengl.EXTFramebufferObject
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Util.Render;

import com.mojang.authlib.GameProfile;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.GL11;

public class Class246 {
    public static float delta;

    public static void pre() {
        GL11.glDisable((int)2929);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
    }

    public static void post() {
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glColor3d((double)1.0, (double)1.0, (double)1.0);
    }

    public static void drawArc(float var0, float var1, double var2, int var4, int var5, double var6, int var8) {
        var2 *= 2.0;
        var0 *= 2.0f;
        var1 *= 2.0f;
        float var9 = (float)(var4 >> 24 & 0xFF) / 255.0f;
        float var10 = (float)(var4 >> 16 & 0xFF) / 255.0f;
        float var11 = (float)(var4 >> 8 & 0xFF) / 255.0f;
        float var12 = (float)(var4 & 0xFF) / 255.0f;
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
        GL11.glLineWidth((float)var8);
        GL11.glEnable((int)2848);
        GL11.glColor4f((float)var10, (float)var11, (float)var12, (float)var9);
        GL11.glBegin((int)3);
        int var13 = var5;
        while ((double)var13 <= var6) {
            double var14 = Math.sin((double)var13 * Math.PI / 180.0) * var2;
            double var16 = Math.cos((double)var13 * Math.PI / 180.0) * var2;
            GL11.glVertex2d((double)((double)var0 + var14), (double)((double)var1 + var16));
            ++var13;
        }
        GL11.glEnd();
        GL11.glDisable((int)2848);
        GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static int rainbow(int var0) {
        double var1 = Math.ceil((double)(System.currentTimeMillis() + (long)var0) / 20.0);
        return Color.getHSBColor((float)((var1 %= 360.0) / 360.0), 0.8f, 0.7f).brighter().getRGB();
    }

    public static Color rainbowEffect(int var0) {
        float var1 = (float)(System.nanoTime() + (long)var0) / 2.0E10f % 1.0f;
        Color var2 = new Color((int)Long.parseLong(Integer.toHexString(Color.HSBtoRGB(var1, 1.0f, 1.0f)), 16));
        return new Color((float)var2.getRed() / 255.0f, (float)var2.getGreen() / 255.0f, (float)var2.getBlue() / 255.0f, (float)var2.getAlpha() / 255.0f);
    }

    public static void drawFullscreenImage(ResourceLocation var0) {
        ScaledResolution var1 = new ScaledResolution(Minecraft.getMinecraft());
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glDisable((int)3008);
        Minecraft.getMinecraft();
        Minecraft.getTextureManager().bindTexture(var0);
        Gui.drawModalRectWithCustomSizedTexture(0, 0, 0.0f, 0.0f, ScaledResolution.getScaledWidth(), ScaledResolution.getScaledHeight(), (float)ScaledResolution.getScaledWidth(), (float)ScaledResolution.getScaledHeight());
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2929);
        GL11.glEnable((int)3008);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public static void drawPlayerHead(String var0, int var1, int var2, int var3, int var4) {
        Minecraft.getMinecraft();
        for (EntityPlayer var6 : Minecraft.theWorld.playerEntities) {
            if (!var0.equalsIgnoreCase(var6.getName())) continue;
            GameProfile var7 = new GameProfile(var6.getUniqueID(), var6.getName());
            NetworkPlayerInfo var8 = new NetworkPlayerInfo(var7);
            new ScaledResolution(Minecraft.getMinecraft());
            GL11.glDisable((int)2929);
            GL11.glEnable((int)3042);
            GL11.glDepthMask((boolean)false);
            OpenGlHelper.glBlendFunc(770, 771, 1, 0);
            GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            Minecraft.getMinecraft();
            Minecraft.getTextureManager().bindTexture(var8.getLocationSkin());
            Gui.drawModalRectWithCustomSizedTexture(var1, var2, 0.0f, 0.0f, var3, var4, (float)var3, (float)var4);
            GL11.glDepthMask((boolean)true);
            GL11.glDisable((int)3042);
            GL11.glEnable((int)2929);
        }
    }

    public static double getAnimationState(double var0, double var2, double var4) {
        float var6 = (float)((double)delta * var4);
        var0 = var0 < var2 ? (var0 + (double)var6 < var2 ? (var0 += (double)var6) : var2) : (var0 - (double)var6 > var2 ? (var0 -= (double)var6) : var2);
        return var0;
    }

    public static void drawLoadingCircle() {
        float var0 = (float)((double)System.currentTimeMillis() * 0.1 % 400.0);
        float var1 = 0.5f;
        ScaledResolution var2 = new ScaledResolution(Minecraft.getMinecraft());
        float var3 = (float)ScaledResolution.getScaledWidth() / 16.0f;
        Class246.drawCircle((float)ScaledResolution.getScaledWidth() / 2.0f, (float)ScaledResolution.getScaledHeight() / 2.0f, var3, new Color(-8418163), 5.0f, 0.0f, 1.0f);
        Class246.drawCircle((float)ScaledResolution.getScaledWidth() / 2.0f, (float)ScaledResolution.getScaledHeight() / 2.0f, var3, new Color(-13330213), 7.0f, var0, var1);
    }

    public static void drawCircle(int var0, int var1, int var2, Color var3) {
        int var4 = 70;
        double var5 = Math.PI * 2 / (double)var4;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glShadeModel((int)7425);
        GL11.glBegin((int)2);
        int var7 = 0;
        while (var7 < var4) {
            float var8 = (float)((double)var2 * Math.cos((double)var7 * var5));
            float var9 = (float)((double)var2 * Math.sin((double)var7 * var5));
            GL11.glColor4f((float)((float)var3.getRed() / 255.0f), (float)((float)var3.getGreen() / 255.0f), (float)((float)var3.getBlue() / 255.0f), (float)((float)var3.getAlpha() / 255.0f));
            GL11.glVertex2f((float)((float)var0 + var8), (float)((float)var1 + var9));
            ++var7;
        }
        GlStateManager.color(0.0f, 0.0f, 0.0f);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawCircle(float var0, float var1, float var2, Color var3) {
        int var4 = 70;
        double var5 = Math.PI * 2 / (double)var4;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)1.0f);
        GL11.glShadeModel((int)7425);
        GL11.glBegin((int)2);
        int var7 = 0;
        while (var7 < var4) {
            float var8 = (float)((double)var2 * Math.cos((double)var7 * var5));
            float var9 = (float)((double)var2 * Math.sin((double)var7 * var5));
            GL11.glColor4f((float)((float)var3.getRed() / 255.0f), (float)((float)var3.getGreen() / 255.0f), (float)((float)var3.getBlue() / 255.0f), (float)((float)var3.getAlpha() / 255.0f));
            GL11.glVertex2f((float)(var0 + var8), (float)(var1 + var9));
            ++var7;
        }
        GlStateManager.color(0.0f, 0.0f, 0.0f);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawCircle(float var0, float var1, float var2, Color var3, float var4, float var5, float var6) {
        int var7 = 100;
        double var8 = (double)(var6 * 2.0f) * Math.PI / (double)var7;
        float var10 = 0.0f;
        float var11 = 0.0f;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)var4);
        GL11.glShadeModel((int)7425);
        GL11.glBegin((int)2);
        int var12 = (int)var5;
        while ((float)var12 < var5 + (float)var7) {
            var10 = (float)((double)var2 * Math.cos((double)var12 * var8));
            var11 = (float)((double)var2 * Math.sin((double)var12 * var8));
            GL11.glColor4f((float)((float)var3.getRed() / 255.0f), (float)((float)var3.getGreen() / 255.0f), (float)((float)var3.getBlue() / 255.0f), (float)((float)var3.getAlpha() / 255.0f));
            GL11.glVertex2f((float)(var0 + var10), (float)(var1 + var11));
            ++var12;
        }
        var12 = (int)(var5 + (float)var7);
        while (var12 > (int)var5) {
            var10 = (float)((double)var2 * Math.cos((double)var12 * var8));
            var11 = (float)((double)var2 * Math.sin((double)var12 * var8));
            GL11.glColor4f((float)((float)var3.getRed() / 255.0f), (float)((float)var3.getGreen() / 255.0f), (float)((float)var3.getBlue() / 255.0f), (float)((float)var3.getAlpha() / 255.0f));
            GL11.glVertex2f((float)(var0 + var10), (float)(var1 + var11));
            --var12;
        }
        GlStateManager.color(0.0f, 0.0f, 0.0f);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawFilledCircle(int var0, int var1, float var2, Color var3) {
        int var4 = 100;
        double var5 = Math.PI * 2 / (double)var4;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glBegin((int)6);
        int var7 = 0;
        while (var7 < var4) {
            float var8 = (float)((double)var2 * Math.sin((double)var7 * var5));
            float var9 = (float)((double)var2 * Math.cos((double)var7 * var5));
            GL11.glColor4f((float)((float)var3.getRed() / 255.0f), (float)((float)var3.getGreen() / 255.0f), (float)((float)var3.getBlue() / 255.0f), (float)((float)var3.getAlpha() / 255.0f));
            GL11.glVertex2f((float)((float)var0 + var8), (float)((float)var1 + var9));
            ++var7;
        }
        GlStateManager.color(0.0f, 0.0f, 0.0f);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawFilledCircle(float var0, float var1, float var2, Color var3) {
        int var4 = 50;
        double var5 = Math.PI * 2 / (double)var4;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glBegin((int)6);
        int var7 = 0;
        while (var7 < var4) {
            float var8 = (float)((double)var2 * Math.sin((double)var7 * var5));
            float var9 = (float)((double)var2 * Math.cos((double)var7 * var5));
            GL11.glColor4f((float)((float)var3.getRed() / 255.0f), (float)((float)var3.getGreen() / 255.0f), (float)((float)var3.getBlue() / 255.0f), (float)((float)var3.getAlpha() / 255.0f));
            GL11.glVertex2f((float)(var0 + var8), (float)(var1 + var9));
            ++var7;
        }
        GlStateManager.color(0.0f, 0.0f, 0.0f);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawFilledCircle(int var0, int var1, float var2, int var3) {
        float var4 = (float)(var3 >> 24 & 0xFF) / 255.0f;
        float var5 = (float)(var3 >> 16 & 0xFF) / 255.0f;
        float var6 = (float)(var3 >> 8 & 0xFF) / 255.0f;
        float var7 = (float)(var3 & 0xFF) / 255.0f;
        int var8 = 50;
        double var9 = Math.PI * 2 / (double)var8;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)2848);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glBegin((int)6);
        int var11 = 0;
        while (var11 < var8) {
            float var12 = (float)((double)var2 * Math.sin((double)var11 * var9));
            float var13 = (float)((double)var2 * Math.cos((double)var11 * var9));
            GL11.glColor4f((float)var5, (float)var6, (float)var7, (float)var4);
            GL11.glVertex2f((float)((float)var0 + var12), (float)((float)var1 + var13));
            ++var11;
        }
        GlStateManager.color(0.0f, 0.0f, 0.0f);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawFilledCircle(float var0, float var1, float var2, int var3) {
        float var4 = (float)(var3 >> 24 & 0xFF) / 255.0f;
        float var5 = (float)(var3 >> 16 & 0xFF) / 255.0f;
        float var6 = (float)(var3 >> 8 & 0xFF) / 255.0f;
        float var7 = (float)(var3 & 0xFF) / 255.0f;
        int var8 = 50;
        double var9 = Math.PI * 2 / (double)var8;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glBegin((int)6);
        int var11 = 0;
        while (var11 < var8) {
            float var12 = (float)((double)var2 * Math.sin((double)var11 * var9));
            float var13 = (float)((double)var2 * Math.cos((double)var11 * var9));
            GL11.glColor4f((float)var5, (float)var6, (float)var7, (float)var4);
            GL11.glVertex2f((float)(var0 + var12), (float)(var1 + var13));
            ++var11;
        }
        GlStateManager.color(0.0f, 0.0f, 0.0f);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawFilledCircle(int var0, int var1, float var2, int var3, int var4, int var5, int var6, int var7) {
        float var8 = (float)(var3 >> 24 & 0xFF) / 255.0f;
        float var9 = (float)(var3 >> 16 & 0xFF) / 255.0f;
        float var10 = (float)(var3 >> 8 & 0xFF) / 255.0f;
        float var11 = (float)(var3 & 0xFF) / 255.0f;
        int var12 = 50;
        double var13 = Math.PI * 2 / (double)var12;
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glBegin((int)6);
        int var15 = 0;
        while (var15 < var12) {
            float var16 = (float)((double)var2 * Math.sin((double)var15 * var13));
            float var17 = (float)((double)var2 * Math.cos((double)var15 * var13));
            float var18 = (float)var0 + var16;
            float var19 = (float)var1 + var17;
            if (var18 < (float)var4) {
                var18 = var4;
            }
            if (var18 > (float)var6) {
                var18 = var6;
            }
            if (var19 < (float)var5) {
                var19 = var5;
            }
            if (var19 > (float)var7) {
                var19 = var7;
            }
            GL11.glColor4f((float)var9, (float)var10, (float)var11, (float)var8);
            GL11.glVertex2f((float)var18, (float)var19);
            ++var15;
        }
        GlStateManager.color(0.0f, 0.0f, 0.0f);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void drawLine(float var0, float var1, float var2, float var3, Color var4) {
        Tessellator var5 = Tessellator.getInstance();
        WorldRenderer var6 = var5.getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GL11.glEnable((int)2848);
        GL11.glLineWidth((float)1.0f);
        GlStateManager.color((float)var4.getRed() / 255.0f, (float)var4.getGreen() / 255.0f, (float)var4.getBlue() / 255.0f, (float)var4.getAlpha() / 255.0f);
        var6.begin(1, DefaultVertexFormats.POSITION);
        var6.pos(var0, var1, 0.0).endVertex();
        var6.pos(var2, var3, 0.0).endVertex();
        var5.draw();
        GL11.glDisable((int)2848);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static String getShaderCode(InputStreamReader var0) {
        String var1 = "";
        try {
            String var2;
            BufferedReader var3 = new BufferedReader(var0);
            while ((var2 = var3.readLine()) != null) {
                var1 = String.valueOf(var1) + var2 + "\n";
            }
            var3.close();
        }
        catch (IOException var4) {
            var4.printStackTrace();
            System.exit(-1);
        }
        return var1.toString();
    }

    public static void drawImage(ResourceLocation var0, int var1, int var2, int var3, int var4) {
        Class246.drawImage(var0, var1, var2, var3, var4, 1.0f);
    }

    public static void drawImage(ResourceLocation var0, float var1, float var2, float var3, float var4) {
        Class246.drawImage(var0, (int)var1, (int)var2, (int)var3, (int)var4, 1.0f);
    }

    public static void drawImage(ResourceLocation var0, int var1, int var2, int var3, int var4, float var5) {
        new ScaledResolution(Minecraft.getMinecraft());
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)var5);
        Minecraft.getMinecraft();
        Minecraft.getTextureManager().bindTexture(var0);
        Gui.drawModalRectWithCustomSizedTexture(var1, var2, 0.0f, 0.0f, var3, var4, (float)var3, (float)var4);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
    }

    public static void drawOutlinedRect(int var0, int var1, int var2, int var3, int var4, Color var5, Color var6) {
        Class246.drawRect(var0, var1, var2, var3, var6.getRGB());
        Class246.drawRect(var0, var1, var2, var1 + var4, var5.getRGB());
        Class246.drawRect(var0, var3 - var4, var2, var3, var5.getRGB());
        Class246.drawRect(var0, var1 + var4, var0 + var4, var3 - var4, var5.getRGB());
        Class246.drawRect(var2 - var4, var1 + var4, var2, var3 - var4, var5.getRGB());
    }

    public static void drawOutlinedRect(float var0, float var1, float var2, float var3, float var4, int var5, int var6) {
        Class246.drawRect(var0, var1, var2, var3, var6);
        Class246.drawRect(var0, var1, var2, var1 + var4, var5);
        Class246.drawRect(var0, var3 - var4, var2, var3, var5);
        Class246.drawRect(var0, var1 + var4, var0 + var4, var3 - var4, var5);
        Class246.drawRect(var2 - var4, var1 + var4, var2, var3 - var4, var5);
    }

    public static void drawImage(ResourceLocation var0, int var1, int var2, int var3, int var4, Color var5) {
        new ScaledResolution(Minecraft.getMinecraft());
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GL11.glColor4f((float)((float)var5.getRed() / 255.0f), (float)((float)var5.getBlue() / 255.0f), (float)((float)var5.getRed() / 255.0f), (float)1.0f);
        Minecraft.getMinecraft();
        Minecraft.getTextureManager().bindTexture(var0);
        Gui.drawModalRectWithCustomSizedTexture(var1, var2, 0.0f, 0.0f, var3, var4, (float)var3, (float)var4);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
    }

    public static void doGlScissor(int var0, int var1, int var2, int var3) {
        Minecraft var4 = Minecraft.getMinecraft();
        int var5 = 1;
        int var6 = var4.gameSettings.guiScale;
        if (var6 == 0) {
            var6 = 1000;
        }
        while (var5 < var6 && var4.displayWidth / (var5 + 1) >= 320 && var4.displayHeight / (var5 + 1) >= 240) {
            ++var5;
        }
        GL11.glScissor((int)(var0 * var5), (int)(var4.displayHeight - (var1 + var3) * var5), (int)(var2 * var5), (int)(var3 * var5));
    }

    public static void drawRect(float var0, float var1, float var2, float var3, int var4) {
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glPushMatrix();
        Class246.color(var4);
        GL11.glBegin((int)7);
        GL11.glVertex2d((double)var2, (double)var1);
        GL11.glVertex2d((double)var0, (double)var1);
        GL11.glVertex2d((double)var0, (double)var3);
        GL11.glVertex2d((double)var2, (double)var3);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
        GL11.glPopMatrix();
    }

    public static void color(int var0) {
        float var1 = (float)(var0 >> 24 & 0xFF) / 255.0f;
        float var2 = (float)(var0 >> 16 & 0xFF) / 255.0f;
        float var3 = (float)(var0 >> 8 & 0xFF) / 255.0f;
        float var4 = (float)(var0 & 0xFF) / 255.0f;
        GL11.glColor4f((float)var2, (float)var3, (float)var4, (float)var1);
    }

    public static int createShader(String var0, int var1) throws Exception {
        int var5;
        int var2 = 0;
        try {
            var5 = ARBShaderObjects.glCreateShaderObjectARB((int)var1);
            if (var5 == 0) {
                return 0;
            }
        }
        catch (Exception var4) {
            ARBShaderObjects.glDeleteObjectARB((int)var2);
            throw var4;
        }
        ARBShaderObjects.glShaderSourceARB((int)var5, (CharSequence)var0);
        ARBShaderObjects.glCompileShaderARB((int)var5);
        if (ARBShaderObjects.glGetObjectParameteriARB((int)var5, (int)35713) == 0) {
            throw new RuntimeException("Error creating shader:");
        }
        return var5;
    }

    public void drawCircle(int var1, int var2, float var3, int var4) {
        float var5 = (float)(var4 >> 24 & 0xFF) / 255.0f;
        float var6 = (float)(var4 >> 16 & 0xFF) / 255.0f;
        float var7 = (float)(var4 >> 8 & 0xFF) / 255.0f;
        float var8 = (float)(var4 & 0xFF) / 255.0f;
        boolean var9 = GL11.glIsEnabled((int)3042);
        boolean var10 = GL11.glIsEnabled((int)2848);
        boolean var11 = GL11.glIsEnabled((int)3553);
        if (!var9) {
            GL11.glEnable((int)3042);
        }
        if (!var10) {
            GL11.glEnable((int)2848);
        }
        if (var11) {
            GL11.glDisable((int)3553);
        }
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glColor4f((float)var6, (float)var7, (float)var8, (float)var5);
        GL11.glBegin((int)9);
        int var12 = 0;
        while (var12 <= 360) {
            GL11.glVertex2d((double)((double)var1 + Math.sin((double)var12 * 3.141526 / 180.0) * (double)var3), (double)((double)var2 + Math.cos((double)var12 * 3.141526 / 180.0) * (double)var3));
            ++var12;
        }
        GL11.glEnd();
        if (var11) {
            GL11.glEnable((int)3553);
        }
        if (!var10) {
            GL11.glDisable((int)2848);
        }
        if (!var9) {
            GL11.glDisable((int)3042);
        }
    }

    public static void outlineOne() {
        GL11.glPushAttrib((int)1048575);
        GL11.glDisable((int)3008);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2896);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glLineWidth((float)4.0f);
        GL11.glEnable((int)2848);
        GL11.glEnable((int)2960);
        GL11.glClear((int)1024);
        GL11.glClearStencil((int)15);
        GL11.glStencilFunc((int)512, (int)1, (int)15);
        GL11.glStencilOp((int)7681, (int)7681, (int)7681);
        GL11.glPolygonMode((int)1032, (int)6913);
    }

    public static void outlineTwo() {
        GL11.glStencilFunc((int)512, (int)0, (int)15);
        GL11.glStencilOp((int)7681, (int)7681, (int)7681);
        GL11.glPolygonMode((int)1032, (int)6914);
    }

    public static void outlineThree() {
        GL11.glStencilFunc((int)514, (int)1, (int)15);
        GL11.glStencilOp((int)7680, (int)7680, (int)7680);
        GL11.glPolygonMode((int)1032, (int)6913);
    }

    public static void outlineFour() {
        GL11.glDepthMask((boolean)false);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)10754);
        GL11.glPolygonOffset((float)1.0f, (float)-2000000.0f);
        GL11.glColor4f((float)0.9529412f, (float)0.6117647f, (float)0.07058824f, (float)1.0f);
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0f, 240.0f);
    }

    public static void outlineFive() {
        GL11.glPolygonOffset((float)1.0f, (float)2000000.0f);
        GL11.glDisable((int)10754);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)2960);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glEnable((int)3042);
        GL11.glEnable((int)2896);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)3008);
        GL11.glPopAttrib();
    }

    public static void drawOutlinedBoundingBox(AxisAlignedBB var0) {
        Tessellator var1 = Tessellator.getInstance();
        WorldRenderer var2 = var1.getWorldRenderer();
        var2.begin(3, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
        var1.draw();
        var2.begin(3, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
        var1.draw();
        var2.begin(1, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.maxZ).endVertex();
        var1.draw();
    }

    public static void drawBoundingBox(AxisAlignedBB var0) {
        Tessellator var1 = Tessellator.getInstance();
        WorldRenderer var2 = var1.getWorldRenderer();
        var2.begin(7, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.maxZ).endVertex();
        var1.draw();
        var2.begin(7, DefaultVertexFormats.POSITION);
        var2.pos(var0.maxX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.maxZ).endVertex();
        var1.draw();
        var2.begin(7, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.minZ).endVertex();
        var1.draw();
        var2.begin(7, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.minX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.minZ).endVertex();
        var1.draw();
        var2.begin(7, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.minX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.minZ).endVertex();
        var1.draw();
        var2.begin(7, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.minY, var0.maxZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.maxX, var0.maxY, var0.maxZ).endVertex();
        var2.pos(var0.maxX, var0.minY, var0.maxZ).endVertex();
        var1.draw();
    }

    public static void drawOutlinedBlockESP(double var0, double var2, double var4, float var6, float var7, float var8, float var9, float var10) {
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)2848);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glLineWidth((float)var10);
        GL11.glColor4f((float)var6, (float)var7, (float)var8, (float)var9);
        Class246.drawOutlinedBoundingBox(new AxisAlignedBB(var0, var2, var4, var0 + 1.0, var2 + 1.0, var4 + 1.0));
        GL11.glDisable((int)2848);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
    }

    public static void drawBlockESP(double var0, double var2, double var4, float var6, float var7, float var8, float var9, float var10, float var11, float var12, float var13, float var14) {
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2896);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)2848);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4f((float)var6, (float)var7, (float)var8, (float)var9);
        Class246.drawBoundingBox(new AxisAlignedBB(var0, var2, var4, var0 + 1.0, var2 + 1.0, var4 + 1.0));
        GL11.glLineWidth((float)var14);
        GL11.glColor4f((float)var10, (float)var11, (float)var12, (float)var13);
        Class246.drawOutlinedBoundingBox(new AxisAlignedBB(var0, var2, var4, var0 + 1.0, var2 + 1.0, var4 + 1.0));
        GL11.glDisable((int)2848);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2896);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
    }

    public static void drawSolidBlockESP(double var0, double var2, double var4, float var6, float var7, float var8, float var9) {
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)2848);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4f((float)var6, (float)var7, (float)var8, (float)var9);
        Class246.drawBoundingBox(new AxisAlignedBB(var0, var2, var4, var0 + 1.0, var2 + 1.0, var4 + 1.0));
        GL11.glDisable((int)2848);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
    }

    public static void drawOutlinedEntityESP(double var0, double var2, double var4, double var6, double var8, float var10, float var11, float var12, float var13) {
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)2848);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4f((float)var10, (float)var11, (float)var12, (float)var13);
        Class246.drawOutlinedBoundingBox(new AxisAlignedBB(var0 - var6, var2, var4 - var6, var0 + var6, var2 + var8, var4 + var6));
        GL11.glDisable((int)2848);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
    }

    public static void drawSolidEntityESP(double var0, double var2, double var4, double var6, double var8, float var10, float var11, float var12, float var13) {
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)2848);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4f((float)var10, (float)var11, (float)var12, (float)var13);
        Class246.drawBoundingBox(new AxisAlignedBB(var0 - var6, var2, var4 - var6, var0 + var6, var2 + var8, var4 + var6));
        GL11.glDisable((int)2848);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
    }

    public static void drawEntityESP(double var0, double var2, double var4, double var6, double var8, float var10, float var11, float var12, float var13, float var14, float var15, float var16, float var17, float var18) {
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)2848);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4f((float)var10, (float)var11, (float)var12, (float)var13);
        Class246.drawBoundingBox(new AxisAlignedBB(var0 - var6, var2, var4 - var6, var0 + var6, var2 + var8, var4 + var6));
        GL11.glLineWidth((float)var18);
        GL11.glColor4f((float)var14, (float)var15, (float)var16, (float)var17);
        Class246.drawOutlinedBoundingBox(new AxisAlignedBB(var0 - var6, var2, var4 - var6, var0 + var6, var2 + var8, var4 + var6));
        GL11.glDisable((int)2848);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
    }

    public static void drawTracerLine(double var0, double var2, double var4, float var6, float var7, float var8, float var9, float var10) {
        GL11.glPushMatrix();
        GL11.glEnable((int)3042);
        GL11.glEnable((int)2848);
        GL11.glDisable((int)2929);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)var10);
        GL11.glColor4f((float)var6, (float)var7, (float)var8, (float)var9);
        GL11.glBegin((int)2);
        Minecraft.getMinecraft();
        GL11.glVertex3d((double)0.0, (double)(0.0 + (double)Minecraft.thePlayer.getEyeHeight()), (double)0.0);
        GL11.glVertex3d((double)var0, (double)var2, (double)var4);
        GL11.glEnd();
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)2848);
        GL11.glDisable((int)3042);
        GL11.glPopMatrix();
    }

    public static void drawFilledBox(AxisAlignedBB var0) {
        Tessellator var1 = Tessellator.getInstance();
        WorldRenderer var2 = var1.getWorldRenderer();
        var2.begin(7, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.minY, var0.minZ).endVertex();
        var2.pos(var0.minX, var0.maxY, var0.minZ);
        var2.pos(var0.maxX, var0.minY, var0.minZ);
        var2.pos(var0.maxX, var0.maxY, var0.minZ);
        var2.pos(var0.maxX, var0.minY, var0.maxZ);
        var2.pos(var0.maxX, var0.maxY, var0.maxZ);
        var2.pos(var0.minX, var0.minY, var0.maxZ);
        var2.pos(var0.minX, var0.maxY, var0.maxZ);
        var1.draw();
        var2.begin(7, DefaultVertexFormats.POSITION);
        var2.pos(var0.maxX, var0.maxY, var0.minZ);
        var2.pos(var0.maxX, var0.minY, var0.minZ);
        var2.pos(var0.minX, var0.maxY, var0.minZ);
        var2.pos(var0.minX, var0.minY, var0.minZ);
        var2.pos(var0.minX, var0.maxY, var0.maxZ);
        var2.pos(var0.minX, var0.minY, var0.maxZ);
        var2.pos(var0.maxX, var0.maxY, var0.maxZ);
        var2.pos(var0.maxX, var0.minY, var0.maxZ);
        var1.draw();
        var2.begin(7, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.maxY, var0.minZ);
        var2.pos(var0.maxX, var0.maxY, var0.minZ);
        var2.pos(var0.maxX, var0.maxY, var0.maxZ);
        var2.pos(var0.minX, var0.maxY, var0.maxZ);
        var2.pos(var0.minX, var0.maxY, var0.minZ);
        var2.pos(var0.minX, var0.maxY, var0.maxZ);
        var2.pos(var0.maxX, var0.maxY, var0.maxZ);
        var2.pos(var0.maxX, var0.maxY, var0.minZ);
        var1.draw();
        var2.begin(7, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.minY, var0.minZ);
        var2.pos(var0.maxX, var0.minY, var0.minZ);
        var2.pos(var0.maxX, var0.minY, var0.maxZ);
        var2.pos(var0.minX, var0.minY, var0.maxZ);
        var2.pos(var0.minX, var0.minY, var0.minZ);
        var2.pos(var0.minX, var0.minY, var0.maxZ);
        var2.pos(var0.maxX, var0.minY, var0.maxZ);
        var2.pos(var0.maxX, var0.minY, var0.minZ);
        var1.draw();
        var2.begin(7, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.minY, var0.minZ);
        var2.pos(var0.minX, var0.maxY, var0.minZ);
        var2.pos(var0.minX, var0.minY, var0.maxZ);
        var2.pos(var0.minX, var0.maxY, var0.maxZ);
        var2.pos(var0.maxX, var0.minY, var0.maxZ);
        var2.pos(var0.maxX, var0.maxY, var0.maxZ);
        var2.pos(var0.maxX, var0.minY, var0.minZ);
        var2.pos(var0.maxX, var0.maxY, var0.minZ);
        var1.draw();
        var2.begin(7, DefaultVertexFormats.POSITION);
        var2.pos(var0.minX, var0.maxY, var0.maxZ);
        var2.pos(var0.minX, var0.minY, var0.maxZ);
        var2.pos(var0.minX, var0.maxY, var0.minZ);
        var2.pos(var0.minX, var0.minY, var0.minZ);
        var2.pos(var0.maxX, var0.maxY, var0.minZ);
        var2.pos(var0.maxX, var0.minY, var0.minZ);
        var2.pos(var0.maxX, var0.maxY, var0.maxZ);
        var2.pos(var0.maxX, var0.minY, var0.maxZ);
        var1.draw();
    }

    public static void checkSetupFBO() {
        Framebuffer var0 = Minecraft.getMinecraft().getFramebuffer();
        if (var0 != null && var0.depthBuffer > -1) {
            EXTFramebufferObject.glDeleteRenderbuffersEXT((int)var0.depthBuffer);
            int var1 = EXTFramebufferObject.glGenRenderbuffersEXT();
            EXTFramebufferObject.glBindRenderbufferEXT((int)36161, (int)var1);
            EXTFramebufferObject.glRenderbufferStorageEXT((int)36161, (int)34041, (int)Minecraft.getMinecraft().displayWidth, (int)Minecraft.getMinecraft().displayHeight);
            EXTFramebufferObject.glFramebufferRenderbufferEXT((int)36160, (int)36128, (int)36161, (int)var1);
            EXTFramebufferObject.glFramebufferRenderbufferEXT((int)36160, (int)36096, (int)36161, (int)var1);
            var0.depthBuffer = -1;
        }
    }

    public static void drawRoundedRect(float var0, float var1, float var2, float var3, float var4, int var5) {
        var0 = (float)((double)var0 + (double)(var4 / 2.0f) + 0.5);
        var1 = (float)((double)var1 + (double)(var4 / 2.0f) + 0.5);
        var2 = (float)((double)var2 - ((double)(var4 / 2.0f) + 0.5));
        var3 = (float)((double)var3 - ((double)(var4 / 2.0f) + 0.5));
        Class246.drawRect(var0, var1, var2, var3, var5);
        Class246.circle(var2 - var4 / 2.0f, var1 + var4 / 2.0f, var4, var5);
        Class246.circle(var0 + var4 / 2.0f, var3 - var4 / 2.0f, var4, var5);
        Class246.circle(var0 + var4 / 2.0f, var1 + var4 / 2.0f, var4, var5);
        Class246.circle(var2 - var4 / 2.0f, var3 - var4 / 2.0f, var4, var5);
        Class246.drawRect(var0 - var4 / 2.0f - 0.5f, var1 + var4 / 2.0f, var2, var3 - var4 / 2.0f, var5);
        Class246.drawRect(var0, var1 + var4 / 2.0f, var2 + var4 / 2.0f + 0.5f, var3 - var4 / 2.0f, var5);
        Class246.drawRect(var0 + var4 / 2.0f, var1 - var4 / 2.0f - 0.5f, var2 - var4 / 2.0f, var3 - var4 / 2.0f, var5);
        Class246.drawRect(var0 + var4 / 2.0f, var1, var2 - var4 / 2.0f, var3 + var4 / 2.0f + 0.5f, var5);
    }

    public static void circle(float var0, float var1, float var2, int var3) {
        Class246.arc(var0, var1, 0.0f, 360.0f, var2, var3);
    }

    public static void circle(float var0, float var1, float var2, Color var3) {
        Class246.arc(var0, var1, 0.0f, 360.0f, var2, var3);
    }

    public static void arc(float var0, float var1, float var2, float var3, float var4, int var5) {
        Class246.arcEllipse(var0, var1, var2, var3, var4, var4, var5);
    }

    public static void arc(float var0, float var1, float var2, float var3, float var4, Color var5) {
        Class246.arcEllipse(var0, var1, var2, var3, var4, var4, var5);
    }

    public static void arcEllipse(float var0, float var1, float var2, float var3, float var4, float var5, int var6) {
        float var7;
        float var8;
        float var9;
        GlStateManager.color(0.0f, 0.0f, 0.0f);
        GL11.glColor4f((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
        float var10 = 0.0f;
        if (var2 > var3) {
            var10 = var3;
            var3 = var2;
            var2 = var10;
        }
        float var11 = (float)(var6 >> 24 & 0xFF) / 255.0f;
        float var12 = (float)(var6 >> 16 & 0xFF) / 255.0f;
        float var13 = (float)(var6 >> 8 & 0xFF) / 255.0f;
        float var14 = (float)(var6 & 0xFF) / 255.0f;
        Tessellator var15 = Tessellator.getInstance();
        WorldRenderer var16 = var15.getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color(var12, var13, var14, var11);
        if (var11 > 0.5f) {
            GL11.glEnable((int)2848);
            GL11.glLineWidth((float)2.0f);
            GL11.glBegin((int)3);
            var9 = var3;
            while (var9 >= var2) {
                var8 = (float)Math.cos((double)var9 * Math.PI / 180.0) * var4 * 1.001f;
                var7 = (float)Math.sin((double)var9 * Math.PI / 180.0) * var5 * 1.001f;
                GL11.glVertex2f((float)(var0 + var8), (float)(var1 + var7));
                var9 -= 4.0f;
            }
            GL11.glEnd();
            GL11.glDisable((int)2848);
        }
        GL11.glBegin((int)6);
        var9 = var3;
        while (var9 >= var2) {
            var8 = (float)Math.cos((double)var9 * Math.PI / 180.0) * var4;
            var7 = (float)Math.sin((double)var9 * Math.PI / 180.0) * var5;
            GL11.glVertex2f((float)(var0 + var8), (float)(var1 + var7));
            var9 -= 4.0f;
        }
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void arcEllipse(float var0, float var1, float var2, float var3, float var4, float var5, Color var6) {
        float var7;
        float var8;
        float var9;
        GlStateManager.color(0.0f, 0.0f, 0.0f);
        GL11.glColor4f((float)0.0f, (float)0.0f, (float)0.0f, (float)0.0f);
        float var10 = 0.0f;
        if (var2 > var3) {
            var10 = var3;
            var3 = var2;
            var2 = var10;
        }
        Tessellator var11 = Tessellator.getInstance();
        WorldRenderer var12 = var11.getWorldRenderer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color((float)var6.getRed() / 255.0f, (float)var6.getGreen() / 255.0f, (float)var6.getBlue() / 255.0f, (float)var6.getAlpha() / 255.0f);
        if ((float)var6.getAlpha() > 0.5f) {
            GL11.glEnable((int)2848);
            GL11.glLineWidth((float)2.0f);
            GL11.glBegin((int)3);
            var9 = var3;
            while (var9 >= var2) {
                var8 = (float)Math.cos((double)var9 * Math.PI / 180.0) * var4 * 1.001f;
                var7 = (float)Math.sin((double)var9 * Math.PI / 180.0) * var5 * 1.001f;
                GL11.glVertex2f((float)(var0 + var8), (float)(var1 + var7));
                var9 -= 4.0f;
            }
            GL11.glEnd();
            GL11.glDisable((int)2848);
        }
        GL11.glBegin((int)6);
        var9 = var3;
        while (var9 >= var2) {
            var8 = (float)Math.cos((double)var9 * Math.PI / 180.0) * var4;
            var7 = (float)Math.sin((double)var9 * Math.PI / 180.0) * var5;
            GL11.glVertex2f((float)(var0 + var8), (float)(var1 + var7));
            var9 -= 4.0f;
        }
        GL11.glEnd();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void startDrawing() {
        GL11.glEnable((int)3042);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        Minecraft.getMinecraft().entityRenderer.setupCameraTransform(Minecraft.getMinecraft().timer.renderPartialTicks, 0);
    }

    public static void stopDrawing() {
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3553);
        GL11.glDisable((int)2848);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
    }

    public static void drawBorderedRect(float var0, float var1, float var2, float var3, float var4, int var5, int var6) {
        Class246.drawRect(var0, var1, var2, var3, var6);
        float var7 = (float)(var5 >> 24 & 0xFF) / 255.0f;
        float var8 = (float)(var5 >> 16 & 0xFF) / 255.0f;
        float var9 = (float)(var5 >> 8 & 0xFF) / 255.0f;
        float var10 = (float)(var5 & 0xFF) / 255.0f;
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)2848);
        GL11.glPushMatrix();
        GL11.glColor4f((float)var8, (float)var9, (float)var10, (float)var7);
        GL11.glLineWidth((float)var4);
        GL11.glBegin((int)1);
        GL11.glVertex2d((double)var0, (double)var1);
        GL11.glVertex2d((double)var0, (double)var3);
        GL11.glVertex2d((double)var2, (double)var3);
        GL11.glVertex2d((double)var2, (double)var1);
        GL11.glVertex2d((double)var0, (double)var1);
        GL11.glVertex2d((double)var2, (double)var1);
        GL11.glVertex2d((double)var0, (double)var3);
        GL11.glVertex2d((double)var2, (double)var3);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable((int)3553);
        GL11.glDisable((int)3042);
        GL11.glDisable((int)2848);
    }

    public static Color blend(Color var0, Color var1, double var2) {
        float var4 = (float)var2;
        float var5 = 1.0f - var4;
        float[] var6 = new float[3];
        float[] var7 = new float[3];
        float[] var10000 = var0.getColorComponents(var6);
        var10000 = var1.getColorComponents(var7);
        Color var8 = new Color(var6[0] * var4 + var7[0] * var5, var6[1] * var4 + var7[1] * var5, var6[2] * var4 + var7[2] * var5);
        return var8;
    }
}

