/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Render;

import cn.M1N3S3NS3.Util.Render.Location;

public class Particles {
    public int ticks;
    public Location location;
    public String text;

    public Particles(Location location, String text) {
        this.location = location;
        this.text = text;
        this.ticks = 0;
    }
}

