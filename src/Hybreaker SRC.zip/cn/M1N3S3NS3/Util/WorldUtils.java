/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util;

import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

public class WorldUtils {
    public static BlockPos getForwardBlock(double length) {
        Minecraft mc = Minecraft.getMinecraft();
        double yaw = Math.toRadians(Minecraft.thePlayer.rotationYaw);
        BlockPos fPos = new BlockPos(Minecraft.thePlayer.posX + -Math.sin(yaw) * length, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ + Math.cos(yaw) * length);
        return fPos;
    }
}

