/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.HWID;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Map;

public class HttpUtil {
    public static String sendGet(String url, String param) {
        String result = "";
        BufferedReader in = null;
        try {
            try {
                String line;
                String urlNameString = String.valueOf(url) + "?" + param;
                URL realUrl = new URL(urlNameString);
                URLConnection connection = realUrl.openConnection();
                connection.setDoOutput(true);
                connection.setReadTimeout(981);
                connection.setRequestProperty("accept", "*/*");
                connection.setRequestProperty("connection", "Keep-Alive");
                connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
                connection.connect();
                Map<String, List<String>> map = connection.getHeaderFields();
                for (String string : map.keySet()) {
                }
                in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                while ((line = in.readLine()) != null) {
                    result = String.valueOf(result) + line + "\n";
                }
            }
            catch (Exception exception) {
                try {
                    if (in != null) {
                        in.close();
                    }
                }
                catch (Exception exception2) {}
            }
        }
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            }
            catch (Exception exception) {}
        }
        return result;
    }
}

