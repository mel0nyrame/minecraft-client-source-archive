/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.HWID;

import java.security.MessageDigest;

public class HWIDUtil {
    private static final char[] hexArray = "0123456789ABCDEF".toCharArray();
    static int count = 3;

    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        int j = 0;
        while (j < bytes.length) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0xF];
            ++j;
        }
        return new String(hexChars);
    }

    public static String getHWID() throws Exception {
        StringBuilder s = new StringBuilder();
        String main = HWIDUtil.generateHWID();
        byte[] bytes = main.getBytes("UTF-8");
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
        byte[] md5 = messageDigest.digest(bytes);
        int i = 0;
        byte[] byArray = md5;
        int n = md5.length;
        int n2 = 0;
        while (n2 < n) {
            byte b = byArray[n2];
            s.append(Integer.toHexString(b & 0xFF | 0x300), 0, 3);
            if (i != md5.length - 1) {
                s.append("-");
            }
            ++i;
            ++n2;
        }
        return s.toString().toUpperCase();
    }

    public static String generateHWID() {
        StringBuilder s = new StringBuilder();
        s.append(System.getProperty("os.name"));
        s.append(System.getProperty("os.arch"));
        s.append(System.getProperty("os.version"));
        s.append(Runtime.getRuntime().availableProcessors());
        s.append(System.getenv("PROCESSOR_IDENTIFIER"));
        s.append(System.getenv("PROCESSOR_ARCHITECTURE"));
        s.append(System.getenv("PROCESSOR_ARCHITEW6432"));
        s.append(System.getenv("NUMBER_OF_PROCESSORS"));
        return s.toString();
    }
}

