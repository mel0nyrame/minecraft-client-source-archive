/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util;

import cn.M1N3S3NS3.API.Events.World.EventMove;
import cn.M1N3S3NS3.Util.BlockUtils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

public final class PlayerUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static boolean isHoldingSword() {
        return Minecraft.thePlayer.getCurrentEquippedItem() != null && Minecraft.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemSword;
    }

    public static boolean isOnSameTeam(EntityPlayer entity) {
        if (entity.getTeam() != null && Minecraft.thePlayer.getTeam() != null) {
            char c2;
            char c1 = entity.getDisplayName().getFormattedText().charAt(1);
            return c1 == (c2 = Minecraft.thePlayer.getDisplayName().getFormattedText().charAt(1));
        }
        return false;
    }

    public static boolean isInLiquid() {
        boolean inLiquid = false;
        AxisAlignedBB playerBB = Minecraft.thePlayer.getEntityBoundingBox();
        int y = (int)playerBB.minY;
        int x = MathHelper.floor_double(playerBB.minX);
        while (x < MathHelper.floor_double(playerBB.maxX) + 1) {
            int z = MathHelper.floor_double(playerBB.minZ);
            while (z < MathHelper.floor_double(playerBB.maxZ) + 1) {
                Block block = Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                if (block != null && !(block instanceof BlockAir)) {
                    if (!(block instanceof BlockLiquid)) {
                        return false;
                    }
                    inLiquid = true;
                }
                ++z;
            }
            ++x;
        }
        return inLiquid;
    }

    public static boolean isOnLiquid() {
        boolean onLiquid = false;
        AxisAlignedBB playerBB = Minecraft.thePlayer.getEntityBoundingBox();
        WorldClient world = Minecraft.theWorld;
        int y = (int)playerBB.offset((double)0.0, (double)-0.01, (double)0.0).minY;
        int x = MathHelper.floor_double(playerBB.minX);
        while (x < MathHelper.floor_double(playerBB.maxX) + 1) {
            int z = MathHelper.floor_double(playerBB.minZ);
            while (z < MathHelper.floor_double(playerBB.maxZ) + 1) {
                Block block = world.getBlockState(new BlockPos(x, y, z)).getBlock();
                if (block != null && !(block instanceof BlockAir)) {
                    if (!(block instanceof BlockLiquid)) {
                        return false;
                    }
                    onLiquid = true;
                }
                ++z;
            }
            ++x;
        }
        return onLiquid;
    }

    public static boolean isOnHypixel() {
        return !mc.isSingleplayer() && PlayerUtils.mc.getCurrentServerData().serverIP.contains("hypixel");
    }

    public static float getMaxFallDist() {
        PotionEffect potioneffect = Minecraft.thePlayer.getActivePotionEffect(Potion.jump);
        int f = potioneffect != null ? potioneffect.getAmplifier() + 1 : 0;
        return Minecraft.thePlayer.getMaxFallHeight() + f;
    }

    public static boolean isBlockUnder() {
        EntityPlayerSP player = Minecraft.thePlayer;
        WorldClient world = Minecraft.theWorld;
        AxisAlignedBB pBb = player.getEntityBoundingBox();
        double height = player.posY + (double)player.getEyeHeight();
        int offset = 0;
        while ((double)offset < height) {
            if (!world.getCollidingBoundingBoxes(player, pBb.offset(0.0, -offset, 0.0)).isEmpty()) {
                return true;
            }
            offset += 2;
        }
        return false;
    }

    public static boolean isInsideBlock() {
        EntityPlayerSP player = Minecraft.thePlayer;
        WorldClient world = Minecraft.theWorld;
        AxisAlignedBB bb = player.getEntityBoundingBox();
        int x = MathHelper.floor_double(bb.minX);
        while (x < MathHelper.floor_double(bb.maxX) + 1) {
            int y = MathHelper.floor_double(bb.minY);
            while (y < MathHelper.floor_double(bb.maxY) + 1) {
                int z = MathHelper.floor_double(bb.minZ);
                while (z < MathHelper.floor_double(bb.maxZ) + 1) {
                    AxisAlignedBB boundingBox;
                    Block block = world.getBlockState(new BlockPos(x, y, z)).getBlock();
                    if (block != null && !(block instanceof BlockAir) && (boundingBox = block.getCollisionBoundingBox(world, new BlockPos(x, y, z), world.getBlockState(new BlockPos(x, y, z)))) != null && player.getEntityBoundingBox().intersectsWith(boundingBox)) {
                        return true;
                    }
                    ++z;
                }
                ++y;
            }
            ++x;
        }
        return false;
    }

    public static void damageuhc() {
        if (Minecraft.thePlayer.onGround) {
            double offset = 0.0601f;
            NetHandlerPlayClient netHandler = mc.getNetHandler();
            EntityPlayerSP player = Minecraft.thePlayer;
            double x1 = player.posX;
            double y1 = player.posY;
            double z2 = player.posZ;
            int i2 = 0;
            while ((double)i2 < ((double)PlayerUtils.getMaxFallDist() + 1.0) / 0.05510000046342611 + 1.0) {
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x1, y1 + (double)0.0601f, z2, false));
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x1, y1 + (double)5.0E-4f, z2, false));
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x1, y1 + (double)0.005f + 6.01000003516674E-8, z2, false));
                ++i2;
            }
            netHandler.addToSendQueue(new C03PacketPlayer(true));
        }
    }

    public static void damage() {
        if (Minecraft.thePlayer.onGround) {
            double offset = 0.0602f;
            NetHandlerPlayClient netHandler = mc.getNetHandler();
            EntityPlayerSP player = Minecraft.thePlayer;
            double x2 = player.posX;
            double y2 = player.posY;
            double z2 = player.posZ;
            int i2 = 0;
            while ((double)i2 < (double)PlayerUtils.getMaxFallDist() / 0.05510000046342611 + 1.0) {
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x2, y2 + (double)0.0624f, z2, false));
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x2, y2 + (double)5.0E-4f, z2, false));
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x2, y2, z2, false));
                ++i2;
            }
            netHandler.addToSendQueue(new C03PacketPlayer(true));
        }
    }

    public static void setSpeed(EventMove moveEvent, double moveSpeed, float pseudoYaw, double pseudoStrafe, double pseudoForward) {
        double forward = pseudoForward;
        double strafe = pseudoStrafe;
        float yaw = pseudoYaw;
        if (pseudoForward == 0.0 && pseudoStrafe == 0.0) {
            moveEvent.setZ(0.0);
            moveEvent.setX(0.0);
        } else {
            if (pseudoForward != 0.0) {
                if (pseudoStrafe > 0.0) {
                    yaw = pseudoYaw + (float)(pseudoForward > 0.0 ? -45 : 45);
                } else if (pseudoStrafe < 0.0) {
                    yaw = pseudoYaw + (float)(pseudoForward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (pseudoForward > 0.0) {
                    forward = 1.0;
                } else if (pseudoForward < 0.0) {
                    forward = -1.0;
                }
            }
            double cos = Math.cos(Math.toRadians(yaw + 90.0f));
            double sin = Math.sin(Math.toRadians(yaw + 90.0f));
            moveEvent.setX(forward * moveSpeed * cos + strafe * moveSpeed * sin);
            moveEvent.setZ(forward * moveSpeed * sin - strafe * moveSpeed * cos);
        }
    }

    public static boolean MovementInput() {
        return PlayerUtils.mc.gameSettings.keyBindForward.pressed || PlayerUtils.mc.gameSettings.keyBindLeft.pressed || PlayerUtils.mc.gameSettings.keyBindRight.pressed || PlayerUtils.mc.gameSettings.keyBindBack.pressed;
    }

    public static boolean isOnGround(double height) {
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, -height, 0.0)).isEmpty();
    }

    public static float getDirection() {
        Minecraft.getMinecraft();
        float yaw = Minecraft.thePlayer.rotationYaw;
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            yaw += 180.0f;
        }
        float forward = 1.0f;
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else {
            Minecraft.getMinecraft();
            if (Minecraft.thePlayer.moveForward > 0.0f) {
                forward = 0.5f;
            }
        }
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.moveStrafing > 0.0f) {
            yaw -= 90.0f * forward;
        }
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.moveStrafing < 0.0f) {
            yaw += 90.0f * forward;
        }
        return yaw *= (float)Math.PI / 180;
    }

    public static double getDistanceToFall() {
        double distance = 0.0;
        double i = Minecraft.thePlayer.posY;
        while (i > 0.0) {
            Block block = BlockUtils.getBlock(new BlockPos(Minecraft.thePlayer.posX, i, Minecraft.thePlayer.posZ));
            if (block.getMaterial() != Material.air && block.isSolidFullCube() && block.isCollidable()) {
                distance = i;
                break;
            }
            if (i < 0.0) break;
            i -= 1.0;
        }
        i = Minecraft.thePlayer.posY - distance - 1.0;
        return i;
    }
}

