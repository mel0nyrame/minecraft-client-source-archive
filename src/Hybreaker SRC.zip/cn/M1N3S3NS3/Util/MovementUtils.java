/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util;

import cn.M1N3S3NS3.API.Events.World.EventMove;
import cn.M1N3S3NS3.Util.BlockUtils;
import cn.M1N3S3NS3.Util.PlayerUtils;
import cn.M1N3S3NS3.Util.Wrapper;
import net.minecraft.block.Block;
import net.minecraft.block.BlockIce;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockPackedIce;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.potion.Potion;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;

public final class MovementUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static float getSpeed() {
        return (float)Math.sqrt(Minecraft.thePlayer.motionX * Minecraft.thePlayer.motionX + Minecraft.thePlayer.motionZ * Minecraft.thePlayer.motionZ);
    }

    public static void strafe() {
        MovementUtils.strafe(MovementUtils.getSpeed());
    }

    public static void strafe(float speed) {
        if (!MovementUtils.isMoving()) {
            return;
        }
        double yaw = MovementUtils.getDirection();
        Minecraft.thePlayer.motionX = -Math.sin(yaw) * (double)speed;
        Minecraft.thePlayer.motionZ = Math.cos(yaw) * (double)speed;
    }

    public static void forward(double length) {
        double yaw = Math.toRadians(Minecraft.thePlayer.rotationYaw);
        Minecraft.thePlayer.setPosition(Minecraft.thePlayer.posX + -Math.sin(yaw) * length, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ + Math.cos(yaw) * length);
    }

    public static boolean isInLiquid() {
        if (Minecraft.thePlayer.isInWater()) {
            return true;
        }
        boolean inLiquid = false;
        int y = (int)Minecraft.thePlayer.getEntityBoundingBox().minY;
        int x = MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().minX);
        while (x < MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().maxX) + 1) {
            int z = MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().minZ);
            while (z < MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().maxZ) + 1) {
                Block block = Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                if (block != null && block.getMaterial() != Material.air) {
                    if (!(block instanceof BlockLiquid)) {
                        return false;
                    }
                    inLiquid = true;
                }
                ++z;
            }
            ++x;
        }
        return inLiquid;
    }

    public static double getDirection() {
        float rotationYaw = Minecraft.thePlayer.rotationYaw;
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            rotationYaw += 180.0f;
        }
        float forward = 1.0f;
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else if (Minecraft.thePlayer.moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (Minecraft.thePlayer.moveStrafing > 0.0f) {
            rotationYaw -= 90.0f * forward;
        }
        if (Minecraft.thePlayer.moveStrafing < 0.0f) {
            rotationYaw += 90.0f * forward;
        }
        return Math.toRadians(rotationYaw);
    }

    public static int getSpeedEffect() {
        return Minecraft.thePlayer.isPotionActive(Potion.moveSpeed) ? Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1 : 0;
    }

    public static double getJumpBoostModifier(double baseJumpHeight, boolean potionJumpHeight) {
        if (Minecraft.thePlayer.isPotionActive(Potion.jump) && potionJumpHeight) {
            int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier();
            baseJumpHeight += (double)((float)(amplifier + 1) * 0.1f);
        }
        return baseJumpHeight;
    }

    public static boolean isMoving() {
        block2: {
            block3: {
                if (Minecraft.thePlayer == null) break block2;
                if (MovementInput.moveForward != 0.0f) break block3;
                if (MovementInput.moveStrafe == 0.0f) break block2;
            }
            return true;
        }
        return false;
    }

    public static void setSpeed(EventMove moveEvent, double moveSpeed) {
        MovementUtils.setSpeed(moveEvent, moveSpeed, Minecraft.thePlayer.rotationYaw, (double)MovementInput.moveStrafe * 0.9, MovementInput.moveForward);
    }

    public static void setMotion(double speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            Minecraft.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f));
            Minecraft.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f));
        }
    }

    public static void setSpeed(EventMove moveEvent, double moveSpeed, float pseudoYaw, double pseudoStrafe, double pseudoForward) {
        double forward = pseudoForward;
        double strafe = pseudoStrafe;
        float yaw = pseudoYaw;
        if (moveEvent != null) {
            moveEvent.setX(0.0);
            moveEvent.setZ(0.0);
        }
        if (forward != 0.0) {
            if (strafe > 0.0) {
                yaw += (float)(forward > 0.0 ? -45 : 45);
            } else if (strafe < 0.0) {
                yaw += (float)(forward > 0.0 ? 45 : -45);
            }
            strafe = 0.0;
            if (forward > 0.0) {
                forward = 1.0;
            } else if (forward < 0.0) {
                forward = -1.0;
            }
        }
        if (strafe > 0.0) {
            strafe = 1.0;
        } else if (strafe < 0.0) {
            strafe = -1.0;
        }
        double mx = Math.cos(Math.toRadians(yaw + 90.0f));
        double mz = Math.sin(Math.toRadians(yaw + 90.0f));
        EventMove.x = forward * moveSpeed * mx + strafe * moveSpeed * mz;
        EventMove.z = forward * moveSpeed * mz - strafe * moveSpeed * mx;
    }

    public static void setSpeed(EventMove moveEvent, double moveSpeed, double v1) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            moveEvent.setX(0.0);
            moveEvent.setZ(0.0);
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            double v9 = Math.sin(Math.toRadians(yaw));
            double v11 = Math.cos(Math.toRadians(yaw));
            moveEvent.setX((forward * moveSpeed * -v9 + strafe * moveSpeed * v11) * v1);
            moveEvent.setZ((forward * moveSpeed * v11 - strafe * moveSpeed * -v9) * v1);
        }
    }

    public static double getBaseMoveSpeed1() {
        double baseSpeed = 0.2873;
        if (Minecraft.thePlayer.isPotionActive(Potion.getPotionById(1))) {
            int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.getPotionById(1)).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return baseSpeed;
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed;
        double d = baseSpeed = BlockUtils.isOnIce() ? 0.258977700006 : 0.2873;
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            baseSpeed *= 1.0 + 0.2 * (double)(Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1);
        }
        return baseSpeed;
    }

    public static double getJumpBoostModifier(double baseJumpHeight) {
        if (Minecraft.thePlayer.isPotionActive(Potion.jump)) {
            int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier();
            baseJumpHeight += (double)((float)(amplifier + 1) * 0.1f);
        }
        return baseJumpHeight;
    }

    public static double getBlockHeight() {
        return Wrapper.getPlayer().posY - (double)((int)Wrapper.getPlayer().posY);
    }

    public static boolean isOnGround(double height) {
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, -height, 0.0)).isEmpty();
    }

    public static double getMinFallDist() {
        double baseFallDist = 3.0;
        if (Wrapper.getPlayer().isPotionActive(Potion.jump)) {
            baseFallDist += (double)((float)Wrapper.getPlayer().getActivePotionEffect(Potion.jump).getAmplifier() + 1.0f);
        }
        return baseFallDist;
    }

    public static boolean isOnGround() {
        return Wrapper.getPlayer().onGround && Wrapper.getPlayer().isCollidedVertically;
    }

    public static boolean canStep(double height) {
        if (!Minecraft.thePlayer.isCollidedHorizontally || !MovementUtils.isOnGround(0.001)) {
            return false;
        }
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().expand(0.1, 0.0, 0.0).offset(0.0, height - 0.1, 0.0)).isEmpty() && Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().expand(0.1, 0.0, 0.0).offset(0.0, height + 0.1, 0.0)).isEmpty() || !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().expand(-0.1, 0.0, 0.0).offset(0.0, height - 0.1, 0.0)).isEmpty() && Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().expand(-0.1, 0.0, 0.0).offset(0.0, height + 0.1, 0.0)).isEmpty() || !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().expand(0.0, 0.0, 0.1).offset(0.0, height - 0.1, 0.0)).isEmpty() && Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().expand(0.0, 0.0, 0.1).offset(0.0, height + 0.1, 0.0)).isEmpty() || !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().expand(0.0, 0.0, -0.1).offset(0.0, height - 0.1, 0.0)).isEmpty() && Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().expand(0.0, 0.0, -0.1).offset(0.0, height + 0.1, 0.0)).isEmpty();
    }

    public static boolean isOnIce() {
        EntityPlayerSP player = Minecraft.thePlayer;
        Block blockUnder = Minecraft.theWorld.getBlockState(new BlockPos(player.posX, player.posY - 1.0, player.posZ)).getBlock();
        return blockUnder instanceof BlockIce || blockUnder instanceof BlockPackedIce;
    }

    public static void setSpeed(double speed) {
        Minecraft.getMinecraft();
        Minecraft.thePlayer.motionX = -Math.sin(PlayerUtils.getDirection()) * speed;
        Minecraft.getMinecraft();
        Minecraft.thePlayer.motionZ = Math.cos(PlayerUtils.getDirection()) * speed;
    }

    public static void setSpeed(double moveSpeed, float pseudoYaw, double pseudoStrafe, double pseudoForward) {
        double forward = pseudoForward;
        double strafe = pseudoStrafe;
        float yaw = pseudoYaw;
        if (forward != 0.0) {
            if (strafe > 0.0) {
                yaw += (float)(forward > 0.0 ? -45 : 45);
            } else if (strafe < 0.0) {
                yaw += (float)(forward > 0.0 ? 45 : -45);
            }
            strafe = 0.0;
            if (forward > 0.0) {
                forward = 1.0;
            } else if (forward < 0.0) {
                forward = -1.0;
            }
        }
        if (strafe > 0.0) {
            strafe = 1.0;
        } else if (strafe < 0.0) {
            strafe = -1.0;
        }
        double mx = Math.cos(Math.toRadians(yaw + 90.0f));
        double mz = Math.sin(Math.toRadians(yaw + 90.0f));
        Minecraft.thePlayer.motionX = forward * moveSpeed * mx + strafe * moveSpeed * mz;
        Minecraft.thePlayer.motionZ = forward * moveSpeed * mz - strafe * moveSpeed * mx;
    }

    public static void zeroXZ() {
        Minecraft.thePlayer.motionX = 0.0;
        Minecraft.thePlayer.motionZ = 0.0;
    }

    public static void strafe2(float speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            double cos = Math.cos(Math.toRadians(yaw + 90.0f));
            double sin = Math.sin(Math.toRadians(yaw + 90.0f));
            Minecraft.thePlayer.motionX = forward * (double)speed * cos + strafe * (double)speed * sin;
            Minecraft.thePlayer.motionZ = forward * (double)speed * sin - strafe * (double)speed * cos;
        }
    }

    public static void setMotion(EventMove e, double speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        double yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            e.setX(0.0);
            e.setZ(0.0);
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (double)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (double)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            double cos = Math.cos(Math.toRadians(yaw + 90.0));
            double sin = Math.sin(Math.toRadians(yaw + 90.0));
            e.setX(forward * speed * cos + strafe * speed * sin);
            e.setZ(forward * speed * sin - strafe * speed * cos);
        }
    }

    public static void setSpeed_2(EventMove moveEvent, double moveSpeed, float pseudoYaw, double pseudoStrafe, double pseudoForward) {
        double forward = pseudoForward;
        double strafe = pseudoStrafe;
        float yaw = pseudoYaw;
        if (forward != 0.0) {
            if (strafe > 0.0) {
                yaw += (float)(forward > 0.0 ? -45 : 45);
            } else if (strafe < 0.0) {
                yaw += (float)(forward > 0.0 ? 45 : -45);
            }
            strafe = 0.0;
            if (forward > 0.0) {
                forward = 1.0;
            } else if (forward < 0.0) {
                forward = -1.0;
            }
        }
        if (strafe > 0.0) {
            strafe = 1.0;
        } else if (strafe < 0.0) {
            strafe = -1.0;
        }
        double mx = Math.cos(Math.toRadians(yaw + 90.0f));
        double mz = Math.sin(Math.toRadians(yaw + 90.0f));
        Minecraft.thePlayer.motionX = forward * moveSpeed * mx + strafe * moveSpeed * mz;
        Minecraft.thePlayer.motionZ = forward * moveSpeed * mz - strafe * moveSpeed * mx;
    }
}

