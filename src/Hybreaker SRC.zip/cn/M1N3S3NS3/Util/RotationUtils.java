/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util;

import cn.M1N3S3NS3.Util.Math.VecRotation;
import cn.M1N3S3NS3.Util.MathUtils;
import cn.M1N3S3NS3.Util.PlayerUtils;
import cn.M1N3S3NS3.Util.Render.Location;
import cn.M1N3S3NS3.Util.Rotation;
import cn.M1N3S3NS3.Util.Wrapper;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;
import net.minecraft.util.Vec3;

public class RotationUtils {
    static Minecraft mc = Minecraft.getMinecraft();

    public static float[] getRotations(EntityLivingBase ent) {
        double x = ent.posX;
        double z = ent.posZ;
        double y = ent.posY + (double)(ent.getEyeHeight() / 2.0f);
        return RotationUtils.getRotationFromPosition(x, z, y);
    }

    public static float[] getPredictedRotations(EntityLivingBase ent) {
        double x = ent.posX + (ent.posX - ent.lastTickPosX);
        double z = ent.posZ + (ent.posZ - ent.lastTickPosZ);
        double y = ent.posY + (double)(ent.getEyeHeight() / 2.0f);
        return RotationUtils.getRotationFromPosition(x, z, y);
    }

    public static float[] getAverageRotations(List<EntityLivingBase> targetList) {
        double posX = 0.0;
        double posY = 0.0;
        double posZ = 0.0;
        for (Entity entity : targetList) {
            posX += entity.posX;
            posY += entity.boundingBox.maxY - 2.0;
            posZ += entity.posZ;
        }
        return new float[]{RotationUtils.getRotationFromPosition(posX /= (double)targetList.size(), posZ /= (double)targetList.size(), posY /= (double)targetList.size())[0], RotationUtils.getRotationFromPosition(posX, posZ, posY)[1]};
    }

    public static float getStraitYaw() {
        float YAW = MathHelper.wrapAngleTo180_float(Minecraft.thePlayer.rotationYaw);
        YAW = YAW < 45.0f && YAW > -45.0f ? 0.0f : (YAW > 45.0f && YAW < 135.0f ? 90.0f : (YAW > 135.0f || YAW < -135.0f ? 180.0f : -90.0f));
        return YAW;
    }

    public static float[] getBowAngles(Entity entity) {
        double xDelta = (entity.posX - entity.lastTickPosX) * 0.4;
        double zDelta = (entity.posZ - entity.lastTickPosZ) * 0.4;
        Minecraft.getMinecraft();
        double d = Minecraft.thePlayer.getDistanceToEntity(entity);
        d -= d % 0.8;
        double xMulti = 1.0;
        double zMulti = 1.0;
        boolean sprint = entity.isSprinting();
        xMulti = d / 0.8 * xDelta * (sprint ? 1.25 : 1.0);
        zMulti = d / 0.8 * zDelta * (sprint ? 1.25 : 1.0);
        Minecraft.getMinecraft();
        double x = entity.posX + xMulti - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double z = entity.posZ + zMulti - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        double y = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight() - (entity.posY + (double)entity.getEyeHeight());
        Minecraft.getMinecraft();
        double dist = Minecraft.thePlayer.getDistanceToEntity(entity);
        float yaw = (float)Math.toDegrees(Math.atan2(z, x)) - 90.0f;
        double d1 = MathHelper.sqrt_double(x * x + z * z);
        float pitch = (float)(-(Math.atan2(y, d1) * 180.0 / Math.PI)) + (float)dist * 0.11f;
        return new float[]{yaw, -pitch};
    }

    public static float[] getRotationFromPosition(double x, double z, double y) {
        Minecraft.getMinecraft();
        double xDiff = x - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double zDiff = z - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        double yDiff = y - Minecraft.thePlayer.posY - 1.2;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float getTrajAngleSolutionLow(float d3, float d1, float velocity) {
        float g = 0.006f;
        float sqrt = velocity * velocity * velocity * velocity - g * (g * (d3 * d3) + 2.0f * d1 * (velocity * velocity));
        return (float)Math.toDegrees(Math.atan(((double)(velocity * velocity) - Math.sqrt(sqrt)) / (double)(g * d3)));
    }

    public static float Method6384(float p_706631, float p_706632, float p_706633) {
        float var4 = MathHelper.sqrt(p_706632 - p_706631);
        if (var4 > p_706633) {
            var4 = p_706633;
        }
        if (var4 < -p_706633) {
            var4 = -p_706633;
        }
        return p_706631 + var4;
    }

    public static float getYawChange(float yaw, double posX, double posZ) {
        Minecraft.getMinecraft();
        double deltaX = posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double deltaZ = posZ - Minecraft.thePlayer.posZ;
        double yawToEntity = 0.0;
        if (deltaZ < 0.0 && deltaX < 0.0) {
            if (deltaX != 0.0) {
                yawToEntity = 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX));
            }
        } else if (deltaZ < 0.0 && deltaX > 0.0) {
            if (deltaX != 0.0) {
                yawToEntity = -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX));
            }
        } else if (deltaZ != 0.0) {
            yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }
        return MathHelper.wrapAngleTo180_float(-(yaw - (float)yawToEntity));
    }

    public static float getPitchChange(float pitch, Entity entity, double posY) {
        Minecraft.getMinecraft();
        double deltaX = entity.posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double deltaZ = entity.posZ - Minecraft.thePlayer.posZ;
        double d = posY - 2.2 + (double)entity.getEyeHeight();
        Minecraft.getMinecraft();
        double deltaY = d - Minecraft.thePlayer.posY;
        double distanceXZ = MathHelper.sqrt_double(deltaX * deltaX + deltaZ * deltaZ);
        double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));
        return -MathHelper.wrapAngleTo180_float(pitch - (float)pitchToEntity) - 2.5f;
    }

    public static float getNewAngle(float angle) {
        if ((angle %= 360.0f) >= 180.0f) {
            angle -= 360.0f;
        }
        if (angle < -180.0f) {
            angle += 360.0f;
        }
        return angle;
    }

    public static boolean canEntityBeSeen(Entity e) {
        boolean see;
        Vec3 vec1 = new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
        AxisAlignedBB box = e.getEntityBoundingBox();
        Vec3 vec2 = new Vec3(e.posX, e.posY + (double)(e.getEyeHeight() / 1.32f), e.posZ);
        double minx = e.posX - 0.25;
        double maxx = e.posX + 0.25;
        double miny = e.posY;
        double maxy = e.posY + Math.abs(e.posY - box.maxY);
        double minz = e.posZ - 0.25;
        double maxz = e.posZ + 0.25;
        boolean bl = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(maxx, miny, minz);
        boolean bl2 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(minx, miny, minz);
        boolean bl3 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(minx, miny, maxz);
        boolean bl4 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(maxx, miny, maxz);
        boolean bl5 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(maxx, maxy, minz);
        boolean bl6 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(minx, maxy, minz);
        boolean bl7 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(minx, maxy, maxz - 0.1);
        boolean bl8 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(maxx, maxy, maxz);
        boolean bl9 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        return see;
    }

    public static float getDistanceBetweenAngles(float angle1, float angle2) {
        float angle = Math.abs(angle1 - angle2) % 360.0f;
        if (angle > 180.0f) {
            angle = 360.0f - angle;
        }
        return angle;
    }

    public static float[] getRotations(double posX, double posY, double posZ) {
        EntityPlayerSP player = Minecraft.thePlayer;
        double x = posX - player.posX;
        double y = posY - (player.posY + (double)player.getEyeHeight());
        double z = posZ - player.posZ;
        double dist = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float)(Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(y, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float[] getRotationsEntity(EntityLivingBase entity) {
        if (PlayerUtils.isOnHypixel() && Minecraft.thePlayer.moving()) {
            return RotationUtils.getRotations(entity.posX + MathUtils.randomNumber(0.03, -0.03), entity.posY + (double)entity.getEyeHeight() - 0.4 + MathUtils.randomNumber(0.07, -0.07), entity.posZ + MathUtils.randomNumber(0.03, -0.03));
        }
        return RotationUtils.getRotations(entity.posX, entity.posY + (double)entity.getEyeHeight() - 0.4, entity.posZ);
    }

    public static Vec3 getVectorForRotation(float pitch, float yaw) {
        float f = MathHelper.cos(-yaw * ((float)Math.PI / 180) - (float)Math.PI);
        float f1 = MathHelper.sin(-yaw * ((float)Math.PI / 180) - (float)Math.PI);
        float f2 = -MathHelper.cos(-pitch * ((float)Math.PI / 180));
        float f3 = MathHelper.sin(-pitch * ((float)Math.PI / 180));
        return new Vec3(f1 * f2, f3, f * f2);
    }

    public static float[] getRotations5(Entity curTarget) {
        double diffY;
        if (curTarget == null) {
            return null;
        }
        Minecraft.getMinecraft();
        double diffX = curTarget.posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double diffZ = curTarget.posZ - Minecraft.thePlayer.posZ;
        if (curTarget instanceof EntityLivingBase) {
            EntityLivingBase elb = (EntityLivingBase)curTarget;
            double d = elb.posY + ((double)elb.getEyeHeight() - 0.8);
            Minecraft.getMinecraft();
            Minecraft.getMinecraft();
            diffY = d - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        } else {
            double d = (curTarget.boundingBox.minY + curTarget.boundingBox.maxY) / 2.0;
            Minecraft.getMinecraft();
            Minecraft.getMinecraft();
            diffY = d - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        }
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float[] getNeededRotations(Entity target) {
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        double d = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight();
        Minecraft.getMinecraft();
        Vec3 eyesPos = new Vec3(Minecraft.thePlayer.posX, d, Minecraft.thePlayer.posZ);
        double diffX = target.posX - eyesPos.xCoord;
        double diffY = target.posY - eyesPos.yCoord + 0.1;
        double diffZ = target.posZ - eyesPos.zCoord;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[]{MathHelper.wrapAngleTo180_float(yaw), MathHelper.wrapAngleTo180_float(pitch)};
    }

    public static float[] getRotations(BlockPos block, EnumFacing face) {
        double x = (double)block.getX() + 0.5 - Minecraft.thePlayer.posX + (double)face.getFrontOffsetX() / 2.0;
        double z = (double)block.getZ() + 0.5 - Minecraft.thePlayer.posZ + (double)face.getFrontOffsetZ() / 2.0;
        double y = (double)block.getY() + 0.5;
        double d1 = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight() - y;
        double d2 = MathHelper.sqrt(x * x + z * z);
        float yaw = (float)(Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(Math.atan2(d1, d2) * 180.0 / Math.PI);
        if (yaw < 0.0f) {
            yaw += 360.0f;
        }
        return new float[]{yaw, pitch};
    }

    public static float lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII(float p_706631, float p_706632, float p_706633) {
        float var4 = MathHelper.abs(p_706632 - p_706631);
        if (var4 > p_706633) {
            var4 = p_706633;
        }
        if (var4 < -p_706633) {
            var4 = -p_706633;
        }
        return p_706631 + var4;
    }

    public static float getYawChange(double posX, double posZ) {
        Minecraft.getMinecraft();
        double deltaX = posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double deltaZ = posZ - Minecraft.thePlayer.posZ;
        double yawToEntity = deltaZ < 0.0 && deltaX < 0.0 ? 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX)) : (deltaZ < 0.0 && deltaX > 0.0 ? -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX)) : Math.toDegrees(-Math.atan(deltaX / deltaZ)));
        Minecraft.getMinecraft();
        return MathHelper.wrapAngleTo180_float(-(Minecraft.thePlayer.rotationYaw - (float)yawToEntity));
    }

    public static float getYawChangeGiven(double posX, double posZ, float yaw) {
        Minecraft.getMinecraft();
        double deltaX = posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double deltaZ = posZ - Minecraft.thePlayer.posZ;
        double yawToEntity = deltaZ < 0.0 && deltaX < 0.0 ? 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX)) : (deltaZ < 0.0 && deltaX > 0.0 ? -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX)) : Math.toDegrees(-Math.atan(deltaX / deltaZ)));
        return MathHelper.wrapAngleTo180_float(-(yaw - (float)yawToEntity));
    }

    public static float clampRotation() {
        float rotationYaw = Minecraft.thePlayer.rotationYaw;
        float n = 1.0f;
        if (MovementInput.moveForward < 0.0f) {
            rotationYaw += 180.0f;
            n = -0.5f;
        } else if (MovementInput.moveForward > 0.0f) {
            n = 0.5f;
        }
        if (MovementInput.moveStrafe > 0.0f) {
            rotationYaw -= 90.0f * n;
        }
        if (MovementInput.moveStrafe < 0.0f) {
            rotationYaw += 90.0f * n;
        }
        return rotationYaw * ((float)Math.PI / 180);
    }

    public static float changeRotation(float p_706631, float p_706632) {
        float var4 = MathHelper.wrapAngleTo180_float(p_706632 - p_706631);
        if (var4 > 1000.0f) {
            var4 = 1000.0f;
        }
        if (var4 < -1000.0f) {
            var4 = -1000.0f;
        }
        return p_706631 + var4;
    }

    public static float[] getRotations(Entity target) {
        double var7;
        double var4 = target.posX - Minecraft.thePlayer.posX;
        double var5 = target.posZ - Minecraft.thePlayer.posZ;
        if (target instanceof EntityLivingBase) {
            EntityLivingBase var6 = (EntityLivingBase)target;
            var7 = var6.posY + (double)var6.getEyeHeight() - Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight();
        } else {
            var7 = (target.getEntityBoundingBox().minY + target.getEntityBoundingBox().maxY) / 2.0 - Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight();
        }
        double var8 = MathHelper.sqrt_double(var4 * var4 + var5 * var5);
        float var9 = (float)(Math.atan2(var5, var4) * 180.0 / Math.PI) - 90.0f;
        float var10 = (float)(-(Math.atan2(var7 - (target instanceof EntityPlayer ? 0.25 : 0.0), var8) * 180.0 / Math.PI));
        float pitch = RotationUtils.changeRotation(Minecraft.thePlayer.rotationPitch, var10);
        float yaw = RotationUtils.changeRotation(Minecraft.thePlayer.rotationYaw, var9);
        return new float[]{yaw, pitch};
    }

    public static float[] getRotationsForAura(Entity entity, double maxRange) {
        if (entity == null) {
            System.out.println("Fuck you ! Entity is nul!");
            return null;
        }
        double diffX = entity.posX - Wrapper.getPlayer().posX;
        double diffZ = entity.posZ - Wrapper.getPlayer().posZ;
        Location BestPos = new Location(entity.posX, entity.posY, entity.posZ);
        Location myEyePos = new Location(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Wrapper.getPlayer().getEyeHeight(), Minecraft.thePlayer.posZ);
        double diffY = entity.boundingBox.minY + 0.7;
        while (diffY < entity.boundingBox.maxY - 0.1) {
            Location location = new Location(entity.posX, diffY, entity.posZ);
            if (myEyePos.distanceTo(location) < myEyePos.distanceTo(BestPos)) {
                BestPos = new Location(entity.posX, diffY, entity.posZ);
            }
            diffY += 0.1;
        }
        if (myEyePos.distanceTo(BestPos) > maxRange) {
            return null;
        }
        diffY = BestPos.getY() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    private static float getAngleDifference(float a, float b) {
        return ((a - b) % 360.0f + 540.0f) % 360.0f - 180.0f;
    }

    public static Rotation toRotation(Vec3 vec, boolean predict) {
        Vec3 eyesPos = new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.getEntityBoundingBox().minY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
        if (predict) {
            eyesPos.addVector(Minecraft.thePlayer.motionX, Minecraft.thePlayer.motionY, Minecraft.thePlayer.motionZ);
        }
        double diffX = vec.xCoord - eyesPos.xCoord;
        double diffY = vec.yCoord - eyesPos.yCoord;
        double diffZ = vec.zCoord - eyesPos.zCoord;
        return new Rotation(MathHelper.wrapAngleTo180_float((float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f), MathHelper.wrapAngleTo180_float((float)(-Math.toDegrees(Math.atan2(diffY, Math.sqrt(diffX * diffX + diffZ * diffZ))))));
    }

    public static VecRotation searchCenterforTargetStrafe(AxisAlignedBB bb) {
        VecRotation vecRotation = null;
        Vec3 vec3 = new Vec3(bb.minX + (bb.maxX - bb.minX) * 0.5, 0.0, bb.minZ + (bb.maxZ - bb.minZ) * 0.5);
        Rotation rotation = RotationUtils.toRotation(vec3, false);
        VecRotation currentVec = new VecRotation(vec3, rotation);
        if (vecRotation == null) {
            vecRotation = currentVec;
        }
        return vecRotation;
    }

    public static float[] getRotation2(EntityLivingBase ent) {
        double lower = (double)ent.getEyeHeight() * (ent.isChild() || ent.getEntityBoundingBox().maxY - ent.getEntityBoundingBox().minY < 1.0 ? 2.0 : 0.5);
        double x = ent.posX + (ent.posX - ent.prevPosX);
        double z = ent.posZ + (ent.posZ - ent.prevPosZ);
        double y = ent.posY - lower;
        return RotationUtils.getRotationFromPosition(x, y, z);
    }

    public static Rotation limitAngleChange(Rotation currentRotation, Rotation targetRotation, float turnSpeed) {
        float yawDifference = RotationUtils.getAngleDifference(targetRotation.getYaw(), currentRotation.getYaw());
        float pitchDifference = RotationUtils.getAngleDifference(targetRotation.getPitch(), currentRotation.getPitch());
        return new Rotation(currentRotation.getYaw() + (yawDifference > turnSpeed ? turnSpeed : Math.max(yawDifference, -turnSpeed)), currentRotation.getPitch() + (pitchDifference > turnSpeed ? turnSpeed : Math.max(pitchDifference, -turnSpeed)));
    }

    public static float[] getRotationsTs(Entity target) {
        double var7;
        double var4 = target.posX - Minecraft.thePlayer.posX;
        double var5 = target.posZ - Minecraft.thePlayer.posZ;
        if (target instanceof EntityLivingBase) {
            EntityLivingBase var6 = (EntityLivingBase)target;
            var7 = var6.posY + (double)var6.getEyeHeight() - Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight();
        } else {
            var7 = (target.getEntityBoundingBox().minY + target.getEntityBoundingBox().maxY) / 2.0 - Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight();
        }
        double var8 = MathHelper.sqrt_double(var4 * var4 + var5 * var5);
        float var9 = (float)(Math.atan2(var5, var4) * 180.0 / Math.PI) - 90.0f;
        float var10 = (float)(-(Math.atan2(var7 - (target instanceof EntityPlayer ? 0.25 : 0.0), var8) * 180.0 / Math.PI));
        float pitch = RotationUtils.changeRotation(Minecraft.thePlayer.rotationPitch, var10);
        float yaw = RotationUtils.changeRotation(Minecraft.thePlayer.rotationYaw, var9);
        return new float[]{yaw, pitch};
    }
}

