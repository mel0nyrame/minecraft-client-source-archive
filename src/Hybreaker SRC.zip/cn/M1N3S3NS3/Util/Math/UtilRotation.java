/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Math;

import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.util.MathHelper;

public class UtilRotation {
    private static Minecraft mc = Minecraft.getMinecraft();

    public static float[] getAngles(Entity entity) {
        double x = entity.posX - Minecraft.thePlayer.posX;
        double z = entity.posZ - Minecraft.thePlayer.posZ;
        double y = entity instanceof EntityEnderman ? entity.posY - Minecraft.thePlayer.posY : entity.posY + ((double)entity.getEyeHeight() - 1.9) - Minecraft.thePlayer.posY + ((double)Minecraft.thePlayer.getEyeHeight() - 1.9);
        double helper = MathHelper.sqrt_double(x * x + z * z);
        float newYaw = (float)Math.toDegrees(-Math.atan(x / z));
        float newPitch = (float)(-Math.toDegrees(Math.atan(y / helper)));
        if (z < 0.0 && x < 0.0) {
            newYaw = (float)(90.0 + Math.toDegrees(Math.atan(z / x)));
        } else if (z < 0.0 && x > 0.0) {
            newYaw = (float)(-90.0 + Math.toDegrees(Math.atan(z / x)));
        }
        return new float[]{newPitch, newYaw};
    }

    public static double getDistanceBetweenAngles(float angle1, float angle2) {
        float distance = Math.abs(angle1 - angle2) % 360.0f;
        if (distance > 180.0f) {
            distance = 360.0f - distance;
        }
        return distance;
    }

    public static void jitterEffect(Random rand) {
        if (rand.nextBoolean()) {
            Minecraft.thePlayer.rotationPitch = rand.nextBoolean() ? (float)((double)Minecraft.thePlayer.rotationPitch - (double)rand.nextFloat() * 0.8) : (float)((double)Minecraft.thePlayer.rotationPitch + (double)rand.nextFloat() * 0.8);
        } else {
            Minecraft.thePlayer.rotationYaw = rand.nextBoolean() ? (float)((double)Minecraft.thePlayer.rotationYaw - (double)rand.nextFloat() * 0.8) : (float)((double)Minecraft.thePlayer.rotationYaw + (double)rand.nextFloat() * 0.8);
        }
    }
}

