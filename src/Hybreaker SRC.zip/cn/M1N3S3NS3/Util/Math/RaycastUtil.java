/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.base.Predicate
 *  com.google.common.base.Predicates
 */
package cn.M1N3S3NS3.Util.Math;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import java.util.List;
import net.minecraft.block.BlockAir;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

public class RaycastUtil {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static Entity raycastEntity(double range, float[] rotations) {
        Entity player = mc.getRenderViewEntity();
        if (player != null && Minecraft.theWorld != null) {
            Vec3 eyeHeight = player.getPositionEyes(RaycastUtil.mc.timer.renderPartialTicks);
            Vec3 looks = Entity.getVectorForRotation(rotations[0], rotations[1]);
            Vec3 vec = eyeHeight.addVector(looks.xCoord * range, looks.yCoord * range, looks.zCoord * range);
            List<Entity> list = Minecraft.theWorld.getEntitiesInAABBexcluding(player, player.getEntityBoundingBox().addCoord(looks.xCoord * range, looks.yCoord * range, looks.zCoord * range).expand(1.0, 1.0, 1.0), (Predicate<? super Entity>)Predicates.and(EntitySelectors.NOT_SPECTATING, Entity::canBeCollidedWith));
            Entity raycastedEntity = null;
            for (Entity entity : list) {
                double distance;
                if (!(entity instanceof EntityLivingBase)) continue;
                float borderSize = entity.getCollisionBorderSize();
                AxisAlignedBB axisalignedbb = entity.getEntityBoundingBox().expand(borderSize, borderSize, borderSize);
                MovingObjectPosition movingobjectposition = axisalignedbb.calculateIntercept(eyeHeight, vec);
                if (axisalignedbb.isVecInside(eyeHeight)) {
                    if (!(range >= 0.0)) continue;
                    raycastedEntity = entity;
                    range = 0.0;
                    continue;
                }
                if (movingobjectposition == null || !((distance = eyeHeight.distanceTo(movingobjectposition.hitVec)) < range) && range != 0.0) continue;
                if (entity == player.ridingEntity) {
                    if (range != 0.0) continue;
                    raycastedEntity = entity;
                    continue;
                }
                raycastedEntity = entity;
                range = distance;
            }
            return raycastedEntity;
        }
        return null;
    }

    public static Entity surroundEntity(Entity target) {
        Entity entity = target;
        for (Entity possibleTarget : Minecraft.theWorld.loadedEntityList) {
            if (!possibleTarget.isInvisible() || (double)target.getDistanceToEntity(possibleTarget) > 0.5 || !(Minecraft.thePlayer.getDistanceToEntity(possibleTarget) < Minecraft.thePlayer.getDistanceToEntity(entity))) continue;
            entity = possibleTarget;
        }
        return target;
    }

    public static BlockPos raycastPosition(double range) {
        Entity renderViewEntity = mc.getRenderViewEntity();
        if (renderViewEntity != null && Minecraft.theWorld != null) {
            MovingObjectPosition movingObjectPosition = renderViewEntity.rayTrace(range, 1.0f);
            if (Minecraft.theWorld.getBlockState(movingObjectPosition.getBlockPos()).getBlock() instanceof BlockAir) {
                return null;
            }
            return movingObjectPosition.getBlockPos();
        }
        return null;
    }
}

