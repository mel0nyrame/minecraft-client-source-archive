/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Math;

import cn.M1N3S3NS3.Util.MathUtils;
import cn.M1N3S3NS3.Util.PlayerUtils;
import cn.M1N3S3NS3.Util.Render.Location;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class RotationUtil {
    static Minecraft mc = Minecraft.getMinecraft();

    public static float a(double a1, double a2) {
        Minecraft.getMinecraft();
        double v1 = a1 - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double v3 = a2 - Minecraft.thePlayer.posZ;
        double v5 = MathHelper.ceiling_double_int(v1 * v1 + v3 * v3);
        return (float)(Math.atan2(v3, v1) * 180.0 / Math.PI) - 90.0f;
    }

    public static float[] getTargetStrafeRotation(Entity ent) {
        double x = ent.posX;
        double z = ent.posZ;
        double y = ent.posY + (double)(ent.getEyeHeight() / 2.0f);
        return RotationUtil.getRotationFromPosition(x, z, y);
    }

    public static boolean canEntityBeSeen(Entity e) {
        boolean see;
        Vec3 vec1 = new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
        AxisAlignedBB box = e.getEntityBoundingBox();
        Vec3 vec2 = new Vec3(e.posX, e.posY + (double)(e.getEyeHeight() / 1.32f), e.posZ);
        double minx = e.posX - 0.25;
        double maxx = e.posX + 0.25;
        double miny = e.posY;
        double maxy = e.posY + Math.abs(e.posY - box.maxY);
        double minz = e.posZ - 0.25;
        double maxz = e.posZ + 0.25;
        boolean bl = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(maxx, miny, minz);
        boolean bl2 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(minx, miny, minz);
        boolean bl3 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(minx, miny, maxz);
        boolean bl4 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(maxx, miny, maxz);
        boolean bl5 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(maxx, maxy, minz);
        boolean bl6 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(minx, maxy, minz);
        boolean bl7 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(minx, maxy, maxz - 0.1);
        boolean bl8 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        if (see) {
            return true;
        }
        vec2 = new Vec3(maxx, maxy, maxz);
        boolean bl9 = see = Minecraft.theWorld.rayTraceBlocks(vec1, vec2) == null;
        return see;
    }

    public static float[] getRotationsEx(EntityLivingBase ent) {
        double x = ent.posX;
        double z = ent.posZ;
        double y = ent.posY + (double)(ent.getEyeHeight() / 2.0f);
        return RotationUtil.getRotationFromPosition(x, z, y);
    }

    public static float[] getRotationFromPosition(double x, double z, double y) {
        Minecraft.getMinecraft();
        double xDiff = x - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double zDiff = z - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        double yDiff = y - Minecraft.thePlayer.posY - 1.2;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float getYawChangeGiven(double posX, double posZ, float yaw) {
        Minecraft.getMinecraft();
        double deltaX = posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double deltaZ = posZ - Minecraft.thePlayer.posZ;
        double yawToEntity = deltaZ < 0.0 && deltaX < 0.0 ? 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX)) : (deltaZ < 0.0 && deltaX > 0.0 ? -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX)) : Math.toDegrees(-Math.atan(deltaX / deltaZ)));
        return MathHelper.wrapAngleTo180_float(-(yaw - (float)yawToEntity));
    }

    public static float[] getRotationsInsane(Entity entity, double maxRange) {
        if (entity == null) {
            return null;
        }
        double diffX = entity.posX - Minecraft.thePlayer.posX;
        double diffZ = entity.posZ - Minecraft.thePlayer.posZ;
        Location BestPos = new Location(entity.posX, entity.posY, entity.posZ);
        Location myEyePos = new Location(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
        double diffY = entity.boundingBox.minY + 0.7;
        while (diffY < entity.boundingBox.maxY - 0.1) {
            Location location = new Location(entity.posX, diffY, entity.posZ);
            if (myEyePos.distanceTo(location) < myEyePos.distanceTo(BestPos)) {
                BestPos = new Location(entity.posX, diffY, entity.posZ);
            }
            diffY += 0.1;
        }
        if (myEyePos.distanceTo(BestPos) >= maxRange) {
            return null;
        }
        diffY = BestPos.getY() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float[] rotate(EntityLivingBase ent) {
        double x = ent.posX - Minecraft.thePlayer.posX;
        double y = ent.posY - Minecraft.thePlayer.posY;
        double z = ent.posZ - Minecraft.thePlayer.posZ;
        float yaw = (float)(-(Math.atan2(x, z) * 57.29577951308232));
        float pitch = (float)(-(Math.asin(y /= (double)Minecraft.thePlayer.getDistanceToEntity(ent)) * 57.29577951308232));
        return new float[]{yaw, pitch};
    }

    public static Vec3 getEyesPos() {
        return new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
    }

    public static float[] getNeededRotations(Vec3 vec) {
        Vec3 eyesPos = RotationUtil.getEyesPos();
        double diffX = vec.xCoord - eyesPos.xCoord + 0.5;
        double diffY = vec.yCoord - eyesPos.yCoord + 0.5;
        double diffZ = vec.zCoord - eyesPos.zCoord + 0.5;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = (float)(-Math.atan2(diffY, diffXZ) * 180.0 / Math.PI);
        float[] arrf = new float[]{MathHelper.wrapAngleTo180_float(yaw), Minecraft.getMinecraft().gameSettings.keyBindJump.pressed ? 90.0f : MathHelper.wrapAngleTo180_float(pitch)};
        return arrf;
    }

    public static void faceVectorPacketInstant(Vec3 vec) {
        float[] rotations = RotationUtil.getNeededRotations(vec);
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(rotations[0], rotations[1], Minecraft.thePlayer.onGround));
    }

    public static float pitch() {
        return Minecraft.thePlayer.rotationPitch;
    }

    public static void pitch(float pitch) {
        Minecraft.thePlayer.rotationPitch = pitch;
    }

    public static float yaw() {
        return Minecraft.thePlayer.rotationYaw;
    }

    public static void yaw(float yaw) {
        Minecraft.thePlayer.rotationYaw = yaw;
    }

    public static float[] faceTarget(Entity target, float p_706252, float p_706253, boolean miss) {
        double var6;
        double var4 = target.posX - Minecraft.thePlayer.posX;
        double var8 = target.posZ - Minecraft.thePlayer.posZ;
        if (target instanceof EntityLivingBase) {
            EntityLivingBase var10 = (EntityLivingBase)target;
            var6 = var10.posY + (double)var10.getEyeHeight() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        } else {
            var6 = (target.getEntityBoundingBox().minY + target.getEntityBoundingBox().maxY) / 2.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        }
        Random rnd = new Random();
        double var14 = MathHelper.sqrt_double(var4 * var4 + var8 * var8);
        float var12 = (float)(Math.atan2(var8, var4) * 180.0 / Math.PI) - 90.0f;
        float var13 = (float)(-Math.atan2(var6 - (target instanceof EntityPlayer ? 0.25 : 0.0), var14) * 180.0 / Math.PI);
        float pitch = RotationUtil.changeRotation(Minecraft.thePlayer.rotationPitch, var13, p_706253);
        float yaw = RotationUtil.changeRotation(Minecraft.thePlayer.rotationYaw, var12, p_706252);
        return new float[]{yaw, pitch};
    }

    public static float changeRotation(float p_706631, float p_706632, float p_706633) {
        float var4 = MathHelper.wrapAngleTo180_float(p_706632 - p_706631);
        if (var4 > p_706633) {
            var4 = p_706633;
        }
        if (var4 < -p_706633) {
            var4 = -p_706633;
        }
        return p_706631 + var4;
    }

    public static double[] getRotationToEntity(Entity entity) {
        double pX = Minecraft.thePlayer.posX;
        double pY = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight();
        double pZ = Minecraft.thePlayer.posZ;
        double eX = entity.posX;
        double eY = entity.posY + (double)(entity.height / 2.0f);
        double eZ = entity.posZ;
        double dX = pX - eX;
        double dY = pY - eY;
        double dZ = pZ - eZ;
        double dH = Math.sqrt(Math.pow(dX, 2.0) + Math.pow(dZ, 2.0));
        double yaw = Math.toDegrees(Math.atan2(dZ, dX)) + 90.0;
        double pitch = Math.toDegrees(Math.atan2(dH, dY));
        return new double[]{yaw, 90.0 - pitch};
    }

    public static float[] getRotations(Entity entity) {
        double diffY;
        if (entity == null) {
            return null;
        }
        double diffX = entity.posX - Minecraft.thePlayer.posX;
        double diffZ = entity.posZ - Minecraft.thePlayer.posZ;
        if (entity instanceof EntityLivingBase) {
            EntityLivingBase elb = (EntityLivingBase)entity;
            diffY = elb.posY + ((double)elb.getEyeHeight() - 0.4) - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        } else {
            diffY = (entity.boundingBox.minY + entity.boundingBox.maxY) / 2.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        }
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-Math.atan2(diffY, dist) * 180.0 / Math.PI);
        return new float[]{yaw, pitch};
    }

    public static float[] getRotation(Entity a12) {
        if (a12 == null) {
            return null;
        }
        Minecraft.getMinecraft();
        double v1 = a12.posX - Minecraft.thePlayer.posX;
        double d = a12.posY + (double)a12.getEyeHeight() * 0.9;
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        double v32 = d - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        Minecraft.getMinecraft();
        double v5 = a12.posZ - Minecraft.thePlayer.posZ;
        double v72 = MathHelper.ceiling_float_int(v1 * v1 + v5 * v5);
        float v9 = (float)(Math.atan2(v5, v1) * 180.0 / Math.PI) - 90.0f;
        float v10 = (float)(-(Math.atan2(v32, v72) * 180.0 / Math.PI));
        float[] fArray = new float[2];
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        fArray[0] = Minecraft.thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(v9 - Minecraft.thePlayer.rotationYaw);
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        fArray[1] = Minecraft.thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float(v10 - Minecraft.thePlayer.rotationPitch);
        return fArray;
    }

    public static float getDistanceBetweenAngles(float angle1, float angle2) {
        float angle3 = Math.abs(angle1 - angle2) % 360.0f;
        if (angle3 > 180.0f) {
            angle3 = 0.0f;
        }
        return angle3;
    }

    public static float[] grabBlockRotations(BlockPos pos) {
        return RotationUtil.getVecRotation(Minecraft.thePlayer.getPositionVector().addVector(0.0, Minecraft.thePlayer.getEyeHeight(), 0.0), new Vec3((double)pos.getX() + 0.5, (double)pos.getY() + 0.5, (double)pos.getZ() + 0.5));
    }

    public static float[] getVecRotation(Vec3 position) {
        return RotationUtil.getVecRotation(Minecraft.thePlayer.getPositionVector().addVector(0.0, Minecraft.thePlayer.getEyeHeight(), 0.0), position);
    }

    public static float[] getVecRotation(Vec3 origin, Vec3 position) {
        Vec3 difference = position.subtract(origin);
        double distance = difference.flat().lengthVector();
        float yaw = (float)Math.toDegrees(Math.atan2(difference.zCoord, difference.xCoord)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(difference.yCoord, distance)));
        return new float[]{yaw, pitch};
    }

    public static int wrapAngleToDirection(float yaw, int zones) {
        int angle = (int)((double)(yaw + (float)(360 / (2 * zones))) + 0.5) % 360;
        if (angle < 0) {
            angle += 360;
        }
        return angle / (360 / zones);
    }

    public static float getYawChange(float yaw, double posX, double posZ) {
        Minecraft.getMinecraft();
        double deltaX = posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double deltaZ = posZ - Minecraft.thePlayer.posZ;
        double yawToEntity = 0.0;
        if (deltaZ < 0.0 && deltaX < 0.0) {
            if (deltaX != 0.0) {
                yawToEntity = 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX));
            }
        } else if (deltaZ < 0.0 && deltaX > 0.0) {
            if (deltaX != 0.0) {
                yawToEntity = -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX));
            }
        } else if (deltaZ != 0.0) {
            yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }
        return MathHelper.wrapAngleTo180_float(-(yaw - (float)yawToEntity));
    }

    public static float[] getRotationsEntity(EntityLivingBase entity) {
        if (PlayerUtils.isOnHypixel() && Minecraft.thePlayer.isMoving()) {
            return RotationUtil.getRotations(entity.posX + MathUtils.randomNumber(0.03, -0.03), entity.posY + (double)entity.getEyeHeight() - 0.4 + MathUtils.randomNumber(0.07, -0.07), entity.posZ + MathUtils.randomNumber(0.03, -0.03));
        }
        return RotationUtil.getRotations(entity.posX, entity.posY + (double)entity.getEyeHeight() - 0.4, entity.posZ);
    }

    public static float[] getRotations(double posX, double posY, double posZ) {
        EntityPlayerSP player = Minecraft.thePlayer;
        double x = posX - player.posX;
        double y = posY - (player.posY + (double)player.getEyeHeight());
        double z = posZ - player.posZ;
        double dist = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float)(Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(y, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float getYawChange(double posX, double posZ) {
        Minecraft.getMinecraft();
        double deltaX = posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double deltaZ = posZ - Minecraft.thePlayer.posZ;
        double yawToEntity = 0.0;
        if (deltaZ < 0.0 && deltaX < 0.0) {
            if (deltaX != 0.0) {
                yawToEntity = 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX));
            }
        } else if (deltaZ < 0.0 && deltaX > 0.0) {
            if (deltaX != 0.0) {
                yawToEntity = -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX));
            }
        } else if (deltaZ != 0.0) {
            yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }
        return MathHelper.wrapAngleTo180_float(-(Minecraft.thePlayer.rotationYaw - (float)yawToEntity));
    }

    public static float getPitchChange(Entity entity, double posY) {
        Minecraft.getMinecraft();
        double v1 = entity.posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double v32 = entity.posZ - Minecraft.thePlayer.posZ;
        double d = posY - 2.2 + (double)entity.getEyeHeight();
        Minecraft.getMinecraft();
        double v5 = d - Minecraft.thePlayer.posY;
        double v72 = MathHelper.ceiling_float_int((float)(v1 * v1 + v32 * v32));
        double v9 = -Math.toDegrees(Math.atan(v5 / v72));
        Minecraft.getMinecraft();
        return -MathHelper.wrapAngleTo180_float(Minecraft.thePlayer.rotationPitch - (float)v9) - 2.5f;
    }

    public static final float getDifference(float a, float b) {
        float r = (float)((double)(a - b) % 360.0);
        if ((double)r < -180.0) {
            r = (float)((double)r + 360.0);
        }
        if ((double)r >= 180.0) {
            r = (float)((double)r - 360.0);
        }
        return r;
    }

    public static final float[] getRotations(Entity entity, boolean predict, double predictionFactor) {
        Vec3 playerPos = new Vec3(Minecraft.thePlayer.posX + (predict ? Minecraft.thePlayer.motionX * predictionFactor : 0.0), Minecraft.thePlayer.posY + (double)(entity instanceof EntityLivingBase ? Minecraft.thePlayer.getEyeHeight() : 0.0f) + (predict ? Minecraft.thePlayer.motionY * predictionFactor : 0.0), Minecraft.thePlayer.posZ + (predict ? Minecraft.thePlayer.motionZ * predictionFactor : 0.0));
        Vec3 entityPos = new Vec3(entity.posX + (predict ? (entity.posX - entity.prevPosX) * predictionFactor : 0.0), entity.posY + (predict ? (entity.posY - entity.prevPosY) * predictionFactor : 0.0), entity.posZ + (predict ? (entity.posZ - entity.prevPosZ) * predictionFactor : 0.0));
        double diffX = entityPos.xCoord - playerPos.xCoord;
        double diffY = entity instanceof EntityLivingBase ? entityPos.yCoord + (double)((EntityLivingBase)entity).getEyeHeight() - playerPos.yCoord : entityPos.yCoord - playerPos.yCoord;
        double diffZ = entityPos.zCoord - playerPos.zCoord;
        double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);
        double yaw = Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0;
        double pitch = -Math.toDegrees(Math.atan2(diffY, dist));
        return new float[]{(float)yaw, (float)pitch};
    }

    public static final double getRotationDifference(float[] clientRotations, float[] serverRotations) {
        return Math.hypot(RotationUtil.getDifference(clientRotations[0], serverRotations[0]), clientRotations[1] - serverRotations[1]);
    }

    public static final double getRotationDifference(Entity entity) {
        float[] rotations = RotationUtil.getRotations(entity, false, 1.0);
        return RotationUtil.getRotationDifference(rotations, new float[]{Minecraft.thePlayer.rotationYaw, Minecraft.thePlayer.rotationPitch});
    }

    public static float[] KillauraRotations(Entity entity) {
        double diffY;
        if (entity == null) {
            return null;
        }
        double diffX = entity.posX - Minecraft.thePlayer.posX;
        double diffZ = entity.posZ - Minecraft.thePlayer.posZ;
        if (entity instanceof EntityLivingBase) {
            EntityLivingBase elb = (EntityLivingBase)entity;
            diffY = elb.posY + ((double)elb.getEyeHeight() - 0.4) - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        } else {
            diffY = (entity.boundingBox.minY + entity.boundingBox.maxY) / 2.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        }
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-Math.atan2(diffY, dist) * 180.0 / Math.PI);
        return new float[]{yaw, pitch};
    }

    public static float getYawDifference(float currentYaw, double targetX, double targetY, double targetZ) {
        double deltaX = targetX - Minecraft.thePlayer.posX;
        double deltaY = targetY - Minecraft.thePlayer.posY;
        double deltaZ = targetZ - Minecraft.thePlayer.posZ;
        double yawToEntity = 0.0;
        double degrees = Math.toDegrees(Math.atan(deltaZ / deltaX));
        if (deltaZ < 0.0 && deltaX < 0.0) {
            if (deltaX != 0.0) {
                yawToEntity = 90.0 + degrees;
            }
        } else if (deltaZ < 0.0 && deltaX > 0.0) {
            if (deltaX != 0.0) {
                yawToEntity = -90.0 + degrees;
            }
        } else if (deltaZ != 0.0) {
            yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }
        return MathHelper.wrapAngleTo180_float(-(currentYaw - (float)yawToEntity));
    }
}

