/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Math;

import cn.M1N3S3NS3.Util.Rotation;
import cn.M1N3S3NS3.Util.Vec3d;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityEgg;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;

public class setBlockAndFacing {
    static Minecraft mc = Minecraft.getMinecraft();
    private BlockPos currentPos;

    private void setBlockAndFacing(BlockPos var1) {
        if (Minecraft.theWorld.getBlockState(var1.add(0, -1, 0)).getBlock() != Blocks.air) {
            this.currentPos = var1.add(0, -1, 0);
            EnumFacing currentFacing = EnumFacing.UP;
        } else if (Minecraft.theWorld.getBlockState(var1.add(-1, 0, 0)).getBlock() != Blocks.air) {
            this.currentPos = var1.add(-1, 0, 0);
            EnumFacing currentFacing = EnumFacing.EAST;
        } else if (Minecraft.theWorld.getBlockState(var1.add(1, 0, 0)).getBlock() != Blocks.air) {
            this.currentPos = var1.add(1, 0, 0);
            EnumFacing currentFacing = EnumFacing.WEST;
        } else if (Minecraft.theWorld.getBlockState(var1.add(0, 0, -1)).getBlock() != Blocks.air) {
            this.currentPos = var1.add(0, 0, -1);
            EnumFacing currentFacing = EnumFacing.SOUTH;
        } else if (Minecraft.theWorld.getBlockState(var1.add(0, 0, 1)).getBlock() != Blocks.air) {
            this.currentPos = var1.add(0, 0, 1);
            EnumFacing currentFacing = EnumFacing.NORTH;
        } else {
            this.currentPos = null;
            Object currentFacing = null;
        }
    }

    public static class BlockUtil {
        private static Minecraft mc = Minecraft.getMinecraft();
        static float last = 0.0f;

        public static void placeHeldItemUnderPlayer() {
            BlockPos blockPos = new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.getEntityBoundingBox().minY - 1.0, Minecraft.thePlayer.posZ);
            Vec3d vec = new Vec3d(blockPos).addVector(0.4f, 0.4f, 0.4f);
            Minecraft.playerController.onPlayerRightClick(Minecraft.thePlayer, Minecraft.theWorld, null, blockPos, EnumFacing.UP, vec.scale(0.4));
        }

        public static Rotation limitAngleChange(Rotation currentRotation, Rotation targetRotation, float turnSpeed) {
            float yawDifference = BlockUtil.getAngleDifference(targetRotation.getYaw(), currentRotation.getYaw());
            float pitchDifference = BlockUtil.getAngleDifference(targetRotation.getPitch(), currentRotation.getPitch());
            return new Rotation(currentRotation.getYaw() + (yawDifference > turnSpeed ? turnSpeed : Math.max(yawDifference, -turnSpeed)), currentRotation.getPitch() + (pitchDifference > turnSpeed ? turnSpeed : Math.max(pitchDifference, -turnSpeed)));
        }

        private static float getAngleDifference(float a, float b) {
            return ((a - b) % 360.0f + 540.0f) % 360.0f - 180.0f;
        }

        public static float[] getDirectionToBlock(int var0, int var1, int var2, EnumFacing var3) {
            EntityEgg var4 = new EntityEgg(Minecraft.theWorld);
            var4.posX = (double)var0 + 0.5;
            var4.posY = (double)var1 + 0.5;
            var4.posZ = (double)var2 + 0.5;
            var4.posX += (double)var3.getDirectionVec().getX() * 0.25;
            var4.posY += (double)var3.getDirectionVec().getY() * 0.25;
            var4.posZ += (double)var3.getDirectionVec().getZ() * 0.25;
            return BlockUtil.getDirectionToEntity(var4);
        }

        private static float[] getDirectionToEntity(Entity var0) {
            return new float[]{BlockUtil.getYaw(var0) + Minecraft.thePlayer.rotationYaw, BlockUtil.getPitch(var0) + Minecraft.thePlayer.rotationPitch};
        }

        public static float[] getRotationNeededForBlock(EntityPlayer paramEntityPlayer, BlockPos pos) {
            double d1 = (double)pos.getX() - paramEntityPlayer.posX;
            double d2 = (double)pos.getY() + 0.5 - (paramEntityPlayer.posY + (double)paramEntityPlayer.getEyeHeight());
            double d3 = (double)pos.getZ() - paramEntityPlayer.posZ;
            double d4 = Math.sqrt(d1 * d1 + d3 * d3);
            float f1 = (float)(Math.atan2(d3, d1) * 180.0 / Math.PI) - 90.0f;
            float f2 = (float)(-(Math.atan2(d2, d4) * 180.0 / Math.PI));
            return new float[]{f1, f2};
        }

        public static float getYaw(Entity var0) {
            double var1 = var0.posX - Minecraft.thePlayer.posX;
            double var3 = var0.posZ - Minecraft.thePlayer.posZ;
            double var5 = var3 < 0.0 && var1 < 0.0 ? 90.0 + Math.toDegrees(Math.atan(var3 / var1)) : (var3 < 0.0 && var1 > 0.0 ? -90.0 + Math.toDegrees(Math.atan(var3 / var1)) : Math.toDegrees(-Math.atan(var1 / var3)));
            return MathHelper.wrapAngleTo180_float(-(Minecraft.thePlayer.rotationYaw - (float)var5));
        }

        public static float getPitch(Entity var0) {
            double var1 = var0.posX - Minecraft.thePlayer.posX;
            double var3 = var0.posZ - Minecraft.thePlayer.posZ;
            double var5 = var0.posY - 1.6 + (double)var0.getEyeHeight() - Minecraft.thePlayer.posY;
            double var7 = MathHelper.sqrt_double(var1 * var1 + var3 * var3);
            double var9 = -Math.toDegrees(Math.atan(var5 / var7));
            return -MathHelper.wrapAngleTo180_float(Minecraft.thePlayer.rotationPitch - (float)var9);
        }
    }
}

