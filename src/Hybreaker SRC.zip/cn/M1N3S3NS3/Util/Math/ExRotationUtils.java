/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Math;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class ExRotationUtils {
    public static float[] getRotations(EntityLivingBase ent) {
        double x = ent.posX;
        double z = ent.posZ;
        double y = ent.posY + (double)(ent.getEyeHeight() / 2.0f);
        return ExRotationUtils.getRotationFromPosition(x, z, y);
    }

    public static float[] getAverageRotations(List targetList) {
        double posX = 0.0;
        double posY = 0.0;
        double posZ = 0.0;
        for (Entity ent : targetList) {
            posX += ent.posX;
            posY += ent.boundingBox.maxY - 2.0;
            posZ += ent.posZ;
        }
        return new float[]{ExRotationUtils.getRotationFromPosition(posX /= (double)targetList.size(), posZ /= (double)targetList.size(), posY /= (double)targetList.size())[0], ExRotationUtils.getRotationFromPosition(posX, posZ, posY)[1]};
    }

    public static float[] getBowAngles(Entity entity) {
        double xDelta = entity.posX - entity.lastTickPosX;
        double zDelta = entity.posZ - entity.lastTickPosZ;
        Minecraft.getMinecraft();
        double d = Minecraft.thePlayer.getDistanceToEntity(entity);
        d -= d % 0.8;
        double xMulti = 1.0;
        double zMulti = 1.0;
        boolean sprint = entity.isSprinting();
        xMulti = d / 0.8 * xDelta * (sprint ? 1.25 : 1.0);
        zMulti = d / 0.8 * zDelta * (sprint ? 1.25 : 1.0);
        Minecraft.getMinecraft();
        double x = entity.posX + xMulti - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double z = entity.posZ + zMulti - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        double y = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight() - (entity.posY + (double)entity.getEyeHeight());
        Minecraft.getMinecraft();
        double dist = Minecraft.thePlayer.getDistanceToEntity(entity);
        float yaw = (float)Math.toDegrees(Math.atan2(z, x)) - 90.0f;
        float pitch = (float)Math.toDegrees(Math.atan2(y, dist));
        return new float[]{yaw, pitch};
    }

    public static float[] getRotations5(Entity curTarget) {
        double diffY;
        if (curTarget == null) {
            return null;
        }
        Minecraft.getMinecraft();
        double diffX = curTarget.posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double diffZ = curTarget.posZ - Minecraft.thePlayer.posZ;
        if (curTarget instanceof EntityLivingBase) {
            EntityLivingBase elb = (EntityLivingBase)curTarget;
            double d = elb.posY + ((double)elb.getEyeHeight() - 0.6);
            Minecraft.getMinecraft();
            Minecraft.getMinecraft();
            diffY = d - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        } else {
            double d = (curTarget.boundingBox.minY + curTarget.boundingBox.maxY) / 2.0;
            Minecraft.getMinecraft();
            Minecraft.getMinecraft();
            diffY = d - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        }
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float[] getNeededRotations(Entity target) {
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        double d = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight();
        Minecraft.getMinecraft();
        Vec3 eyesPos = new Vec3(Minecraft.thePlayer.posX, d, Minecraft.thePlayer.posZ);
        double diffX = target.posX - eyesPos.xCoord;
        double diffY = target.posY - eyesPos.yCoord;
        double diffZ = target.posZ - eyesPos.zCoord;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[]{MathHelper.wrapAngleTo180_float(yaw), MathHelper.wrapAngleTo180_float(pitch)};
    }

    public static float[] getRotationFromPosition(double x, double z, double y) {
        Minecraft.getMinecraft();
        double xDiff = x - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double zDiff = z - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        double yDiff = y - Minecraft.thePlayer.posY - 1.2;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float getTrajAngleSolutionLow(float d3, float d1, float velocity) {
        float g = 0.006f;
        float sqrt = velocity * velocity * velocity * velocity - g * (g * d3 * d3 + 2.0f * d1 * velocity * velocity);
        return (float)Math.toDegrees(Math.atan(((double)(velocity * velocity) - Math.sqrt(sqrt)) / (double)(g * d3)));
    }

    public static float getYawChange(double posX, double posZ) {
        Minecraft.getMinecraft();
        double deltaX = posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double deltaZ = posZ - Minecraft.thePlayer.posZ;
        double yawToEntity = deltaZ < 0.0 && deltaX < 0.0 ? 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX)) : (deltaZ < 0.0 && deltaX > 0.0 ? -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX)) : Math.toDegrees(-Math.atan(deltaX / deltaZ)));
        Minecraft.getMinecraft();
        return MathHelper.wrapAngleTo180_float(-(Minecraft.thePlayer.rotationYaw - (float)yawToEntity));
    }

    public static float getYawChangeGiven(double posX, double posZ, float yaw) {
        Minecraft.getMinecraft();
        double deltaX = posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double deltaZ = posZ - Minecraft.thePlayer.posZ;
        double yawToEntity = deltaZ < 0.0 && deltaX < 0.0 ? 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX)) : (deltaZ < 0.0 && deltaX > 0.0 ? -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX)) : Math.toDegrees(-Math.atan(deltaX / deltaZ)));
        return MathHelper.wrapAngleTo180_float(-(yaw - (float)yawToEntity));
    }

    public static float getPitchChange(Entity entity, double posY) {
        Minecraft.getMinecraft();
        double deltaX = entity.posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double deltaZ = entity.posZ - Minecraft.thePlayer.posZ;
        double d = posY - 2.2 + (double)entity.getEyeHeight();
        Minecraft.getMinecraft();
        double deltaY = d - Minecraft.thePlayer.posY;
        double distanceXZ = MathHelper.sqrt_double(deltaX * deltaX + deltaZ * deltaZ);
        double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));
        Minecraft.getMinecraft();
        return -MathHelper.wrapAngleTo180_float(Minecraft.thePlayer.rotationPitch - (float)pitchToEntity) - 2.5f;
    }

    public static float getNewAngle(float angle) {
        if ((angle %= 360.0f) >= 180.0f) {
            angle -= 360.0f;
        }
        if (angle < -180.0f) {
            angle += 360.0f;
        }
        return angle;
    }

    public static float getDistanceBetweenAngles(float angle1, float angle2) {
        float angle = Math.abs(angle1 - angle2) % 360.0f;
        if (angle > 180.0f) {
            angle = 360.0f - angle;
        }
        return angle;
    }
}

