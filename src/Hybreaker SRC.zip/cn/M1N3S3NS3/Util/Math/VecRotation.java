/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Math;

import cn.M1N3S3NS3.Util.Rotation;
import net.minecraft.util.Vec3;

public class VecRotation {
    Vec3 vec;
    Rotation rotation;

    public VecRotation(Vec3 vec, Rotation rotation) {
        this.vec = vec;
        this.rotation = rotation;
    }

    public Rotation getRotation() {
        return this.rotation;
    }
}

