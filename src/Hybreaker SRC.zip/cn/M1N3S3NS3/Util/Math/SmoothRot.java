/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Math;

import cn.M1N3S3NS3.Util.Math.RaycastUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class SmoothRot {
    private static final Minecraft MC = Minecraft.getMinecraft();
    public static float serverYaw;
    public static float serverPitch;

    public static final float[] getRotations(Entity entity, boolean predict, double predictionFactor) {
        Vec3 playerPos = new Vec3(Minecraft.thePlayer.posX + (predict ? Minecraft.thePlayer.motionX * predictionFactor : 0.0), Minecraft.thePlayer.posY + (double)(entity instanceof EntityLivingBase ? Minecraft.thePlayer.getEyeHeight() : 0.0f) + (predict ? Minecraft.thePlayer.motionY * predictionFactor : 0.0), Minecraft.thePlayer.posZ + (predict ? Minecraft.thePlayer.motionZ * predictionFactor : 0.0));
        Vec3 entityPos = new Vec3(entity.posX + (predict ? (entity.posX - entity.prevPosX) * predictionFactor : 0.0), entity.posY + (predict ? (entity.posY - entity.prevPosY) * predictionFactor : 0.0), entity.posZ + (predict ? (entity.posZ - entity.prevPosZ) * predictionFactor : 0.0));
        double diffX = entityPos.xCoord - playerPos.xCoord;
        double diffY = entity instanceof EntityLivingBase ? entityPos.yCoord + (double)((EntityLivingBase)entity).getEyeHeight() - playerPos.yCoord : entityPos.yCoord - playerPos.yCoord;
        double diffZ = entityPos.zCoord - playerPos.zCoord;
        double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);
        double yaw = Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0;
        double pitch = -Math.toDegrees(Math.atan2(diffY, dist));
        return new float[]{(float)yaw, (float)pitch};
    }

    public final float[] getRotations(Vec3 pos, boolean predict, double predictionFactor) {
        Vec3 playerPos = new Vec3(Minecraft.thePlayer.posX + (predict ? Minecraft.thePlayer.motionX * predictionFactor : 0.0), Minecraft.thePlayer.posY + (predict ? Minecraft.thePlayer.motionY * predictionFactor : 0.0), Minecraft.thePlayer.posZ + (predict ? Minecraft.thePlayer.motionZ * predictionFactor : 0.0));
        double diffX = pos.xCoord + 0.5 - playerPos.xCoord;
        double diffY = pos.yCoord + 0.5 - (playerPos.yCoord + (double)Minecraft.thePlayer.getEyeHeight());
        double diffZ = pos.zCoord + 0.5 - playerPos.zCoord;
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        double yaw = Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0;
        double pitch = -Math.toDegrees(Math.atan2(diffY, dist));
        yaw = (double)Minecraft.thePlayer.rotationYaw + MathHelper.wrapAngleTo180_double(yaw - (double)Minecraft.thePlayer.rotationYaw);
        pitch = (double)Minecraft.thePlayer.rotationPitch + MathHelper.wrapAngleTo180_double(pitch - (double)Minecraft.thePlayer.rotationPitch);
        return new float[]{(float)yaw, (float)pitch};
    }

    public final Vec3 getVectorForRotation(float yaw, float pitch) {
        double f = Math.cos(Math.toRadians(-yaw) - Math.PI);
        double f1 = Math.sin(Math.toRadians(-yaw) - Math.PI);
        double f2 = -Math.cos(Math.toRadians(-pitch));
        double f3 = Math.sin(Math.toRadians(-pitch));
        return new Vec3(f1 * f2, f3, f * f2);
    }

    public static final float getDifference(float a, float b) {
        float r = (float)((double)(a - b) % 360.0);
        if ((double)r < -180.0) {
            r = (float)((double)r + 360.0);
        }
        if ((double)r >= 180.0) {
            r = (float)((double)r - 360.0);
        }
        return r;
    }

    public final double getRotationDifference(float[] clientRotations, float[] serverRotations) {
        return Math.hypot(SmoothRot.getDifference(clientRotations[0], serverRotations[0]), clientRotations[1] - serverRotations[1]);
    }

    public final double getRotationDifference(Entity entity) {
        float[] rotations = SmoothRot.getRotations(entity, false, 1.0);
        return this.getRotationDifference(rotations, new float[]{Minecraft.thePlayer.rotationYaw, Minecraft.thePlayer.rotationPitch});
    }

    public static final float[] smoothRotation(float[] currentRotations, float[] neededRotations, float rotationSpeed) {
        float yawDiff = SmoothRot.getDifference(neededRotations[0], currentRotations[0]);
        float pitchDiff = SmoothRot.getDifference(neededRotations[1], currentRotations[1]);
        float rotationSpeedYaw = rotationSpeed;
        rotationSpeedYaw = yawDiff > rotationSpeed ? rotationSpeed : Math.max(yawDiff, -rotationSpeed);
        float rotationSpeedPitch = rotationSpeed;
        rotationSpeedPitch = pitchDiff > rotationSpeed ? rotationSpeed : Math.max(pitchDiff, -rotationSpeed);
        float newYaw = currentRotations[0] + rotationSpeedYaw;
        float newPitch = currentRotations[1] + rotationSpeedPitch;
        return new float[]{newYaw, newPitch};
    }

    public final boolean isFaced(double range) {
        return RaycastUtil.raycastEntity(range, new float[]{serverYaw, serverPitch}) != null;
    }

    public final void setRotations(float yaw, float pitch) {
        serverYaw = yaw;
        serverPitch = pitch;
    }

    public final void setRotations(float[] rotations) {
        this.setRotations(rotations[0], rotations[1]);
    }

    public final float[] getServerRotations() {
        return new float[]{serverYaw, serverPitch};
    }
}

