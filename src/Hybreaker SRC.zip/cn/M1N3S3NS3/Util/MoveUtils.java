/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util;

import cn.M1N3S3NS3.API.Events.World.EventMove;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;

public class MoveUtils {
    private static Minecraft mc = Minecraft.getMinecraft();

    public static double defaultSpeed() {
        double baseSpeed = 0.2873;
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            Minecraft.getMinecraft();
            int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return baseSpeed;
    }

    public static boolean isMoving() {
        block2: {
            block3: {
                if (Minecraft.thePlayer == null) break block2;
                if (MovementInput.moveForward != 0.0f) break block3;
                if (MovementInput.moveStrafe == 0.0f) break block2;
            }
            return true;
        }
        return false;
    }

    public static float getSpeed() {
        return (float)Math.sqrt(Minecraft.thePlayer.motionX * Minecraft.thePlayer.motionX + Minecraft.thePlayer.motionZ * Minecraft.thePlayer.motionZ);
    }

    public static void strafe() {
        MoveUtils.strafe(MoveUtils.getSpeed());
    }

    public static double getDirection() {
        float rotationYaw = Minecraft.thePlayer.rotationYaw;
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            rotationYaw += 180.0f;
        }
        float forward = 1.0f;
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else if (Minecraft.thePlayer.moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (Minecraft.thePlayer.moveStrafing > 0.0f) {
            rotationYaw -= 90.0f * forward;
        }
        if (Minecraft.thePlayer.moveStrafing < 0.0f) {
            rotationYaw += 90.0f * forward;
        }
        return Math.toRadians(rotationYaw);
    }

    public static void strafe(float speed) {
        if (!MoveUtils.isMoving()) {
            return;
        }
        double yaw = MoveUtils.getDirection();
        Minecraft.thePlayer.motionX = -Math.sin(yaw) * (double)speed;
        Minecraft.thePlayer.motionZ = Math.cos(yaw) * (double)speed;
    }

    public static void strafe(double speed) {
        float a = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180);
        float l = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180) - 4.712389f;
        float r = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180) + 4.712389f;
        float rf = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180) + 0.5969026f;
        float lf = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180) + -0.5969026f;
        float lb = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180) - 2.3876104f;
        float rb = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180) - -2.3876104f;
        if (MoveUtils.mc.gameSettings.keyBindForward.pressed) {
            if (MoveUtils.mc.gameSettings.keyBindLeft.pressed && !MoveUtils.mc.gameSettings.keyBindRight.pressed) {
                Minecraft.thePlayer.motionX -= (double)MathHelper.sin(lf) * speed;
                Minecraft.thePlayer.motionZ += (double)MathHelper.cos(lf) * speed;
            } else if (MoveUtils.mc.gameSettings.keyBindRight.pressed && !MoveUtils.mc.gameSettings.keyBindLeft.pressed) {
                Minecraft.thePlayer.motionX -= (double)MathHelper.sin(rf) * speed;
                Minecraft.thePlayer.motionZ += (double)MathHelper.cos(rf) * speed;
            } else {
                Minecraft.thePlayer.motionX -= (double)MathHelper.sin(a) * speed;
                Minecraft.thePlayer.motionZ += (double)MathHelper.cos(a) * speed;
            }
        } else if (MoveUtils.mc.gameSettings.keyBindBack.pressed) {
            if (MoveUtils.mc.gameSettings.keyBindLeft.pressed && !MoveUtils.mc.gameSettings.keyBindRight.pressed) {
                Minecraft.thePlayer.motionX -= (double)MathHelper.sin(lb) * speed;
                Minecraft.thePlayer.motionZ += (double)MathHelper.cos(lb) * speed;
            } else if (MoveUtils.mc.gameSettings.keyBindRight.pressed && !MoveUtils.mc.gameSettings.keyBindLeft.pressed) {
                Minecraft.thePlayer.motionX -= (double)MathHelper.sin(rb) * speed;
                Minecraft.thePlayer.motionZ += (double)MathHelper.cos(rb) * speed;
            } else {
                Minecraft.thePlayer.motionX += (double)MathHelper.sin(a) * speed;
                Minecraft.thePlayer.motionZ -= (double)MathHelper.cos(a) * speed;
            }
        } else if (MoveUtils.mc.gameSettings.keyBindLeft.pressed && !MoveUtils.mc.gameSettings.keyBindRight.pressed && !MoveUtils.mc.gameSettings.keyBindForward.pressed && !MoveUtils.mc.gameSettings.keyBindBack.pressed) {
            Minecraft.thePlayer.motionX += (double)MathHelper.sin(l) * speed;
            Minecraft.thePlayer.motionZ -= (double)MathHelper.cos(l) * speed;
        } else if (MoveUtils.mc.gameSettings.keyBindRight.pressed && !MoveUtils.mc.gameSettings.keyBindLeft.pressed && !MoveUtils.mc.gameSettings.keyBindForward.pressed && !MoveUtils.mc.gameSettings.keyBindBack.pressed) {
            Minecraft.thePlayer.motionX += (double)MathHelper.sin(r) * speed;
            Minecraft.thePlayer.motionZ -= (double)MathHelper.cos(r) * speed;
        }
    }

    public static void setMotion(double speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            Minecraft.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f));
            Minecraft.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f));
        }
    }

    public static boolean checkTeleport(double x, double y, double z, double distBetweenPackets) {
        double distx = Minecraft.thePlayer.posX - x;
        double disty = Minecraft.thePlayer.posY - y;
        double distz = Minecraft.thePlayer.posZ - z;
        double dist = Math.sqrt(Minecraft.thePlayer.getDistanceSq(x, y, z));
        double distanceEntreLesPackets = distBetweenPackets;
        double nbPackets = Math.round(dist / distanceEntreLesPackets + 0.49999999999) - 1L;
        double xtp = Minecraft.thePlayer.posX;
        double ytp = Minecraft.thePlayer.posY;
        double ztp = Minecraft.thePlayer.posZ;
        int i = 1;
        while ((double)i < nbPackets) {
            AxisAlignedBB bb;
            double xdi = (x - Minecraft.thePlayer.posX) / nbPackets;
            double ydi = (y - Minecraft.thePlayer.posY) / nbPackets;
            double zdi = (z - Minecraft.thePlayer.posZ) / nbPackets;
            if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb = new AxisAlignedBB((xtp += xdi) - 0.3, ytp += ydi, (ztp += zdi) - 0.3, xtp + 0.3, ytp + 1.8, ztp + 0.3)).isEmpty()) {
                return false;
            }
            ++i;
        }
        return true;
    }

    public static boolean isOnGround(double height) {
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, -height, 0.0)).isEmpty();
    }

    public static int getJumpEffect() {
        if (Minecraft.thePlayer.isPotionActive(Potion.jump)) {
            return Minecraft.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1;
        }
        return 0;
    }

    public static int getSpeedEffect() {
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            return Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1;
        }
        return 0;
    }

    public static Block getBlockUnderPlayer(EntityPlayer inPlayer, double height) {
        Minecraft.getMinecraft();
        return Minecraft.theWorld.getBlockState(new BlockPos(inPlayer.posX, inPlayer.posY - height, inPlayer.posZ)).getBlock();
    }

    public static Block getBlockAtPosC(double x, double y, double z) {
        Minecraft.getMinecraft();
        EntityPlayerSP inPlayer = Minecraft.thePlayer;
        Minecraft.getMinecraft();
        return Minecraft.theWorld.getBlockState(new BlockPos(inPlayer.posX + x, inPlayer.posY + y, inPlayer.posZ + z)).getBlock();
    }

    public static float getDistanceToGround(Entity e) {
        if (Minecraft.thePlayer.isCollidedVertically && Minecraft.thePlayer.onGround) {
            return 0.0f;
        }
        float a = (float)e.posY;
        while (a > 0.0f) {
            int[] stairs = new int[]{53, 67, 108, 109, 114, 128, 134, 135, 136, 156, 163, 164, 180};
            int[] exemptIds = new int[]{6, 27, 28, 30, 31, 32, 37, 38, 39, 40, 50, 51, 55, 59, 63, 65, 66, 68, 69, 70, 72, 75, 76, 77, 83, 92, 93, 94, 104, 105, 106, 115, 119, 131, 132, 143, 147, 148, 149, 150, 157, 171, 175, 176, 177};
            Block block = Minecraft.theWorld.getBlockState(new BlockPos(e.posX, a - 1.0f, e.posZ)).getBlock();
            if (!(block instanceof BlockAir)) {
                int id;
                if (Block.getIdFromBlock(block) == 44 || Block.getIdFromBlock(block) == 126) {
                    return (float)(e.posY - (double)a - 0.5) < 0.0f ? 0.0f : (float)(e.posY - (double)a - 0.5);
                }
                int[] arrayOfInt1 = stairs;
                int j = stairs.length;
                int i = 0;
                while (i < j) {
                    id = arrayOfInt1[i];
                    if (Block.getIdFromBlock(block) == id) {
                        return (float)(e.posY - (double)a - 1.0) < 0.0f ? 0.0f : (float)(e.posY - (double)a - 1.0);
                    }
                    ++i;
                }
                arrayOfInt1 = exemptIds;
                j = exemptIds.length;
                i = 0;
                while (i < j) {
                    id = arrayOfInt1[i];
                    if (Block.getIdFromBlock(block) == id) {
                        return (float)(e.posY - (double)a) < 0.0f ? 0.0f : (float)(e.posY - (double)a);
                    }
                    ++i;
                }
                return (float)(e.posY - (double)a + block.getBlockBoundsMaxY() - 1.0);
            }
            a -= 1.0f;
        }
        return 0.0f;
    }

    public static float[] getRotationsBlock(BlockPos block, EnumFacing face) {
        double x = (double)block.getX() + 0.5 - Minecraft.thePlayer.posX + (double)face.getFrontOffsetX() / 2.0;
        double z = (double)block.getZ() + 0.5 - Minecraft.thePlayer.posZ + (double)face.getFrontOffsetZ() / 2.0;
        double y = (double)block.getY() + 0.5;
        double d1 = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight() - y;
        double d3 = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float)(Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(Math.atan2(d1, d3) * 180.0 / Math.PI);
        if (yaw < 0.0f) {
            yaw += 360.0f;
        }
        return new float[]{yaw, pitch};
    }

    public static boolean isBlockAboveHead() {
        AxisAlignedBB bb = new AxisAlignedBB(Minecraft.thePlayer.posX - 0.3, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ + 0.3, Minecraft.thePlayer.posX + 0.3, Minecraft.thePlayer.posY + 2.5, Minecraft.thePlayer.posZ - 0.3);
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb).isEmpty();
    }

    public static boolean isCollidedH(double dist) {
        AxisAlignedBB bb = new AxisAlignedBB(Minecraft.thePlayer.posX - 0.3, Minecraft.thePlayer.posY + 2.0, Minecraft.thePlayer.posZ + 0.3, Minecraft.thePlayer.posX + 0.3, Minecraft.thePlayer.posY + 3.0, Minecraft.thePlayer.posZ - 0.3);
        if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(0.3 + dist, 0.0, 0.0)).isEmpty()) {
            return true;
        }
        if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(-0.3 - dist, 0.0, 0.0)).isEmpty()) {
            return true;
        }
        if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(0.0, 0.0, 0.3 + dist)).isEmpty()) {
            return true;
        }
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(0.0, 0.0, -0.3 - dist)).isEmpty();
    }

    public static boolean isRealCollidedH(double dist) {
        AxisAlignedBB bb = new AxisAlignedBB(Minecraft.thePlayer.posX - 0.3, Minecraft.thePlayer.posY + 0.5, Minecraft.thePlayer.posZ + 0.3, Minecraft.thePlayer.posX + 0.3, Minecraft.thePlayer.posY + 1.9, Minecraft.thePlayer.posZ - 0.3);
        if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(0.3 + dist, 0.0, 0.0)).isEmpty()) {
            return true;
        }
        if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(-0.3 - dist, 0.0, 0.0)).isEmpty()) {
            return true;
        }
        if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(0.0, 0.0, 0.3 + dist)).isEmpty()) {
            return true;
        }
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(0.0, 0.0, -0.3 - dist)).isEmpty();
    }

    public static void setSpeed(EventMove moveEvent, double moveSpeed, float pseudoYaw, double pseudoStrafe, double pseudoForward) {
        double forward = pseudoForward;
        double strafe = pseudoStrafe;
        float yaw = pseudoYaw;
        if (forward != 0.0) {
            if (strafe > 0.0) {
                yaw += (float)(forward > 0.0 ? -45 : 45);
            } else if (strafe < 0.0) {
                yaw += (float)(forward > 0.0 ? 45 : -45);
            }
            strafe = 0.0;
            if (forward > 0.0) {
                forward = 1.0;
            } else if (forward < 0.0) {
                forward = -1.0;
            }
        }
        if (strafe > 0.0) {
            strafe = 1.0;
        } else if (strafe < 0.0) {
            strafe = -1.0;
        }
        double mx = Math.cos(Math.toRadians(yaw + 90.0f));
        double mz = Math.sin(Math.toRadians(yaw + 90.0f));
        EventMove.x = forward * moveSpeed * mx + strafe * moveSpeed * mz;
        EventMove.z = forward * moveSpeed * mz - strafe * moveSpeed * mx;
    }

    public static void setMotion(EventMove e, double speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            if (e != null) {
                e.setX(0.0);
                e.setZ(0.0);
            } else {
                Minecraft.thePlayer.motionX = 0.0;
                Minecraft.thePlayer.motionZ = 0.0;
            }
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            if (e != null) {
                e.setX(forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 91.5f)));
                e.setZ(forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.25f)));
            } else {
                Minecraft.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 91.5f));
                Minecraft.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.25f));
            }
        }
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed = 0.2873;
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            baseSpeed *= 1.0 + 0.2 * (double)(Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1);
        }
        return baseSpeed;
    }

    public static void setMotionWithValues(EventMove em, double speed, float yaw, double forward, double strafe) {
        if (forward == 0.0 && strafe == 0.0) {
            if (em != null) {
                em.setX(0.0);
                em.setZ(0.0);
            } else {
                Minecraft.thePlayer.motionX = 0.0;
                Minecraft.thePlayer.motionZ = 0.0;
            }
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            if (em != null) {
                em.setX(forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f)));
                em.setZ(forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f)));
            } else {
                Minecraft.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f));
                Minecraft.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f));
            }
        }
    }

    public static float getSpeed(EntityLivingBase e) {
        return (float)Math.sqrt((e.posX - e.prevPosX) * (e.posX - e.prevPosX) + (e.posZ - e.prevPosZ) * (e.posZ - e.prevPosZ));
    }

    public static boolean isBlockUnderneath(BlockPos pos) {
        int k = 0;
        while (k < pos.getY() + 1) {
            if (Minecraft.theWorld.getBlockState(new BlockPos(pos.getX(), k, pos.getZ())).getBlock().getMaterial() != Material.air) {
                return true;
            }
            ++k;
        }
        return false;
    }

    public static double getBaseSpeed() {
        double baseSpeed = 0.2873;
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            Minecraft.getMinecraft();
            int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return baseSpeed;
    }

    public static void setMotionWithValues(double speed, float yaw, double forward, double strafe) {
        if (forward == 0.0 && strafe == 0.0) {
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            Minecraft.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f));
            Minecraft.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f));
        }
    }
}

