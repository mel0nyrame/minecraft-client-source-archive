/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Theing;

import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

public class SystemUtil {
    public static String readClipboard() {
        try {
            return (String)Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
        }
        catch (HeadlessException | UnsupportedFlavorException | IOException e) {
            e.printStackTrace();
            return null;
        }
    }
}

