/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Theing;

public enum FieldType {
    ANY,
    NUMBERS,
    LETTERS,
    NUMBER_LETTERS,
    NUMBERS_LETTERS_SPECIAL;

}

