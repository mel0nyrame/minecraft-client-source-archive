/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Theing;

import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.Util.Theing.Render2DUtil;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;

public class MenuButton
extends GuiButton {
    public boolean hovered;
    private int buttonId;
    private int x;
    private int y;
    private int widthIn;
    private int heightIn;
    private String buttonText;

    public MenuButton(int buttonId, int x, int y, int widthIn, int heightIn, String buttonText) {
        super(buttonId, x, y, widthIn, heightIn, buttonText);
        this.buttonId = buttonId;
        this.x = x;
        this.y = y;
        this.widthIn = widthIn;
        this.heightIn = heightIn;
        this.buttonText = buttonText;
    }

    public String getButtonText() {
        return this.buttonText;
    }

    public void setButtonText(String buttonText) {
        this.buttonText = buttonText;
    }

    @Override
    public boolean isMouseOver() {
        return this.hovered;
    }

    @Override
    public void drawButton(Minecraft mc, int mouseX, int mouseY) {
        this.hovered = mouseX >= this.xPosition + 30 && mouseY >= this.yPosition && mouseX < this.xPosition + this.width - 30 && mouseY < this.yPosition + this.height;
        int color = this.hovered ? new Color(112, 112, 112).getRGB() : new Color(65, 65, 65).getRGB();
        Render2DUtil.drawGradientRect(this.x + 30, this.y, this.x + this.widthIn - 30, this.y + this.heightIn, new Color(35, 35, 35).getRGB(), new Color(27, 27, 27).getRGB());
        Render2DUtil.drawOutline(this.x + 30, this.y, this.widthIn - 60, this.heightIn, 0.5, color);
        FontLoaders.Comfortaa16.drawCenteredStringWithShadow(this.buttonText, this.x + this.widthIn / 2, this.y + this.heightIn / 2 - 2, new Color(166, 166, 166).getRGB());
    }
}

