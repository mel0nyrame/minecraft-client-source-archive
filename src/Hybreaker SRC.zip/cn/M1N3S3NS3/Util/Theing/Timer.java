/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Theing;

public class Timer {
    private long lastMS = this.getCurrentMS();

    private long getCurrentMS() {
        return System.nanoTime() / 1000000L;
    }

    public boolean hasReached(long milliseconds) {
        return this.getCurrentMS() - this.lastMS >= milliseconds;
    }

    public void reset() {
        this.lastMS = this.getCurrentMS();
    }
}

