/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package cn.M1N3S3NS3.Util.Theing;

import cn.M1N3S3NS3.UI.Font.CFontRenderer;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.Util.Theing.FieldType;
import cn.M1N3S3NS3.Util.Theing.Render2DUtil;
import cn.M1N3S3NS3.Util.Theing.SystemUtil;
import cn.M1N3S3NS3.Util.Theing.Timer;
import java.awt.Color;
import java.io.IOException;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Keyboard;

public class TextField
extends Gui {
    CFontRenderer fontRenderer = FontLoaders.Comfortaa16;
    private int posX;
    private int posY;
    private int width;
    private int height;
    private String defaultContent;
    private String typedContent;
    private int defaultTextColor;
    private int typedTextColor;
    private int backgroundColor;
    private int borderColor;
    private int focusedBackgroundColor;
    private int focusedBorderColor;
    private double borderWidth;
    private int charLimit;
    private FieldType type;
    private boolean focused;
    private char character;
    private int key;
    private int ticksKeyDown;
    private Timer keyTimer;
    private String replaceAll;
    private int startIndex;
    private boolean hidden;

    public TextField(CFontRenderer fontRenderer, int posX, int posY, int width, int height) {
        this.fontRenderer = fontRenderer;
        this.posX = posX;
        this.posY = posY;
        this.width = width;
        this.height = height;
        this.defaultContent = "";
        this.typedContent = "";
        this.defaultTextColor = new Color(180, 180, 180).getRGB();
        this.typedTextColor = new Color(230, 230, 230).getRGB();
        this.backgroundColor = new Color(15, 15, 15, 255).getRGB();
        this.borderColor = new Color(10, 10, 10, 255).getRGB();
        this.focusedBackgroundColor = new Color(10, 10, 10, 255).getRGB();
        this.focusedBorderColor = new Color(0, 0, 0).getRGB();
        this.borderWidth = 1.0;
        this.charLimit = -1;
        this.type = FieldType.ANY;
        this.focused = false;
        this.key = 0;
        this.ticksKeyDown = 0;
        this.keyTimer = new Timer();
        this.replaceAll = "";
        this.startIndex = 0;
        this.hidden = false;
    }

    public void initTextField() {
        this.focused = false;
        this.ticksKeyDown = 0;
    }

    public void updateTextField() {
        if (this.key != 0) {
            if (Keyboard.isKeyDown((int)this.key)) {
                ++this.ticksKeyDown;
            } else {
                this.key = 0;
                this.ticksKeyDown = 0;
                return;
            }
        }
    }

    public void keyTyped(char typedChar, int keyCode) throws IOException {
        if (!this.focused) {
            return;
        }
        if (keyCode == 1) {
            this.focused = false;
            return;
        }
        if (keyCode != this.key) {
            this.character = typedChar;
            this.key = keyCode;
            this.ticksKeyDown = 0;
            this.keyTimer.reset();
        }
        if (keyCode == 14 || keyCode == 211) {
            this.backspace();
            return;
        }
        if (keyCode == 47 && (Keyboard.isKeyDown((int)157) || Keyboard.isKeyDown((int)29))) {
            String clipboardContent = SystemUtil.readClipboard();
            this.typedContent = String.valueOf(this.typedContent) + clipboardContent;
            return;
        }
        String charAsString = Character.toString(typedChar);
        if (typedChar != ' ') {
            switch (this.type) {
                case LETTERS: {
                    if (Character.isLetter(typedChar)) break;
                    return;
                }
                case NUMBERS: {
                    if (Character.isDigit(typedChar)) break;
                    return;
                }
                case NUMBER_LETTERS: {
                    if (Character.isLetter(typedChar) || Character.isDigit(typedChar)) break;
                    return;
                }
                case NUMBERS_LETTERS_SPECIAL: {
                    boolean specialChar = false;
                    String specialChars = "-/*!@#$%^&*()\"{}_[]|\\?/<>,.";
                    int i = 0;
                    while (i < specialChars.length()) {
                        char special = specialChars.charAt(i);
                        if (typedChar == special) {
                            specialChar = true;
                        }
                        ++i;
                    }
                    if (Character.isLetter(typedChar) || Character.isDigit(typedChar) || specialChar) break;
                    return;
                }
                case ANY: {
                    break;
                }
            }
        }
        if (this.charLimit != -1 && this.typedContent.length() >= this.charLimit) {
            return;
        }
        this.typedContent = String.valueOf(this.typedContent) + charAsString;
        if (this.fontRenderer.getStringWidth(this.typedContent) >= this.width - 4) {
            ++this.startIndex;
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        this.focused = mouseX >= this.posX && mouseY >= this.posY && mouseX <= this.posX + this.width && mouseY <= this.posY + this.height;
    }

    public void drawTextField() {
        if (this.hidden) {
            return;
        }
        Render2DUtil.drawBorderedRect(this.posX, this.posY, this.posX + this.width, this.posY + this.height, 1.0, this.focused ? this.focusedBackgroundColor : this.backgroundColor, this.focused ? this.focusedBorderColor : this.borderColor, true);
        String content = this.getReplacedContent().substring(this.startIndex);
        this.fontRenderer.drawString(this.typedContent.isEmpty() ? this.defaultContent : (this.replaceAll != "" ? content.replaceAll(".", this.replaceAll) : content), this.posX + 1, this.posY + this.height / 2 - this.fontRenderer.getHeight() / 2, this.typedContent.isEmpty() ? this.defaultTextColor : this.typedTextColor);
        if (this.focused) {
            Render2DUtil.drawRect((double)(this.typedContent.isEmpty() ? this.posX + 2 : this.posX + 2 + this.fontRenderer.getStringWidth(content)), (double)(this.posY + this.height / 2 + this.fontRenderer.getHeight() / 2), (double)(this.typedContent.isEmpty() ? this.posX + 5 : this.posX + 5 + this.fontRenderer.getStringWidth(content)), (double)(this.posY + this.height / 2 + this.fontRenderer.getHeight() / 2 + 1), -1);
        }
        if (this.ticksKeyDown == 10) {
            this.keyTimer.reset();
        } else if (this.ticksKeyDown > 5 && this.ticksKeyDown < 25) {
            if (this.keyTimer.hasReached(100L)) {
                try {
                    this.keyTyped(this.character, this.key);
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
                this.keyTimer.reset();
            }
        } else if (this.ticksKeyDown > 25 && this.keyTimer.hasReached(25L)) {
            try {
                this.keyTyped(this.character, this.key);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            this.keyTimer.reset();
        }
    }

    public void backspace() {
        if (!this.typedContent.isEmpty()) {
            this.typedContent = this.typedContent.substring(0, this.typedContent.length() - 1);
            if (this.startIndex > 0) {
                --this.startIndex;
            }
        }
    }

    public String getReplacedContent() {
        return this.replaceAll != "" ? this.typedContent.replaceAll(".", this.replaceAll) : this.typedContent;
    }

    public String getTypedContentFormatted() {
        return this.trimStringToWidth(this.getReplacedContent(), this.width - 2);
    }

    public String trimStringToWidth(String string, int width) {
        if (this.fontRenderer.getStringWidth(string) > width) {
            return this.trimStringToWidth(string.substring(0, string.length() - 1), width);
        }
        return string;
    }

    public String getTypedContent() {
        return this.typedContent;
    }

    public String getDefaultContent() {
        return this.defaultContent;
    }

    public void setDefaultContent(String defaultContent) {
        this.defaultContent = defaultContent;
    }

    public FieldType getType() {
        return this.type;
    }

    public void setType(FieldType type) {
        this.type = type;
    }

    public boolean isFocused() {
        return this.focused;
    }

    public void setFocused(boolean focused) {
        this.focused = focused;
    }

    public String getReplaceAll() {
        return this.replaceAll;
    }

    public void setReplaceAll(String replaceAll) {
        this.replaceAll = replaceAll;
    }

    public void setTypedContent(String typedContent) {
        this.typedContent = typedContent;
    }

    public boolean isHidden() {
        return this.hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }
}

