/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Iterables
 *  com.google.common.collect.Lists
 *  org.lwjgl.input.Mouse
 */
package cn.M1N3S3NS3.Util;

import cn.M1N3S3NS3.API.EventBus;
import cn.M1N3S3NS3.API.Events.Misc.MouseEvent;
import cn.M1N3S3NS3.API.Value.Numbers;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import java.awt.Color;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;
import net.minecraft.util.StringUtils;
import net.minecraft.util.Timer;
import org.lwjgl.input.Mouse;

public class ay {
    private static final Random rand = new Random();
    public static final Minecraft mc = Minecraft.getMinecraft();
    public static final String s = "\u00a7";
    public static final String pr = new String(new char[]{'&', '7', '[', '&', 'd', 'R', '&', '7', ']', '&', 'r'});
    public static final String md = new String(new char[]{'M', 'o', 'd', 'e', ':', ' '});
    public static final String hp = new String(new char[]{'h', 'y', 'p', 'i', 'x', 'e', 'l', '.', 'n', 'e', 't'});
    private static Field t = null;
    private static Field g = null;
    private static Field f = null;
    private static Field h = null;

    public static void su() {
        try {
            t = Minecraft.class.getDeclaredField(new String(new char[]{'f', 'i', 'e', 'l', 'd', '_', '7', '1', '4', '2', '8', '_', 'T'}));
        }
        catch (Exception er) {
            try {
                t = Minecraft.class.getDeclaredField(new String(new char[]{'t', 'i', 'm', 'e', 'r'}));
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        if (t != null) {
            t.setAccessible(true);
        }
        try {
            g = MouseEvent.class.getDeclaredField(new String(new char[]{'b', 'u', 't', 't', 'o', 'n'}));
            f = MouseEvent.class.getDeclaredField(new String(new char[]{'b', 'u', 't', 't', 'o', 'n', 's', 't', 'a', 't', 'e'}));
            h = Mouse.class.getDeclaredField(new String(new char[]{'b', 'u', 't', 't', 'o', 'n', 's'}));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void sc(int t2, boolean s) {
        if (g == null || f == null || h == null) {
            return;
        }
        MouseEvent m2 = new MouseEvent();
        try {
            g.setAccessible(true);
            g.set(m2, t2);
            f.setAccessible(true);
            f.set(m2, s);
            EventBus.class.cast(m2);
            h.setAccessible(true);
            ByteBuffer bf2 = (ByteBuffer)h.get(null);
            h.setAccessible(false);
            bf2.put(t2, (byte)(s ? 1 : 0));
        }
        catch (IllegalAccessException illegalAccessException) {
            // empty catch block
        }
    }

    public static void sm(String txt) {
        if (!ay.e()) {
            return;
        }
        String m2 = ay.r(String.valueOf(pr) + " " + txt);
        Minecraft.thePlayer.addChatMessage(new ChatComponentText(m2));
    }

    public static String r(String txt) {
        return txt.replaceAll("&", s);
    }

    public static boolean e() {
        return Minecraft.thePlayer != null && Minecraft.theWorld != null;
    }

    public static boolean isHyp() {
        if (mc.isSingleplayer()) {
            return false;
        }
        return ay.mc.getCurrentServerData().serverIP.toLowerCase().contains(hp);
    }

    public static int f() {
        return mc.getNetHandler().getPlayerInfo(Minecraft.thePlayer.getUniqueID()).getResponseTime();
    }

    public static Timer gt() {
        try {
            return (Timer)t.get(mc);
        }
        catch (IllegalAccessException | IndexOutOfBoundsException er) {
            return null;
        }
    }

    public static void rt() {
        try {
            ay.gt();
            Timer.timerSpeed = 1.0f;
        }
        catch (NullPointerException nullPointerException) {
            // empty catch block
        }
    }

    public static Random rand() {
        return rand;
    }

    public static boolean im() {
        return Minecraft.thePlayer.moveForward != 0.0f || Minecraft.thePlayer.moveStrafing != 0.0f;
    }

    public static void aim(Entity en, float ps, boolean pc) {
        if (en == null) {
            return;
        }
        float[] t2 = ay.gr(en);
        if (t2 != null) {
            float y = t2[0];
            float p = t2[1] + 4.0f + ps;
            if (pc) {
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(y, p, Minecraft.thePlayer.onGround));
            } else {
                Minecraft.thePlayer.rotationYaw = y;
                Minecraft.thePlayer.rotationPitch = p;
            }
        }
    }

    public static float[] gr(Entity q) {
        double diffY;
        if (q == null) {
            return null;
        }
        double diffX = q.posX - Minecraft.thePlayer.posX;
        if (q instanceof EntityLivingBase) {
            EntityLivingBase en = (EntityLivingBase)q;
            diffY = en.posY + (double)en.getEyeHeight() * 0.9 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        } else {
            diffY = (q.getEntityBoundingBox().minY + q.getEntityBoundingBox().maxY) / 2.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        }
        double diffZ = q.posZ - Minecraft.thePlayer.posZ;
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
        return new float[]{Minecraft.thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(yaw - Minecraft.thePlayer.rotationYaw), Minecraft.thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float(pitch - Minecraft.thePlayer.rotationPitch)};
    }

    public static double n(Entity en) {
        return ((double)(Minecraft.thePlayer.rotationYaw - ay.m(en)) % 360.0 + 540.0) % 360.0 - 180.0;
    }

    public static float m(Entity ent) {
        double x = ent.posX - Minecraft.thePlayer.posX;
        double z = ent.posZ - Minecraft.thePlayer.posZ;
        double yaw = Math.atan2(x, z) * 57.2957795;
        return (float)(yaw * -1.0);
    }

    public static boolean fov(Entity entity, float fov) {
        fov = (float)((double)fov * 0.5);
        double v = ((double)(Minecraft.thePlayer.rotationYaw - ay.m(entity)) % 360.0 + 540.0) % 360.0 - 180.0;
        return v > 0.0 && v < (double)fov || (double)(-fov) < v && v < 0.0;
    }

    public static void ss(double s, boolean m2) {
        if (m2 && !ay.im()) {
            return;
        }
        Minecraft.thePlayer.motionX = -Math.sin(ay.gd()) * s;
        Minecraft.thePlayer.motionZ = Math.cos(ay.gd()) * s;
    }

    public static void ss2(double s) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            double rad = Math.toRadians(yaw + 90.0f);
            double sin = Math.sin(rad);
            double cos = Math.cos(rad);
            Minecraft.thePlayer.motionX = forward * s * cos + strafe * s * sin;
            Minecraft.thePlayer.motionZ = forward * s * sin - strafe * s * cos;
        }
    }

    public static float gd() {
        float f;
        float yw = Minecraft.thePlayer.rotationYaw;
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            yw += 180.0f;
        }
        float f2 = Minecraft.thePlayer.moveForward < 0.0f ? -0.5f : (f = Minecraft.thePlayer.moveForward > 0.0f ? 0.5f : 1.0f);
        if (Minecraft.thePlayer.moveStrafing > 0.0f) {
            yw -= 90.0f * f;
        }
        if (Minecraft.thePlayer.moveStrafing < 0.0f) {
            yw += 90.0f * f;
        }
        return yw *= (float)Math.PI / 180;
    }

    public static double gs() {
        return Math.sqrt(Minecraft.thePlayer.motionX * Minecraft.thePlayer.motionX + Minecraft.thePlayer.motionZ * Minecraft.thePlayer.motionZ);
    }

    public static double gbps(Entity en, int d) {
        double x = en.posX - en.prevPosX;
        double z = en.posZ - en.prevPosZ;
        double sp2 = Math.sqrt(x * x + z * z) * 20.0;
        return ay.rnd(sp2, d);
    }

    public static int gc(long speed, long ... delay) {
        long time = System.currentTimeMillis() + (delay.length > 0 ? delay[0] : 0L);
        return Color.getHSBColor((float)(time % (15000L / speed)) / (15000.0f / (float)speed), 1.0f, 1.0f).getRGB();
    }

    public static double rnd(double n, int d) {
        if (d == 0) {
            return Math.round(n);
        }
        double p = Math.pow(10.0, d);
        return (double)Math.round(n * p) / p;
    }

    public static String str(String s) {
        char[] n = StringUtils.stripControlCodes(s).toCharArray();
        StringBuilder v = new StringBuilder();
        char[] cArray = n;
        int n2 = n.length;
        int n3 = 0;
        while (n3 < n2) {
            char c = cArray[n3];
            if (c < '\u007f' && c > '\u0014') {
                v.append(c);
            }
            ++n3;
        }
        return v.toString();
    }

    public static List<String> gsl() {
        ArrayList<String> lines = new ArrayList<String>();
        if (Minecraft.theWorld == null) {
            return lines;
        }
        Scoreboard scoreboard = Minecraft.theWorld.getScoreboard();
        if (scoreboard == null) {
            return lines;
        }
        ScoreObjective objective = scoreboard.getObjectiveInDisplaySlot(1);
        if (objective == null) {
            return lines;
        }
        ArrayList<Score> scores = new ArrayList<Score>(scoreboard.getSortedScores(objective));
        ArrayList list = new ArrayList();
        for (Score input : scores) {
            if (input == null || input.getPlayerName() == null || input.getPlayerName().startsWith("#")) continue;
            list.add(input);
        }
        scores = list.size() > 15 ? Lists.newArrayList((Iterable)Iterables.skip(list, (int)(scores.size() - 15))) : list;
        for (Score score : scores) {
            ScorePlayerTeam team = scoreboard.getPlayersTeam(score.getPlayerName());
            lines.add(ScorePlayerTeam.formatPlayerName(team, score.getPlayerName()));
        }
        return lines;
    }

    public static void rsa() {
        int armSwingEnd;
        EntityPlayerSP p = Minecraft.thePlayer;
        int n = p.isPotionActive(Potion.digSpeed) ? 6 - (1 + p.getActivePotionEffect(Potion.digSpeed).getAmplifier()) * 1 : (armSwingEnd = p.isPotionActive(Potion.digSlowdown) ? 6 + (1 + p.getActivePotionEffect(Potion.digSlowdown).getAmplifier()) * 2 : 6);
        if (!p.isSwingInProgress || p.swingProgressInt >= armSwingEnd / 2 || p.swingProgressInt < 0) {
            p.swingProgressInt = -1;
            p.isSwingInProgress = true;
        }
    }

    public static String uf(String s) {
        return String.valueOf(s.substring(0, 1).toUpperCase()) + s.substring(1);
    }

    public static void b(Numbers<Double> c, Numbers<Double> d) {
        if ((Double)c.getValue() > (Double)d.getValue()) {
            double p = (Double)c.getValue();
            c.setValue((Double)d.getValue());
            d.setValue(p);
        }
    }

    public static boolean eob() {
        double x = Minecraft.thePlayer.posX;
        double y = Minecraft.thePlayer.posY - 1.0;
        double z = Minecraft.thePlayer.posZ;
        BlockPos p = new BlockPos(MathHelper.floor_double(x), MathHelper.floor_double(y), MathHelper.floor_double(z));
        return Minecraft.theWorld.isAirBlock(p);
    }

    public static boolean wpn() {
        if (Minecraft.thePlayer.getCurrentEquippedItem() == null) {
            return false;
        }
        Item item = Minecraft.thePlayer.getCurrentEquippedItem().getItem();
        return item instanceof ItemSword || item instanceof ItemAxe;
    }

    public static double mmVal(Numbers<Double> a, Numbers<Double> b, Random rand2) {
        return a.getValue() == b.getValue() ? (Double)a.getValue() : (Double)a.getValue() + rand2.nextDouble() * ((Double)b.getValue() - (Double)a.getValue());
    }
}

