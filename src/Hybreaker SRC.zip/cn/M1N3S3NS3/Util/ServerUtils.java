/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util;

import cn.M1N3S3NS3.UI.Menu.GuiClientMainMenu;
import cn.M1N3S3NS3.Util.Wrapper;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;

public final class ServerUtils {
    private static final Map<String, Long> serverIpPingCache = new HashMap<String, Long>();
    private static final String HYPIXEL = "hypixel.net";
    public static ServerData serverData;

    private ServerUtils() {
    }

    public static void update(String ip, long ping) {
        serverIpPingCache.put(ip, ping);
    }

    public static long getPingToServer(String ip) {
        return serverIpPingCache.get(ip);
    }

    public static boolean isOnServer(String ip) {
        return !Wrapper.getMinecraft().isSingleplayer() && ServerUtils.getCurrentServerIP().endsWith(ip);
    }

    public static String getCurrentServerIP() {
        return Wrapper.getMinecraft().isSingleplayer() ? "Singleplayer" : Wrapper.getMinecraft().getCurrentServerData().serverIP;
    }

    public static boolean isOnHypixel() {
        return ServerUtils.isOnServer(HYPIXEL);
    }

    public static long getPingToCurrentServer() {
        return Wrapper.getMinecraft().isSingleplayer() ? 0L : ServerUtils.getPingToServer(ServerUtils.getCurrentServerIP());
    }

    public static void connectToLastServer() {
        if (serverData == null) {
            return;
        }
        Wrapper.getMinecraft().displayGuiScreen(new GuiConnecting(new GuiMultiplayer(new GuiClientMainMenu()), Wrapper.getMinecraft(), serverData));
    }
}

