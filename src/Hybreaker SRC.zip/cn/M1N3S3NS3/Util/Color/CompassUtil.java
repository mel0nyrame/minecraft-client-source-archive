/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Util.Color;

import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.opengl.GL11;

public class CompassUtil {
    private Minecraft mc;
    private FontRenderer fr;
    private final double PRIMARY_CARDINAL_SCALE = 1.5;
    private final double SECONDARY_CARDINAL_SCALE = 1.0;
    private final double ANGLE_SCALE = 0.75;
    public boolean enabled = true;
    public int details = 2;
    public int offX = 0;
    public int offY = 0;
    public int width = 150;
    public int height = 20;
    public int cwidth = 500;
    public boolean background = true;
    public boolean chroma = false;
    public boolean shadow = true;
    public int tintMarker = 0;
    public int tintDirection = 0;
    private int offsetAll;
    private int centerX;
    private int colorMarker;
    private int colorDirection;

    public CompassUtil(Minecraft mc) {
        this.mc = mc;
        this.fr = Minecraft.fontRendererObj;
    }

    public void drawCompass(int screenWidth) {
        int direction = this.normalize((int)Minecraft.thePlayer.rotationYaw);
        this.offsetAll = this.cwidth * direction / 360;
        this.centerX = screenWidth / 2 + this.offX;
        if (this.background) {
            Gui.drawRect(this.centerX - this.width / 2, this.offY, this.centerX + this.width / 2, this.offY + this.height, -1442840576);
        }
        if (!this.chroma) {
            this.colorMarker = this.tintMarker != 0 ? Color.HSBtoRGB((float)this.tintMarker / 100.0f, 1.0f, 1.0f) : -1;
            this.colorDirection = this.tintDirection != 0 ? Color.HSBtoRGB((float)this.tintDirection / 100.0f, 1.0f, 1.0f) : -1;
        } else {
            this.colorDirection = this.colorMarker = Color.HSBtoRGB((float)(System.currentTimeMillis() % 3000L) / 3000.0f, 1.0f, 1.0f);
        }
        this.renderMarker();
        if (this.details >= 0) {
            this.drawDirection("S", 0, 1.5);
            this.drawDirection("W", 90, 1.5);
            this.drawDirection("N", 180, 1.5);
            this.drawDirection("E", 270, 1.5);
        }
        if (this.details >= 1) {
            this.drawDirection("SW", 45, 1.0);
            this.drawDirection("NW", 135, 1.0);
            this.drawDirection("NE", 225, 1.0);
            this.drawDirection("SE", 315, 1.0);
        }
        if (this.details >= 2) {
            this.drawDirection("15", 15, 0.75);
            this.drawDirection("30", 30, 0.75);
            this.drawDirection("60", 60, 0.75);
            this.drawDirection("75", 75, 0.75);
            this.drawDirection("105", 105, 0.75);
            this.drawDirection("120", 120, 0.75);
            this.drawDirection("150", 150, 0.75);
            this.drawDirection("165", 165, 0.75);
            this.drawDirection("195", 195, 0.75);
            this.drawDirection("210", 210, 0.75);
            this.drawDirection("240", 240, 0.75);
            this.drawDirection("255", 255, 0.75);
            this.drawDirection("285", 285, 0.75);
            this.drawDirection("300", 300, 0.75);
            this.drawDirection("330", 330, 0.75);
            this.drawDirection("345", 345, 0.75);
        }
    }

    private void renderMarker() {
        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer worldrenderer = tessellator.getWorldRenderer();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.color((float)(this.colorMarker >> 16 & 0xFF) / 255.0f, (float)(this.colorMarker >> 8 & 0xFF) / 255.0f, (float)(this.colorMarker & 0xFF) / 255.0f, 1.0f);
        worldrenderer.begin(6, DefaultVertexFormats.POSITION_COLOR);
        worldrenderer.pos(this.centerX, this.offY + 3, 0.0).endVertex();
        worldrenderer.pos(this.centerX + 3, this.offY, 0.0).endVertex();
        worldrenderer.pos(this.centerX - 3, this.offY, 0.0).endVertex();
        tessellator.draw();
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    private void drawDirection(String dir, int degrees, double scale) {
        double opacity;
        int offset = this.cwidth * degrees / 360 - this.offsetAll;
        if (offset > this.cwidth / 2) {
            offset -= this.cwidth;
        }
        if (offset < -this.cwidth / 2) {
            offset += this.cwidth;
        }
        if ((opacity = 1.0 - (double)Math.abs(offset) / ((double)this.width / 2.0)) > 0.1) {
            int defcolor = this.colorDirection & 0xFFFFFF;
            int color = defcolor | (int)(opacity * 255.0) << 24;
            int posX = this.centerX + offset - (int)((double)this.fr.getStringWidth(dir) * scale / 2.0);
            int posY = this.offY + this.height / 2 - (int)((double)this.fr.FONT_HEIGHT * scale / 2.0);
            GL11.glEnable((int)3042);
            GL11.glPushMatrix();
            GL11.glTranslated((double)((double)(-posX) * (scale - 1.0)), (double)((double)(-posY) * (scale - 1.0)), (double)0.0);
            GL11.glScaled((double)scale, (double)scale, (double)1.0);
            if (this.shadow) {
                this.fr.drawStringWithShadow(dir, posX, posY, color);
            } else {
                this.fr.drawString(dir, posX, posY, color);
            }
            GL11.glPopMatrix();
            GL11.glDisable((int)3042);
        }
    }

    /*
     * Unable to fully structure code
     */
    private int normalize(int direction) {
        ** if (direction <= 360) goto lbl2
lbl2:
        // 3 sources

        while ((direction %= 360) < 0) {
            direction += 360;
        }
        return direction;
    }
}

