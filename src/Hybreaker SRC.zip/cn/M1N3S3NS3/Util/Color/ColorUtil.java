/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Util.Color;

import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.MathUtils;
import java.awt.Color;
import org.lwjgl.opengl.GL11;

public class ColorUtil {
    public static Color getRainbow(float second, float sat, float bright) {
        float hue = (float)(System.currentTimeMillis() % (long)((int)(second * 1000.0f))) / (second * 1000.0f);
        return new Color(Color.HSBtoRGB(hue, sat, bright));
    }

    public static Color getRainbow(float second, float sat, float bright, long index) {
        float hue = (float)((System.currentTimeMillis() + index) % (long)((int)(second * 1000.0f))) / (second * 1000.0f);
        return new Color(Color.HSBtoRGB(hue, sat, bright));
    }

    public static Color getFadeRainbow(Color color, int index, int count) {
        float[] hsb = new float[3];
        Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), hsb);
        float brightness = Math.abs(((float)(System.currentTimeMillis() % 2000L) / 1000.0f + (float)index / (float)count * 2.0f) % 2.0f - 1.0f);
        brightness = 0.5f + 0.5f * brightness;
        hsb[2] = brightness % 2.0f;
        return new Color(Color.HSBtoRGB(hsb[0], hsb[1], hsb[2]));
    }

    public static Color getBlendColor(double current, double max) {
        long base = Math.round(max / 5.0);
        if (current >= (double)(base * 5L)) {
            return new Color(15, 255, 15);
        }
        if (current >= (double)(base * 4L)) {
            return new Color(166, 255, 0);
        }
        if (current >= (double)(base * 3L)) {
            return new Color(255, 191, 0);
        }
        if (current >= (double)(base * 2L)) {
            return new Color(255, 89, 0);
        }
        return new Color(255, 0, 0);
    }

    public static int getCategoryColor(ModuleType category) {
        int color = -1;
        if (category == ModuleType.Combat) {
            color = new Color(150, 53, 46).getRGB();
        } else if (category == ModuleType.Move) {
            color = new Color(200, 121, 0).getRGB();
        } else if (category == ModuleType.Player) {
            color = new Color(65, 134, 45).getRGB();
        } else if (category == ModuleType.Render) {
            color = new Color(65, 118, 146).getRGB();
        } else if (category == ModuleType.Ghost) {
            color = new Color(65, 155, 103).getRGB();
        }
        return color;
    }

    public static Color getDarker(Color before, int dark, int alpha) {
        int rDank = Math.max(before.getRed() - dark, 0);
        int gDank = Math.max(before.getGreen() - dark, 0);
        int bDank = Math.max(before.getBlue() - dark, 0);
        return new Color(rDank, gDank, bDank, alpha);
    }

    public static Color getLighter(Color before, int light, int alpha) {
        int rDank = Math.min(before.getRed() + light, 255);
        int gDank = Math.min(before.getGreen() + light, 255);
        int bDank = Math.min(before.getBlue() + light, 255);
        return new Color(rDank, gDank, bDank, alpha);
    }

    public static void glColor(int color) {
        float f = (float)(color >> 24 & 0xFF) / 255.0f;
        float f1 = (float)(color >> 16 & 0xFF) / 255.0f;
        float f2 = (float)(color >> 8 & 0xFF) / 255.0f;
        float f3 = (float)(color & 0xFF) / 255.0f;
        GL11.glColor4f((float)f1, (float)f2, (float)f3, (float)f);
    }

    public static Color getRandomColor() {
        return new Color(MathUtils.getRandom().nextInt(256), MathUtils.getRandom().nextInt(256), MathUtils.getRandom().nextInt(256));
    }

    public static Color reAlpha(Color before, int alpha) {
        return new Color(before.getRed(), before.getGreen(), before.getBlue(), alpha);
    }
}

