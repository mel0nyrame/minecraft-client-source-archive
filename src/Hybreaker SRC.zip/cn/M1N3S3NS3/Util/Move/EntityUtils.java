/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Move;

import cn.M1N3S3NS3.Manager.FriendManager;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Modules.Combat.AntiBot;
import cn.M1N3S3NS3.Module.Modules.Misc.Teams;
import cn.M1N3S3NS3.Util.Render.ColorUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.scoreboard.ScorePlayerTeam;

public final class EntityUtils {
    static Minecraft mc = Minecraft.getMinecraft();
    public static boolean targetInvisible = false;
    public static boolean targetPlayer = true;
    public static boolean targetMobs = true;
    public static boolean targetAnimals = false;
    public static boolean targetDead = false;

    public static boolean isSelected(Entity entity, boolean canAttackCheck) {
        if (entity instanceof EntityLivingBase && (targetDead || entity.isEntityAlive()) && entity != Minecraft.thePlayer && (targetInvisible || !entity.isInvisible())) {
            if (targetPlayer && entity instanceof EntityPlayer) {
                EntityPlayer entityPlayer = (EntityPlayer)entity;
                if (canAttackCheck) {
                    AntiBot antiBot = (AntiBot)ModuleManager.getModuleByClass(AntiBot.class);
                    if (AntiBot.isBot(entityPlayer)) {
                        return false;
                    }
                    if (entityPlayer.isSpectator()) {
                        return false;
                    }
                    Teams teams = (Teams)ModuleManager.getModuleByName("Teams");
                    return !teams.isEnabled() || !Teams.isOnSameTeam(entityPlayer);
                }
                return true;
            }
            return targetMobs && EntityUtils.isMob(entity) || targetAnimals && EntityUtils.isAnimal(entity);
        }
        return false;
    }

    public static boolean isFriend(Entity entity) {
        return entity instanceof EntityPlayer && entity.getName() != null && FriendManager.isFriend(ColorUtils.stripColor(entity.getName()));
    }

    public static boolean isAnimal(Entity entity) {
        return entity instanceof EntityAnimal || entity instanceof EntitySquid || entity instanceof EntityGolem || entity instanceof EntityBat;
    }

    public static boolean isMob(Entity entity) {
        return entity instanceof EntityMob || entity instanceof EntityVillager || entity instanceof EntitySlime || entity instanceof EntityGhast || entity instanceof EntityDragon;
    }

    public static String getName(NetworkPlayerInfo networkPlayerInfoIn) {
        return networkPlayerInfoIn.getDisplayName() != null ? networkPlayerInfoIn.getDisplayName().getFormattedText() : ScorePlayerTeam.formatPlayerName(networkPlayerInfoIn.getPlayerTeam(), networkPlayerInfoIn.getGameProfile().getName());
    }

    public static int getPing(EntityPlayer entityPlayer) {
        if (entityPlayer == null) {
            return 0;
        }
        NetworkPlayerInfo networkPlayerInfo = mc.getNetHandler().getPlayerInfo(entityPlayer.getUniqueID());
        return networkPlayerInfo == null ? 0 : networkPlayerInfo.getResponseTime();
    }
}

