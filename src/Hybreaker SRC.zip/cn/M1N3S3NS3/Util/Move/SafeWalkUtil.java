/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Move;

public class SafeWalkUtil {
    public static boolean flag = false;

    public static void setSafe(boolean isSafe) {
        flag = isSafe;
    }
}

