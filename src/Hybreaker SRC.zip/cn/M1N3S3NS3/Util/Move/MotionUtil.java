/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Move;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovementInput;

public class MotionUtil {
    public static boolean isMoving(EntityLivingBase entity) {
        return entity.moveForward != 0.0f || entity.moveStrafing != 0.0f;
    }

    public static void setSpeed(EntityLivingBase entity, double speed) {
        double[] dir = MotionUtil.forward(speed);
        entity.motionX = dir[0];
        entity.motionZ = dir[1];
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed = 0.2873;
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer != null) {
            Minecraft.getMinecraft();
            if (Minecraft.thePlayer.isPotionActive(Potion.getPotionById(1))) {
                Minecraft.getMinecraft();
                int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.getPotionById(1)).getAmplifier();
                baseSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
            }
        }
        return baseSpeed;
    }

    public static double[] forward(double speed) {
        Minecraft.getMinecraft();
        float forward = MovementInput.moveForward;
        Minecraft.getMinecraft();
        float side = MovementInput.moveStrafe;
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        float yaw = Minecraft.thePlayer.prevRotationYaw + (Minecraft.thePlayer.rotationYaw - Minecraft.thePlayer.prevRotationYaw) * Minecraft.getMinecraft().getRenderPartialTicks();
        if (forward != 0.0f) {
            if (side > 0.0f) {
                yaw += (float)(forward > 0.0f ? -45 : 45);
            } else if (side < 0.0f) {
                yaw += (float)(forward > 0.0f ? 45 : -45);
            }
            side = 0.0f;
            if (forward > 0.0f) {
                forward = 1.0f;
            } else if (forward < 0.0f) {
                forward = -1.0f;
            }
        }
        double sin = Math.sin(Math.toRadians(yaw + 90.0f));
        double cos = Math.cos(Math.toRadians(yaw + 90.0f));
        double posX = (double)forward * speed * cos + (double)side * speed * sin;
        double posZ = (double)forward * speed * sin - (double)side * speed * cos;
        return new double[]{posX, posZ};
    }
}

