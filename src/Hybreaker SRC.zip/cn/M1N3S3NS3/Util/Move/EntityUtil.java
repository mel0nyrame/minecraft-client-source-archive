/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.Move;

import cn.M1N3S3NS3.API.Events.World.EventMove;
import java.util.ArrayList;
import java.util.HashSet;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class EntityUtil {
    private static Minecraft mc = Minecraft.getMinecraft();

    public static void tpRel(double x, double y, double z) {
        Minecraft.thePlayer.setPosition(Minecraft.thePlayer.posX + x, Minecraft.thePlayer.posY + y, Minecraft.thePlayer.posZ + z);
    }

    public static boolean isOnSameTeam(EntityLivingBase entity) {
        if (entity.getTeam() != null && Minecraft.thePlayer.getTeam() != null) {
            char c2;
            char c1 = entity.getDisplayName().getFormattedText().charAt(1);
            return c1 == (c2 = Minecraft.thePlayer.getDisplayName().getFormattedText().charAt(1));
        }
        return false;
    }

    public static float getDistanceToEntity(EntityLivingBase entityLivingBase) {
        return Minecraft.thePlayer.getDistanceToEntity(entityLivingBase);
    }

    public static void setMoveSpeed(EventMove event, double speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            event.setX(0.0);
            event.setZ(0.0);
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            event.setX(forward * speed * -Math.sin(Math.toRadians(yaw)) + strafe * speed * Math.cos(Math.toRadians(yaw)));
            event.setZ(forward * speed * Math.cos(Math.toRadians(yaw)) - strafe * speed * -Math.sin(Math.toRadians(yaw)));
        }
    }

    private static MovingObjectPosition tracePath(World world, float x, float y, float z, float tx, float ty, float tz, float borderSize, HashSet<Entity> excluded) {
        Vec3 startVec = new Vec3(x, y, z);
        Vec3 endVec = new Vec3(tx, ty, tz);
        float minX = x < tx ? x : tx;
        float minY = y < ty ? y : ty;
        float minZ = z < tz ? z : tz;
        float maxX = x > tx ? x : tx;
        float maxY = y > ty ? y : ty;
        float maxZ = z > tz ? z : tz;
        AxisAlignedBB bb = new AxisAlignedBB(minX, minY, minZ, maxX, maxY, maxZ).expand(borderSize, borderSize, borderSize);
        ArrayList allEntities = (ArrayList)world.getEntitiesWithinAABBExcludingEntity(null, bb);
        MovingObjectPosition blockHit = world.rayTraceBlocks(startVec, endVec);
        startVec = new Vec3(x, y, z);
        endVec = new Vec3(tx, ty, tz);
        Entity closestHitEntity = null;
        float closestHit = Float.POSITIVE_INFINITY;
        for (Entity ent : allEntities) {
            float currentHit;
            MovingObjectPosition intercept;
            if (!ent.canBeCollidedWith() || excluded.contains(ent)) continue;
            float entBorder = ent.getCollisionBorderSize();
            AxisAlignedBB entityBb = ent.getEntityBoundingBox();
            if (entityBb == null || (intercept = (entityBb = entityBb.expand(entBorder, entBorder, entBorder)).calculateIntercept(startVec, endVec)) == null || (currentHit = (float)intercept.hitVec.distanceTo(startVec)) >= closestHit && currentHit != 0.0f) continue;
            closestHit = currentHit;
            closestHitEntity = ent;
        }
        if (closestHitEntity != null) {
            blockHit = new MovingObjectPosition(closestHitEntity);
        }
        return blockHit;
    }

    private static MovingObjectPosition tracePathD(World w, double posX, double posY, double posZ, double v, double v1, double v2, float borderSize, HashSet<Entity> exclude) {
        return EntityUtil.tracePath(w, (float)posX, (float)posY, (float)posZ, (float)v, (float)v1, (float)v2, borderSize, exclude);
    }

    public static MovingObjectPosition rayCast(EntityPlayerSP player, double x, double y, double z) {
        HashSet<Entity> excluded = new HashSet<Entity>();
        excluded.add(player);
        return EntityUtil.tracePathD(player.worldObj, player.posX, player.posY + (double)player.getEyeHeight(), player.posZ, x, y, z, 1.0f, excluded);
    }

    public static void resetTimer() {
        Minecraft.getMinecraft().timer.tickLength = 50.0f;
    }

    public static Block isColliding(double posX, double posY, double posZ) {
        Block block = null;
        if (Minecraft.thePlayer != null) {
            AxisAlignedBB bb = Minecraft.thePlayer.getRidingEntity() != null ? Minecraft.thePlayer.getRidingEntity().getEntityBoundingBox().contract(0.0, 0.0, 0.0).offset(posX, posY, posZ) : Minecraft.thePlayer.getEntityBoundingBox().contract(0.0, 0.0, 0.0).offset(posX, posY, posZ);
            int y = (int)bb.minY;
            int x = MathHelper.floor(bb.minX);
            while (x < MathHelper.floor(bb.maxX) + 1) {
                int z = MathHelper.floor(bb.minZ);
                while (z < MathHelper.floor(bb.maxZ) + 1) {
                    block = Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                    ++z;
                }
                ++x;
            }
        }
        return block;
    }

    public static boolean isInLiquid() {
        if (Minecraft.thePlayer != null) {
            if (Minecraft.thePlayer.fallDistance >= 3.0f) {
                return false;
            }
            boolean inLiquid = false;
            AxisAlignedBB bb = Minecraft.thePlayer.getRidingEntity() != null ? Minecraft.thePlayer.getRidingEntity().getEntityBoundingBox() : Minecraft.thePlayer.getEntityBoundingBox();
            int y = (int)bb.minY;
            int x = MathHelper.floor(bb.minX);
            while (x < MathHelper.floor(bb.maxX) + 1) {
                int z = MathHelper.floor(bb.minZ);
                while (z < MathHelper.floor(bb.maxZ) + 1) {
                    Block block = Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                    if (!(block instanceof BlockAir)) {
                        if (!(block instanceof BlockLiquid)) {
                            return false;
                        }
                        inLiquid = true;
                    }
                    ++z;
                }
                ++x;
            }
            return inLiquid;
        }
        return false;
    }

    public static void setTimer(float speed) {
        Minecraft.getMinecraft().timer.tickLength = 50.0f / speed;
    }
}

