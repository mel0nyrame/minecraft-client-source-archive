/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util;

import java.util.ArrayList;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;

public class BlockUtil {
    private static Minecraft mc = Minecraft.getMinecraft();

    public static void attack(Entity target) {
        Minecraft.thePlayer.swingItem();
        Minecraft.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(target, C02PacketUseEntity.Action.ATTACK));
    }

    public static double Criticals() {
        float motionY = 0.0f;
        int i = 0;
        while (i < 10) {
            motionY += (float)i / 47999.0f;
            float o = 0.0f;
            while ((double)o < 0.42) {
                motionY -= o / 47999.0f;
                int p = 0;
                while (p < 10) {
                    motionY = (float)((double)motionY + Math.random() / 47999.0);
                    ++p;
                }
                o = (float)((double)o + 0.01);
            }
            ++i;
        }
        return motionY;
    }

    public static void Block() {
        if (Minecraft.thePlayer.getHeldItem().getItem() instanceof ItemSword) {
            KeyBinding.setKeyBindState(BlockUtil.mc.gameSettings.keyBindUseItem.getKeyCode(), true);
            Minecraft.playerController.sendUseItem(Minecraft.thePlayer, Minecraft.theWorld, Minecraft.thePlayer.inventory.getCurrentItem());
        }
    }

    public static IBlockState getState(BlockPos pos) {
        return Minecraft.theWorld.getBlockState(pos);
    }

    private Vec3 grabPosition(BlockPos position, EnumFacing facing) {
        Vec3 offset = new Vec3((double)facing.getDirectionVec().getX() / 2.0, (double)facing.getDirectionVec().getY() / 2.0 - 5.0, (double)facing.getDirectionVec().getZ() / 2.0);
        Vec3 point = new Vec3((double)position.getX() + 0.5, (double)position.getY() + 0.5, (double)position.getZ() + 0.5);
        return point.add(offset);
    }

    public static ArrayList<BlockPos> getAllInBox(BlockPos from, BlockPos to) {
        ArrayList<BlockPos> blocks = new ArrayList<BlockPos>();
        BlockPos min = new BlockPos(Math.min(from.getX(), to.getX()), Math.min(from.getY(), to.getY()), Math.min(from.getZ(), to.getZ()));
        BlockPos max = new BlockPos(Math.max(from.getX(), to.getX()), Math.max(from.getY(), to.getY()), Math.max(from.getZ(), to.getZ()));
        int x = min.getX();
        while (x <= max.getX()) {
            int y = min.getY();
            while (y <= max.getY()) {
                int z = min.getZ();
                while (z <= max.getZ()) {
                    blocks.add(new BlockPos(x, y, z));
                    ++z;
                }
                ++y;
            }
            ++x;
        }
        return blocks;
    }
}

