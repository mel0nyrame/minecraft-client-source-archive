/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.util.vector.Vector3f
 */
package cn.M1N3S3NS3.Util;

import cn.M1N3S3NS3.API.Events.World.EventMove;
import cn.M1N3S3NS3.Util.MoveUtils;
import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;
import net.minecraft.util.Timer;
import org.lwjgl.util.vector.Vector3f;

public class PlayerUtil {
    private static Minecraft mc = Minecraft.getMinecraft();

    public static double getIncremental(double val, double inc) {
        double one = 1.0 / inc;
        return (double)Math.round(val * one) / one;
    }

    public static double k() {
        double d = Minecraft.thePlayer.posX - Minecraft.thePlayer.prevPosX;
        double d2 = Minecraft.thePlayer.posZ - Minecraft.thePlayer.prevPosZ;
        return Math.sqrt(d * d + d2 * d2);
    }

    public static float getDirection() {
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            yaw += 180.0f;
        }
        float forward = 1.0f;
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else if (Minecraft.thePlayer.moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (Minecraft.thePlayer.moveStrafing > 0.0f) {
            yaw -= 90.0f * forward;
        }
        if (Minecraft.thePlayer.moveStrafing < 0.0f) {
            yaw += 90.0f * forward;
        }
        return yaw *= (float)Math.PI / 180;
    }

    public static void blockHit(Entity en, boolean value) {
        Minecraft mc = Minecraft.getMinecraft();
        ItemStack stack = Minecraft.thePlayer.getCurrentEquippedItem();
        if (Minecraft.thePlayer.getCurrentEquippedItem() != null && en != null && value && stack.getItem() instanceof ItemSword && (double)Minecraft.thePlayer.swingProgress > 0.2) {
            KeyBinding.onTick(mc.gameSettings.keyBindUseItem.getKeyCode());
        }
    }

    public static boolean isInWater() {
        return Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ)).getBlock().getMaterial() == Material.water;
    }

    public static void toFwd(double speed) {
        float yaw = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180);
        EntityPlayerSP thePlayer = Minecraft.thePlayer;
        thePlayer.motionX -= (double)MathHelper.sin(yaw) * speed;
        EntityPlayerSP thePlayer2 = Minecraft.thePlayer;
        thePlayer2.motionZ += (double)MathHelper.cos(yaw) * speed;
    }

    public static void setSpeed(double speed) {
        Minecraft.thePlayer.motionX = -Math.sin(PlayerUtil.getDirection()) * speed;
        Minecraft.thePlayer.motionZ = Math.cos(PlayerUtil.getDirection()) * speed;
    }

    public static double getSpeed() {
        Minecraft.getMinecraft();
        double motionX = Minecraft.thePlayer.motionX;
        Minecraft.getMinecraft();
        double n = motionX * Minecraft.thePlayer.motionX;
        Minecraft.getMinecraft();
        double motionZ = Minecraft.thePlayer.motionZ;
        Minecraft.getMinecraft();
        return Math.sqrt(n + motionZ * Minecraft.thePlayer.motionZ);
    }

    public static Block getBlockUnderPlayer(EntityPlayer inPlayer) {
        return PlayerUtil.getBlock(new BlockPos(inPlayer.posX, inPlayer.posY - 1.0, inPlayer.posZ));
    }

    public static Block getBlock(BlockPos pos) {
        Minecraft.getMinecraft();
        return Minecraft.theWorld.getBlockState(pos).getBlock();
    }

    public static Block getBlockAtPosC(EntityPlayer inPlayer, double x, double y, double z) {
        return PlayerUtil.getBlock(new BlockPos(inPlayer.posX - x, inPlayer.posY - y, inPlayer.posZ - z));
    }

    public static ArrayList<Vector3f> vanillaTeleportPositions(double tpX, double tpY, double tpZ, double speed) {
        ArrayList<Vector3f> positions = new ArrayList<Vector3f>();
        Minecraft mc = Minecraft.getMinecraft();
        double posX = tpX - Minecraft.thePlayer.posX;
        double posY = tpY - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight() + 1.1);
        double posZ = tpZ - Minecraft.thePlayer.posZ;
        float yaw = (float)(Math.atan2(posZ, posX) * 180.0 / Math.PI - 90.0);
        float pitch = (float)(-Math.atan2(posY, Math.sqrt(posX * posX + posZ * posZ)) * 180.0 / Math.PI);
        double tmpX = Minecraft.thePlayer.posX;
        double tmpY = Minecraft.thePlayer.posY;
        double tmpZ = Minecraft.thePlayer.posZ;
        double steps = 1.0;
        double d = speed;
        while (d < PlayerUtil.getDistance(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ, tpX, tpY, tpZ)) {
            steps += 1.0;
            d += speed;
        }
        d = speed;
        while (d < PlayerUtil.getDistance(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ, tpX, tpY, tpZ)) {
            tmpX = Minecraft.thePlayer.posX - Math.sin(PlayerUtil.getDirection(yaw)) * d;
            tmpZ = Minecraft.thePlayer.posZ + Math.cos(PlayerUtil.getDirection(yaw)) * d;
            positions.add(new Vector3f((float)tmpX, (float)(tmpY -= (Minecraft.thePlayer.posY - tpY) / steps), (float)tmpZ));
            d += speed;
        }
        positions.add(new Vector3f((float)tpX, (float)tpY, (float)tpZ));
        return positions;
    }

    public static float getDirection(float yaw) {
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            yaw += 180.0f;
        }
        float forward = 1.0f;
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else {
            Minecraft.getMinecraft();
            if (Minecraft.thePlayer.moveForward > 0.0f) {
                forward = 0.5f;
            }
        }
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.moveStrafing > 0.0f) {
            yaw -= 90.0f * forward;
        }
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.moveStrafing < 0.0f) {
            yaw += 90.0f * forward;
        }
        return yaw *= (float)Math.PI / 180;
    }

    public static double getDistance(double x1, double y1, double z1, double x2, double y2, double z2) {
        double d0 = x1 - x2;
        double d2 = y1 - y2;
        double d3 = z1 - z2;
        return MathHelper.sqrt_double(d0 * d0 + d2 * d2 + d3 * d3);
    }

    public static boolean MovementInput() {
        return PlayerUtil.mc.gameSettings.keyBindForward.pressed || PlayerUtil.mc.gameSettings.keyBindLeft.pressed || PlayerUtil.mc.gameSettings.keyBindRight.pressed || PlayerUtil.mc.gameSettings.keyBindBack.pressed;
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed = 0.2873;
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return baseSpeed;
    }

    public static boolean isMoving2() {
        return Minecraft.thePlayer.moveForward != 0.0f || Minecraft.thePlayer.moveStrafing != 0.0f;
    }

    public static boolean isInLiquid() {
        if (Minecraft.thePlayer == null) {
            return false;
        }
        if (Minecraft.thePlayer.isInWater()) {
            return true;
        }
        boolean var1 = false;
        int var2 = (int)Minecraft.thePlayer.getEntityBoundingBox().minY;
        int var3 = MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().minX);
        while (var3 < MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().maxX) + 1) {
            int var4 = MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().minZ);
            while (var4 < MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().maxZ) + 1) {
                Block var5 = Minecraft.theWorld.getBlockState(new BlockPos(var3, var2, var4)).getBlock();
                if (var5 != null && var5.getMaterial() != Material.air) {
                    if (!(var5 instanceof BlockLiquid)) {
                        return false;
                    }
                    var1 = true;
                }
                ++var4;
            }
            ++var3;
        }
        return var1;
    }

    public static BlockPos getHypixelBlockpos(String str) {
        int val = 89;
        if (str != null && str.length() > 1) {
            char[] chs = str.toCharArray();
            int lenght = chs.length;
            int i = 0;
            while (i < lenght) {
                val += chs[i] * str.length() * str.length() + str.charAt(0) + str.charAt(1);
                ++i;
            }
            val /= str.length();
        }
        return new BlockPos(val, -val % 255, val);
    }

    public static boolean isOnLiquid() {
        AxisAlignedBB boundingBox = Minecraft.thePlayer.getEntityBoundingBox();
        if (boundingBox == null) {
            return false;
        }
        boundingBox = boundingBox.contract(0.01, 0.0, 0.01).offset(0.0, -0.01, 0.0);
        boolean onLiquid = false;
        int y = (int)boundingBox.minY;
        int x = MathHelper.floor_double(boundingBox.minX);
        while (x < MathHelper.floor_double(boundingBox.maxX + 1.0)) {
            int z = MathHelper.floor_double(boundingBox.minZ);
            while (z < MathHelper.floor_double(boundingBox.maxZ + 1.0)) {
                Block block = Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                if (block != Blocks.air) {
                    if (!(block instanceof BlockLiquid)) {
                        return false;
                    }
                    onLiquid = true;
                }
                ++z;
            }
            ++x;
        }
        return onLiquid;
    }

    public static void blinkToPos(double[] startPos, BlockPos endPos, double slack, double[] pOffset) {
        double curX = startPos[0];
        double curY = startPos[1];
        double curZ = startPos[2];
        try {
            double endX = (double)endPos.getX() + 0.5;
            double endY = (double)endPos.getY() + 1.0;
            double endZ = (double)endPos.getZ() + 0.5;
            double distance = Math.abs(curX - endX) + Math.abs(curY - endY) + Math.abs(curZ - endZ);
            int count = 0;
            while (distance > slack) {
                distance = Math.abs(curX - endX) + Math.abs(curY - endY) + Math.abs(curZ - endZ);
                if (count <= 120) {
                    double offset;
                    boolean next = false;
                    double diffX = curX - endX;
                    double diffY = curY - endY;
                    double diffZ = curZ - endZ;
                    double d = offset = (count & 1) == 0 ? pOffset[0] : pOffset[1];
                    if (diffX < 0.0) {
                        curX = Math.abs(diffX) > offset ? (curX += offset) : (curX += Math.abs(diffX));
                    }
                    if (diffX > 0.0) {
                        curX = Math.abs(diffX) > offset ? (curX -= offset) : (curX -= Math.abs(diffX));
                    }
                    if (diffY < 0.0) {
                        curY = Math.abs(diffY) > 0.25 ? (curY += 0.25) : (curY += Math.abs(diffY));
                    }
                    if (diffY > 0.0) {
                        curY = Math.abs(diffY) > 0.25 ? (curY -= 0.25) : (curY -= Math.abs(diffY));
                    }
                    if (diffZ < 0.0) {
                        curZ = Math.abs(diffZ) > offset ? (curZ += offset) : (curZ += Math.abs(diffZ));
                    }
                    if (diffZ > 0.0) {
                        curZ = Math.abs(diffZ) > offset ? (curZ -= offset) : (curZ -= Math.abs(diffZ));
                    }
                    Minecraft.getMinecraft().getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(curX, curY, curZ, true));
                    ++count;
                    continue;
                }
                break;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public static void hypixelTeleport(double[] startPos, BlockPos endPos) {
        double distx = startPos[0] - (double)endPos.getX() + 0.5;
        double disty = startPos[1] - (double)endPos.getY();
        double distz = startPos[2] - (double)endPos.getZ() + 0.5;
        double dist = Math.sqrt(Minecraft.thePlayer.getDistanceSq(endPos));
        double distanceEntreLesPackets = 0.31 + (double)(MoveUtils.getSpeedEffect() / 20);
        double ztp = 0.0;
        if (dist > distanceEntreLesPackets) {
            double nbPackets = Math.round(dist / distanceEntreLesPackets + 0.49999999999) - 1L;
            double xtp = Minecraft.thePlayer.posX;
            double ytp = Minecraft.thePlayer.posY;
            ztp = Minecraft.thePlayer.posZ;
            double count = 0.0;
            int i = 1;
            while ((double)i < nbPackets) {
                double xdi = ((double)endPos.getX() - Minecraft.thePlayer.posX) / nbPackets;
                double zdi = ((double)endPos.getZ() - Minecraft.thePlayer.posZ) / nbPackets;
                double ydi = ((double)endPos.getY() - Minecraft.thePlayer.posY) / nbPackets;
                count += 1.0;
                if (!Minecraft.theWorld.getBlockState(new BlockPos(xtp += xdi, (ytp += ydi) - 1.0, ztp += zdi)).getBlock().isFullCube()) {
                    if (count <= 2.0) {
                        ytp += 2.0E-8;
                    } else if (count >= 4.0) {
                        count = 0.0;
                    }
                }
                C03PacketPlayer.C04PacketPlayerPosition Packet2 = new C03PacketPlayer.C04PacketPlayerPosition(xtp, ytp, ztp, false);
                Minecraft.thePlayer.sendQueue.addToSendQueue(Packet2);
                ++i;
            }
            Minecraft.thePlayer.setPosition((double)endPos.getX() + 0.5, endPos.getY(), (double)endPos.getZ() + 0.5);
        } else {
            Minecraft.thePlayer.setPosition(endPos.getX(), endPos.getY(), endPos.getZ());
        }
    }

    public static void teleport(double[] startPos, BlockPos endPos) {
        double distx = startPos[0] - (double)endPos.getX() + 0.5;
        double disty = startPos[1] - (double)endPos.getY();
        double distz = startPos[2] - (double)endPos.getZ() + 0.5;
        double dist = Math.sqrt(Minecraft.thePlayer.getDistanceSq(endPos));
        double distanceEntreLesPackets = 5.0;
        double ztp = 0.0;
        if (dist > distanceEntreLesPackets) {
            double nbPackets = Math.round(dist / distanceEntreLesPackets + 0.49999999999) - 1L;
            double xtp = Minecraft.thePlayer.posX;
            double ytp = Minecraft.thePlayer.posY;
            ztp = Minecraft.thePlayer.posZ;
            double count = 0.0;
            int i = 1;
            while ((double)i < nbPackets) {
                double xdi = ((double)endPos.getX() - Minecraft.thePlayer.posX) / nbPackets;
                double zdi = ((double)endPos.getZ() - Minecraft.thePlayer.posZ) / nbPackets;
                double ydi = ((double)endPos.getY() - Minecraft.thePlayer.posY) / nbPackets;
                count += 1.0;
                C03PacketPlayer.C04PacketPlayerPosition Packet2 = new C03PacketPlayer.C04PacketPlayerPosition(xtp += xdi, ytp += ydi, ztp += zdi, true);
                Minecraft.thePlayer.sendQueue.addToSendQueue(Packet2);
                ++i;
            }
            Minecraft.thePlayer.setPosition((double)endPos.getX() + 0.5, endPos.getY(), (double)endPos.getZ() + 0.5);
        } else {
            Minecraft.thePlayer.setPosition(endPos.getX(), endPos.getY(), endPos.getZ());
        }
    }

    public static boolean isMoving() {
        if (!Minecraft.thePlayer.isCollidedHorizontally && !Minecraft.thePlayer.isSneaking()) {
            if (MovementInput.moveForward == 0.0f) {
                if (MovementInput.moveStrafe == 0.0f) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public static void setMotion(EventMove e, double speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            if (e != null) {
                e.setX(0.0);
                e.setZ(0.0);
            } else {
                Minecraft.thePlayer.motionX = 0.0;
                Minecraft.thePlayer.motionZ = 0.0;
            }
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            if (e != null) {
                e.setX(forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.25f)));
                e.setZ(forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.25f)));
            } else {
                Minecraft.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.25f));
                Minecraft.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.25f));
            }
        }
    }

    public static void tellPlayer(String string) {
        Minecraft.getMinecraft();
        Minecraft.thePlayer.addChatMessage(new ChatComponentText(string));
    }

    public static boolean isOnGround(double height) {
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, -height, 0.0)).isEmpty();
    }

    public static int getJumpEffect() {
        return Minecraft.thePlayer.isPotionActive(Potion.jump) ? Minecraft.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1 : 0;
    }

    public static boolean isAirUnder(Entity ent) {
        return Minecraft.theWorld.getBlockState(new BlockPos(ent.posX, ent.posY - 1.0, ent.posZ)).getBlock() == Blocks.air;
    }

    public static double getLastDist() {
        double xDist = Minecraft.thePlayer.posX - Minecraft.thePlayer.prevPosX;
        double zDist = Minecraft.thePlayer.posZ - Minecraft.thePlayer.prevPosZ;
        return Math.sqrt(xDist * xDist + zDist * zDist);
    }

    public static double getLastDist(Entity entIn) {
        double xDist = entIn.posX - entIn.prevPosX;
        double zDist = entIn.posZ - entIn.prevPosZ;
        return Math.sqrt(xDist * xDist + zDist * zDist);
    }

    public static double getBPS() {
        double bps = PlayerUtil.getLastDist() * 20.0;
        return ((double)((int)bps) + bps - (double)((int)bps)) * (double)Timer.timerSpeed;
    }

    public static double getBPS(Entity entityIn) {
        double bps = PlayerUtil.getLastDist(entityIn) * 20.0;
        return (double)((int)bps) + bps - (double)((int)bps);
    }

    public static void setSpeed(EventMove event, double speed) {
        float yaw = Minecraft.thePlayer.rotationYaw;
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        if (forward == 0.0 && strafe == 0.0) {
            event.setX(0.0);
            event.setZ(0.0);
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                forward = forward > 0.0 ? 1.0 : -1.0;
            }
            event.setX(forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f)));
            event.setZ(forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f)));
        }
    }

    public static boolean isBlockUnder() {
        if (Minecraft.thePlayer.posY < 0.0) {
            return false;
        }
        int off = 0;
        while (off < (int)Minecraft.thePlayer.posY + 2) {
            AxisAlignedBB bb = Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, -off, 0.0);
            if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb).isEmpty()) {
                return true;
            }
            off += 2;
        }
        return false;
    }

    public static void strafe(double speed) {
        if (!PlayerUtil.isMoving()) {
            return;
        }
        double yaw = PlayerUtil.getDirection();
        Minecraft.thePlayer.motionX = -Math.sin(yaw) * speed;
        Minecraft.thePlayer.motionZ = Math.cos(yaw) * speed;
    }

    public static int getSpeedEffect() {
        return Minecraft.thePlayer.isPotionActive(Potion.moveSpeed) ? Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1 : 0;
    }

    public static double getlastDist() {
        double xDist = Minecraft.thePlayer.posX - Minecraft.thePlayer.prevPosX;
        double zDist = Minecraft.thePlayer.posZ - Minecraft.thePlayer.prevPosZ;
        return Math.sqrt(xDist * xDist + zDist * zDist);
    }

    public static void setMoveSpeed(EventMove e, double speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            e.setX(0.0);
            e.setZ(0.0);
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            e.setX(forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f)));
            e.setZ(forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f)));
        }
    }
}

