/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util;

import cn.M1N3S3NS3.API.Events.World.EventMove;
import net.minecraft.client.Minecraft;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovementInput;

public class MoveUtil {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static void setSpeed(EventMove moveEvent, double moveSpeed) {
        float rotationYaw = Minecraft.thePlayer.rotationYaw;
        double pseudoStrafe = MovementInput.moveStrafe;
        MoveUtil.setSpeed(moveEvent, moveSpeed, rotationYaw, pseudoStrafe, MovementInput.moveForward);
    }

    public static void setSpeed(EventMove moveEvent, double moveSpeed, float pseudoYaw, double pseudoStrafe, double pseudoForward) {
        double forward = pseudoForward;
        double strafe = pseudoStrafe;
        float yaw = pseudoYaw;
        if (forward != 0.0) {
            if (strafe > 0.0) {
                yaw += (float)(forward > 0.0 ? -45 : 45);
            } else if (strafe < 0.0) {
                yaw += (float)(forward > 0.0 ? 45 : -45);
            }
            strafe = 0.0;
            if (forward > 0.0) {
                forward = 1.0;
            } else if (forward < 0.0) {
                forward = -1.0;
            }
        }
        if (strafe > 0.0) {
            strafe = 1.0;
        } else if (strafe < 0.0) {
            strafe = -1.0;
        }
        double mx = Math.cos(Math.toRadians(yaw + 90.0f));
        double mz = Math.sin(Math.toRadians(yaw + 90.0f));
        EventMove.x = forward * moveSpeed * mx + strafe * moveSpeed * mz;
        EventMove.z = forward * moveSpeed * mz - strafe * moveSpeed * mx;
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed = 0.2875;
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            baseSpeed *= 1.0 + 0.2 * (double)(Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1);
        }
        return baseSpeed;
    }

    public static double getJumpBoostModifier(double baseJumpHeight) {
        if (Minecraft.thePlayer.isPotionActive(Potion.jump)) {
            int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier();
            baseJumpHeight += (double)((float)(amplifier + 1) * 0.1f);
        }
        return baseJumpHeight;
    }
}

