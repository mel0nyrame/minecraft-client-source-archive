/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.JsonObject
 *  org.apache.commons.io.IOUtils
 *  org.apache.http.client.methods.CloseableHttpResponse
 *  org.apache.http.client.methods.HttpGet
 *  org.apache.http.client.methods.HttpUriRequest
 *  org.apache.http.impl.client.CloseableHttpClient
 *  org.apache.http.impl.client.HttpClients
 */
package cn.M1N3S3NS3.Util;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;
import javax.swing.JOptionPane;
import org.apache.commons.io.IOUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

public class WatchdogHelper {
    public static String getBanSource(String player, String banID) throws Throwable {
        String UUID2 = player.trim();
        String string4 = "https://hypixel.net/api/players/" + UUID2;
        System.out.println(UUID2);
        CloseableHttpClient closeableHttpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(string4);
        httpGet.setHeader("user-agent", "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Mobile Safari/537.36");
        httpGet.setHeader("xf-api-key", "LnM-qSeQqtJlJmJnVt76GhU-SoiolWs9");
        String finalResult = "";
        try (CloseableHttpResponse response = closeableHttpClient.execute((HttpUriRequest)httpGet);){
            finalResult = IOUtils.toString((InputStream)response.getEntity().getContent(), (Charset)StandardCharsets.UTF_8);
            System.out.println(finalResult);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        Gson gson1 = new Gson();
        JsonObject array = (JsonObject)gson1.fromJson(finalResult.trim(), JsonObject.class);
        String finalID = banID.replace("#", "");
        String accessLocation = "https://hypixel.net/api/players/" + array.get("uuid").getAsString() + "/ban/" + finalID;
        CloseableHttpClient closeableHttpClient1 = HttpClients.createDefault();
        HttpGet newHttp = new HttpGet(accessLocation);
        newHttp.setHeader("user-agent", "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Mobile Safari/537.36");
        newHttp.setHeader("xf-api-key", "LnM-qSeQqtJlJmJnVt76GhU-SoiolWs9");
        try (CloseableHttpResponse response = closeableHttpClient1.execute((HttpUriRequest)newHttp);){
            finalResult = IOUtils.toString((InputStream)response.getEntity().getContent(), (Charset)StandardCharsets.UTF_8);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
        while (finalResult.contains("too_many_request") && JOptionPane.showConfirmDialog(null, "\u8bbf\u95ee\u9891\u7e41, \u6309\u786e\u5b9a\u7ee7\u7eed\u5c1d\u8bd5\u83b7\u53d6!") == 1) {
            String string4111 = "https://hypixel.net/api/players/" + array.get("uuid").getAsString() + "/ban/" + finalID;
            CloseableHttpClient newCloseableHttpClient = HttpClients.createDefault();
            HttpGet anoHttp = new HttpGet(string4111);
            anoHttp.setHeader("user-agent", "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Mobile Safari/537.36");
            anoHttp.setHeader("xf-api-key", "LnM-qSeQqtJlJmJnVt76GhU-SoiolWs9");
            try (CloseableHttpResponse closeableHttpResponse = newCloseableHttpClient.execute((HttpUriRequest)anoHttp);){
                finalResult = IOUtils.toString((InputStream)closeableHttpResponse.getEntity().getContent(), (Charset)StandardCharsets.UTF_8);
            }
            catch (IOException iOException) {
                iOException.printStackTrace();
            }
        }
        return WatchdogHelper.getWatchdogString(finalResult);
    }

    public static String getBanID(List<String> messages) {
        for (String message : messages) {
            if (!message.contains("#")) continue;
            return message.substring(message.length() - 9, message.length());
        }
        return "";
    }

    private static String getWatchdogString(String load) {
        System.out.println(load);
        Gson gson = new Gson();
        JsonObject json = (JsonObject)gson.fromJson(load.trim(), JsonObject.class);
        if (json.has("tags") && json.has("punishmentCategory")) {
            return String.valueOf(json.get("punishmentCategory").getAsString()) + " " + json.get("tags").getAsString();
        }
        return "";
    }
}

