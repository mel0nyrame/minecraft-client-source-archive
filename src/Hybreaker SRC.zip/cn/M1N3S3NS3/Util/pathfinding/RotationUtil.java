/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.pathfinding;

import cn.M1N3S3NS3.API.Events.World.EventPacket;
import cn.M1N3S3NS3.Util.Math.Rotation;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.MathHelper;

public class RotationUtil {
    private static final Minecraft mc = Minecraft.getMinecraft();
    public static Rotation serverRotation = new Rotation(0.0f, 0.0f);

    public static float[] getRotation(EntityLivingBase ent) {
        double lower = (double)ent.getEyeHeight() * (ent.isChild() || ent.getEntityBoundingBox().maxY - ent.getEntityBoundingBox().minY < 1.0 ? 2.0 : 0.5);
        double x = ent.posX + (ent.posX - ent.prevPosX);
        double z = ent.posZ + (ent.posZ - ent.prevPosZ);
        double y = ent.posY - lower;
        return RotationUtil.getRotationFromPosition(x, y, z);
    }

    public static float[] getRotationFromPosition(double x, double y, double z) {
        double xDiff = x - Minecraft.thePlayer.posX;
        double zDiff = z - Minecraft.thePlayer.posZ;
        double yDiff = y - Minecraft.thePlayer.posY;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float getYawDifference(float currentYaw, double targetX, double targetY, double targetZ) {
        double deltaX = targetX - Minecraft.thePlayer.posX;
        double deltaY = targetY - Minecraft.thePlayer.posY;
        double deltaZ = targetZ - Minecraft.thePlayer.posZ;
        double yawToEntity = 0.0;
        double degrees = Math.toDegrees(Math.atan(deltaZ / deltaX));
        if (deltaZ < 0.0 && deltaX < 0.0) {
            if (deltaX != 0.0) {
                yawToEntity = 90.0 + degrees;
            }
        } else if (deltaZ < 0.0 && deltaX > 0.0) {
            if (deltaX != 0.0) {
                yawToEntity = -90.0 + degrees;
            }
        } else if (deltaZ != 0.0) {
            yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }
        return MathHelper.wrapAngleTo180_float(-(currentYaw - (float)yawToEntity));
    }

    public static float getPitchDifference(float currentPitch, double targetX, double targetY, double targetZ) {
        double deltaX = targetX - Minecraft.thePlayer.posX;
        double deltaY = targetY - Minecraft.thePlayer.posY;
        double deltaZ = targetZ - Minecraft.thePlayer.posZ;
        double distanceXZ = MathHelper.sqrt_double(deltaX * deltaX + deltaZ * deltaZ);
        double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));
        return -MathHelper.wrapAngleTo180_float(currentPitch - (float)pitchToEntity) - 2.5f;
    }

    public static float getYawDifference(float currentYaw, float targetYaw) {
        return ((currentYaw - targetYaw) % 360.0f + 540.0f) % 360.0f - 180.0f;
    }

    public static boolean serverRotate(EventPacket event, Rotation customRotation) {
        Packet packet = event.getPacket();
        if (event.isIncoming() && packet instanceof S08PacketPlayerPosLook) {
            S08PacketPlayerPosLook s08PacketPlayerPosLook = (S08PacketPlayerPosLook)packet;
            s08PacketPlayerPosLook.yaw = customRotation.getYaw();
            s08PacketPlayerPosLook.pitch = customRotation.getPitch();
            event.setPacket(s08PacketPlayerPosLook);
            return true;
        }
        return false;
    }

    public static Rotation getEntityRotation(Entity entityIn) {
        return new Rotation(entityIn);
    }
}

