/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util;

import net.minecraft.client.Minecraft;
import net.minecraft.inventory.Slot;

public class InventoryUtil {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final int hotBarSize = 9;
    private static final int inventoryContainerSize = 36;
    private static final int allInventorySize = 45;

    public static int getHotBarSize() {
        return 9;
    }

    public static int getInventoryContainerSize() {
        return 36;
    }

    public static int getAllInventorySize() {
        return 45;
    }

    public static Slot getSlot(int id) {
        return Minecraft.thePlayer.inventoryContainer.getSlot(id);
    }

    public static int findEmptySlot() {
        int i = 0;
        while (i < 9) {
            int id = i + 36;
            if (!InventoryUtil.getSlot(id).getHasStack()) {
                return id;
            }
            ++i;
        }
        return -1;
    }

    public static void swap(int currentSlot, int targetSlot) {
        Minecraft.playerController.windowClick(Minecraft.thePlayer.inventoryContainer.windowId, currentSlot, targetSlot, 2, Minecraft.thePlayer);
    }
}

