/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util;

import cn.M1N3S3NS3.Client;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;

public final class FileUtils {
    public static List<String> read(File inputFile) {
        ArrayList<String> readContent = new ArrayList<String>();
        try {
            String str;
            BufferedReader in = new BufferedReader(new InputStreamReader((InputStream)new FileInputStream(inputFile), StandardCharsets.UTF_8));
            while ((str = in.readLine()) != null) {
                readContent.add(str);
            }
            in.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return readContent;
    }

    public static String readFile(String dir, String fileName) {
        StringBuilder result = new StringBuilder();
        try {
            File file = new File(dir, fileName);
            if (!file.exists()) {
                file.createNewFile();
            }
            FileInputStream fIn = new FileInputStream(file);
            Throwable throwable = null;
            Object var6_8 = null;
            try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fIn));){
                String str;
                while ((str = bufferedReader.readLine()) != null) {
                    result.append(str);
                    result.append(System.lineSeparator());
                }
            }
            catch (Throwable throwable2) {
                if (throwable == null) {
                    throwable = throwable2;
                } else if (throwable != throwable2) {
                    throwable.addSuppressed(throwable2);
                }
                throw throwable;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return result.toString();
    }

    public static void write(File outputFile, List<String> writeContent, boolean overrideContent) {
        try {
            BufferedWriter out = new BufferedWriter(new OutputStreamWriter((OutputStream)new FileOutputStream(outputFile), StandardCharsets.UTF_8));
            for (String outputLine : writeContent) {
                out.write(String.valueOf(outputLine) + System.getProperty("line.separator"));
            }
            ((Writer)out).close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static File getConfigDir() {
        File file = new File(Minecraft.getMinecraft().mcDataDir, Client.name);
        if (!file.exists()) {
            file.mkdir();
        }
        return file;
    }

    private static File getConfigFolder() {
        File Sigma = new File(Minecraft.getMinecraft().mcDataDir, Client.name);
        File file = new File(Sigma, "Configs");
        if (!file.exists()) {
            file.mkdir();
        }
        return file;
    }

    public static File getConfig(String name) {
        File file = new File(FileUtils.getConfigFolder(), String.format("%s.txt", name));
        if (!file.exists()) {
            return null;
        }
        return file;
    }

    public static File getConfigFile(String name) {
        File file = new File(FileUtils.getConfigDir(), String.format("%s.txt", name));
        if (!file.exists()) {
            try {
                file.createNewFile();
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        }
        return file;
    }
}

