/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Util.timer;

public class TimerUtil {
    private long lastMS;

    private long getCurrentMS() {
        return System.nanoTime() / 1000000L;
    }

    public boolean hasReached(double milliseconds) {
        return (double)(this.getCurrentMS() - this.lastMS) >= milliseconds;
    }

    public void reset() {
        this.lastMS = this.getCurrentMS();
    }

    public boolean delay(float milliSec) {
        return (float)(this.getTime() - this.lastMS) >= milliSec;
    }

    public long getTime() {
        return System.nanoTime() / 1000000L;
    }

    public final long getElapsedTime() {
        return this.getCurrentMS() - this.lastMS;
    }

    public long lastMS() {
        return System.nanoTime() / 1000000L - this.lastMS;
    }

    public boolean reach(long time) {
        return this.lastMS() >= time;
    }

    public final long getDifference() {
        return this.getCurrentMS() - this.lastMS;
    }

    public final boolean hasPassed(long milliseconds) {
        return this.getCurrentMS() - this.lastMS > milliseconds;
    }
}

