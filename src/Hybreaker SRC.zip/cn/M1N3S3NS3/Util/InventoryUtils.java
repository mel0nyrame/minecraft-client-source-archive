/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Multimap
 */
package cn.M1N3S3NS3.Util;

import cn.M1N3S3NS3.Util.Wrapper;
import com.google.common.collect.Multimap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C10PacketCreativeInventoryAction;
import net.minecraft.util.DamageSource;

public class InventoryUtils {
    public static Minecraft mc = Minecraft.getMinecraft();
    public static final List<Block> BLOCK_BLACKLIST = Arrays.asList(Blocks.enchanting_table, Blocks.chest, Blocks.ender_chest, Blocks.trapped_chest, Blocks.anvil, Blocks.sand, Blocks.web, Blocks.torch, Blocks.crafting_table, Blocks.furnace, Blocks.waterlily, Blocks.dispenser, Blocks.stone_pressure_plate, Blocks.wooden_pressure_plate, Blocks.noteblock, Blocks.dropper, Blocks.tnt, Blocks.standing_banner, Blocks.wall_banner);
    float f;

    public void dropSlot(int slot) {
        int windowId = new GuiInventory((EntityPlayer)Minecraft.thePlayer).inventorySlots.windowId;
        Minecraft.playerController.windowClick(windowId, slot, 1, 4, Minecraft.thePlayer);
    }

    public static void updateInventory() {
        int index = 0;
        while (index < 44) {
            try {
                int offset = index < 9 ? 36 : 0;
                Minecraft.getMinecraft();
                Minecraft.getMinecraft();
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C10PacketCreativeInventoryAction(index + offset, Minecraft.thePlayer.inventory.mainInventory[index]));
            }
            catch (Exception exception) {
                // empty catch block
            }
            ++index;
        }
    }

    public static int findAutoBlockBlock() {
        ItemBlock itemBlock;
        Block block;
        ItemStack itemStack;
        int i = 36;
        while (i < 45) {
            itemStack = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (itemStack != null && itemStack.getItem() instanceof ItemBlock && (block = (itemBlock = (ItemBlock)itemStack.getItem()).getBlock()).isFullCube() && !BLOCK_BLACKLIST.contains(block)) {
                return i;
            }
            ++i;
        }
        i = 36;
        while (i < 45) {
            itemStack = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (itemStack != null && itemStack.getItem() instanceof ItemBlock && !BLOCK_BLACKLIST.contains(block = (itemBlock = (ItemBlock)itemStack.getItem()).getBlock())) {
                return i;
            }
            ++i;
        }
        return -1;
    }

    public static ItemStack getStackInSlot(int slot) {
        return Minecraft.thePlayer.inventory.getStackInSlot(slot);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static boolean isBestArmorOfTypeInInv(ItemStack is) {
        int otherProt;
        ItemArmor otherArmor;
        ItemStack stack;
        int i;
        int prot;
        ItemArmor ia;
        try {
            if (is == null) {
                return false;
            }
            if (is.getItem() == null) {
                return false;
            }
            if (is.getItem() != null && !(is.getItem() instanceof ItemArmor)) {
                return false;
            }
            ia = (ItemArmor)is.getItem();
            prot = InventoryUtils.getArmorProt(is);
            i = 0;
            while (i < 4) {
                stack = Minecraft.thePlayer.inventory.armorInventory[i];
                if (stack != null) {
                    otherArmor = (ItemArmor)stack.getItem();
                    if (otherArmor.armorType == ia.armorType && (otherProt = InventoryUtils.getArmorProt(stack)) >= prot) {
                        return false;
                    }
                }
                ++i;
            }
        }
        catch (Exception exception) {
            // empty catch block
            return true;
        }
        for (i = 0; i < Minecraft.thePlayer.inventory.getSizeInventory() - 4; ++i) {
            stack = Minecraft.thePlayer.inventory.getStackInSlot(i);
            if (stack == null || !(stack.getItem() instanceof ItemArmor)) continue;
            otherArmor = (ItemArmor)stack.getItem();
            if (otherArmor.armorType != ia.armorType || otherArmor == ia || (otherProt = InventoryUtils.getArmorProt(stack)) < prot) continue;
            return false;
        }
        return true;
    }

    public static boolean hotbarHas(Item item) {
        int index = 0;
        while (index <= 36) {
            Minecraft.getMinecraft();
            ItemStack stack = Minecraft.thePlayer.inventory.getStackInSlot(index);
            if (stack != null && stack.getItem() == item) {
                return true;
            }
            ++index;
        }
        return false;
    }

    public static boolean hotbarHas(Item item, int slotID) {
        int index = 0;
        while (index <= 36) {
            Minecraft.getMinecraft();
            ItemStack stack = Minecraft.thePlayer.inventory.getStackInSlot(index);
            if (stack != null && stack.getItem() == item && InventoryUtils.getSlotID(stack.getItem()) == slotID) {
                return true;
            }
            ++index;
        }
        return false;
    }

    public static int getSlotID(Item item) {
        int index = 0;
        while (index <= 36) {
            Minecraft.getMinecraft();
            ItemStack stack = Minecraft.thePlayer.inventory.getStackInSlot(index);
            if (stack != null && stack.getItem() == item) {
                return index;
            }
            ++index;
        }
        return -1;
    }

    public static ItemStack getItemBySlotID(int slotID) {
        int index = 0;
        while (index <= 36) {
            Minecraft.getMinecraft();
            ItemStack stack = Minecraft.thePlayer.inventory.getStackInSlot(index);
            if (stack != null && InventoryUtils.getSlotID(stack.getItem()) == slotID) {
                return stack;
            }
            ++index;
        }
        return null;
    }

    public static int getArmorProt(ItemStack i) {
        int armorprot = -1;
        if (i != null && i.getItem() != null && i.getItem() instanceof ItemArmor) {
            armorprot = ((ItemArmor)i.getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(i)) + EnchantmentHelper.getEnchantmentModifierDamage(new ItemStack[]{i}, DamageSource.generic);
        }
        return armorprot;
    }

    public static int getBestSwordSlotID(ItemStack item, double damage) {
        int index = 0;
        while (index <= 36) {
            Minecraft.getMinecraft();
            ItemStack stack = Minecraft.thePlayer.inventory.getStackInSlot(index);
            if (stack != null && stack == item && InventoryUtils.getSwordDamage(stack) == InventoryUtils.getSwordDamage(item)) {
                return index;
            }
            ++index;
        }
        return -1;
    }

    private static double getSwordDamage(ItemStack itemStack) {
        double damage = 0.0;
        Optional attributeModifier = itemStack.getAttributeModifiers().values().stream().findFirst();
        if (attributeModifier.isPresent()) {
            damage = ((AttributeModifier)attributeModifier.get()).getAmount();
        }
        return damage += (double)EnchantmentHelper.getModifierForCreature(itemStack, EnumCreatureAttribute.UNDEFINED);
    }

    public boolean isBestChest(int slot) {
        if (InventoryUtils.getStackInSlot(slot) != null && InventoryUtils.getStackInSlot(slot).getItem() != null && InventoryUtils.getStackInSlot(slot).getItem() instanceof ItemArmor) {
            int otherProtection;
            ItemArmor ia1;
            ItemStack[] arritemStack = new ItemStack[]{Minecraft.thePlayer.inventory.getStackInSlot(slot)};
            int slotProtection = ((ItemArmor)Minecraft.thePlayer.inventory.getStackInSlot(slot).getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(Minecraft.thePlayer.inventory.getStackInSlot(slot))) + EnchantmentHelper.getEnchantmentModifierDamage(arritemStack, DamageSource.generic);
            if (Minecraft.thePlayer.inventory.armorInventory[2] != null) {
                ItemArmor ia = (ItemArmor)Minecraft.thePlayer.inventory.armorInventory[2].getItem();
                ItemStack is = Minecraft.thePlayer.inventory.armorInventory[2];
                ia1 = (ItemArmor)InventoryUtils.getStackInSlot(slot).getItem();
                otherProtection = ((ItemArmor)is.getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(is)) + EnchantmentHelper.getEnchantmentModifierDamage(new ItemStack[]{is}, DamageSource.generic);
                if (otherProtection > slotProtection || otherProtection == slotProtection) {
                    return false;
                }
            }
            for (int i = 0; i < Minecraft.thePlayer.inventory.getSizeInventory(); ++i) {
                if (InventoryUtils.getStackInSlot(i) == null || !(Minecraft.thePlayer.inventory.getStackInSlot(i).getItem() instanceof ItemArmor)) continue;
                ItemStack[] arritemStack2 = new ItemStack[]{Minecraft.thePlayer.inventory.getStackInSlot(i)};
                otherProtection = ((ItemArmor)Minecraft.thePlayer.inventory.getStackInSlot(i).getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(Minecraft.thePlayer.inventory.getStackInSlot(i))) + EnchantmentHelper.getEnchantmentModifierDamage(arritemStack2, DamageSource.generic);
                ia1 = (ItemArmor)InventoryUtils.getStackInSlot(slot).getItem();
                ItemArmor ia2 = (ItemArmor)InventoryUtils.getStackInSlot(i).getItem();
                if (ia1.armorType != 1 || ia2.armorType != 1 || otherProtection <= slotProtection) continue;
                return false;
            }
        }
        return true;
    }

    public boolean isBestHelmet(int slot) {
        if (InventoryUtils.getStackInSlot(slot) != null && InventoryUtils.getStackInSlot(slot).getItem() != null && InventoryUtils.getStackInSlot(slot).getItem() instanceof ItemArmor) {
            int otherProtection;
            ItemArmor ia1;
            ItemStack[] arritemStack = new ItemStack[]{Minecraft.thePlayer.inventory.getStackInSlot(slot)};
            int slotProtection = ((ItemArmor)Minecraft.thePlayer.inventory.getStackInSlot(slot).getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(Minecraft.thePlayer.inventory.getStackInSlot(slot))) + EnchantmentHelper.getEnchantmentModifierDamage(arritemStack, DamageSource.generic);
            if (Minecraft.thePlayer.inventory.armorInventory[3] != null) {
                ItemArmor ia = (ItemArmor)Minecraft.thePlayer.inventory.armorInventory[3].getItem();
                ItemStack is = Minecraft.thePlayer.inventory.armorInventory[3];
                ia1 = (ItemArmor)InventoryUtils.getStackInSlot(slot).getItem();
                otherProtection = ((ItemArmor)is.getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(is)) + EnchantmentHelper.getEnchantmentModifierDamage(new ItemStack[]{is}, DamageSource.generic);
                if (otherProtection > slotProtection || otherProtection == slotProtection) {
                    return false;
                }
            }
            for (int i = 0; i < Minecraft.thePlayer.inventory.getSizeInventory(); ++i) {
                if (InventoryUtils.getStackInSlot(i) == null || !(Minecraft.thePlayer.inventory.getStackInSlot(i).getItem() instanceof ItemArmor)) continue;
                ItemStack[] arritemStack2 = new ItemStack[]{Minecraft.thePlayer.inventory.getStackInSlot(i)};
                otherProtection = ((ItemArmor)Minecraft.thePlayer.inventory.getStackInSlot(i).getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(Minecraft.thePlayer.inventory.getStackInSlot(i))) + EnchantmentHelper.getEnchantmentModifierDamage(arritemStack2, DamageSource.generic);
                ia1 = (ItemArmor)InventoryUtils.getStackInSlot(slot).getItem();
                ItemArmor ia2 = (ItemArmor)InventoryUtils.getStackInSlot(i).getItem();
                if (ia1.armorType != 0 || ia2.armorType != 0 || otherProtection <= slotProtection) continue;
                return false;
            }
        }
        return true;
    }

    public boolean isBestLeggings(int slot) {
        if (InventoryUtils.getStackInSlot(slot) != null && InventoryUtils.getStackInSlot(slot).getItem() != null && InventoryUtils.getStackInSlot(slot).getItem() instanceof ItemArmor) {
            int otherProtection;
            ItemArmor ia1;
            ItemStack[] arritemStack = new ItemStack[]{Minecraft.thePlayer.inventory.getStackInSlot(slot)};
            int slotProtection = ((ItemArmor)Minecraft.thePlayer.inventory.getStackInSlot(slot).getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(Minecraft.thePlayer.inventory.getStackInSlot(slot))) + EnchantmentHelper.getEnchantmentModifierDamage(arritemStack, DamageSource.generic);
            if (Minecraft.thePlayer.inventory.armorInventory[1] != null) {
                ItemArmor ia = (ItemArmor)Minecraft.thePlayer.inventory.armorInventory[1].getItem();
                ItemStack is = Minecraft.thePlayer.inventory.armorInventory[1];
                ia1 = (ItemArmor)InventoryUtils.getStackInSlot(slot).getItem();
                otherProtection = ((ItemArmor)is.getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(is)) + EnchantmentHelper.getEnchantmentModifierDamage(new ItemStack[]{is}, DamageSource.generic);
                if (otherProtection > slotProtection || otherProtection == slotProtection) {
                    return false;
                }
            }
            for (int i = 0; i < Minecraft.thePlayer.inventory.getSizeInventory(); ++i) {
                if (InventoryUtils.getStackInSlot(i) == null || !(Minecraft.thePlayer.inventory.getStackInSlot(i).getItem() instanceof ItemArmor)) continue;
                ItemStack[] arritemStack2 = new ItemStack[]{Minecraft.thePlayer.inventory.getStackInSlot(i)};
                otherProtection = ((ItemArmor)Minecraft.thePlayer.inventory.getStackInSlot(i).getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(Minecraft.thePlayer.inventory.getStackInSlot(i))) + EnchantmentHelper.getEnchantmentModifierDamage(arritemStack2, DamageSource.generic);
                ia1 = (ItemArmor)InventoryUtils.getStackInSlot(slot).getItem();
                ItemArmor ia2 = (ItemArmor)InventoryUtils.getStackInSlot(i).getItem();
                if (ia1.armorType != 2 || ia2.armorType != 2 || otherProtection <= slotProtection) continue;
                return false;
            }
        }
        return true;
    }

    public boolean isBestBoots(int slot) {
        if (InventoryUtils.getStackInSlot(slot) != null && InventoryUtils.getStackInSlot(slot).getItem() != null && InventoryUtils.getStackInSlot(slot).getItem() instanceof ItemArmor) {
            int otherProtection;
            ItemArmor ia1;
            ItemStack[] arritemStack = new ItemStack[]{Minecraft.thePlayer.inventory.getStackInSlot(slot)};
            int slotProtection = ((ItemArmor)Minecraft.thePlayer.inventory.getStackInSlot(slot).getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(Minecraft.thePlayer.inventory.getStackInSlot(slot))) + EnchantmentHelper.getEnchantmentModifierDamage(arritemStack, DamageSource.generic);
            if (Minecraft.thePlayer.inventory.armorInventory[0] != null) {
                ItemArmor ia = (ItemArmor)Minecraft.thePlayer.inventory.armorInventory[0].getItem();
                ItemStack is = Minecraft.thePlayer.inventory.armorInventory[0];
                ia1 = (ItemArmor)InventoryUtils.getStackInSlot(slot).getItem();
                otherProtection = ((ItemArmor)is.getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(is)) + EnchantmentHelper.getEnchantmentModifierDamage(new ItemStack[]{is}, DamageSource.generic);
                if (otherProtection > slotProtection || otherProtection == slotProtection) {
                    return false;
                }
            }
            for (int i = 0; i < Minecraft.thePlayer.inventory.getSizeInventory(); ++i) {
                if (InventoryUtils.getStackInSlot(i) == null || !(Minecraft.thePlayer.inventory.getStackInSlot(i).getItem() instanceof ItemArmor)) continue;
                ItemStack[] arritemStack2 = new ItemStack[]{Minecraft.thePlayer.inventory.getStackInSlot(i)};
                otherProtection = ((ItemArmor)Minecraft.thePlayer.inventory.getStackInSlot(i).getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(Minecraft.thePlayer.inventory.getStackInSlot(i))) + EnchantmentHelper.getEnchantmentModifierDamage(arritemStack2, DamageSource.generic);
                ia1 = (ItemArmor)InventoryUtils.getStackInSlot(slot).getItem();
                ItemArmor ia2 = (ItemArmor)InventoryUtils.getStackInSlot(i).getItem();
                if (ia1.armorType != 3 || ia2.armorType != 3 || otherProtection <= slotProtection) continue;
                return false;
            }
        }
        return true;
    }

    public boolean isBestSword(int slotIn) {
        return this.getBestWeapon() == slotIn;
    }

    public static int getItemType(ItemStack itemStack) {
        if (itemStack.getItem() instanceof ItemArmor) {
            ItemArmor armor = (ItemArmor)itemStack.getItem();
            return armor.armorType;
        }
        return -1;
    }

    public static float getItemDamage(ItemStack itemStack) {
        Iterator iterator;
        Multimap<String, AttributeModifier> multimap = itemStack.getAttributeModifiers();
        if (!multimap.isEmpty() && (iterator = multimap.entries().iterator()).hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            AttributeModifier attributeModifier = (AttributeModifier)entry.getValue();
            double damage = attributeModifier.getOperation() != 1 && attributeModifier.getOperation() != 2 ? attributeModifier.getAmount() : attributeModifier.getAmount() * 100.0;
            return attributeModifier.getAmount() > 1.0 ? 1.0f + (float)damage : 1.0f;
        }
        return 1.0f;
    }

    public boolean hasItemMoreTimes(int slotIn) {
        boolean has = false;
        ArrayList<ItemStack> stacks = new ArrayList<ItemStack>();
        stacks.clear();
        for (int i = 0; i < Minecraft.thePlayer.inventory.getSizeInventory(); ++i) {
            if (!stacks.contains(InventoryUtils.getStackInSlot(i))) {
                stacks.add(InventoryUtils.getStackInSlot(i));
                continue;
            }
            if (InventoryUtils.getStackInSlot(i) != InventoryUtils.getStackInSlot(slotIn)) continue;
            return true;
        }
        return false;
    }

    public int getBestWeaponInHotbar() {
        int originalSlot = Minecraft.thePlayer.inventory.currentItem;
        int weaponSlot = -1;
        float weaponDamage = 1.0f;
        int slot = 0;
        while (slot < 9) {
            ItemStack itemStack = Minecraft.thePlayer.inventory.getStackInSlot(slot);
            if (itemStack != null) {
                float damage = InventoryUtils.getItemDamage(itemStack);
                damage += EnchantmentHelper.getModifierForCreature(itemStack, EnumCreatureAttribute.UNDEFINED);
                if (this.f > weaponDamage) {
                    weaponDamage = damage;
                    weaponSlot = slot;
                }
            }
            slot = (byte)(slot + 1);
        }
        if (weaponSlot != -1) {
            return weaponSlot;
        }
        return originalSlot;
    }

    public int getBestWeapon() {
        int originalSlot = Minecraft.thePlayer.inventory.currentItem;
        int weaponSlot = -1;
        float weaponDamage = 1.0f;
        for (int slot = 0; slot < Minecraft.thePlayer.inventory.getSizeInventory(); slot = (int)((byte)(slot + 1))) {
            ItemStack itemStack;
            if (InventoryUtils.getStackInSlot(slot) == null || (itemStack = InventoryUtils.getStackInSlot(slot)) == null || itemStack.getItem() == null || !(itemStack.getItem() instanceof ItemSword)) continue;
            float damage = InventoryUtils.getItemDamage(itemStack);
            damage += EnchantmentHelper.getModifierForCreature(itemStack, EnumCreatureAttribute.UNDEFINED);
            if (!(this.f > weaponDamage)) continue;
            weaponDamage = damage;
            weaponSlot = slot;
        }
        if (weaponSlot != -1) {
            return weaponSlot;
        }
        return originalSlot;
    }

    public int getArmorProt(int i) {
        int armorprot = -1;
        if (InventoryUtils.getStackInSlot(i) != null && InventoryUtils.getStackInSlot(i).getItem() != null && InventoryUtils.getStackInSlot(i).getItem() instanceof ItemArmor) {
            ItemStack[] arritemStack = new ItemStack[]{Minecraft.thePlayer.inventory.getStackInSlot(i)};
            armorprot = ((ItemArmor)Minecraft.thePlayer.inventory.getStackInSlot(i).getItem()).getArmorMaterial().getDamageReductionAmount(InventoryUtils.getItemType(Minecraft.thePlayer.inventory.getStackInSlot(i))) + EnchantmentHelper.getEnchantmentModifierDamage(arritemStack, DamageSource.generic);
        }
        return armorprot;
    }

    public static int getFirstItem(Item i1) {
        for (int i = 0; i < Minecraft.thePlayer.inventory.getSizeInventory(); ++i) {
            if (InventoryUtils.getStackInSlot(i) == null || InventoryUtils.getStackInSlot(i).getItem() == null || InventoryUtils.getStackInSlot(i).getItem() != i1) continue;
            return i;
        }
        return -1;
    }

    public static boolean isBestSword(ItemStack itemSword, int slot) {
        if (itemSword != null && itemSword.getItem() instanceof ItemSword) {
            for (int i = 0; i < Minecraft.thePlayer.inventory.getSizeInventory(); ++i) {
                ItemStack iStack = Minecraft.thePlayer.inventory.getStackInSlot(i);
                if (iStack == null || !(iStack.getItem() instanceof ItemSword) || !(InventoryUtils.getItemDamage(iStack) >= InventoryUtils.getItemDamage(itemSword)) || slot == i) continue;
                return false;
            }
        }
        return true;
    }

    public static void swap(int slot1, int hotbarSlot) {
        if (hotbarSlot == slot1 - 36) {
            return;
        }
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.playerController.windowClick(Minecraft.thePlayer.inventoryContainer.windowId, slot1, hotbarSlot, 2, Minecraft.thePlayer);
    }

    public static int getDepthStriderLevel() {
        return EnchantmentHelper.getDepthStriderModifier(Wrapper.getPlayer());
    }
}

