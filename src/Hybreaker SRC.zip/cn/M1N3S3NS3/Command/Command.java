/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Command;

import cn.M1N3S3NS3.Util.Chat.Helper;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

public abstract class Command {
    private String name;
    private String[] alias;
    private String syntax;
    private String help;

    public Command(String name, String[] alias, String syntax, String help) {
        this.name = name.toLowerCase();
        this.syntax = syntax.toLowerCase();
        this.help = help;
        this.alias = alias;
    }

    public abstract String execute(String[] var1);

    public String getName() {
        return this.name;
    }

    public String[] getAlias() {
        return this.alias;
    }

    public String getSyntax() {
        return this.syntax;
    }

    public String getHelp() {
        return this.help;
    }

    public void syntaxError(String msg) {
        Helper.sendMessage(String.format("\u00a77Invalid command usage", msg));
    }

    public void syntaxError(byte errorType) {
        switch (errorType) {
            case 0: {
                this.syntaxError("bad argument");
                break;
            }
            case 1: {
                this.syntaxError("argument gay");
            }
        }
    }

    public static void sendPrivateChatMessage(Object text) {
        Minecraft.getMinecraft();
        Minecraft.thePlayer.addChatComponentMessage(new ChatComponentText("\u00a76[ \u00a7fMineSense \u00a76] \u00a7f" + text.toString()));
    }
}

