/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Command.Commands;

import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Util.Chat.Helper;
import net.minecraft.util.EnumChatFormatting;

public class Toggle
extends Command {
    public Toggle() {
        super("t", new String[]{"toggle", "togl", "turnon", "enable"}, "", "Toggles a specified Module");
    }

    @Override
    public String execute(String[] args) {
        if (args.length == 0) {
            Helper.sendMessage("Correct usage .t <module>");
            return null;
        }
        String[] stringArray = args;
        int n = args.length;
        int n2 = 0;
        while (n2 < n) {
            String s = stringArray[n2];
            boolean found = false;
            Module m = Client.instance.getModuleManager().getAlias(s);
            if (m != null) {
                if (!m.isEnabled()) {
                    m.setEnabled(true);
                } else {
                    m.setEnabled(false);
                }
                found = true;
                if (m.isEnabled()) {
                    Helper.sendMessage(String.valueOf(m.getName()) + (Object)((Object)EnumChatFormatting.GRAY) + " was" + (Object)((Object)EnumChatFormatting.GREEN) + " enabled");
                } else {
                    Helper.sendMessage(String.valueOf(m.getName()) + (Object)((Object)EnumChatFormatting.GRAY) + " was" + (Object)((Object)EnumChatFormatting.RED) + " disabled");
                }
            }
            if (!found) {
                Helper.sendMessage("Module name " + (Object)((Object)EnumChatFormatting.RED) + s + (Object)((Object)EnumChatFormatting.GRAY) + " is invalid");
            }
            ++n2;
        }
        return null;
    }
}

