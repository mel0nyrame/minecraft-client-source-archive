/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Command.Commands;

import cn.M1N3S3NS3.API.EventBus;
import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventMove;
import cn.M1N3S3NS3.API.Events.World.EventPacketReceive;
import cn.M1N3S3NS3.API.Events.World.EventPacketSend;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Command.Commands.AStarCustomPathFinder;
import cn.M1N3S3NS3.Command.Commands.Vec3;
import cn.M1N3S3NS3.UI.notification.Notification;
import cn.M1N3S3NS3.Util.Chat.Helper;
import cn.M1N3S3NS3.Util.MovementUtils;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0CPacketInput;
import net.minecraft.network.play.client.C13PacketPlayerAbilities;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.BlockPos;

public class Teleport
extends Command {
    public static Minecraft mc = Minecraft.getMinecraft();
    private ArrayList<Vec3> path = new ArrayList();
    public boolean tp;
    public BlockPos target;
    public Entity targetEntity;
    public TimerUtil timer = new TimerUtil();

    public Teleport() {
        super("Teleport", new String[]{"teleport", "tp"}, "", "Teleport");
    }

    @Override
    public String execute(String[] args) {
        this.timer = new TimerUtil();
        if (args.length != 3 && args.length != 1) {
            return null;
        }
        Helper.sendMessage("Please Wait...");
        this.timer.reset();
        this.tp = false;
        this.targetEntity = null;
        this.target = null;
        if (args.length == 3) {
            try {
                this.target = new BlockPos(Integer.parseInt(args[0]), Integer.parseInt(args[1]), Integer.parseInt(args[2]));
            }
            catch (Exception e) {
                Helper.sendMessage("Invalid Position!");
                return null;
            }
        } else {
            for (Entity entity : Minecraft.theWorld.loadedEntityList) {
                if (!(entity instanceof EntityPlayer) || Minecraft.thePlayer == entity || !entity.getName().equalsIgnoreCase(args[0])) continue;
                this.targetEntity = entity;
                break;
            }
            if (this.targetEntity == null) {
                Helper.sendMessage("Can not locate " + args[0]);
                return null;
            }
            Helper.sendMessage("Located Player " + this.targetEntity.getName() + "!");
        }
        EventBus.getInstance().register(this);
        return null;
    }

    @EventHandler
    public final void onSendPacket(EventPacketSend event) {
        if (!this.tp && EventPacketSend.getPacket() instanceof C03PacketPlayer) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public final void onReceivePacket(EventPacketReceive event) {
        if (EventPacketReceive.getPacket() instanceof S08PacketPlayerPosLook && !this.tp) {
            this.tp = true;
        }
    }

    @EventHandler
    public void onPre(EventPreUpdate e) {
        if (this.timer.hasReached(8500.0)) {
            Helper.sendMessage("Failed to teleport. Please make sure you are in Hypixel Gaming!");
            EventBus.getInstance().unregister(this);
        }
        Vec3 topFrom = new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ);
        if (this.target == null) {
            this.target = new BlockPos(this.targetEntity.posX, this.targetEntity.posY + 1.0, this.targetEntity.posZ);
        }
        Vec3 to = new Vec3(this.target.getX(), this.target.getY(), this.target.getZ());
        this.path = this.computePath(topFrom, to);
        Helper.sendMessage("Teleporting to X:" + this.target.getX() + " Y:" + this.target.getY() + " Z:" + this.target.getZ());
        EventBus.getInstance().unregister(this);
        new Thread(() -> {
            try {
                Thread.sleep(1750L);
            }
            catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
            }
            mc.getNetHandler().addToSendQueue(new C0CPacketInput(0.0f, 0.0f, true, true));
            C13PacketPlayerAbilities c13PacketPlayerAbilities = new C13PacketPlayerAbilities();
            c13PacketPlayerAbilities.setCreativeMode(false);
            c13PacketPlayerAbilities.setCreativeMode(false);
            c13PacketPlayerAbilities.setFlying(false);
            c13PacketPlayerAbilities.setAllowFlying(false);
            c13PacketPlayerAbilities.setFlySpeed(1.0E8f);
            c13PacketPlayerAbilities.setWalkSpeed(1.0E8f);
            Minecraft.thePlayer.sendQueue.addToSendQueue(c13PacketPlayerAbilities);
            for (Vec3 pathElm : this.path) {
                Minecraft.thePlayer.sendQueue.getNetworkManager().sendPacketNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(pathElm.getX(), pathElm.getY(), pathElm.getZ(), true));
            }
            Minecraft.thePlayer.sendQueue.getNetworkManager().sendPacketNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(this.target.getX(), this.target.getY(), this.target.getZ(), true));
            Minecraft.thePlayer.sendQueue.getNetworkManager().sendPacketNoEvent(new C03PacketPlayer(true));
            Minecraft.thePlayer.setPosition(this.target.getX(), this.target.getY(), this.target.getZ());
            Client.instance.getNotificationManager().getNotifications().add(new Notification("Tppppppp"));
        }).start();
    }

    @EventHandler
    public void onMove(EventMove event) {
        MovementUtils.setSpeed(event, 0.0);
        Minecraft.thePlayer.motionY = 0.0;
        EventMove.y = 0.0;
    }

    private ArrayList<Vec3> computePath(Vec3 topFrom, Vec3 to) {
        if (!this.canPassThrow(new BlockPos(topFrom.mc()))) {
            topFrom = topFrom.addVector(0.0, 1.0, 0.0);
        }
        AStarCustomPathFinder pathfinder = new AStarCustomPathFinder(topFrom, to);
        pathfinder.compute();
        int i = 0;
        Vec3 lastLoc = null;
        Vec3 lastDashLoc = null;
        ArrayList<Vec3> path = new ArrayList<Vec3>();
        ArrayList<Vec3> pathFinderPath = pathfinder.getPath();
        for (Vec3 pathElm : pathFinderPath) {
            if (i == 0 || i == pathFinderPath.size() - 1) {
                if (lastLoc != null) {
                    path.add(lastLoc.addVector(0.5, 0.0, 0.5));
                }
                path.add(pathElm.addVector(0.5, 0.0, 0.5));
                lastDashLoc = pathElm;
            } else {
                boolean canContinue = true;
                if (pathElm.squareDistanceTo(lastDashLoc) > 80.0) {
                    canContinue = false;
                } else {
                    double smallX = Math.min(lastDashLoc.getX(), pathElm.getX());
                    double smallY = Math.min(lastDashLoc.getY(), pathElm.getY());
                    double smallZ = Math.min(lastDashLoc.getZ(), pathElm.getZ());
                    double bigX = Math.max(lastDashLoc.getX(), pathElm.getX());
                    double bigY = Math.max(lastDashLoc.getY(), pathElm.getY());
                    double bigZ = Math.max(lastDashLoc.getZ(), pathElm.getZ());
                    int x = (int)smallX;
                    block1: while ((double)x <= bigX) {
                        int y = (int)smallY;
                        while ((double)y <= bigY) {
                            int z = (int)smallZ;
                            while ((double)z <= bigZ) {
                                if (!AStarCustomPathFinder.checkPositionValidity(x, y, z, false)) {
                                    canContinue = false;
                                    break block1;
                                }
                                ++z;
                            }
                            ++y;
                        }
                        ++x;
                    }
                }
                if (!canContinue) {
                    path.add(lastLoc.addVector(0.5, 0.0, 0.5));
                    lastDashLoc = lastLoc;
                }
            }
            lastLoc = pathElm;
            ++i;
        }
        return path;
    }

    private boolean canPassThrow(BlockPos pos) {
        Minecraft.getMinecraft();
        Block block = Minecraft.theWorld.getBlockState(new BlockPos(pos.getX(), pos.getY(), pos.getZ())).getBlock();
        return block.getMaterial() == Material.air || block.getMaterial() == Material.plants || block.getMaterial() == Material.vine || block == Blocks.ladder || block == Blocks.water || block == Blocks.flowing_water || block == Blocks.wall_sign || block == Blocks.standing_sign;
    }
}

