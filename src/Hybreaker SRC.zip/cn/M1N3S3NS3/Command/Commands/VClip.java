/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Command.Commands;

import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Util.Chat.Helper;
import cn.M1N3S3NS3.Util.Math.MathUtil;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumChatFormatting;

public class VClip
extends Command {
    private final TimerUtil timer = new TimerUtil();

    public VClip() {
        super("Vc", new String[]{"Vclip", "clip", "verticalclip", "clip"}, "", "Teleport");
    }

    @Override
    public String execute(String[] args) {
        if (args.length > 0) {
            if (MathUtil.parsable(args[0], (byte)4)) {
                double blocks = Double.parseDouble(args[0]);
                Minecraft.thePlayer.setEntityBoundingBox(Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, blocks, 0.0));
                Helper.sendMessage("Vclipped " + blocks + " blocks");
            } else {
                Helper.sendMessage((Object)((Object)EnumChatFormatting.GRAY) + args[0] + " is not a valid number");
            }
        } else {
            Helper.sendMessage((Object)((Object)EnumChatFormatting.GRAY) + "Correct usage .vclip <number>");
        }
        return null;
    }
}

