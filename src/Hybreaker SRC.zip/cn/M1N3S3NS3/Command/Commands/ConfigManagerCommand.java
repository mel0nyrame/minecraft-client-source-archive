/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Command.Commands;

import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Manager.ConfigManager;
import cn.M1N3S3NS3.Util.Chat.Helper;

public class ConfigManagerCommand
extends Command {
    public ConfigManagerCommand() {
        super("ConfigManager", new String[]{"cm"}, "", "Load or Save Local Config");
    }

    @Override
    public String execute(String[] args) {
        if (args.length == 2 && args[0].equalsIgnoreCase("save")) {
            ConfigManager.SaveConfig(args[1]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("load")) {
            ConfigManager.LoadConfig(args[1]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("remove")) {
            ConfigManager.RemoveConfig(args[1]);
        }
        if (args.length != 2) {
            Helper.sendMessageWithoutPrefix("\u00a77\u00a7m\u00a7l==================================");
            Helper.sendMessageWithoutPrefix("\u00a7b\u00a7lNivia ConfigManager");
            Helper.sendMessageWithoutPrefix("\u00a7b.cm save <Configuration name> :\u00a77 Save Config");
            Helper.sendMessageWithoutPrefix("\u00a7b.cm load <Configuration name> :\u00a77 Load Config");
            Helper.sendMessageWithoutPrefix("\u00a7b.cm remove <Configuration name> :\u00a77 Remove Config");
            Helper.sendMessageWithoutPrefix("\u00a77\u00a7m\u00a7l==================================");
        }
        return null;
    }
}

