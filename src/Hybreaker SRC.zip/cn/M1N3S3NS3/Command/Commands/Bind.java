/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package cn.M1N3S3NS3.Command.Commands;

import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Util.Chat.Helper;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.input.Keyboard;

public class Bind
extends Command {
    public Bind() {
        super("Bind", new String[]{"b"}, "", "sketit");
    }

    @Override
    public String execute(String[] args) {
        if (args.length >= 2) {
            Module m = Client.instance.getModuleManager().getAlias(args[0]);
            if (m != null) {
                int k = Keyboard.getKeyIndex((String)args[1].toUpperCase());
                m.setKey(k);
                Object[] arrobject = new Object[]{m.getName(), k == 0 ? "none" : args[1].toUpperCase()};
                Helper.sendMessage(String.format("Bound %s to %s", arrobject));
            } else {
                Helper.sendMessage("Module name " + (Object)((Object)EnumChatFormatting.RED) + args[0] + (Object)((Object)EnumChatFormatting.GRAY) + " is invalid");
            }
        } else {
            Helper.sendMessage("Correct usage .bind <module> <key>");
        }
        return null;
    }
}

