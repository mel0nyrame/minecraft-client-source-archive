/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.Display
 */
package cn.M1N3S3NS3.Command.Commands;

import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Util.Chat.Helper;
import javax.swing.JOptionPane;
import org.lwjgl.opengl.Display;

public class Title
extends Command {
    public Title() {
        super("title", new String[]{"settile", "st", "sett", "stitle"}, "", "Set Client Title");
    }

    @Override
    public String execute(String[] args) {
        String input = JOptionPane.showInputDialog(null, "set title", null);
        if (input != null) {
            if (input.contains("lnt")) {
                Display.setTitle((String)"dRUG");
            } else {
                Display.setTitle((String)input);
                Helper.sendMessage("> Client Title was set to " + input);
            }
        } else {
            Display.setTitle((String)Display.getTitle());
            Helper.sendMessage("> Client Title was set to " + Display.getTitle());
        }
        return null;
    }
}

