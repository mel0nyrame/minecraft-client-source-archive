/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Command.Commands;

import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Util.Chat.Helper;

public class Help
extends Command {
    public Help() {
        super("Help", new String[]{"list"}, "", "sketit");
    }

    @Override
    public String execute(String[] args) {
        if (args.length == 0) {
            Helper.sendMessageWithoutPrefix("\u00a77\u00a7m\u00a7l----------------------------------");
            Helper.sendMessageWithoutPrefix("\u00a7b\u00a7lMineSense Client");
            Helper.sendMessageWithoutPrefix("\u00a7b.help >\u00a77 list commands");
            Helper.sendMessageWithoutPrefix("\u00a7b.t >\u00a77 toggle a module on/off");
            Helper.sendMessageWithoutPrefix("\u00a7b.modlist >\u00a77 list all modules");
            Helper.sendMessageWithoutPrefix("\u00a77\u00a7m\u00a7l----------------------------------");
        } else {
            Helper.sendMessage("Correct usage .help");
        }
        return null;
    }
}

