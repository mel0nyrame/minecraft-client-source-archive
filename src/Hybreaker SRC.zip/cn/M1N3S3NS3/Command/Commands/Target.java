/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Command.Commands;

import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Module.Modules.Combat.KillAura;
import cn.M1N3S3NS3.Util.Chat.ChatUtil;
import cn.M1N3S3NS3.Util.Chat.Helper;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class Target
extends Command {
    protected final Minecraft mc = Minecraft.getMinecraft();
    public Entity targetEntity;

    public Target() {
        super("Target", new String[]{"Target", "target", "target"}, "target", "Target Player");
    }

    @Override
    public String execute(String[] args) {
        if (args == null) {
            Helper.sendMessage(".target <name>");
        } else if (args.length > 0) {
            String name = args[0];
            if (Minecraft.theWorld.getPlayerEntityByName(name) != null) {
                EntityPlayer vip = Minecraft.theWorld.getPlayerEntityByName(name);
                KillAura.vip = vip;
                ChatUtil.printChat("\u00a74[\u00a7cE\u00a74]\u00a78 Now targeting " + args[0]);
                return null;
            }
            KillAura.vip = null;
            ChatUtil.printChat("\u00a74[\u00a7cE\u00a74]\u00a78 No entity with the name \"" + args[0] + "\" currently exists.");
        }
        return null;
    }
}

