/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Command.Commands;

import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Util.Chat.Helper;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.EnumChatFormatting;

public class Hidden
extends Command {
    public static List<String> list = new ArrayList<String>();

    public Hidden() {
        super("hidden", new String[]{"h", "hide"}, "", "Hide a module.");
    }

    @Override
    public String execute(String[] args) {
        if (args.length == 0) {
            Helper.sendMessage("Correct usage .h <module>");
            return null;
        }
        String[] stringArray = args;
        int n = args.length;
        int n2 = 0;
        while (n2 < n) {
            String s = stringArray[n2];
            boolean found = false;
            Module m = Client.getModuleManager().getAlias(s);
            if (m != null) {
                found = true;
                if (!m.wasRemoved()) {
                    m.setRemoved(true);
                    Helper.sendMessage(String.valueOf(m.getName()) + (Object)((Object)EnumChatFormatting.GRAY) + " was" + (Object)((Object)EnumChatFormatting.RED) + " hidden");
                } else {
                    m.setRemoved(false);
                    Helper.sendMessage(String.valueOf(m.getName()) + (Object)((Object)EnumChatFormatting.GRAY) + " was" + (Object)((Object)EnumChatFormatting.GREEN) + " shown");
                }
            }
            if (!found) {
                Helper.sendMessage("Module name " + (Object)((Object)EnumChatFormatting.RED) + s + (Object)((Object)EnumChatFormatting.GRAY) + " is invalid");
            }
            ++n2;
        }
        return null;
    }
}

