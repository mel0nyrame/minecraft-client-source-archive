/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Command.Commands;

import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Util.Chat.Helper;
import net.minecraft.client.Minecraft;

public class Say
extends Command {
    public Say() {
        super("p", new String[]{"list"}, "", "sketit");
    }

    @Override
    public String execute(String[] args) {
        if (args.length == 0) {
            Helper.sendMessage(".p <Text>");
        } else {
            String msg = "";
            int i = 1;
            while (i < args.length) {
                msg = String.valueOf(String.valueOf(String.valueOf(String.valueOf(msg)))) + args[i] + " ";
                ++i;
            }
            Minecraft.thePlayer.sendChatMessage("/p " + msg);
            new Thread(() -> {
                try {
                    Thread.sleep(350L);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Minecraft.thePlayer.sendChatMessage("/p leave");
            }).start();
        }
        return null;
    }
}

