/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Command.Commands;

import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Manager.TagManager;
import cn.M1N3S3NS3.Util.Chat.Helper;
import cn.M1N3S3NS3.Util.Management;
import cn.M1N3S3NS3.Util.Math.Vec3f;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Waypoint
extends Command {
    public static List<String> list = new ArrayList<String>();

    public Waypoint() {
        super("Waypoint", new String[]{"w", "Waypoint"}, "", "set custom name for a module.");
    }

    @Override
    public String execute(String[] args) {
        TagManager manager = Management.getTagManager();
        if (args.length == 6 && args[0].equalsIgnoreCase("add")) {
            if (manager.getMapping().containsKey(args[1])) {
                Helper.sendMessage("Tag with the same name is existing!");
                Helper.sendMessage("Try again with another name.");
            } else {
                Vec3f location = new Vec3f(Integer.parseInt(args[2]), Integer.parseInt(args[3]), Integer.parseInt(args[4]));
                Helper.sendMessage("Added Tag " + args[5] + " successfully.");
                manager.getMapping().put(args[5], location);
            }
        } else if (args.length == 3 && args[1].equalsIgnoreCase("remove")) {
            if (manager.getMapping().containsKey(args[2])) {
                manager.getMapping().remove(args[2]);
                Helper.sendMessage("Removed Tag " + args[2] + " successfully.");
            } else {
                Helper.sendMessage("There's no tag named " + args[2] + "!");
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("clear")) {
            manager.getMapping().clear();
            Helper.sendMessage("Removed all tags.");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("list")) {
            Helper.sendMessage("As the followings:");
            for (Map.Entry<String, Vec3f> entry : manager.getMapping().entrySet()) {
                Vec3f vec = entry.getValue();
                Helper.sendMessage(String.valueOf(entry.getKey()) + " " + "[" + vec.getX() + ", " + vec.getY() + ", " + vec.getZ() + "]");
            }
        }
        return null;
    }
}

