/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module;

import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.Command.Command;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Util.Chat.Helper;
import cn.M1N3S3NS3.Util.Math.MathUtil;

class Module$1
extends Command {
    private final Module m;
    final Module this$0;

    Module$1(Module var1, String $anonymous0, String[] $anonymous1, String $anonymous2, String $anonymous3) {
        super($anonymous0, $anonymous1, $anonymous2, $anonymous3);
        this.this$0 = var1;
        this.m = var1;
    }

    @Override
    public String execute(String[] args) {
        if (args.length >= 2) {
            Value option = null;
            Numbers fuck = null;
            Mode xd = null;
            for (Value<?> v : this.m.values) {
                if (!(v instanceof Option) || !v.getName().equalsIgnoreCase(args[0])) continue;
                option = (Option)v;
            }
            if (option != null) {
                option.setValue((Boolean)option.getValue() == false);
                Helper.sendMessage(String.format("%s has been set to %s", option.getName(), option.getValue()));
            } else {
                for (Value<?> v : this.m.values) {
                    if (!(v instanceof Numbers) || !v.getName().equalsIgnoreCase(args[0])) continue;
                    fuck = (Numbers)v;
                }
                if (fuck != null) {
                    if (MathUtil.parsable(args[1], (byte)4)) {
                        double v1 = MathUtil.round(Double.parseDouble(args[1]), 1);
                        fuck.setValue(v1 > (Double)fuck.getMaximum() ? (Double)fuck.getMaximum() : v1);
                        Helper.sendMessage(String.format("> %s has been set to %s", fuck.getName(), fuck.getValue()));
                    } else {
                        Helper.sendMessage("> " + args[1] + " is not a number");
                    }
                }
                for (Value<?> v : this.m.values) {
                    if (!args[0].equalsIgnoreCase(v.getDisplayName()) || !(v instanceof Mode)) continue;
                    xd = (Mode)v;
                }
                if (xd != null) {
                    if (xd.isValid(args[1])) {
                        xd.setMode(args[1]);
                        Helper.sendMessage(String.format("> %s set to %s", xd.getName(), xd.getModeAsString()));
                    } else {
                        Helper.sendMessage("> " + args[1] + " is an invalid mode");
                    }
                }
            }
            if (fuck == null && option == null && xd == null) {
                this.syntaxError("Valid .<module> <setting> <mode if needed>");
            }
        } else if (args.length >= 1) {
            Value option = null;
            for (Value<?> fuck1 : this.m.values) {
                if (!(fuck1 instanceof Option) || !fuck1.getName().equalsIgnoreCase(args[0])) continue;
                option = (Option)fuck1;
            }
            if (option != null) {
                option.setValue((Boolean)option.getValue() == false);
                String fuck2 = option.getName().substring(1);
                String xd2 = option.getName().substring(0, 1).toUpperCase();
                if (((Boolean)option.getValue()).booleanValue()) {
                    Helper.sendMessage(String.format("> %s has been set to \u00a7a%s", String.valueOf(xd2) + fuck2, option.getValue()));
                } else {
                    Helper.sendMessage(String.format("> %s has been set to \u00a7c%s", String.valueOf(xd2) + fuck2, option.getValue()));
                }
            } else {
                this.syntaxError("Valid .<module> <setting> <mode if needed>");
            }
        } else {
            Helper.sendMessage(String.format("%s Values: \n %s", String.valueOf(this.getName().substring(0, 1).toUpperCase()) + this.getName().substring(1).toLowerCase(), this.getSyntax(), "false"));
        }
        return null;
    }
}

