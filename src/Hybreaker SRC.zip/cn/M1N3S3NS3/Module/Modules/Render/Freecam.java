/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Misc.EventCollideWithBlock;
import cn.M1N3S3NS3.API.Events.World.EventPacketReceive;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.event.ClickEvent;
import net.minecraft.event.HoverEvent;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatStyle;
import net.minecraft.util.EnumChatFormatting;

public class Freecam
extends Module {
    private EntityOtherPlayerMP copy;
    private double x;
    private double y;
    private double z;

    public Freecam() {
        super("Freecam", new String[]{"Freecam"}, ModuleType.Player);
        this.setColor(new Color(221, 214, 51).getRGB());
    }

    @Override
    public void onEnable() {
        this.copy = new EntityOtherPlayerMP(Minecraft.theWorld, Minecraft.thePlayer.getGameProfile());
        this.copy.clonePlayer(Minecraft.thePlayer, true);
        this.copy.setLocationAndAngles(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ, Minecraft.thePlayer.rotationYaw, Minecraft.thePlayer.rotationPitch);
        this.copy.rotationYawHead = Minecraft.thePlayer.rotationYawHead;
        this.copy.setEntityId(-1337);
        this.copy.setSneaking(Minecraft.thePlayer.isSneaking());
        Minecraft.theWorld.addEntityToWorld(this.copy.getEntityId(), this.copy);
        this.x = Minecraft.thePlayer.posX;
        this.y = Minecraft.thePlayer.posY;
        this.z = Minecraft.thePlayer.posZ;
    }

    @EventHandler
    private void onPreMotion(EventPreUpdate e) {
        PlayerCapabilities.isFlying = true;
        Minecraft.thePlayer.noClip = true;
        Minecraft.thePlayer.capabilities.setFlySpeed(0.1f);
        e.setCancelled(true);
    }

    @EventHandler
    private void onPacketSend(EventPacketReceive e) {
        if (EventPacketReceive.getPacket() instanceof C03PacketPlayer) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    private void onBB(EventCollideWithBlock e) {
        e.setBoundingBox(null);
    }

    @Override
    public void onDisable() {
        int x = (int)Minecraft.thePlayer.posX;
        int y = (int)Minecraft.thePlayer.posY;
        int z = (int)Minecraft.thePlayer.posZ;
        Object[] objectArray = new Object[2];
        objectArray[0] = ChatFormatting.GREEN + Client.name + " > " + ChatFormatting.GRAY;
        objectArray[1] = String.valueOf(Minecraft.thePlayer.getName()) + ChatFormatting.GOLD + " [" + x + "," + y + "," + z + "]";
        ChatComponentText ChatComponent = new ChatComponentText(String.format("%s%s", objectArray));
        ChatComponent.appendSibling(new ChatComponentText((Object)((Object)EnumChatFormatting.RED) + " [\u70b9\u6211TP\u5230\u4f4d\u7f6e" + "]").setChatStyle(new ChatStyle().setChatClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, new StringBuilder().insert(0, ".tp ").append(String.valueOf(x) + " " + y + " " + z).toString())).setChatHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ChatComponentText("\u70b9\u51fbTP\u5230\u73a9\u5bb6\uff1a" + Minecraft.thePlayer.getName())))));
        Minecraft.thePlayer.addChatMessage(ChatComponent);
        Minecraft.thePlayer.setSpeed(0.0);
        Minecraft.thePlayer.setLocationAndAngles(this.copy.posX, this.copy.posY, this.copy.posZ, this.copy.rotationYaw, this.copy.rotationPitch);
        Minecraft.thePlayer.rotationYawHead = this.copy.rotationYawHead;
        Minecraft.theWorld.removeEntityFromWorld(this.copy.getEntityId());
        Minecraft.thePlayer.setSneaking(this.copy.isSneaking());
        this.copy = null;
        Freecam.mc.renderGlobal.loadRenderers();
        Minecraft.thePlayer.setPosition(this.x, this.y, this.z);
        mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + 0.01, Minecraft.thePlayer.posZ, Minecraft.thePlayer.onGround));
        PlayerCapabilities.isFlying = false;
        Minecraft.thePlayer.noClip = false;
        Minecraft.theWorld.removeEntityFromWorld(-1);
    }
}

