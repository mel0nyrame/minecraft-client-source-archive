/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  javax.vecmath.Vector3d
 *  javax.vecmath.Vector4d
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Misc.EventLivingUpdate;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.FriendManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.AntiBot;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.Util.Render.MoonRender;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector4d;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.StringUtils;
import org.lwjgl.opengl.GL11;

public class NameTags
extends Module {
    private Option<Boolean> players = new Option<Boolean>("Players", true);
    private Option<Boolean> animals = new Option<Boolean>("Animals", true);
    private Option<Boolean> mobs = new Option<Boolean>("Mobs", false);
    private Option<Boolean> invisibles = new Option<Boolean>("Invisibles", false);
    private Option<Boolean> passives = new Option<Boolean>("Passives", true);
    private Option<Boolean> health = new Option<Boolean>("Health", true);
    private Option<Boolean> armor = new Option<Boolean>("Armor", true);
    private Option<Boolean> distance = new Option<Boolean>("Distance", true);
    private Option<Boolean> potions = new Option<Boolean>("Potions", true);
    private Option<Boolean> stripColorCodes = new Option<Boolean>("StripColorCodes", false);
    public static Mode<Enum> backDropModeEnumValue = new Mode("BackdropMode", "BackdropMode", (Enum[])backDropMode.values(), (Enum)backDropMode.BOTH);
    private Option<Boolean> font = new Option<Boolean>("Font", true);

    public NameTags() {
        super("NameTags", new String[]{"tags"}, ModuleType.Render);
        this.setColor(new Color(29, 187, 102).getRGB());
        this.addValues(this.players, this.animals, this.mobs, this.invisibles, this.passives, this.health, this.armor, this.distance, this.potions, this.stripColorCodes, backDropModeEnumValue, this.font);
    }

    @EventHandler
    public void onRender2D(EventRender2D event) {
        Minecraft.theWorld.loadedEntityList.forEach(entity -> {
            EntityLivingBase ent;
            if (entity instanceof EntityLivingBase && this.isValid(ent = (EntityLivingBase)entity)) {
                if (entity.getUniqueID() != Minecraft.thePlayer.getUniqueID() && MoonRender.isInViewFrustrum(ent)) {
                    double posX = MoonRender.interpolate(entity.posX, entity.lastTickPosX, event.getPartialTicks());
                    double posY = MoonRender.interpolate(entity.posY, entity.lastTickPosY, event.getPartialTicks());
                    double posZ = MoonRender.interpolate(entity.posZ, entity.lastTickPosZ, event.getPartialTicks());
                    double width = (double)entity.width / 1.5;
                    double height = (double)entity.height + (entity.isSneaking() ? -0.3 : 0.2);
                    AxisAlignedBB aabb = new AxisAlignedBB(posX - width, posY, posZ - width, posX + width, posY + height + 0.05, posZ + width);
                    List<Vector3d> vectors = Arrays.asList(new Vector3d(aabb.minX, aabb.minY, aabb.minZ), new Vector3d(aabb.minX, aabb.maxY, aabb.minZ), new Vector3d(aabb.maxX, aabb.minY, aabb.minZ), new Vector3d(aabb.maxX, aabb.maxY, aabb.minZ), new Vector3d(aabb.minX, aabb.minY, aabb.maxZ), new Vector3d(aabb.minX, aabb.maxY, aabb.maxZ), new Vector3d(aabb.maxX, aabb.minY, aabb.maxZ), new Vector3d(aabb.maxX, aabb.maxY, aabb.maxZ));
                    NameTags.mc.entityRenderer.setupCameraTransform(event.getPartialTicks(), 0);
                    Vector4d position = null;
                    for (Vector3d vector : vectors) {
                        mc.getRenderManager();
                        mc.getRenderManager();
                        mc.getRenderManager();
                        vector = MoonRender.project(vector.x - RenderManager.viewerPosX, vector.y - RenderManager.viewerPosY, vector.z - RenderManager.viewerPosZ);
                        if (vector == null || !(vector.z >= 0.0) || !(vector.z < 1.0)) continue;
                        if (position == null) {
                            position = new Vector4d(vector.x, vector.y, vector.z, 0.0);
                        }
                        position.x = Math.min(vector.x, position.x);
                        position.y = Math.min(vector.y, position.y);
                        position.z = Math.max(vector.x, position.z);
                        position.w = Math.max(vector.y, position.w);
                    }
                    NameTags.mc.entityRenderer.setupOverlayRendering();
                    if (position != null) {
                        GL11.glPushMatrix();
                        if (ent instanceof EntityPlayer) {
                            if (((Boolean)this.armor.getValue()).booleanValue()) {
                                this.drawArmor((EntityPlayer)ent, position.x + (position.z - position.x) / 2.0, position.y - 8.0 - (double)(FontLoaders.Comfortaa18.getHeight() * 2));
                            }
                            if (((Boolean)this.potions.getValue()).booleanValue()) {
                                this.drawPotions((EntityPlayer)ent, position.x + (position.z - position.x) / 2.0, position.y - 1.0 - (double)(FontLoaders.Comfortaa18.getHeight() * 2));
                            }
                        }
                        float x = (float)position.x;
                        float x2 = (float)position.z;
                        float y = (float)position.y - 1.0f;
                        String healthtext = (ent.getHealth() >= 16.0f ? ChatFormatting.GREEN : (ent.getHealth() >= 12.0f ? ChatFormatting.YELLOW : (ent.getHealth() >= 8.0f ? ChatFormatting.RED : ChatFormatting.DARK_RED))) + " " + (int)ent.getHealth() + (Object)((Object)EnumChatFormatting.RED) + "\u2764";
                        String nametext = String.valueOf(((Boolean)this.distance.getValue()).booleanValue() ? "(" + Math.round(Minecraft.thePlayer.getDistance(ent.posX, ent.posY, ent.posZ)) + "m) " : "") + ((Boolean)this.stripColorCodes.getValue() != false ? StringUtils.stripControlCodes(ent.getName()) : ent.getDisplayName().getUnformattedText()) + ((Boolean)this.health.getValue() != false ? healthtext : "");
                        if (backDropModeEnumValue.getValue() == backDropMode.BOTH || backDropModeEnumValue.getValue() == backDropMode.NAME) {
                            MoonRender.drawRect((double)(x + (x2 - x) / 2.0f - (float)((((Boolean)this.font.getValue()).booleanValue() ? FontLoaders.Comfortaa18.getStringWidth(nametext) : Minecraft.fontRendererObj.getStringWidth(nametext) / 2) / 2)) - 2.5, y - (float)(((Boolean)this.font.getValue()).booleanValue() ? FontLoaders.Comfortaa18.getHeight() + 6 : Minecraft.fontRendererObj.FONT_HEIGHT), (((Boolean)this.font.getValue()).booleanValue() ? FontLoaders.Comfortaa18.getStringWidth(nametext) : Minecraft.fontRendererObj.getStringWidth(nametext) / 2) + 5, ((Boolean)this.font.getValue()).booleanValue() ? FontLoaders.Comfortaa18.getHeight() + 6 : Minecraft.fontRendererObj.FONT_HEIGHT, new Color(0, 0, 0, 120).getRGB());
                        }
                        if (((Boolean)this.font.getValue()).booleanValue()) {
                            FontLoaders.Comfortaa18.drawStringWithShadow(nametext, x + (x2 - x) / 2.0f - (float)(FontLoaders.Comfortaa18.getStringWidth(nametext) / 2), y - (float)FontLoaders.Comfortaa18.getHeight() - 2.0f, this.getNameColor(ent));
                        } else {
                            GL11.glPushMatrix();
                            GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
                            Minecraft.fontRendererObj.drawStringWithShadow(nametext, (x + (x2 - x) / 2.0f - (float)(Minecraft.fontRendererObj.getStringWidth(nametext) / 4)) * 2.0f, (y - (float)(Minecraft.fontRendererObj.FONT_HEIGHT / 2) - 2.0f) * 2.0f, this.getNameColor(ent));
                            GL11.glPopMatrix();
                            GL11.glScalef((float)1.0f, (float)1.0f, (float)1.0f);
                        }
                        GL11.glPopMatrix();
                    }
                }
            }
        });
    }

    @EventHandler
    public void onNamePlate(EventLivingUpdate event) {
        event.setCancelled(event.getEntity() instanceof EntityLivingBase && this.isValid((EntityLivingBase)event.getEntity()));
    }

    public void drawArmor(EntityPlayer player, double posX, double posY) {
        ArrayList<ItemStack> stacks = new ArrayList<ItemStack>();
        if (player.getHeldItem() != null) {
            stacks.add(player.getHeldItem());
        }
        stacks.addAll(Arrays.stream(player.inventory.armorInventory).filter(Objects::nonNull).collect(Collectors.toList()));
        double offset = posX - (double)stacks.size() * 9.5;
        for (ItemStack stack : stacks) {
            if (backDropModeEnumValue.getValue() == backDropMode.BOTH || backDropModeEnumValue.getValue() == backDropMode.ARMOR) {
                MoonRender.drawRect(offset - 1.0, posY - 1.0, 18.0, 18.0, new Color(0, 0, 0, 120).getRGB());
            }
            GlStateManager.enableLighting();
            mc.getRenderItem().renderItemIntoGUI(stack, (int)offset, (int)posY);
            mc.getRenderItem().renderItemOverlayIntoGUI(Minecraft.fontRendererObj, stack, (int)offset, (int)posY, "");
            GlStateManager.disableLighting();
            NBTTagList enchants = stack.getEnchantmentTagList();
            GlStateManager.pushMatrix();
            GlStateManager.disableDepth();
            if (stack.isStackable()) {
                if (((Boolean)this.font.getValue()).booleanValue()) {
                    FontLoaders.Comfortaa18.drawStringWithShadow(String.valueOf(stack.stackSize), offset, posY + 11.0, 14537190);
                } else {
                    GL11.glPushMatrix();
                    GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
                    Minecraft.fontRendererObj.drawStringWithShadow(String.valueOf(stack.stackSize), (float)(offset * 2.0), (float)(posY + 11.0) * 2.0f, 14537190);
                    GL11.glPopMatrix();
                    GL11.glScalef((float)1.0f, (float)1.0f, (float)1.0f);
                }
            }
            if (stack.getItem() == Items.golden_apple && stack.getMetadata() == 1) {
                if (((Boolean)this.font.getValue()).booleanValue()) {
                    FontLoaders.Comfortaa18.drawStringWithShadow("op", offset, posY + 2.0, -65536);
                } else {
                    GL11.glPushMatrix();
                    GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
                    Minecraft.fontRendererObj.drawStringWithShadow("op", (float)(offset * 2.0), (float)((posY + 2.0) * 2.0), -65536);
                    GL11.glPopMatrix();
                    GL11.glScalef((float)1.0f, (float)1.0f, (float)1.0f);
                }
            }
            Enchantment[] goodEnchants = new Enchantment[]{Enchantment.protection, Enchantment.unbreaking, Enchantment.sharpness, Enchantment.fireAspect, Enchantment.efficiency, Enchantment.featherFalling, Enchantment.power, Enchantment.flame, Enchantment.punch, Enchantment.fortune, Enchantment.infinity, Enchantment.thorns};
            if (enchants != null) {
                double enchantmentY = posY + 11.0;
                if (enchants.tagCount() > 3) {
                    if (((Boolean)this.font.getValue()).booleanValue()) {
                        FontLoaders.Comfortaa18.drawStringWithShadow("god", offset, enchantmentY, new Color(15741213).getRGB());
                    } else {
                        GL11.glPushMatrix();
                        GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
                        Minecraft.fontRendererObj.drawStringWithShadow("god", (float)(offset * 2.0), (float)(enchantmentY * 2.0), new Color(15741213).getRGB());
                        GL11.glPopMatrix();
                        GL11.glScalef((float)1.0f, (float)1.0f, (float)1.0f);
                    }
                } else {
                    int index = 0;
                    while (index < enchants.tagCount()) {
                        short id = enchants.getCompoundTagAt(index).getShort("id");
                        short level = enchants.getCompoundTagAt(index).getShort("lvl");
                        Enchantment enc = Enchantment.getEnchantmentById(id);
                        Enchantment[] enchantmentArray = goodEnchants;
                        int n = goodEnchants.length;
                        int n2 = 0;
                        while (n2 < n) {
                            Enchantment goodEnchant = enchantmentArray[n2];
                            if (enc == goodEnchant) {
                                String encName = Objects.requireNonNull(enc).getTranslatedName(level).substring(0, 1).toLowerCase();
                                encName = level > 99 ? String.valueOf(encName) + "99+" : String.valueOf(encName) + level;
                                if (((Boolean)this.font.getValue()).booleanValue()) {
                                    FontLoaders.Comfortaa18.drawStringWithShadow(encName, offset, enchantmentY, 14537190);
                                } else {
                                    GL11.glPushMatrix();
                                    GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
                                    Minecraft.fontRendererObj.drawStringWithShadow(encName, (float)(offset * 2.0), (float)(enchantmentY * 2.0), 14537190);
                                    GL11.glPopMatrix();
                                    GL11.glScalef((float)1.0f, (float)1.0f, (float)1.0f);
                                }
                                enchantmentY -= 5.0;
                                break;
                            }
                            ++n2;
                        }
                        ++index;
                    }
                }
            }
            GlStateManager.enableDepth();
            GlStateManager.popMatrix();
            offset += 19.0;
        }
    }

    public void drawPotions(EntityPlayer player, double posX, double posY) {
        ArrayList<ItemStack> stacks = new ArrayList<ItemStack>();
        if (player.getHeldItem() != null) {
            stacks.add(player.getHeldItem());
        }
        stacks.addAll(Arrays.stream(player.inventory.armorInventory).filter(Objects::nonNull).collect(Collectors.toList()));
        double offset = posY - (double)(stacks.isEmpty() ? (((Boolean)this.font.getValue()).booleanValue() ? 0 : -4) : ((Boolean)this.font.getValue() != false ? 20 : 16));
        Iterator<PotionEffect> iterator = player.getActivePotionEffects().iterator();
        while (iterator.hasNext()) {
            PotionEffect o;
            PotionEffect effect = o = iterator.next();
            Potion potion = Potion.potionTypes[effect.getPotionID()];
            boolean potRanOut = (double)effect.getDuration() != 0.0;
            String effectpower = " ";
            if (potion == null || !player.isPotionActive(potion) || !potRanOut) continue;
            if (effect.getAmplifier() == 1) {
                effectpower = " II ";
            } else if (effect.getAmplifier() == 2) {
                effectpower = " III ";
            } else if (effect.getAmplifier() == 3) {
                effectpower = " IV ";
            }
            if (((Boolean)this.font.getValue()).booleanValue()) {
                FontLoaders.Comfortaa18.drawStringWithShadow(String.valueOf(I18n.format(potion.getName(), new Object[0])) + ChatFormatting.GRAY + effectpower + ": " + Potion.getDurationString(effect), posX - (double)(FontLoaders.Comfortaa18.getStringWidth(String.valueOf(I18n.format(potion.getName(), new Object[0])) + ChatFormatting.GRAY + effectpower + ": " + Potion.getDurationString(effect)) / 2), offset, potion.getLiquidColor());
            } else {
                GL11.glPushMatrix();
                GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
                Minecraft.fontRendererObj.drawStringWithShadow(String.valueOf(I18n.format(potion.getName(), new Object[0])) + ChatFormatting.GRAY + effectpower + ": " + Potion.getDurationString(effect), (float)((posX - (double)(Minecraft.fontRendererObj.getStringWidth(String.valueOf(I18n.format(potion.getName(), new Object[0])) + ChatFormatting.GRAY + effectpower + ": " + Potion.getDurationString(effect)) / 4)) * 2.0), (float)(offset * 2.0), potion.getLiquidColor());
                GL11.glPopMatrix();
                GL11.glScalef((float)1.0f, (float)1.0f, (float)1.0f);
            }
            offset -= (double)((Boolean)this.font.getValue() != false ? 10 : 6);
        }
    }

    private boolean isValid(EntityLivingBase entity) {
        if (!AntiBot.isBot(entity)) {
            if (Minecraft.thePlayer != entity && entity.getEntityId() != -1488 && this.isValidType(entity) && entity.isEntityAlive() && (!entity.isInvisible() || ((Boolean)this.invisibles.getValue()).booleanValue())) {
                return true;
            }
        }
        return false;
    }

    private boolean isValidType(EntityLivingBase entity) {
        return (Boolean)this.players.getValue() != false && entity instanceof EntityPlayer || (Boolean)this.mobs.getValue() != false && (entity instanceof EntityMob || entity instanceof EntitySlime) || (Boolean)this.passives.getValue() != false && (entity instanceof EntityVillager || entity instanceof EntityGolem) || (Boolean)this.animals.getValue() != false && entity instanceof EntityAnimal;
    }

    private int getNameColor(EntityLivingBase ent) {
        Client.instance.getFriendManager();
        if (FriendManager.isFriend(ent.getName())) {
            return new Color(122, 190, 255).getRGB();
        }
        if (ent.getName().equals(Minecraft.thePlayer.getName())) {
            return new Color(-6684775).getRGB();
        }
        return new Color(240, 177, 175).getRGB();
    }

    private static enum backDropMode {
        BOTH,
        ARMOR,
        NAME,
        NONE;

    }
}

