/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventBlockRenderSide;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Events.Render.EventRender3D;
import cn.M1N3S3NS3.API.Events.World.EventPacketReceive;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Manager.FileManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.UI.Font.CFontRenderer;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.Util.BlockUtil;
import cn.M1N3S3NS3.Util.BlockUtils;
import cn.M1N3S3NS3.Util.Colors;
import cn.M1N3S3NS3.Util.Render.RenderUtil;
import cn.M1N3S3NS3.Util.Render.XrayBlock;
import com.google.common.collect.Lists;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.BlockOre;
import net.minecraft.block.BlockRedstoneOre;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.server.S22PacketMultiBlockChange;
import net.minecraft.network.play.server.S23PacketBlockChange;
import net.minecraft.src.Config;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;

public class Xray
extends Module {
    private static final HashSet blockIDs = new HashSet();
    private int opacity = 160;
    float ULX2 = 2.0f;
    private List<Integer> KEY_IDS = Lists.newArrayList((Object[])new Integer[]{10, 11, 8, 9, 14, 15, 16, 21, 41, 42, 46, 48, 52, 56, 57, 61, 62, 73, 74, 84, 89, 103, 116, 117, 118, 120, 129, 133, 137, 145, 152, 153, 154});
    public CopyOnWriteArrayList<XrayBlock> list = new CopyOnWriteArrayList();
    public static Numbers<Double> OPACITY = new Numbers<Double>("OPACITY", "OPACITY", 160.0, 0.0, 255.0, 5.0);
    public static Numbers<Double> Dis = new Numbers<Double>("Dis", "Dis", 50.0, 0.0, 256.0, 1.0);
    public static Numbers<Double> radXZ = new Numbers<Double>("radXZ", "radXZ", 20.0, 5.0, 200.0, 1.0);
    public static Numbers<Double> radY = new Numbers<Double>("radY", "radY", 6.0, 2.0, 50.0, 1.0);
    public static Option<Boolean> CAVE = new Option<Boolean>("CAVE", "CAVE", false);
    public static Option<Boolean> Packet = new Option<Boolean>("Packet", "Packet", false);
    public static Option<Boolean> Coord = new Option<Boolean>("Coord", "Coord", false);
    public static Option<Boolean> Tags = new Option<Boolean>("Tags", "Tags", false);
    public static Option<Boolean> Tracers = new Option<Boolean>("Tracers", "Tracers", false);
    public static Option<Boolean> ESP = new Option<Boolean>("ESP", "ESP", true);
    public static Option<Boolean> CoalOre = new Option<Boolean>("Coal Ore", "Coal Ore", true);
    public static Option<Boolean> RedStoneOre = new Option<Boolean>("RedStone Ore", "RedStone Ore", true);
    public static Option<Boolean> IronOre = new Option<Boolean>("Iron Ore", "Iron Ore", true);
    public static Option<Boolean> GoldOre = new Option<Boolean>("Gold Ore", "Gold Ore", true);
    public static Option<Boolean> DiamondOre = new Option<Boolean>("Diamond Ore", "Diamond Ore", true);
    public static Option<Boolean> EmeraldOre = new Option<Boolean>("Emerald Ore", "Emerald Ore", true);
    public static Option<Boolean> LapisOre = new Option<Boolean>("Lapis Ore", "Lapis Ore", true);
    public static Option<Boolean> uhc = new Option<Boolean>("UHC", "UHC", true);
    int done = 0;
    public static int all;
    public static ArrayList blocks;
    public static final boolean[] ids;
    Thread updater;
    public boolean loaded;
    public static ArrayList<BlockPos> glow;
    private static final File CLEAN_DIR;

    static {
        blocks = new ArrayList();
        ids = new boolean[4096];
        CLEAN_DIR = FileManager.getConfigFile("Xray");
        glow = new ArrayList();
        blocks = new ArrayList();
    }

    public Xray() {
        super("Xray", new String[]{"Xray"}, ModuleType.Render);
        this.addValues(OPACITY, CAVE, Tags, Tracers, Coord, ESP, uhc, Dis, CoalOre, RedStoneOre, IronOre, GoldOre, DiamondOre, EmeraldOre, LapisOre, radXZ, radY);
        super.setRemoved(true);
    }

    @Override
    public void onEnable() {
        this.list.clear();
        this.opacity = ((Double)OPACITY.getValue()).intValue();
        blockIDs.clear();
        int radXZ = ((Double)Xray.radXZ.getValue()).intValue();
        int radY = ((Double)Xray.radY.getValue()).intValue();
        for (int i : this.KEY_IDS) {
            blockIDs.add(i);
        }
        ArrayList<BlockPos> blockPositions = this.getBlocks(radXZ, radY, radXZ);
        for (BlockPos pos : blockPositions) {
            IBlockState state = BlockUtil.getState(pos);
            if (!this.isCheckableOre(Block.getIdFromBlock(state.getBlock()))) continue;
            blockIDs.add(pos);
        }
        all = blockIDs.size();
        this.done = 0;
        super.onEnable();
        Xray.mc.renderGlobal.loadRenderers();
        int var0 = (int)Minecraft.thePlayer.posX;
        int var = (int)Minecraft.thePlayer.posY;
        int var2 = (int)Minecraft.thePlayer.posZ;
        Xray.mc.renderGlobal.markBlockRangeForRenderUpdate(var0 - 900, var - 900, var2 - 900, var0 + 900, var + 900, var2 + 900);
        this.loaded = true;
    }

    private ArrayList<BlockPos> getBlocks(int x, int y, int z) {
        BlockPos min = new BlockPos(Minecraft.thePlayer.posX - (double)x, Minecraft.thePlayer.posY - (double)y, Minecraft.thePlayer.posZ - (double)z);
        BlockPos max = new BlockPos(Minecraft.thePlayer.posX + (double)x, Minecraft.thePlayer.posY + (double)y, Minecraft.thePlayer.posZ + (double)z);
        return BlockUtil.getAllInBox(min, max);
    }

    private boolean isCheckableOre(int id) {
        int check = 0;
        int check1 = 0;
        int check2 = 0;
        int check3 = 0;
        int check4 = 0;
        int check5 = 0;
        int check6 = 0;
        if (((Boolean)DiamondOre.getValue()).booleanValue() && id != 0) {
            check = 56;
        }
        if (((Boolean)GoldOre.getValue()).booleanValue() && id != 0) {
            check1 = 14;
        }
        if (((Boolean)IronOre.getValue()).booleanValue() && id != 0) {
            check2 = 15;
        }
        if (((Boolean)EmeraldOre.getValue()).booleanValue() && id != 0) {
            check3 = 129;
        }
        if (((Boolean)RedStoneOre.getValue()).booleanValue() && id != 0) {
            check4 = 73;
        }
        if (((Boolean)CoalOre.getValue()).booleanValue() && id != 0) {
            check5 = 16;
        }
        if (((Boolean)LapisOre.getValue()).booleanValue() && id != 0) {
            check6 = 21;
        }
        if (id == 0) {
            return false;
        }
        return id == check || id == check1 || id == check2 || id == check3 || id == check4 || id == check5 || id == check6;
    }

    public static boolean contains(int id) {
        return ids[id];
    }

    public static void add(int id) {
        Xray.ids[id] = true;
    }

    public static void remove(int id) {
        Xray.ids[id] = false;
    }

    public static void clear() {
        int i = 0;
        while (i < ids.length) {
            Xray.ids[i] = false;
            ++i;
        }
    }

    public static boolean shouldRender(int id) {
        return ids[id];
    }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        String f = "" + all;
        String g = "" + this.done;
        ScaledResolution sr = new ScaledResolution(mc);
        CFontRenderer font = FontLoaders.Comfortaa16;
        int size = 125;
        float xOffset = (float)ScaledResolution.getScaledWidth() / 550.0f - (float)size / 550.0f;
        float yOffset = 400.0f;
        float Y = 0.0f;
        RenderUtil.rectangleBordered(xOffset + 2.0f, yOffset + 1.0f, xOffset + 10.0f + (float)size + (float)font.getStringWidth(g) + 1.0f, yOffset + (float)size / 6.0f + 3.0f + ((float)font.getHeight() + 2.2f), 0.5, Colors.getColor(90), Colors.getColor(0));
        RenderUtil.rectangleBordered(xOffset + 3.0f, yOffset + 2.0f, xOffset + 10.0f + (float)size + (float)font.getStringWidth(g), yOffset + (float)size / 6.0f + 2.0f + ((float)font.getHeight() + 2.2f), 0.5, Colors.getColor(27), Colors.getColor(61));
        font.drawStringWithShadow(ChatFormatting.GREEN + "Done: " + ChatFormatting.WHITE + this.done + " / " + ChatFormatting.RED + "All: " + ChatFormatting.WHITE + all, xOffset + 25.0f, yOffset + (float)font.getHeight() + 4.0f, -1);
        GlStateManager.disableBlend();
    }

    @EventHandler
    public void onReceivePacket(EventPacketReceive e) {
        if (EventPacketReceive.getPacket() instanceof S23PacketBlockChange) {
            S23PacketBlockChange p = (S23PacketBlockChange)EventPacketReceive.getPacket();
            if (this.isEnabledOre(Block.getIdFromBlock(p.getBlockState().getBlock()))) {
                glow.add(p.getBlockPosition());
            }
        } else if (EventPacketReceive.getPacket() instanceof S22PacketMultiBlockChange) {
            S22PacketMultiBlockChange p = (S22PacketMultiBlockChange)EventPacketReceive.getPacket();
            S22PacketMultiBlockChange.BlockUpdateData[] blockUpdateDataArray = p.getChangedBlocks();
            int n = blockUpdateDataArray.length;
            int n2 = 0;
            while (n2 < n) {
                S22PacketMultiBlockChange.BlockUpdateData dat = blockUpdateDataArray[n2];
                if (this.isEnabledOre(Block.getIdFromBlock(dat.getBlockState().getBlock()))) {
                    glow.add(dat.getPos());
                }
                ++n2;
            }
        }
    }

    private boolean isEnabledOre(int id) {
        int check = 0;
        int check1 = 0;
        int check2 = 0;
        int check3 = 0;
        int check4 = 0;
        int check5 = 0;
        int check6 = 0;
        if (((Boolean)DiamondOre.getValue()).booleanValue() && id != 0) {
            check = 56;
        }
        if (((Boolean)GoldOre.getValue()).booleanValue() && id != 0) {
            check1 = 14;
        }
        if (((Boolean)IronOre.getValue()).booleanValue() && id != 0) {
            check2 = 15;
        }
        if (((Boolean)EmeraldOre.getValue()).booleanValue() && id != 0) {
            check3 = 129;
        }
        if (((Boolean)RedStoneOre.getValue()).booleanValue() && id != 0) {
            check4 = 73;
        }
        if (((Boolean)CoalOre.getValue()).booleanValue() && id != 0) {
            check5 = 16;
        }
        if (((Boolean)LapisOre.getValue()).booleanValue() && id != 0) {
            check6 = 21;
        }
        if (id == 0) {
            return false;
        }
        return id == check || id == check1 || id == check2 || id == check3 || id == check4 || id == check5 || id == check6;
    }

    @EventHandler
    private void on3DRender(EventRender3D e) {
        Iterator<XrayBlock> x = this.list.iterator();
        if (((Boolean)Tracers.getValue()).booleanValue()) {
            while (x.hasNext()) {
                XrayBlock x1 = x.next();
                double[] arrd = new double[3];
                double posX = x1.x - RenderManager.renderPosX;
                double posY = x1.y - RenderManager.renderPosY;
                double posZ = x1.z - RenderManager.renderPosZ;
                boolean old = Xray.mc.gameSettings.viewBobbing;
                double posX2 = x1.x;
                double posY2 = x1.y;
                double posZ2 = x1.z;
                if (BlockUtils.getBlock(new BlockPos(posX2, posY2, posZ2)) == Blocks.air) {
                    return;
                }
                RenderUtil.startDrawing();
                Xray.mc.gameSettings.viewBobbing = false;
                Xray.mc.entityRenderer.setupCameraTransform(Xray.mc.timer.renderPartialTicks, 1);
                Xray.mc.gameSettings.viewBobbing = old;
                if ((x1.type.contains("Diamond") || x1.type.contains("\ufffd\ufffd\u02af")) && ((Boolean)DiamondOre.getValue()).booleanValue()) {
                    arrd[0] = 0.0;
                    arrd[1] = 128.0;
                    arrd[2] = 255.0;
                    this.drawLine(arrd, posX, posY, posZ);
                } else if ((x1.type.contains("Gold") || x1.type.contains("\ufffd\ufffd")) && ((Boolean)GoldOre.getValue()).booleanValue()) {
                    arrd[0] = 255.0;
                    arrd[1] = 255.0;
                    arrd[2] = 0.0;
                    this.drawLine(arrd, posX, posY, posZ);
                } else if ((x1.type.contains("Iron") || x1.type.contains("\ufffd\ufffd")) && ((Boolean)IronOre.getValue()).booleanValue()) {
                    arrd[0] = 210.0;
                    arrd[1] = 170.0;
                    arrd[2] = 140.0;
                    this.drawLine(arrd, posX, posY, posZ);
                } else if ((x1.type.contains("Redstone") || x1.type.contains("\ufffd\ufffd\u02af")) && ((Boolean)RedStoneOre.getValue()).booleanValue()) {
                    arrd[0] = 255.0;
                    arrd[1] = 0.0;
                    arrd[2] = 0.0;
                    this.drawLine(arrd, posX, posY, posZ);
                } else if ((x1.type.contains("Coal") || x1.type.contains("\u00fa\u033f")) && ((Boolean)CoalOre.getValue()).booleanValue()) {
                    arrd[0] = 0.0;
                    arrd[1] = 0.0;
                    arrd[2] = 0.0;
                    this.drawLine(arrd, posX, posY, posZ);
                } else if ((x1.type.contains("Lapis") || x1.type.contains("\ufffd\ufffd\ufffd\u02af")) && ((Boolean)LapisOre.getValue()).booleanValue()) {
                    arrd[0] = 27.0;
                    arrd[1] = 74.0;
                    arrd[2] = 161.0;
                    this.drawLine(arrd, posX, posY, posZ);
                } else if ((x1.type.contains("Emerald") || x1.type.contains("\ufffd\u0331\ufffd\u02af")) && ((Boolean)EmeraldOre.getValue()).booleanValue()) {
                    arrd[0] = 23.0;
                    arrd[1] = 221.0;
                    arrd[2] = 98.0;
                    this.drawLine(arrd, posX, posY, posZ);
                }
                RenderUtil.stopDrawing();
            }
        }
    }

    @EventHandler
    public void onPre(EventPreUpdate e) {
        int i = 0;
        while (i < 9) {
            if (blockIDs.size() < 1) {
                return;
            }
            BlockPos pos = glow.remove(0);
            ++this.done;
            mc.getNetHandler().getNetworkManager().sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, pos, EnumFacing.UP));
            ++i;
        }
    }

    @EventHandler
    public void onEvent(EventBlockRenderSide e) {
        block20: {
            block21: {
                e.getState().getBlock();
                if (!(((Boolean)CAVE.getValue()).booleanValue() || !Xray.containsID(Block.getIdFromBlock(e.getState().getBlock())) || e.getSide() == EnumFacing.DOWN && e.minY > 0.0 || e.getSide() == EnumFacing.UP && e.maxY < 1.0 || e.getSide() == EnumFacing.NORTH && e.minZ > 0.0 || e.getSide() == EnumFacing.SOUTH && e.maxZ < 1.0 || e.getSide() == EnumFacing.WEST && e.minX > 0.0 || e.getSide() == EnumFacing.EAST && e.maxX < 1.0 || !e.getWorld().getBlockState(e.pos).getBlock().isOpaqueCube())) {
                    e.setToRender(true);
                } else if (!((Boolean)CAVE.getValue()).booleanValue()) {
                    e.setCancelled(true);
                }
                if (!((Boolean)ESP.getValue()).booleanValue()) {
                    return;
                }
                if (!(e.getSide() == EnumFacing.DOWN && e.minY > 0.0 || e.getSide() == EnumFacing.UP && e.maxY < 1.0 || e.getSide() == EnumFacing.NORTH && e.minZ > 0.0 || e.getSide() == EnumFacing.SOUTH && e.maxZ < 1.0 || e.getSide() == EnumFacing.WEST && e.minX > 0.0 || e.getSide() == EnumFacing.EAST && e.maxX < 1.0) && e.getWorld().getBlockState((Boolean)uhc.getValue() != false ? e.pos.offset(e.getSide()) : e.pos).getBlock().isOpaqueCube()) break block20;
                if (Minecraft.theWorld.getBlockState(e.getPos().offset(e.getSide(), -1)).getBlock() instanceof BlockOre) break block21;
                if (!(Minecraft.theWorld.getBlockState(e.getPos().offset(e.getSide(), -1)).getBlock() instanceof BlockRedstoneOre)) break block20;
            }
            float xDiff = (float)(Minecraft.thePlayer.posX - (double)e.pos.getX());
            float yDiff = 0.0f;
            float zDiff = (float)(Minecraft.thePlayer.posZ - (double)e.pos.getZ());
            float dis = MathHelper.sqrt_float(xDiff * xDiff + 0.0f + zDiff * zDiff);
            if ((double)dis > (Double)Dis.getValue()) {
                return;
            }
            XrayBlock x = new XrayBlock(Math.round(e.pos.offset(e.getSide(), -1).getZ()), Math.round(e.pos.offset(e.getSide(), -1).getY()), Math.round(e.pos.offset(e.getSide(), -1).getX()), Minecraft.theWorld.getBlockState(e.pos.offset(e.getSide(), -1)).getBlock().getUnlocalizedName());
            if (!this.list.contains(x)) {
                this.list.add(x);
                EnumFacing[] enumFacingArray = EnumFacing.values();
                int n = enumFacingArray.length;
                int n2 = 0;
                while (n2 < n) {
                    EnumFacing e1 = enumFacingArray[n2];
                    XrayBlock x1 = new XrayBlock(Math.round(e.pos.offset(e.getSide(), -1).offset(e1, 1).getZ()), Math.round(e.pos.offset(e.getSide(), -1).offset(e1, 1).getY()), Math.round(e.pos.offset(e.getSide(), -1).offset(e1, 1).getX()), Minecraft.theWorld.getBlockState(e.pos.offset(e.getSide(), -1).offset(e1, 1)).getBlock().getUnlocalizedName());
                    boolean b = false;
                    if (x.type.contains("Diamond") && x1.type.contains("Diamond")) {
                        b = true;
                    } else if (x.type.contains("Iron") && x1.type.contains("Iron")) {
                        b = true;
                    } else if (x.type.contains("Gold") && x1.type.contains("Gold")) {
                        b = true;
                    } else if (x.type.contains("Red") && x1.type.contains("Red")) {
                        b = true;
                    } else if (x.type.contains("Coal") && x1.type.contains("Coal")) {
                        b = true;
                    }
                    if (b && !this.list.contains(x1)) {
                        this.list.add(x1);
                    }
                    ++n2;
                }
            }
        }
    }

    private void drawLine(double[] color, double x, double y, double z) {
        GL11.glEnable((int)2848);
        GL11.glColor3d((double)color[0], (double)color[1], (double)color[2]);
        GL11.glLineWidth((float)0.1f);
        GL11.glBegin((int)1);
        GL11.glVertex3d((double)0.0, (double)Minecraft.thePlayer.getEyeHeight(), (double)0.0);
        GL11.glVertex3d((double)(x + 0.5), (double)(y + 0.5), (double)(z + 0.5));
        GL11.glEnd();
        GL11.glDisable((int)2848);
    }

    @Override
    public void onDisable() {
        Xray.mc.renderGlobal.loadRenderers();
        this.list.clear();
        boolean done = false;
    }

    public static boolean containsID(int id) {
        return blockIDs.contains(id);
    }

    private static float getSize(double x, double y, double z) {
        return (float)Minecraft.thePlayer.getDistance(x, y, z) / 4.0f <= 2.0f ? 2.0f : (float)Minecraft.thePlayer.getDistance(x, y, z) / 4.0f;
    }

    private static void startDrawing(double x, double y, double z, double StringX, double StringY, double StringZ) {
        float var10001 = Xray.mc.gameSettings.thirdPersonView == 2 ? -1.0f : 1.0f;
        double size = Config.zoomMode ? (double)(Xray.getSize(StringX, StringY, StringZ) / 10.0f) * 1.6 : (double)(Xray.getSize(StringX, StringY, StringZ) / 10.0f) * 4.8;
        GL11.glPushMatrix();
        RenderUtil.startDrawing();
        GL11.glTranslatef((float)((float)x), (float)((float)y), (float)((float)z));
        GL11.glNormal3f((float)0.0f, (float)1.0f, (float)0.0f);
        mc.getRenderManager();
        GL11.glRotatef((float)(-RenderManager.playerViewY), (float)0.0f, (float)1.0f, (float)0.0f);
        mc.getRenderManager();
        GL11.glRotatef((float)RenderManager.playerViewX, (float)var10001, (float)0.0f, (float)0.0f);
        GL11.glScaled((double)(-0.01666666753590107 * size), (double)(-0.01666666753590107 * size), (double)(0.01666666753590107 * size));
    }

    private static void stopDrawing() {
        RenderUtil.stopDrawing();
        GlStateManager.color(1.0f, 1.0f, 1.0f);
        GlStateManager.popMatrix();
    }

    @EventHandler
    public void RenderWall(EventRender3D event) {
        Iterator<XrayBlock> x = this.list.iterator();
        if (((Boolean)ESP.getValue()).booleanValue()) {
            while (x.hasNext()) {
                XrayBlock x1 = x.next();
                double posX = x1.x;
                double posY = x1.y;
                double posZ = x1.z;
                if (BlockUtils.getBlock(new BlockPos(posX, posY, posZ)) == Blocks.air) {
                    return;
                }
                if ((x1.type.contains("Diamond") || x1.type.contains("\ufffd\ufffd\u02af")) && ((Boolean)DiamondOre.getValue()).booleanValue()) {
                    mc.getRenderManager();
                    mc.getRenderManager();
                    mc.getRenderManager();
                    RenderUtil.drawblock(x1.x - RenderManager.viewerPosX, x1.y - RenderManager.viewerPosY, x1.z - RenderManager.viewerPosZ, Xray.getColor(0, 0, 0, 0), new Color(0, 128, 255, 100).getRGB(), 0.1f);
                }
                if ((x1.type.contains("Gold") || x1.type.contains("\ufffd\ufffd")) && ((Boolean)GoldOre.getValue()).booleanValue()) {
                    mc.getRenderManager();
                    mc.getRenderManager();
                    mc.getRenderManager();
                    RenderUtil.drawblock(x1.x - RenderManager.viewerPosX, x1.y - RenderManager.viewerPosY, x1.z - RenderManager.viewerPosZ, Xray.getColor(0, 0, 0, 0), new Color(255, 255, 0, 100).getRGB(), 0.1f);
                }
                if ((x1.type.contains("Iron") || x1.type.contains("\ufffd\ufffd")) && ((Boolean)IronOre.getValue()).booleanValue()) {
                    mc.getRenderManager();
                    mc.getRenderManager();
                    mc.getRenderManager();
                    RenderUtil.drawblock(x1.x - RenderManager.viewerPosX, x1.y - RenderManager.viewerPosY, x1.z - RenderManager.viewerPosZ, Xray.getColor(0, 0, 0, 0), new Color(214, 173, 145, 100).getRGB(), 0.1f);
                }
                if ((x1.type.contains("Redstone") || x1.type.contains("\ufffd\ufffd\u02af")) && ((Boolean)RedStoneOre.getValue()).booleanValue()) {
                    mc.getRenderManager();
                    mc.getRenderManager();
                    mc.getRenderManager();
                    RenderUtil.drawblock(x1.x - RenderManager.viewerPosX, x1.y - RenderManager.viewerPosY, x1.z - RenderManager.viewerPosZ, Xray.getColor(0, 0, 0, 0), new Color(255, 0, 0, 100).getRGB(), 0.1f);
                }
                if ((x1.type.contains("Coal") || x1.type.contains("\u00fa\u033f")) && ((Boolean)CoalOre.getValue()).booleanValue()) {
                    mc.getRenderManager();
                    mc.getRenderManager();
                    mc.getRenderManager();
                    RenderUtil.drawblock(x1.x - RenderManager.viewerPosX, x1.y - RenderManager.viewerPosY, x1.z - RenderManager.viewerPosZ, Xray.getColor(0, 0, 0, 0), new Color(0, 0, 0, 100).getRGB(), 0.1f);
                }
                if ((x1.type.contains("Lapis") || x1.type.contains("\ufffd\ufffd\ufffd\u02af")) && ((Boolean)LapisOre.getValue()).booleanValue()) {
                    mc.getRenderManager();
                    mc.getRenderManager();
                    mc.getRenderManager();
                    RenderUtil.drawblock(x1.x - RenderManager.viewerPosX, x1.y - RenderManager.viewerPosY, x1.z - RenderManager.viewerPosZ, Xray.getColor(0, 0, 0, 0), new Color(27, 74, 161, 100).getRGB(), 0.1f);
                }
                if (!x1.type.contains("Emerald") && !x1.type.contains("\ufffd\u0331\ufffd\u02af") || !((Boolean)EmeraldOre.getValue()).booleanValue()) continue;
                mc.getRenderManager();
                mc.getRenderManager();
                mc.getRenderManager();
                RenderUtil.drawblock(x1.x - RenderManager.viewerPosX, x1.y - RenderManager.viewerPosY, x1.z - RenderManager.viewerPosZ, Xray.getColor(0, 0, 0, 0), new Color(23, 221, 98, 100).getRGB(), 0.1f);
            }
        }
    }

    public static int getColor(int red, int green, int blue) {
        return Xray.getColor(red, green, blue, 255);
    }

    public static int getColor(int red, int green, int blue, int alpha) {
        int color = 0;
        color |= alpha << 24;
        color |= red << 16;
        color |= green << 8;
        return color |= blue;
    }

    public int getOpacity() {
        return this.opacity;
    }
}

