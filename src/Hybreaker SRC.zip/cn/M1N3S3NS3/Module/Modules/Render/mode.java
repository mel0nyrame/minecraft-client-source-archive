/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Render;

enum mode {
    yi,
    er,
    san,
    si,
    wu,
    liu,
    qi,
    ba,
    jiu,
    shi,
    shiyi,
    shier,
    shisan,
    shisi,
    shiwu;

}

