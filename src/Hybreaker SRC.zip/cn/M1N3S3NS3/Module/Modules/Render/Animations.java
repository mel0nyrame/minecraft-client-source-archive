/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventAttack;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import java.awt.Color;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumParticleTypes;

public class Animations
extends Module {
    public int multiplier = 50;
    public final Numbers<Double> blockHValue = new Numbers<Double>("Block H", "Block H", 0.0, -1.5, 1.5, 0.05);
    public final Numbers<Double> blockVValue = new Numbers<Double>("Block V", "Block V", 0.0, -1.5, 1.5, 0.05);
    public final Numbers<Double> blockSValue = new Numbers<Double>("Block S", "Block S", 0.0, -1.5, 1.5, 0.05);
    public final Numbers<Double> armHValue = new Numbers<Double>("Arm H", "Arm H", 0.0, -3.0, 3.0, 0.05);
    public final Numbers<Double> armVValue = new Numbers<Double>("Arm V", "Arm V", 0.0, -3.0, 3.0, 0.05);
    public final Numbers<Double> armSValue = new Numbers<Double>("Arm S", "Arm S", 0.0, -3.0, 3.0, 0.05);
    public final Numbers<Double> swingSlowValue = new Numbers<Double>("Swing", "Novoline moments", 0.0, -3.0, 15.0, 1.0);
    private Numbers<Double> crack = new Numbers<Double>("CrackSize", "CrackSize", 1.0, 0.0, 10.0, 1.0);
    public final Option<Boolean> forceHeightValue = new Option<Boolean>("Force Height", "Just force", false);
    public final Option<Boolean> AttackCrit = new Option<Boolean>("AttackCrit", "AttackCrit", false);
    public static final Option<Boolean> EventRot = new Option<Boolean>("Event Rotaton", "Event Rotaton", false);
    public static final Option<Boolean> NoHurtCam = new Option<Boolean>("NoHurtCam", "NoHurtCam", false);
    public final Mode<Enum> modeValue = new Mode("Mode", "Block mode", (Enum[])modeEnums.values(), (Enum)modeEnums.None);

    public Animations() {
        super("Old Hitting", new String[]{"OldHitting"}, ModuleType.Render);
        this.addValues(this.modeValue, this.forceHeightValue, this.AttackCrit, EventRot, NoHurtCam, this.blockHValue, this.blockVValue, this.blockSValue, this.armHValue, this.armVValue, this.armSValue, this.swingSlowValue, this.crack);
    }

    public static Color fade(long offset, float fade) {
        float hue = (float)(System.nanoTime() + offset) / 1.0E10f % 1.0f;
        long color = Long.parseLong(Integer.toHexString(Color.HSBtoRGB(hue, 1.0f, 1.0f)), 16);
        Color c = new Color((int)color);
        return new Color((float)c.getRed() / 255.0f * fade, (float)c.getGreen() / 255.0f * fade, (float)c.getBlue() / 255.0f * fade, (float)c.getAlpha() / 155.0f);
    }

    @EventHandler
    public void onAttack(EventAttack event) {
        if (((Boolean)this.AttackCrit.getValue()).booleanValue()) {
            Entity entity = event.entity;
            if (!(entity instanceof EntityLivingBase)) {
                return;
            }
            int i2 = 0;
            while ((double)i2 < (Double)this.crack.getValue()) {
                Animations.mc.effectRenderer.emitParticleAtEntity(entity, EnumParticleTypes.CRIT_MAGIC);
                ++i2;
            }
        }
    }

    public static int getRainbow(int speed, int offset) {
        float hue = (System.currentTimeMillis() * 1L + (long)(offset / 2)) % (long)speed * 2L;
        return Color.getHSBColor(hue /= (float)speed, 1.0f, 1.0f).getRGB();
    }

    public static enum modeEnums {
        None,
        Old,
        Push,
        Slide,
        Jello,
        Rainy,
        Swang,
        Swong,
        Swong2,
        Dislike,
        Leaked;

    }
}

