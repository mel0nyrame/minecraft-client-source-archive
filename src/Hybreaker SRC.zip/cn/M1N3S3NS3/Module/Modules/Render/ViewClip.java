/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Misc.EventChat;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.Util.Chat.PlayerListObject;
import cn.M1N3S3NS3.Util.RenderUtils;
import java.awt.Color;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumChatFormatting;

public class ViewClip
extends Module {
    public static Option<Boolean> bighead = new Option<Boolean>("BigHead", false);
    public static Option<Boolean> Higherhelditem = new Option<Boolean>("Higherhelditem", true);
    public static Option<Boolean> Itemtoview = new Option<Boolean>("Itemtoview", false);
    public static Option<Boolean> Itemblock = new Option<Boolean>("ItemBlock", true);
    public static Option<Boolean> Littleentities = new Option<Boolean>("LittleEntities", false);
    private static Option<Boolean> PlayerList = new Option<Boolean>("PlayerList", "PlayerList", true);
    public static Option<Boolean> Flipentities = new Option<Boolean>("Flipentities", "Flipentities", true);
    public Numbers<Double> xv = new Numbers<Double>("X", "X", 50.0, 0.0, 1000.0, 10.0);
    public Numbers<Double> yv = new Numbers<Double>("Y", "Y", 50.0, 0.0, 1000.0, 10.0);
    public float x;
    public float y;
    private static final String[] killMessage = new String[]{"was killed by ", "was thrown into the void by ", "was thrown off a cliff by ", "was deleted by ", "was purified by ", "was scared off an edge by ", "was socked by ", "was oinked by "};
    private List<PlayerListObject> players = new CopyOnWriteArrayList<PlayerListObject>();
    private PlayerListObject no1Player;
    public static Numbers<Double> N = new Numbers<Double>("3rdPersonDistance", 4.0, 1.0, 10.0, 0.01);

    public ViewClip() {
        super("ViewClip", new String[]{"ViewClip"}, ModuleType.Render);
        super.setRemoved(true);
        this.addValues(N, bighead, Higherhelditem, Itemtoview, Itemblock, PlayerList, this.xv, this.yv, Littleentities, Flipentities);
    }

    @EventHandler
    public void chat(EventChat chatMessage) {
        if (((Boolean)PlayerList.getValue()).booleanValue()) {
            if (Minecraft.thePlayer == null) {
                return;
            }
            String playerName = null;
            try {
                String[] stringArray = killMessage;
                int n = killMessage.length;
                int n2 = 0;
                while (n2 < n) {
                    String s = stringArray[n2];
                    if (chatMessage.getMessage().contains(s)) {
                        playerName = chatMessage.getMessage().split(s)[1];
                    }
                    ++n2;
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            if (playerName == null || playerName.isEmpty()) {
                return;
            }
            if (!this.players.isEmpty()) {
                for (PlayerListObject player : this.players) {
                    if (!player.name.equals(playerName)) continue;
                    ++player.kills;
                    break;
                }
            } else {
                this.players.add(new PlayerListObject(playerName, 1));
            }
        }
    }

    @EventHandler
    public void onTitle(EventPreUpdate e) {
        if (((Boolean)PlayerList.getValue()).booleanValue()) {
            if (Minecraft.thePlayer.ticksExisted <= 1) {
                this.players.clear();
            }
            this.no1Player = null;
        }
    }

    @EventHandler
    public void on2D(EventRender2D e) {
        if (((Boolean)PlayerList.getValue()).booleanValue()) {
            this.x = ((Double)this.xv.getValue()).floatValue();
            this.y = ((Double)this.yv.getValue()).floatValue();
            int staticColor = new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue()).getRGB();
            if (Minecraft.thePlayer.isDead) {
                this.players.clear();
                this.no1Player = null;
            }
            float textY = this.y;
            if (Minecraft.thePlayer == null) {
                return;
            }
            this.players.sort((o1, o2) -> o2.kills - o1.kills);
            for (PlayerListObject player : this.players) {
                String killString;
                if (player == this.players.get(0)) {
                    this.no1Player = player;
                }
                RenderUtils.drawRect((double)this.x, (double)(this.y + 8.0f), (double)(this.x + (float)Client.instance.getFontManager().Tahoma16.getStringWidth("PlayetList") + 65.0f), (double)(this.y + (float)Client.instance.getFontManager().Tahoma16.getHeight() + 3.0f), staticColor);
                RenderUtils.drawRect((double)this.x, (double)(textY + (float)Client.instance.getFontManager().Tahoma16.getHeight() + 3.0f), (double)(this.x + (float)Client.instance.getFontManager().Tahoma16.getStringWidth("PlayetList") + 65.0f), (double)(textY + (float)Client.instance.getFontManager().Tahoma16.getHeight() + 13.0f), new Color(0, 5, 0, 155).getRGB());
                if (player == this.no1Player) {
                    Client.instance.getFontManager().logo13.drawString((Object)((Object)EnumChatFormatting.AQUA) + "a", this.x + 1.0f, (float)Client.instance.getFontManager().Tahoma16.getHeight() + 8.0f + (float)((int)textY), -1);
                }
                Client.instance.getFontManager().Tahoma16.drawStringWithShadow(player.name, this.x + (player == this.no1Player ? 8.5f : 1.0f), (float)Client.instance.getFontManager().Tahoma16.getHeight() + 6.0f + textY, -1);
                switch (player.kills) {
                    case -1: 
                    case 0: 
                    case 1: {
                        killString = "kill";
                        break;
                    }
                    default: {
                        killString = "kills";
                    }
                }
                Client.instance.getFontManager().Tahoma16.drawStringWithShadow(String.valueOf(player.kills) + " " + killString, (float)((double)(this.x + (float)Client.instance.getFontManager().Tahoma16.getStringWidth("PlayetList") + 65.0f - (float)Client.instance.getFontManager().Tahoma16.getStringWidth(String.valueOf(player.kills) + killString) - 2.0f) - (killString.equalsIgnoreCase("kill") ? 1.5 : 1.5)), (float)Client.instance.getFontManager().Tahoma16.getHeight() + 6.5f + textY, -1);
                textY += 10.0f;
            }
        }
    }

    @Override
    public void onDisable() {
        this.players.clear();
        this.no1Player = null;
        super.onDisable();
    }
}

