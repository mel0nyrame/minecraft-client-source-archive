/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.Render.RenderUtil;
import cn.M1N3S3NS3.Util.Color.Colors2;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.MovementInput;

public class Crosshair
extends Module {
    private boolean dragging;
    float hue;
    private Option<Boolean> DYNAMIC = new Option<Boolean>("DYNAMIC", "DYNAMIC", true);
    public static Numbers<Double> GAP = new Numbers<Double>("gap", "gap", 5.0, 0.25, 15.0, 0.25);
    private Numbers<Double> WIDTH = new Numbers<Double>("width", "width", 2.0, 0.25, 10.0, 0.25);
    public static Numbers<Double> SIZE = new Numbers<Double>("size", "size", 7.0, 0.25, 15.0, 0.25);

    public Crosshair() {
        super("Crosshair", new String[]{"Crosshair"}, ModuleType.Render);
        this.addValues(this.DYNAMIC, GAP, this.WIDTH, SIZE);
    }

    @EventHandler
    public void onGui(EventRender2D e) {
        int red = ((Double)HUD.r.getValue()).intValue();
        int green = ((Double)HUD.g.getValue()).intValue();
        int blue = ((Double)HUD.b.getValue()).intValue();
        int alph = 255;
        double gap = (Double)GAP.getValue();
        double width = (Double)this.WIDTH.getValue();
        double size = (Double)SIZE.getValue();
        ScaledResolution scaledRes = new ScaledResolution(mc);
        RenderUtil.rectangleBordered((double)(ScaledResolution.getScaledWidth() / 2) - width, (double)(ScaledResolution.getScaledHeight() / 2) - gap - size - (double)(this.isMoving() ? 2 : 0), (double)((float)(ScaledResolution.getScaledWidth() / 2) + 1.0f) + width, (double)(ScaledResolution.getScaledHeight() / 2) - gap - (double)(this.isMoving() ? 2 : 0), 0.5, Colors2.getColor(red, green, blue, 255), new Color(0, 0, 0, 255).getRGB());
        RenderUtil.rectangleBordered((double)(ScaledResolution.getScaledWidth() / 2) - width, (double)(ScaledResolution.getScaledHeight() / 2) + gap + 1.0 + (double)(this.isMoving() ? 2 : 0) - 0.15, (double)((float)(ScaledResolution.getScaledWidth() / 2) + 1.0f) + width, (double)(ScaledResolution.getScaledHeight() / 2 + 1) + gap + size + (double)(this.isMoving() ? 2 : 0) - 0.15, 0.5, Colors2.getColor(red, green, blue, 255), new Color(0, 0, 0, 255).getRGB());
        RenderUtil.rectangleBordered((double)(ScaledResolution.getScaledWidth() / 2) - gap - size - (double)(this.isMoving() ? 2 : 0) + 0.15, (double)(ScaledResolution.getScaledHeight() / 2) - width, (double)(ScaledResolution.getScaledWidth() / 2) - gap - (double)(this.isMoving() ? 2 : 0) + 0.15, (double)((float)(ScaledResolution.getScaledHeight() / 2) + 1.0f) + width, 0.5, Colors2.getColor(red, green, blue, 255), new Color(0, 0, 0, 255).getRGB());
        RenderUtil.rectangleBordered((double)(ScaledResolution.getScaledWidth() / 2 + 1) + gap + (double)(this.isMoving() ? 2 : 0), (double)(ScaledResolution.getScaledHeight() / 2) - width, (double)(ScaledResolution.getScaledWidth() / 2) + size + gap + 1.0 + (double)(this.isMoving() ? 2 : 0), (double)((float)(ScaledResolution.getScaledHeight() / 2) + 1.0f) + width, 0.5, Colors2.getColor(red, green, blue, 255), new Color(0, 0, 0, 255).getRGB());
    }

    public boolean isMoving() {
        if (((Boolean)this.DYNAMIC.getValue()).booleanValue()) {
            Minecraft mc = Crosshair.mc;
            if (!Minecraft.thePlayer.isCollidedHorizontally) {
                Minecraft mc2 = Crosshair.mc;
                if (!Minecraft.thePlayer.isSneaking()) {
                    MovementInput movementInput = Minecraft.thePlayer.movementInput;
                    if (MovementInput.moveForward == 0.0f) {
                        MovementInput movementInput2 = Minecraft.thePlayer.movementInput;
                        if (MovementInput.moveStrafe == 0.0f) {
                            return false;
                        }
                    }
                    return true;
                }
            }
        }
        return false;
    }
}

