/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  javax.vecmath.Vector3d
 *  javax.vecmath.Vector4d
 *  org.lwjgl.opengl.Display
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.util.glu.GLU
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Events.Render.RenderNameEvent;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.FriendManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.UI.Font.CFontRenderer;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.Util.PlayerUtils;
import cn.M1N3S3NS3.Util.Render.ColorUtils;
import cn.M1N3S3NS3.Util.RenderUtils;
import cn.M1N3S3NS3.Util.Theing.Render2DUtil;
import java.awt.Color;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector4d;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

public class ESP2D
extends Module {
    public final List collectedEntities;
    private final IntBuffer viewport;
    private final FloatBuffer modelview;
    private final FloatBuffer projection;
    private final FloatBuffer vector;
    private final int color;
    private final int backgroundColor;
    private final int black;
    public final Mode<Enum> modeValue = new Mode("Mode", "Block mode", (Enum[])modeEnums.values(), (Enum)modeEnums.off);
    public Numbers<Number> width = new Numbers<Double>("Width", 0.5, 0.5, 2.0, 0.1);
    public Option<Boolean> DroppedItems = new Option<Boolean>("DroppedItems", false);
    public Option<Boolean> LocalPlayer = new Option<Boolean>("LocalPlayer", false);
    public Option<Boolean> Invisibles = new Option<Boolean>("Invisibles", false);
    public Option<Boolean> HealthBar = new Option<Boolean>("HealthBar", false);
    public Option<Boolean> ArmorBar = new Option<Boolean>("ArmorBar", false);
    public Option<Boolean> Outline = new Option<Boolean>("Outline", false);
    public Option<Boolean> Players = new Option<Boolean>("Players", true);
    public Option<Boolean> Animals = new Option<Boolean>("Animals", true);
    public Option<Boolean> Mobs = new Option<Boolean>("Mobs", true);
    public Option<Boolean> Chests = new Option<Boolean>("Chests", true);
    public Option<Boolean> Tag = new Option<Boolean>("Tag 2D", true);

    public ESP2D() {
        super("ESP2D", new String[]{"ESP2D", "ESP2D"}, ModuleType.Render);
        this.addValues(this.modeValue, this.DroppedItems, this.LocalPlayer, this.Invisibles, this.HealthBar, this.ArmorBar, this.Outline, this.Players, this.Animals, this.Mobs, this.Chests, this.Tag);
        this.collectedEntities = new ArrayList();
        this.viewport = GLAllocation.createDirectIntBuffer(16);
        this.modelview = GLAllocation.createDirectFloatBuffer(16);
        this.projection = GLAllocation.createDirectFloatBuffer(16);
        this.vector = GLAllocation.createDirectFloatBuffer(4);
        this.color = Color.WHITE.getRGB();
        this.backgroundColor = new Color(0, 0, 0, 120).getRGB();
        this.black = Color.BLACK.getRGB();
    }

    @EventHandler
    public void onRenderNametag(RenderNameEvent e) {
        if (e.getEntity() instanceof EntityPlayer && this.isValid((EntityPlayer)e.getEntity()) && ((Boolean)this.Tag.getValue()).booleanValue()) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onRender2D(EventRender2D event) {
        String mode2 = ((Enum)this.modeValue.getValue()).toString();
        GL11.glPushMatrix();
        this.collectEntities();
        float partialTicks = event.getPartialTicks();
        ScaledResolution scaledResolution = event.getSR();
        int scaleFactor = scaledResolution.getScaleFactor();
        double scaling = (double)scaleFactor / Math.pow(scaleFactor, 2.0);
        GL11.glScaled((double)scaling, (double)scaling, (double)scaling);
        int black = this.black;
        int color = this.color;
        int background = this.backgroundColor;
        float scale = 0.65f;
        float upscale = 1.0f / scale;
        FontRenderer fr = Minecraft.fontRendererObj;
        RenderManager renderMng = mc.getRenderManager();
        EntityRenderer entityRenderer = ESP2D.mc.entityRenderer;
        boolean tag = (Boolean)this.Tag.getValue();
        boolean outline = (Boolean)this.Outline.getValue();
        boolean health = (Boolean)this.HealthBar.getValue();
        boolean armor = (Boolean)this.ArmorBar.getValue();
        List collectedEntities = this.collectedEntities;
        int i = 0;
        int collectedEntitiesSize = collectedEntities.size();
        while (i < collectedEntitiesSize) {
            Entity entity = (Entity)collectedEntities.get(i);
            if (this.isValid(entity) && RenderUtils.isInViewFrustrum(entity)) {
                double x = RenderUtils.interpolate(entity.posX, entity.lastTickPosX, (double)partialTicks);
                double y = RenderUtils.interpolate(entity.posY, entity.lastTickPosY, (double)partialTicks);
                double z = RenderUtils.interpolate(entity.posZ, entity.lastTickPosZ, (double)partialTicks);
                double width = (double)entity.width / 1.5;
                double height = (double)entity.height + (entity.isSneaking() ? -0.3 : 0.2);
                AxisAlignedBB aabb = new AxisAlignedBB(x - width, y, z - width, x + width, y + height, z + width);
                List<Vector3d> vectors = Arrays.asList(new Vector3d(aabb.minX, aabb.minY, aabb.minZ), new Vector3d(aabb.minX, aabb.maxY, aabb.minZ), new Vector3d(aabb.maxX, aabb.minY, aabb.minZ), new Vector3d(aabb.maxX, aabb.maxY, aabb.minZ), new Vector3d(aabb.minX, aabb.minY, aabb.maxZ), new Vector3d(aabb.minX, aabb.maxY, aabb.maxZ), new Vector3d(aabb.maxX, aabb.minY, aabb.maxZ), new Vector3d(aabb.maxX, aabb.maxY, aabb.maxZ));
                entityRenderer.setupCameraTransform(partialTicks, 0);
                Vector4d position = null;
                for (Vector3d vector : vectors) {
                    vector = this.project2D(scaleFactor, vector.x - RenderManager.viewerPosX, vector.y - RenderManager.viewerPosY, vector.z - RenderManager.viewerPosZ);
                    if (vector == null || !(vector.z >= 0.0) || !(vector.z < 1.0)) continue;
                    if (position == null) {
                        position = new Vector4d(vector.x, vector.y, vector.z, 0.0);
                    }
                    position.x = Math.min(vector.x, position.x);
                    position.y = Math.min(vector.y, position.y);
                    position.z = Math.max(vector.x, position.z);
                    position.w = Math.max(vector.y, position.w);
                }
                if (position != null) {
                    float tagY;
                    double textWidth;
                    double durabilityWidth;
                    float itemDurability;
                    float armorValue;
                    EntityLivingBase entityLivingBase;
                    boolean living;
                    entityRenderer.setupOverlayRendering(ScaledResolution.getScaledWidth(), ScaledResolution.getScaledHeight());
                    double posX = position.x;
                    double posY = position.y;
                    double endPosX = position.z;
                    double endPosY = position.w;
                    if (outline) {
                        if (mode2.equalsIgnoreCase("Box")) {
                            Render2DUtil.drawRect(posX - 1.0, posY, posX + 0.5, endPosY + 0.5, black);
                            Render2DUtil.drawRect(posX - 1.0, posY - 0.5, endPosX + 0.5, posY + 0.5 + 0.5, black);
                            Render2DUtil.drawRect(endPosX - 0.5 - 0.5, posY, endPosX + 0.5, endPosY + 0.5, black);
                            Render2DUtil.drawRect(posX - 1.0, endPosY - 0.5 - 0.5, endPosX + 0.5, endPosY + 0.5, black);
                            Render2DUtil.drawRect(posX - 0.5, posY, posX + 0.5 - 0.5, endPosY, color);
                            Render2DUtil.drawRect(posX, endPosY - 0.5, endPosX, endPosY, color);
                            Render2DUtil.drawRect(posX - 0.5, posY, endPosX, posY + 0.5, color);
                            Render2DUtil.drawRect(endPosX - 0.5, posY, endPosX, endPosY, color);
                        }
                        if (mode2.equalsIgnoreCase("Box2")) {
                            Render2DUtil.drawRect(posX + 0.5, posY, posX - 1.0, posY + (endPosY - posY) / 4.0 + 0.5, black);
                        }
                        Render2DUtil.drawRect(posX - 1.0, endPosY, posX + 0.5, endPosY - (endPosY - posY) / 4.0 - 0.5, black);
                        Render2DUtil.drawRect(posX - 1.0, posY - 0.5, posX + (endPosX - posX) / 3.0 + 0.5, posY + 1.0, black);
                        Render2DUtil.drawRect(endPosX - (endPosX - posX) / 3.0 - 0.5, posY - 0.5, endPosX, posY + 1.0, black);
                        Render2DUtil.drawRect(endPosX - 1.0, posY, endPosX + 0.5, posY + (endPosY - posY) / 4.0 + 0.5, black);
                        Render2DUtil.drawRect(endPosX - 1.0, endPosY, endPosX + 0.5, endPosY - (endPosY - posY) / 4.0 - 0.5, black);
                        Render2DUtil.drawRect(posX - 1.0, endPosY - 1.0, posX + (endPosX - posX) / 3.0 + 0.5, endPosY + 0.5, black);
                        Render2DUtil.drawRect(endPosX - (endPosX - posX) / 3.0 - 0.5, endPosY - 1.0, endPosX + 0.5, endPosY + 0.5, black);
                        Render2DUtil.drawRect(posX, posY, posX - 0.5, posY + (endPosY - posY) / 4.0, color);
                        Render2DUtil.drawRect(posX, endPosY, posX - 0.5, endPosY - (endPosY - posY) / 4.0, color);
                        Render2DUtil.drawRect(posX - 0.5, posY, posX + (endPosX - posX) / 3.0, posY + 0.5, color);
                        Render2DUtil.drawRect(endPosX - (endPosX - posX) / 3.0, posY, endPosX, posY + 0.5, color);
                        Render2DUtil.drawRect(endPosX - 0.5, posY, endPosX, posY + (endPosY - posY) / 4.0, color);
                        Render2DUtil.drawRect(endPosX - 0.5, endPosY, endPosX, endPosY - (endPosY - posY) / 4.0, color);
                        Render2DUtil.drawRect(posX, endPosY - 0.5, posX + (endPosX - posX) / 3.0, endPosY, color);
                        Render2DUtil.drawRect(endPosX - (endPosX - posX) / 3.0, endPosY - 0.5, endPosX - 0.5, endPosY, color);
                    }
                    if (living = entity instanceof EntityLivingBase) {
                        entityLivingBase = (EntityLivingBase)entity;
                        if (health) {
                            armorValue = entityLivingBase.getHealth();
                            if (armorValue > (itemDurability = entityLivingBase.getMaxHealth())) {
                                armorValue = itemDurability;
                            }
                            durabilityWidth = armorValue / itemDurability;
                            textWidth = (endPosY - posY) * durabilityWidth;
                            Gui.drawRect(posX - 3.5, posY - 0.5, posX - 1.5, endPosY + 0.5, background);
                            if (armorValue > 0.0f) {
                                int healthColor = ColorUtils.getHealthColor(armorValue, itemDurability).getRGB();
                                Gui.drawRect(posX - 3.0, endPosY, posX - 2.0, endPosY - textWidth, healthColor);
                                tagY = entityLivingBase.getAbsorptionAmount();
                                if (tagY > 0.0f) {
                                    Gui.drawRect(posX - 3.0, endPosY, posX - 2.0, endPosY - (endPosY - posY) / 6.0 * (double)tagY / 2.0, new Color(Potion.absorption.getLiquidColor()).getRGB());
                                }
                            }
                        }
                    }
                    if (tag) {
                        float scaledHeight = 10.0f;
                        String name = entity.getName();
                        if (entity instanceof EntityItem) {
                            name = ((EntityItem)entity).getEntityItem().getDisplayName();
                        }
                        String prefix = "";
                        if (entity instanceof EntityPlayer) {
                            prefix = this.isFriendly((EntityPlayer)entity) ? "\u00a7a" : "\u00a7c";
                        }
                        durabilityWidth = (endPosX - posX) / 2.0;
                        textWidth = (float)fr.getStringWidth(name) * scale;
                        float tagX = (float)((posX + durabilityWidth - textWidth / 2.0) * (double)upscale);
                        tagY = (float)(posY * (double)upscale) - scaledHeight;
                        GL11.glPushMatrix();
                        GL11.glScalef((float)scale, (float)scale, (float)scale);
                        CFontRenderer font = FontLoaders.Comfortaa18;
                        if (living) {
                            Gui.drawRect(tagX - 2.0f, tagY - 2.0f, (double)tagX + textWidth * (double)upscale + 2.0, tagY + 9.0f, new Color(0, 0, 0, 140).getRGB());
                        }
                        Client.instance.getFontManager().Tahoma18.drawStringWithShadow(String.valueOf(prefix) + name, tagX, tagY, -1);
                        GL11.glPopMatrix();
                    }
                    if (armor) {
                        ItemStack itemStack;
                        if (living) {
                            entityLivingBase = (EntityLivingBase)entity;
                            armorValue = entityLivingBase.getTotalArmorValue();
                            double armorWidth = (endPosX - posX) * (double)armorValue / 20.0;
                            Gui.drawRect(posX - 0.5, endPosY + 1.5, posX - 0.5 + endPosX - posX + 1.0, endPosY + 1.5 + 2.0, background);
                            if (armorValue > 0.0f) {
                                Gui.drawRect(posX, endPosY + 2.0, posX + armorWidth, endPosY + 3.0, 0xFFFFFF);
                            }
                        } else if (entity instanceof EntityItem && (itemStack = ((EntityItem)entity).getEntityItem()).isItemStackDamageable()) {
                            int maxDamage = itemStack.getMaxDamage();
                            itemDurability = maxDamage - itemStack.getItemDamage();
                            durabilityWidth = (endPosX - posX) * (double)itemDurability / (double)maxDamage;
                            Gui.drawRect(posX - 0.5, endPosY + 1.5, posX - 0.5 + endPosX - posX + 1.0, endPosY + 1.5 + 2.0, background);
                            Gui.drawRect(posX, endPosY + 2.0, posX + durabilityWidth, endPosY + 3.0, 0xFFFFFF);
                        }
                    }
                }
            }
            ++i;
        }
        GL11.glPopMatrix();
        GlStateManager.enableBlend();
        entityRenderer.setupOverlayRendering(ScaledResolution.getScaledWidth(), ScaledResolution.getScaledHeight());
    }

    private boolean isFriendly(EntityPlayer player) {
        return PlayerUtils.isOnSameTeam(player) || FriendManager.isFriend(player.getName());
    }

    private void collectEntities() {
        this.collectedEntities.clear();
        List playerEntities = Minecraft.theWorld.loadedEntityList;
        int i = 0;
        int playerEntitiesSize = playerEntities.size();
        while (i < playerEntitiesSize) {
            Entity entity = (Entity)playerEntities.get(i);
            if (this.isValid(entity)) {
                this.collectedEntities.add(entity);
            }
            ++i;
        }
    }

    private Vector3d project2D(int scaleFactor, double x, double y, double z) {
        GL11.glGetFloat((int)2982, (FloatBuffer)this.modelview);
        GL11.glGetFloat((int)2983, (FloatBuffer)this.projection);
        GL11.glGetInteger((int)2978, (IntBuffer)this.viewport);
        return GLU.gluProject((float)((float)x), (float)((float)y), (float)((float)z), (FloatBuffer)this.modelview, (FloatBuffer)this.projection, (IntBuffer)this.viewport, (FloatBuffer)this.vector) ? new Vector3d((double)(this.vector.get(0) / (float)scaleFactor), (double)(((float)Display.getHeight() - this.vector.get(1)) / (float)scaleFactor), (double)this.vector.get(2)) : null;
    }

    private boolean isValid(Entity entity) {
        if (entity != Minecraft.thePlayer || ((Boolean)this.ArmorBar.getValue()).booleanValue() && ESP2D.mc.gameSettings.thirdPersonView != 0) {
            for (Object obj : Minecraft.theWorld.loadedEntityList) {
                EntityItem entity2;
                if (!((Boolean)this.DroppedItems.getValue()).booleanValue() || !(entity instanceof EntityItem) || !(entity2 = (EntityItem)entity).getEntityItem().getDisplayName().contains("iamond") && !entity2.getEntityItem().getDisplayName().contains("olden_apple") && !entity2.getEntityItem().getDisplayName().contains("otion")) continue;
                return true;
            }
            if (entity.isDead) {
                return false;
            }
            if (!((Boolean)this.Invisibles.getValue()).booleanValue() && entity.isInvisible()) {
                return false;
            }
            if (((Boolean)this.Animals.getValue()).booleanValue() && entity instanceof EntityAnimal) {
                return true;
            }
            if (((Boolean)this.Players.getValue()).booleanValue() && entity instanceof EntityPlayer) {
                return true;
            }
            return (Boolean)this.Mobs.getValue() != false && (entity instanceof EntityMob || entity instanceof EntitySlime || entity instanceof EntityDragon || entity instanceof EntityGolem);
        }
        return false;
    }

    public static int[] getFractionIndicies(float[] fractions, float progress) {
        int[] range = new int[2];
        int startPoint = 0;
        while (startPoint < fractions.length && fractions[startPoint] <= progress) {
            ++startPoint;
        }
        if (startPoint >= fractions.length) {
            startPoint = fractions.length - 1;
        }
        range[0] = startPoint - 1;
        range[1] = startPoint;
        return range;
    }

    public static Color blend(Color color1, Color color2, double ratio) {
        float r = (float)ratio;
        float ir = 1.0f - r;
        float[] rgb1 = new float[3];
        float[] rgb2 = new float[3];
        color1.getColorComponents(rgb1);
        color2.getColorComponents(rgb2);
        float red = rgb1[0] * r + rgb2[0] * ir;
        float green = rgb1[1] * r + rgb2[1] * ir;
        float blue = rgb1[2] * r + rgb2[2] * ir;
        if (red < 0.0f) {
            red = 0.0f;
        } else if (red > 255.0f) {
            red = 255.0f;
        }
        if (green < 0.0f) {
            green = 0.0f;
        } else if (green > 255.0f) {
            green = 255.0f;
        }
        if (blue < 0.0f) {
            blue = 0.0f;
        } else if (blue > 255.0f) {
            blue = 255.0f;
        }
        Color color = null;
        try {
            color = new Color(red, green, blue);
        }
        catch (IllegalArgumentException exp) {
            NumberFormat nf = NumberFormat.getNumberInstance();
            System.out.println(String.valueOf(nf.format(red)) + "; " + nf.format(green) + "; " + nf.format(blue));
            exp.printStackTrace();
        }
        return color;
    }

    public static Color blendColors(float[] fractions, Color[] colors, float progress) {
        Object color = null;
        if (fractions == null) {
            throw new IllegalArgumentException("Fractions can't be null");
        }
        if (colors == null) {
            throw new IllegalArgumentException("Colours can't be null");
        }
        if (fractions.length != colors.length) {
            throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
        }
        int[] indicies = ESP2D.getFractionIndicies(fractions, progress);
        float[] range = new float[]{fractions[indicies[0]], fractions[indicies[1]]};
        Color[] colorRange = new Color[]{colors[indicies[0]], colors[indicies[1]]};
        float max = range[1] - range[0];
        float value = progress - range[0];
        float weight = value / max;
        return ESP2D.blend(colorRange[0], colorRange[1], 1.0f - weight);
    }

    public static enum modeEnums {
        Box2,
        Box,
        off;

    }
}

