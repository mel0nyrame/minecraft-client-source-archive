/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;

public class LowFire
extends Module {
    public static final Numbers<Number> y = new Numbers<Double>("y", -0.1, -2.0, 2.0, 0.05);

    public LowFire() {
        super("LowFire", new String[]{"LowFire"}, ModuleType.Render);
        this.addValues(y);
    }
}

