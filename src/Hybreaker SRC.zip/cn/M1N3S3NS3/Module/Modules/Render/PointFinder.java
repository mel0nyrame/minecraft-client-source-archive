/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender3D;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.Render.RenderUtil;
import com.mojang.authlib.GameProfile;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.awt.Color;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.src.Config;
import org.lwjgl.opengl.GL11;

public class PointFinder
extends Module {
    public static EntityOtherPlayerMP player;
    public static EntityOtherPlayerMP player2;
    private Numbers<Double> scale = new Numbers<Double>("Scale", "scale", 3.0, 1.0, 5.0, 0.1);

    public PointFinder() {
        super("PointFinder", new String[]{"PointFinder"}, ModuleType.Render);
        this.addValues(this.scale);
        this.setRemoved(true);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        player = new EntityOtherPlayerMP(Minecraft.theWorld, new GameProfile(new UUID(69L, 96L), ""));
        player.setPositionAndRotation(0.0, 128.0, 0.0, Minecraft.thePlayer.rotationYaw, Minecraft.thePlayer.rotationPitch);
        player2 = new EntityOtherPlayerMP(Minecraft.theWorld, new GameProfile(new UUID(69L, 96L), ""));
        player2.setPositionAndRotation(0.0, 128.0, 0.0, Minecraft.thePlayer.rotationYaw, Minecraft.thePlayer.rotationPitch);
        Minecraft.theWorld.addEntityToWorld(player.getEntityId(), player);
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @EventHandler
    private void onRender(EventRender3D render) {
        float x = (float)(PointFinder.player.posX - RenderManager.renderPosX);
        float y = (float)(PointFinder.player.posY - RenderManager.renderPosY);
        float z = (float)(PointFinder.player.posZ - RenderManager.renderPosZ);
        this.renderNametag(player, x, y, z);
        float x2 = (float)(PointFinder.player2.posX - RenderManager.renderPosX);
        float y2 = (float)(PointFinder.player2.posY - RenderManager.renderPosY);
        float z2 = (float)(PointFinder.player2.posZ - RenderManager.renderPosZ);
        this.renderNametag(player2, x2, y2, z2);
    }

    private void renderNametag(EntityPlayer player, float x, float y, float z) {
        y = (float)((double)y + 2.25);
        this.startDrawing(x, y, z, player);
        this.drawNames(player);
        GL11.glColor4d((double)1.0, (double)1.0, (double)1.0, (double)1.0);
        this.stopDrawing();
    }

    private void drawNames(EntityPlayer player) {
        float xP = 2.2f;
        float width = (float)this.getWidth(this.getPlayerName(player)) / 2.0f + xP;
        float w = width = (float)((double)width);
        float nw = -width;
        float offset = this.getWidth(this.getPlayerName(player)) + 4;
        RenderUtil.drawBorderedRect(nw + offset - 3.0f, -3.0f, width + offset, 10.0f, 1.0f, new Color(20, 20, 20, 180).getRGB(), new Color(10, 10, 10, 200).getRGB());
        GlStateManager.disableDepth();
        offset = 0.0f;
        this.drawString(this.getPlayerName(player), w - offset, 0.0f, 0xFFFFFF);
        GlStateManager.enableDepth();
    }

    private String getPlayerName(EntityPlayer player) {
        String name = ChatFormatting.GOLD + "[00]" + "\u00a7bX:\u00a77" + player.posX + " \u00a7bY:\u00a77" + player.posY + " \u00a7bZ:\u00a77" + player.posZ + "[" + Minecraft.thePlayer.getDistance(0.0, Minecraft.thePlayer.posY, 0.0) + "]";
        return String.valueOf(name.substring(0, 65)) + "m]";
    }

    private void drawString(String text, float x, float y, int color) {
        Minecraft.fontRendererObj.drawStringWithShadow(text, x, y, color);
    }

    private int getWidth(String text) {
        return Minecraft.fontRendererObj.getStringWidth(text);
    }

    private void startDrawing(float x, float y, float z, EntityPlayer player) {
        float var10001 = PointFinder.mc.gameSettings.thirdPersonView == 2 ? -1.0f : 1.0f;
        double size = Config.zoomMode ? (double)(this.getSize(player) / 10.0f) * (Double)this.scale.getValue() * 0.5 : (double)(this.getSize(player) / 10.0f) * (Double)this.scale.getValue() * 1.5;
        GL11.glPushMatrix();
        RenderUtil.startDrawing();
        GL11.glTranslatef((float)x, (float)y, (float)z);
        GL11.glNormal3f((float)0.0f, (float)1.0f, (float)0.0f);
        mc.getRenderManager();
        GL11.glRotatef((float)(-RenderManager.playerViewY), (float)0.0f, (float)1.0f, (float)0.0f);
        mc.getRenderManager();
        GL11.glRotatef((float)RenderManager.playerViewX, (float)var10001, (float)0.0f, (float)0.0f);
        GL11.glScaled((double)(-0.01666666753590107 * size), (double)(-0.01666666753590107 * size), (double)(0.01666666753590107 * size));
    }

    private void stopDrawing() {
        RenderUtil.stopDrawing();
        GlStateManager.color(1.0f, 1.0f, 1.0f);
        GlStateManager.popMatrix();
    }

    private float getSize(EntityPlayer player) {
        return Minecraft.thePlayer.getDistanceToEntity(player) / 4.0f <= 2.0f ? 2.0f : Minecraft.thePlayer.getDistanceToEntity(player) / 4.0f;
    }
}

