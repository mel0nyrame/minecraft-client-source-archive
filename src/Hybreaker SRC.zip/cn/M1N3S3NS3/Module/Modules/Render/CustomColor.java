/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import java.awt.Color;

public class CustomColor
extends Module {
    public static final Numbers<Number> armorHue = new Numbers<Double>("Damage Hue", 0.8, 0.0, 1.0, 0.1);
    public static final Numbers<Number> itemHue = new Numbers<Double>("Damage Sat", 0.8, 0.0, 1.0, 0.1);
    public static final Option<Boolean> rainbow = new Option<Boolean>("Rainbow Damage", false);
    public static final Numbers<Number> damageHue = new Numbers<Double>("Damage Hue", 0.8, 0.0, 1.0, 0.1);
    public static final Numbers<Number> damageAlpha = new Numbers<Double>("Damage Alpha", 0.3, 0.3, 1.0, 0.1);
    public static final Numbers<Number> damageSaturation = new Numbers<Double>("Damage Sat", 1.0, (Double)((Object)Float.valueOf(0.0f)), 1.0, 0.1);
    public static final Option<Boolean> rainbowHits = new Option<Boolean>("Rainbow Hits", false);

    public CustomColor() {
        super("CustomColor", new String[]{"Custom color when damaging entities"}, ModuleType.Render);
        this.addValues(damageHue, damageAlpha, damageSaturation, rainbowHits, armorHue, itemHue, rainbow);
    }

    public static int getRainbow(int speed, int offset) {
        float hue = (System.currentTimeMillis() * 2L + (long)(offset / 2)) % (long)speed * 2L;
        return Color.getHSBColor(hue /= (float)speed, 1.0f, 1.0f).getRGB();
    }
}

