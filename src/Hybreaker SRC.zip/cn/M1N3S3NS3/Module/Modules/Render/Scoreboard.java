/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.RenderUtil;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

public class Scoreboard
extends Module {
    public static Option<Boolean> noShadow = new Option<Boolean>("No Shadow", false);
    public static Option<Boolean> FastChat = new Option<Boolean>("FastChat", false);
    public static Option<Boolean> hide = new Option<Boolean>("Hide", false);
    public static Option<Boolean> drawShadow = new Option<Boolean>("Draw Shadow", false);
    public static Option<Boolean> transparent = new Option<Boolean>("Transparent", false);
    public static Option<Boolean> hideNumbers = new Option<Boolean>("Hide Numbers", false);
    public static Numbers<Number> height = new Numbers<Double>("Height", 70.0, 1.0, 138.0, 1.0);
    private static Numbers<Double> x = new Numbers<Double>("X", "X", 10.0, 0.0, 800.0, 10.0);
    private static Numbers<Double> y = new Numbers<Double>("Y", "Y", 10.0, 0.0, 600.0, 10.0);

    public Scoreboard() {
        super("Scoreboard", new String[]{"Scoreboard", "Scoreboard"}, ModuleType.Render);
        this.addValues(x, y, height, hide, drawShadow, transparent, hideNumbers, FastChat, noShadow);
    }

    @EventHandler
    private void render(EventRender2D event) {
        GlStateManager.pushMatrix();
        GlStateManager.translate((Double)x.getValue(), (Double)y.getValue(), 0.0);
        RenderUtil.drawBorderedRect(0.0f, 1.0f, 180.0f, -58.0f, 1.0f, new Color(0, 0, 0, 255).getRGB(), new Color(0, 0, 0, 130).getRGB());
        RenderHelper.enableGUIStandardItemLighting();
        this.renderArmor();
        int x2 = 1;
        int x3 = 1;
        int x4 = 1;
        int i2 = 27;
        while (i2 < 36) {
            this.renderItem(i2, 1 + x2, -16, Minecraft.thePlayer);
            x2 += 20;
            ++i2;
        }
        int i3 = 18;
        while (i3 < 27) {
            this.renderItem(i3, 1 + x3, -36, Minecraft.thePlayer);
            x3 += 20;
            ++i3;
        }
        int i4 = 9;
        while (i4 < 18) {
            this.renderItem(i4, 1 + x4, -56, Minecraft.thePlayer);
            x4 += 20;
            ++i4;
        }
        RenderHelper.disableStandardItemLighting();
        GlStateManager.popMatrix();
    }

    void renderItem(int i, int x, int y, EntityPlayer player) {
        ItemStack itemstack = player.inventory.mainInventory[i];
        if (itemstack != null) {
            mc.getRenderItem().renderItemAndEffectIntoGUI(itemstack, x, y);
            mc.getRenderItem().renderItemOverlays(Minecraft.fontRendererObj, itemstack, x - 1, y - 1);
        }
    }

    void renderArmor() {
        int protectionenchantmentLevel4 = EnchantmentHelper.getEnchantmentLevel(Enchantment.protection.effectId, Minecraft.thePlayer.getEquipmentInSlot(4));
        int protectionenchantmentLevel3 = EnchantmentHelper.getEnchantmentLevel(Enchantment.protection.effectId, Minecraft.thePlayer.getEquipmentInSlot(3));
        int protectionenchantmentLevel2 = EnchantmentHelper.getEnchantmentLevel(Enchantment.protection.effectId, Minecraft.thePlayer.getEquipmentInSlot(2));
        int protectionenchantmentLevel1 = EnchantmentHelper.getEnchantmentLevel(Enchantment.protection.effectId, Minecraft.thePlayer.getEquipmentInSlot(1));
        int unbreakingenchantmentLevel44 = EnchantmentHelper.getEnchantmentLevel(Enchantment.unbreaking.effectId, Minecraft.thePlayer.getEquipmentInSlot(4));
        int unbreakingenchantmentLevel33 = EnchantmentHelper.getEnchantmentLevel(Enchantment.unbreaking.effectId, Minecraft.thePlayer.getEquipmentInSlot(3));
        int unbreakingenchantmentLevel22 = EnchantmentHelper.getEnchantmentLevel(Enchantment.unbreaking.effectId, Minecraft.thePlayer.getEquipmentInSlot(2));
        int unbreakingenchantmentLevel11 = EnchantmentHelper.getEnchantmentLevel(Enchantment.unbreaking.effectId, Minecraft.thePlayer.getEquipmentInSlot(1));
        int sharpnessenchantmentLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId, Minecraft.thePlayer.getEquipmentInSlot(0));
        int fireAspectenchantmentLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.fireAspect.effectId, Minecraft.thePlayer.getEquipmentInSlot(0));
        if (Minecraft.thePlayer.getEquipmentInSlot(4) != null) {
            Gui.drawRect(0.0, 3.0, 20.0, 30.0, new Color(0, 0, 0, 150).getRGB());
            mc.getRenderItem().renderItemAndEffectIntoGUI(Minecraft.thePlayer.getEquipmentInSlot(4), 2, 10);
            mc.getRenderItem().renderItemOverlays(Minecraft.fontRendererObj, Minecraft.thePlayer.getEquipmentInSlot(4), 2, 10);
            if (protectionenchantmentLevel4 > 0) {
                Client.instance.getFontManager().Tahoma14.drawStringWithShadow("Pro\u00a72" + protectionenchantmentLevel4, 3.0, 10.0, -1);
            }
            if (unbreakingenchantmentLevel44 > 0) {
                Client.instance.getFontManager().Tahoma14.drawStringWithShadow("Unb\u00a72" + unbreakingenchantmentLevel44, 3.0, 5.0, -1);
            }
        }
        if (Minecraft.thePlayer.getEquipmentInSlot(3) != null) {
            Gui.drawRect(20.0, 3.0, 40.0, 30.0, new Color(0, 0, 0, 150).getRGB());
            if (protectionenchantmentLevel3 > 0) {
                Client.instance.getFontManager().Tahoma14.drawStringWithShadow("Pro\u00a72" + protectionenchantmentLevel3, 23.0, 9.0, -1);
            }
            if (unbreakingenchantmentLevel33 > 0) {
                Client.instance.getFontManager().Tahoma14.drawStringWithShadow("Unb\u00a72" + unbreakingenchantmentLevel33, 23.0, 4.0, -1);
            }
            mc.getRenderItem().renderItemAndEffectIntoGUI(Minecraft.thePlayer.getEquipmentInSlot(3), 22, 10);
            mc.getRenderItem().renderItemOverlays(Minecraft.fontRendererObj, Minecraft.thePlayer.getEquipmentInSlot(3), 42, 10);
        }
        if (Minecraft.thePlayer.getEquipmentInSlot(2) != null) {
            Gui.drawRect(40.0, 3.0, 60.0, 30.0, new Color(0, 0, 0, 150).getRGB());
            mc.getRenderItem().renderItemAndEffectIntoGUI(Minecraft.thePlayer.getEquipmentInSlot(2), 42, 10);
            mc.getRenderItem().renderItemOverlays(Minecraft.fontRendererObj, Minecraft.thePlayer.getEquipmentInSlot(2), 42, 10);
            if (protectionenchantmentLevel2 > 0) {
                Client.instance.getFontManager().Tahoma14.drawStringWithShadow("Pro\u00a72" + protectionenchantmentLevel2, 43.0, 9.0, -1);
            }
            if (unbreakingenchantmentLevel22 > 0) {
                Client.instance.getFontManager().Tahoma14.drawStringWithShadow("Unb\u00a72" + unbreakingenchantmentLevel22, 43.0, 4.0, -1);
            }
        }
        if (Minecraft.thePlayer.getEquipmentInSlot(1) != null) {
            Gui.drawRect(60.0, 3.0, 80.0, 30.0, new Color(0, 0, 0, 150).getRGB());
            mc.getRenderItem().renderItemAndEffectIntoGUI(Minecraft.thePlayer.getEquipmentInSlot(1), 62, 10);
            mc.getRenderItem().renderItemOverlays(Minecraft.fontRendererObj, Minecraft.thePlayer.getEquipmentInSlot(1), 62, 10);
            if (protectionenchantmentLevel1 > 0) {
                Client.instance.getFontManager().Tahoma14.drawStringWithShadow("Pro\u00a72" + protectionenchantmentLevel1, 63.0, 10.0, -1);
            }
            if (unbreakingenchantmentLevel11 > 0) {
                Client.instance.getFontManager().Tahoma14.drawStringWithShadow("Unb\u00a72" + unbreakingenchantmentLevel11, 63.0, 5.0, -1);
            }
        }
        if (Minecraft.thePlayer.getEquipmentInSlot(0) != null) {
            Gui.drawRect(83.0, 3.0, 103.0, 30.0, new Color(0, 0, 0, 150).getRGB());
            mc.getRenderItem().renderItemAndEffectIntoGUI(Minecraft.thePlayer.getEquipmentInSlot(0), 85, 10);
            mc.getRenderItem().renderItemOverlays(Minecraft.fontRendererObj, Minecraft.thePlayer.getEquipmentInSlot(0), 85, 10);
            if (sharpnessenchantmentLevel > 0) {
                Client.instance.getFontManager().Tahoma14.drawStringWithShadow("Sha\u00a72" + sharpnessenchantmentLevel, 86.0, 10.0, -1);
            }
            if (fireAspectenchantmentLevel > 0) {
                Client.instance.getFontManager().Tahoma14.drawStringWithShadow("Fire\u00a72" + fireAspectenchantmentLevel, 86.0, 5.0, -1);
            }
        }
    }
}

