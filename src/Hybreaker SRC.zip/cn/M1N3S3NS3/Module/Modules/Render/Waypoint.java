/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender3D;
import cn.M1N3S3NS3.API.Events.World.EventPacketReceive;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.UI.Font.CFontRenderer;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.Util.Chat.Logger;
import cn.M1N3S3NS3.Util.Management;
import cn.M1N3S3NS3.Util.Math.Vec3f;
import cn.M1N3S3NS3.Util.Render.GLUtil;
import java.awt.Color;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity;
import org.lwjgl.opengl.GL11;

public class Waypoint
extends Module {
    private static int indexFirst = 0;
    private static int indexSecond = 1;
    private static int indexThird = 2;
    private static Random random = new Random();
    private static String[] indexes = new String[]{"1", "2", "3", "4", "5", "6", "7", "8"};

    public Waypoint() {
        super("Waypoints", new String[]{"Waypoints"}, ModuleType.Player);
    }

    public static double getRandomDouble(double min, double max) {
        if (max < min) {
            return max + (min - max) * random.nextDouble();
        }
        return min + (max - min) * random.nextDouble();
    }

    public static String getRandomString() {
        int length = indexes.length;
        String result = String.valueOf(indexes[indexFirst % length]) + indexes[indexSecond % length] + indexes[indexThird % length];
        indexFirst += (int)Waypoint.getRandomDouble(1.0, 5.0);
        indexSecond += (int)Waypoint.getRandomDouble(2.0, 6.0);
        indexThird += (int)Waypoint.getRandomDouble(3.0, 7.0);
        return result;
    }

    @EventHandler
    public void onPacketReceive(EventPacketReceive packetEvent) {
        S2CPacketSpawnGlobalEntity packetIn;
        if (EventPacketReceive.getPacket() instanceof S2CPacketSpawnGlobalEntity && (packetIn = (S2CPacketSpawnGlobalEntity)EventPacketReceive.getPacket()).func_149053_g() == 1) {
            int x = (int)((double)packetIn.func_149051_d() / 32.0);
            int y = (int)((double)packetIn.func_149050_e() / 32.0);
            int z = (int)((double)packetIn.func_149049_f() / 32.0);
            Logger.log("\u95ea\u7535!XYZ " + x + y + z);
            Logger.log("Create a tag for the lightning.");
            Logger.log("It will be removed after 45s.");
            String name = String.valueOf(Waypoint.getRandomString()) + "[Lighting!]";
            Management.getTagManager().getMapping().put(name, new Vec3f(x, y, z));
            new Thread(() -> {
                try {
                    Thread.sleep(45000L);
                    Management.getTagManager().getMapping().remove(name);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }

    @EventHandler
    public void onRender3D(EventRender3D event) {
        Set<Map.Entry<String, Vec3f>> entries = Management.getTagManager().getMapping().entrySet();
        for (Map.Entry<String, Vec3f> entry : entries) {
            String name = "00";
            Vec3f vec = entry.getValue();
            double d = vec.getX();
            mc.getRenderManager();
            double vX = d - RenderManager.renderPosX;
            double d2 = vec.getY();
            mc.getRenderManager();
            double vY = d2 - RenderManager.renderPosY;
            double d3 = vec.getZ();
            mc.getRenderManager();
            double vZ = d3 - RenderManager.renderPosZ;
            this.renderTag("00", vX, vY, vZ, vec);
        }
    }

    private void renderTag(String name, double pX, double pY, double pZ, Vec3f vec) {
        int color = new Color(255, 255, 255, 255).getRGB();
        int distance = (int)Minecraft.thePlayer.getDistance(pX, pY, pZ);
        CFontRenderer font = FontLoaders.Comfortaa16;
        float size = (float)distance / 6.0f;
        if (size < 1.1f) {
            size = 1.1f;
        }
        float scale = size * 2.0f;
        GL11.glPushMatrix();
        GL11.glTranslated((double)pX, (double)((pY += 0.7) + 2.0), (double)pZ);
        GL11.glNormal3f((float)0.0f, (float)1.0f, (float)0.0f);
        mc.getRenderManager();
        GL11.glRotatef((float)(-RenderManager.playerViewY), (float)0.0f, (float)2.0f, (float)0.0f);
        mc.getRenderManager();
        GL11.glRotatef((float)RenderManager.playerViewX, (float)2.0f, (float)0.0f, (float)0.0f);
        GL11.glScalef((float)(-(scale /= 100.0f)), (float)(-scale), (float)scale);
        GLUtil.setGLCap(2896, false);
        GLUtil.setGLCap(2929, false);
        GLUtil.setGLCap(3042, true);
        GL11.glBlendFunc((int)770, (int)771);
        int nameTagsWitdh = font.getStringWidth(String.valueOf(name) + " " + distance + "m");
        font.drawStringWithShadow(String.valueOf(name) + " " + distance + "m", -(nameTagsWitdh / 2), -14.0, color);
        String vecString = "[" + vec.getX() + ", " + vec.getY() + ", " + vec.getZ() + "]";
        int vecTagsWitdh = font.getStringWidth(vecString);
        font.drawStringWithShadow(vecString, -(vecTagsWitdh / 2), -6.0, color);
        GLUtil.revertAllCaps();
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GL11.glPopMatrix();
    }
}

