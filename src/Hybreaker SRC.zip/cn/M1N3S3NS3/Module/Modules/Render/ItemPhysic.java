/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;

public class ItemPhysic
extends Module {
    public ItemPhysic() {
        super("ItemPhysic", new String[]{"ItemPhysic"}, ModuleType.Render);
    }
}

