/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

public class MotionBlur
extends Module {
    private Mode<Enum> mode = new Mode("Mode", "mode", (Enum[])Modes.values(), (Enum)Modes.Normal);

    public MotionBlur() {
        super("MotionBlur", new String[]{"MotionBlur"}, ModuleType.Render);
        super.addValues(this.mode);
    }

    @Override
    public void onDisable() {
        Module.mc.entityRenderer.theShaderGroup = null;
    }

    @Override
    public void onEnable() {
        block14: {
            if (!OpenGlHelper.shadersSupported || !(mc.getRenderViewEntity() instanceof EntityPlayer)) break block14;
            if (Module.mc.entityRenderer.theShaderGroup != null) {
                Module.mc.entityRenderer.theShaderGroup.deleteShaderGroup();
            }
            switch (((Enum)this.mode.getValue()).name()) {
                case "Little": {
                    Module.mc.entityRenderer.loadShader(new ResourceLocation("MotionBlur/Little.json"));
                    break;
                }
                case "Normal": {
                    Module.mc.entityRenderer.loadShader(new ResourceLocation("MotionBlur/Normal.json"));
                    break;
                }
                case "Large": {
                    Module.mc.entityRenderer.loadShader(new ResourceLocation("MotionBlur/Large.json"));
                }
            }
        }
    }

    @EventHandler
    public void onUpdate(EventPreUpdate e) {
        block14: {
            this.setSuffix(this.mode.getValue());
            if (Module.mc.entityRenderer.theShaderGroup != null && Module.mc.entityRenderer.theShaderGroup.getShaderGroupName().contains("MotionBlur") || !OpenGlHelper.shadersSupported || !(mc.getRenderViewEntity() instanceof EntityPlayer)) break block14;
            if (Module.mc.entityRenderer.theShaderGroup != null) {
                Module.mc.entityRenderer.theShaderGroup.deleteShaderGroup();
            }
            switch (((Enum)this.mode.getValue()).name()) {
                case "Little": {
                    Module.mc.entityRenderer.loadShader(new ResourceLocation("MotionBlur/Little.json"));
                    break;
                }
                case "Normal": {
                    Module.mc.entityRenderer.loadShader(new ResourceLocation("MotionBlur/Normal.json"));
                    break;
                }
                case "Large": {
                    Module.mc.entityRenderer.loadShader(new ResourceLocation("MotionBlur/Large.json"));
                }
            }
        }
    }

    public static enum Modes {
        Little,
        Normal,
        Large;

    }
}

