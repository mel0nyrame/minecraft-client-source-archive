/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.AntiBot;
import cn.M1N3S3NS3.Util.RenderUtils;
import cn.M1N3S3NS3.Util.RotationUtils;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;

public class Radar
extends Module {
    private boolean dragging;
    float hue;
    public static Option<Boolean> players = new Option<Boolean>("Players", false);
    public static Option<Boolean> monsters = new Option<Boolean>("Monsters", false);
    public static Option<Boolean> animals = new Option<Boolean>("Animals", false);
    public static Option<Boolean> passives = new Option<Boolean>("Passives", false);
    public static Option<Boolean> invisibles = new Option<Boolean>("Invisibles", false);
    public static Option<Boolean> items = new Option<Boolean>("Items", false);
    private Numbers<Double> x = new Numbers<Double>("X", "X", 2.0, 1.0, 897.0, 5.0);
    private Numbers<Double> y = new Numbers<Double>("Y", "Y", 27.0, 0.0, 340.0, 5.0);
    private Numbers<Double> size = new Numbers<Double>("Size", "Size", 125.0, 50.0, 200.0, 5.0);

    public Radar() {
        super("Radar", new String[]{"minimap"}, ModuleType.Render);
        this.addValues(players, monsters, animals, passives, invisibles, items, this.x, this.y, this.size);
        this.setRemoved(true);
    }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        if (!Radar.mc.gameSettings.showDebugInfo) {
            GL11.glPushMatrix();
            int x = ((Double)this.x.getValue()).intValue();
            int y = ((Double)this.y.getValue()).intValue();
            int width = ((Double)this.size.getValue()).intValue();
            int height = ((Double)this.size.getValue()).intValue();
            float cx = (float)x + (float)width / 2.0f;
            float cy = (float)y + (float)height / 2.0f;
            RenderUtils.drawBorderedRect2(x, y, x + width, y + height, 1.0f, -12303292, -14540254);
            RenderUtils.drawRectSized((float)x + (float)width / 2.0f - 0.5f, y, 1.0f, height, -12303292);
            RenderUtils.drawRectSized(x, (float)y + (float)height / 2.0f - 0.5f, width, 1.0f, -12303292);
            RenderUtils.drawRectSized(cx - 1.0f, cy - 1.0f, 2.0f, 2.0f, -256);
            int maxDist = ((Double)this.size.getValue()).intValue() / 2;
            for (Entity entity : Minecraft.theWorld.loadedEntityList) {
                double dz;
                double dx;
                if (!this.qualifies(entity) || !((dx = RenderUtils.lerp(entity.prevPosX, entity.posX, e.getPartialTicks()) - RenderUtils.lerp(Minecraft.thePlayer.prevPosX, Minecraft.thePlayer.posX, e.getPartialTicks())) * dx + (dz = RenderUtils.lerp(entity.prevPosZ, entity.posZ, e.getPartialTicks()) - RenderUtils.lerp(Minecraft.thePlayer.prevPosZ, Minecraft.thePlayer.posZ, e.getPartialTicks())) * dz <= (double)(maxDist * maxDist))) continue;
                float dist = MathHelper.sqrt_double(dx * dx + dz * dz);
                double[] vector = this.getLookVector(RotationUtils.getRotations(entity)[0] - (float)RenderUtils.lerp(Minecraft.thePlayer.prevRotationYawHead, Minecraft.thePlayer.rotationYawHead, e.getPartialTicks()));
                if (entity instanceof EntityMob) {
                    RenderUtils.drawRectSized(cx - 1.0f - (float)vector[0] * dist, cy - 1.0f - (float)vector[1] * dist, 2.0f, 2.0f, new Color(0, 252, 103).getRGB());
                    continue;
                }
                if (entity instanceof EntityPlayer) {
                    RenderUtils.drawRectSized(cx - 1.0f - (float)vector[0] * dist, cy - 1.0f - (float)vector[1] * dist, 2.0f, 2.0f, new Color(248, 0, 0).getRGB());
                    continue;
                }
                if (entity instanceof EntityAnimal || entity instanceof EntitySquid || entity instanceof EntityVillager || entity instanceof EntityGolem) {
                    RenderUtils.drawRectSized(cx - 1.0f - (float)vector[0] * dist, cy - 1.0f - (float)vector[1] * dist, 2.0f, 2.0f, new Color(248, 178, 0).getRGB());
                    continue;
                }
                if (!(entity instanceof EntityItem)) continue;
                RenderUtils.drawRectSized(cx - 1.0f - (float)vector[0] * dist, cy - 1.0f - (float)vector[1] * dist, 2.0f, 2.0f, new Color(0, 147, 241).getRGB());
            }
        }
        GL11.glPopMatrix();
    }

    public double[] getLookVector(float yaw) {
        return new double[]{-MathHelper.sin(yaw *= MathHelper.deg2Rad), MathHelper.cos(yaw)};
    }

    private boolean qualifies(Entity entity) {
        return (entity instanceof EntityPlayer && (Boolean)players.getValue() != false && !AntiBot.isBot((EntityPlayer)entity) || entity instanceof EntityMob && (Boolean)monsters.getValue() != false || (entity instanceof EntityAnimal || entity instanceof EntitySquid) && (Boolean)animals.getValue() != false || (entity instanceof EntityVillager || entity instanceof EntityGolem) && (Boolean)passives.getValue() != false || entity instanceof EntityItem && (Boolean)items.getValue() != false) && (!entity.isInvisible() || (Boolean)invisibles.getValue() != false) && entity != Minecraft.thePlayer;
    }
}

