/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.RLEEvent;
import cn.M1N3S3NS3.API.Events.Render.RenderArmEvent;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.Color.ColorUtil;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;

public class Chams
extends Module {
    private final TimerUtil pulseTimer = new TimerUtil();
    private boolean pulsing;
    private float nope;
    private final Option<Boolean> coloredValue = new Option<Boolean>("Colored", "Colored ent", true);
    private final Option<Boolean> pulseValue = new Option<Boolean>("Pulse", "CSGO Be like", false);
    private final Option<Boolean> handValue = new Option<Boolean>("Hand", "CSGO Be like", true);
    private final Option<Boolean> fillValue = new Option<Boolean>("Fill", "Colored fill", true);
    private final Numbers<Number> redValue = new Numbers<Double>("Red", "Red color", 255.0, 0.0, 255.0, 5.0);
    private final Numbers<Number> greenValue = new Numbers<Double>("Green", "Green color", 255.0, 0.0, 255.0, 5.0);
    private final Numbers<Number> blueValue = new Numbers<Double>("Blue", "Blue color", 255.0, 0.0, 255.0, 5.0);
    private final Numbers<Number> alphaValue = new Numbers<Double>("Alpha", "Alpha color", 35.0, 0.0, 255.0, 5.0);
    private final Mode<colorEnums> colorModeValue = new Mode("Color Mode", "Just chams color mode", (Enum[])colorEnums.values(), (Enum)colorEnums.Custom);

    public Chams() {
        super("Chams", new String[]{"Chams"}, ModuleType.Render);
        this.addValues(this.colorModeValue, this.coloredValue, this.pulseValue, this.handValue, this.fillValue, this.redValue, this.greenValue, this.blueValue, this.alphaValue);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.pulseTimer.reset();
        this.pulsing = false;
        this.nope = 0.0f;
    }

    @EventHandler
    void onRenderModel(RenderArmEvent event) {
        if (!((Boolean)this.handValue.getValue()).booleanValue()) {
            return;
        }
        try {
            if (event.getEntity() == Minecraft.thePlayer && Chams.mc.gameSettings.thirdPersonView == 0) {
                if (event.isPre()) {
                    GlStateManager.enableBlend();
                    GlStateManager.disableDepth();
                    GlStateManager.disableLighting();
                    GlStateManager.disableTexture2D();
                    Chams.mc.entityRenderer.disableLightmap();
                    Color color = this.getColor2();
                    switch ((colorEnums)((Object)this.colorModeValue.getValue())) {
                        case Rainbow: {
                            Color rain = ColorUtil.getRainbow(10.0f, 1.0f, 1.0f);
                            color = new Color(rain.getRed(), rain.getGreen(), rain.getBlue(), ((Number)this.alphaValue.getValue()).intValue());
                            break;
                        }
                        case Health: {
                            Color blend = ColorUtil.getBlendColor(Minecraft.thePlayer.getHealth(), Minecraft.thePlayer.getMaxHealth());
                            color = new Color(blend.getRed(), blend.getGreen(), blend.getBlue(), ((Number)this.alphaValue.getValue()).intValue());
                            break;
                        }
                        case Team: {
                            String text = Minecraft.thePlayer.getDisplayName().getFormattedText();
                            if (Character.toLowerCase(text.charAt(0)) == '\u00a7') {
                                char oneMore = Character.toLowerCase(text.charAt(1));
                                int colorCode = "0123456789abcdefklmnorg".indexOf(oneMore);
                                if (colorCode >= 16) break;
                                try {
                                    int newColor = Minecraft.fontRendererObj.colorCode[colorCode];
                                    color = new Color(newColor >> 16, newColor >> 8 & 0xFF, newColor & 0xFF, ((Number)this.alphaValue.getValue()).intValue());
                                }
                                catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
                                break;
                            }
                            color = new Color(255, 255, 255, ((Number)this.alphaValue.getValue()).intValue());
                        }
                    }
                    GlStateManager.color(0.003921569f * (float)color.getRed(), 0.003921569f * (float)color.getGreen(), 0.003921569f * (float)color.getBlue(), 0.003921569f * (float)color.getAlpha());
                }
                if (event.isPost()) {
                    GlStateManager.resetColor();
                    Chams.mc.entityRenderer.enableLightmap();
                    GlStateManager.enableLighting();
                    GlStateManager.enableDepth();
                    GlStateManager.disableBlend();
                    GlStateManager.enableTexture2D();
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @EventHandler
    void onRLE(RLEEvent e) {
        if (e.getEntity() instanceof EntityPlayer && e.isPre()) {
            if (((Boolean)this.coloredValue.getValue()).booleanValue()) {
                e.setCancelled(true);
                try {
                    Render render = mc.getRenderManager().getEntityRenderObject(e.getEntity());
                    if (render != null && Chams.mc.getRenderManager().renderEngine != null && render instanceof RendererLivingEntity) {
                        RendererLivingEntity rendererLivingEntity = (RendererLivingEntity)render;
                        GlStateManager.pushMatrix();
                        GlStateManager.disableTexture2D();
                        GlStateManager.disableAlpha();
                        Chams.mc.entityRenderer.disableLightmap();
                        GlStateManager.enableBlend();
                        if (((Boolean)this.fillValue.getValue()).booleanValue()) {
                            GlStateManager.disableLighting();
                        }
                        Color color = this.getColor2();
                        switch ((colorEnums)((Object)this.colorModeValue.getValue())) {
                            case Rainbow: {
                                Color rain = ColorUtil.getRainbow(10.0f, 1.0f, 1.0f);
                                color = new Color(rain.getRed(), rain.getGreen(), rain.getBlue(), ((Number)this.alphaValue.getValue()).intValue());
                                break;
                            }
                            case Health: {
                                Color blend = ColorUtil.getBlendColor(e.getEntity().getHealth(), e.getEntity().getMaxHealth());
                                color = new Color(blend.getRed(), blend.getGreen(), blend.getBlue(), ((Number)this.alphaValue.getValue()).intValue());
                                break;
                            }
                            case Team: {
                                String text = e.getEntity().getDisplayName().getFormattedText();
                                if (Character.toLowerCase(text.charAt(0)) == '\u00a7') {
                                    char oneMore = Character.toLowerCase(text.charAt(1));
                                    int colorCode = "0123456789abcdefklmnorg".indexOf(oneMore);
                                    if (colorCode >= 16) break;
                                    try {
                                        int newColor = Minecraft.fontRendererObj.colorCode[colorCode];
                                        color = new Color(newColor >> 16, newColor >> 8 & 0xFF, newColor & 0xFF, ((Number)this.alphaValue.getValue()).intValue());
                                    }
                                    catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {}
                                    break;
                                }
                                color = new Color(255, 255, 255, ((Number)this.alphaValue.getValue()).intValue());
                            }
                        }
                        if (((Boolean)this.pulseValue.getValue()).booleanValue() && this.pulseTimer.hasPassed(15L)) {
                            if (this.pulsing && this.nope >= 0.5f) {
                                this.pulsing = false;
                            }
                            if (!this.pulsing && this.nope <= 0.0f) {
                                this.pulsing = true;
                            }
                            this.nope = this.pulsing ? (this.nope += 0.02f) : (this.nope -= 0.015f);
                            if (this.nope > 1.0f) {
                                this.nope = 1.0f;
                            } else if (this.nope < 0.0f) {
                                this.nope = 0.0f;
                            }
                            this.pulseTimer.reset();
                        }
                        GlStateManager.color(0.003921569f * (float)color.getRed(), 0.003921569f * (float)color.getGreen(), 0.003921569f * (float)color.getBlue(), (Boolean)this.pulseValue.getValue() != false ? this.nope : 0.003921569f * (float)color.getAlpha());
                        GlStateManager.disableDepth();
                        rendererLivingEntity.renderModel(e.getEntity(), e.getLimbSwing(), e.getLimbSwingAmount(), e.getAgeInTicks(), e.getRotationYawHead(), e.getRotationPitch(), e.getOffset());
                        GlStateManager.enableDepth();
                        rendererLivingEntity.renderModel(e.getEntity(), e.getLimbSwing(), e.getLimbSwingAmount(), e.getAgeInTicks(), e.getRotationYawHead(), e.getRotationPitch(), e.getOffset());
                        GlStateManager.resetColor();
                        if (((Boolean)this.fillValue.getValue()).booleanValue()) {
                            GlStateManager.enableLighting();
                        }
                        GlStateManager.disableBlend();
                        Chams.mc.entityRenderer.enableLightmap();
                        GlStateManager.enableAlpha();
                        GlStateManager.enableTexture2D();
                        GlStateManager.popMatrix();
                        rendererLivingEntity.renderLayers(e.getEntity(), e.getLimbSwing(), e.getLimbSwingAmount(), e.getTick(), e.getAgeInTicks(), e.getRotationYawHead(), e.getRotationPitch(), e.getOffset());
                        GlStateManager.popMatrix();
                    }
                }
                catch (Exception exception) {}
            } else {
                GL11.glEnable((int)32823);
                GL11.glPolygonOffset((float)1.0f, (float)-1100000.0f);
            }
        } else if (!((Boolean)this.coloredValue.getValue()).booleanValue() && e.getEntity() instanceof EntityPlayer && e.isPost()) {
            GL11.glDisable((int)32823);
            GL11.glPolygonOffset((float)1.0f, (float)1100000.0f);
        }
    }

    public Color getColor2() {
        return new Color(((Number)this.redValue.getValue()).intValue(), ((Number)this.greenValue.getValue()).intValue(), ((Number)this.blueValue.getValue()).intValue(), ((Number)this.alphaValue.getValue()).intValue());
    }

    public static int getRainbow(int speed, int offset) {
        float hue = (System.currentTimeMillis() * 1L + (long)(offset / 2)) % (long)speed * 2L;
        return Color.getHSBColor(hue /= (float)speed, 1.0f, 1.0f).getRGB();
    }

    private static enum colorEnums {
        Custom,
        Rainbow,
        Health,
        Team;

    }
}

