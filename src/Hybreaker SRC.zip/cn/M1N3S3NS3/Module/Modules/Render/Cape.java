/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.RenderCapeEvent;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Render.mode;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.ResourceLocation;

public class Cape
extends Module {
    public final Mode<Enum> modeValue = new Mode("Mode", "Block mode", (Enum[])mode.values(), (Enum)mode.yi);

    public Cape() {
        super("Cape", new String[]{"Cape"}, ModuleType.Render);
        this.addValues(this.modeValue);
    }

    @EventHandler
    void onRenderCape(RenderCapeEvent event) {
        if (this.modeValue.getValue() == mode.yi && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/awkwardemoji.png"));
        }
        if (this.modeValue.getValue() == mode.er && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/cb_gold.png"));
        }
        if (this.modeValue.getValue() == mode.san && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/clownemoji.png"));
        }
        if (this.modeValue.getValue() == mode.si && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/coldemoji.png"));
        }
        if (this.modeValue.getValue() == mode.wu && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/devilemoji.png"));
        }
        if (this.modeValue.getValue() == mode.liu && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/graser1.png"));
        }
        if (this.modeValue.getValue() == mode.qi && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/hearteyesemoji.png"));
        }
        if (this.modeValue.getValue() == mode.ba && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/moonsworth_4.png"));
        }
        if (this.modeValue.getValue() == mode.jiu && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/pyronicredorange.png"));
        }
        if (this.modeValue.getValue() == mode.shi && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/sademoji.png"));
        }
        if (this.modeValue.getValue() == mode.shiyi && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/season4nodebuff.png"));
        }
        if (this.modeValue.getValue() == mode.shier && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/valentine_cape_2.png"));
        }
        if (this.modeValue.getValue() == mode.shisan && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/youtube_3.png"));
        }
        if (this.modeValue.getValue() == mode.shisi && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/yukiaim.png"));
        }
        if (this.modeValue.getValue() == mode.shiwu && event.getPlayer() instanceof EntityPlayerSP) {
            event.setLocation(new ResourceLocation("BetterCaps/zonixblack.png"));
        }
    }
}

