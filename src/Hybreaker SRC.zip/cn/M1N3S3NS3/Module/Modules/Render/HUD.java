/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.ibm.icu.math.BigDecimal
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Events.World.EventPacketReceive;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.UI.Font.CFontRenderer;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.UI.Menu.HWIDMenu;
import cn.M1N3S3NS3.UI.Render.RenderUtil;
import cn.M1N3S3NS3.UI.Render.SuperLib;
import cn.M1N3S3NS3.Util.Color.CompassUtil;
import cn.M1N3S3NS3.Util.Render.FKCounter;
import cn.M1N3S3NS3.Util.Render.Palette;
import cn.M1N3S3NS3.Util.Render.RenderUtil2;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import com.ibm.icu.math.BigDecimal;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class HUD
extends Module {
    TimerUtil fpsanim = new TimerUtil();
    private final CompassUtil compass = new CompassUtil(mc);
    private static CFontRenderer fontarry;
    public static Numbers<Double> ArrayGap;
    private Option<Boolean> info = new Option<Boolean>("Information", "Information", true);
    public static Mode<Enum> ArrayMode;
    public static Mode<Enum> Tags;
    public static Option<Boolean> customlogo;
    public static Option<Boolean> Notifications;
    public static Option<Boolean> enableNotifications;
    private Option<Boolean> armor = new Option<Boolean>("Armor", "Armor", false);
    private Option<Boolean> COMPACT_HUD = new Option<Boolean>("COMPACT_HUD", "COMPACT_HUD", false);
    public static Option<Boolean> customfont;
    private Option<Boolean> ArrayFont = new Option<Boolean>("ArrayFont", "ArrayFont", true);
    public static Option<Boolean> FastChat;
    public static Option<Boolean> FKCounter1;
    private Option<Boolean> arrfont = new Option<Boolean>("ArrayListFont", "ArrayListFont", true);
    private Option<Boolean> Keybind = new Option<Boolean>("Keybind", "Keybind", true);
    public static Option<Boolean> compassValue;
    private float renderY;
    public static Option<Boolean> tabgui;
    public static Option<Boolean> fontValue;
    public static Option<Boolean> lhp;
    public static Option<Boolean> Arraylists;
    public static Option<Boolean> Bigarry;
    private Option<Boolean> Rect = new Option<Boolean>("Rect", "Rect", false);
    public static Numbers<Double> RainbowSpeed;
    public static Numbers<Double> r;
    public static Numbers<Double> g;
    public static Numbers<Double> b;
    public static Numbers<Double> a;
    public static Numbers<Double> Arraybackground;
    public static Mode logomode;
    public static boolean shouldMove;
    public static boolean useFont;
    public static float hue;
    public static Color RainbowColor;
    public static Color RainbowColor2;
    public static String User;
    public static String Pass;
    public static String Users;
    boolean lowhealth = false;
    SimpleDateFormat df = new SimpleDateFormat("HH:mm");
    private int posY = 4;
    public static int PotY;
    public static String clientName;
    public static String playername;
    public static FKCounter lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII;
    public static Numbers<Double> AlphaValue;
    public static Numbers<Double> color;

    static {
        Notifications = new Option<Boolean>("Notifications", "Notifications", false);
        enableNotifications = new Option<Boolean>("ModNotifications", "ModNotifications", false);
        customfont = new Option<Boolean>("Font", "Font", true);
        FastChat = new Option<Boolean>("FastChat", "FastChat", true);
        FKCounter1 = new Option<Boolean>("FKCounter", "FKCounter", true);
        compassValue = new Option<Boolean>("Compass", "Compass", true);
        tabgui = new Option<Boolean>("Tabgui", "Tabgui", false);
        fontValue = new Option<Boolean>("font", "font", false);
        clientName = Client.name;
        playername = Client.player;
        AlphaValue = new Numbers<Double>("Colors", "Colors", -8350465.0, -1.0E7, 1000000.0, 100.0);
        color = new Numbers<Double>("Colors", "Colors", -8350465.0, -1.0E7, 1000000.0, 100.0);
        ArrayGap = new Numbers<Double>("ArraylistGap", "ArraylistGap", 0.0, -10.0, 10.0, 0.5);
        ArrayMode = new Mode("ArrayMode", "ArrayMode", (Enum[])ArrayModeE.values(), (Enum)ArrayModeE.None);
        Tags = new Mode("Tags", "Tags", (Enum[])TagMode.values(), (Enum)TagMode.None);
        customlogo = new Option<Boolean>("Logo", "logo", true);
        lhp = new Option<Boolean>("LHPWarning", "LHPWarning", true);
        Arraylists = new Option<Boolean>("ArrayList", "ArrayList", true);
        Bigarry = new Option<Boolean>("BigArrayList", "BigArrayList", false);
        RainbowSpeed = new Numbers<Double>("RainbowSpeed", "RainbowSpeed", 6.0, 1.0, 20.0, 1.0);
        r = new Numbers<Double>("Red", "Red", 255.0, 0.0, 255.0, 1.0);
        g = new Numbers<Double>("Green", "Green", 255.0, 0.0, 255.0, 1.0);
        b = new Numbers<Double>("Blue", "Blue", 255.0, 0.0, 255.0, 1.0);
        a = new Numbers<Double>("Alpha", "Alpha", 255.0, 0.0, 255.0, 1.0);
        Arraybackground = new Numbers<Double>("ArrayAlpha", "ArrayAlpha", 60.0, 0.0, 255.0, 1.0);
        logomode = new Mode("LogoMode", "logomode", (Enum[])logomodeE.values(), (Enum)logomodeE.GameSense);
        hue = 0.0f;
        RainbowColor = Color.getHSBColor(hue / 255.0f, 0.55f, 0.9f);
        RainbowColor2 = Client.getClientColor(true);
    }

    public HUD() {
        super("HUD", new String[]{"HUD"}, ModuleType.Render);
        this.addValues(logomode, Tags, RainbowSpeed, Arraylists, this.ArrayFont, this.COMPACT_HUD, Notifications, enableNotifications, tabgui, FKCounter1, FastChat, compassValue, ArrayGap, this.Rect, this.armor, this.arrfont, this.info, Bigarry, ArrayMode, customlogo, customfont, lhp, r, g, b, a, color, Arraybackground, this.Keybind);
    }

    @EventHandler
    public void lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII(EventPacketReceive event) {
        if (EventPacketReceive.getPacket() instanceof S02PacketChat) {
            IChatComponent chat = ((S02PacketChat)EventPacketReceive.getPacket()).getChatComponent();
            if (chat.getUnformattedText().equals("                                 Mega Walls")) {
                lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII = new FKCounter();
            }
            if (lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII != null) {
                lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII.onChatMessage(((S02PacketChat)EventPacketReceive.getPacket()).getChatComponent());
            }
        }
    }

    public void e() {
        ArrayList<String> messages = new ArrayList<String>();
        messages.add(String.valueOf(new StringBuilder().append((Object)EnumChatFormatting.RED).append("RED").append((Object)EnumChatFormatting.GRAY).append(": ").append(lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII.getKills(0))));
        messages.add(String.valueOf(new StringBuilder().append((Object)EnumChatFormatting.GREEN).append("GREEN").append((Object)EnumChatFormatting.GRAY).append(": ").append(lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII.getKills(1))));
        messages.add(String.valueOf(new StringBuilder().append((Object)EnumChatFormatting.YELLOW).append("YELLOW").append((Object)EnumChatFormatting.GRAY).append(": ").append(lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII.getKills(2))));
        messages.add(String.valueOf(new StringBuilder().append((Object)EnumChatFormatting.BLUE).append("BLUE").append((Object)EnumChatFormatting.GRAY).append(": ").append(lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII.getKills(3))));
        int y = 200;
        for (String text : messages) {
            if (((Boolean)this.COMPACT_HUD.getValue()).booleanValue()) {
                Minecraft.getMinecraft();
                Minecraft.fontRendererObj.drawStringWithShadow(text, 4.0f, y, -1);
            } else {
                FontLoaders.Comfortaa18.drawStringWithShadow(text, 4.0, y, -1);
            }
            y = (int)((float)y + 9.0f);
        }
    }

    @EventHandler
    private void renderHud(EventRender2D event) {
        float f;
        Color rainbowcolors = Color.getHSBColor(hue / 255.0f, 0.4f, 0.8f);
        Color rainbowcolors2 = Color.getHSBColor(hue / 255.0f, 1.0f, 1.0f);
        Color color2222 = Color.getHSBColor(hue / 255.0f, 0.55f, 0.9f);
        int c2222 = color2222.getRGB();
        int colorXD = ((Enum)ArrayMode.getValue()).equals((Object)ArrayModeE.Wave) ? Palette.fade(Client.getClientColor(false), 100, 1).getRGB() : (((Enum)ArrayMode.getValue()).equals((Object)ArrayModeE.asto) ? HUD.getAstolfoRainbow(6) : Client.getClientColor());
        hue += ((Double)RainbowSpeed.getValue()).floatValue() / 5.0f;
        if (f > 255.0f) {
            hue = 0.0f;
        }
        float h = hue;
        if (((Boolean)lhp.getValue()).booleanValue()) {
            if (Minecraft.thePlayer.getHealth() < 6.0f && !this.lowhealth) {
                this.lowhealth = true;
            }
            if (Minecraft.thePlayer.getHealth() > 6.0f && this.lowhealth) {
                this.lowhealth = false;
            }
        }
        if (((Boolean)this.Keybind.getValue()).booleanValue()) {
            this.KeyBinds(0, 8);
            Arraylists.setValue(false);
        }
        if (((Boolean)FKCounter1.getValue()).booleanValue() && lilililllllllllllllllllliiiiiiillllllllllllllllllllllilllllllllllIIIIlllliIIII != null) {
            this.e();
        }
        CFontRenderer font = FontLoaders.GoogleSans18;
        if (((Boolean)customfont.getValue()).booleanValue()) {
            useFont = true;
        } else if (!((Boolean)customfont.getValue()).booleanValue()) {
            useFont = false;
        }
        if (((Boolean)this.armor.getValue()).booleanValue()) {
            this.renderArmorStatus(new ScaledResolution(mc));
        }
        ScaledResolution res = new ScaledResolution(mc);
        float n114514 = ScaledResolution.getScaledWidth();
        if (mc.isSingleplayer()) {
            FontLoaders.Comfortaa16.drawCenteredStringWithShadow("You are in Singleplayer mode, some module will invalid.", n114514 / 2.0f, 60.0f, SuperLib.reAlpha(SuperLib.Colors.YELLOW.c, 0.8f));
        }
        if (!HUD.mc.gameSettings.showDebugInfo) {
            String text;
            int n;
            int ychat;
            String name;
            if (((Boolean)customlogo.getValue()).booleanValue()) {
                shouldMove = true;
                switch ((logomodeE)((Object)logomode.getValue())) {
                    case GameSense: {
                        float h1 = hue;
                        float h2 = hue + 85.0f;
                        float h3 = hue + 170.0f;
                        Color color33 = Color.getHSBColor(h / 255.0f, 0.9f, 1.0f);
                        Color color3323 = Color.getHSBColor(h2 / 255.0f, 0.9f, 1.0f);
                        Color color333 = Color.getHSBColor(h3 / 255.0f, 0.9f, 1.0f);
                        int color1 = color33.getRGB();
                        int color2 = color3323.getRGB();
                        int color3 = color333.getRGB();
                        int ping = mc.getNetHandler().getPlayerInfo(Minecraft.thePlayer.getUniqueID()).getResponseTime();
                        String pings = String.valueOf(ping) + " ms";
                        shouldMove = true;
                        CFontRenderer ffff = FontLoaders.Comfortaa12;
                        String text2 = "\u00a77MineSense  | " + Minecraft.getDebugFPS() + " \u00a7fFps | " + this.df.format(new Date()) + " | " + (mc.isSingleplayer() ? "SinglePlayer" : HUD.mc.getCurrentServerData().serverIP) + " | " + (String)pings + " | " + Minecraft.thePlayer.getName();
                        RenderUtil.Gamesense(0.0, 5.0, ffff.getStringWidth(text2) + 35, 16.0, 1.0, color33.getRGB(), color3323.getRGB(), color333.getRGB());
                        ffff.drawCenteredStringWithShadow(text2, (double)(ffff.getStringWidth(text2) / 2 + 8), 14.25 - (double)(ffff.getStringHeight(text2) / 2) - 0.75, new Color(255, 255, 255).getRGB());
                        break;
                    }
                    case Jigsaw: {
                        int ping = mc.getNetHandler().getPlayerInfo(Minecraft.thePlayer.getUniqueID()).getResponseTime();
                        String pings = String.valueOf(String.valueOf(ping)) + "ms";
                        if (ping == 0) {
                            pings = "N/A";
                        }
                        GlStateManager.pushMatrix();
                        GlStateManager.translate(0.0f, 1.0f, 1.0f);
                        RenderUtil.drawRoundedRect(1.5f, 1.0f, 49.0f, 13.0f, 2.0f, new Color(224, 223, 225).getRGB());
                        RenderUtil.drawRoundedRect(1.0f, 1.0f, 46.0f, 13.0f, 2.0f, new Color(1, 30, 44).getRGB());
                        RenderUtil.drawRoundedRect(47.0f, 1.0f, 72.0f, 13.0f, 3.0f, new Color(224, 223, 225).getRGB());
                        Gui.drawRect(47, 1, 49, 13, new Color(1, 30, 44).getRGB());
                        RenderUtil.drawRoundedRect(47.0f, 1.0f, 71.0f, 13.0f, 2.0f, new Color(1, 30, 44).getRGB());
                        RenderUtil.drawRoundedRect(45.0f, 1.0f, 45.5f, 13.0f, 1.0f, new Color(1, 30, 54).getRGB());
                        CFontRenderer font2 = FontLoaders.GoogleSans15;
                        FontLoaders.Comfortaa20.drawStringWithShadow("\u00a7DOLITA", 2.0, 3.5, -1);
                        GlStateManager.pushMatrix();
                        GlStateManager.scale(0.5, 0.5, 0.5);
                        FontLoaders.Comfortaa22.drawStringWithShadow(String.valueOf(String.valueOf(Minecraft.debugFPS)) + "fps", 102.0, 4.0, -1);
                        FontLoaders.Comfortaa22.drawStringWithShadow(pings, 102.0, 16.0, -1);
                        GlStateManager.popMatrix();
                        GlStateManager.popMatrix();
                        break;
                    }
                    case Novoline: {
                        int ychat2 = HUD.mc.ingameGUI.getChatGUI().getChatOpen() ? 25 : 10;
                        name = "\u00a7l" + "MineSense".substring(0, 1);
                        int ping = mc.getNetHandler().getPlayerInfo(Minecraft.thePlayer.getUniqueID()).getResponseTime();
                        String text3 = (Object)((Object)EnumChatFormatting.WHITE) + "XYZ: " + (Object)((Object)EnumChatFormatting.GRAY) + MathHelper.floor_double(Minecraft.thePlayer.posX) + " " + (Object)((Object)EnumChatFormatting.GRAY) + MathHelper.floor_double(Minecraft.thePlayer.posY) + " " + (Object)((Object)EnumChatFormatting.GRAY) + MathHelper.floor_double(Minecraft.thePlayer.posZ) + (Object)((Object)EnumChatFormatting.WHITE) + " | " + (Object)((Object)EnumChatFormatting.WHITE) + "FPS: " + (Object)((Object)EnumChatFormatting.GRAY) + Minecraft.debugFPS + (Object)((Object)EnumChatFormatting.WHITE);
                        FontLoaders.GoogleSans28.drawStringWithShadow(clientName.substring(0, 1), 3.0, 3.0, colorXD);
                        String ok = "MineSense".substring(1);
                        FontLoaders.GoogleSans28.drawStringWithShadow(clientName.substring(1), (float)font.getStringWidth(name) + 6.3f, 3.0, new Color(255, 255, 255).getRGB());
                        break;
                    }
                    case OneTap: {
                        int ping = mc.getNetHandler().getPlayerInfo(Minecraft.thePlayer.getUniqueID()).getResponseTime();
                        String pings = String.valueOf(String.valueOf(ping)) + "ms";
                        String text4 = "Astolfo | User: " + HWIDMenu.hwid.getText() + " | " + "ping: " + pings;
                        String text2 = "Astolfo | User: " + HWIDMenu.hwid.getText() + " | " + "ping: " + pings;
                        int textLength = ((Boolean)fontValue.getValue()).booleanValue() ? font.getStringWidth(text4) / 2 + 50 + 5 : Minecraft.fontRendererObj.getStringWidth(text4) / 2 + 34;
                        float rectHeight = 0.8f;
                        RenderUtil2.drawRect(4.0, 4.0, 4 + textLength, 4.0f + rectHeight, colorXD);
                        GlStateManager.pushMatrix();
                        if (((Boolean)fontValue.getValue()).booleanValue()) {
                            font.drawStringWithOutline(text2, 5.7f, 8.7f, -1, 0);
                        } else {
                            GlStateManager.scale(0.7, 0.7, 0.7);
                            Minecraft.fontRendererObj.drawStringWithOutline(text2, 7.7f, 9.7f, -1, 0);
                        }
                        GlStateManager.popMatrix();
                        this.posY += 13;
                        break;
                    }
                    case Csgo: {
                        String text5 = "N\u00a77ivia \u00a7fb" + Client.version + " | \u00a77" + "Player: \u00a7f" + Minecraft.thePlayer.getName() + "\u00a7f | \u00a77" + "User: \u00a7f" + HWIDMenu.hwid.getText() + "\u00a7f | \u00a77" + (mc.isSingleplayer() ? "In \u00a7fSingle Player" : "In \u00a7f" + HUD.mc.getCurrentServerData().serverIP.toLowerCase()) + "\u00a7f | \u00a77" + "Time: \u00a7f" + new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime()) + "\u00a7f | \u00a77" + "FPS: \u00a7f" + mc.getDebugFPS();
                        RenderUtil.drawRect(4.0f, 4.0f, (float)Minecraft.fontRendererObj.getStringWidth(text5) / 2.0f + 4.0f + 8.0f, 15.5f, new Color(60, 60, 60).getRGB());
                        RenderUtil.drawRect(5.0f, 5.0f, (float)Minecraft.fontRendererObj.getStringWidth(text5) / 2.0f + 5.0f + 6.0f, 14.5f, new Color(14, 14, 14).getRGB());
                        GlStateManager.pushMatrix();
                        GlStateManager.scale(0.5, 0.5, 0.5);
                        Minecraft.fontRendererObj.drawString(text5, 16, 16, colorXD);
                        GlStateManager.popMatrix();
                    }
                }
            } else if (!((Boolean)customlogo.getValue()).booleanValue()) {
                shouldMove = false;
                if (useFont) {
                    CFontRenderer cFontRenderer3 = font;
                    StringBuilder append3 = new StringBuilder(String.valueOf(Client.name)).append(" ").append((Object)EnumChatFormatting.GRAY);
                } else {
                    FontRenderer fontRendererObj3 = Minecraft.fontRendererObj;
                    StringBuilder text5 = new StringBuilder(String.valueOf(Client.name)).append(" ").append((Object)EnumChatFormatting.GRAY);
                }
            }
            int ychat2 = HUD.mc.ingameGUI.getChatGUI().getChatOpen() ? 25 : 10;
            int n2 = ychat2;
            if (this.renderY < (float)ychat2) {
                this.renderY = (float)((double)this.renderY + 0.5);
            }
            if (this.renderY > (float)ychat2) {
                this.renderY = (float)((double)this.renderY - 0.5);
            }
            ScaledResolution sr = new ScaledResolution(mc);
            if (((Boolean)this.ArrayFont.getValue()).booleanValue()) {
                fontarry = (Boolean)Bigarry.getValue() != false ? FontLoaders.Comfortaa19 : FontLoaders.Comfortaa16;
            } else {
                CFontRenderer cFontRenderer = fontarry = (Boolean)Bigarry.getValue() != false ? FontLoaders.GoogleSans20 : FontLoaders.GoogleSans19;
            }
            if (((Boolean)this.info.getValue()).booleanValue()) {
                String in12 = (Object)((Object)EnumChatFormatting.GRAY) + "Developer Build - " + (Object)((Object)EnumChatFormatting.WHITE) + "#Beta" + (Object)((Object)EnumChatFormatting.GRAY) + " - " + HWIDMenu.hwid.getText();
                if (((Boolean)customfont.getValue()).booleanValue()) {
                    new ScaledResolution(mc);
                    fontarry.drawStringWithShadow(in12, ScaledResolution.getScaledWidth() - fontarry.getStringWidth(in12) - 2, (float)ScaledResolution.getScaledHeight() - this.renderY, new Color(255, 255, 255).getRGB());
                } else {
                    new ScaledResolution(mc);
                    Minecraft.fontRendererObj.drawStringWithShadow(in12, ScaledResolution.getScaledWidth() - Minecraft.fontRendererObj.getStringWidth(in12) - 2, (float)ScaledResolution.getScaledHeight() - this.renderY, new Color(255, 255, 255).getRGB());
                }
            }
            int[] counter = new int[1];
            if (((Boolean)Arraylists.getValue()).booleanValue()) {
                ArrayList<Module> sorted = new ArrayList<Module>();
                for (Module m : ModuleManager.getModules()) {
                    if (m.wasRemoved() || !m.isEnabled() && !m.getRender()) continue;
                    sorted.add(m);
                }
                if (!((Boolean)this.arrfont.getValue()).booleanValue()) {
                    sorted.sort((o1, o2) -> Minecraft.fontRendererObj.getStringWidth(o2.getSuffix().isEmpty() ? Client.getModuleName(o2) : String.format("%s %s", Client.getModuleName(o2), o2.getSuffix())) - Minecraft.fontRendererObj.getStringWidth(o1.getSuffix().isEmpty() ? Client.getModuleName(o1) : String.format("%s %s", Client.getModuleName(o1), o1.getSuffix())));
                } else {
                    sorted.sort((o1, o2) -> fontarry.getStringWidth(o2.getSuffix().isEmpty() ? Client.getModuleName(o2) : String.format("%s %s", Client.getModuleName(o2), o2.getSuffix())) - fontarry.getStringWidth(o1.getSuffix().isEmpty() ? Client.getModuleName(o1) : String.format("%s %s", Client.getModuleName(o1), o1.getSuffix())));
                }
                int y = 0;
                int lastX = 0;
                boolean first = true;
                Color color = new Color(((Double)HUD.color.getValue()).intValue());
                int rainbowTick = 0;
                for (Module m : sorted) {
                    Color rainbowcolor = Color.getHSBColor(h / 255.0f, 0.6f, 0.7f);
                    Color rainbowcolor2 = Color.getHSBColor(h / 255.0f, 0.6f, 1.0f);
                    color = new Color(((Double)HUD.color.getValue()).intValue());
                    if (h > 255.0f) {
                        h = 0.0f;
                    }
                    if (((Enum)ArrayMode.getValue()).equals((Object)ArrayModeE.Wave)) {
                        color = Palette.fade(Client.getClientColor(false), 100, sorted.indexOf(m) * 4 + 50);
                    }
                    if (((Enum)ArrayMode.getValue()).equals((Object)ArrayModeE.asto)) {
                        color = new Color(HUD.getAstolfoRainbow(y * 6));
                    }
                    name = m.getSuffix().isEmpty() ? Client.getModuleName(m) : String.format("%s %s", Client.getModuleName(m), m.getSuffix());
                    int x = RenderUtil.width() - m.getX();
                    if (((Boolean)this.arrfont.getValue()).booleanValue()) {
                        Gui.drawRect(x - 3, y, x + fontarry.getStringWidth(name), y + 11, new Color(0, 0, 0, ((Double)Arraybackground.getValue()).intValue()).getRGB());
                    } else {
                        Gui.drawRect(x - 3, y, x + Minecraft.fontRendererObj.getStringWidth(name), y + 11, new Color(0, 0, 0, ((Double)Arraybackground.getValue()).intValue()).getRGB());
                    }
                    if (((Boolean)this.Rect.getValue()).booleanValue()) {
                        if (((Boolean)this.arrfont.getValue()).booleanValue()) {
                            Gui.drawRect(x - 4, y, x - 3, y + 11, color.getRGB());
                            if (!first) {
                                boolean Del = lastX - 3 - 1 > lastX - 3 - 1 - (lastX - 3 - 1 - (x - 3 - 1));
                                Gui.drawRect(lastX - 3 - 1 + (Del ? 1 : 0), y - 1 + (Del ? 0 : 1), lastX - 3 - 1 - (lastX - 3 - 1 - (x - 3 - 1)), y + (Del ? 0 : 1), color.getRGB());
                            }
                        } else {
                            if (first) {
                                Gui.drawRect(x - 4, 0, x + Minecraft.fontRendererObj.getStringWidth(name), 1, color.getRGB());
                            }
                            Gui.drawRect(x - 4, y, x - 3, y + 11, color.getRGB());
                            if (!first) {
                                boolean Del = lastX - 3 - 1 > lastX - 3 - 1 - (lastX - 3 - 1 - (x - 3 - 1));
                                Gui.drawRect(lastX - 3 - 1 + (Del ? 1 : 0), y - 1 + (Del ? 0 : 1), lastX - 3 - 1 - (lastX - 3 - 1 - (x - 3 - 1)), y + (Del ? 0 : 1), color.getRGB());
                            }
                        }
                    }
                    if (!((Boolean)this.arrfont.getValue()).booleanValue()) {
                        Minecraft.fontRendererObj.drawStringWithShadow(name, x - 1, y + 1, color.getRGB());
                    } else {
                        fontarry.drawStringWithShadow(name, x - 1, y + 3, color.getRGB());
                    }
                    lastX = x;
                    first = false;
                    h += 9.0f;
                    if (this.fpsanim.hasReached(12.3)) {
                        if (!((Boolean)this.arrfont.getValue()).booleanValue()) {
                            if (m.getX() < Minecraft.fontRendererObj.getStringWidth(name) && m.getX() != fontarry.getStringWidth(name) && m.getRender() && m.isEnabled()) {
                                m.setX(m.getX() + 1);
                            }
                            if (m.getX() > Minecraft.fontRendererObj.getStringWidth(name) && m.getX() != Minecraft.fontRendererObj.getStringWidth(name) && m.getRender() && m.isEnabled()) {
                                m.setX(m.getX() - 1);
                            }
                            if (m.getX() > -1 && m.getX() != -1 && m.getRender() && !m.isEnabled()) {
                                m.setX(m.getX() - 1);
                            }
                            if (m.getX() == -1) {
                                m.setRender(false);
                            }
                            if (m.getX() < Minecraft.fontRendererObj.getStringWidth(name) && m.getX() != Minecraft.fontRendererObj.getStringWidth(name) && m.getRender() && m.isEnabled()) {
                                m.setX(m.getX() + 1);
                            }
                            if (m.getX() > Minecraft.fontRendererObj.getStringWidth(name) && m.getX() != Minecraft.fontRendererObj.getStringWidth(name) && m.getRender() && m.isEnabled()) {
                                m.setX(m.getX() - 1);
                            }
                            if (m.getX() > -1 && m.getX() != -1 && m.getRender() && !m.isEnabled()) {
                                m.setX(m.getX() - 1);
                            }
                            if (m.getX() == -1) {
                                m.setRender(false);
                            }
                            if (m.getX() < Minecraft.fontRendererObj.getStringWidth(name) && m.getX() != Minecraft.fontRendererObj.getStringWidth(name) && m.getRender() && m.isEnabled()) {
                                m.setX(m.getX() + 1);
                            }
                            if (m.getX() > Minecraft.fontRendererObj.getStringWidth(name) && m.getX() != Minecraft.fontRendererObj.getStringWidth(name) && m.getRender() && m.isEnabled()) {
                                m.setX(m.getX() - 1);
                            }
                            if (m.getX() > -1 && m.getX() != -1 && m.getRender() && !m.isEnabled()) {
                                m.setX(m.getX() - 1);
                            }
                            if (m.getX() == -1) {
                                m.setRender(false);
                            }
                            y = (int)((double)y + ((double)(11 < Minecraft.fontRendererObj.getStringWidth(name) ? Math.min(11, m.getX()) : 11) - (Double)ArrayGap.getValue()));
                        } else {
                            if (m.getX() < fontarry.getStringWidth(name) && m.getX() != fontarry.getStringWidth(name) && m.getRender() && m.isEnabled()) {
                                m.setX(m.getX() + 1);
                            }
                            if (m.getX() > fontarry.getStringWidth(name) && m.getX() != fontarry.getStringWidth(name) && m.getRender() && m.isEnabled()) {
                                m.setX(m.getX() - 1);
                            }
                            if (m.getX() > -1 && m.getX() != -1 && m.getRender() && !m.isEnabled()) {
                                m.setX(m.getX() - 1);
                            }
                            if (m.getX() == -1) {
                                m.setRender(false);
                            }
                            if (m.getX() < fontarry.getStringWidth(name) && m.getX() != fontarry.getStringWidth(name) && m.getRender() && m.isEnabled()) {
                                m.setX(m.getX() + 1);
                            }
                            if (m.getX() > fontarry.getStringWidth(name) && m.getX() != fontarry.getStringWidth(name) && m.getRender() && m.isEnabled()) {
                                m.setX(m.getX() - 1);
                            }
                            if (m.getX() > -1 && m.getX() != -1 && m.getRender() && !m.isEnabled()) {
                                m.setX(m.getX() - 1);
                            }
                            if (m.getX() == -1) {
                                m.setRender(false);
                            }
                            if (m.getX() < fontarry.getStringWidth(name) && m.getX() != fontarry.getStringWidth(name) && m.getRender() && m.isEnabled()) {
                                m.setX(m.getX() + 1);
                            }
                            if (m.getX() > fontarry.getStringWidth(name) && m.getX() != fontarry.getStringWidth(name) && m.getRender() && m.isEnabled()) {
                                m.setX(m.getX() - 1);
                            }
                            if (m.getX() > -1 && m.getX() != -1 && m.getRender() && !m.isEnabled()) {
                                m.setX(m.getX() - 1);
                            }
                            if (m.getX() == -1) {
                                m.setRender(false);
                            }
                            y = (int)((double)y + ((double)(11 < fontarry.getStringWidth(name) ? Math.min(11, m.getX()) : 11) - (Double)ArrayGap.getValue()));
                        }
                    }
                    int[] arrn = counter;
                    arrn[0] = arrn[0] + 1;
                }
                if (++rainbowTick > 50) {
                    rainbowTick = 0;
                }
                if (((Boolean)this.Rect.getValue()).booleanValue() && !sorted.isEmpty()) {
                    Gui.drawRect(lastX - 3 - 1, y, RenderUtil.width(), y + 1, color.getRGB());
                }
            }
            int ping = mc.getNetHandler().getPlayerInfo(Minecraft.thePlayer.getUniqueID()).getResponseTime();
            String pings = String.valueOf(ping) + "ms";
            if (ping == 0) {
                pings = "N/A";
            }
            if (useFont) {
                n = ychat = HUD.mc.ingameGUI.getChatGUI().getChatOpen() ? 24 : 10;
                if (((Boolean)this.info.getValue()).booleanValue()) {
                    BigDecimal bg = new BigDecimal(Minecraft.thePlayer.getVelocity() * 10.0);
                    double curSpeed = bg.setScale(2, 4).doubleValue();
                    text = String.valueOf((int)Minecraft.thePlayer.posX) + " " + (int)Minecraft.thePlayer.posY + " " + (int)Minecraft.thePlayer.posZ;
                    new ScaledResolution(mc);
                    fontarry.drawStringWithShadow(text, 1.0, (float)ScaledResolution.getScaledHeight() - this.renderY, new Color(((Double)color.getValue()).intValue()).getRGB());
                    new ScaledResolution(mc);
                    fontarry.drawStringWithShadow("" + curSpeed + (Object)((Object)EnumChatFormatting.GRAY) + " b/s ", 1.0, (float)(ScaledResolution.getScaledHeight() - 10) - this.renderY, new Color(((Double)color.getValue()).intValue()).getRGB());
                    this.drawPotionStatus(new ScaledResolution(mc));
                }
                this.drawPotionStatus(new ScaledResolution(mc));
            } else {
                n = ychat = HUD.mc.ingameGUI.getChatGUI().getChatOpen() ? 25 : 10;
                if (((Boolean)this.info.getValue()).booleanValue()) {
                    BigDecimal bg = new BigDecimal(Minecraft.thePlayer.getVelocity() * 10.0);
                    double curSpeed = bg.setScale(2, 4).doubleValue();
                    text = String.valueOf((int)Minecraft.thePlayer.posX) + " " + (int)Minecraft.thePlayer.posY + " " + (int)Minecraft.thePlayer.posZ;
                    new ScaledResolution(mc);
                    Minecraft.fontRendererObj.drawStringWithShadow(text, 1.0f, (float)ScaledResolution.getScaledHeight() - this.renderY, new Color(((Double)color.getValue()).intValue()).getRGB());
                    new ScaledResolution(mc);
                    Minecraft.fontRendererObj.drawStringWithShadow("" + curSpeed + (Object)((Object)EnumChatFormatting.GRAY) + " b/s ", 1.0f, (float)(ScaledResolution.getScaledHeight() - 10) - this.renderY, new Color(((Double)color.getValue()).intValue()).getRGB());
                    this.drawPotionStatus(new ScaledResolution(mc));
                }
            }
            if (((Boolean)customlogo.getValue()).booleanValue()) {
                int y = 128;
            } else {
                int n3 = 112;
            }
        }
    }

    public static int astofloc(int delay) {
        float speed = 3200.0f;
        float hue = (float)(System.currentTimeMillis() % (long)((int)speed)) + (float)(delay / 2);
        while (hue > speed) {
            hue -= speed;
        }
        if ((double)(hue /= speed) > 0.5) {
            hue = 0.5f - hue - 0.5f;
        }
        return Color.HSBtoRGB(hue += 0.5f, 0.5f, 1.0f);
    }

    private void drawPotionStatus(ScaledResolution sr) {
        ResourceLocation inventoryBackground = new ResourceLocation("textures/gui/container/inventory.png");
        int i = -5;
        int j = 75;
        int k = 166;
        Collection<PotionEffect> collection = Minecraft.thePlayer.getActivePotionEffects();
        if (!collection.isEmpty()) {
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.disableLighting();
            int l = 33;
            if (collection.size() > 5) {
                l = 132 / (collection.size() - 1);
            }
            for (PotionEffect potioneffect : Minecraft.thePlayer.getActivePotionEffects()) {
                String s;
                Potion potion = Potion.potionTypes[potioneffect.getPotionID()];
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                mc.getTextureManager().bindTexture(inventoryBackground);
                if (potion.hasStatusIcon()) {
                    int i1 = potion.getStatusIconIndex();
                    HUD.mc.ingameGUI.drawTexturedModalRect(i + 6, j + 7, 0 + i1 % 8 * 18, 198 + i1 / 8 * 18, 18, 18);
                }
                String s1 = I18n.format(potion.getName(), new Object[0]);
                if (potioneffect.getAmplifier() == 1) {
                    s1 = String.valueOf(s1) + " " + I18n.format("enchantment.level.2", new Object[0]);
                } else if (potioneffect.getAmplifier() == 2) {
                    s1 = String.valueOf(s1) + " " + I18n.format("enchantment.level.3", new Object[0]);
                } else if (potioneffect.getAmplifier() == 3) {
                    s1 = String.valueOf(s1) + " " + I18n.format("enchantment.level.4", new Object[0]);
                }
                CFontRenderer fonts = FontLoaders.GoogleSans18;
                if (useFont) {
                    fonts.drawStringWithShadow(s1, i + 10 + 18, j + 6, 0xFFFFFF);
                    s = Potion.getDurationString(potioneffect);
                    fonts.drawStringWithShadow(s, i + 10 + 18, j + 6 + 10, 0x7F7F7F);
                    j += l;
                    continue;
                }
                Minecraft.fontRendererObj.drawStringWithShadow(s1, i + 10 + 18, j + 6, 0xFFFFFF);
                s = Potion.getDurationString(potioneffect);
                Minecraft.fontRendererObj.drawStringWithShadow(s, i + 10 + 18, j + 6 + 10, 0x7F7F7F);
                j += l;
            }
        }
    }

    @Override
    @EventHandler
    public void onDisable() {
        PotY = 0;
    }

    public String getAmplifier(int count) {
        String Amplifier = "";
        switch (count) {
            case 0: {
                Amplifier = " I";
                break;
            }
            case 1: {
                Amplifier = " II";
                break;
            }
            case 2: {
                Amplifier = " III";
                break;
            }
            case 3: {
                Amplifier = " IV";
                break;
            }
            case 4: {
                Amplifier = " V";
                break;
            }
            case 5: {
                Amplifier = " VI";
                break;
            }
            case 6: {
                Amplifier = " VII";
                break;
            }
            case 7: {
                Amplifier = " VIII";
                break;
            }
            case 8: {
                Amplifier = " IX";
                break;
            }
            case 9: {
                Amplifier = " X";
            }
        }
        if (count >= 10) {
            Amplifier = " X+";
        }
        return Amplifier;
    }

    private void KeyBinds(int x, int y) {
        CFontRenderer font = FontLoaders.Comfortaa14;
        ArrayList<Module> mod = new ArrayList<Module>(ModuleManager.getModules());
        mod.sort((o1, o2) -> font.getStringWidth(o2.getName()) - font.getStringWidth(o1.getName()));
        int my = y + 15;
        for (Module m : mod) {
            if (m.getKey() == 0) continue;
            int bg = new Color(0, 0, 0, 120).getRGB();
            FontLoaders.Comfortaa14.drawStringWithShadow(m.getName(), x + 2, (float)my + 3.0f, HUD.getAstolfoRainbow(my * 6));
            FontLoaders.Comfortaa14.drawStringWithShadow("[" + Keyboard.getKeyName((int)m.getKey()) + "]", x + font.getStringWidth(mod.get(1).getName()) + 19 - font.getStringWidth("[" + Keyboard.getKeyName((int)m.getKey()) + "]"), (float)my + 3.0f, HUD.getAstolfoRainbow(my * 6));
            my += 9;
        }
    }

    public static int getAstolfoRainbow(int v1) {
        double d;
        double length = 1.6;
        double delay = Math.ceil((double)(System.currentTimeMillis() + (long)((double)v1 * length)) / 5.0);
        float rainbow = (double)((float)(d / 360.0)) < 0.5 ? -((float)(delay / 360.0)) : (float)((delay %= 360.0) / 360.0);
        return Color.getHSBColor(rainbow, 0.6f, 1.0f).getRGB();
    }

    public void renderArmorStatus(ScaledResolution sr) {
        CFontRenderer font = FontLoaders.Comfortaa16;
        GL11.glPushMatrix();
        int divide = 0;
        RenderItem ir = new RenderItem(mc.getTextureManager(), HUD.mc.modelManager);
        ArrayList<ItemStack> stuff = new ArrayList<ItemStack>();
        int split = 17;
        int index = 3;
        while (index >= 0) {
            ItemStack armer = Minecraft.thePlayer.inventory.armorInventory[index];
            if (armer != null) {
                stuff.add(armer);
            }
            --index;
        }
        for (ItemStack errything : stuff) {
            boolean half = ++divide > 2;
            int x = ScaledResolution.getScaledWidth() / 2 + split;
            int y = ScaledResolution.getScaledHeight() - 58;
            if (Minecraft.theWorld != null) {
                RenderHelper.enableGUIStandardItemLighting();
                ir.renderItemIntoGUI(errything, x, y);
                Minecraft.getMinecraft();
                ir.renderItemOverlays(Minecraft.fontRendererObj, errything, x, y);
                RenderHelper.enableGUIStandardItemLighting();
                split += 18;
            }
            int damage = errything.getMaxDamage() - errything.getItemDamage();
            GlStateManager.enableAlpha();
            GlStateManager.disableCull();
            GlStateManager.disableBlend();
            GlStateManager.disableLighting();
            GlStateManager.clear(256);
            GL11.glPushMatrix();
            GL11.glPopMatrix();
            NBTTagList nBTTagList = errything.getEnchantmentTagList();
        }
        GL11.glPopMatrix();
    }

    public static Color getCustomColor() {
        return new Color(((Double)r.getValue()).intValue(), ((Double)g.getValue()).intValue(), ((Double)b.getValue()).intValue());
    }

    public static enum ArrayModeE {
        asto,
        Wave,
        None;

    }

    static class PPSRenderer {
        private int x;
        private int y;
        private final String fuckingName;
        private final ArrayList<Integer> list;
        private Minecraft mc = Minecraft.getMinecraft();

        public PPSRenderer(int xx, int yy, String name, ArrayList<Integer> targetList) {
            this.x = xx;
            this.y = yy;
            this.list = targetList;
            this.fuckingName = name;
        }

        public void draw() {
            int renderY = Math.max(Math.round((float)(this.y + 30) - (float)this.list.get(this.list.size() - 1).intValue() / 26.0f - 2.0f), this.y);
            GlStateManager.pushMatrix();
            GlStateManager.scale(0.5, 0.5, 0.5);
            FontLoaders.Comfortaa22.drawStringWithShadow(String.valueOf(this.fuckingName) + " Count/s", (this.x + 1) * 2, this.y * 2, HUD.getAstolfoRainbow(renderY * 6));
            FontLoaders.Comfortaa22.drawStringWithShadow(this.list.get(this.list.size() - 1) + " P/s", (this.x + 100) * 2, renderY * 2, HUD.getAstolfoRainbow(renderY * 6));
            GlStateManager.popMatrix();
            this.y += 5;
            RenderUtil.drawBorderedRect(this.x, this.y, this.x + 95, this.y + 30, 0.5f, -1, new Color(0, 0, 0, 150).getRGB());
            RenderUtil.startGlScissor(this.x, this.y, 95, 30);
            int xOffset = this.x;
            int i = 0;
            while (i < this.list.size()) {
                if (this.list.size() > 1 && i > 1) {
                    this.connectPoints((float)xOffset - 3.5f, (float)this.y + 29.5f - (float)this.list.get(i - 1).intValue() / 26.0f, (float)xOffset - 1.5f, (float)this.y + 29.5f - (float)this.list.get(i).intValue() / 26.0f, -1);
                }
                if ((xOffset += 2) == 103) {
                    this.list.remove(0);
                }
                ++i;
            }
            RenderUtil.rectangle(this.x, Math.round((float)(this.y + 30) - (float)this.list.get(this.list.size() - 1).intValue() / 26.0f - 2.0f) + 1, this.x + 95, (float)Math.round((float)(this.y + 30) - (float)this.list.get(this.list.size() - 1).intValue() / 26.0f - 2.0f) + 1.5f, Color.GREEN.getRGB());
            RenderUtil.stopGlScissor();
        }

        private void connectPoints(float xOne, float yOne, float xTwo, float yTwo, int color) {
            GL11.glPushMatrix();
            GL11.glEnable((int)2848);
            GL11.glDisable((int)3553);
            GL11.glBlendFunc((int)770, (int)771);
            GL11.glEnable((int)3042);
            GL11.glLineWidth((float)2.0f);
            GL11.glBegin((int)1);
            GL11.glVertex2f((float)xOne, (float)yOne);
            GL11.glVertex2f((float)xTwo, (float)yTwo);
            GL11.glEnd();
            GlStateManager.resetColor();
            GL11.glDisable((int)2848);
            GL11.glEnable((int)3553);
            GL11.glPopMatrix();
        }
    }

    public static enum TagMode {
        None,
        Null,
        Hyphen,
        Box;

    }

    public static enum logomodeE {
        Novoline,
        Jigsaw,
        GameSense,
        Csgo,
        OneTap;

    }
}

