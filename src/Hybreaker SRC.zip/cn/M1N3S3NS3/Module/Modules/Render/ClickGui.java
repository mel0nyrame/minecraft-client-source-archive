/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.UI.Astolfo.asClickgui;
import cn.M1N3S3NS3.UI.ClickGuiScreen;
import cn.M1N3S3NS3.UI.Clickgui;
import cn.M1N3S3NS3.UI.GuiClickUI;
import de.Hero.clickgui.ClickGUI;
import de.Hero.clickgui.Panel;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.Minecraft;

public class ClickGui
extends Module {
    public static Option<Boolean> blur = new Option<Boolean>("Blur", "Blur", false);
    private static final Option<Boolean> bottomValue = new Option<Boolean>("Bottom", "If u don't know , toggle it and look", true);
    private static final Option<Boolean> borderValue = new Option<Boolean>("Border", "Just bord the window", false);
    private static final Mode<grilleEnums> grilleValue = new Mode("Grille", "Exhi has this", (Enum[])grilleEnums.values(), (Enum)grilleEnums.None);
    private static final Numbers<Number> gradientValue = new Numbers<Double>("Bottom gradient", "Depends on ur PC performers", 8.0, 1.0, 30.0, 1.0);
    public static ArrayList<Panel> panels;
    public static ArrayList<Panel> rpanels;
    private Mode mode = new Mode("Mode", (Enum[])RenderMode.values(), (Enum)RenderMode.onetap);
    public static int memoriseX;
    public static int memoriseY;
    public static int memoriseWheel;
    public static List<Module> memoriseML;
    public static ModuleType memoriseCatecory;

    static {
        memoriseX = 30;
        memoriseY = 30;
        memoriseWheel = 0;
        memoriseML = new CopyOnWriteArrayList<Module>();
        memoriseCatecory = null;
    }

    public ClickGui() {
        super("ClickGui", new String[]{"clickui"}, ModuleType.Render);
        super.setRemoved(true);
        this.addValues(this.mode, grilleValue, blur, bottomValue, borderValue, gradientValue);
    }

    public static Option<Boolean> getBottomValue() {
        return bottomValue;
    }

    public static Option<Boolean> getBorderValue() {
        return borderValue;
    }

    public static Numbers<Number> getGradientValue() {
        return gradientValue;
    }

    public static Mode<grilleEnums> getGrilleValue() {
        return grilleValue;
    }

    @Override
    public void onEnable() {
        if (this.mode.getValue() == RenderMode.new2) {
            mc.displayGuiScreen(new ClickGUI());
        }
        if (this.mode.getValue() == RenderMode.onetap) {
            Minecraft.getMinecraft().displayGuiScreen(Client.instance.newClickgui);
        }
        if (this.mode.getValue() == RenderMode.Sunny) {
            mc.displayGuiScreen(new Clickgui());
        }
        if (this.mode.getValue() == RenderMode.Astolfo) {
            mc.displayGuiScreen(new asClickgui());
        }
        if (this.mode.getValue() == RenderMode.aneex) {
            mc.displayGuiScreen(new ClickGuiScreen());
            ClickGuiScreen.setX(memoriseX);
            ClickGuiScreen.setY(memoriseY);
            ClickGuiScreen.setWheel(memoriseWheel);
            ClickGuiScreen.setInSetting(memoriseML);
            if (memoriseCatecory != null) {
                ClickGuiScreen.setCategory(memoriseCatecory);
            }
        }
        if (this.mode.getValue() == RenderMode.chsot) {
            mc.displayGuiScreen(new GuiClickUI());
            GuiClickUI.setX(memoriseX);
            GuiClickUI.setY(memoriseY);
            GuiClickUI.setWheel(memoriseWheel);
            GuiClickUI.setInSetting(memoriseML);
            if (memoriseCatecory != null) {
                GuiClickUI.setCategory(memoriseCatecory);
            }
        }
        this.setEnabled(false);
    }

    static enum RenderMode {
        onetap,
        new2,
        Sunny,
        chsot,
        aneex,
        Astolfo;

    }

    public static enum grilleEnums {
        None,
        HUD,
        Rainbow;

    }
}

