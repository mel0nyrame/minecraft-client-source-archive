/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.ibm.icu.math.BigDecimal
 *  com.ibm.icu.text.NumberFormat
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.KillAura;
import cn.M1N3S3NS3.UI.Font.CFontRenderer;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.Util.Math.MathUtil;
import cn.M1N3S3NS3.Util.PlayerUtil;
import cn.M1N3S3NS3.Util.Render.AnimationUtil;
import cn.M1N3S3NS3.Util.Render.Animationutils;
import cn.M1N3S3NS3.Util.Render.BLCRender;
import cn.M1N3S3NS3.Util.Render.ColorUtils;
import cn.M1N3S3NS3.Util.Render.Colors;
import cn.M1N3S3NS3.Util.Render.R3DUtil;
import cn.M1N3S3NS3.Util.Render.RenderUtil;
import cn.M1N3S3NS3.Util.RenderUtils;
import cn.M1N3S3NS3.Util.timer.Stopwatch;
import com.ibm.icu.text.NumberFormat;
import java.awt.Color;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class TargetHUD2
extends Module {
    boolean Crit = false;
    public static Mode<Enum> mode = new Mode("Mode", "Mode", (Enum[])TargetHudEnum.values(), (Enum)TargetHudEnum.Astolfo);
    NetworkPlayerInfo playerInfo;
    float width2 = 0.0f;
    float powerxHealthAnim = 0.0f;
    double healthamout = 0.0;
    double anima = 0.0;
    double rect;
    double r2;
    int color;
    double anim21 = 0.0;
    int animAlpha = 0;
    float anim = 75.0f;
    private final CFontRenderer font = FontLoaders.Comfortaa18;
    public static float AnimotaiX;
    float anim2 = 0.0f;
    int posX = 400;
    final ScaledResolution scaledRes = new ScaledResolution(mc);
    float astolfoHelathAnim = 0.0f;
    boolean startAnim;
    boolean stopAnim;
    public EntityLivingBase lastEnt;
    private int animWidth;
    private int lastWidth;
    public float lastHealth = -1.0f;
    public float damageDelt = 0.0f;
    public float lastPlayerHealth = -1.0f;
    public float damageDeltToPlayer = 0.0f;
    public DecimalFormat format = new DecimalFormat("0.0");
    float width = 0.0f;
    double healthwidth;
    double maxhealth1;
    float maxhealth = 1.0f;
    public static float hue;
    private static final Color COLOR;
    String Distance = "";
    int ColourBreathingOffset = 0;
    public static float AnimotaiSpeed;
    private final Stopwatch animationStopwatch = new Stopwatch();
    private EntityLivingBase target;
    private double healthBarWidth;
    private double hudHeight;
    String targetPing;
    int TargetDistance = 0;
    int targetHurtTime = 0;
    int animationSpeed = 10;
    int Purple = new Color(84, 30, 97).getRGB();
    int Blue = new Color(32, 45, 99).getRGB();
    int Green = new Color(45, 214, 45).getRGB();
    int Red = new Color(190, 0, 0).getRGB();
    int White = new Color(255, 255, 255).getRGB();
    int Aftery = new Color(255, 160, 255).getRGB();
    int mcHeight = 100;
    int mcWidth = 100;
    private Object texture;
    KillAura KillAura = (KillAura)ModuleManager.getModuleByClass(KillAura.class);
    double healthLocationani;
    public double healthanimation;
    float curAbsorptionAmountX = 0.0f;
    float curY;
    float curHealthX = 0.0f;
    private double Animation = 0.0;

    static {
        hue = 0.0f;
        COLOR = new Color(0, 0, 0, 180);
    }

    public TargetHUD2() {
        super("TargetHUD2", new String[]{"TargetHUD2"}, ModuleType.Render);
        this.addValues(mode);
        this.setRemoved(true);
    }

    private void Background1(EntityLivingBase target) {
        Gui.drawRect(ScaledResolution.getScaledWidth() / 2 + 20, ScaledResolution.getScaledHeight() / 2 + 45, ScaledResolution.getScaledWidth() / 2 + 140, ScaledResolution.getScaledHeight() / 2 + 85, new Color(0, 0, 0, 180).getRGB());
    }

    private void onHead1() {
        GlStateManager.color(1.0f, 1.0f, 1.0f);
        RenderUtil.drawEntityOnScreen(ScaledResolution.getScaledWidth() / 2 + 35, ScaledResolution.getScaledHeight() / 2 + 80, 15.0f, cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.rotationYaw, cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.rotationPitch, cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
    }

    private void onArmor1(EntityLivingBase target) {
        EntityPlayer player = (EntityPlayer)target;
        ItemStack[] render = player.inventory.armorInventory;
        TargetHUD2.renderItemStack1(render[3], ScaledResolution.getScaledWidth() / 2 + 5 + 45, ScaledResolution.getScaledHeight() / 2 + 60);
        TargetHUD2.renderItemStack1(render[2], ScaledResolution.getScaledWidth() / 2 + 5 + 63, ScaledResolution.getScaledHeight() / 2 + 60);
        TargetHUD2.renderItemStack1(render[1], ScaledResolution.getScaledWidth() / 2 + 5 + 80, ScaledResolution.getScaledHeight() / 2 + 60);
        TargetHUD2.renderItemStack1(render[0], ScaledResolution.getScaledWidth() / 2 + 5 + 98, ScaledResolution.getScaledHeight() / 2 + 60);
    }

    public static void renderItemStack1(ItemStack stack, int x, int y) {
        GlStateManager.pushMatrix();
        GlStateManager.depthMask(true);
        GlStateManager.clear(256);
        RenderHelper.enableStandardItemLighting();
        Minecraft.getMinecraft().getRenderItem().zLevel = -150.0f;
        GlStateManager.disableDepth();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.enableLighting();
        GlStateManager.enableDepth();
        Minecraft.getMinecraft().getRenderItem().renderItemAndEffectIntoGUI(stack, x, y);
        RenderItem renderItem = Minecraft.getMinecraft().getRenderItem();
        Minecraft.getMinecraft();
        renderItem.renderItemOverlays(Minecraft.fontRendererObj, stack, x, y);
        Minecraft.getMinecraft().getRenderItem().zLevel = 0.0f;
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableCull();
        GlStateManager.enableAlpha();
        GlStateManager.disableBlend();
        GlStateManager.disableLighting();
        double s = 0.5;
        GlStateManager.scale(s, s, s);
        GlStateManager.disableDepth();
        GlStateManager.enableDepth();
        GlStateManager.scale(2.0f, 2.0f, 2.0f);
        GlStateManager.popMatrix();
    }

    private void onName1(EntityLivingBase target) {
        Minecraft.fontRendererObj.drawString(target.getName(), ScaledResolution.getScaledWidth() / 2 + 55, ScaledResolution.getScaledHeight() / 2 + 50, -1);
    }

    @Override
    public void onEnable() {
        this.animAlpha = 0;
        this.startAnim = false;
        this.stopAnim = false;
        this.astolfoHelathAnim = 0.0f;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    private int color(int h) {
        if (h >= 15) {
            return new Color(0, 255, 0).getRGB();
        }
        if (h >= 10 && h < 15) {
            return new Color(133, 113, 0).getRGB();
        }
        if (h >= 6 && h < 10) {
            return new Color(174, 86, 0).getRGB();
        }
        if (h < 6) {
            return new Color(255, 0, 0).getRGB();
        }
        return new Color(0, 255, 0).getRGB();
    }

    private void drawFace(EntityLivingBase e, float x, float y) {
        if (e instanceof EntityPlayer) {
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.enableAlpha();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            List var5 = GuiPlayerTabOverlay.field_175252_a.sortedCopy(Minecraft.thePlayer.sendQueue.getPlayerInfoMap());
            for (Object aVar5 : var5) {
                NetworkPlayerInfo var6 = (NetworkPlayerInfo)aVar5;
                if (Minecraft.theWorld.getPlayerEntityByUUID(var6.getGameProfile().getId()) != e) continue;
                mc.getTextureManager().bindTexture(var6.getLocationSkin());
                Gui.drawScaledCustomSizeModalRect(x, y, 8.0f, 8.0f, 8, 8, 36, 36, 64.0f, 64.0f);
                if (((EntityPlayer)e).isWearing(EnumPlayerModelParts.HAT)) {
                    Gui.drawScaledCustomSizeModalRect(x, y, 40.0f, 8.0f, 8, 8, 36, 36, 64.0f, 64.0f);
                }
                GlStateManager.bindTexture(0);
                break;
            }
        }
    }

    private void renderArrmor(ScaledResolution scaledRes, EntityPlayer p, int x, int y) {
        int yOffset = 15;
        int slot = 3;
        int xOffset = 0;
        while (slot >= 0) {
            ItemStack stack = p.inventory.armorItemInSlot(slot);
            GuiIngame gi = new GuiIngame(mc);
            if (stack != null) {
                GL11.glDisable((int)2929);
                mc.getRenderItem().renderItemIntoGUI(stack, x + xOffset, y);
                GL11.glScalef((float)0.5f, (float)0.5f, (float)0.5f);
                Minecraft.fontRendererObj.drawStringWithShadow(String.valueOf(stack.getMaxDamage() - stack.getItemDamage()), (x + 6 + xOffset) * 2, (y + 2) * 2, -1);
                GL11.glScalef((float)2.0f, (float)2.0f, (float)2.0f);
                GL11.glEnable((int)2929);
                xOffset += 18;
            }
            --slot;
        }
    }

    public int getPing(Entity e) {
        if (e != null && e instanceof EntityPlayer && mc.getNetHandler().getPlayerInfo(e.getUniqueID()) != null) {
            return mc.getNetHandler().getPlayerInfo(e.getUniqueID()).getResponseTime();
        }
        return -1;
    }

    public static boolean isContainChinese(String str) {
        Pattern p = Pattern.compile("[\u4e00-\u9fa5]");
        Matcher m = p.matcher(str);
        return m.find();
    }

    private int toPercent(int num, float total) {
        return Math.round((float)num / total * 10000.0f) / 100;
    }

    @EventHandler
    public void onRenderGui(EventRender2D event) {
        ScaledResolution res;
        ScaledResolution res1;
        if (((Enum)mode.getValue()).equals((Object)TargetHudEnum.Flux)) {
            this.FLux();
        }
        if (mode.getValue() == TargetHudEnum.NovolineNew && cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null) {
            Client.instance.getModuleManager();
            KillAura ka = (KillAura)ModuleManager.getModuleByClass(KillAura.class);
            res1 = new ScaledResolution(mc);
            int x = ScaledResolution.getScaledWidth() / 2 + 30;
            int y = ScaledResolution.getScaledHeight() / 2 + 30;
            EntityLivingBase target = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
            if (target != null) {
                double width = Minecraft.fontRendererObj.getStringWidth(target.getName()) > 40 ? 20 + Minecraft.fontRendererObj.getStringWidth(target.getName()) : 50;
                this.healthwidth = width + 18.0;
                this.healthamout = RenderUtil.getAnimationState(this.healthamout, this.healthwidth * (double)target.getHealth() / (double)target.getMaxHealth(), 200.0);
                RenderUtil.rectangleBordered(x, y, (double)(x + 50) + width, y + 30, 1.0, new Color(41, 41, 41).getRGB(), new Color(31, 34, 40).getRGB());
                RenderUtil.rectangleBordered(x + 30, y + 11, (double)(x + 30) + this.healthwidth, y + 15, 0.5, new Color(0, 0, 0, 0).getRGB(), new Color(0, 0, 0).getRGB());
                RenderUtil.rectangle(x + 30, y + 13, (double)(x + 30) + this.healthwidth, y + 20, new Color(90, 90, 90).getRGB());
                RenderUtil.rectangleBordered(x + 30, y + 13, (double)(x + 30) + this.healthamout, y + 20, 0.0, this.color((int)target.getHealth()), new Color(0, 0, 0, 0).getRGB());
                this.drawNormalFace(target, x + 2, y + 2, 26.0f);
                ScaledResolution res2 = new ScaledResolution(mc);
                boolean cfr_ignored_0 = target instanceof EntityPlayer;
                Minecraft.fontRendererObj.drawStringWithShadow(target.getName(), x + 31, y + 4, -1);
            }
        }
        if (mode.getValue() == TargetHudEnum.Chocolate) {
            ScaledResolution sr = new ScaledResolution(mc);
            float scaledWidth = ScaledResolution.getScaledWidth();
            float scaledHeight = ScaledResolution.getScaledHeight();
            CFontRenderer fr = FontLoaders.Comfortaa14;
            if (this.target != null && this.isEnabled()) {
                if (this.target instanceof EntityLivingBase) {
                    if (this.anim > 0.0f) {
                        this.anim -= 5.0f;
                    }
                    float xOffset = Math.max((float)fr.getStringWidth(this.target.getName()) + 35.0f, 100.0f);
                    float x = scaledWidth / 2.0f + 20.0f;
                    float y = scaledHeight / 2.0f + 80.0f + this.anim;
                    float health = this.target.getHealth();
                    double hpPercentage = health / this.target.getMaxHealth();
                    hpPercentage = MathHelper.clamp_double(hpPercentage, 0.0, 1.0);
                    double hpWidth = (double)(xOffset - 35.0f - 8.0f) * hpPercentage;
                    int healthColor = ColorUtils.getHealthColor(this.target.getHealth(), this.target.getMaxHealth()).getRGB();
                    String healthStr = String.valueOf((float)((int)this.target.getHealth()));
                    Gui.drawRect(x, y, x + xOffset, y + 30.0f, new Color(64, 68, 75, 255).getRGB());
                    Gui.drawRect(x + 1.0f, y + 1.0f, x + xOffset - 1.0f, y + 30.0f - 1.0f, new Color(30, 30, 30, 255).getRGB());
                    Gui.drawRect((double)(x + 32.0f) - 0.2, (double)(y + 15.0f) - 0.2, (double)(x + 32.0f) + hpWidth + 0.2, (double)(y + 16.0f) + 0.2, new Color(64, 68, 75, 255).getRGB());
                    RenderUtil.drawGradientSideways(x + 32.0f, y + 15.0f, (double)(x + 32.0f) + hpWidth, y + 16.0f, new Color(255, 120, 255, 255).getRGB(), new Color(120, 120, 255, 255).getRGB());
                    fr.drawStringWithShadow("Health : " + healthStr, x + 32.0f, y + 21.0f, -1);
                    fr.drawStringWithShadow(this.target.getName(), x + 32.0f, y + 7.0f, -1);
                    this.texture = ((AbstractClientPlayer)this.target).getLocationSkin();
                    mc.getTextureManager().bindTexture((ResourceLocation)this.texture);
                    Gui.drawScaledCustomSizeModalRect((int)(x + 6.0f), (int)(y + 6.0f), 8.0f, 8.0f, 8, 8, 18, 18, 64.0f, 64.0f);
                }
            } else {
                this.anim = 100.0f;
                this.target = null;
            }
        }
        if (mode.getValue() == TargetHudEnum.MeMe) {
            ScaledResolution res12 = new ScaledResolution(mc);
            int x = ScaledResolution.getScaledWidth() / 2 + 10;
            int y = ScaledResolution.getScaledHeight() - 100;
            EntityLivingBase player = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
            if (player != null) {
                GlStateManager.pushMatrix();
                AnimotaiX = (float)RenderUtil.getAnimationState(AnimotaiX, 150.0, 2.0);
                BLCRender.drawRect((double)x + 0.0, (double)y + 0.0, (double)x + 125.0, (double)y + 36.0, Colors.getColor(0, 150));
                RenderUtil.drawBorderedRect((float)x - 7.0f, (float)y - 7.0f, (float)x + 132.0f, (float)y + 43.0f, 1.2f, Colors.getColor(0, 150), Colors.getColor(0, 150));
                Minecraft.fontRendererObj.drawStringWithShadow(player.getName(), (float)x + 38.0f, (float)y + 1.0f, -1);
                BigDecimal bigDecimal = new BigDecimal(player.getHealth());
                bigDecimal = bigDecimal.setScale(1, RoundingMode.HALF_UP);
                double HEALTH = bigDecimal.doubleValue();
                BigDecimal DT = new BigDecimal(Minecraft.thePlayer.getDistanceToEntity(player));
                DT = DT.setScale(1, RoundingMode.HALF_UP);
                double Dis = DT.doubleValue();
                float health = player.getHealth();
                float[] fractions = new float[]{0.0f, 0.5f, 1.0f};
                Color[] colors = new Color[]{Color.RED, Color.YELLOW, Color.GREEN};
                float progress = health / player.getMaxHealth();
                Color customColor = health >= 0.0f ? TargetHUD2.blendColors(fractions, colors, progress).brighter() : Color.RED;
                double width = Minecraft.fontRendererObj.getStringWidth(player.getName());
                width = PlayerUtil.getIncremental(width, 10.0);
                if (width < 50.0) {
                    width = 50.0;
                }
                double healthLocation = width * (double)progress;
                AnimotaiSpeed = (float)RenderUtil.getAnimationState(AnimotaiSpeed, healthLocation, 120.0);
                BLCRender.drawRect((double)x + 37.5, (double)y + 11.5, (double)x + 38.0 + (double)AnimotaiSpeed + 0.5, (double)y + 14.5, cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.hurtTime > 5 ? new Color(255, 0, 0).getRGB() : customColor.getRGB());
                BLCRender.rectangleBordered((double)x + 37.0, (double)y + 11.0, (double)x + 39.0 + width, (double)y + 15.0, 0.5, Colors.getColor(0, 0), Colors.getColor(0));
                int i = 1;
                while (i < 10) {
                    double dThing = width / 10.0 * (double)i;
                    BLCRender.drawRect((double)x + 38.0 + dThing, (double)y + 11.0, (double)x + 38.0 + dThing + 0.5, (double)y + 15.0, Colors.getColor(0));
                    ++i;
                }
                String COLOR1 = (double)health > 20.0 ? " \u00a79" : ((double)health >= 10.0 ? " \u00a7a" : ((double)health >= 3.0 ? " \u00a7e" : " \u00a74"));
                int rate = 0;
                BLCRender.rectangleBordered((double)x + 1.0, (double)y + 1.0, (double)x + 35.0, (double)y + 35.0, 0.5, Colors.getColor(0, 0), cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.hurtTime > 5 ? new Color(255, 0, 0).getRGB() : new Color(255, 255, 255).getRGB());
                if (Minecraft.thePlayer.getHealth() > cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth()) {
                    rate += 20;
                }
                if (Minecraft.thePlayer.getTotalArmorValue() > cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getTotalArmorValue()) {
                    rate += 20;
                }
                if (Minecraft.thePlayer.onGround != cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.onGround) {
                    rate += 20;
                }
                String Rate = (double)rate > 90.0 ? " \u00a79" : ((double)rate >= 60.0 ? " \u00a7a" : ((double)rate >= 30.0 ? " \u00a7e" : " \u00a74"));
                if (Minecraft.thePlayer.getHeldItem() != null && Minecraft.thePlayer.getHeldItem().getItem() instanceof ItemSword || Minecraft.thePlayer.isBlocking()) {
                    rate += 20;
                }
                GlStateManager.scale(0.5, 0.5, 0.5);
                String str = "HP: " + COLOR1 + HEALTH + "\u00a7r | Dist: " + Dis;
                Minecraft.fontRendererObj.drawStringWithShadow(str, (float)(x * 2) + 76.0f, (float)(y * 2) + 35.0f, Colors.getColor(255, 0));
                String str2 = String.format("Yaw: %s Pitch: %s BodyYaw: %s", (int)player.rotationYaw, (int)player.rotationPitch, (int)player.renderYawOffset);
                Minecraft.fontRendererObj.drawStringWithShadow(str2, (float)(x * 2) + 76.0f, (float)(y * 2) + 47.0f, Colors.getColor(255, 0));
                String str3 = String.format("G: %s HURT: %s TE: %s", player.onGround, player.hurtTime, player.ticksExisted);
                Minecraft.fontRendererObj.drawStringWithShadow(str3, (float)(x * 2) + 76.0f, (float)(y * 2) + 59.0f, Colors.getColor(255, 0));
                String Win = "Winrate : " + Rate + rate + "%";
                Minecraft.fontRendererObj.drawStringWithShadow(Win, (float)(x * 2) + 80.0f, (float)(y * 2) + 75.0f, Colors.getColor(255, 0));
                GlStateManager.scale(2.0f, 2.0f, 2.0f);
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.enableAlpha();
                GlStateManager.enableBlend();
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                if (player instanceof EntityPlayer) {
                    Minecraft.getMinecraft();
                    List var5 = GuiPlayerTabOverlay.field_175252_a.sortedCopy(Minecraft.thePlayer.sendQueue.getPlayerInfoMap());
                    for (Object aVar5 : var5) {
                        NetworkPlayerInfo var6 = (NetworkPlayerInfo)aVar5;
                        Minecraft.getMinecraft();
                        if (Minecraft.theWorld.getPlayerEntityByUUID(var6.getGameProfile().getId()) != player) continue;
                        Minecraft.getMinecraft();
                        Minecraft.getTextureManager().bindTexture(var6.getLocationSkin());
                        Gui.drawScaledCustomSizeModalRect(x + 2, y + 2, 8.0f, 8.0f, 8, 8, 32, 32, 64.0f, 64.0f);
                        if (((EntityPlayer)player).isWearing(EnumPlayerModelParts.HAT)) {
                            Gui.drawScaledCustomSizeModalRect(x + 2, y + 2, 40.0f, 8.0f, 8, 8, 32, 32, 64.0f, 64.0f);
                        }
                        GlStateManager.bindTexture(0);
                        break;
                    }
                }
                GlStateManager.popMatrix();
            }
        }
        if (mode.getValue() == TargetHudEnum.Autumn) {
            if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null && this.KillAura.isEnabled()) {
                if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget instanceof EntityOtherPlayerMP) {
                    this.target = (EntityOtherPlayerMP)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
                    float width = 140.0f;
                    float height = 40.0f;
                    float xOffset = 40.0f;
                    ScaledResolution res3 = new ScaledResolution(mc);
                    int x = ScaledResolution.getScaledWidth() / 2 + 30;
                    int y = ScaledResolution.getScaledHeight() / 2 + 30;
                    float health = this.target.getHealth();
                    double hpPercentage = health / this.target.getMaxHealth();
                    hpPercentage = MathHelper.clamp_double(hpPercentage, 0.0, 1.0);
                    double hpWidth = 92.0 * hpPercentage;
                    int healthColor = ColorUtils.getHealthColor(this.target.getHealth(), this.target.getMaxHealth()).getRGB();
                    String healthStr = String.valueOf((float)((int)this.target.getHealth()) / 2.0f);
                    if (this.animationStopwatch.elapsed(15L)) {
                        this.healthBarWidth = Animationutils.animate(hpWidth, this.healthBarWidth, 0.353f);
                        this.hudHeight = Animationutils.animate(40.0, this.hudHeight, 0.1f);
                        this.animationStopwatch.reset();
                    }
                    GL11.glEnable((int)3089);
                    RenderUtils.prepareScissorBox(x, y, (float)x + 140.0f, (float)((double)y + this.hudHeight));
                    Gui.drawRect((double)x, (double)y, (float)x + 140.0f, (float)y + 40.0f, COLOR.getRGB());
                    Gui.drawRect((float)x + 40.0f, (float)y + 15.0f, (double)((float)x + 40.0f) + this.healthBarWidth, (float)y + 25.0f, healthColor);
                    Minecraft.fontRendererObj.drawStringWithShadow(healthStr, (float)x + 40.0f + 46.0f - (float)Minecraft.fontRendererObj.getStringWidth(healthStr) / 2.0f, (float)y + 16.0f, -1);
                    Minecraft.fontRendererObj.drawStringWithShadow(this.target.getName(), (float)x + 40.0f, (float)y + 2.0f, -1);
                    GuiInventory.drawEntityOnScreen((int)((float)x + 13.333333f), (int)((float)y + 40.0f), 20, this.target.rotationYaw, this.target.rotationPitch, this.target);
                    GL11.glDisable((int)3089);
                }
            } else {
                this.healthBarWidth = 92.0;
                this.hudHeight = 0.0;
                this.target = null;
            }
        }
        if (mode.getValue() == TargetHudEnum.Normal) {
            FontRenderer font2 = Minecraft.fontRendererObj;
            CFontRenderer font = FontLoaders.Comfortaa16;
            CFontRenderer name = FontLoaders.Comfortaa16;
            CFontRenderer var12 = FontLoaders.Comfortaa40;
            ScaledResolution res4 = new ScaledResolution(mc);
            ScaledResolution sr = new ScaledResolution(mc);
            int y = 2;
            boolean count = false;
            Color color = new Color(1.0f, 0.75f, 0.0f, 0.45f);
            int x1 = 600;
            int y1 = 355;
            int x2 = 750;
            int y2 = ScaledResolution.getScaledHeight() - 50;
            int nametag = y1 + 12;
            int rainbowTick = 0;
            double thickness = 0.015f;
            double xLeft = -20.0;
            Color rainbow = new Color(Color.HSBtoRGB((float)((double)Minecraft.thePlayer.ticksExisted / 50.0 + Math.sin((double)rainbowTick / 50.0 * 1.6)) % 1.0f, 0.5f, 1.0f));
            double xRight = 20.0;
            double yUp = 27.0;
            double yDown = 130.0;
            double size = 10.0;
            boolean bl = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null;
            Client.instance.getModuleManager();
            if (bl & ModuleManager.getModuleByClass(KillAura.class).isEnabled()) {
                new ScaledResolution(mc);
                RenderUtil.drawBorderedRect(0.0f, 0.0f, ScaledResolution.getScaledWidth(), 55.0f, 1.0f, new Color(35, 35, 35, 0).getRGB(), new Color(35, 35, 35, 255).getRGB());
                new ScaledResolution(mc);
                font2.drawString(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getName(), ScaledResolution.getScaledWidth() / 2, 2, 0xFFFFFF);
                new ScaledResolution(mc);
                font.drawString("HP>" + (int)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth() + "/" + (int)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getMaxHealth(), ScaledResolution.getScaledWidth() / 2, 14.0f, 0xFFFFFF);
                new ScaledResolution(mc);
                font.drawString("Hurt>" + (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.hurtTime > 0), ScaledResolution.getScaledWidth() / 2, 22.0f, 0xFFFFFF);
                new ScaledResolution(mc);
                font.drawString("Armor>" + cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getTotalArmorValue(), ScaledResolution.getScaledWidth() / 2, 30.0f, 0xFFFFFF);
                new ScaledResolution(mc);
                font.drawString("Dis>" + (int)Minecraft.thePlayer.getDistanceToEntity(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget), ScaledResolution.getScaledWidth() / 2, 38.0f, 0xFFFFFF);
                new ScaledResolution(mc);
                font.drawString("X>" + (int)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.posX + " " + "Y>" + (int)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.posY + " " + "Z>" + (int)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.posZ, ScaledResolution.getScaledWidth() / 2, 46.0f, 0xFFFFFF);
                if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.isSneaking()) {
                    new ScaledResolution(mc);
                    R3DUtil.drawEntityOnScreen(ScaledResolution.getScaledWidth() / 2 - 30, 45, 25, 0.0f, 9.0f, cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
                } else {
                    new ScaledResolution(mc);
                    R3DUtil.drawEntityOnScreen(ScaledResolution.getScaledWidth() / 2 - 30, 50, 25, 0.0f, 9.0f, cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
                }
                new ScaledResolution(mc);
                RenderUtil.drawBorderedRect(0.0f, 53.0f, ScaledResolution.getScaledWidth(), 55.0f, 1.0f, new Color(255, 255, 255, 0).getRGB(), new Color(255, 255, 255, 255).getRGB());
                new ScaledResolution(mc);
                new ScaledResolution(mc);
                RenderUtil.drawBorderedRect(0.0f, 55.0f, (float)ScaledResolution.getScaledWidth() * Math.min((float)ScaledResolution.getScaledWidth(), cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth() / (float)((int)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getMaxHealth())), 53.0f, 3.0f, new Color(255, 255, 255, 0).getRGB(), rainbow.getRGB());
                if (++rainbowTick > 50) {
                    rainbowTick = 0;
                }
            }
        }
        Client.instance.getModuleManager();
        KillAura k1a = (KillAura)ModuleManager.getModuleByClass(KillAura.class);
        if (mode.getValue() == TargetHudEnum.Lnk) {
            ScaledResolution es = new ScaledResolution(mc);
            if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget == null || !(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget instanceof EntityPlayer)) {
                this.animWidth = 0;
                return;
            }
            int modelWidth = 22;
            int height = 38;
            int width = 2 + Math.max(Minecraft.fontRendererObj.getStringWidth(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getName()) + 2, 85);
            EntityPlayer ent = (EntityPlayer)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
            GlStateManager.pushMatrix();
            GlStateManager.translate((float)(ScaledResolution.getScaledWidth() / 2) + 35.0f, (float)(ScaledResolution.getScaledHeight() / 2) + 55.0f, 0.0f);
            RenderUtils.drawRect(0.0, 0.0, (double)(modelWidth + width), (double)height, new Color(0, 0, 0, 150).getRGB());
            GlStateManager.color(1.0f, 1.0f, 1.0f);
            RenderUtils.drawEntityOnScreen(12, 28, 14, ent);
            Minecraft.fontRendererObj.drawStringWithShadow(ent.getName(), modelWidth, 2.0f, -1);
            double healthLocation = (float)(modelWidth + width - 2) * ent.getHealth() / ent.getMaxHealth();
            if ((double)this.animWidth > healthLocation) {
                this.animWidth = MathUtil.getNextPostion(this.animWidth, (int)healthLocation, 2.0);
            }
            if ((double)this.animWidth < healthLocation) {
                this.animWidth = MathUtil.getNextPostion(this.animWidth, (int)healthLocation, 2.0);
            }
            boolean lineWidth = true;
            RenderUtils.drawRect(2.0, 32.0, (double)(2 + (modelWidth + width - 2) - 2), 36.0, new Color(0, 0, 0, 35).getRGB());
            RenderUtils.drawRect(2.0, 32.0, (double)(2 + this.animWidth - 2), 36.0, Colors.getHealthColor(ent.getHealth(), ent.getMaxHealth()));
            int armorX = 0;
            int rectX = 0;
            int i = 4;
            while (i >= 0) {
                Gui.drawRect(modelWidth + rectX, 2 + Minecraft.fontRendererObj.FONT_HEIGHT + 1 - 1, modelWidth + rectX + 16, 2 + Minecraft.fontRendererObj.FONT_HEIGHT + 1 - 1 + 16, new Color(0, 0, 0, 75).getRGB());
                ItemStack itemStack = ent.getEquipmentInSlot(i);
                if (itemStack != null) {
                    RenderUtils.renderItemStack(itemStack, modelWidth + armorX, 2 + Minecraft.fontRendererObj.FONT_HEIGHT + 1 - 1);
                    GlStateManager.pushMatrix();
                    float scale = 0.5f;
                    GlStateManager.scale(scale, scale, scale);
                    Minecraft.fontRendererObj.drawStringWithShadow(String.valueOf(itemStack.getMaxDamage() - itemStack.getItemDamage()), ((float)(modelWidth + armorX) + (16.0f - (float)Minecraft.fontRendererObj.getStringWidth(String.valueOf(itemStack.getMaxDamage() - itemStack.getItemDamage())) * scale) / 2.0f) / scale, ((float)(2 + Minecraft.fontRendererObj.FONT_HEIGHT + 1 - 1 + 22) - (float)Minecraft.fontRendererObj.FONT_HEIGHT * scale - 2.0f) / scale, -1);
                    GlStateManager.popMatrix();
                    armorX += 17;
                }
                rectX += 17;
                --i;
            }
            GlStateManager.popMatrix();
        }
        if (mode.getValue() == TargetHudEnum.Drug) {
            ArrayList targets = new ArrayList();
            Client.instance.getModuleManager();
            KillAura ka = (KillAura)ModuleManager.getModuleByClass(KillAura.class);
            ScaledResolution res5 = new ScaledResolution(mc);
            int x = ScaledResolution.getScaledWidth() / 2 + 30;
            int y = ScaledResolution.getScaledHeight() / 2 + 30;
            if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null) {
                EntityLivingBase target = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
                double width = Minecraft.fontRendererObj.getStringWidth(target.getName()) > 60 ? 80 + Minecraft.fontRendererObj.getStringWidth(target.getName()) : 125;
                double healthwidth = width - 45.0;
                double maxhealth = healthwidth - 2.0;
                this.healthamout = RenderUtil.getAnimationState(this.healthamout, healthwidth * (double)target.getHealth() / (double)target.getMaxHealth(), 50.0);
                Gui.drawRect((double)x, (double)y, (double)x + width, (double)(y + 40), new Color(0, 0, 0, 180).getRGB());
                Gui.drawRect((double)(x + 40), (double)(y + 14), (double)(x + 40) + maxhealth, (double)(y + 20), this.color((int)target.getHealth()) + new Color(0, 0, 0, 100).getRGB());
                Gui.drawRect((double)(x + 40), (double)(y + 14), (double)(x + 42) + this.healthamout, (double)(y + 20), this.color((int)target.getHealth()));
                Gui.drawRect(x + 40, y + 20, x + 40 + target.getTotalArmorValue() * 3, y + 23, new Color(102, 172, 255).getRGB());
                Minecraft.fontRendererObj.drawStringWithShadow(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getName(), x + 40, y + 4, -1);
                Minecraft.fontRendererObj.drawStringWithShadow((int)target.getHealth() + "\u2764", (float)((double)x + width - (double)Minecraft.fontRendererObj.getStringWidth((int)target.getHealth() + "\u9242\ue619")) - 4.0f, y + 4, this.color((int)target.getHealth()));
                this.drawFace(target, x + 2, y + 2);
                if (target instanceof EntityPlayer) {
                    this.renderArrmor(res5, (EntityPlayer)target, x + 39, y + 23);
                }
            }
        }
        if (mode.getValue() == TargetHudEnum.Entity) {
            res = new ScaledResolution(mc);
            int x = ScaledResolution.getScaledWidth() / 2 + 30;
            int y = ScaledResolution.getScaledHeight() / 2 + 30;
            if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null) {
                this.Background1(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
                this.onArmor1(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
                this.onName1(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
                this.onHead1();
                Client.getModuleManager();
                if (ModuleManager.getModuleByClass(KillAura.class).isEnabled()) {
                    if (!(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget instanceof EntityPlayer)) {
                        return;
                    }
                    EntityLivingBase target1 = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
                    int Custom = new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)).getRGB();
                    if (target1 != this.lastEnt && target1 != null) {
                        this.lastEnt = target1;
                    }
                    if (this.startAnim) {
                        this.stopAnim = false;
                    }
                    if (this.animAlpha == 255 && cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget == null) {
                        this.stopAnim = true;
                    }
                    this.startAnim = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null;
                    if (this.startAnim && this.animAlpha < 255) {
                        this.animAlpha += 15;
                    }
                    if (this.stopAnim && this.animAlpha > 0) {
                        this.animAlpha -= 15;
                    }
                    if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget == null && this.animAlpha < 255) {
                        this.startAnim = false;
                        this.stopAnim = true;
                    }
                    int color = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth() > 10.0f ? RenderUtil.blend(new Color(-16711936), new Color(-256), 1.0f / cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth() / 2.0f * (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth() - 10.0f)).getRGB() : RenderUtil.blend(new Color(-256), new Color(-65536), 0.1f * cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth()).getRGB();
                    EntityLivingBase player = null;
                    if (this.lastEnt != null) {
                        player = this.lastEnt;
                    }
                    if (player != null && this.animAlpha >= 135) {
                        double healthLocation;
                        double Width = 120.0;
                        if (Width < 50.0) {
                            Width = 50.0;
                        }
                        if (this.anima < (healthLocation = Width / 20.0 * (double)((int)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth())) + 1.0) {
                            this.anima += 1.0;
                        }
                        if (this.anima > healthLocation + 1.0) {
                            this.anima -= 1.0;
                        }
                        Gui.drawRect((double)(ScaledResolution.getScaledWidth() / 2 + 20), (double)(ScaledResolution.getScaledHeight() / 2 + 83), (double)(ScaledResolution.getScaledWidth() / 2 + 20) + this.anima, (double)(ScaledResolution.getScaledHeight() / 2 + 85), color);
                    }
                }
            }
        }
        if (mode.getValue() == TargetHudEnum.ExhibitionReload && cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null) {
            res1 = new ScaledResolution(mc);
            int hudX = ScaledResolution.getScaledWidth() / 2 + 30;
            int hudY = ScaledResolution.getScaledHeight() / 2 + 30;
            RenderUtil.drawRect(hudX, hudY + 20, hudX + 110, hudY + 60, Color.BLACK.getRGB());
            RenderUtil.drawRect(hudX + 1, hudY + 20 + 1, hudX + 110 - 1, hudY + 60 - 1, new Color(55, 55, 55).getRGB());
            RenderUtil.drawRect((double)(hudX + 1), (double)hudY + 21.5, (double)(hudX + 108), (double)hudY + 58.5, new Color(30, 30, 30).getRGB());
            RenderUtil.drawRect(hudX + 3, hudY + 20 + 3, hudX + 110 - 3, hudY + 60 - 3, new Color(14, 14, 14).getRGB());
            int x = hudX + 3;
            int y = hudY + 20 + 3;
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GuiInventory.drawEntityOnScreen(x + 15, y + 33, 15, cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.rotationYaw, cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.rotationPitch, cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
            GlStateManager.resetColor();
            FontLoaders.Comfortaa14.drawStringWithShadow("\u00a7l" + cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getName(), (x += 30) + 1, y + 5, -1);
            RenderUtil.drawBorderedRect(x, y + 12, x + 55, y + 16, 0.5f, new Color(40, 40, 40).getRGB(), Color.BLACK.getRGB());
            double hpWidth = 55.0 * MathHelper.clamp_double(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth() / cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getMaxHealth(), 0.0, 1.0);
            RenderUtil.drawRect((double)((float)x + 0.5f), (double)((float)(y + 11) + 0.5f), (double)x + hpWidth - 0.5, (double)((float)(y + 15) - 0.5f), ColorUtils.getBlendColor(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth(), cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getMaxHealth()).getRGB());
            int xOff = 6;
            int i = 0;
            while (i < 8) {
                RenderUtil.drawRect(x + xOff, y + 11, (float)(x + xOff) + 0.5f, y + 15, Color.BLACK.getRGB());
                xOff += 6;
                ++i;
            }
            GlStateManager.pushMatrix();
            GlStateManager.scale(0.5, 0.5, 0.5);
            Minecraft.fontRendererObj.drawStringWithShadow("HP:" + (int)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth() + " | Dist:" + (int)Minecraft.thePlayer.getDistanceToEntity(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget), (x + 1) * 2, (y + 17) * 2, -1);
            GlStateManager.popMatrix();
            if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget instanceof EntityPlayer) {
                EntityPlayer player = (EntityPlayer)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
                int xOffset = 3;
                int slot = 3;
                while (slot >= 0) {
                    ItemStack stack = player.inventory.armorItemInSlot(slot);
                    if (stack != null) {
                        mc.getRenderItem().renderItemIntoGUI(stack, x - xOffset, y + 20);
                        xOffset -= 15;
                    }
                    --slot;
                }
                ItemStack stack = player.inventory.getCurrentItem();
                if (stack != null) {
                    RenderHelper.enableGUIStandardItemLighting();
                    mc.getRenderItem().renderItemIntoGUI(stack, x - xOffset, y + 18);
                    RenderHelper.disableStandardItemLighting();
                }
            }
        }
        if (mode.getValue() == TargetHudEnum.Evelina && cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null) {
            this.Background(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
            this.onName(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
            this.onHead();
            Client.getModuleManager();
            if (ModuleManager.getModuleByClass(KillAura.class).isEnabled()) {
                if (!(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget instanceof EntityPlayer)) {
                    return;
                }
                res = new ScaledResolution(mc);
                EntityLivingBase target1 = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
                int x = ScaledResolution.getScaledWidth() / 2 + 30;
                int y = ScaledResolution.getScaledHeight() / 2 + 30;
                int Custom = new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)).getRGB();
                if (target1 != this.lastEnt && target1 != null) {
                    this.lastEnt = target1;
                }
                if (this.startAnim) {
                    this.stopAnim = false;
                }
                if (this.animAlpha == 255 && cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget == null) {
                    this.stopAnim = true;
                }
                this.startAnim = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null;
                if (this.startAnim && this.animAlpha < 255) {
                    this.animAlpha += 15;
                }
                if (this.stopAnim && this.animAlpha > 0) {
                    this.animAlpha -= 15;
                }
                if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget == null && this.animAlpha < 255) {
                    this.startAnim = false;
                    this.stopAnim = true;
                }
                EntityLivingBase player = null;
                if (this.lastEnt != null) {
                    player = this.lastEnt;
                }
                if (player != null && this.animAlpha >= 135) {
                    double healthLocation;
                    float health = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth();
                    float progress = this.getWidth(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget) / 20;
                    double Width = this.getWidth(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
                    if (Width < 50.0) {
                        Width = 50.0;
                    }
                    if (this.anima < (healthLocation = (double)(this.getWidth(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget) / 20 * (int)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth())) + 1.0) {
                        this.anima += 1.0;
                    }
                    if (this.anima > healthLocation + 1.0) {
                        this.anima -= 1.0;
                    }
                    Gui.drawRect((double)(ScaledResolution.getScaledWidth() / 2 + 20), (double)(ScaledResolution.getScaledHeight() / 2 + 28), (double)(ScaledResolution.getScaledWidth() / 2 + 20) + this.anima, (double)(ScaledResolution.getScaledHeight() / 2 + 30), -1);
                }
            }
        }
    }

    private void Background(EntityLivingBase target) {
        Gui.drawRect(ScaledResolution.getScaledWidth() / 2 + 20, ScaledResolution.getScaledHeight() / 2 + 28, ScaledResolution.getScaledWidth() / 2 + 20 + this.getWidth(target), ScaledResolution.getScaledHeight() / 2 + 30, new Color(0, 0, 0, 220).getRGB());
        Gui.drawRect(ScaledResolution.getScaledWidth() / 2 + 20, ScaledResolution.getScaledHeight() / 2, ScaledResolution.getScaledWidth() / 2 + 20 + 38 + this.font.getStringWidth(target.getName()), ScaledResolution.getScaledHeight() / 2 + 28, new Color(0, 0, 0, 200).getRGB());
    }

    private int getWidth(EntityLivingBase target) {
        return 38 + this.font.getStringWidth(target.getName());
    }

    private void onHead() {
        mc.getTextureManager().bindTexture(((AbstractClientPlayer)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget).getLocationSkin());
        Gui.drawScaledCustomSizeModalRect(ScaledResolution.getScaledWidth() / 2 + 20, ScaledResolution.getScaledHeight() / 2, 8.0f, 8.0f, 8, 8, 28, 28, 64.0f, 64.0f);
    }

    private void drawNormalFace(EntityLivingBase e, float x, float y, float scale) {
        if (e instanceof EntityPlayer) {
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.enableAlpha();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            List var5 = GuiPlayerTabOverlay.field_175252_a.sortedCopy(Minecraft.thePlayer.sendQueue.getPlayerInfoMap());
            for (Object aVar5 : var5) {
                NetworkPlayerInfo var6 = (NetworkPlayerInfo)aVar5;
                if (Minecraft.theWorld.getPlayerEntityByUUID(var6.getGameProfile().getId()) != e) continue;
                mc.getTextureManager().bindTexture(var6.getLocationSkin());
                Gui.drawScaledCustomSizeModalRect(x, y, 8.0f, 8.0f, 8, 8, (int)scale, (int)scale, 64.0f, 64.0f);
                if (((EntityPlayer)e).isWearing(EnumPlayerModelParts.HAT)) {
                    Gui.drawScaledCustomSizeModalRect(x, y, 40.0f, 8.0f, 8, 8, (int)scale, (int)scale, 64.0f, 64.0f);
                }
                GlStateManager.bindTexture(0);
                break;
            }
        }
    }

    public static void drawEntityOnScreen(int p_147046_0_, int p_147046_1_, int p_147046_2_, float p_147046_3_, float p_147046_4_, EntityLivingBase p_147046_5_) {
        GlStateManager.enableColorMaterial();
        GlStateManager.pushMatrix();
        GlStateManager.translate(p_147046_0_, p_147046_1_, 40.0f);
        GlStateManager.scale(-p_147046_2_, p_147046_2_, p_147046_2_);
        GlStateManager.rotate(180.0f, 0.0f, 0.0f, 1.0f);
        float var6 = p_147046_5_.renderYawOffset;
        float var7 = p_147046_5_.rotationYaw;
        float var8 = p_147046_5_.rotationPitch;
        float var9 = p_147046_5_.prevRotationYawHead;
        float var10 = p_147046_5_.rotationYawHead;
        RenderHelper.enableStandardItemLighting();
        GlStateManager.rotate(p_147046_5_.rotationYaw, 0.0f, 1.0f, 0.0f);
        p_147046_5_.renderYawOffset = (float)Math.atan(p_147046_3_ / 40.0f) * -14.0f;
        p_147046_5_.rotationYaw = (float)Math.atan(p_147046_3_ / 40.0f) * -14.0f;
        p_147046_5_.rotationPitch = -((float)Math.atan(p_147046_4_ / 40.0f)) * 15.0f;
        p_147046_5_.rotationYawHead = p_147046_5_.rotationYaw;
        p_147046_5_.prevRotationYawHead = p_147046_5_.rotationYaw;
        GlStateManager.translate(0.0f, 0.0f, 0.0f);
        RenderManager var11 = Minecraft.getMinecraft().getRenderManager();
        var11.setPlayerViewY(180.0f);
        var11.setRenderShadow(false);
        var11.renderEntityWithPosYaw(p_147046_5_, 0.0, 0.0, 0.0, 0.0f, 1.0f);
        var11.setRenderShadow(true);
        p_147046_5_.renderYawOffset = var6;
        p_147046_5_.rotationYaw = var7;
        p_147046_5_.rotationPitch = var8;
        p_147046_5_.prevRotationYawHead = var9;
        p_147046_5_.rotationYawHead = var10;
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
        GlStateManager.disableTexture2D();
        GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    }

    private void onName(EntityLivingBase target) {
        this.font.drawString(target.getName(), ScaledResolution.getScaledWidth() / 2 + 50, ScaledResolution.getScaledHeight() / 2 + 4, -1);
        this.font.drawString("HP:" + (int)target.getHealth(), ScaledResolution.getScaledWidth() / 2 + 50, ScaledResolution.getScaledHeight() / 2 + 4 + this.font.getStringHeight("") + 2, -1);
    }

    /*
     * Unable to fully structure code
     */
    @EventHandler
    public void onScreenDraw(EventRender2D render) {
        block111: {
            block113: {
                block112: {
                    res = new ScaledResolution(TargetHUD2.mc);
                    target1 = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
                    x = ScaledResolution.getScaledWidth() / 2 + 30;
                    y = ScaledResolution.getScaledHeight() / 2 + 30;
                    Custom = new Color(TargetHUD2.random.nextInt(255), TargetHUD2.random.nextInt(255), TargetHUD2.random.nextInt(255)).getRGB();
                    if (target1 != this.lastEnt && target1 != null) {
                        this.lastEnt = target1;
                    }
                    if (this.startAnim) {
                        this.stopAnim = false;
                    }
                    if (this.animAlpha == 255 && cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget == null) {
                        this.stopAnim = true;
                    }
                    this.startAnim = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null;
                    if (this.startAnim) {
                        this.anim = AnimationUtil.mvoeUD(this.anim, 0.0f, 0.09f);
                        if (this.animAlpha < 255) {
                            this.animAlpha += 15;
                        }
                    }
                    if (this.stopAnim) {
                        this.anim = AnimationUtil.mvoeUD(this.anim, 75.0f, 0.09f);
                        if (this.animAlpha > 0) {
                            this.animAlpha -= 15;
                        }
                    }
                    if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget == null && this.animAlpha < 255) {
                        this.startAnim = false;
                        this.stopAnim = true;
                    }
                    player = null;
                    if (TargetHUD2.mode.getValue() == TargetHudEnum.Client) {
                        if (this.lastEnt != null) {
                            player = this.lastEnt;
                        }
                    } else {
                        player = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
                    }
                    if (TargetHUD2.mode.getValue() == TargetHudEnum.New) {
                        Client.instance.getModuleManager();
                        ka = (KillAura)ModuleManager.getModuleByClass(KillAura.class);
                        target = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
                        if (target != null) {
                            width = Minecraft.fontRendererObj.getStringWidth(target.getName()) > 40 ? 20 + Minecraft.fontRendererObj.getStringWidth(target.getName()) : 50;
                            this.healthwidth = width + 18.0;
                            this.healthamout = this.healthwidth * (double)target.getHealth() / (double)target.getMaxHealth();
                            RenderUtil.rectangleBordered(x, y, (double)(x + 50) + width, y + 30, 1.0, new Color(40, 44, 50, 230).getRGB(), new Color(31, 34, 40, 230).getRGB());
                            RenderUtil.rectangleBordered(x + 29, y + 11, (double)(x + 29) + this.healthwidth, y + 15, 0.5, new Color(0, 0, 0, 0).getRGB(), new Color(0, 0, 0).getRGB());
                            RenderUtil.rectangleBordered(x + 29, y + 11, (double)(x + 29) + this.healthamout, y + 15, 0.5, this.color((int)target.getHealth()), new Color(0, 0, 0).getRGB());
                            RenderUtil.rectangleBordered((double)x + 1.5, (double)y + 1.5, (double)x + 28.5, (double)y + 28.5, 0.5, new Color(40, 44, 50, 230).getRGB(), target.hurtTime > 15 ? new Color(255, 0, 0).getRGB() : new Color(0, 255, 0).getRGB());
                            i = 1;
                            while (i < 9) {
                                space = this.healthwidth / 9.0 * (double)i;
                                RenderUtil.rectangle((double)(x + 29) + space, y + 11, (double)x + 29.5 + space, y + 15, new Color(0, 0, 0).getRGB());
                                ++i;
                            }
                            this.drawNormalFace(target, x + 2, y + 2, 26.0f);
                            if (target instanceof EntityPlayer) {
                                this.renderArrmor(res, (EntityPlayer)target, x + 26, y + 14);
                            }
                            Minecraft.fontRendererObj.drawStringWithShadow(target.getName(), x + 31, y + 2, -1);
                        }
                    }
                    if (TargetHUD2.mode.getValue() == TargetHudEnum.Simple) {
                        Client.instance.getModuleManager();
                        ka = (KillAura)ModuleManager.getModuleByClass(KillAura.class);
                        target = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
                        if (target != null) {
                            width = Minecraft.fontRendererObj.getStringWidth(target.getName()) > 60 ? 120 + Minecraft.fontRendererObj.getStringWidth(target.getName()) : 165;
                            this.healthwidth = width - 3.0;
                            this.maxhealth1 = RenderUtil.getAnimationState(this.maxhealth, this.healthwidth * (double)target.getHealth() / (double)target.getMaxHealth(), this.healthamout < this.healthwidth * (double)target.getHealth() / (double)target.getMaxHealth() ? 150 : 50);
                            this.healthamout = RenderUtil.getAnimationState(this.healthamout, this.healthwidth * (double)target.getHealth() / (double)target.getMaxHealth(), 150.0);
                            Gui.drawRect((double)x, (double)y, (double)x + width - 3.0, (double)(y + 50), new Color(0, 0, 0, 180).getRGB());
                            Gui.drawRect((double)x, (double)(y + 48), (double)x + width - 3.0, (double)(y + 50), new Color(0, 0, 0, 180).getRGB());
                            Gui.drawRect((double)x, (double)(y + 48), (float)x + this.maxhealth, (double)(y + 50), this.color((int)target.getHealth()) + new Color(0, 0, 0, 100).getRGB());
                            Gui.drawRect((double)x, (double)(y + 48), (double)x + this.healthamout, (double)(y + 50), this.color((int)target.getHealth()));
                            Minecraft.fontRendererObj.drawStringWithShadow(target.getName(), x + 8, y + 8, -1);
                            Minecraft.fontRendererObj.drawStringWithShadow(target.getHeldItem().getDisplayName(), (float)((double)x + width - 8.0 - (double)Minecraft.fontRendererObj.getStringWidth(target.getHeldItem().getDisplayName())), y + 8, new Color(180, 180, 180).getRGB());
                            GlStateManager.pushMatrix();
                            GlStateManager.scale(2.0, 2.0, 2.0);
                            Minecraft.fontRendererObj.drawStringWithShadow(String.valueOf(String.valueOf(target.getHealth()).substring(0, target.getHealth() > 10.0f ? 4 : 3)) + " HP", (x + 8) / 2, (y + 23) / 2, this.color((int)target.getHealth()));
                            GlStateManager.scale(1.0, 1.0, 1.0);
                            GlStateManager.popMatrix();
                        }
                    }
                    if (TargetHUD2.mode.getValue() == TargetHudEnum.Exhibition) {
                        entity = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
                        scaledRes = new ScaledResolution(TargetHUD2.mc);
                        width = ScaledResolution.getScaledWidth();
                        height = ScaledResolution.getScaledHeight();
                        if (entity instanceof EntityLivingBase) {
                            if (entity == null) {
                                this.healthLocationani = 70.0;
                            }
                            if (entity != null && !entity.isDead) {
                                if (Minecraft.thePlayer.getDistanceToEntity(entity) < 8.0f) {
                                    h1 = TargetHUD2.hue;
                                    h2 = TargetHUD2.hue + 85.0f;
                                    h3 = TargetHUD2.hue + 170.0f;
                                    color33 = Color.getHSBColor(h1 / 255.0f, 0.9f, 1.0f);
                                    color332 = Color.getHSBColor(h2 / 255.0f, 0.9f, 1.0f);
                                    color333 = Color.getHSBColor(h3 / 255.0f, 0.9f, 1.0f);
                                    GlStateManager.pushMatrix();
                                    GlStateManager.translate(width / 2.0f + 10.0f, height - 180.0f, 0.0f);
                                    RenderUtil.drawBorderedRect(-0.0f, -5.0f, 126.0f, 38.0f, 3.0f, new Color(140, 140, 140, 200).getRGB(), new Color(0, 0, 0, 0).getRGB());
                                    RenderUtil.Gamesense(-5.0, -5.0, 125.0, 37.0, 1.0, color33.getRGB(), color332.getRGB(), color333.getRGB(), 0);
                                    Minecraft.fontRendererObj.drawStringWithShadow(entity.getName(), 37.5f, 2.0f, -1);
                                    health = entity.getHealth();
                                    fractions = new float[]{0.0f, 0.5f, 1.0f};
                                    colors = new Color[]{new Color(255, 19, 19), new Color(255, 223, 5), new Color(0, 141, 0)};
                                    progress = health / entity.getMaxHealth();
                                    blend = TargetHUD2.blendColors(fractions, colors, progress).brighter();
                                    customColor = entity.hurtTime > 5 ? blend : blend;
                                    width1 = 70.0;
                                    width1 = this.getIncremental(width1, 10.0);
                                    if (width1 < 50.0) {
                                        width1 = 50.0;
                                    }
                                    healthLocation = width1 * (double)progress;
                                    this.healthLocationani = Animationutils.animate(healthLocation, this.healthLocationani, 0.075);
                                    RenderUtil.rectangle(36.5, 12.3, 38.0 + width1 + 1.5, 24.0, new Color(25, 25, 25).getRGB());
                                    RenderUtil.rectangle(37.5, 13.5, 38.0 + this.healthLocationani + 0.5, 23.0, customColor.darker().getRGB());
                                    RenderUtil.rectangle(37.5, 13.5, 38.0 + healthLocation + 0.5, 23.0, customColor.getRGB());
                                    GlStateManager.scale(0.5, 0.5, 0.5);
                                    dist = Minecraft.thePlayer.getDistanceToEntity(entity);
                                    str = "XYZ: " + (int)entity.posX + " " + (int)entity.posY + " " + (int)entity.posZ + " | HP: " + (int)health;
                                    FontLoaders.GoogleSans22.drawStringWithShadow(str, 76.0, 56.0, -1);
                                    GlStateManager.scale(2.0f, 2.0f, 2.0f);
                                    GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                                    GlStateManager.enableAlpha();
                                    GlStateManager.enableBlend();
                                    GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                                    TargetHUD2.mc.getRenderItem().zLevel = -147.0f;
                                    for (E xD : GuiPlayerTabOverlay.field_175252_a.sortedCopy(Minecraft.thePlayer.sendQueue.getPlayerInfoMap())) {
                                        var6 = (NetworkPlayerInfo)xD;
                                        if (Minecraft.theWorld.getPlayerEntityByUUID(var6.getGameProfile().getId()) != entity) continue;
                                        TargetHUD2.mc.getTextureManager().bindTexture(var6.getLocationSkin());
                                        Gui.drawScaledCustomSizeModalRect(0, 0, 8.0f, 8.0f, 8, 8, 34, 34, 64.0f, 64.0f);
                                        GlStateManager.bindTexture(0);
                                        break;
                                    }
                                    GlStateManager.popMatrix();
                                }
                            }
                        }
                    }
                    if (TargetHUD2.mode.getValue() == TargetHudEnum.Client && player != null && this.animAlpha >= 135) {
                        GlStateManager.pushMatrix();
                        GlStateManager.translate(this.anim, 0.0f, 0.0f);
                        RenderUtil.drawBorderedRect((float)x + 33.0f, (float)y + 0.0f, (float)x + 130.0f, (float)y + 36.0f, 2.0f, new Color(0, 0, 0, 0).getRGB(), new Color(0, 0, 0, 150).getRGB());
                        Minecraft.fontRendererObj.drawStringWithShadow(player.getName(), (float)x + 38.0f, (float)y + 3.0f, -1);
                        bigDecimal = new BigDecimal(player.getHealth());
                        bigDecimal = bigDecimal.setScale(1, RoundingMode.HALF_UP);
                        HEALTH = bigDecimal.doubleValue();
                        DT = new BigDecimal(Minecraft.thePlayer.getDistanceToEntity(player));
                        DT = DT.setScale(1, RoundingMode.HALF_UP);
                        Dis = DT.doubleValue();
                        Food = Minecraft.thePlayer.getFoodStats().getFoodLevel();
                        Armor = Minecraft.thePlayer.getTotalArmorValue();
                        health = player.getHealth();
                        fractions = new float[]{0.0f, 0.5f, 1.0f};
                        colors = new Color[]{Color.RED, Color.green, Color.GREEN};
                        progress = health / player.getMaxHealth();
                        customColor = health >= 0.0f ? TargetHUD2.blendColors(fractions, colors, progress).brighter() : Color.RED;
                        width = Minecraft.fontRendererObj.getStringWidth(player.getName());
                        width = this.getIncremental(width, 10.0);
                        if (width < 50.0) {
                            width = 50.0;
                        }
                        if (this.anima < (healthLocation = width * (double)progress) + 1.0) {
                            this.anima += 1.0;
                        }
                        if (this.anima > healthLocation + 1.0) {
                            this.anima -= 1.0;
                        }
                        RenderUtil.drawGradientSideways((double)x + 37.5, (double)y + 13.5, (double)x + 37.5 + this.anima, (double)y + 15.5, new Color(0, 20, 0).getRGB(), new Color(Custom).getRGB());
                        RenderUtil.rectangleBordered((double)x + 37.0, (double)y + 13.5, (double)x + 39.0 + width, (double)y + 15.5, 0.5, Colors.getColor(0, 0), new Color(0, 0, 0).getRGB());
                        i = 1;
                        while (i < 10) {
                            dist = width / 10.0 * (double)i;
                            ++i;
                        }
                        COLOR1 = (double)health > 20.0 ? " \u00a79" : ((double)health >= 10.0 ? " \u00a7a" : ((double)health >= 3.0 ? " \u00a7e" : " \u00a74"));
                        GlStateManager.scale(0.5f, 0.5f, 0.5f);
                        str = "Dist >> \u00a76" + Dis + " \u00a7 HP >> \u00a72" + health;
                        Minecraft.fontRendererObj.drawStringWithShadow(str, (float)(x * 2) + 76.0f, (float)(y * 2) + 40.0f, new Color(255, 255, 255).getRGB());
                        str2 = String.format("Yaw >> \u00a75%s", new Object[]{String.valueOf((int)player.rotationYaw) + " \u00a7 Armor >>\u00a73 " + Armor});
                        Minecraft.fontRendererObj.drawStringWithShadow(str2, (float)(x * 2) + 76.0f, (float)(y * 2) + 55.0f, new Color(255, 255, 255).getRGB());
                        GlStateManager.popMatrix();
                    }
                    if (TargetHUD2.mode.getValue() != TargetHudEnum.AzureWare) break block111;
                    target = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
                    res1 = new ScaledResolution(TargetHUD2.mc);
                    font1 = FontLoaders.Comfortaa20;
                    Y = ScaledResolution.getScaledHeight();
                    X = (float)ScaledResolution.getScaledWidth() / 1.8f;
                    Text = "Do not have target";
                    TextLength = font1.getStringWidth(Text);
                    MaxHealth = 0.0f;
                    Health = 0.0f;
                    AbsorptionAmount = 0.0f;
                    if (target != null) {
                        Y = (float)ScaledResolution.getScaledHeight() / 1.8f;
                        Text = target.getName();
                        TextLength = font1.getStringWidth(Text);
                        MaxHealth = (int)target.getMaxHealth();
                        Health = (int)target.getHealth();
                        AbsorptionAmount = (int)target.getAbsorptionAmount();
                    }
                    if (this.curY > Y) {
                        this.curY -= 2.0f;
                        if (this.curY < Y) {
                            this.curY += 1.0f;
                        }
                    }
                    if (this.curY < Y) {
                        this.curY += 2.0f;
                        if (this.curY > Y) {
                            this.curY -= 1.0f;
                        }
                    }
                    if (this.curHealthX > Health) {
                        this.curHealthX = (float)((double)this.curHealthX - 0.2);
                    }
                    if (this.curHealthX < Health) {
                        this.curHealthX = (float)((double)this.curHealthX + 0.2);
                    }
                    if (this.curAbsorptionAmountX > AbsorptionAmount) {
                        this.curAbsorptionAmountX = (float)((double)this.curAbsorptionAmountX - 0.2);
                    }
                    if (this.curAbsorptionAmountX < AbsorptionAmount) {
                        this.curAbsorptionAmountX = (float)((double)this.curAbsorptionAmountX + 0.2);
                    }
                    nextX = 28;
                    nextX = (float)TextLength > (MaxHealth + AbsorptionAmount) * 5.0f ? (TextLength > 160 ? (nextX += TextLength) : (nextX += 160)) : ((MaxHealth + AbsorptionAmount) * 5.0f > 160.0f ? (int)((float)nextX + (MaxHealth + AbsorptionAmount) * 5.0f) : (nextX += 160));
                    RenderUtil.drawImage(new ResourceLocation("ZenithAssets/background.png"), (int)X, (int)this.curY, nextX, 100);
                    RenderUtil.drawImage(new ResourceLocation("ZenithAssets/Head.png"), (int)X + 4, (int)this.curY + 4, 20, 20);
                    font1.drawString(Text, X + 20.0f + 4.0f, this.curY + 7.0f, new Color(255, 255, 255, 255).getRGB());
                    RenderUtil.drawImage(new ResourceLocation("ZenithAssets/Heart.png"), (int)X + 6, (int)this.curY + 6 + 20, 16, 16);
                    color1 = new Color(250 - (int)(this.curHealthX / MaxHealth * 10.0f * 25.0f), 0 + (int)(this.curHealthX / MaxHealth * 10.0f * 25.0f), 0, 255).getRGB();
                    if (this.curHealthX > 0.5f) {
                        RenderUtil.drawFastRoundedRect(X + 20.0f + 4.0f, this.curY + 20.0f + 9.0f, X + 20.0f + 4.0f + this.curHealthX * 5.0f, this.curY + 20.0f + 8.0f + 10.0f, 2.0f, color1);
                    } else if (Health < 0.5f && Health != 0.0f) {
                        this.curHealthX = 0.0f;
                    }
                    if (this.curAbsorptionAmountX > 0.5f) {
                        RenderUtil.drawRect(X + 20.0f + 4.0f + this.curHealthX * 5.0f, this.curY + 20.0f + 9.0f, X + 20.0f + 4.0f + this.curHealthX * 5.0f - 4.0f, this.curY + 20.0f + 8.0f + 10.0f, color1);
                        RenderUtil.drawRect(X + 20.0f + 4.0f + this.curHealthX * 5.0f, this.curY + 20.0f + 9.0f, X + 20.0f + 4.0f + this.curHealthX * 5.0f + 4.0f, this.curY + 20.0f + 8.0f + 10.0f, new Color(255, 225, 100, 255).getRGB());
                        RenderUtil.drawFastRoundedRect(X + 20.0f + 4.0f + this.curHealthX * 5.0f, this.curY + 20.0f + 9.0f, X + 20.0f + 4.0f + (this.curHealthX + this.curAbsorptionAmountX) * 5.0f, this.curY + 20.0f + 8.0f + 10.0f, 2.0f, new Color(255, 225, 100, 255).getRGB());
                    } else if (AbsorptionAmount < 0.5f && AbsorptionAmount != 0.0f) {
                        this.curAbsorptionAmountX = 0.0f;
                    }
                    RenderUtil.drawRect((int)X + 6, (int)this.curY + 4 + 20 + 20 + 3, (int)X + nextX - 6, (int)this.curY + 4 + 20 + 20 + 4, new Color(255, 255, 255, 160).getRGB());
                    RenderUtil.drawImage(new ResourceLocation("ZenithAssets/Half_Heart.png"), (int)X + 6, (int)this.curY + 6 + 20 + 20 + 7, 16, 16);
                    if (!this.Crit) break block112;
                    var24 = "Criticals";
                    break block113;
                }
                var10000 = TargetHUD2.mc;
                if (Minecraft.thePlayer.onGround) ** GOTO lbl-1000
                var10000 = TargetHUD2.mc;
                if (Minecraft.thePlayer.fallDistance > 0.0f) {
                    var24 = "Criticals";
                } else lbl-1000:
                // 2 sources

                {
                    var24 = "Normal";
                }
            }
            Text = var24;
            font1.getStringWidth(Text);
            color1 = Text == "Normal" ? Color.GREEN.getRGB() : Color.ORANGE.getRGB();
            font1.drawString(Text, (int)X + 6 + 20, (int)this.curY + 6 + 20 + 20 + 7, color1);
            RenderUtil.drawImage(new ResourceLocation("ZenithAssets/Sword.png"), (int)X + 4, (int)this.curY + 4 + 20 + 20 + 20 + 7, 20, 20);
            color1 = Color.GREEN.getRGB();
            LoseOrWin = "Finding Player...";
            SelfScore = 0;
            TargetScore = 0;
            if (target instanceof EntityPlayer) {
                entity = (EntityPlayer)target;
                var20 = entity.inventory.armorInventory;
                var19 = entity.inventory.armorInventory.length;
                var18 = 0;
                while (var18 < var19) {
                    armourStack = var20[var18];
                    if (armourStack != null) {
                        renderStack1 = armourStack.copy();
                        if (Item.getIdFromItem(renderStack1.getItem()) == 298) {
                            ++TargetScore;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 299) {
                            ++TargetScore;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 300) {
                            ++TargetScore;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 301) {
                            ++TargetScore;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 302) {
                            TargetScore += 3;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 303) {
                            TargetScore += 3;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 304) {
                            TargetScore += 3;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 305) {
                            TargetScore += 3;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 306) {
                            TargetScore += 4;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 307) {
                            TargetScore += 4;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 308) {
                            TargetScore += 4;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 309) {
                            TargetScore += 4;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 310) {
                            TargetScore += 5;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 311) {
                            TargetScore += 5;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 312) {
                            TargetScore += 5;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 313) {
                            TargetScore += 5;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 314) {
                            TargetScore += 2;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 315) {
                            TargetScore += 2;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 316) {
                            TargetScore += 2;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 317) {
                            TargetScore += 2;
                        }
                    }
                    ++var18;
                }
                if (entity.getHeldItem() != null) {
                    TargetScore += entity.getHeldItem().getMaxDamage();
                }
                TargetScore = (int)((float)TargetScore + entity.getHealth());
                TargetScore += entity.isBlocking() != false ? 1 : 0;
                TargetScore += entity.onGround == false && entity.fallDistance > 0.0f ? 1 : 0;
            }
            if (target instanceof EntityPlayer) {
                var10000 = TargetHUD2.mc;
                entity = Minecraft.thePlayer;
                var20 = entity.inventory.armorInventory;
                var19 = entity.inventory.armorInventory.length;
                var18 = 0;
                while (var18 < var19) {
                    armourStack = var20[var18];
                    if (armourStack != null) {
                        renderStack1 = armourStack.copy();
                        if (Item.getIdFromItem(renderStack1.getItem()) == 298) {
                            ++SelfScore;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 299) {
                            ++SelfScore;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 300) {
                            ++SelfScore;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 301) {
                            ++SelfScore;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 302) {
                            SelfScore += 3;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 303) {
                            SelfScore += 3;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 304) {
                            SelfScore += 3;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 305) {
                            SelfScore += 3;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 306) {
                            SelfScore += 4;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 307) {
                            SelfScore += 4;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 308) {
                            SelfScore += 4;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 309) {
                            SelfScore += 4;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 310) {
                            SelfScore += 5;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 311) {
                            SelfScore += 5;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 312) {
                            SelfScore += 5;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 313) {
                            SelfScore += 5;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 314) {
                            SelfScore += 2;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 315) {
                            SelfScore += 2;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 316) {
                            SelfScore += 2;
                        }
                        if (Item.getIdFromItem(renderStack1.getItem()) == 317) {
                            SelfScore += 2;
                        }
                    }
                    ++var18;
                }
                if (entity.getHeldItem() != null) {
                    SelfScore += entity.getHeldItem().getMaxDamage();
                }
                SelfScore = (int)((float)SelfScore + entity.getHealth());
                SelfScore += entity.isBlocking() != false ? 1 : 0;
                SelfScore += entity.onGround == false && entity.fallDistance > 0.0f ? 1 : 0;
            }
            if (SelfScore > TargetScore) {
                color1 = Color.GREEN.getRGB();
                LoseOrWin = "I think you will win.";
            }
            if (SelfScore < TargetScore) {
                LoseOrWin = "I think you will lose.";
                color1 = Color.RED.getRGB();
            }
            if (SelfScore - TargetScore < 2 && SelfScore - TargetScore > -2) {
                LoseOrWin = "WTF? I DONT THINK ANY.";
                color1 = Color.YELLOW.getRGB();
            }
            font1.getStringWidth(LoseOrWin);
            font1.drawString(LoseOrWin, (int)X + 6 + 20, (int)this.curY + 6 + 20 + 20 + 20 + 10, color1);
        }
        if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null && TargetHUD2.mode.getValue() == TargetHudEnum.AstolfoNew) {
            addY = 0;
            Color4243 = Color.getHSBColor(TargetHUD2.hue / 255.0f, 0.55f, 0.9f);
            asrainbow53 = TargetHUD2.getAstolfoRainbow((addY + 11) / 11).getRGB();
            target = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
            height = ScaledResolution.getScaledWidth() / 2 - 220;
            width = ScaledResolution.getScaledHeight() / 2 - 130;
            health = this.getHealthes(target);
            n18 = 125.0f * (health / target.getMaxHealth());
            this.Animation = RenderUtil.getAnimationState(this.Animation, n18, 135.0);
            GlStateManager.pushMatrix();
            GlStateManager.translate(ScaledResolution.getScaledWidth() / 2 + width, ScaledResolution.getScaledHeight() - height, 0.0f);
            GlStateManager.color(1.0f, 1.0f, 1.0f);
            if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget instanceof EntityPlayer) {
                GuiInventory.drawEntityOnScreen(-18, 47, 30, -180.0f, 0.0f, target);
            } else {
                GuiInventory.drawEntityOnScreen(-20, 50, 30, -180.0f, 0.0f, target);
            }
            Gui.drawRect(-38.0, -14.0, 133.0, 52.0, Colors.getColor(0, 0, 0, 180));
            Minecraft.fontRendererObj.drawStringWithShadow(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getName(), 0.0f, -8.0f, new Color(255, 255, 255).getRGB());
            Gui.drawRect(0.0, 8.0f + (float)Math.round(40.0f), 130.0, 40.0, asrainbow53);
            if ((double)(target.getHealth() / 2.0f + target.getAbsorptionAmount() / 2.0f) > 1.0) {
                Gui.drawRect(0.0, 8.0f + (float)Math.round(40.0f), this.Animation + 5.0, 40.0, asrainbow53);
            }
            Gui.drawRect(0.0, 8.0f + (float)Math.round(40.0f), this.Animation + 5.0, 40.0, asrainbow53);
            GlStateManager.scale(3.0f, 3.0f, 3.0f);
            Minecraft.fontRendererObj.drawStringWithShadow(String.valueOf(this.getHealthes(target)) + " \u2764", 0.0f, 2.5f, asrainbow53);
            GlStateManager.popMatrix();
        }
        if (TargetHUD2.mode.getValue() == TargetHudEnum.Astolfo && player != null) {
            RenderUtil.pre();
            GlStateManager.pushMatrix();
            Gui.drawRect((float)x + 0.7f, (double)y, (float)x + 149.7f, (double)(y + 60), new Color(0, 0, 0, 110).getRGB());
            health = player.getHealth();
            fractions = new float[]{0.0f, 0.2f, 0.7f};
            colors = new Color[]{Color.RED, Color.YELLOW, Color.GREEN};
            progress = health / player.getMaxHealth();
            customColor = health >= 0.0f ? TargetHUD2.blendColors(fractions, colors, progress).brighter() : Color.RED;
            customColor = customColor.darker();
            Minecraft.fontRendererObj.drawStringWithShadow(player.getName(), x + 37, y + 8, -1);
            GlStateManager.scale(1.5f, 1.5f, 1.5f);
            Minecraft.fontRendererObj.drawStringWithShadow(String.valueOf((int)player.getHealth()) + "\u2764", (float)(x + 37) / 1.5f, (float)(y + 20) / 1.5f, customColor.getRGB());
            wdnmd = 150.0;
            health2 = player.getHealth() / player.getMaxHealth();
            if ((double)this.astolfoHelathAnim < wdnmd * (double)v0) {
                if (wdnmd * (double)health2 - (double)this.astolfoHelathAnim < 1.0) {
                    this.astolfoHelathAnim = (float)(wdnmd * (double)health2);
                }
                this.astolfoHelathAnim = (float)((double)this.astolfoHelathAnim + 4.0);
            }
            if (wdnmd * (double)health2 - (double)this.astolfoHelathAnim > 1.0) {
                this.astolfoHelathAnim = (float)(wdnmd * (double)health2);
            }
            this.astolfoHelathAnim = (float)((double)this.astolfoHelathAnim - 4.0);
            if (this.astolfoHelathAnim < 0.0f) {
                this.astolfoHelathAnim = 0.0f;
            }
            Gui.drawRect(((float)x + 2.985f) / 1.5f, (float)(y + 55) / 1.5f, (float)(x + 148) / 1.5f, (float)(y + 58) / 1.5f, new Color(customColor.getRed(), customColor.getGreen(), customColor.getBlue(), 100).getRGB());
            Gui.drawRect(((float)x + 2.985f) / 1.5f, (float)(y + 55) / 1.5f, ((float)(x + 2) + this.astolfoHelathAnim) / 1.5f, (float)(y + 58) / 1.5f, customColor.getRGB());
            GlStateManager.popMatrix();
            RenderUtil.post();
            GlStateManager.color(1.0f, 1.0f, 1.0f);
            RenderUtil.drawEntityOnScreen(x + 18, (int)((float)(y + (player.isSneaking() ? 38 : (player instanceof EntityPlayer ? (((EntityPlayer)player).inventory.armorInventory.length == 0 ? 44 : 46) : 46))) + player.getEyeHeight() / 0.3f), 24.0f, player.rotationYaw, player.rotationPitch, player);
            if (player instanceof EntityPlayer) {
                GlStateManager.pushMatrix();
                entityplayer = (EntityPlayer)player;
                stuff = new ArrayList<ItemStack>();
                split = x + 132;
                y2 = y - 16;
                index = 3;
                while (index >= 0) {
                    armer = entityplayer.inventory.armorInventory[index];
                    if (armer != null) {
                        stuff.add(armer);
                    }
                    --index;
                }
                for (ItemStack errything : stuff) {
                    if (Minecraft.theWorld != null) {
                        RenderHelper.enableGUIStandardItemLighting();
                        y2 += 14;
                    }
                    GlStateManager.disableAlpha();
                    GlStateManager.clear(256);
                    TargetHUD2.mc.getRenderItem().zLevel = -150.0f;
                    TargetHUD2.mc.getRenderItem().renderItemAndEffectIntoGUI(errything, split, y2);
                    TargetHUD2.mc.getRenderItem().renderItemOverlays(Minecraft.fontRendererObj, errything, split, y2);
                    TargetHUD2.mc.getRenderItem().zLevel = 0.0f;
                    GlStateManager.disableBlend();
                    GlStateManager.scale(0.5, 0.5, 0.5);
                    GlStateManager.disableDepth();
                    GlStateManager.disableLighting();
                    GlStateManager.enableDepth();
                    GlStateManager.scale(2.0f, 2.0f, 2.0f);
                    GlStateManager.enableAlpha();
                }
                GlStateManager.popMatrix();
            }
        }
    }

    private float getHealthes(EntityLivingBase entityLivingBase) {
        return (int)((float)((int)Math.ceil(entityLivingBase.getHealth())) + 0.5f);
    }

    private void onArmor(EntityLivingBase target) {
        EntityPlayer player = (EntityPlayer)target;
        ItemStack[] render = player.inventory.armorInventory;
        TargetHUD2.renderItemStack(render[3], ScaledResolution.getScaledWidth() / 2 + 5 + 45, ScaledResolution.getScaledHeight() / 2 + 60);
        TargetHUD2.renderItemStack(render[2], ScaledResolution.getScaledWidth() / 2 + 5 + 63, ScaledResolution.getScaledHeight() / 2 + 60);
        TargetHUD2.renderItemStack(render[1], ScaledResolution.getScaledWidth() / 2 + 5 + 80, ScaledResolution.getScaledHeight() / 2 + 60);
        TargetHUD2.renderItemStack(render[0], ScaledResolution.getScaledWidth() / 2 + 5 + 98, ScaledResolution.getScaledHeight() / 2 + 60);
    }

    public static void renderItemStack(ItemStack stack, int x, int y) {
        GlStateManager.pushMatrix();
        GlStateManager.depthMask(true);
        GlStateManager.clear(256);
        RenderHelper.enableStandardItemLighting();
        Minecraft.getMinecraft().getRenderItem().zLevel = -150.0f;
        GlStateManager.disableDepth();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.enableLighting();
        GlStateManager.enableDepth();
        Minecraft.getMinecraft().getRenderItem().renderItemAndEffectIntoGUI(stack, x, y);
        RenderItem renderItem = Minecraft.getMinecraft().getRenderItem();
        Minecraft.getMinecraft();
        renderItem.renderItemOverlays(Minecraft.fontRendererObj, stack, x, y);
        Minecraft.getMinecraft().getRenderItem().zLevel = 0.0f;
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableCull();
        GlStateManager.enableAlpha();
        GlStateManager.disableBlend();
        GlStateManager.disableLighting();
        double s = 0.5;
        GlStateManager.scale(s, s, s);
        GlStateManager.disableDepth();
        GlStateManager.enableDepth();
        GlStateManager.scale(2.0f, 2.0f, 2.0f);
        GlStateManager.popMatrix();
    }

    private double getIncremental(double val, double inc) {
        double one = 1.0 / inc;
        return (double)Math.round(val * one) / one;
    }

    public static int[] getFractionIndicies(float[] fractions, float progress) {
        int[] range = new int[2];
        int startPoint = 0;
        while (startPoint < fractions.length && fractions[startPoint] <= progress) {
            ++startPoint;
        }
        if (startPoint >= fractions.length) {
            startPoint = fractions.length - 1;
        }
        range[0] = startPoint - 1;
        range[1] = startPoint;
        return range;
    }

    public static Color blendColors(float[] fractions, Color[] colors, float progress) {
        Color color = null;
        if (fractions == null) {
            throw new IllegalArgumentException("Fractions can't be null");
        }
        if (colors == null) {
            throw new IllegalArgumentException("Colours can't be null");
        }
        if (fractions.length == colors.length) {
            int[] indicies = TargetHUD2.getFractionIndicies(fractions, progress);
            float[] range = new float[]{fractions[indicies[0]], fractions[indicies[1]]};
            Color[] colorRange = new Color[]{colors[indicies[0]], colors[indicies[1]]};
            float max = range[1] - range[0];
            float value = progress - range[0];
            float weight = value / max;
            color = TargetHUD2.blend(colorRange[0], colorRange[1], 1.0f - weight);
            return color;
        }
        throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
    }

    @EventHandler
    public void on2D(EventRender2D er) {
        super.setSuffix(mode.getValue());
        EntityLivingBase target1 = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
        ScaledResolution res = new ScaledResolution(mc);
        int x = ScaledResolution.getScaledWidth() / 2 + 30;
        int y = ScaledResolution.getScaledHeight() / 2 + 30;
        if (target1 != this.lastEnt && target1 != null) {
            this.lastEnt = target1;
        }
        if (this.startAnim) {
            this.stopAnim = false;
        }
        if (this.animAlpha == 255 && cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget == null) {
            this.stopAnim = true;
        }
        this.startAnim = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null;
        if (this.startAnim) {
            this.anim = AnimationUtil.mvoeUD(this.anim, 0.0f, 0.09f);
            if (this.animAlpha < 255) {
                this.animAlpha += 15;
            }
        }
        if (this.stopAnim) {
            this.anim = AnimationUtil.mvoeUD(this.anim, 75.0f, 0.09f);
            if (this.animAlpha > 0) {
                this.animAlpha -= 15;
            }
        }
        if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget == null && this.animAlpha < 255) {
            this.startAnim = false;
            this.stopAnim = true;
        }
        int ccolor = 0;
        EntityLivingBase player = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
        if (mode.getValue() == TargetHudEnum.Spring) {
            if (this.lastEnt != null) {
                player = this.lastEnt;
            }
        } else {
            player = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
        }
        if (mode.getValue() == TargetHudEnum.Spring) {
            if (this.animAlpha != 0) {
                float f;
                GlStateManager.enableBlend();
                GlStateManager.pushMatrix();
                GlStateManager.translate(this.anim, 0.0f, 0.0f);
                RenderUtils.drawImage(new ResourceLocation("ZenithAssets/th2.png"), x - 10, y - 8, 153, 54, new Color(255, 255, 255, this.animAlpha));
                ccolor = new Color(255, 255, 255, this.animAlpha).getRGB();
                double wdnmd = 90.796;
                float health2 = player.getHealth() / player.getMaxHealth();
                if ((double)this.width2 < wdnmd * (double)f) {
                    if (wdnmd * (double)health2 - (double)this.width2 < 1.0) {
                        this.width2 = (float)(wdnmd * (double)health2);
                    }
                    this.width2 = (float)((double)this.width2 + 1.6);
                }
                if (wdnmd * (double)health2 - (double)this.width2 > 1.0) {
                    this.width2 = (float)(wdnmd * (double)health2);
                }
                this.width2 = (float)((double)this.width2 - 1.6);
                Minecraft.fontRendererObj.drawString(player.getName(), (float)x + 38.0f, (double)(y + 1), ccolor);
                BigDecimal DT = new BigDecimal(Minecraft.thePlayer.getDistanceToEntity(player));
                DT = DT.setScale(1, RoundingMode.HALF_UP);
                double Dis = DT.doubleValue();
                BigDecimal bigDecimal = new BigDecimal(player.getHealth());
                bigDecimal = bigDecimal.setScale(1, RoundingMode.HALF_UP);
                double HEALTH = bigDecimal.doubleValue();
                String str = "HP: " + HEALTH + "  Dis: " + (int)Minecraft.thePlayer.getDistanceToEntity(player);
                Minecraft.fontRendererObj.drawString(str, (float)x + 38.0f, (float)y + 26.0f, ccolor);
                float health = player.getHealth();
                float[] fractions = new float[]{0.0f, 0.5f, 1.0f};
                Color[] colors = new Color[]{Color.RED, Color.YELLOW, Color.GREEN};
                float progress = health / player.getMaxHealth();
                Color customColor = health2 >= 0.0f ? TargetHUD2.blendColors(fractions, colors, progress).brighter() : Color.RED;
                double width = Minecraft.fontRendererObj.getStringWidth(player.getName());
                width = this.getIncremental(width, 18.0);
                if (width < 71.0) {
                    width = 71.0;
                }
                double healthLocation = width * (double)progress;
                RenderUtil.drawGradientSideways(x + 37, y + 14, (float)(x + 37) + this.width2, y + 25, new Color(RenderUtil.makeDarker(customColor, 150).getRed(), RenderUtil.makeDarker(customColor, 150).getGreen(), RenderUtil.makeDarker(customColor, 150).getBlue(), this.animAlpha).getRGB(), new Color(customColor.getRed(), customColor.getGreen(), customColor.getBlue(), this.animAlpha).getRGB());
                String string = (double)health > 20.0 ? " \u00a79" : ((double)health >= 10.0 ? " \u00a7a" : ((double)health >= 3.0 ? " \u00a7e" : " \u00a74"));
                if (player instanceof EntityPlayer) {
                    GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                    GlStateManager.enableAlpha();
                    GlStateManager.enableBlend();
                    GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                    List var5 = GuiPlayerTabOverlay.field_175252_a.sortedCopy(Minecraft.thePlayer.sendQueue.getPlayerInfoMap());
                    for (Object aVar5 : var5) {
                        NetworkPlayerInfo var6 = (NetworkPlayerInfo)aVar5;
                        if (Minecraft.theWorld.getPlayerEntityByUUID(var6.getGameProfile().getId()) != player) continue;
                        mc.getTextureManager().bindTexture(var6.getLocationSkin());
                        Gui.drawScaledCustomSizeModalRect((double)(x - 3), (double)y + 0.7, 8.0f, 8.0f, 8, 8, 36.0f, 36.0f, 64.0f, 64.0f);
                        if (((EntityPlayer)player).isWearing(EnumPlayerModelParts.HAT)) {
                            Gui.drawScaledCustomSizeModalRect((double)(x - 3), (double)y + 0.7, 40.0f, 8.0f, 8, 8, 36.0f, 36.0f, 64.0f, 64.0f);
                        }
                        GlStateManager.bindTexture(0);
                        break;
                    }
                } else {
                    R3DUtil.drawEntityOnScreen(x + 18, y + 40, 20, player.rotationYaw, 0.0f, player);
                }
                GlStateManager.popMatrix();
                GlStateManager.disableBlend();
            }
        } else if (mode.getValue() == TargetHudEnum.PowerX && player != null) {
            float f;
            GlStateManager.pushMatrix();
            float xLeng = 144.0f;
            float yLeng = 52.0f;
            RenderUtil.rectangleBordered(x, y, (float)x + xLeng, (float)y + yLeng, 0.5, Colors.getColor(90), Colors.getColor(0));
            RenderUtil.rectangleBordered((float)x + 1.0f, (float)y + 1.0f, (float)x + xLeng - 1.0f, (float)y + yLeng - 1.0f, 1.0, Colors.getColor(90), Colors.getColor(61));
            RenderUtil.rectangleBordered((double)x + 2.5, (double)y + 2.5, (double)((float)x + xLeng) - 2.5, (double)((float)y + yLeng) - 2.5, 0.5, Colors.getColor(61), Colors.getColor(0));
            RenderUtil.rectangleBordered((float)x + 3.0f, (float)y + 3.0f, (float)x + xLeng - 3.0f, (float)y + yLeng - 3.0f, 0.5, Colors.getColor(27), Colors.getColor(61));
            Minecraft.fontRendererObj.drawStringWithShadow(player.getName(), x + 40, y + 6, -1);
            if (player instanceof EntityPlayer) {
                GlStateManager.pushMatrix();
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.enableAlpha();
                GlStateManager.enableBlend();
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                List var5 = GuiPlayerTabOverlay.field_175252_a.sortedCopy(Minecraft.thePlayer.sendQueue.getPlayerInfoMap());
                for (Object aVar5 : var5) {
                    NetworkPlayerInfo var6 = (NetworkPlayerInfo)aVar5;
                    if (Minecraft.theWorld.getPlayerEntityByUUID(var6.getGameProfile().getId()) != player) continue;
                    float size = 30.0f;
                    mc.getTextureManager().bindTexture(var6.getLocationSkin());
                    Gui.drawScaledCustomSizeModalRect((double)(x + 6), (double)(y + 6), 8.0f, 8.0f, 8, 8, size, size, 64.0f, 64.0f);
                    if (((EntityPlayer)player).isWearing(EnumPlayerModelParts.HAT)) {
                        Gui.drawScaledCustomSizeModalRect((double)(x + 6), (double)(y + 6), 40.0f, 8.0f, 8, 8, size, size, 64.0f, 64.0f);
                    }
                    GlStateManager.bindTexture(0);
                    break;
                }
                GlStateManager.popMatrix();
            }
            if (player instanceof EntityPlayer) {
                GlStateManager.pushMatrix();
                EntityPlayer entityPlayer = (EntityPlayer)player;
                ArrayList<ItemStack> stuff = new ArrayList<ItemStack>();
                int split = x + 19;
                int armorY = y + 16;
                int index = 3;
                while (index >= 0) {
                    ItemStack armer = entityPlayer.inventory.armorInventory[index];
                    if (armer != null) {
                        stuff.add(armer);
                    }
                    --index;
                }
                if (entityPlayer.getCurrentEquippedItem() != null) {
                    stuff.add(entityPlayer.getCurrentEquippedItem());
                }
                for (ItemStack errything : stuff) {
                    if (Minecraft.theWorld != null) {
                        RenderHelper.enableGUIStandardItemLighting();
                        split += 20;
                    }
                    RenderUtil.rectangleBordered(split, armorY, (double)split + 18.0, (double)armorY + 18.0, 1.0, new Color(52, 52, 52, 150).getRGB(), Colors.BLACK.c);
                    GlStateManager.disableAlpha();
                    GlStateManager.clear(256);
                    TargetHUD2.mc.getRenderItem().zLevel = -150.0f;
                    mc.getRenderItem().renderItemAndEffectIntoGUI(errything, split + 1, armorY + 1);
                    mc.getRenderItem().renderItemOverlays(Minecraft.fontRendererObj, errything, split + 1, armorY + 1);
                    TargetHUD2.mc.getRenderItem().zLevel = 0.0f;
                    GlStateManager.disableBlend();
                    GlStateManager.scale(0.5, 0.5, 0.5);
                    GlStateManager.disableDepth();
                    GlStateManager.disableLighting();
                    GlStateManager.enableDepth();
                    GlStateManager.scale(2.0f, 2.0f, 2.0f);
                    GlStateManager.enableAlpha();
                }
                GlStateManager.popMatrix();
            }
            BigDecimal bigDecimal = new BigDecimal(player.getHealth());
            float health = bigDecimal.setScale(1, 4).floatValue();
            float[] fractions = new float[]{0.0f, 0.2f, 0.7f};
            Color[] colors = new Color[]{Color.RED, Color.YELLOW, Color.GREEN};
            float progress = health / player.getMaxHealth();
            Color customColor = health >= 0.0f ? TargetHUD2.blendColors(fractions, colors, progress).brighter() : Color.RED;
            double wdnmd = 98.0;
            float health2 = player.getHealth() / player.getMaxHealth();
            if ((double)this.powerxHealthAnim < wdnmd * (double)f) {
                if (wdnmd * (double)health2 - (double)this.powerxHealthAnim < 1.0) {
                    this.powerxHealthAnim = (float)(wdnmd * (double)health2);
                }
                this.powerxHealthAnim = (float)((double)this.powerxHealthAnim + 2.0);
            }
            if (wdnmd * (double)health2 - (double)this.powerxHealthAnim > 1.0) {
                this.powerxHealthAnim = (float)(wdnmd * (double)health2);
            }
            this.powerxHealthAnim = (float)((double)this.powerxHealthAnim - 2.0);
            if (this.powerxHealthAnim < 0.0f) {
                this.powerxHealthAnim = 0.0f;
            }
            RenderUtil.rectangleBordered(x + 39, y + Minecraft.fontRendererObj.FONT_HEIGHT + 26, x + 137, y + Minecraft.fontRendererObj.FONT_HEIGHT + 38, 1.0, 0, Colors.BLACK.c);
            Gui.drawRect((double)(x + 40), (double)(y + Minecraft.fontRendererObj.FONT_HEIGHT + 27), (float)(x + 40) + this.powerxHealthAnim, (double)(y + Minecraft.fontRendererObj.FONT_HEIGHT + 37), customColor.darker().getRGB());
            Minecraft.fontRendererObj.drawStringWithShadow((Object)((Object)EnumChatFormatting.RED) + "\u2764" + (Object)((Object)EnumChatFormatting.RESET) + health, (float)x + 7.5f, (float)y + 52.0f - (float)Minecraft.fontRendererObj.FONT_HEIGHT - 5.0f, customColor.darker().getRGB());
            GlStateManager.popMatrix();
        }
    }

    public static Color blend(Color color1, Color color2, double ratio) {
        float r = (float)ratio;
        float ir = 1.0f - r;
        float[] rgb1 = new float[3];
        float[] rgb2 = new float[3];
        color1.getColorComponents(rgb1);
        color2.getColorComponents(rgb2);
        float red = rgb1[0] * r + rgb2[0] * ir;
        float green = rgb1[1] * r + rgb2[1] * ir;
        float blue = rgb1[2] * r + rgb2[2] * ir;
        if (red < 0.0f) {
            red = 0.0f;
        } else if (red > 255.0f) {
            red = 255.0f;
        }
        if (green < 0.0f) {
            green = 0.0f;
        } else if (green > 255.0f) {
            green = 255.0f;
        }
        if (blue < 0.0f) {
            blue = 0.0f;
        } else if (blue > 255.0f) {
            blue = 255.0f;
        }
        Color color3 = null;
        try {
            color3 = new Color(red, green, blue);
        }
        catch (IllegalArgumentException exp) {
            NumberFormat nf = NumberFormat.getNumberInstance();
            System.out.println(String.valueOf(nf.format((double)red)) + "; " + nf.format((double)green) + "; " + nf.format((double)blue));
            exp.printStackTrace();
        }
        return color3;
    }

    private void drawEntityOnScreen(float posX, float posY, float scale, float mouseX, float mouseY, EntityLivingBase ent) {
        GlStateManager.enableColorMaterial();
        GlStateManager.pushMatrix();
        GlStateManager.translate((double)posX, (double)posY, 50.0);
        GlStateManager.scale(-scale, scale, scale);
        GlStateManager.rotate(180.0f, 0.0f, 0.0f, 1.0f);
        GlStateManager.rotate(135.0f, 0.0f, 1.0f, 0.0f);
        RenderHelper.enableStandardItemLighting();
        GlStateManager.rotate(-135.0f, 0.0f, 1.0f, 0.0f);
        GlStateManager.translate(0.0, 0.0, 0.0);
        RenderManager rendermanager = mc.getRenderManager();
        rendermanager.setPlayerViewY(180.0f);
        rendermanager.setRenderShadow(false);
        rendermanager.renderEntityWithPosYaw(ent, 0.0, 0.0, 0.0, 0.0f, 1.0f);
        rendermanager.setRenderShadow(true);
        GlStateManager.popMatrix();
        RenderHelper.disableStandardItemLighting();
        GlStateManager.disableRescaleNormal();
        GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
        GlStateManager.disableTexture2D();
        GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    }

    private void FluxonHead() {
        ScaledResolution res = new ScaledResolution(mc);
        int x = ScaledResolution.getScaledWidth() / 2 + 30;
        int y = ScaledResolution.getScaledHeight() / 2 + 30;
        mc.getTextureManager().bindTexture(((AbstractClientPlayer)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget).getLocationSkin());
        Gui.drawScaledCustomSizeModalRect(x, y - 10, 8.0f, 8.0f, 8, 8, 20, 20, 64.0f, 64.0f);
    }

    private void FluxonName(EntityLivingBase target) {
        ScaledResolution res = new ScaledResolution(mc);
        int x = ScaledResolution.getScaledWidth() / 2 + 30;
        int y = ScaledResolution.getScaledHeight() / 2 + 30;
        CFontRenderer font2 = FontLoaders.GoogleSans14;
        CFontRenderer font4 = FontLoaders.GoogleSans18;
        CFontRenderer font3 = FontLoaders.NovICON11;
        font4.drawStringWithShadow(target.getName(), x + 20 + 2, y - 10 + 3, -1);
        double hea = target.getHealth();
        String str1 = String.format("%.1f", hea);
        double f1 = new com.ibm.icu.math.BigDecimal(hea).setScale(1, 4).doubleValue();
        font2.drawStringWithShadow("", x - 20 + 50 + 2 + 2 + font2.getStringWidth("Health: " + f1), y - 10, -1);
        font2.drawStringWithShadow("Health:" + f1, x + 20 + 2, y - 6 + this.font.getStringHeight("") + 2, -1);
        font3.drawString("z", x, y - 1 + this.font.getStringHeight(""), -1);
        font3.drawString("r", x, y - 30 + this.font.getStringHeight("") + 6, -1);
    }

    private void FluxBackground(EntityLivingBase target) {
        ScaledResolution res = new ScaledResolution(mc);
        int x = ScaledResolution.getScaledWidth() / 2 + 30;
        int y = ScaledResolution.getScaledHeight() / 2 + 30;
        double hea = target.getHealth();
        double f1 = new com.ibm.icu.math.BigDecimal(hea).setScale(1, 4).doubleValue();
        if (FontLoaders.GoogleSans18.getStringWidth(target.getName()) > FontLoaders.GoogleSans14.getStringWidth("Health:" + f1)) {
            this.rect = FontLoaders.GoogleSans18.getStringWidth(target.getName());
        }
        if (FontLoaders.GoogleSans18.getStringWidth(target.getName()) == FontLoaders.GoogleSans14.getStringWidth("Health:" + f1)) {
            this.rect = FontLoaders.GoogleSans18.getStringWidth(target.getName());
        }
        if (FontLoaders.GoogleSans18.getStringWidth(target.getName()) < FontLoaders.GoogleSans14.getStringWidth("Health:" + f1)) {
            this.rect = FontLoaders.GoogleSans14.getStringWidth("Health:" + f1);
        }
        RenderUtil.drawFastRoundedRect(x - 2, (float)(y - 12), (int)((double)(x + 25) + this.rect), (float)(y - 20 + 28 + 15), 1.0f, new Color(40, 40, 40, 200).getRGB());
    }

    public static Color getAstolfoRainbow(int v1) {
        double d;
        double delay = Math.ceil((double)(System.currentTimeMillis() + (long)(v1 * 70)) / 5.0);
        float rainbow = (double)((float)(d / 420.0)) < 0.5 ? -((float)(delay / 420.0)) : (float)((delay %= 420.0) / 420.0);
        return Color.getHSBColor(rainbow, 0.5f, 1.0f);
    }

    public void FLux() {
        ScaledResolution res = new ScaledResolution(mc);
        int x = ScaledResolution.getScaledWidth() / 2 + 30;
        int y = ScaledResolution.getScaledHeight() / 2 + 30;
        if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null) {
            if (!(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget instanceof EntityPlayer)) {
                return;
            }
            this.FluxBackground(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
            this.FluxonName(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
            this.FluxonHead();
            RenderUtil.drawRect((double)x - 0.3, (double)(y - 10), (double)(x + 20) + 0.3, (double)y - 9.3, new Color(149, 255, 147).getRGB());
            RenderUtil.drawRect((double)x - 0.3, (double)(y - 10), (double)x, (double)(y + 10), new Color(149, 255, 147).getRGB());
            RenderUtil.drawRect((double)x - 0.3, (double)(y + 10), (double)(x + 20) + 0.3, (double)y + 10.3, new Color(149, 255, 147).getRGB());
            RenderUtil.drawRect((double)(x + 20), (double)(y - 10), (double)(x + 20) + 0.6, (double)(y + 10), new Color(149, 255, 147).getRGB());
            if (ModuleManager.getModuleByClass(KillAura.class).isEnabled()) {
                EntityLivingBase target1 = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget;
                int Custom = new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)).getRGB();
                if (target1 != this.lastEnt && target1 != null) {
                    this.lastEnt = target1;
                }
                if (this.startAnim) {
                    this.stopAnim = false;
                }
                if (this.animAlpha == 255 && cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget == null) {
                    this.stopAnim = true;
                }
                boolean bl = this.startAnim = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget != null;
                if (this.startAnim && this.animAlpha < 255) {
                    this.animAlpha += 15;
                }
                if (this.stopAnim && this.animAlpha > 0) {
                    this.animAlpha -= 15;
                }
                if (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget == null && this.animAlpha < 255) {
                    this.startAnim = false;
                    this.stopAnim = true;
                }
                EntityLivingBase player = null;
                if (this.lastEnt != null) {
                    player = this.lastEnt;
                }
                if (player != null && this.animAlpha >= 135) {
                    double healthLocation;
                    float health = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth();
                    float progress = this.getWidth(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget) / 20;
                    double Width = this.getWidth(cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget);
                    if (Width < 50.0) {
                        Width = 50.0;
                    }
                    if ((double)this.anim2 < (healthLocation = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth() > 20.0f ? 16.0 + this.rect : (16.0 + this.rect) / 20.0 * (double)((int)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth()))) {
                        this.anim2 = (float)healthLocation;
                    }
                    if ((double)this.anim2 > healthLocation) {
                        this.anim2 = (float)((double)this.anim2 - 0.5);
                    }
                    int color = cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth() > 10.0f ? RenderUtil.blend(new Color(-16711936), new Color(-256), 1.0f / cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth() / 2.0f * (cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth() - 10.0f)).getRGB() : RenderUtil.blend(new Color(-256), new Color(-65536), 0.1f * cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getHealth()).getRGB();
                    this.r2 = (16.0 + this.rect) / 20.0 * (double)cn.M1N3S3NS3.Module.Modules.Combat.KillAura.curTarget.getTotalArmorValue();
                    Gui.drawRect((double)(x + 7), (double)(y + 13), (float)(x + 7) + this.anim2, (double)(y + 15), new Color(255, 213, 0, 201).getRGB());
                    Gui.drawRect((double)(x + 7), (double)(y + 13), (double)(x + 7) + healthLocation, (double)(y + 15), new Color(47, 190, 130).getRGB());
                    Gui.drawRect((double)(x + 7), (double)(y + 18), (double)(x + 23) + this.rect, (double)(y + 20), new Color(50, 50, 50).getRGB());
                    Gui.drawRect((double)(x + 7), (double)(y + 18), (double)(x + 7) + this.r2, (double)(y + 20), new Color(87, 130, 189).getRGB());
                }
            }
        }
    }

    static enum TargetHudEnum {
        Client,
        Astolfo,
        Exhibition,
        Entity,
        Evelina,
        Drug,
        Lnk,
        New,
        Simple,
        Normal,
        Autumn,
        MeMe,
        PowerX,
        Spring,
        Chocolate,
        AzureWare,
        NovolineNew,
        Flux,
        AstolfoNew,
        ExhibitionReload;

    }
}

