/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.ibm.icu.text.NumberFormat
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Module.Modules.Render;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.KillAura;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.Font.CFontRenderer;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import cn.M1N3S3NS3.Util.Color.ColorUtil;
import cn.M1N3S3NS3.Util.Math.MathUtil;
import cn.M1N3S3NS3.Util.Render.Colors;
import cn.M1N3S3NS3.Util.Render.RenderUtil;
import cn.M1N3S3NS3.Util.Render.RenderUtil2;
import cn.M1N3S3NS3.Util.RenderUtils;
import com.ibm.icu.text.NumberFormat;
import java.awt.Color;
import java.math.BigDecimal;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;

public class TargetHUD
extends Module {
    double healthwidth;
    double maxhealth;
    double healthamout;
    int animAlpha = 0;
    double anim2 = 0.0;
    double rect;
    public Mode<Enum> mode = new Mode("Mode", "Mode", (Enum[])targetinfoenum.values(), (Enum)targetinfoenum.Flux);
    double r2;
    public static Numbers<Double> xn = new Numbers<Double>("X", "X", 20.0, 0.0, 1920.0, 10.0);
    public static Numbers<Double> yn = new Numbers<Double>("Y", "Y", 10.0, 0.0, 1080.0, 10.0);
    float astolfoHelathAnim = 0.0f;
    boolean startAnim;
    boolean stopAnim;
    public EntityLivingBase lastEnt;
    private final CFontRenderer font = FontLoaders.GoogleSans18;
    public static float hue;
    double healthLocationani;
    private int animWidth;

    public TargetHUD() {
        super("TargetHUD", new String[]{"targetInformationHud"}, ModuleType.Render);
        this.addValues(this.mode, xn, yn);
    }

    private void drawNormalFace(EntityLivingBase e, float x, float y, float scale) {
        if (e instanceof EntityPlayer) {
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
            GlStateManager.enableAlpha();
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
            List var5 = GuiPlayerTabOverlay.field_175252_a.sortedCopy(Minecraft.thePlayer.sendQueue.getPlayerInfoMap());
            for (Object aVar5 : var5) {
                NetworkPlayerInfo var6 = (NetworkPlayerInfo)aVar5;
                if (Minecraft.theWorld.getPlayerEntityByUUID(var6.getGameProfile().getId()) != e) continue;
                mc.getTextureManager().bindTexture(var6.getLocationSkin());
                Gui.drawScaledCustomSizeModalRect(x, y, 8.0f, 8.0f, 8, 8, (int)scale, (int)scale, 64.0f, 64.0f);
                if (((EntityPlayer)e).isWearing(EnumPlayerModelParts.HAT)) {
                    Gui.drawScaledCustomSizeModalRect(x, y, 40.0f, 8.0f, 8, 8, (int)scale, (int)scale, 64.0f, 64.0f);
                }
                GlStateManager.bindTexture(0);
                break;
            }
        }
    }

    @EventHandler
    public void on2D(EventRender2D er) {
        EntityLivingBase entity = TargetHUD.mc.currentScreen instanceof GuiChat ? Minecraft.thePlayer : (KillAura.getTarget() != null ? KillAura.getTarget() : (KillAura.getTarget() != null ? KillAura.getTarget() : null));
        Client.instance.getModuleManager();
        KillAura ka = (KillAura)ModuleManager.getModuleByClass(KillAura.class);
        EntityLivingBase target1 = entity;
        ScaledResolution res = new ScaledResolution(mc);
        int x = (int)((double)(ScaledResolution.getScaledWidth() / 2) + (Double)xn.getValue());
        int y = (int)((double)ScaledResolution.getScaledHeight() - (Double)yn.getValue());
        if (this.mode.getModeAsString().equals("Novoline")) {
            Color customColor;
            int colors233 = new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue(), 255).getRGB();
            EntityLivingBase target = TargetHUD.mc.currentScreen instanceof GuiChat ? Minecraft.thePlayer : (KillAura.getTarget() != null ? KillAura.getTarget() : (KillAura.getTarget() != null ? KillAura.getTarget() : null));
            ScaledResolution res1 = new ScaledResolution(mc);
            BigDecimal bigDecimal = new BigDecimal(target.getHealth());
            float health = bigDecimal.setScale(1, 4).floatValue();
            float[] fractions = new float[]{0.0f, 0.2f, 0.7f};
            String healthStr = String.valueOf((float)((int)target.getHealth()) / 2.0f);
            Color[] colors = new Color[]{Color.RED, Color.YELLOW, Color.GREEN};
            float progress = health / target.getHealth();
            Color color = customColor = health >= 0.0f ? TargetHUD.blendColors(fractions, colors, progress).brighter() : Color.RED;
            if (target != null) {
                GL11.glPushMatrix();
                GL11.glScalef((float)0.9f, (float)0.9f, (float)0.9f);
                double width = Minecraft.fontRendererObj.getStringWidth(target.getName()) > 40 ? 20 + Minecraft.fontRendererObj.getStringWidth(target.getName()) : 50;
                this.healthwidth = width + 18.0;
                this.healthamout = RenderUtil.getAnimationState(this.healthamout, this.healthwidth * (double)target.getHealth() / (double)target.getMaxHealth(), 200.0);
                RenderUtil.rectangleBordered(x - 9, y, (double)(x + 50) + width, (double)(y + 30 + 5) + 2.5, 1.0, new Color(41, 41, 41).getRGB(), new Color(31, 34, 40).getRGB());
                RenderUtil.rectangle(x + 30, (double)y + 15.5, (double)(x + 30) + this.healthwidth, y + 20 + 5, new Color(90, 90, 90).getRGB());
                RenderUtil.rectangleBordered(x + 30, (double)y + 15.5, (double)(x + 30) + this.healthamout, y + 20 + 5, 0.0, colors233, new Color(0, 0, 0, 0).getRGB());
                this.drawNormalFace(target, x + 2 - 11, (float)((double)(y + 2) - 2.0), 37.0f);
                Minecraft.fontRendererObj.drawStringWithShadow(String.valueOf(healthStr) + " \u2764", (float)x + 29.5f, (float)y + 52.0f + 5.0f + 2.0f - (float)Minecraft.fontRendererObj.FONT_HEIGHT - 22.2f, colors233);
                boolean cfr_ignored_0 = target instanceof EntityPlayer;
                Minecraft.fontRendererObj.drawStringWithShadow(target.getName(), x + 31, y + 4, new Color(255, 255, 255).getRGB());
            }
            GL11.glPopMatrix();
            GL11.glScalef((float)1.0f, (float)1.0f, (float)1.0f);
        }
        if (this.mode.getModeAsString().equals("Zenith") && entity instanceof EntityLivingBase) {
            if (entity == null) {
                this.healthLocationani = 70.0;
            }
            if (entity != null && !entity.isDead) {
                if (Minecraft.thePlayer.getDistanceToEntity(entity) < 8.0f) {
                    GlStateManager.pushMatrix();
                    float xLeng = 100.0f;
                    float yLeng = 50.0f;
                    RenderUtil.rectangleBordered(x, y, (float)x + xLeng, (float)y + yLeng, 0.8, Colors.getColor(255), Colors.getColor(25));
                    RenderUtil.rectangleBordered((float)x + 1.0f, (float)y + 1.0f, (float)x + xLeng - 1.0f, (float)y + yLeng - 1.0f, 1.0, Colors.getColor(35), Colors.getColor(130));
                    RenderUtil.rectangleBordered((float)x + 1.5f, (float)y + 1.5f, (float)x + xLeng - 1.5f, (float)y + yLeng - 1.5f, 1.1, Colors.getColor(35), Colors.getColor(90));
                    String name = entity.getDisplayName().getFormattedText();
                    FontLoaders.GoogleSans20.drawStringWithShadow(name, (double)x + 8.5, y + 10, 0xFFFFFF);
                    double hpWidth = 70.0 * MathHelper.clamp_double(entity.getHealth() / entity.getMaxHealth(), 0.0, 1.0);
                    RenderUtils.drawRect((double)((float)x + 8.5f), (double)((float)y + 31.0f), (double)x + hpWidth + 8.5, (double)((float)(y + 21) - 0.5f), ColorUtil.getBlendColor(entity.getHealth(), entity.getMaxHealth()).getRGB());
                    FontLoaders.GoogleSans20.drawStringWithShadow(String.valueOf((int)entity.getHealth()) + " HP", (float)x + 24.5f, (float)y + 56.0f - (float)FontLoaders.GoogleSans20.FONT_HEIGHT - 22.2f, -1);
                    if (entity instanceof EntityPlayer) {
                        FontLoaders.GoogleSans15.drawStringWithShadow(String.valueOf(new StringBuilder("Experience: ").append(((EntityPlayer)entity).experienceLevel)), (float)x + 8.5f, (float)y + 72.0f - (float)FontLoaders.GoogleSans15.FONT_HEIGHT - 22.2f, -1);
                        FontLoaders.GoogleSans15.drawStringWithShadow(String.valueOf(new StringBuilder("Blocking: ").append(((EntityPlayer)entity).isBlocking())), (float)x + 8.5f, (float)y + 65.0f - (float)FontLoaders.GoogleSans15.FONT_HEIGHT - 22.2f, -1);
                    }
                    GlStateManager.popMatrix();
                }
            }
        }
        if (this.mode.getModeAsString().equals("PowerX")) {
            double armorlecotion;
            ScaledResolution es = new ScaledResolution(mc);
            if (entity == null || !(entity instanceof EntityPlayer)) {
                this.animWidth = 0;
                this.r2 = 0.0;
                return;
            }
            int modelWidth = 22;
            int height = 30;
            int width = 2 + Math.max(Minecraft.fontRendererObj.getStringWidth(entity.getName()) + 2, 98);
            String healthStr = String.valueOf((float)((int)entity.getHealth()) / 2.0f);
            GlStateManager.pushMatrix();
            GlStateManager.translate(x, y, 0.0f);
            RenderUtil2.drawRect(0.0, 0.0, modelWidth + width, height, Colors.getColor(0, 155));
            GlStateManager.color(1.0f, 1.0f, 1.0f);
            int color = entity.getHealth() > 10.0f ? RenderUtil.blend(new Color(255, 2, 12), new Color(-180), 1.0f / entity.getHealth() / 2.0f * (entity.getHealth() - 10.0f)).getRGB() : RenderUtil.blend(new Color(-256), new Color(-65536), 0.1f * entity.getHealth()).getRGB();
            String name = entity.getDisplayName().getFormattedText();
            Client.instance.getFontManager().Tahoma18.drawStringWithShadow(name, modelWidth + 11, 5.0, -1);
            Client.instance.getFontManager().arial12.drawStringWithShadow(healthStr, modelWidth + 81, 23.6, new Color(150, 150, 150).getRGB());
            Client.instance.getFontManager().logo10.drawStringWithShadow("s", modelWidth + 74, 25.0, new Color(87, 160, 250).getRGB());
            Client.instance.getFontManager().logo10.drawStringWithShadow("s", modelWidth + 11, 18.5, new Color(255, 85, 85).getRGB());
            Client.instance.getFontManager().logo10.drawStringWithShadow("r", modelWidth + 11, 25.5, new Color(153, 153, 153).getRGB());
            double healthLocation = (float)(modelWidth + width - 2) * entity.getHealth() / entity.getMaxHealth();
            if ((double)this.animWidth > healthLocation) {
                this.animWidth = MathUtil.getNextPostion(this.animWidth, (int)healthLocation, 2.0);
            }
            if ((double)this.animWidth < healthLocation) {
                this.animWidth = MathUtil.getNextPostion(this.animWidth, (int)healthLocation, 2.0);
            }
            if (this.r2 > (armorlecotion = (double)((modelWidth + width - 2) * entity.getTotalArmorValue()))) {
                this.r2 = MathUtil.getNextPostion((int)this.r2, (int)armorlecotion, 2.0);
            }
            if (this.r2 < armorlecotion) {
                this.r2 = MathUtil.getNextPostion((int)this.r2, (int)armorlecotion, 2.0);
            }
            boolean lineWidth = true;
            RenderUtils.drawRect((double)(modelWidth + 18), 17.0, (double)(modelWidth + 18) + (double)(modelWidth + width - 2) / 1.6, 19.0, new Color(0, 0, 0, 180).getRGB());
            RenderUtils.drawRect((double)(modelWidth + 18), 17.0, (double)(modelWidth + 18) + (double)this.animWidth / 1.6, 19.0, Colors.getHealthColor(entity.getHealth(), entity.getMaxHealth()));
            RenderUtils.drawRect((double)(modelWidth + 18), 24.0, (double)(modelWidth + 18) + (double)(modelWidth + width - 2) / 2.4, 26.0, new Color(0, 0, 0, 180).getRGB());
            RenderUtils.drawRect((double)(modelWidth + 18), 24.0, (double)(modelWidth + 18) + this.r2 / 48.0, 26.0, new Color(87, 160, 250).getRGB());
            boolean armorX = false;
            boolean rectX = false;
            this.drawNormalFace(entity, 1.0f, 1.0f, 28.0f);
            GlStateManager.popMatrix();
        }
    }

    public static Color blendColors(float[] fractions, Color[] colors, float progress) {
        Color color = null;
        if (fractions == null) {
            throw new IllegalArgumentException("Fractions can't be null");
        }
        if (colors == null) {
            throw new IllegalArgumentException("Colours can't be null");
        }
        if (fractions.length == colors.length) {
            int[] indicies = TargetHUD.getFractionIndicies(fractions, progress);
            float[] range = new float[]{fractions[indicies[0]], fractions[indicies[1]]};
            Color[] colorRange = new Color[]{colors[indicies[0]], colors[indicies[1]]};
            float max = range[1] - range[0];
            float value = progress - range[0];
            float weight = value / max;
            color = TargetHUD.blend(colorRange[0], colorRange[1], 1.0f - weight);
            return color;
        }
        throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
    }

    public static Color blend(Color color1, Color color2, double ratio) {
        float r = (float)ratio;
        float ir = 1.0f - r;
        float[] rgb1 = new float[3];
        float[] rgb2 = new float[3];
        color1.getColorComponents(rgb1);
        color2.getColorComponents(rgb2);
        float red = rgb1[0] * r + rgb2[0] * ir;
        float green = rgb1[1] * r + rgb2[1] * ir;
        float blue = rgb1[2] * r + rgb2[2] * ir;
        if (red < 0.0f) {
            red = 0.0f;
        } else if (red > 250.0f) {
            red = 255.0f;
        }
        if (green < 0.0f) {
            green = 0.0f;
        } else if (green > 250.0f) {
            green = 255.0f;
        }
        if (blue < 0.0f) {
            blue = 0.0f;
        } else if (blue > 250.0f) {
            blue = 250.0f;
        }
        Color color3 = null;
        try {
            color3 = new Color(red, green, blue);
        }
        catch (IllegalArgumentException exp) {
            NumberFormat nf = NumberFormat.getNumberInstance();
            System.out.println(String.valueOf(String.valueOf(nf.format((double)red))) + "; " + nf.format((double)green) + "; " + nf.format((double)blue));
            exp.printStackTrace();
        }
        return color3;
    }

    @EventHandler
    public void onRender(EventRender2D event) {
        if (this.mode.getModeAsString().equals("Flux")) {
            float f;
            EntityLivingBase entity = TargetHUD.mc.currentScreen instanceof GuiChat ? Minecraft.thePlayer : (KillAura.getTarget() != null ? KillAura.getTarget() : (KillAura.getTarget() != null ? KillAura.getTarget() : null));
            Client.instance.getModuleManager();
            KillAura ka = (KillAura)ModuleManager.getModuleByClass(KillAura.class);
            ScaledResolution res = new ScaledResolution(mc);
            int x = ScaledResolution.getScaledWidth() / 2 + 30;
            int y = ScaledResolution.getScaledHeight() / 2 - 5;
            hue = (float)((double)hue + 1.2);
            if (f > 255.0f) {
                hue = 0.0f;
            }
            float h = hue;
            if (KillAura.curTarget != null) {
                if (!(KillAura.curTarget instanceof EntityPlayer)) {
                    return;
                }
                if (h > 255.0f) {
                    h = 0.0f;
                }
                this.Background(KillAura.curTarget);
                this.onName(KillAura.curTarget);
                this.onHead();
                RenderUtil.drawRect((double)x - 0.3, (double)(y - 10), (double)(x + 20) + 0.3, (double)y - 9.3, new Color(149, 255, 147).getRGB());
                RenderUtil.drawRect((double)x - 0.3, (double)(y - 10), (double)x, (double)(y + 10), new Color(149, 255, 147).getRGB());
                RenderUtil.drawRect((double)x - 0.3, (double)(y + 10), (double)(x + 20) + 0.3, (double)y + 10.3, new Color(149, 255, 147).getRGB());
                RenderUtil.drawRect((double)(x + 20), (double)(y - 10), (double)(x + 20) + 0.6, (double)(y + 10), new Color(149, 255, 147).getRGB());
                Client.getModuleManager();
                if (ModuleManager.getModuleByClass(KillAura.class).isEnabled()) {
                    EntityLivingBase target1 = KillAura.curTarget;
                    int Custom = new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)).getRGB();
                    if (target1 != this.lastEnt && target1 != null) {
                        this.lastEnt = target1;
                    }
                    if (this.startAnim) {
                        this.stopAnim = false;
                    }
                    if (this.animAlpha == 255 && KillAura.curTarget == null) {
                        this.stopAnim = true;
                    }
                    this.startAnim = KillAura.curTarget != null;
                    if (this.startAnim && this.animAlpha < 255) {
                        this.animAlpha += 15;
                    }
                    if (this.stopAnim && this.animAlpha > 0) {
                        this.animAlpha -= 15;
                    }
                    if (KillAura.curTarget == null && this.animAlpha < 255) {
                        this.startAnim = false;
                        this.stopAnim = true;
                    }
                    EntityLivingBase player = null;
                    if (this.lastEnt != null) {
                        player = this.lastEnt;
                    }
                    if (player != null && this.animAlpha >= 135) {
                        double healthLocation;
                        float health = KillAura.curTarget.getHealth();
                        float progress = this.getWidth(KillAura.curTarget) / 20;
                        double Width = this.getWidth(KillAura.curTarget);
                        if (Width < 50.0) {
                            Width = 50.0;
                        }
                        if (this.anim2 < (healthLocation = KillAura.curTarget.getHealth() > 20.0f ? 16.0 + this.rect : (16.0 + this.rect) / 20.0 * (double)((int)KillAura.curTarget.getHealth()))) {
                            this.anim2 = healthLocation;
                        }
                        if (this.anim2 > healthLocation) {
                            this.anim2 -= 0.5;
                        }
                        float[] fractions = new float[]{0.0f, 0.5f, 1.0f};
                        Color[] colors = new Color[]{Color.RED, Color.YELLOW, Color.GREEN};
                        Color cl = Color.RED;
                        Color rainbow = new Color(Color.getHSBColor(h / 255.0f, 0.4f, 0.8f).getRed(), Color.getHSBColor(h / 255.0f, 0.4f, 0.8f).getGreen(), 255);
                        Color rainbowa = new Color(Color.getHSBColor(h / 255.0f, 0.4f, 0.8f).getRed(), Color.getHSBColor(h / 255.0f, 0.4f, 0.8f).getGreen(), 255, 100);
                        int color = KillAura.curTarget.getHealth() > 10.0f ? RenderUtil.blend(new Color(-16711936), new Color(-256), 1.0f / KillAura.curTarget.getHealth() / 2.0f * (KillAura.curTarget.getHealth() - 10.0f)).getRGB() : RenderUtil.blend(new Color(-256), new Color(-65536), 0.1f * KillAura.curTarget.getHealth()).getRGB();
                        this.r2 = (16.0 + this.rect) / 20.0 * (double)KillAura.curTarget.getTotalArmorValue();
                        Gui.drawRect((double)(x + 7), (double)(y + 13), (double)(x + 7) + this.anim2, (double)(y + 15), new Color(255, 213, 0, 201).getRGB());
                        Gui.drawRect((double)(x + 7), (double)(y + 13), (double)(x + 7) + healthLocation, (double)(y + 15), new Color(47, 190, 130).getRGB());
                        Gui.drawRect((double)(x + 7), (double)(y + 18), (double)(x + 23) + this.rect, (double)(y + 20), new Color(50, 50, 50).getRGB());
                        Gui.drawRect((double)(x + 7), (double)(y + 18), (double)(x + 7) + this.r2, (double)(y + 20), new Color(87, 130, 189).getRGB());
                    }
                }
            }
        }
    }

    @Override
    public void onEnable() {
        this.animAlpha = 0;
        this.startAnim = false;
        this.stopAnim = false;
        this.astolfoHelathAnim = 0.0f;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    private double getIncremental(double val, double inc) {
        double one = 1.0 / inc;
        return (double)Math.round(val * one) / one;
    }

    public static int[] getFractionIndicies(float[] fractions, float progress) {
        int[] range = new int[2];
        int startPoint = 0;
        while (startPoint < fractions.length && fractions[startPoint] <= progress) {
            ++startPoint;
        }
        if (startPoint >= fractions.length) {
            startPoint = fractions.length - 1;
        }
        range[0] = startPoint - 1;
        range[1] = startPoint;
        return range;
    }

    private int getWidth(EntityLivingBase target) {
        return 38 + this.font.getStringWidth(target.getName());
    }

    private void Background(EntityLivingBase target) {
        ScaledResolution res = new ScaledResolution(mc);
        int x = ScaledResolution.getScaledWidth() / 2 + 30;
        int y = ScaledResolution.getScaledHeight() / 2 - 5;
        double hea = target.getHealth();
        double f1 = new BigDecimal(hea).setScale(1, 4).doubleValue();
        if (FontLoaders.GoogleSans18.getStringWidth(target.getName()) > FontLoaders.Comfortaa14.getStringWidth("Health:" + f1)) {
            this.rect = FontLoaders.GoogleSans18.getStringWidth(target.getName());
        }
        if (FontLoaders.GoogleSans18.getStringWidth(target.getName()) == FontLoaders.Comfortaa14.getStringWidth("Health:" + f1)) {
            this.rect = FontLoaders.GoogleSans18.getStringWidth(target.getName());
        }
        if (FontLoaders.GoogleSans18.getStringWidth(target.getName()) < FontLoaders.Comfortaa14.getStringWidth("Health:" + f1)) {
            this.rect = FontLoaders.Comfortaa14.getStringWidth("Health:" + f1);
        }
        RenderUtil.drawFastRoundedRect(x - 2, (float)(y - 12), (int)((double)(x + 25) + this.rect), (float)(y - 20 + 28 + 15), 1.0f, new Color(40, 40, 40, 200).getRGB());
    }

    private void onHead() {
        ScaledResolution res = new ScaledResolution(mc);
        int x = ScaledResolution.getScaledWidth() / 2 + 30;
        int y = ScaledResolution.getScaledHeight() / 2 - 5;
        mc.getTextureManager().bindTexture(((AbstractClientPlayer)KillAura.curTarget).getLocationSkin());
        Gui.drawScaledCustomSizeModalRect(x, y - 10, 8.0f, 8.0f, 8, 8, 20, 20, 64.0f, 64.0f);
    }

    private void onName(EntityLivingBase target) {
        ScaledResolution res = new ScaledResolution(mc);
        int x = ScaledResolution.getScaledWidth() / 2 + 30;
        int y = ScaledResolution.getScaledHeight() / 2 + 30;
        CFontRenderer font2 = FontLoaders.Comfortaa14;
        CFontRenderer font4 = FontLoaders.Comfortaa18;
        CFontRenderer font3 = FontLoaders.NovICON11;
        font4.drawStringWithShadow(target.getDisplayName().getFormattedText(), x + 20 + 2, y - 45 + 1, -1);
        double hea = target.getHealth();
        String str1 = String.format("%.1f", hea);
        double f1 = new BigDecimal(hea).setScale(1, 4).doubleValue();
        font2.drawStringWithShadow("", x - 20 + 50 + 2 + 2 + font2.getStringWidth("Health: " + f1), y - 25 + 20 + 6, -1);
        font2.drawStringWithShadow("Health:" + f1, x + 20 + 2, y - 40 + this.font.getStringHeight("") - 2, -1);
        font3.drawString("s", x, y - 30 + this.font.getStringHeight("") - 1, -1);
        font3.drawString("r", x, y - 30 + this.font.getStringHeight("") + 5, -1);
    }

    static enum targetinfoenum {
        Flux,
        Zenith,
        Novoline,
        PowerX;

    }
}

