/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 */
package cn.M1N3S3NS3.Module.Modules.Move;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPacketSend;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import com.mojang.authlib.GameProfile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;

public class Blink
extends Module {
    private EntityOtherPlayerMP blinkEntity;
    private List<Packet> packetList = new ArrayList<Packet>();

    public Blink() {
        super("Blink", new String[]{"blonk"}, ModuleType.Move);
    }

    @Override
    public void onEnable() {
        this.setColor(new Color(200, 100, 200).getRGB());
        if (Minecraft.thePlayer == null) {
            return;
        }
        this.blinkEntity = new EntityOtherPlayerMP(Minecraft.theWorld, new GameProfile(new UUID(69L, 96L), "Blink"));
        this.blinkEntity.inventory = Minecraft.thePlayer.inventory;
        this.blinkEntity.inventoryContainer = Minecraft.thePlayer.inventoryContainer;
        this.blinkEntity.setPositionAndRotation(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ, Minecraft.thePlayer.rotationYaw, Minecraft.thePlayer.rotationPitch);
        this.blinkEntity.rotationYawHead = Minecraft.thePlayer.rotationYawHead;
        Minecraft.theWorld.addEntityToWorld(this.blinkEntity.getEntityId(), this.blinkEntity);
    }

    @EventHandler
    private void onPacketSend(EventPacketSend event) {
        if (EventPacketSend.getPacket() instanceof C0BPacketEntityAction || EventPacketSend.getPacket() instanceof C03PacketPlayer || EventPacketSend.getPacket() instanceof C02PacketUseEntity || EventPacketSend.getPacket() instanceof C0APacketAnimation || EventPacketSend.getPacket() instanceof C08PacketPlayerBlockPlacement) {
            this.packetList.add(EventPacketSend.getPacket());
            event.setCancelled(true);
        }
    }

    @Override
    public void onDisable() {
        for (Packet packet : this.packetList) {
            mc.getNetHandler().addToSendQueue(packet);
        }
        this.packetList.clear();
        Minecraft.theWorld.removeEntityFromWorld(this.blinkEntity.getEntityId());
    }
}

