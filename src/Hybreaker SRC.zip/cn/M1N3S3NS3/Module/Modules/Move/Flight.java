/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventMove;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.MovementUtils;
import java.awt.Color;
import net.minecraft.client.Minecraft;

public class Flight
extends Module {
    private static Numbers<Double> motionspeed = new Numbers<Double>("MotionSpeed", "MotionSpeed", 1.0, 0.0, 10.0, 0.1);
    private static Numbers<Double> Mupspeed = new Numbers<Double>("MotiUpSpeed", "MotiUpSpeed", 0.6, 0.0, 1.0, 0.1);
    private double distance;
    private double flyHeight;
    private double moveSpeed;

    public Flight() {
        super("MwFlight", new String[]{"MwFlight"}, ModuleType.Move);
        this.setColor(new Color(158, 114, 243).getRGB());
        this.addValues(motionspeed);
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
    }

    @EventHandler
    private void onMove(EventPreUpdate e) {
        Minecraft.thePlayer.onGround = false;
        Minecraft.thePlayer.motionY = Minecraft.thePlayer.movementInput.jump ? 1.5 : (Minecraft.thePlayer.movementInput.sneak ? -1.5 : 0.0);
    }

    @EventHandler
    private void onMove(EventMove e) {
        MovementUtils.setSpeed(e, (Double)motionspeed.getValue(), 1.0);
    }
}

