/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move.Utils;

import cn.M1N3S3NS3.API.Events.World.EventMove;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.Module.Modules.Move.Utils.Position;
import cn.M1N3S3NS3.Util.Wrapper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockIce;
import net.minecraft.block.BlockPackedIce;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;

public class MoveUtils {
    public static final double BUNNY_SLOPE = 0.66;
    public static final double WATCHDOG_BUNNY_SLOPE = 0.6336;
    public static final double SPRINTING_MOD = 1.3;
    public static final double ICE_MOD = 2.5;
    public static final List<Double> frictionValues = new ArrayList<Double>();
    public static final double MIN_DIF = 1.0E-4;
    public static final double MAX_DIST = 2.1498999999999997;
    public static final double WALK_SPEED = 0.221;
    public static final double SWIM_MOD = 0.5203619909502263;
    public static final double[] DEPTH_STRIDER_VALUES = new double[]{1.0, 1.4304347826086956, 1.734782608695652, 1.9217391304347824};
    public static final double SNEAKING_MOD = 0.5882352941176471;
    public static final double AIR_FRICTION = 0.98;
    public static final double WATER_FRICTION = 0.89;
    public static final double LAVA_FRICTION = 0.535;
    public static final double BUNNY_DIV_FRICTION = 159.9999;
    public static Minecraft mc = Minecraft.getMinecraft();

    public static boolean isInLiquid() {
        return Wrapper.getPlayer().isInWater() || Wrapper.getPlayer().isInLava();
    }

    public static double getJumpHeight() {
        double baseJumpHeight = 0.42f;
        if (MoveUtils.isInLiquid()) {
            return 0.13500000163912773;
        }
        if (Wrapper.getPlayer().isPotionActive(Potion.jump)) {
            return baseJumpHeight + (double)(((float)Wrapper.getPlayer().getActivePotionEffect(Potion.jump).getAmplifier() + 1.0f) * 0.1f);
        }
        return baseJumpHeight;
    }

    public static int getJumpBoostModifier() {
        PotionEffect effect = Wrapper.getPlayer().getActivePotionEffect(Potion.jump);
        if (effect != null) {
            return effect.getAmplifier() + 1;
        }
        return 0;
    }

    public static double calculateFriction(double moveSpeed, double lastDist, double baseMoveSpeedRef) {
        frictionValues.clear();
        frictionValues.add(lastDist - lastDist / 159.9999985);
        frictionValues.add(lastDist - (moveSpeed - lastDist) / 33.3);
        double materialFriction = Wrapper.getPlayer().isInWater() ? (double)0.89f : (Wrapper.getPlayer().isInLava() ? (double)0.535f : (double)0.98f);
        frictionValues.add(lastDist - baseMoveSpeedRef * (1.0 - materialFriction));
        return Collections.min(frictionValues);
    }

    public static boolean isOnIce() {
        EntityPlayerSP player = Wrapper.getPlayer();
        Block blockUnder = Wrapper.getWorld().getBlockState(new BlockPos(player.posX, player.posY - 1.0, player.posZ)).getBlock();
        return blockUnder instanceof BlockIce || blockUnder instanceof BlockPackedIce;
    }

    public static boolean isOnGround() {
        return Wrapper.getPlayer().onGround && Wrapper.getPlayer().isCollidedVertically;
    }

    public static double defaultSpeed() {
        double baseSpeed = 0.2873;
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            Minecraft.getMinecraft();
            int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return baseSpeed;
    }

    public static BlockPos getHypixelBlockpos(String str) {
        int val = 89;
        if (str != null && str.length() > 1) {
            char[] chs = str.toCharArray();
            int lenght = chs.length;
            int i = 0;
            while (i < lenght) {
                val += chs[i] * str.length() * str.length() + str.charAt(0) + str.charAt(1);
                ++i;
            }
            val /= str.length();
        }
        return new BlockPos(val, -val % 255, val);
    }

    public static void setTpSpeedAndUpdate(double speed) {
        double dX = -Math.sin(MoveUtils.getDirection()) * speed;
        double dZ = Math.cos(MoveUtils.getDirection()) * speed;
        Minecraft.thePlayer.setPositionAndUpdate(Minecraft.thePlayer.posX + dX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ + dZ);
    }

    public static void setX(double x) {
        MoveUtils.setPos(x, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ);
    }

    public static void setZ(double z) {
        MoveUtils.setPos(Minecraft.thePlayer.posX, 0.0, Minecraft.thePlayer.posZ);
    }

    public static void setY(double y) {
        MoveUtils.setPos(Minecraft.thePlayer.posX, y, Minecraft.thePlayer.posZ);
    }

    public static void setSpeed(EventPreUpdate moveEvent, double moveSpeed, float pseudoYaw, double pseudoStrafe, double pseudoForward) {
        double forward = pseudoForward;
        double strafe = pseudoStrafe;
        float yaw = pseudoYaw;
        if (pseudoForward != 0.0) {
            if (pseudoStrafe > 0.0) {
                yaw = pseudoYaw + (float)(pseudoForward > 0.0 ? -45 : 45);
            } else if (pseudoStrafe < 0.0) {
                yaw = pseudoYaw + (float)(pseudoForward > 0.0 ? 45 : -45);
            }
            strafe = 0.0;
            if (pseudoForward > 0.0) {
                forward = 1.0;
            } else if (pseudoForward < 0.0) {
                forward = -1.0;
            }
        }
        if (strafe > 0.0) {
            strafe = 1.0;
        } else if (strafe < 0.0) {
            strafe = -1.0;
        }
        double mx = Math.cos(Math.toRadians(yaw + 90.0f));
        double mz = Math.sin(Math.toRadians(yaw + 90.0f));
        Minecraft.thePlayer.motionX = forward * moveSpeed * mx + strafe * moveSpeed * mz;
        moveEvent.setX(Minecraft.thePlayer.motionX);
        Minecraft.thePlayer.motionZ = forward * moveSpeed * mz - strafe * moveSpeed * mx;
        moveEvent.setZ(Minecraft.thePlayer.motionZ);
    }

    public static void setSpeed(EventMove moveEvent, double moveSpeed, float pseudoYaw, double pseudoStrafe, double pseudoForward) {
        double forward = pseudoForward;
        double strafe = pseudoStrafe;
        float yaw = pseudoYaw;
        if (pseudoForward != 0.0) {
            if (pseudoStrafe > 0.0) {
                yaw = pseudoYaw + (float)(pseudoForward > 0.0 ? -45 : 45);
            } else if (pseudoStrafe < 0.0) {
                yaw = pseudoYaw + (float)(pseudoForward > 0.0 ? 45 : -45);
            }
            strafe = 0.0;
            if (pseudoForward > 0.0) {
                forward = 1.0;
            } else if (pseudoForward < 0.0) {
                forward = -1.0;
            }
        }
        if (strafe > 0.0) {
            strafe = 1.0;
        } else if (strafe < 0.0) {
            strafe = -1.0;
        }
        double mx = Math.cos(Math.toRadians(yaw + 90.0f));
        double mz = Math.sin(Math.toRadians(yaw + 90.0f));
        Minecraft.thePlayer.motionX = forward * moveSpeed * mx + strafe * moveSpeed * mz;
        Minecraft.thePlayer.motionZ = forward * moveSpeed * mz - strafe * moveSpeed * mx;
    }

    public static void setSpeed(EventMove moveEvent, double moveSpeed) {
        MoveUtils.setSpeed(moveEvent, moveSpeed, Minecraft.thePlayer.rotationYaw, (double)MovementInput.moveStrafe, (double)MovementInput.moveForward);
    }

    public static Position findInBetween(Position a, Position b) {
        return new Position(a.getX() + (b.getX() - a.getX()) / 2.0, a.getY() + (b.getY() - a.getY()) / 2.0, a.getZ() + (b.getZ() - a.getZ()) / 2.0);
    }

    public static void strafe(double speed) {
        float a = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180);
        float l = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180) - 4.712389f;
        float r = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180) + 4.712389f;
        float rf = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180) + 0.5969026f;
        float lf = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180) + -0.5969026f;
        float lb = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180) - 2.3876104f;
        float rb = Minecraft.thePlayer.rotationYaw * ((float)Math.PI / 180) - -2.3876104f;
        if (MoveUtils.mc.gameSettings.keyBindForward.pressed) {
            if (MoveUtils.mc.gameSettings.keyBindLeft.pressed && !MoveUtils.mc.gameSettings.keyBindRight.pressed) {
                Minecraft.thePlayer.motionX -= (double)MathHelper.sin(lf) * speed;
                Minecraft.thePlayer.motionZ += (double)MathHelper.cos(lf) * speed;
            } else if (MoveUtils.mc.gameSettings.keyBindRight.pressed && !MoveUtils.mc.gameSettings.keyBindLeft.pressed) {
                Minecraft.thePlayer.motionX -= (double)MathHelper.sin(rf) * speed;
                Minecraft.thePlayer.motionZ += (double)MathHelper.cos(rf) * speed;
            } else {
                Minecraft.thePlayer.motionX -= (double)MathHelper.sin(a) * speed;
                Minecraft.thePlayer.motionZ += (double)MathHelper.cos(a) * speed;
            }
        } else if (MoveUtils.mc.gameSettings.keyBindBack.pressed) {
            if (MoveUtils.mc.gameSettings.keyBindLeft.pressed && !MoveUtils.mc.gameSettings.keyBindRight.pressed) {
                Minecraft.thePlayer.motionX -= (double)MathHelper.sin(lb) * speed;
                Minecraft.thePlayer.motionZ += (double)MathHelper.cos(lb) * speed;
            } else if (MoveUtils.mc.gameSettings.keyBindRight.pressed && !MoveUtils.mc.gameSettings.keyBindLeft.pressed) {
                Minecraft.thePlayer.motionX -= (double)MathHelper.sin(rb) * speed;
                Minecraft.thePlayer.motionZ += (double)MathHelper.cos(rb) * speed;
            } else {
                Minecraft.thePlayer.motionX += (double)MathHelper.sin(a) * speed;
                Minecraft.thePlayer.motionZ -= (double)MathHelper.cos(a) * speed;
            }
        } else if (MoveUtils.mc.gameSettings.keyBindLeft.pressed && !MoveUtils.mc.gameSettings.keyBindRight.pressed && !MoveUtils.mc.gameSettings.keyBindForward.pressed && !MoveUtils.mc.gameSettings.keyBindBack.pressed) {
            Minecraft.thePlayer.motionX += (double)MathHelper.sin(l) * speed;
            Minecraft.thePlayer.motionZ -= (double)MathHelper.cos(l) * speed;
        } else if (MoveUtils.mc.gameSettings.keyBindRight.pressed && !MoveUtils.mc.gameSettings.keyBindLeft.pressed && !MoveUtils.mc.gameSettings.keyBindForward.pressed && !MoveUtils.mc.gameSettings.keyBindBack.pressed) {
            Minecraft.thePlayer.motionX += (double)MathHelper.sin(r) * speed;
            Minecraft.thePlayer.motionZ -= (double)MathHelper.cos(r) * speed;
        }
    }

    public static void setMotion(double speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            Minecraft.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f));
            Minecraft.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f));
        }
    }

    public static void setMotion(EventMove event, double speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            Minecraft.thePlayer.motionX = 0.0;
            event.setX(0.0);
            Minecraft.thePlayer.motionZ = 0.0;
            event.setZ(0.0);
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            Minecraft.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f));
            event.setX(Minecraft.thePlayer.motionX);
            Minecraft.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f));
            event.setZ(Minecraft.thePlayer.motionZ);
        }
    }

    public static boolean checkTeleport(double x, double y, double z, double distBetweenPackets) {
        double distx = Minecraft.thePlayer.posX - x;
        double disty = Minecraft.thePlayer.posY - y;
        double distz = Minecraft.thePlayer.posZ - z;
        double dist = Math.sqrt(Minecraft.thePlayer.getDistanceSq(x, y, z));
        double distanceEntreLesPackets = distBetweenPackets;
        double nbPackets = Math.round(dist / distanceEntreLesPackets + 0.49999999999) - 1L;
        double xtp = Minecraft.thePlayer.posX;
        double ytp = Minecraft.thePlayer.posY;
        double ztp = Minecraft.thePlayer.posZ;
        int i = 1;
        while ((double)i < nbPackets) {
            AxisAlignedBB bb;
            double xdi = (x - Minecraft.thePlayer.posX) / nbPackets;
            double ydi = (y - Minecraft.thePlayer.posY) / nbPackets;
            double zdi = (z - Minecraft.thePlayer.posZ) / nbPackets;
            if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb = new AxisAlignedBB((xtp += xdi) - 0.3, ytp += ydi, (ztp += zdi) - 0.3, xtp + 0.3, ytp + 1.8, ztp + 0.3)).isEmpty()) {
                return false;
            }
            ++i;
        }
        return true;
    }

    public static boolean isOnGround(double height) {
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, -height, 0.0)).isEmpty();
    }

    public static int getJumpEffect() {
        if (Minecraft.thePlayer.isPotionActive(Potion.jump)) {
            return Minecraft.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1;
        }
        return 0;
    }

    public static int getSpeedEffect() {
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            return Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1;
        }
        return 0;
    }

    public static Block getBlockUnderPlayer(EntityPlayer inPlayer, double height) {
        Minecraft.getMinecraft();
        return Minecraft.theWorld.getBlockState(new BlockPos(inPlayer.posX, inPlayer.posY - height, inPlayer.posZ)).getBlock();
    }

    public static Block getBlockAtPosC(double x, double y, double z) {
        Minecraft.getMinecraft();
        EntityPlayerSP inPlayer = Minecraft.thePlayer;
        Minecraft.getMinecraft();
        return Minecraft.theWorld.getBlockState(new BlockPos(inPlayer.posX + x, inPlayer.posY + y, inPlayer.posZ + z)).getBlock();
    }

    public static float getDistanceToGround(Entity e) {
        if (Minecraft.thePlayer.isCollidedVertically && Minecraft.thePlayer.onGround) {
            return 0.0f;
        }
        float a = (float)e.posY;
        while (a > 0.0f) {
            int[] stairs = new int[]{53, 67, 108, 109, 114, 128, 134, 135, 136, 156, 163, 164, 180};
            int[] exemptIds = new int[]{6, 27, 28, 30, 31, 32, 37, 38, 39, 40, 50, 51, 55, 59, 63, 65, 66, 68, 69, 70, 72, 75, 76, 77, 83, 92, 93, 94, 104, 105, 106, 115, 119, 131, 132, 143, 147, 148, 149, 150, 157, 171, 175, 176, 177};
            Block block = Minecraft.theWorld.getBlockState(new BlockPos(e.posX, a - 1.0f, e.posZ)).getBlock();
            if (!(block instanceof BlockAir)) {
                int id;
                if (Block.getIdFromBlock(block) == 44 || Block.getIdFromBlock(block) == 126) {
                    return (float)(e.posY - (double)a - 0.5) < 0.0f ? 0.0f : (float)(e.posY - (double)a - 0.5);
                }
                int[] arrayOfInt1 = stairs;
                int j = stairs.length;
                int i = 0;
                while (i < j) {
                    id = arrayOfInt1[i];
                    if (Block.getIdFromBlock(block) == id) {
                        return (float)(e.posY - (double)a - 1.0) < 0.0f ? 0.0f : (float)(e.posY - (double)a - 1.0);
                    }
                    ++i;
                }
                arrayOfInt1 = exemptIds;
                j = exemptIds.length;
                i = 0;
                while (i < j) {
                    id = arrayOfInt1[i];
                    if (Block.getIdFromBlock(block) == id) {
                        return (float)(e.posY - (double)a) < 0.0f ? 0.0f : (float)(e.posY - (double)a);
                    }
                    ++i;
                }
                return (float)(e.posY - (double)a + block.getBlockBoundsMaxY() - 1.0);
            }
            a -= 1.0f;
        }
        return 0.0f;
    }

    public static float[] getRotationsBlock(BlockPos block, EnumFacing face) {
        double x = (double)block.getX() + 0.5 - Minecraft.thePlayer.posX + (double)face.getFrontOffsetX() / 2.0;
        double z = (double)block.getZ() + 0.5 - Minecraft.thePlayer.posZ + (double)face.getFrontOffsetZ() / 2.0;
        double y = (double)block.getY() + 0.5;
        double d1 = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight() - y;
        double d3 = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float)(Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(Math.atan2(d1, d3) * 180.0 / Math.PI);
        if (yaw < 0.0f) {
            yaw += 360.0f;
        }
        return new float[]{yaw, pitch};
    }

    public static boolean isBlockAboveHead() {
        AxisAlignedBB bb = new AxisAlignedBB(Minecraft.thePlayer.posX - 0.3, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ + 0.3, Minecraft.thePlayer.posX + 0.3, Minecraft.thePlayer.posY + 2.5, Minecraft.thePlayer.posZ - 0.3);
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb).isEmpty();
    }

    public static boolean isCollidedH(double dist) {
        AxisAlignedBB bb = new AxisAlignedBB(Minecraft.thePlayer.posX - 0.3, Minecraft.thePlayer.posY + 2.0, Minecraft.thePlayer.posZ + 0.3, Minecraft.thePlayer.posX + 0.3, Minecraft.thePlayer.posY + 3.0, Minecraft.thePlayer.posZ - 0.3);
        if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(0.3 + dist, 0.0, 0.0)).isEmpty()) {
            return true;
        }
        if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(-0.3 - dist, 0.0, 0.0)).isEmpty()) {
            return true;
        }
        if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(0.0, 0.0, 0.3 + dist)).isEmpty()) {
            return true;
        }
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(0.0, 0.0, -0.3 - dist)).isEmpty();
    }

    public static void setMoveSpeed(EventMove event, double moveSpeed) {
        MovementInput movementInput = Minecraft.thePlayer.movementInput;
        double moveForward = MovementInput.moveForward;
        double moveStrafe = MovementInput.moveStrafe;
        double yaw = Minecraft.thePlayer.rotationYaw;
        if (moveForward == 0.0 && moveStrafe == 0.0) {
            event.setX(0.0);
            event.setZ(0.0);
        } else {
            if (moveStrafe > 0.0) {
                moveStrafe = 1.0;
            } else if (moveStrafe < 0.0) {
                moveStrafe = -1.0;
            }
            if (moveForward != 0.0) {
                if (moveStrafe > 0.0) {
                    yaw += (double)(moveForward > 0.0 ? -45 : 45);
                } else if (moveStrafe < 0.0) {
                    yaw += (double)(moveForward > 0.0 ? 45 : -45);
                }
                moveStrafe = 0.0;
                if (moveForward > 0.0) {
                    moveForward = 1.0;
                } else if (moveForward < 0.0) {
                    moveForward = -1.0;
                }
            }
            double cos = Math.cos(Math.toRadians(yaw + 90.0));
            double sin = Math.sin(Math.toRadians(yaw + 90.0));
            event.setX(moveForward * moveSpeed * cos + moveStrafe * moveSpeed * sin);
            event.setZ(moveForward * moveSpeed * sin - moveStrafe * moveSpeed * cos);
        }
    }

    public static boolean isRealCollidedH(double dist) {
        AxisAlignedBB bb = new AxisAlignedBB(Minecraft.thePlayer.posX - 0.3, Minecraft.thePlayer.posY + 0.5, Minecraft.thePlayer.posZ + 0.3, Minecraft.thePlayer.posX + 0.3, Minecraft.thePlayer.posY + 1.9, Minecraft.thePlayer.posZ - 0.3);
        if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(0.3 + dist, 0.0, 0.0)).isEmpty()) {
            return true;
        }
        if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(-0.3 - dist, 0.0, 0.0)).isEmpty()) {
            return true;
        }
        if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(0.0, 0.0, 0.3 + dist)).isEmpty()) {
            return true;
        }
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb.offset(0.0, 0.0, -0.3 - dist)).isEmpty();
    }

    public static double getDirection() {
        float rotationYaw = Minecraft.thePlayer.rotationYaw;
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            rotationYaw += 180.0f;
        }
        float forward = 1.0f;
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else if (Minecraft.thePlayer.moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (Minecraft.thePlayer.moveStrafing > 0.0f) {
            rotationYaw -= 90.0f * forward;
        }
        if (Minecraft.thePlayer.moveStrafing < 0.0f) {
            rotationYaw += 90.0f * forward;
        }
        return Math.toRadians(rotationYaw);
    }

    public static boolean isMoving() {
        block2: {
            block3: {
                if (Minecraft.thePlayer == null) break block2;
                if (MovementInput.moveForward != 0.0f) break block3;
                if (MovementInput.moveStrafe == 0.0f) break block2;
            }
            return true;
        }
        return false;
    }

    public static void strafe(float speed) {
        if (!MoveUtils.isMoving()) {
            return;
        }
        double yaw = MoveUtils.getDirection();
        Minecraft.thePlayer.motionX = -Math.sin(yaw) * (double)speed;
        Minecraft.thePlayer.motionZ = Math.cos(yaw) * (double)speed;
    }

    public static void strafe() {
        MoveUtils.strafe(MoveUtils.getSpeed());
    }

    public static float getSpeed() {
        return (float)Math.sqrt(Minecraft.thePlayer.motionX * Minecraft.thePlayer.motionX + Minecraft.thePlayer.motionZ * Minecraft.thePlayer.motionZ);
    }

    public static float getSpeed(EntityLivingBase e) {
        return (float)Math.sqrt((e.posX - e.prevPosX) * (e.posX - e.prevPosX) + (e.posZ - e.prevPosZ) * (e.posZ - e.prevPosZ));
    }

    public static boolean isBlockAbovePlayer() {
        return !(Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.getEntityBoundingBox().maxY + (double)0.42f, Minecraft.thePlayer.posZ)).getBlock() instanceof BlockAir);
    }

    public static void setPos(double x, double y, double z) {
        Minecraft.thePlayer.setPosition(x, y, z);
    }

    public static void setPosPlus(double x, double y, double z) {
        Minecraft.thePlayer.setPosition(Minecraft.thePlayer.posX + x, Minecraft.thePlayer.posY + y, Minecraft.thePlayer.posZ + z);
    }

    public static void setPosPlusUpdate(double x, double y, double z) {
        Minecraft.thePlayer.setPositionAndUpdate(Minecraft.thePlayer.posX + x, Minecraft.thePlayer.posY + y, Minecraft.thePlayer.posZ + z);
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed = 0.2875;
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            baseSpeed *= 1.0 + 0.2 * (double)(Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1);
        }
        return baseSpeed;
    }

    public static double getJumpBoostModifier(double baseJumpHeight) {
        if (Minecraft.thePlayer.isPotionActive(Potion.jump)) {
            int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier();
            baseJumpHeight += (double)((float)(amplifier + 1) * 0.1f);
        }
        return baseJumpHeight;
    }
}

