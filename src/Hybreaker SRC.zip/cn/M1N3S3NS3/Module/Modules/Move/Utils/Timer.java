/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move.Utils;

import cn.M1N3S3NS3.Command.Command;

public class Timer {
    public long lastMS = System.currentTimeMillis();

    public void reset() {
        this.lastMS = System.currentTimeMillis();
    }

    public boolean hasTimeElapsed(long time, boolean reset) {
        if (this.lastMS > System.currentTimeMillis()) {
            this.lastMS = System.currentTimeMillis();
            Command.sendPrivateChatMessage("Fixed timer, did you set the clock on your pc back or something?");
        }
        if (System.currentTimeMillis() - this.lastMS > time) {
            if (reset) {
                this.reset();
            }
            return true;
        }
        return false;
    }
}

