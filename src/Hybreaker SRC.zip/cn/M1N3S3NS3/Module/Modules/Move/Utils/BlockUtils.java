/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move.Utils;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

public final class BlockUtils {
    public static Minecraft mc = Minecraft.getMinecraft();

    public static final Block getBlock(BlockPos blockPos) {
        IBlockState var1;
        WorldClient var10000 = Minecraft.theWorld;
        if (var10000 != null && (var1 = var10000.getBlockState(blockPos)) != null) {
            Block var2 = var1.getBlock();
            return var2;
        }
        Block var2 = null;
        return var2;
    }

    public static final Material getMaterial(BlockPos blockPos) {
        Block var10000 = BlockUtils.getBlock(blockPos);
        return var10000 != null ? var10000.getMaterial() : null;
    }

    public static final boolean isReplaceable(BlockPos blockPos) {
        Material var10000 = BlockUtils.getMaterial(blockPos);
        return var10000 != null && var10000.isReplaceable();
    }

    public static final IBlockState getState(BlockPos blockPos) {
        IBlockState var10000 = Minecraft.theWorld.getBlockState(blockPos);
        return var10000;
    }

    public static final boolean canBeClicked(BlockPos blockPos) {
        WorldClient var1;
        Block var10000 = BlockUtils.getBlock(blockPos);
        if (var10000 != null && var10000.canCollideCheck(BlockUtils.getState(blockPos), false) && (var1 = Minecraft.theWorld).getWorldBorder().contains(blockPos)) {
            boolean var2 = true;
            return var2;
        }
        boolean var2 = false;
        return var2;
    }

    public static final String getBlockName(int id) {
        Block var10000 = Block.getBlockById(id);
        String var1 = var10000.getLocalizedName();
        return var1;
    }

    public static final boolean isFullBlock(BlockPos blockPos) {
        AxisAlignedBB var2;
        Block var10000 = BlockUtils.getBlock(blockPos);
        if (var10000 != null && (var2 = var10000.getCollisionBoundingBox(Minecraft.theWorld, blockPos, BlockUtils.getState(blockPos))) != null) {
            AxisAlignedBB axisAlignedBB = var2;
            return axisAlignedBB.maxX - axisAlignedBB.minX == 1.0 && axisAlignedBB.maxY - axisAlignedBB.minY == 1.0 && axisAlignedBB.maxZ - axisAlignedBB.minZ == 1.0;
        }
        return false;
    }

    public static final double getCenterDistance(BlockPos blockPos) {
        return Minecraft.thePlayer.getDistance((double)blockPos.getX() + 0.5, (double)blockPos.getY() + 0.5, (double)blockPos.getZ() + 0.5);
    }

    public static final Map searchBlocks(int radius) {
        boolean var2 = false;
        LinkedHashMap<BlockPos, Block> blocks = new LinkedHashMap<BlockPos, Block>();
        int x = radius;
        int var3 = -radius + 1;
        if (radius >= var3) {
            while (true) {
                int y = radius;
                int var5 = -radius + 1;
                if (radius >= var5) {
                    while (true) {
                        int z = radius;
                        int var7 = -radius + 1;
                        if (radius >= var7) {
                            while (true) {
                                BlockPos blockPos;
                                Block var10000;
                                if ((var10000 = BlockUtils.getBlock(blockPos = new BlockPos((int)Minecraft.thePlayer.posX + x, (int)Minecraft.thePlayer.posY + y, (int)Minecraft.thePlayer.posZ + z))) != null) {
                                    Block block = var10000;
                                    blocks.put(blockPos, block);
                                }
                                if (z == var7) break;
                                --z;
                            }
                        }
                        if (y == var5) break;
                        --y;
                    }
                }
                if (x == var3) break;
                --x;
            }
        }
        return blocks;
    }

    public static final boolean collideBlock(AxisAlignedBB axisAlignedBB, Collidable collide) {
        EntityPlayerSP var10000 = Minecraft.thePlayer;
        int x = MathHelper.floor_double(var10000.getEntityBoundingBox().minX);
        var10000 = Minecraft.thePlayer;
        int var3 = MathHelper.floor_double(var10000.getEntityBoundingBox().maxX) + 1;
        while (x < var3) {
            var10000 = Minecraft.thePlayer;
            int z = MathHelper.floor_double(var10000.getEntityBoundingBox().minZ);
            var10000 = Minecraft.thePlayer;
            int var5 = MathHelper.floor_double(var10000.getEntityBoundingBox().maxZ) + 1;
            while (z < var5) {
                Block block = BlockUtils.getBlock(new BlockPos((double)x, axisAlignedBB.minY, (double)z));
                if (!collide.collideBlock(block)) {
                    return false;
                }
                ++z;
            }
            ++x;
        }
        return true;
    }

    public static final boolean collideBlockIntersects(AxisAlignedBB axisAlignedBB, Collidable collide) {
        EntityPlayerSP var10000 = Minecraft.thePlayer;
        int x = MathHelper.floor_double(var10000.getEntityBoundingBox().minX);
        var10000 = Minecraft.thePlayer;
        int var3 = MathHelper.floor_double(var10000.getEntityBoundingBox().maxX) + 1;
        while (x < var3) {
            var10000 = Minecraft.thePlayer;
            int z = MathHelper.floor_double(var10000.getEntityBoundingBox().minZ);
            var10000 = Minecraft.thePlayer;
            int var5 = MathHelper.floor_double(var10000.getEntityBoundingBox().maxZ) + 1;
            while (z < var5) {
                AxisAlignedBB var9;
                BlockPos blockPos = new BlockPos((double)x, axisAlignedBB.minY, (double)z);
                Block block = BlockUtils.getBlock(blockPos);
                if (collide.collideBlock(block) && block != null && (var9 = block.getCollisionBoundingBox(Minecraft.theWorld, blockPos, BlockUtils.getState(blockPos))) != null) {
                    AxisAlignedBB boundingBox = var9;
                    var10000 = Minecraft.thePlayer;
                    if (var10000.getEntityBoundingBox().intersectsWith(boundingBox)) {
                        return true;
                    }
                }
                ++z;
            }
            ++x;
        }
        return false;
    }

    public static interface Collidable {
        public boolean collideBlock(Block var1);
    }
}

