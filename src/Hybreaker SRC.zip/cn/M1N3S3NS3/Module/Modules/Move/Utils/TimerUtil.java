/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move.Utils;

public final class TimerUtil {
    private long time = System.nanoTime() / 1000000L;

    public boolean reach(long time) {
        return this.time() >= time;
    }

    public void reset() {
        this.time = System.nanoTime() / 1000000L;
    }

    public boolean sleep(long time) {
        if (this.time() >= time) {
            this.reset();
            return true;
        }
        return false;
    }

    public short convertToMS(float perSecond) {
        return (short)(1000.0f / perSecond);
    }

    public long time() {
        return System.nanoTime() / 1000000L - this.time;
    }
}

