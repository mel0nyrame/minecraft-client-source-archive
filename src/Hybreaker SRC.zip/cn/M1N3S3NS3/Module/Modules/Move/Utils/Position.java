/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move.Utils;

import net.minecraft.util.MathHelper;

public class Position {
    double x;
    double y;
    double z;

    public Position(double x, double y, double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public double getX() {
        return this.x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return this.y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public double getZ() {
        return this.z;
    }

    public void setZ(double z) {
        this.z = z;
    }

    public float getDistanceToPosition(Position entityIn) {
        float f = (float)(this.getX() - entityIn.getX());
        float f1 = (float)(this.getY() - entityIn.getY());
        float f2 = (float)(this.getZ() - entityIn.getZ());
        return MathHelper.sqrt_float(f * f + f1 * f1 + f2 * f2);
    }
}

