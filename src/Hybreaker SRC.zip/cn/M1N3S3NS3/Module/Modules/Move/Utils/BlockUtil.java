/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move.Utils;

import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;
import net.minecraft.util.Vec3;

public class BlockUtil {
    static Minecraft mc = Minecraft.getMinecraft();

    public static BlockPos getForwardBlock(double length) {
        double yaw = Math.toRadians(Minecraft.thePlayer.rotationYaw);
        BlockPos fPos = new BlockPos(Minecraft.thePlayer.posX + -Math.sin(yaw) * length, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ + Math.cos(yaw) * length);
        return fPos;
    }

    public static boolean canIItemBePlaced(Item item) {
        return Item.getIdFromItem(item) == 116 ? false : (Item.getIdFromItem(item) == 30 ? false : (Item.getIdFromItem(item) == 31 ? false : (Item.getIdFromItem(item) == 175 ? false : (Item.getIdFromItem(item) == 28 ? false : (Item.getIdFromItem(item) == 27 ? false : (Item.getIdFromItem(item) == 66 ? false : (Item.getIdFromItem(item) == 157 ? false : (Item.getIdFromItem(item) == 31 ? false : (Item.getIdFromItem(item) == 6 ? false : (Item.getIdFromItem(item) == 31 ? false : (Item.getIdFromItem(item) == 32 ? false : (Item.getIdFromItem(item) == 140 ? false : (Item.getIdFromItem(item) == 390 ? false : (Item.getIdFromItem(item) == 37 ? false : (Item.getIdFromItem(item) == 38 ? false : (Item.getIdFromItem(item) == 39 ? false : (Item.getIdFromItem(item) == 40 ? false : (Item.getIdFromItem(item) == 69 ? false : (Item.getIdFromItem(item) == 50 ? false : (Item.getIdFromItem(item) == 75 ? false : (Item.getIdFromItem(item) == 76 ? false : (Item.getIdFromItem(item) == 54 ? false : (Item.getIdFromItem(item) == 130 ? false : (Item.getIdFromItem(item) == 146 ? false : (Item.getIdFromItem(item) == 342 ? false : (Item.getIdFromItem(item) == 12 ? false : (Item.getIdFromItem(item) == 77 ? false : (Item.getIdFromItem(item) == 143 ? false : Item.getIdFromItem(item) != 46))))))))))))))))))))))))))));
    }

    public static boolean canItemBePlaced(ItemStack item) {
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 116) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 30) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 31) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 175) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 28) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 27) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 66) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 157) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 31) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 6) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 31) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 32) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 140) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 390) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 37) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 38) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 39) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 40) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 69) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 50) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 75) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 76) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 54) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 130) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 146) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 342) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 12) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 77) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 143) {
            return false;
        }
        item.getItem();
        if (Item.getIdFromItem(item.getItem()) == 46) {
            return false;
        }
        item.getItem();
        return Item.getIdFromItem(item.getItem()) != 145;
    }

    public static int getBlockCount() {
        int blockCount = 0;
        int i = 0;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                Item item = is.getItem();
                if (is.getItem() instanceof ItemBlock && BlockUtil.canIItemBePlaced(item)) {
                    blockCount += is.stackSize;
                }
            }
            ++i;
        }
        return blockCount;
    }

    public static int findBlockSlot() {
        int slot = -1;
        int highestStack = -1;
        int i = 36;
        while (i < 45) {
            ItemStack stack = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (stack != null && stack.getItem() instanceof ItemBlock && BlockUtil.canIItemBePlaced(stack.getItem()) && stack.stackSize > 0 && stack.stackSize > highestStack) {
                slot = i;
                highestStack = stack.stackSize;
            }
            ++i;
        }
        return slot;
    }

    public static float[] getRotations(BlockPos block, EnumFacing face) {
        double x = (double)block.getX() + 0.5 - Minecraft.thePlayer.posX + (double)face.getFrontOffsetX() / 2.0;
        double z = (double)block.getZ() + 0.5 - Minecraft.thePlayer.posZ + (double)face.getFrontOffsetZ() / 2.0;
        double y = (double)block.getY() + 0.5;
        double d1 = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight() - y;
        double d2 = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float)(Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(Math.atan2(d1, d2) * 180.0 / Math.PI);
        if (yaw < 0.0f) {
            yaw += 360.0f;
        }
        return new float[]{yaw, pitch};
    }

    public static int grabBlockSlot() {
        int slot = -1;
        int highestStack = -1;
        boolean didGetHotbar = false;
        int hotbarNum = 0;
        while (hotbarNum < 36) {
            ItemStack itemStack = Minecraft.thePlayer.inventory.mainInventory[hotbarNum];
            if (itemStack != null && itemStack.getItem() instanceof ItemBlock && BlockUtil.canItemBePlaced(itemStack) && itemStack.stackSize > 0) {
                int hotbarNum1;
                if (Minecraft.thePlayer.inventory.mainInventory[hotbarNum].stackSize > highestStack && hotbarNum < 9) {
                    highestStack = Minecraft.thePlayer.inventory.mainInventory[hotbarNum].stackSize;
                    slot = hotbarNum;
                    if (hotbarNum == BlockUtil.getLastHotbarSlot()) {
                        didGetHotbar = true;
                    }
                }
                if (hotbarNum > 8 && !didGetHotbar && (hotbarNum1 = BlockUtil.getFreeHotbarSlot()) != -1 && Minecraft.thePlayer.inventory.mainInventory[hotbarNum].stackSize > highestStack) {
                    highestStack = Minecraft.thePlayer.inventory.mainInventory[hotbarNum].stackSize;
                    slot = hotbarNum;
                }
            }
            ++hotbarNum;
        }
        if (slot > 8) {
            hotbarNum = BlockUtil.getFreeHotbarSlot();
            if (hotbarNum == -1) {
                return -1;
            }
            Minecraft.playerController.windowClick(Minecraft.thePlayer.inventoryContainer.windowId, slot, hotbarNum, 2, Minecraft.thePlayer);
        }
        return slot;
    }

    public static int getLastHotbarSlot() {
        int hotbarNum = -1;
        int k = 0;
        while (k < 9) {
            ItemStack itemStack = Minecraft.thePlayer.inventory.mainInventory[k];
            if (itemStack != null && itemStack.getItem() instanceof ItemBlock && BlockUtil.canItemBePlaced(itemStack) && itemStack.stackSize > 1) {
                hotbarNum = k;
            }
            ++k;
        }
        return hotbarNum;
    }

    public static int getFreeHotbarSlot() {
        int hotbarNum = -1;
        int k = 0;
        while (k < 9) {
            hotbarNum = Minecraft.thePlayer.inventory.mainInventory[k] == null ? k : 7;
            ++k;
        }
        return hotbarNum;
    }

    private Vec3 grabPosition(BlockPos position, EnumFacing facing) {
        Vec3 offset = new Vec3((double)facing.getDirectionVec().getX() / 2.0, (double)facing.getDirectionVec().getY() / 2.0 - 5.0, (double)facing.getDirectionVec().getZ() / 2.0);
        Vec3 point = new Vec3((double)position.getX() + 0.5, (double)position.getY() + 0.5, (double)position.getZ() + 0.5);
        return point.add(offset);
    }

    public static float clampRotation() {
        float rotationYaw = Minecraft.thePlayer.rotationYaw;
        float n = 1.0f;
        if (MovementInput.moveForward < 0.0f) {
            rotationYaw += 180.0f;
            n = -0.5f;
        } else if (MovementInput.moveForward > 0.0f) {
            n = 0.5f;
        }
        if (MovementInput.moveStrafe > 0.0f) {
            rotationYaw -= 90.0f * n;
        }
        if (MovementInput.moveStrafe < 0.0f) {
            rotationYaw += 90.0f * n;
        }
        return rotationYaw * ((float)Math.PI / 180);
    }
}

