/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Events.World.StepEvent;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.PlayerUtil;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.Timer;

public class Step
extends Module {
    private final Option<Boolean> smoothValue = new Option<Boolean>("Smooth", "Step smooth", true);
    private final Option<Boolean> packetValue = new Option<Boolean>("Packet", "Packet step", true);
    private final Numbers<Number> heightValue = new Numbers<Double>("Height", "Just height", 1.0, 1.0, 5.0, 0.1);
    private final Numbers<Number> delayValue = new Numbers<Double>("Delay", "Just delay", 1.0, 1.0, 15.0, 0.1);
    private final TimerUtil timer = new TimerUtil();
    private boolean resetTimer;
    private int groundTicks;

    public Step() {
        super("Step", new String[]{"Step"}, ModuleType.Move);
        this.addValues(this.heightValue, this.delayValue, this.smoothValue, this.packetValue);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.timer.reset();
        this.resetTimer = false;
        this.groundTicks = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @EventHandler
    void onUpdate(EventPreUpdate event) {
        this.setSuffix((Boolean)this.packetValue.getValue() != false ? "Packet" : "");
        this.groundTicks = PlayerUtil.isOnGround(0.01) ? ++this.groundTicks : 0;
        if (this.groundTicks > 20) {
            this.groundTicks = 20;
        }
    }

    @EventHandler
    void onStep(StepEvent event) {
        block17: {
            double y;
            double posZ;
            double posX;
            List<Double> offset;
            Double realHeight;
            block18: {
                if (this.resetTimer) {
                    this.resetTimer = false;
                    Timer.timerSpeed = 1.0f;
                }
                if (event.isPre() && this.canStep() && this.timer.hasPassed((long)((Number)this.delayValue.getValue()).intValue() * 100L)) {
                    event.setStepHeight((Boolean)this.packetValue.getValue() != false ? Math.min(((Number)this.heightValue.getValue()).doubleValue(), 2.5) : ((Number)this.heightValue.getValue()).doubleValue());
                }
                if (!event.isPost()) break block17;
                realHeight = Minecraft.thePlayer.getEntityBoundingBox().minY - Minecraft.thePlayer.posY;
                if (!(realHeight >= 0.625)) {
                    return;
                }
                this.timer.reset();
                if (((Boolean)this.smoothValue.getValue()).booleanValue()) {
                    Timer.timerSpeed = 0.4f - (((Number)realHeight).floatValue() >= 1.0f ? Math.abs(1.0f - ((Number)realHeight).floatValue()) * 0.2f : 0.0f);
                    if (Timer.timerSpeed <= 0.1f) {
                        Timer.timerSpeed = 0.1f;
                    }
                    this.resetTimer = true;
                }
                if (!((Boolean)this.packetValue.getValue()).booleanValue()) break block17;
                offset = Arrays.asList(0.42, 0.333, 0.248, 0.083, -0.078);
                posX = Minecraft.thePlayer.posX;
                posZ = Minecraft.thePlayer.posZ;
                y = Minecraft.thePlayer.posY;
                if (!(realHeight < 1.1)) break block18;
                double first = 0.42;
                double second = 0.75;
                if (realHeight != 1.0) {
                    first *= ((Number)realHeight).doubleValue();
                    second *= ((Number)realHeight).doubleValue();
                    if (first > 0.425) {
                        first = 0.425;
                    }
                    if (second > 0.78) {
                        second = 0.78;
                    }
                    if (second < 0.49) {
                        second = 0.49;
                    }
                }
                if (first == 0.42) {
                    first = 0.41999998688698;
                }
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, y + first, posZ, false));
                if (!(y + second < y + realHeight)) break block17;
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, y + second, posZ, false));
                break block17;
            }
            if (realHeight < 1.6) {
                for (double off : offset) {
                    Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, y += off, posZ, false));
                }
            } else if (realHeight < 2.1) {
                double[] heights;
                double[] dArray = heights = new double[]{0.425, 0.821, 0.699, 0.599, 1.022, 1.372, 1.652, 1.869};
                int n = heights.length;
                int n2 = 0;
                while (n2 < n) {
                    double off = dArray[n2];
                    Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, y + off, posZ, false));
                    ++n2;
                }
            } else {
                double[] heights;
                double[] dArray = heights = new double[]{0.425, 0.821, 0.699, 0.599, 1.022, 1.372, 1.652, 1.869, 2.019, 1.907};
                int n = heights.length;
                int n3 = 0;
                while (n3 < n) {
                    double off = dArray[n3];
                    Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, y + off, posZ, false));
                    ++n3;
                }
            }
        }
    }

    private boolean canStep() {
        if (this.groundTicks > 3) {
            if (Minecraft.thePlayer.isCollidedVertically && !Step.mc.gameSettings.keyBindJump.pressed && !PlayerUtil.isInLiquid()) {
                return true;
            }
        }
        return false;
    }
}

