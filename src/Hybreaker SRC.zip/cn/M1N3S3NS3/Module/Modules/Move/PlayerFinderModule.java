/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 */
package cn.M1N3S3NS3.Module.Modules.Move;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Misc.EntityAddedEvent;
import cn.M1N3S3NS3.API.Events.World.EventPacketReceive;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.Chat.Helper;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.event.ClickEvent;
import net.minecraft.event.HoverEvent;
import net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatStyle;
import net.minecraft.util.EnumChatFormatting;

public class PlayerFinderModule
extends Module {
    private static String[] q;
    public static PlayerFinderModule a12;
    public Option Thunder2 = new Option<Boolean>("Thunder2", "Thunder2", true);
    public Option Thunder = new Option<Boolean>("Thunder", "Thunder", true);
    public Option Player = new Option<Boolean>("Player", "Player", true);

    public PlayerFinderModule() {
        super("LightBoltSearcher", new String[]{"PlayerFinder"}, ModuleType.Player);
        String[] v2 = q;
        this.addValues(this.Thunder2, this.Thunder, this.Player);
    }

    public boolean isNCPBot(Entity v1) {
        if (this.isEnabled()) {
            String formattedText = v1.getDisplayName().getFormattedText();
            StringBuilder append = new StringBuilder().append(v1.getName());
            String[] v2 = q;
            if (formattedText.equalsIgnoreCase(append.append("\u00a7r").toString()) && v1.getDisplayName().getFormattedText().contains("NPC")) {
                return true;
            }
        }
        return false;
    }

    @EventHandler
    public void onPacketReceive(EventPacketReceive packetEvent) {
        S2CPacketSpawnGlobalEntity packetIn;
        if (((Boolean)this.Thunder2.getValue()).booleanValue() && EventPacketReceive.getPacket() instanceof S2CPacketSpawnGlobalEntity && (packetIn = (S2CPacketSpawnGlobalEntity)EventPacketReceive.getPacket()).func_149053_g() == 1) {
            int x = packetIn.func_149051_d() / 32;
            int y = packetIn.func_149050_e() / 32;
            int z = packetIn.func_149049_f() / 32;
            ChatComponentText ChatComponent = new ChatComponentText(String.format("%s%s", ChatFormatting.GREEN + Client.name + " > \u96f7\u58f0\u5b9a\u4f4d" + ChatFormatting.GRAY, ChatFormatting.GOLD + " [" + x + "," + y + "," + z + "]"));
            ChatComponent.appendSibling(new ChatComponentText((Object)((Object)EnumChatFormatting.RED) + " [\u70b9\u6211tp\u5230\u8be5\u4f4d\u7f6e]").setChatStyle(new ChatStyle().setChatClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, new StringBuilder().insert(0, ".tp " + x + " " + y + " " + z).toString())).setChatHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ChatComponentText("[\u70b9\u6211tp\u5230\u8be5\u4f4d\u7f6e]")))));
            Minecraft.thePlayer.addChatMessage(ChatComponent);
        }
    }

    @EventHandler
    public void leishen(EventPacketReceive event) {
        if (((Boolean)this.Thunder.getValue()).booleanValue()) {
            StringBuilder append = new StringBuilder().append((Object)EnumChatFormatting.DARK_GRAY).append("[").append((Object)EnumChatFormatting.DARK_AQUA);
            if (EventPacketReceive.getPacket() instanceof S2CPacketSpawnGlobalEntity) {
                if (EventPacketReceive.getPacket() != Minecraft.thePlayer) {
                    if (Minecraft.theWorld.getEntityByID(((S2CPacketSpawnGlobalEntity)EventPacketReceive.getPacket()).func_149052_c()) instanceof EntityLightningBolt) {
                        Helper.sendMessage(append.append("Notifier").append((Object)EnumChatFormatting.DARK_GRAY).append("] ").append((Object)EnumChatFormatting.DARK_AQUA).append("Name: ").append((Object)EnumChatFormatting.WHITE).append(((S2CPacketSpawnGlobalEntity)EventPacketReceive.getPacket()).func_149052_c()).append(" ").append((Object)EnumChatFormatting.DARK_AQUA).append("Coords: ").append((Object)EnumChatFormatting.AQUA).append("X: ").append((Object)EnumChatFormatting.WHITE).append(((S2CPacketSpawnGlobalEntity)EventPacketReceive.getPacket()).func_149051_d()).append((Object)EnumChatFormatting.AQUA).append(" Y: ").append((Object)EnumChatFormatting.WHITE).append(((S2CPacketSpawnGlobalEntity)EventPacketReceive.getPacket()).func_149050_e()).append((Object)EnumChatFormatting.AQUA).append(" Z: ").append((Object)EnumChatFormatting.WHITE).append(((S2CPacketSpawnGlobalEntity)EventPacketReceive.getPacket()).func_149049_f()).toString());
                    }
                }
            }
        }
    }

    @EventHandler
    public void onEntityAdded(EntityAddedEvent v1) {
        if (((Boolean)this.Player.getValue()).booleanValue() && v1.getEntity() instanceof EntityPlayer) {
            if (v1.getEntity() != Minecraft.thePlayer && !this.isNCPBot(v1.getEntity())) {
                String formattedText = v1.getEntity().getDisplayName().getFormattedText();
                String[] v2 = q;
                if (!formattedText.contains("[NPC]")) {
                    StringBuilder sb = new StringBuilder();
                    v2 = q;
                    Helper.sendMessage(sb.append("target detected: ").append(v1.getEntity().getName()).toString());
                }
                StringBuilder append = new StringBuilder().append((Object)EnumChatFormatting.DARK_GRAY).append("[").append((Object)EnumChatFormatting.DARK_AQUA);
                v2 = q;
                Helper.sendMessage(append.append("Notifier").append((Object)EnumChatFormatting.DARK_GRAY).append("] ").append((Object)EnumChatFormatting.DARK_AQUA).append("Name: ").append((Object)EnumChatFormatting.WHITE).append(v1.getEntity().getDisplayName().getFormattedText()).append(" ").append((Object)EnumChatFormatting.DARK_AQUA).append("Coords: ").append((Object)EnumChatFormatting.AQUA).append("X: ").append((Object)EnumChatFormatting.WHITE).append((int)v1.getEntity().posX).append((Object)EnumChatFormatting.AQUA).append(" Y: ").append((Object)EnumChatFormatting.WHITE).append((int)v1.getEntity().posY).append((Object)EnumChatFormatting.AQUA).append(" Z: ").append((Object)EnumChatFormatting.WHITE).append((int)v1.getEntity().posZ).toString());
                q = new String[]{"Name: ", "alert you if player in your chunks", "Notifier", " Z: ", "\u00a7r", "X: ", "target detected: ", "NPC", "] ", "[NPC]", " Y: ", "Coords: "};
            }
        }
    }
}

