/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package cn.M1N3S3NS3.Module.Modules.Move;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.GuiCloseEvent;
import cn.M1N3S3NS3.API.Events.World.EventPacket;
import cn.M1N3S3NS3.API.Events.World.LivingUpdateEvent;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.MovementUtils;
import java.awt.Color;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.play.client.C0EPacketClickWindow;
import org.lwjgl.input.Keyboard;

public class InvMove
extends Module {
    public static Option<Boolean> Cancel = new Option<Boolean>("Cancel", "Cancel", Boolean.TRUE);
    boolean inInventory = false;
    public static Option<Boolean> inventory = new Option<Boolean>("Only inventory", "Only inventory", Boolean.FALSE);

    public InvMove() {
        super("InvWalk", new String[]{"InvMove", "crit"}, ModuleType.Move);
        this.setColor(new Color(235, 194, 138).getRGB());
        this.addValues(Cancel, inventory);
    }

    @Override
    public void onDisable() {
    }

    @EventHandler
    public void onLivingUpdate(LivingUpdateEvent event) {
        if (InvMove.mc.currentScreen instanceof GuiChat || !(InvMove.mc.currentScreen instanceof GuiInventory) && ((Boolean)inventory.getValue()).booleanValue()) {
            return;
        }
        if (InvMove.mc.currentScreen != null) {
            this.checkKeys();
        }
    }

    @EventHandler
    public void onGuiClose(GuiCloseEvent event) {
        if (InvMove.mc.currentScreen instanceof GuiChat || !(InvMove.mc.currentScreen instanceof GuiInventory) && ((Boolean)inventory.getValue()).booleanValue()) {
            return;
        }
        this.checkKeys();
    }

    private void checkKeys() {
        KeyBinding[] keys;
        KeyBinding[] keyBindingArray = keys = new KeyBinding[]{InvMove.mc.gameSettings.keyBindForward, InvMove.mc.gameSettings.keyBindRight, InvMove.mc.gameSettings.keyBindBack, InvMove.mc.gameSettings.keyBindLeft, InvMove.mc.gameSettings.keyBindJump};
        int n = keys.length;
        int n2 = 0;
        while (n2 < n) {
            KeyBinding key = keyBindingArray[n2];
            KeyBinding.setKeyBindState(key.getKeyCode(), Keyboard.isKeyDown((int)key.getKeyCode()));
            ++n2;
        }
    }

    @EventHandler
    public void onmove(EventPacket ep) {
        if (((Boolean)Cancel.getValue()).booleanValue() && InvMove.mc.currentScreen instanceof GuiInventory) {
            if (!MovementUtils.isMoving()) {
                return;
            }
            if (ep.isOutgoing() && ep.getPacket() instanceof C0EPacketClickWindow) {
                ep.setCancelled(true);
            }
        }
    }
}

