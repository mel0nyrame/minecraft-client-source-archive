/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Misc.EventCollideWithBlock;
import cn.M1N3S3NS3.API.Events.World.EventMove;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Move.Speed;
import cn.M1N3S3NS3.Util.PlayerUtil;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;

public class Jesus
extends Module {
    int stage;
    int water;
    private TimerUtil timer = new TimerUtil();
    public static int Delay = 0;
    boolean getDown;
    private boolean wasWater;
    private int ticks = 0;
    public static boolean Jesuss = false;
    private Mode<Enum> mode = new Mode("Mode", "Mode", (Enum[])JMode.values(), (Enum)JMode.Dolphin);
    private static Numbers<Double> SpeedMode = new Numbers<Double>("Speed", "Speed", 0.2073, 0.05, 0.2999, 1.0E-4);

    public Jesus() {
        super("Jesus", new String[]{"waterwalk", "float"}, ModuleType.Move);
        this.setColor(new Color(188, 233, 248).getRGB());
        this.addValues(this.mode, SpeedMode);
    }

    @Override
    public void onEnable() {
        this.wasWater = false;
        super.onEnable();
    }

    private boolean canJeboos() {
        if (!(Minecraft.thePlayer.fallDistance >= 3.0f || Jesus.mc.gameSettings.keyBindJump.isPressed() || PlayerUtil.isInLiquid())) {
            if (!Minecraft.thePlayer.isSneaking()) {
                return true;
            }
        }
        return false;
    }

    boolean shouldJesus() {
        double x = Minecraft.thePlayer.posX;
        double y = Minecraft.thePlayer.posY;
        double z = Minecraft.thePlayer.posZ;
        ArrayList<BlockPos> pos = new ArrayList<BlockPos>(Arrays.asList(new BlockPos(x + 0.3, y, z + 0.3), new BlockPos(x - 0.3, y, z + 0.3), new BlockPos(x + 0.3, y, z - 0.3), new BlockPos(x - 0.3, y, z - 0.3)));
        for (BlockPos po : pos) {
            if (!(Minecraft.theWorld.getBlockState(po).getBlock() instanceof BlockLiquid)) continue;
            if (!(Minecraft.theWorld.getBlockState(po).getProperties().get((Object)BlockLiquid.LEVEL) instanceof Integer)) continue;
            if ((Integer)((Comparable)Minecraft.theWorld.getBlockState(po).getProperties().get((Object)BlockLiquid.LEVEL)) > 4) continue;
            return true;
        }
        return false;
    }

    private boolean isInLiquid() {
        if (Minecraft.thePlayer == null) {
            return false;
        }
        int x = MathHelper.floor_double(Minecraft.thePlayer.boundingBox.minX);
        int n;
        block0: while ((n = ++x) < MathHelper.floor_double(Minecraft.thePlayer.boundingBox.maxX) + 1) {
            int z = MathHelper.floor_double(Minecraft.thePlayer.boundingBox.minZ);
            while (true) {
                int n2;
                if ((n2 = ++z) >= MathHelper.floor_double(Minecraft.thePlayer.boundingBox.maxZ) + 1) continue block0;
                int x2 = x;
                BlockPos pos = new BlockPos(x2, (int)Minecraft.thePlayer.boundingBox.minY, z);
                Block block = Minecraft.theWorld.getBlockState(pos).getBlock();
                if (block == null || block instanceof BlockAir) continue;
                if (block instanceof BlockLiquid && Minecraft.theWorld.getBlockState(pos).getProperties().get((Object)BlockLiquid.LEVEL) instanceof Integer && (Integer)((Comparable)Minecraft.theWorld.getBlockState(pos).getProperties().get((Object)BlockLiquid.LEVEL)) >= 1) {
                    return false;
                }
                return block instanceof BlockLiquid;
            }
            break;
        }
        return false;
    }

    public boolean isOnLiquid2() {
        if (Minecraft.thePlayer == null) {
            return false;
        }
        boolean onLiquid = false;
        int y = (int)Minecraft.thePlayer.boundingBox.offset((double)0.0, (double)-0.0, (double)0.0).minY;
        int x = MathHelper.floor_double(Minecraft.thePlayer.boundingBox.minX);
        while (x < MathHelper.floor_double(Minecraft.thePlayer.boundingBox.maxX) + 1) {
            int z = MathHelper.floor_double(Minecraft.thePlayer.boundingBox.minZ);
            while (z < MathHelper.floor_double(Minecraft.thePlayer.boundingBox.maxZ) + 1) {
                Block block = Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                if (block != null && !(block instanceof BlockAir)) {
                    if (!(block instanceof BlockLiquid)) {
                        return false;
                    }
                    if (Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getProperties().get((Object)BlockLiquid.LEVEL) instanceof Integer && (Integer)((Comparable)Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getProperties().get((Object)BlockLiquid.LEVEL)) > 2) {
                        return false;
                    }
                    onLiquid = true;
                }
                ++z;
            }
            ++x;
        }
        return onLiquid;
    }

    public static boolean isOnLiquid() {
        if (Minecraft.thePlayer == null) {
            return false;
        }
        boolean onLiquid = false;
        int y = (int)Minecraft.thePlayer.getEntityBoundingBox().offset((double)0.0, (double)-0.01, (double)0.0).minY;
        int x = MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().minX);
        while (x < MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().maxX) + 1) {
            int z = MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().minZ);
            while (z < MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().maxZ) + 1) {
                Block block = Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                if (block != null && block.getMaterial() != Material.air) {
                    if (!(block instanceof BlockLiquid)) {
                        return false;
                    }
                    if (Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getProperties().get((Object)BlockLiquid.LEVEL) instanceof Integer && (Integer)((Comparable)Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getProperties().get((Object)BlockLiquid.LEVEL)) >= 1) {
                        return false;
                    }
                    onLiquid = true;
                }
                ++z;
            }
            ++x;
        }
        return onLiquid;
    }

    public static boolean isInLiquidB() {
        if (Minecraft.thePlayer == null) {
            return false;
        }
        boolean onLiquid = false;
        int y = (int)Minecraft.thePlayer.getEntityBoundingBox().offset((double)0.0, (double)0.01, (double)0.0).minY;
        int x = MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().minX);
        while (x < MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().maxX) + 1) {
            int z = MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().minZ);
            while (z < MathHelper.floor_double(Minecraft.thePlayer.getEntityBoundingBox().maxZ) + 1) {
                Block block = Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                if (block != null && block.getMaterial() != Material.air) {
                    if (!(block instanceof BlockLiquid)) {
                        return false;
                    }
                    onLiquid = true;
                }
                ++z;
            }
            ++x;
        }
        return onLiquid;
    }

    public static boolean isOnLiquid(double profondeur) {
        boolean onLiquid = false;
        if (Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - profondeur, Minecraft.thePlayer.posZ)).getBlock().getMaterial().isLiquid()) {
            onLiquid = true;
        }
        return onLiquid;
    }

    public static boolean isTotalOnLiquid(double profondeur) {
        double x = Minecraft.thePlayer.boundingBox.minX;
        while (x < Minecraft.thePlayer.boundingBox.maxX) {
            double z = Minecraft.thePlayer.boundingBox.minZ;
            while (z < Minecraft.thePlayer.boundingBox.maxZ) {
                Block block = Minecraft.theWorld.getBlockState(new BlockPos(x, Minecraft.thePlayer.posY - profondeur, z)).getBlock();
                if (!(block instanceof BlockLiquid) && !(block instanceof BlockAir)) {
                    return false;
                }
                z += (double)0.01f;
            }
            x += (double)0.01f;
        }
        return true;
    }

    public double getMotionY(double stage) {
        stage -= 1.0;
        double[] dArray = new double[]{0.5, 0.484, 0.468, 0.436, 0.404, 0.372, 0.34, 0.308, 0.276, 0.244, 0.212, 0.18, 0.166, 0.166, 0.156, 0.123, 0.135, 0.111, 0.086, 0.098, 0.073, 0.048, 0.06, 0.036, 0.0106, 0.015, 0.004, 0.004, 0.004, 0.004, -0.013, -0.045, -0.077, -0.109};
        double[] motion = dArray;
        if (stage < (double)motion.length && stage >= 0.0) {
            return motion[(int)stage];
        }
        return -999.0;
    }

    public static boolean isOnGround(double height) {
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, -height, 0.0)).isEmpty();
    }

    public static int getSpeedEffect() {
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            return Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1;
        }
        return 0;
    }

    public static void setMotion(double speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            Minecraft.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f));
            Minecraft.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f));
        }
    }

    private boolean b() {
        boolean var13;
        BlockPos[] var8;
        double var2 = Minecraft.thePlayer.posX;
        double var4 = Minecraft.thePlayer.posY;
        double var6 = Minecraft.thePlayer.posZ;
        BlockPos[] var9 = var8 = new BlockPos[]{new BlockPos(var2 + 0.3, var4, var6 + 0.3), new BlockPos(var2 - 0.3, var4, var6 + 0.3), new BlockPos(var2 + 0.3, var4, var6 - 0.3), new BlockPos(var2 - 0.3, var4, var6 - 0.3)};
        int v0 = 0;
        int var10 = var8.length;
        if (v0 < var10) {
            BlockPos v1 = var9[v0];
            var13 = Minecraft.theWorld.getBlockState(v1).getBlock() instanceof BlockLiquid;
            if (var13 && Minecraft.theWorld.getBlockState(v1).getProperties().get((Object)BlockLiquid.LEVEL) instanceof Integer && (Integer)Minecraft.theWorld.getBlockState(v1).getProperties().get((Object)BlockLiquid.LEVEL) <= 3) {
                return true;
            }
            ++v0;
        }
        var13 = false;
        return var13;
    }

    public void DoNative(EventPreUpdate em) {
        if (Minecraft.thePlayer.fallDistance != 0.0f) {
            return;
        }
        Minecraft.thePlayer.stepHeight = 0.015625f;
        ++this.stage;
        if (this.stage == 1) {
            EventPreUpdate.setY(EventPreUpdate.y - ThreadLocalRandom.current().nextDouble(0.0155249999999, 0.015625));
        }
        if (this.stage == 2) {
            EventPreUpdate.setY(EventPreUpdate.y + ThreadLocalRandom.current().nextDouble(0.0148999999999, 0.015));
        }
        if (this.stage == 3) {
            EventPreUpdate.setY(EventPreUpdate.y + ThreadLocalRandom.current().nextDouble(0.0198999999999, 0.02));
        }
        if (this.stage >= 4) {
            EventPreUpdate.setY(EventPreUpdate.y + 0.015625);
            this.stage = 0;
        }
        if (this.stage % 2 == 0) {
            EventPreUpdate.setY(EventPreUpdate.y - 1.0E-13);
        }
        EventPreUpdate.setY(EventPreUpdate.y + 1.0E-13);
        EventPreUpdate.setOnground(Jesus.isOnGround(EventPreUpdate.y));
    }

    public void onNative2() {
        Minecraft.thePlayer.motionY = 0.11999998688698;
    }

    public boolean isInLiquiddol() {
        if (Minecraft.thePlayer == null) {
            return false;
        }
        boolean inLiquid = false;
        int y = (int)(Minecraft.thePlayer.boundingBox.minY + 0.02);
        int x = MathHelper.floor_double(Minecraft.thePlayer.boundingBox.minX);
        while (x < MathHelper.floor_double(Minecraft.thePlayer.boundingBox.maxX) + 1) {
            int z = MathHelper.floor_double(Minecraft.thePlayer.boundingBox.minZ);
            while (z < MathHelper.floor_double(Minecraft.thePlayer.boundingBox.maxZ) + 1) {
                Block block = Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                if (block != null && !(block instanceof BlockAir)) {
                    if (!(block instanceof BlockLiquid)) {
                        return false;
                    }
                    if (block instanceof BlockLiquid && Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getProperties().get((Object)BlockLiquid.LEVEL) instanceof Integer && (Integer)((Comparable)Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getProperties().get((Object)BlockLiquid.LEVEL)) >= 1) {
                        return false;
                    }
                    inLiquid = true;
                }
                ++z;
            }
            ++x;
        }
        return inLiquid;
    }

    @EventHandler
    public void onMove(EventMove e) {
        if (Jesus.isOnLiquid() && !this.isInLiquid()) {
            e.setSpeed((Double)SpeedMode.getValue());
        }
    }

    @EventHandler
    public void onUpdate(EventPreUpdate em) {
        Client.instance.getModuleManager();
        if (!(ModuleManager.getModuleByClass(Speed.class).isEnabled() || Jesus.mc.gameSettings.keyBindSneak.isKeyDown() || Jesus.mc.gameSettings.keyBindJump.isKeyDown())) {
            if (Jesus.isOnLiquid() && !this.isInLiquid() && !this.isInLiquiddol()) {
                this.DoNative(em);
                return;
            }
            if (this.isInLiquid() && this.isInLiquiddol()) {
                this.onNative2();
            }
        }
        this.stage = 0;
        if (Minecraft.thePlayer.stepHeight < 0.02f) {
            Minecraft.thePlayer.stepHeight = 0.6f;
        }
    }

    @EventHandler
    public void onBlockCollide(EventCollideWithBlock event) {
        int x = event.getPos().getX();
        int y = event.getPos().getY();
        int z = event.getPos().getZ();
        Client.instance.getModuleManager();
        if (!(ModuleManager.getModuleByClass(Speed.class).isEnabled() || this.isInLiquid() || Jesus.mc.gameSettings.keyBindSneak.isKeyDown() || Jesus.mc.gameSettings.keyBindJump.isKeyDown())) {
            if (Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getProperties().get((Object)BlockLiquid.LEVEL) instanceof Integer && (Integer)((Comparable)Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getProperties().get((Object)BlockLiquid.LEVEL)) >= 1) {
                return;
            }
            Object v2 = Minecraft.theWorld.getBlockState(event.getPos()).getProperties().get((Object)BlockLiquid.LEVEL);
            if (!(v2 instanceof Integer && (Integer)v2 > 3 || !(Minecraft.theWorld.getBlockState(event.getPos()).getBlock() instanceof BlockLiquid) || Minecraft.thePlayer.isSneaking())) {
                event.setCancelled(true);
                event.setBoundingBox(new AxisAlignedBB(event.getPos().getX(), event.getPos().getY(), event.getPos().getZ(), (double)event.getPos().getX() + 0.98, (double)event.getPos().getY() + 1.0, (double)event.getPos().getZ() + 0.98));
            }
        }
    }

    static enum JMode {
        Solid,
        Dolphin;

    }
}

