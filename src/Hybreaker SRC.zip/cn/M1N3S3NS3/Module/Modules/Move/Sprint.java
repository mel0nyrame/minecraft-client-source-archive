/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Misc.EventChat;
import cn.M1N3S3NS3.API.Events.World.EventMove;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.BlockUtils;
import cn.M1N3S3NS3.Util.PlayerUtil;
import cn.M1N3S3NS3.Util.RotationUtil;
import java.awt.Color;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;

public class Sprint
extends Module {
    public static boolean backward = true;
    private Option<Boolean> omni = new Option<Boolean>("Omni-Directional", "omni", true);
    Option bback = new Option<Boolean>("AutoBack", true);
    Option AntiObs = new Option<Boolean>("AntiObs", true);

    public Sprint() {
        super("Sprint", new String[]{"run"}, ModuleType.Move);
        this.setColor(new Color(158, 205, 125).getRGB());
        this.addValues(this.omni, this.bback, this.AntiObs);
    }

    private boolean canSprint() {
        if (!((Boolean)this.omni.getValue()).booleanValue() && !Sprint.mc.gameSettings.keyBindForward.pressed) {
            return false;
        }
        if (PlayerUtil.isMoving()) {
            if (Minecraft.thePlayer.getFoodStats().getFoodLevel() > 6) {
                return true;
            }
        }
        return false;
    }

    @EventHandler
    private void onUpdate(EventMove event) {
        if (!(Minecraft.thePlayer.getFoodStats().getFoodLevel() > 6 && (Boolean)this.omni.getValue() != false ? !Minecraft.thePlayer.moving() : !(Minecraft.thePlayer.moveForward > 0.0f))) {
            Minecraft.thePlayer.setSprinting(true);
        }
    }

    @EventHandler
    public void OnUpdate(EventPreUpdate e) {
        if (((Boolean)this.AntiObs.getValue()).booleanValue()) {
            BlockPos obsidianpos = new BlockPos(new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + 1.0, Minecraft.thePlayer.posZ));
            Block obsidianblock = Minecraft.theWorld.getBlockState(obsidianpos).getBlock();
            if (obsidianblock == Block.getBlockById(49)) {
                obsidianpos = new BlockPos(new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ));
                obsidianblock = Minecraft.theWorld.getBlockState(obsidianpos).getBlock();
                if (obsidianblock != Block.getBlockById(49)) {
                    BlockUtils.updateTool(obsidianpos);
                    float[] rot = RotationUtil.getRotationFromPosition(Minecraft.thePlayer.posX + 0.5, Minecraft.thePlayer.posY - 1.0 + 0.5, Minecraft.thePlayer.posZ + 0.5);
                    if (rot == null) {
                        return;
                    }
                    e.setYaw(rot[0]);
                    e.setPitch(rot[1]);
                    Minecraft.playerController.onPlayerDamageBlock(obsidianpos, EnumFacing.UP);
                } else {
                    BlockPos block1pos = new BlockPos(new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + 1.0, Minecraft.thePlayer.posZ - 1.0));
                    BlockPos block2pos = new BlockPos(new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ - 1.0));
                    Block block = Minecraft.theWorld.getBlockState(block1pos).getBlock();
                    if (block != Block.getBlockById(0)) {
                        BlockUtils.updateTool(block1pos);
                        float[] rot = RotationUtil.getRotationFromPosition(Minecraft.thePlayer.posX + 0.5, Minecraft.thePlayer.posY + 1.0 + 0.5, Minecraft.thePlayer.posZ - 1.0 + 0.5);
                        if (rot == null) {
                            return;
                        }
                        e.setYaw(rot[0]);
                        e.setPitch(rot[1]);
                        Minecraft.playerController.onPlayerDamageBlock(block1pos, EnumFacing.EAST);
                    } else {
                        BlockUtils.updateTool(block2pos);
                        float[] rot = RotationUtil.getRotationFromPosition(Minecraft.thePlayer.posX + 0.5, Minecraft.thePlayer.posY + 0.5, Minecraft.thePlayer.posZ - 1.0 + 0.5);
                        if (rot == null) {
                            return;
                        }
                        e.setYaw(rot[0]);
                        e.setPitch(rot[1]);
                        Minecraft.playerController.onPlayerDamageBlock(block2pos, EnumFacing.EAST);
                    }
                }
            }
        }
    }

    @EventHandler
    private void onChat(EventChat e) {
        if (((Boolean)this.bback.getValue()).booleanValue()) {
            if (e.getMessage().contains("Flying or related.")) {
                Minecraft.thePlayer.sendChatMessage("/back");
            }
            if (e.getMessage().contains("You were spawned in Limbo.")) {
                Minecraft.thePlayer.sendChatMessage("/back");
            }
        }
    }
}

