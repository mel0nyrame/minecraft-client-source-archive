/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPostUpdate;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.KillAura;
import cn.M1N3S3NS3.Util.MovementUtils;
import cn.M1N3S3NS3.Util.PlayerUtils;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class NoSlow
extends Module {
    private Option<Boolean> Packet = new Option<Boolean>("Packet", "Packet", true);
    public TimerUtil timer = new TimerUtil();
    public static Numbers<Double> Speed = new Numbers<Double>("Speed", "Speed", 1.0, 0.0, 1.0, 0.1);

    public NoSlow() {
        super("NoSlow", new String[]{"NoSlow", "float"}, ModuleType.Move);
        this.setColor(new Color(188, 233, 248).getRGB());
        this.addValues(this.Packet, Speed);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @EventHandler
    public void onPost(EventPostUpdate event) {
        this.setSuffix((Boolean)this.Packet.getValue() != false ? "NCP" : "");
        Client.instance.getModuleManager();
        KillAura aura = (KillAura)ModuleManager.getModuleByClass(KillAura.class);
        if (PlayerUtils.isHoldingSword() || !MovementUtils.isMoving()) {
            return;
        }
        if (!Minecraft.thePlayer.isBlocking() && !KillAura.blocking) {
            return;
        }
        if (((Boolean)this.Packet.getValue()).booleanValue()) {
            Minecraft.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(new BlockPos(-1.0, -1.0, -1.0), 255, Minecraft.thePlayer.inventory.getCurrentItem(), 0.0f, 0.0f, 0.0f));
        }
    }

    @EventHandler
    public void onPre(EventPreUpdate e) {
        Client.instance.getModuleManager();
        KillAura aura = (KillAura)ModuleManager.getModuleByClass(KillAura.class);
        if (PlayerUtils.isHoldingSword() || !MovementUtils.isMoving()) {
            return;
        }
        if (!Minecraft.thePlayer.isBlocking() && !KillAura.blocking) {
            return;
        }
        if (((Boolean)this.Packet.getValue()).booleanValue()) {
            Minecraft.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(-1.0, -1.0, -1.0), EnumFacing.DOWN));
        }
    }
}

