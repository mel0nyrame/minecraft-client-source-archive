/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package cn.M1N3S3NS3.Module.Modules.Move;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Events.World.EventMove;
import cn.M1N3S3NS3.API.Events.World.EventPacketReceive;
import cn.M1N3S3NS3.API.Events.World.EventPacketSend;
import cn.M1N3S3NS3.API.Events.World.EventPostUpdate;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Events.World.SafeWalkEvent;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.KillAura;
import cn.M1N3S3NS3.Module.Modules.Move.Speed;
import cn.M1N3S3NS3.Util.MoveUtils;
import cn.M1N3S3NS3.Util.MovementUtils;
import cn.M1N3S3NS3.Util.PlayerUtil;
import cn.M1N3S3NS3.Util.Rotation;
import cn.M1N3S3NS3.Util.RotationUtil;
import cn.M1N3S3NS3.Util.timer.Test;
import java.util.Arrays;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockCarpet;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.BlockSkull;
import net.minecraft.block.BlockSnow;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.server.S2FPacketSetSlot;
import net.minecraft.stats.StatList;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Timer;
import net.minecraft.util.Vec3;
import org.lwjgl.input.Keyboard;

public class Scaffold
extends Module {
    private Option tower = new Option<Boolean>("Tower", true);
    private Option moveTower = new Option<Boolean>("MoveTower", true);
    private Option ab = new Option<Boolean>("Silent", true);
    private Option sprint = new Option<Boolean>("Sprint", false);
    private Option swing = new Option<Boolean>("Swing", false);
    private BlockData blockData;
    private double jumpGround = 0.0;
    private int lastSlot;
    private int slot;
    public static transient Test timer = new Test();
    public static List<Block> blacklisted = Arrays.asList(Blocks.air, Blocks.water, Blocks.flowing_water, Blocks.lava, Blocks.flowing_lava, Blocks.enchanting_table, Blocks.ender_chest, Blocks.yellow_flower, Blocks.carpet, Blocks.glass_pane, Blocks.stained_glass_pane, Blocks.iron_bars, Blocks.crafting_table, Blocks.snow_layer, Blocks.packed_ice, Blocks.coal_ore, Blocks.diamond_ore, Blocks.emerald_ore, Blocks.chest, Blocks.torch, Blocks.anvil, Blocks.trapped_chest, Blocks.noteblock, Blocks.gold_ore, Blocks.iron_ore, Blocks.lapis_ore, Blocks.lit_redstone_ore, Blocks.redstone_ore, Blocks.wooden_pressure_plate, Blocks.stone_pressure_plate, Blocks.light_weighted_pressure_plate, Blocks.heavy_weighted_pressure_plate, Blocks.stone_button, Blocks.wooden_button, Blocks.cactus, Blocks.lever, Blocks.activator_rail, Blocks.rail, Blocks.detector_rail, Blocks.golden_rail, Blocks.furnace, Blocks.ladder, Blocks.oak_fence, Blocks.redstone_torch, Blocks.iron_trapdoor, Blocks.trapdoor, Blocks.tripwire_hook, Blocks.hopper, Blocks.acacia_fence_gate, Blocks.birch_fence_gate, Blocks.dark_oak_fence_gate, Blocks.jungle_fence_gate, Blocks.spruce_fence_gate, Blocks.oak_fence_gate, Blocks.dispenser, Blocks.sapling, Blocks.tallgrass, Blocks.deadbush, Blocks.web, Blocks.red_flower, Blocks.red_mushroom, Blocks.brown_mushroom, Blocks.nether_brick_fence, Blocks.vine, Blocks.double_plant, Blocks.flower_pot, Blocks.beacon, Blocks.pumpkin, Blocks.lit_pumpkin);
    public static List<Block> blacklistedBlocks = Arrays.asList(Blocks.air, Blocks.water, Blocks.flowing_water, Blocks.lava, Blocks.flowing_lava, Blocks.ender_chest, Blocks.enchanting_table, Blocks.stone_button, Blocks.wooden_button, Blocks.crafting_table, Blocks.beacon);
    private static final Rotation rotation = new Rotation(999.0f, 999.0f);
    public static transient float lastYaw = 0.0f;
    public static transient float lastPitch = 0.0f;
    public static transient float lastRandX = 0.0f;
    public static transient float lastRandY = 0.0f;
    public static transient float lastRandZ = 0.0f;
    public static transient BlockPos lastBlockPos = null;
    public static transient EnumFacing lastFacing = null;

    public Scaffold() {
        super("Scaffold", new String[]{"magiccarpet", "blockplacer", "airwalk"}, ModuleType.Move);
        this.addValues(this.tower, this.moveTower, this.ab, this.sprint, this.swing);
    }

    private void fakeJump() {
        Minecraft.thePlayer.isAirBorne = true;
        Minecraft.thePlayer.triggerAchievement(StatList.jumpStat);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.lastSlot = -1;
    }

    @EventHandler
    public void onmove(EventMove e) {
        if (MovementUtils.isMoving()) {
            Client.getModuleManager();
            if (!ModuleManager.getModuleByClass(Speed.class).isEnabled()) {
                MovementUtils.setSpeed(e, 0.22);
            }
        }
    }

    @EventHandler
    public void onPreMotion(EventPreUpdate e) {
        double x = Minecraft.thePlayer.posX;
        double y = Minecraft.thePlayer.posY - 1.0;
        double z = Minecraft.thePlayer.posZ;
        BlockPos underPos = new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ);
        Block underBlock = Minecraft.theWorld.getBlockState(underPos).getBlock();
        BlockPos blockBelow = new BlockPos(x, y, z);
        this.blockData = this.getBlockData(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ), blacklistedBlocks);
        if (this.getBlockSlot() == -1) {
            int i = 0;
            while (i < 36) {
                ItemStack block = Minecraft.thePlayer.inventory.getStackInSlot(i);
                if (block != null && block.getItem() instanceof ItemBlock) {
                    Minecraft.playerController.windowClick(0, i, 0, 0, Minecraft.thePlayer);
                    Minecraft.playerController.windowClick(0, 44, 0, 0, Minecraft.thePlayer);
                }
                ++i;
            }
        }
        float[] rotations = RotationUtil.getRotationBlock(BlockData.position);
        e.setYaw(rotations[0]);
        e.setPitch(rotations[1]);
        Minecraft.thePlayer.rotationYawHead = rotations[0];
        Minecraft.thePlayer.rotationPitchHead = rotations[1];
        RendererLivingEntity.SetPitchY(rotations[1]);
    }

    public boolean isAirBlock(Block block) {
        return block.getMaterial().isReplaceable() && (!(block instanceof BlockSnow) || block.getBlockBoundsMaxY() <= 0.125);
    }

    private Vec3 grabPosition(BlockPos position, EnumFacing facing) {
        Vec3 offset = new Vec3((double)facing.getDirectionVec().getX() / 2.0, (double)facing.getDirectionVec().getY() / 2.0, (double)facing.getDirectionVec().getZ() / 2.0);
        Vec3 point = new Vec3((double)position.getX() + 0.5, (double)position.getY() + 0.5, (double)position.getZ() + 0.5);
        return point.add(offset);
    }

    private BlockData grab() {
        EnumFacing[] invert = new EnumFacing[]{EnumFacing.UP, EnumFacing.DOWN, EnumFacing.SOUTH, EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.WEST};
        BlockPos position = new BlockPos(Minecraft.thePlayer.getPositionVector()).offset(EnumFacing.DOWN);
        if (!(Minecraft.theWorld.getBlockState(position).getBlock() instanceof BlockAir)) {
            return null;
        }
        EnumFacing[] var6 = EnumFacing.values();
        int var5 = var6.length;
        int offset = 0;
        while (offset < var5) {
            EnumFacing offsets = var6[offset];
            BlockPos offset1 = position.offset(offsets);
            Minecraft.theWorld.getBlockState(offset1);
            if (!(Minecraft.theWorld.getBlockState(offset1).getBlock() instanceof BlockAir)) {
                return new BlockData(offset1, invert[offsets.ordinal()], this.blockData);
            }
            ++offset;
        }
        return null;
    }

    public static float[] grabBlockRotations(BlockPos pos) {
        return Scaffold.getVecRotation(Minecraft.thePlayer.getPositionVector().addVector(0.0, Minecraft.thePlayer.getEyeHeight(), 0.0), new Vec3((double)pos.getX() + 0.5, (double)pos.getY() + 0.5, (double)pos.getZ() + 0.5));
    }

    public static float[] getVecRotation(Vec3 position) {
        return Scaffold.getVecRotation(Minecraft.thePlayer.getPositionVector().addVector(0.0, Minecraft.thePlayer.getEyeHeight(), 0.0), position);
    }

    public static float[] getVecRotation(Vec3 origin, Vec3 position) {
        Vec3 difference = position.subtract(origin);
        double distance = difference.flat().lengthVector();
        float yaw = (float)Math.toDegrees(Math.atan2(difference.zCoord, difference.xCoord)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(difference.yCoord, distance)));
        return new float[]{yaw, pitch};
    }

    public boolean isOnGround(double height) {
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, -height, 0.0)).isEmpty();
    }

    public static boolean isMoving2() {
        return Minecraft.thePlayer.moveForward != 0.0f || Minecraft.thePlayer.moveStrafing != 0.0f;
    }

    public float[] getRotationsBlock(BlockPos block, EnumFacing face) {
        double x = (double)block.getX() + 0.5 - Minecraft.thePlayer.posX + (double)face.getFrontOffsetX() / 2.0;
        double z = (double)block.getZ() + 0.5 - Minecraft.thePlayer.posZ + (double)face.getFrontOffsetZ() / 2.0;
        double y = (double)block.getY() + 0.5;
        double d1 = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight() - y;
        double d3 = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float)(Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(Math.atan2(d1, d3) * 180.0 / Math.PI);
        if (yaw < 0.0f) {
            yaw += 360.0f;
        }
        return new float[]{yaw, pitch};
    }

    @EventHandler
    public void onRender(EventRender2D e) {
        ItemStack block = Minecraft.thePlayer.inventory.getStackInSlot(this.getBlockSlot());
    }

    @EventHandler
    public void onPost(EventPacketReceive e) {
        Client.getModuleManager();
        if (ModuleManager.getModuleByClass(KillAura.class).isEnabled() && KillAura.curTarget != null) {
            return;
        }
        if (EventPacketReceive.packet instanceof S2FPacketSetSlot) {
            this.lastSlot = ((S2FPacketSetSlot)EventPacketReceive.packet).slot;
        }
    }

    @EventHandler
    public void onPost(EventPacketSend e) {
        Client.getModuleManager();
        if (ModuleManager.getModuleByClass(KillAura.class).isEnabled() && KillAura.curTarget != null) {
            return;
        }
        if (EventPacketSend.packet instanceof C09PacketHeldItemChange) {
            this.lastSlot = ((C09PacketHeldItemChange)EventPacketSend.packet).getSlotId();
        }
    }

    @EventHandler
    void onSafeWalk(SafeWalkEvent event) {
        event.setCancelled(Minecraft.thePlayer.onGround);
    }

    /*
     * Unable to fully structure code
     */
    @EventHandler
    public void onPost(EventPostUpdate e) {
        block16: {
            block17: {
                x = Minecraft.thePlayer.posX;
                y = Minecraft.thePlayer.posY - 1.0;
                z = Minecraft.thePlayer.posZ;
                blockBelow = new BlockPos(x, y, z);
                if (this.blockData == null) break block16;
                this.lastSlot = this.getBlockSlot();
                if (this.lastSlot == -1) break block17;
                if (Minecraft.thePlayer.getCurrentEquippedItem() == null) break block17;
                if (Minecraft.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemBlock) ** GOTO lbl-1000
            }
            if (this.lastSlot != -1 && ((Boolean)this.ab.getValue()).booleanValue()) lbl-1000:
            // 2 sources

            {
                if (((Boolean)this.ab.getValue()).booleanValue()) {
                    Scaffold.mc.getNetHandler().getNetworkManager().sendPacket(new C09PacketHeldItemChange(this.lastSlot));
                }
                this.placeBlock(BlockData.position, BlockData.face, this.lastSlot);
            } else if (((Boolean)this.ab.getValue()).booleanValue()) {
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(Minecraft.thePlayer.inventory.currentItem));
            }
        }
        if (this.invCheck()) {
            i = 9;
            while (i < 36) {
                if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack() && (item = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack().getItem()) instanceof ItemBlock && !Scaffold.blacklisted.contains(((ItemBlock)item).getBlock()) && !((ItemBlock)item).getBlock().getLocalizedName().toLowerCase().contains("chest")) {
                    this.swap(i, 7);
                    break;
                }
                ++i;
            }
        }
        if (((Boolean)this.moveTower.getValue()).booleanValue() && this.slot != -1 && Scaffold.mc.gameSettings.keyBindJump.pressed && ((Boolean)this.tower.getValue()).booleanValue()) {
            underPos = new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ);
            underBlock = Minecraft.theWorld.getBlockState(underPos).getBlock();
            if (Scaffold.isMoving2() && ((Boolean)this.tower.getValue()).booleanValue()) {
                if (this.isOnGround(0.76) && !this.isOnGround(0.75)) {
                    if (Minecraft.thePlayer.motionY > 0.23) {
                        if (Minecraft.thePlayer.motionY < 0.25) {
                            Minecraft.thePlayer.motionY = (double)Math.round(Minecraft.thePlayer.posY) - Minecraft.thePlayer.posY;
                        }
                    }
                }
                if (this.isOnGround(1.0E-4)) {
                    Minecraft.thePlayer.motionY = 0.41999998688698;
                    Minecraft.thePlayer.motionX *= 0.9;
                    Minecraft.thePlayer.motionZ *= 0.9;
                } else if (Minecraft.thePlayer.posY >= (double)Math.round(Minecraft.thePlayer.posY) - 1.0E-4) {
                    if (Minecraft.thePlayer.posY <= (double)Math.round(Minecraft.thePlayer.posY) + 1.0E-4) {
                        Minecraft.thePlayer.motionY = 0.0;
                    }
                }
            }
        }
    }

    @EventHandler
    public void onPost1(EventPostUpdate e) {
        if (this.slot != -1 && Scaffold.mc.gameSettings.keyBindJump.pressed) {
            ((Boolean)this.tower.getValue()).booleanValue();
        }
    }

    private int getBestBlockSlotHotBar() {
        return 0;
    }

    private void doMotionUp() {
        if (this.getBlockSlot() > 0 && ((Boolean)this.tower.getValue()).booleanValue() && !PlayerUtil.isMoving2()) {
            BlockPos blockPos0 = new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ);
            Block getBlock0 = Minecraft.theWorld.getBlockState(blockPos0).getBlock();
            BlockData blockData0 = this.getBlockData(blockPos0, blacklistedBlocks);
            if (!Scaffold.mc.gameSettings.keyBindJump.isKeyDown()) {
                if (PlayerUtil.isMoving()) {
                    if (MoveUtils.isOnGround(0.76) && !MoveUtils.isOnGround(0.75)) {
                        if (Minecraft.thePlayer.motionY > 0.23) {
                            if (Minecraft.thePlayer.motionY < 0.25) {
                                Minecraft.thePlayer.motionY = (double)Math.round(Minecraft.thePlayer.posY) - Minecraft.thePlayer.posY;
                            }
                        }
                    }
                    if (!MoveUtils.isOnGround(1.0E-4)) {
                        if (Minecraft.thePlayer.motionY > 0.1) {
                            if (Minecraft.thePlayer.posY >= (double)Math.round(Minecraft.thePlayer.posY) - 1.0E-4) {
                                if (Minecraft.thePlayer.posY <= (double)Math.round(Minecraft.thePlayer.posY) + 1.0E-4) {
                                    Minecraft.thePlayer.motionY = 0.0;
                                }
                            }
                        }
                    }
                }
                return;
            }
            if (PlayerUtil.isMoving2()) {
                if (MoveUtils.isOnGround(0.76) && !MoveUtils.isOnGround(0.75)) {
                    if (Minecraft.thePlayer.motionY > 0.23) {
                        if (Minecraft.thePlayer.motionY < 0.25) {
                            Minecraft.thePlayer.motionY = (double)Math.round(Minecraft.thePlayer.posY) - Minecraft.thePlayer.posY;
                        }
                    }
                }
                if (MoveUtils.isOnGround(1.0E-4)) {
                    Minecraft.thePlayer.motionY = 0.4196f;
                } else if (!MoveUtils.isOnGround(1.0E-4)) {
                    if (Minecraft.thePlayer.posY >= (double)Math.round(Minecraft.thePlayer.posY) - 1.0E-4) {
                        if (Minecraft.thePlayer.posY <= (double)Math.round(Minecraft.thePlayer.posY) + 1.0E-4) {
                            Minecraft.thePlayer.motionY = 0.0;
                        }
                    }
                }
                Minecraft.thePlayer.motionX = 0.0;
                Minecraft.thePlayer.motionZ = 0.0;
                Minecraft.thePlayer.jumpMovementFactor = 0.0f;
                if (this.isAirBlock(getBlock0) && blockData0 != null) {
                    Timer.timerSpeed = 0.9f;
                    Minecraft.thePlayer.motionY = 0.41993956416514;
                    Minecraft.thePlayer.motionX *= 0.75;
                    Minecraft.thePlayer.motionZ *= 0.75;
                }
            }
        }
    }

    protected void swap(int slot, int hotbarNum) {
        Minecraft.playerController.windowClick(Minecraft.thePlayer.inventoryContainer.windowId, slot, hotbarNum, 2, Minecraft.thePlayer);
    }

    private boolean invCheck() {
        int i = 36;
        while (i < 45) {
            Item item;
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack() && (item = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack().getItem()) instanceof ItemBlock && !blacklisted.contains(((ItemBlock)item).getBlock())) {
                return false;
            }
            ++i;
        }
        return true;
    }

    @Override
    public void onDisable() {
        Timer.timerSpeed = 1.0f;
        this.lastSlot = -1;
        Minecraft.thePlayer.stepHeight = 0.5f;
        if (Minecraft.thePlayer.isSwingInProgress) {
            Minecraft.thePlayer.swingProgress = 0.0f;
            Minecraft.thePlayer.swingProgressInt = 0;
            Minecraft.thePlayer.isSwingInProgress = false;
        }
        if (((Boolean)this.ab.getValue()).booleanValue()) {
            Minecraft.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(Minecraft.thePlayer.inventory.currentItem));
        }
        if (this.slot != Minecraft.thePlayer.inventory.currentItem) {
            mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(Minecraft.thePlayer.inventory.currentItem));
        }
    }

    private boolean placeBlock(BlockPos pos, EnumFacing facing, int slotWithBlockInIt) {
        Vec3 eyesPos = new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
        ItemStack itemstack = Minecraft.thePlayer.inventory.mainInventory[slotWithBlockInIt];
        if (Minecraft.playerController.onPlayerRightClick(Minecraft.thePlayer, Minecraft.theWorld, itemstack, pos, facing, new Vec3(BlockData.position).addVector(0.5, 0.5, 0.5).add(new Vec3(BlockData.face.getDirectionVec()).scale(0.5)))) {
            if (((Boolean)this.swing.getValue()).booleanValue()) {
                Minecraft.thePlayer.swingItem();
            } else {
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
            }
            return true;
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    private BlockData getBlockData(BlockPos pos, List list) {
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(pos.add(0, -1, 0)).getBlock())) {
            return new BlockData(pos.add(0, -1, 0), EnumFacing.UP, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(pos.add(-1, 0, 0)).getBlock())) {
            EnumFacing enumFacing;
            BlockPos blockPos = pos.add(-1, 0, 0);
            if (Keyboard.isKeyDown((int)42) && Minecraft.thePlayer.onGround && Minecraft.thePlayer.fallDistance == 0.0f) {
                if (Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ)).getBlock() == Blocks.air) {
                    enumFacing = EnumFacing.DOWN;
                    return new BlockData(blockPos, enumFacing, this.blockData);
                }
            }
            enumFacing = EnumFacing.EAST;
            return new BlockData(blockPos, enumFacing, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(pos.add(1, 0, 0)).getBlock())) {
            EnumFacing enumFacing;
            BlockPos blockPos = pos.add(1, 0, 0);
            if (Keyboard.isKeyDown((int)42) && Minecraft.thePlayer.onGround && Minecraft.thePlayer.fallDistance == 0.0f) {
                if (Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ)).getBlock() == Blocks.air) {
                    enumFacing = EnumFacing.DOWN;
                    return new BlockData(blockPos, enumFacing, this.blockData);
                }
            }
            enumFacing = EnumFacing.WEST;
            return new BlockData(blockPos, enumFacing, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(pos.add(0, 0, -1)).getBlock())) {
            EnumFacing enumFacing;
            BlockPos blockPos = pos.add(0, 0, -1);
            if (Keyboard.isKeyDown((int)42) && Minecraft.thePlayer.onGround && Minecraft.thePlayer.fallDistance == 0.0f) {
                if (Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ)).getBlock() == Blocks.air) {
                    enumFacing = EnumFacing.DOWN;
                    return new BlockData(blockPos, enumFacing, this.blockData);
                }
            }
            enumFacing = EnumFacing.SOUTH;
            return new BlockData(blockPos, enumFacing, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(pos.add(0, 0, 1)).getBlock())) {
            EnumFacing enumFacing;
            BlockPos blockPos = pos.add(0, 0, 1);
            if (Keyboard.isKeyDown((int)42) && Minecraft.thePlayer.onGround && Minecraft.thePlayer.fallDistance == 0.0f) {
                if (Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ)).getBlock() == Blocks.air) {
                    enumFacing = EnumFacing.DOWN;
                    return new BlockData(blockPos, enumFacing, this.blockData);
                }
            }
            enumFacing = EnumFacing.NORTH;
            return new BlockData(blockPos, enumFacing, this.blockData);
        }
        BlockPos add = pos.add(-1, 0, 0);
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add.add(-1, 0, 0)).getBlock())) {
            return new BlockData(add.add(-1, 0, 0), EnumFacing.EAST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add.add(1, 0, 0)).getBlock())) {
            return new BlockData(add.add(1, 0, 0), EnumFacing.WEST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add.add(0, 0, -1)).getBlock())) {
            return new BlockData(add.add(0, 0, -1), EnumFacing.SOUTH, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add.add(0, 0, 1)).getBlock())) {
            return new BlockData(add.add(0, 0, 1), EnumFacing.NORTH, this.blockData);
        }
        BlockPos add2 = pos.add(1, 0, 0);
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add2.add(-1, 0, 0)).getBlock())) {
            return new BlockData(add2.add(-1, 0, 0), EnumFacing.EAST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add2.add(1, 0, 0)).getBlock())) {
            return new BlockData(add2.add(1, 0, 0), EnumFacing.WEST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add2.add(0, 0, -1)).getBlock())) {
            return new BlockData(add2.add(0, 0, -1), EnumFacing.SOUTH, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add2.add(0, 0, 1)).getBlock())) {
            return new BlockData(add2.add(0, 0, 1), EnumFacing.NORTH, this.blockData);
        }
        BlockPos add3 = pos.add(0, 0, -1);
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add3.add(-1, 0, 0)).getBlock())) {
            return new BlockData(add3.add(-1, 0, 0), EnumFacing.EAST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add3.add(1, 0, 0)).getBlock())) {
            return new BlockData(add3.add(1, 0, 0), EnumFacing.WEST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add3.add(0, 0, -1)).getBlock())) {
            return new BlockData(add3.add(0, 0, -1), EnumFacing.SOUTH, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add3.add(0, 0, 1)).getBlock())) {
            return new BlockData(add3.add(0, 0, 1), EnumFacing.NORTH, this.blockData);
        }
        BlockPos add4 = pos.add(0, 0, 1);
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add4.add(-1, 0, 0)).getBlock())) {
            return new BlockData(add4.add(-1, 0, 0), EnumFacing.EAST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add4.add(1, 0, 0)).getBlock())) {
            return new BlockData(add4.add(1, 0, 0), EnumFacing.WEST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add4.add(0, 0, -1)).getBlock())) {
            return new BlockData(add4.add(0, 0, -1), EnumFacing.SOUTH, this.blockData);
        }
        if (blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add4.add(0, 0, 1)).getBlock())) return null;
        return new BlockData(add4.add(0, 0, 1), EnumFacing.NORTH, this.blockData);
    }

    private boolean canPush(BlockPos pos) {
        Block block = Minecraft.theWorld.getBlockState(pos).getBlock();
        return (block.getMaterial().isSolid() || !block.isTranslucent() || block instanceof BlockLadder || block instanceof BlockCarpet || block instanceof BlockSnow || block instanceof BlockSkull) && !block.getMaterial().isLiquid() && !(block instanceof BlockContainer);
    }

    private int getBlockSlot() {
        int i = 36;
        while (i < 45) {
            ItemStack itemStack = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (itemStack != null && itemStack.getItem() instanceof ItemBlock && itemStack.stackSize > 0 && !blacklisted.stream().anyMatch(e -> e.equals(((ItemBlock)itemStack.getItem()).getBlock()))) {
                return i - 36;
            }
            ++i;
        }
        return -1;
    }

    public static boolean isRotating() {
        return rotation.getYaw() != 999.0f || rotation.getPitch() != 999.0f;
    }

    private static class BlockData {
        public static BlockPos position;
        public static EnumFacing face;

        public BlockData(BlockPos position, EnumFacing face, BlockData blockData) {
            BlockData.position = position;
            BlockData.face = face;
        }

        private BlockPos getPosition() {
            return position;
        }

        private EnumFacing getFacing() {
            return face;
        }

        static BlockPos access$0(BlockData var0) {
            return var0.getPosition();
        }

        static EnumFacing access$1(BlockData var0) {
            return var0.getFacing();
        }

        static BlockPos access$2(BlockData var0) {
            return position;
        }

        static EnumFacing access$3(BlockData var0) {
            return face;
        }
    }
}

