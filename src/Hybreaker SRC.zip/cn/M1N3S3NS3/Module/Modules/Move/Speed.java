/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventMove;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Events.World.EventTick;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.TargetStrafe;
import cn.M1N3S3NS3.Module.Modules.Move.Scaffold;
import cn.M1N3S3NS3.Util.MovementUtils;
import cn.M1N3S3NS3.Util.PlayerUtil;
import java.awt.Color;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Timer;

public class Speed
extends Module {
    public Mode<Enum> mode = new Mode("Mode", "mode", (Enum[])SpeedMode.values(), (Enum)SpeedMode.Watchdog);
    public Mode<Enum> mode2 = new Mode("BypassMode", "BypassMode", (Enum[])bypassmode.values(), (Enum)bypassmode.Offset);
    private Option<Boolean> TimerBoost = new Option<Boolean>("TimerBoost", true);
    public static final Numbers<Double> Timer = new Numbers<Double>("Boost", 1.4, 1.0, 5.0, 0.1);
    public static final Numbers<Double> a2 = new Numbers<Double>("TargetStrafe", 0.32, 0.0, 0.5, 0.01);
    public static final Numbers<Double> a1 = new Numbers<Double>("WaterSpeed", 0.32, 0.0, 0.5, 0.01);
    private int stage;
    double stair;
    int ticks = 0;
    private double less;

    public Speed() {
        super("Speed", new String[]{"zoom"}, ModuleType.Move);
        this.setColor(new Color(99, 248, 91).getRGB());
        this.addValues(this.mode, this.mode2, this.TimerBoost, a1, a2, Timer);
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
        net.minecraft.util.Timer.timerSpeed = 1.0f;
        Minecraft.thePlayer.motionX *= 1.0;
        Minecraft.thePlayer.motionY *= 1.0;
        Minecraft.thePlayer.motionZ *= 1.0;
        Minecraft.thePlayer.speedInAir = 0.02f;
    }

    @EventHandler
    public void autojump(EventTick e) {
    }

    @EventHandler
    private void onUpdate(EventPreUpdate e) {
        this.setSuffix(this.mode.getValue());
        Client.getModuleManager();
        Scaffold scaffoldModule = (Scaffold)ModuleManager.getModuleByClass(Scaffold.class);
        Client.getModuleManager();
        TargetStrafe target = (TargetStrafe)ModuleManager.getModuleByClass(TargetStrafe.class);
        if (this.mode.getValue() == SpeedMode.Watchdog) {
            if (this.mode2.getValue() == bypassmode.Offset && MovementUtils.isMoving()) {
                List<Double> BypassOffset = Arrays.asList(0.125, 0.25, 0.375, 0.625, 0.75, 0.015625, 0.5, 0.0625, 0.875, 0.1875);
                double d3 = e.getY() % 1.0;
                BypassOffset.sort(Comparator.comparingDouble(PreY -> Math.abs(PreY - d3)));
                double acc = e.getY() - d3 + BypassOffset.get(0);
                if (Math.abs(BypassOffset.get(0) - d3) < 0.005) {
                    EventPreUpdate.setY(acc);
                    EventPreUpdate.setOnground(true);
                } else {
                    List<Double> BypassOffset2 = Arrays.asList(0.715, 0.945, 0.09, 0.155, 0.14, 0.045, 0.63, 0.31);
                    double d3_ = e.getY() % 1.0;
                    BypassOffset2.sort(Comparator.comparingDouble(PreY -> Math.abs(PreY - d3_)));
                    acc = e.getY() - d3_ + BypassOffset2.get(0);
                    if (Math.abs(BypassOffset2.get(0) - d3_) < 0.005) {
                        EventPreUpdate.setY(acc);
                    }
                }
            }
            if (this.mode2.getValue() == bypassmode.groundSpoof && Minecraft.thePlayer.isMoving() && Minecraft.thePlayer.isCollidedVertically && Minecraft.thePlayer.onGround && Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, 0.5, 0.0)).isEmpty()) {
                EventPreUpdate.y += ThreadLocalRandom.current().nextDouble() / 1000.0;
                EventPreUpdate.ground = true;
            }
            if (this.stair > 0.0) {
                this.stair -= 0.25;
                return;
            }
            if (MovementUtils.isMoving()) {
                if (((Boolean)this.TimerBoost.getValue()).booleanValue() && Minecraft.thePlayer.ticksExisted % 2 == 0) {
                    net.minecraft.util.Timer.timerSpeed = ((Double)Timer.getValue()).floatValue();
                }
                if (MovementUtils.isOnGround(1.0E-4) && MovementUtils.isInLiquid()) {
                    Minecraft.thePlayer.motionY = MovementUtils.getJumpBoostModifier(0.066, false);
                    MovementUtils.setMotion(Math.max((double)0.3f + (double)MovementUtils.getSpeedEffect() * 0.1, PlayerUtil.getBaseMoveSpeed()));
                }
                if (MovementUtils.isOnGround(1.0E-4)) {
                    if (scaffoldModule.isEnabled()) {
                        Minecraft.thePlayer.motionY = MovementUtils.getJumpBoostModifier(0.36, false);
                        MovementUtils.setMotion(Math.max((double)0.4f + (double)MovementUtils.getSpeedEffect() * 0.1, MovementUtils.getBaseMoveSpeed()));
                    } else {
                        Minecraft.thePlayer.motionY = MovementUtils.getJumpBoostModifier(0.39999998, true);
                    }
                    MovementUtils.setMotion(Math.max((double)0.471f + (double)MovementUtils.getSpeedEffect() * 0.1, MovementUtils.getBaseMoveSpeed()));
                } else if (!TargetStrafe.starfe(Math.max((double)((Double)a2.getValue()).floatValue() + (double)MovementUtils.getSpeedEffect() * 0.1, MovementUtils.getBaseMoveSpeed()))) {
                    MovementUtils.setMotion(MovementUtils.getSpeed());
                }
            }
        } else {
            Minecraft.thePlayer.motionX *= 0.25;
            Minecraft.thePlayer.motionZ *= 0.25;
        }
    }

    @EventHandler
    public void onmove22(EventMove e) {
        if (this.mode.getValue() == SpeedMode.Watchdog && MovementUtils.isMoving() && Minecraft.thePlayer.isCollidedHorizontally) {
            MovementUtils.setSpeed(e, MovementUtils.getBaseMoveSpeed());
        }
    }

    public static enum SpeedMode {
        Watchdog,
        AutoJump;

    }

    static enum bypassmode {
        Offset,
        groundSpoof;

    }
}

