/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.PlayerUtil;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;

public class AntiFall
extends Module {
    private BlockPos lastGround;
    private double lastBouncePosY;
    private final TimerUtil timer = new TimerUtil();
    private final TimerUtil timerLagBack = new TimerUtil();
    private final Mode<modeEnums> modeValue = new Mode("Mode", "Lag back mode", (Enum[])modeEnums.values(), (Enum)modeEnums.Update);
    private final Option<Boolean> voidOnlyValue = new Option<Boolean>("Void Only", "Detect blocks under", true);
    private final Numbers<Number> distanceValue = new Numbers<Double>("Distance", "Active distance", 7.0, 3.0, 15.0, 0.5);

    public AntiFall() {
        super("AntiFall", new String[]{"AntiFall"}, ModuleType.Move);
        this.addValues(this.modeValue, this.distanceValue, this.voidOnlyValue);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.timer.reset();
        this.timerLagBack.reset();
        this.lastBouncePosY = 0.0;
        this.lastGround = Minecraft.thePlayer.getPosition().add(0.0, ((Number)this.distanceValue.getValue()).doubleValue(), 0.0);
    }

    @EventHandler
    void onUpdate(EventPreUpdate event) {
        block12: {
            block11: {
                this.setSuffix(this.modeValue.getValue());
                boolean checks = !PlayerUtil.isBlockUnder() || (Boolean)this.voidOnlyValue.getValue() == false;
                if (Minecraft.thePlayer.onGround) {
                    if (Minecraft.thePlayer.ticksExisted % 30 == 0) {
                        this.lastGround = Minecraft.thePlayer.getPosition();
                    }
                    this.lastBouncePosY = 0.0;
                }
                if (!checks) break block11;
                if ((double)Minecraft.thePlayer.fallDistance <= ((Number)this.distanceValue.getValue()).doubleValue() || !this.timerLagBack.hasPassed(500L)) break block11;
                if (!(Minecraft.thePlayer.posY > this.lastBouncePosY - 0.5) || this.lastBouncePosY == 0.0) break block12;
            }
            return;
        }
        switch ((modeEnums)((Object)this.modeValue.getValue())) {
            case Update: {
                event.setX(this.lastGround.getX());
                EventPreUpdate.setY(this.lastGround.getY());
                event.setZ(this.lastGround.getZ());
                this.timerLagBack.reset();
                break;
            }
            case Packet: {
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(this.lastGround.getX(), this.lastGround.getY(), this.lastGround.getZ(), true));
                this.timerLagBack.reset();
                break;
            }
            case Position: {
                Minecraft.thePlayer.setPosition(this.lastGround.getX(), this.lastGround.getY(), this.lastGround.getZ());
                this.timerLagBack.reset();
                break;
            }
            case Bounce: {
                PlayerUtil.setSpeed(0.0);
                Minecraft.thePlayer.motionY = 0.4001999986886975 * (double)(((Number)this.distanceValue.getValue()).intValue() / 2);
                this.lastBouncePosY = Minecraft.thePlayer.posY;
                Minecraft.thePlayer.fallDistance = 0.0f;
                this.timerLagBack.reset();
            }
        }
    }

    private static enum modeEnums {
        Update,
        Packet,
        Bounce,
        Position;

    }
}

