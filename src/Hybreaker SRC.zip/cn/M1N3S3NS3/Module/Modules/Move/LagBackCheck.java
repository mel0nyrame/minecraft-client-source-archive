/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Move;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPacketReceive;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Move.Scaffold;
import cn.M1N3S3NS3.Module.Modules.Move.Speed;
import cn.M1N3S3NS3.UI.notification.Notification;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;

public class LagBackCheck
extends Module {
    private Option<Boolean> boostflight = new Option<Boolean>("Flight lagback", "Flight lagback", true);
    private Option<Boolean> speed = new Option<Boolean>("Speed lagback", "Speed lagback", true);
    private Option<Boolean> scaffold = new Option<Boolean>("Scaffold lagback", "Scaffold lagback", true);
    private Option<Boolean> Longjump = new Option<Boolean>("LongJump lagback", "LongJump lagback", true);
    int sb;

    public LagBackCheck() {
        super("LagBackCheck", new String[]{"Lagback", "LagbackCheck"}, ModuleType.Player);
        this.addValues(this.boostflight, this.speed, this.scaffold, this.Longjump);
    }

    @EventHandler
    private void Onputee(EventPacketReceive event) {
        Speed speed;
        if (!(EventPacketReceive.getPacket() instanceof S08PacketPlayerPosLook)) {
            return;
        }
        Client var10000 = Client.instance;
        Client.instance.getModuleManager();
        Client.instance.getModuleManager();
        if (((Boolean)this.speed.getValue()).booleanValue() && (speed = (Speed)ModuleManager.getModuleByClass(Speed.class)).isEnabled()) {
            speed.setEnabled(false);
            Client.instance.getNotificationManager().getNotifications().add(new Notification("Disabled Speed modules."));
        }
        var10000 = Client.instance;
        Client.instance.getModuleManager();
        Scaffold scaffold = (Scaffold)ModuleManager.getModuleByClass(Scaffold.class);
        if (((Boolean)this.scaffold.getValue()).booleanValue() && scaffold.isEnabled()) {
            scaffold.setEnabled(false);
            Client.instance.getNotificationManager().getNotifications().add(new Notification("Disabled Scaffold modules."));
        }
    }
}

