/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventTick;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.MovementUtils;
import java.awt.Color;

public class Timer
extends Module {
    private Numbers<Double> speed = new Numbers<Double>("Speed", "Speed", 1.0, 0.0, 10.0, 0.01);
    private Option<Boolean> auto = new Option<Boolean>("onMove", true);

    public Timer() {
        super("Timer", new String[]{"timer"}, ModuleType.Player);
        this.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)).getRGB());
        this.addValues(this.speed, this.auto);
    }

    @Override
    public void onEnable() {
        if (MovementUtils.isMoving() || !((Boolean)this.auto.getValue()).booleanValue()) {
            net.minecraft.util.Timer.timerSpeed = ((Double)this.speed.getValue()).floatValue();
            return;
        }
        net.minecraft.util.Timer.timerSpeed = 1.0f;
    }

    @Override
    public void onDisable() {
        net.minecraft.util.Timer.timerSpeed = 1.0f;
    }

    @EventHandler
    public void onTick(EventTick e) {
        this.setSuffix(this.speed.getValue());
        if (MovementUtils.isMoving() || !((Boolean)this.auto.getValue()).booleanValue()) {
            net.minecraft.util.Timer.timerSpeed = ((Double)this.speed.getValue()).floatValue();
            return;
        }
        net.minecraft.util.Timer.timerSpeed = 1.0f;
    }
}

