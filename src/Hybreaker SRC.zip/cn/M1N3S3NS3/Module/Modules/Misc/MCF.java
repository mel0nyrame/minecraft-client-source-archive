/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.Manager.FriendManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Mouse;

public class MCF
extends Module {
    private boolean down;

    public MCF() {
        super("MCF", new String[]{"middleclickfriends", "middleclick"}, ModuleType.Player);
        this.setColor(new Color(241, 175, 67).getRGB());
        super.setRemoved(true);
    }

    @EventHandler
    private void onClick(EventPreUpdate e) {
        if (Mouse.isButtonDown((int)2) && !this.down) {
            if (MCF.mc.objectMouseOver.entityHit != null) {
                EntityPlayer player = (EntityPlayer)MCF.mc.objectMouseOver.entityHit;
                String playername = player.getName();
                if (!FriendManager.isFriend(playername)) {
                    Minecraft.thePlayer.sendChatMessage(".f add " + playername);
                } else {
                    Minecraft.thePlayer.sendChatMessage(".f del " + playername);
                }
            }
            this.down = true;
        }
        if (!Mouse.isButtonDown((int)2)) {
            this.down = false;
        }
    }
}

