/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;

public class ChestStealer
extends Module {
    private Numbers<Double> delay = new Numbers<Double>("Delay", "Delay", 1.0, 0.0, 5.0, 0.1);
    public static Option<Boolean> menucheck = new Option<Boolean>("MenuCheck", "MenuCheck", true);
    public static Option<Boolean> slient = new Option<Boolean>("Slient", "Slient", false);
    private TimerUtil timer = new TimerUtil();

    public ChestStealer() {
        super("ChestStealer", new String[]{"cheststeal", "chests", "stealer"}, ModuleType.Player);
        this.addValues(this.delay, menucheck, slient);
        this.setColor(new Color(218, 97, 127).getRGB());
    }

    @EventHandler
    public void onRender2D(EventRender2D e) {
        if (Minecraft.thePlayer.openContainer != null) {
            boolean cfr_ignored_0 = Minecraft.thePlayer.openContainer instanceof ContainerChest;
        }
    }

    @EventHandler
    private void onUpdate(EventPreUpdate event) {
        if (Minecraft.thePlayer.openContainer != null) {
            if (Minecraft.thePlayer.openContainer instanceof ContainerChest) {
                ContainerChest container = (ContainerChest)Minecraft.thePlayer.openContainer;
                if (((Boolean)menucheck.getValue()).booleanValue()) {
                    String[] list;
                    String name = container.getLowerChestInventory().getDisplayName().getUnformattedText().toLowerCase();
                    String[] stringArray = list = new String[]{"menu", "selector", "game", "gui", "server", "inventory", "play", "teleporter", "shop", "melee", "armor", "block", "castle", "mini", "warp", "teleport", "user", "team", "tool", "sure", "trade", "cancel", "accept", "soul", "book", "recipe", "profile", "tele", "port", "map", "kit", "select", "lobby", "vault", "lock", "anticheat", "travel", "settings", "user", "preference", "compass", "cake", "wars", "buy", "upgrade", "ranged", "potions", "utility"};
                    int n = list.length;
                    int n2 = 0;
                    while (n2 < n) {
                        String str = stringArray[n2];
                        if (name.contains(str)) {
                            return;
                        }
                        ++n2;
                    }
                }
                int i = 0;
                while (i < container.getLowerChestInventory().getSizeInventory()) {
                    if (!(container.getLowerChestInventory().getStackInSlot(i) == null || !this.timer.hasPassed(((Double)this.delay.getValue()).longValue() * 100L) || container.getLowerChestInventory().getStackInSlot(i).getItem() instanceof ItemArmor && !this.betterCheck(container, container.getLowerChestInventory().getStackInSlot(i), i) || container.getLowerChestInventory().getStackInSlot(i).getItem() instanceof ItemSword && !((double)this.getDamage(container.getLowerChestInventory().getStackInSlot(i)) >= this.bestDamage(container, i)))) {
                        Minecraft.playerController.windowClick(container.windowId, i, 0, 1, Minecraft.thePlayer);
                        this.timer.reset();
                    }
                    ++i;
                }
                if (this.isEmpty()) {
                    Minecraft.thePlayer.closeScreen();
                }
            }
        }
    }

    private boolean isEmpty() {
        if (Minecraft.thePlayer.openContainer != null) {
            if (Minecraft.thePlayer.openContainer instanceof ContainerChest) {
                ContainerChest container = (ContainerChest)Minecraft.thePlayer.openContainer;
                int i = 0;
                while (i < container.getLowerChestInventory().getSizeInventory()) {
                    ItemStack itemStack = container.getLowerChestInventory().getStackInSlot(i);
                    if (!(itemStack == null || itemStack.getItem() == null || itemStack.getItem() instanceof ItemArmor && !this.betterCheck(container, itemStack, i) || itemStack.getItem() instanceof ItemSword && !((double)this.getDamage(itemStack) >= this.bestDamage(container, i)))) {
                        return false;
                    }
                    ++i;
                }
            }
        }
        return true;
    }

    private boolean betterCheck(ContainerChest c, ItemStack item, int slot) {
        double temp;
        double var12;
        int i;
        double item1 = (double)((ItemArmor)item.getItem()).damageReduceAmount + this.getProtectionValue(item);
        double item2 = 0.0;
        int bestslot = 0;
        if (item.getUnlocalizedName().contains("helmet")) {
            i = 0;
            while (i < 45) {
                if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                    if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack().getItem().getUnlocalizedName().contains("helmet")) {
                        var12 = ((ItemArmor)Minecraft.thePlayer.inventoryContainer.getSlot((int)i).getStack().getItem()).damageReduceAmount;
                        temp = var12 + this.getProtectionValue(Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack());
                        if (temp > item2) {
                            item2 = temp;
                            bestslot = i;
                        }
                    }
                }
                ++i;
            }
            i = 0;
            while (i < c.getLowerChestInventory().getSizeInventory()) {
                if (c.getLowerChestInventory().getStackInSlot(i) != null && c.getLowerChestInventory().getStackInSlot(i).getUnlocalizedName().contains("helmet") && (temp = (double)((ItemArmor)c.getLowerChestInventory().getStackInSlot((int)i).getItem()).damageReduceAmount + this.getProtectionValue(c.getLowerChestInventory().getStackInSlot(i))) > item2) {
                    item2 = temp;
                    bestslot = i;
                }
                ++i;
            }
        }
        if (item.getUnlocalizedName().contains("chestplate")) {
            i = 0;
            while (i < 45) {
                if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                    if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack().getItem().getUnlocalizedName().contains("chestplate")) {
                        var12 = ((ItemArmor)Minecraft.thePlayer.inventoryContainer.getSlot((int)i).getStack().getItem()).damageReduceAmount;
                        temp = var12 + this.getProtectionValue(Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack());
                        if (temp > item2) {
                            item2 = temp;
                            bestslot = i;
                        }
                    }
                }
                ++i;
            }
            i = 0;
            while (i < c.getLowerChestInventory().getSizeInventory()) {
                if (c.getLowerChestInventory().getStackInSlot(i) != null && c.getLowerChestInventory().getStackInSlot(i).getUnlocalizedName().contains("chestplate") && (temp = (double)((ItemArmor)c.getLowerChestInventory().getStackInSlot((int)i).getItem()).damageReduceAmount + this.getProtectionValue(c.getLowerChestInventory().getStackInSlot(i))) > item2) {
                    item2 = temp;
                    bestslot = i;
                }
                ++i;
            }
        }
        if (item.getUnlocalizedName().contains("leggings")) {
            i = 0;
            while (i < 45) {
                if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                    if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack().getItem().getUnlocalizedName().contains("leggings")) {
                        var12 = ((ItemArmor)Minecraft.thePlayer.inventoryContainer.getSlot((int)i).getStack().getItem()).damageReduceAmount;
                        temp = var12 + this.getProtectionValue(Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack());
                        if (temp > item2) {
                            item2 = temp;
                            bestslot = i;
                        }
                    }
                }
                ++i;
            }
            i = 0;
            while (i < c.getLowerChestInventory().getSizeInventory()) {
                if (c.getLowerChestInventory().getStackInSlot(i) != null && c.getLowerChestInventory().getStackInSlot(i).getUnlocalizedName().contains("leggings") && (temp = (double)((ItemArmor)c.getLowerChestInventory().getStackInSlot((int)i).getItem()).damageReduceAmount + this.getProtectionValue(c.getLowerChestInventory().getStackInSlot(i))) > item2) {
                    item2 = temp;
                    bestslot = i;
                }
                ++i;
            }
        }
        if (item.getUnlocalizedName().contains("boots")) {
            i = 0;
            while (i < 45) {
                if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                    if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack().getItem().getUnlocalizedName().contains("boots")) {
                        var12 = ((ItemArmor)Minecraft.thePlayer.inventoryContainer.getSlot((int)i).getStack().getItem()).damageReduceAmount;
                        temp = var12 + this.getProtectionValue(Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack());
                        if (temp > item2) {
                            item2 = temp;
                            bestslot = i;
                        }
                    }
                }
                ++i;
            }
            i = 0;
            while (i < c.getLowerChestInventory().getSizeInventory()) {
                if (c.getLowerChestInventory().getStackInSlot(i) != null && c.getLowerChestInventory().getStackInSlot(i).getUnlocalizedName().contains("boots") && (temp = (double)((ItemArmor)c.getLowerChestInventory().getStackInSlot((int)i).getItem()).damageReduceAmount + this.getProtectionValue(c.getLowerChestInventory().getStackInSlot(i))) > item2) {
                    item2 = temp;
                    bestslot = i;
                }
                ++i;
            }
        }
        return item1 >= item2 && c.getLowerChestInventory().getStackInSlot(bestslot) == item;
    }

    private double getProtectionValue(ItemStack stack) {
        return stack.getItem() instanceof ItemArmor ? (double)((ItemArmor)stack.getItem()).damageReduceAmount + (double)((100 - ((ItemArmor)stack.getItem()).damageReduceAmount) * EnchantmentHelper.getEnchantmentLevel(Enchantment.protection.effectId, stack)) * 0.0075 : 0.0;
    }

    private double bestDamage(ContainerChest container, int slot) {
        ItemStack is;
        double bestDamage = 0.0;
        int i = 0;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (is.getItem() instanceof ItemSword && (double)this.getDamage(is) > bestDamage) {
                    bestDamage = this.getDamage(is);
                }
            }
            ++i;
        }
        i = 0;
        while (i < container.getLowerChestInventory().getSizeInventory()) {
            if (container.getLowerChestInventory().getStackInSlot(i) != null) {
                is = container.getLowerChestInventory().getStackInSlot(i);
                if (i != slot && is.getItem() instanceof ItemSword && (double)this.getDamage(is) > bestDamage) {
                    bestDamage = this.getDamage(is);
                }
            }
            ++i;
        }
        return bestDamage;
    }

    private float getDamage(ItemStack stack) {
        float damage = 0.0f;
        Item item = stack.getItem();
        if (item instanceof ItemTool) {
            damage += this.getSpeed(stack);
        }
        damage = item instanceof ItemSword ? (damage += this.getAttackDamage(stack)) : (damage += 1.0f);
        return damage;
    }

    private float getAttackDamage(ItemStack itemStack) {
        float damage = ((ItemSword)itemStack.getItem()).getDamageVsEntity();
        damage += (float)EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId, itemStack) * 1.25f;
        return damage += (float)EnchantmentHelper.getEnchantmentLevel(Enchantment.fireAspect.effectId, itemStack) * 0.01f;
    }

    private float getSpeed(ItemStack stack) {
        return ((ItemTool)stack.getItem()).getToolMaterial().getEfficiencyOnProperMaterial();
    }
}

