/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPacket;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.network.play.client.C01PacketChatMessage;

public class ChatFilter
extends Module {
    public Option<Boolean> OBF = new Option<Boolean>("ObfSucator", "ObfSucator", true);
    private Option<Boolean> BYPASS = new Option<Boolean>("Bypass", "Byass", true);

    public ChatFilter() {
        super("ChatFilter", new String[]{"ChatFilter", "ChatFilter"}, ModuleType.Player);
        this.setColor(new Color(242, 137, 73).getRGB());
        this.addValues(this.OBF, this.BYPASS);
    }

    @EventHandler
    public void onPacket(EventPacket event) {
        this.setSuffix((Boolean)this.BYPASS.getValue() != false ? "Bypass" : "");
        if (((Boolean)this.BYPASS.getValue()).booleanValue() && event.isOutgoing() && event.getPacket() instanceof C01PacketChatMessage) {
            C01PacketChatMessage c01PacketChatMessage = (C01PacketChatMessage)event.getPacket();
            String string = "";
            ArrayList<String> list = new ArrayList<String>();
            String[] split = c01PacketChatMessage.getMessage().split(" ");
            int i = 0;
            while (i < split.length) {
                char[] charArray = split[i].toCharArray();
                int j = 0;
                while (j < charArray.length) {
                    list.add(String.valueOf(charArray[j]) + "uF8FF");
                    ++j;
                }
                list.add(" ");
                ++i;
            }
            int k = 0;
            while (k < list.size()) {
                string = String.valueOf(string) + (String)list.get(k);
                ++k;
            }
            if (c01PacketChatMessage.getMessage().startsWith("%")) {
                c01PacketChatMessage.setMessage(string.replaceFirst("%", ""));
                list.clear();
            }
        }
    }
}

