/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import net.minecraft.client.Minecraft;

public class AutoRejoin
extends Module {
    private boolean down;

    public AutoRejoin() {
        super("AutoRejoin", new String[]{"AutoRejoin", "AutoRejoin"}, ModuleType.Player);
    }

    @Override
    public void onEnable() {
        this.setEnabled(false);
        if (Minecraft.thePlayer == null) {
            return;
        }
        Minecraft.thePlayer.sendChatMessage("/lobby");
        new Thread(() -> {
            try {
                Thread.sleep(200L);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
            Minecraft.thePlayer.sendChatMessage("/back");
        }).start();
    }
}

