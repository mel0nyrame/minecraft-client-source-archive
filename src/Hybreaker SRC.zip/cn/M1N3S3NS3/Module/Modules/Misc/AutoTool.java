/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPacketSend;
import cn.M1N3S3NS3.API.Events.World.EventTick;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Move.Scaffold;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;
import org.lwjgl.input.Mouse;

public class AutoTool
extends Module {
    public Minecraft mc = Minecraft.getMinecraft();
    private int oldSlot = -1;
    private boolean wasBreaking = false;

    public AutoTool() {
        super("Auto Tool", new String[]{"AutoTool"}, ModuleType.Player);
        super.setRemoved(true);
        this.setCustomName("Auto Tool");
    }

    public Class type() {
        return EventPacketSend.class;
    }

    @EventHandler
    public void onEvent(EventTick event) {
        Client.getModuleManager();
        if (ModuleManager.getModuleByClass(Scaffold.class).isEnabled()) {
            return;
        }
        if (this.mc.currentScreen == null && Minecraft.thePlayer != null && Minecraft.theWorld != null && this.mc.objectMouseOver != null && this.mc.objectMouseOver.getBlockPos() != null && this.mc.objectMouseOver.entityHit == null && Mouse.isButtonDown((int)0)) {
            float bestSpeed = 1.0f;
            int bestSlot = -1;
            Block block = Minecraft.theWorld.getBlockState(this.mc.objectMouseOver.getBlockPos()).getBlock();
            int k = 0;
            while (k < 9) {
                float speed;
                ItemStack item = Minecraft.thePlayer.inventory.getStackInSlot(k);
                if (item != null && (speed = item.getStrVsBlock(block)) > bestSpeed) {
                    bestSpeed = speed;
                    bestSlot = k;
                }
                ++k;
            }
            if (bestSlot != -1 && Minecraft.thePlayer.inventory.currentItem != bestSlot) {
                Minecraft.thePlayer.inventory.currentItem = bestSlot;
                this.wasBreaking = true;
            } else if (bestSlot == -1) {
                if (this.wasBreaking) {
                    Minecraft.thePlayer.inventory.currentItem = this.oldSlot;
                    this.wasBreaking = false;
                }
                this.oldSlot = Minecraft.thePlayer.inventory.currentItem;
            }
        } else if (Minecraft.thePlayer != null && Minecraft.theWorld != null) {
            if (this.wasBreaking) {
                Minecraft.thePlayer.inventory.currentItem = this.oldSlot;
                this.wasBreaking = false;
            }
            this.oldSlot = Minecraft.thePlayer.inventory.currentItem;
        }
    }
}

