/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventTick;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import java.awt.Color;
import java.util.Arrays;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;

public class FastPlace
extends Module {
    private final Numbers<Double> delay = new Numbers<Double>("Delay", 1.0, 0.0, 4.0, 1.0);
    private final List blackList = Arrays.asList(Blocks.air, Blocks.water, Blocks.torch, Blocks.redstone_torch, Blocks.ladder, Blocks.flowing_water, Blocks.lava, Blocks.flowing_lava, Blocks.enchanting_table, Blocks.carpet, Blocks.glass_pane, Blocks.stained_glass_pane, Blocks.iron_bars, Blocks.chest, Blocks.torch, Blocks.anvil, Blocks.web, Blocks.redstone_torch, Blocks.brewing_stand, Blocks.waterlily, Blocks.farmland, Blocks.sand, Blocks.beacon, Blocks.double_plant, Blocks.noteblock, Blocks.hopper, Blocks.dispenser, Blocks.dropper);

    public FastPlace() {
        super("FastPlace", new String[]{"fPlace", "fc", "fp"}, ModuleType.Player);
        this.setColor(new Color(226, 197, 78).getRGB());
        this.addValues(this.delay);
    }

    @EventHandler
    private void onTick(EventTick e) {
        if (Minecraft.thePlayer.getHeldItem() != null) {
            if (Minecraft.thePlayer.getHeldItem().getItem() instanceof ItemBlock) {
                if (!this.blackList.contains(((ItemBlock)Minecraft.thePlayer.getHeldItem().getItem()).getBlock())) {
                    FastPlace.mc.rightClickDelayTimer = ((Double)this.delay.getValue()).intValue();
                }
            }
        }
    }
}

