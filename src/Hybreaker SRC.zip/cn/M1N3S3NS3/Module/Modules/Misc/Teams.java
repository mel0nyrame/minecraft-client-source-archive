/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class Teams
extends Module {
    public Teams() {
        super("Teams", new String[0], ModuleType.Player);
        super.setRemoved(true);
    }

    public static boolean isOnSameTeam(Entity entity) {
        Client.instance.getModuleManager();
        if (!ModuleManager.getModuleByClass(Teams.class).isEnabled()) {
            return false;
        }
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.getDisplayName().getUnformattedText().startsWith("\u00a7")) {
            Minecraft.getMinecraft();
            if (Minecraft.thePlayer.getDisplayName().getUnformattedText().length() <= 2 || entity.getDisplayName().getUnformattedText().length() <= 2) {
                return false;
            }
            Minecraft.getMinecraft();
            if (Minecraft.thePlayer.getDisplayName().getUnformattedText().substring(0, 2).equals(entity.getDisplayName().getUnformattedText().substring(0, 2))) {
                return true;
            }
        }
        return false;
    }

    private static String isTeam(EntityPlayer player) {
        Matcher m = Pattern.compile("\u00a7(.).*\u00a7r").matcher(player.getDisplayName().getFormattedText());
        return m.find() ? m.group(1) : "f";
    }

    public static boolean isTeam(EntityPlayer e, EntityPlayer e2) {
        return e.getDisplayName().getFormattedText().contains("\u00a7" + Teams.isTeam(e)) && e2.getDisplayName().getFormattedText().contains("\u00a7" + Teams.isTeam(e));
    }
}

