/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import net.minecraft.client.Minecraft;

public class AutoKill
extends Module {
    private boolean down;

    public AutoKill() {
        super("AutoKill", new String[]{"AutoKill", "AutoKill"}, ModuleType.Player);
    }

    @Override
    public void onEnable() {
        this.setEnabled(false);
        if (Minecraft.thePlayer == null) {
            return;
        }
        Minecraft.thePlayer.sendChatMessage("/kill");
    }
}

