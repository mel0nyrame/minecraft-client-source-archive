/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Misc.AutoArmor;
import cn.M1N3S3NS3.Module.Modules.Move.Scaffold;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemGlassBottle;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemSkull;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class InvCleaner
extends Module {
    private Numbers<Double> BlockCap = new Numbers<Double>("BlockCap", "BlockCap", 128.0, 0.0, 256.0, 8.0);
    private Numbers<Double> Delay = new Numbers<Double>("Delay", "Delay", 1.0, 0.0, 10.0, 1.0);
    private Option<Boolean> Food = new Option<Boolean>("Food", "Food", true);
    private Option<Boolean> sort = new Option<Boolean>("sort", "sort", true);
    private Option<Boolean> Archery = new Option<Boolean>("Archery", "Archery", true);
    private Option<Boolean> Sword = new Option<Boolean>("Sword", "Sword", true);
    private Mode<Enum> Mode = new Mode("Mode", "Mode", (Enum[])EMode.values(), (Enum)EMode.Basic);
    private Option<Boolean> InvCleaner = new Option<Boolean>("InvCleaner", "InvCleaner", true);
    private Option<Boolean> UHC = new Option<Boolean>("UHC", "UHC", false);
    public static int weaponSlot = 36;
    public static int pickaxeSlot = 37;
    public static int axeSlot = 38;
    public static int shovelSlot = 39;
    TimerUtil timer = new TimerUtil();
    ArrayList<Integer> whitelistedItems = new ArrayList();

    public InvCleaner() {
        super("InvCleaner", new String[]{"InvCleaner"}, ModuleType.Player);
        this.addValues(this.BlockCap, this.Delay, this.Food, this.Archery, this.Sword, this.Mode, this.InvCleaner, this.sort, this.UHC);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @EventHandler
    public void onEvent(EventPreUpdate event) {
        ItemStack is;
        this.setColor(new Color(16728020).getRGB());
        if (Minecraft.thePlayer.openContainer instanceof ContainerChest && cn.M1N3S3NS3.Module.Modules.Misc.InvCleaner.mc.currentScreen instanceof GuiContainer) {
            return;
        }
        Client.instance.getModuleManager();
        InvCleaner i3 = (InvCleaner)ModuleManager.getModuleByClass(InvCleaner.class);
        long delay = ((Double)this.Delay.getValue()).longValue() * 50L;
        EventPreUpdate em = event;
        long Adelay = ((Double)AutoArmor.DELAY.getValue()).longValue() * 50L;
        if (this.timer.hasReached(Adelay) && i3.isEnabled() && (i3.Mode.getValue() != AutoArmor.EMode.OpenInv || cn.M1N3S3NS3.Module.Modules.Misc.InvCleaner.mc.currentScreen instanceof GuiInventory) && (cn.M1N3S3NS3.Module.Modules.Misc.InvCleaner.mc.currentScreen == null || cn.M1N3S3NS3.Module.Modules.Misc.InvCleaner.mc.currentScreen instanceof GuiInventory || cn.M1N3S3NS3.Module.Modules.Misc.InvCleaner.mc.currentScreen instanceof GuiChat)) {
            this.getBestArmor();
        }
        if (i3.isEnabled()) {
            int type = 1;
            while (type < 5) {
                if (Minecraft.thePlayer.inventoryContainer.getSlot(4 + type).getHasStack()) {
                    is = Minecraft.thePlayer.inventoryContainer.getSlot(4 + type).getStack();
                    if (!AutoArmor.isBestArmor(is, type)) {
                        return;
                    }
                } else if (this.invContainsType(type - 1)) {
                    return;
                }
                ++type;
            }
        }
        if (this.Mode.getValue() == EMode.OpenInv && !(cn.M1N3S3NS3.Module.Modules.Misc.InvCleaner.mc.currentScreen instanceof GuiInventory)) {
            return;
        }
        if (cn.M1N3S3NS3.Module.Modules.Misc.InvCleaner.mc.currentScreen == null || cn.M1N3S3NS3.Module.Modules.Misc.InvCleaner.mc.currentScreen instanceof GuiInventory || cn.M1N3S3NS3.Module.Modules.Misc.InvCleaner.mc.currentScreen instanceof GuiChat) {
            if (this.timer.hasReached(delay) && weaponSlot >= 36) {
                if (!Minecraft.thePlayer.inventoryContainer.getSlot(weaponSlot).getHasStack()) {
                    this.getBestWeapon(weaponSlot);
                } else if (!this.isBestWeapon(Minecraft.thePlayer.inventoryContainer.getSlot(weaponSlot).getStack())) {
                    this.getBestWeapon(weaponSlot);
                }
            }
            if (((Boolean)this.sort.getValue()).booleanValue()) {
                if (this.timer.hasReached(delay) && pickaxeSlot >= 36) {
                    this.getBestPickaxe(pickaxeSlot);
                }
                if (this.timer.hasReached(delay) && shovelSlot >= 36) {
                    this.getBestShovel(shovelSlot);
                }
                if (this.timer.hasReached(delay) && axeSlot >= 36) {
                    this.getBestAxe(axeSlot);
                }
            }
            if (this.timer.hasReached(delay) && ((Boolean)this.InvCleaner.getValue()).booleanValue()) {
                int i = 9;
                while (i < 45) {
                    if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                        is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                        if (this.shouldDrop(is, i)) {
                            this.drop(i);
                            this.timer.reset();
                            if (delay > 0L) break;
                        }
                    }
                    ++i;
                }
            }
        }
    }

    public void shiftClick(int slot) {
        Minecraft.playerController.windowClick(Minecraft.thePlayer.inventoryContainer.windowId, slot, 0, 1, Minecraft.thePlayer);
    }

    public void swap(int slot1, int hotbarSlot) {
        Minecraft.playerController.windowClick(Minecraft.thePlayer.inventoryContainer.windowId, slot1, hotbarSlot, 2, Minecraft.thePlayer);
    }

    public void drop(int slot) {
        Minecraft.playerController.windowClick(Minecraft.thePlayer.inventoryContainer.windowId, slot, 1, 4, Minecraft.thePlayer);
    }

    public boolean isBestWeapon(ItemStack stack) {
        float damage = this.getDamage(stack);
        int i = 9;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (this.getDamage(is) > damage && (is.getItem() instanceof ItemSword || !((Boolean)this.Sword.getValue()).booleanValue())) {
                    return false;
                }
            }
            ++i;
        }
        return stack.getItem() instanceof ItemSword || (Boolean)this.Sword.getValue() == false;
    }

    public void getBestWeapon(int slot) {
        int i = 9;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (this.isBestWeapon(is) && this.getDamage(is) > 0.0f && (is.getItem() instanceof ItemSword || !((Boolean)this.Sword.getValue()).booleanValue())) {
                    this.swap(i, slot - 36);
                    this.timer.reset();
                    break;
                }
            }
            ++i;
        }
    }

    private float getDamage(ItemStack stack) {
        float damage = 0.0f;
        Item item = stack.getItem();
        if (item instanceof ItemTool) {
            ItemTool tool = (ItemTool)item;
            damage += (float)tool.getMaxDamage();
        }
        if (item instanceof ItemSword) {
            ItemSword sword = (ItemSword)item;
            damage += sword.getDamageVsEntity();
        }
        return damage += (float)EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId, stack) * 1.25f + (float)EnchantmentHelper.getEnchantmentLevel(Enchantment.fireAspect.effectId, stack) * 0.01f;
    }

    public boolean shouldDrop(ItemStack stack, int slot) {
        block88: {
            block87: {
                block84: {
                    block86: {
                        block85: {
                            block83: {
                                if (stack.getDisplayName().contains("\u70b9\u51fb")) {
                                    return false;
                                }
                                if (stack.getDisplayName().contains("\u53f3\u952e")) {
                                    return false;
                                }
                                if (stack.getDisplayName().toLowerCase().contains("(right click)")) {
                                    return false;
                                }
                                if (stack.getItem() instanceof ItemSkull) {
                                    return false;
                                }
                                if (((Boolean)this.UHC.getValue()).booleanValue()) {
                                    if (stack.getDisplayName().toLowerCase().contains("\u5934")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("apple")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("head")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("gold")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("crafting table")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("stick")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("and") && stack.getDisplayName().toLowerCase().contains("ril")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("axe of perun")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("barbarian")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("bloodlust")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("dragonchest")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("dragon sword")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("dragon armor")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("excalibur")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("exodus")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("fusion armor")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("hermes boots")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("hide of leviathan")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("scythe")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("seven-league boots")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("shoes of vidar")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("apprentice")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("master")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("vorpal")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("enchanted")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("spiked")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("tarnhelm")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("philosopher")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("anvil")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("panacea")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("fusion")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("excalibur")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u5b66\u5f92")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u5927\u5e08\u7f57\u76d8")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u65a9\u9996\u4e4b\u5251")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u9644\u9b54")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u5de8\u9f99\u4e4b\u5251")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u5de8\u9f99\u4e4b\u7532")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u5203\u7532")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u4e03\u56fd\u6218\u9774")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u51b0\u6597\u6e56")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u54f2\u4eba")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u94c1\u7827")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u82f9\u679c")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u91d1")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u6c38\u751f\u4e4b\u9152")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u4e18\u6bd4\u7279\u4e4b\u5f13")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u953b\u7089")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("backpack")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u805a\u53d8\u4e4b\u7532")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u80cc\u5305")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u6708\u795e")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u6c38\u751f")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u6f6e\u6c50")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u96f7\u65a7")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u738b\u8005\u4e4b\u5251")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u5b89\u90fd\u745e\u5c14")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u6b7b\u795e\u9570\u5200")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u4e30\u9976\u4e4b\u89d2")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u7ef4\u8fbe\u6218\u9774")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u593a\u9b42\u4e4b\u5203")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u86ee\u4eba\u4e4b\u7532")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("\u7a83\u8d3c\u4e4b\u9774")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("hermes")) {
                                        return false;
                                    }
                                    if (stack.getDisplayName().toLowerCase().contains("barbarian")) {
                                        return false;
                                    }
                                }
                                if (slot != weaponSlot) break block83;
                                if (this.isBestWeapon(Minecraft.thePlayer.inventoryContainer.getSlot(weaponSlot).getStack())) break block84;
                            }
                            if (slot != pickaxeSlot) break block85;
                            if (this.isBestPickaxe(Minecraft.thePlayer.inventoryContainer.getSlot(pickaxeSlot).getStack()) && pickaxeSlot >= 0) break block84;
                        }
                        if (slot != axeSlot) break block86;
                        if (this.isBestAxe(Minecraft.thePlayer.inventoryContainer.getSlot(axeSlot).getStack()) && axeSlot >= 0) break block84;
                    }
                    if (slot != shovelSlot) break block87;
                    if (!this.isBestShovel(Minecraft.thePlayer.inventoryContainer.getSlot(shovelSlot).getStack()) || shovelSlot < 0) break block87;
                }
                return false;
            }
            if (!(stack.getItem() instanceof ItemArmor)) break block88;
            int type = 1;
            while (type < 5) {
                block90: {
                    block89: {
                        if (!Minecraft.thePlayer.inventoryContainer.getSlot(4 + type).getHasStack()) break block89;
                        ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(4 + type).getStack();
                        if (AutoArmor.isBestArmor(is, type)) break block90;
                    }
                    if (AutoArmor.isBestArmor(stack, type)) {
                        return false;
                    }
                }
                ++type;
            }
        }
        if (((Double)this.BlockCap.getValue()).intValue() != 0 && stack.getItem() instanceof ItemBlock && (this.getBlockCount() > ((Double)this.BlockCap.getValue()).intValue() || Scaffold.blacklisted.contains(((ItemBlock)stack.getItem()).getBlock()))) {
            return true;
        }
        if (stack.getItem() instanceof ItemPotion && this.isBadPotion(stack)) {
            return true;
        }
        if (stack.getItem() instanceof ItemFood && ((Boolean)this.Food.getValue()).booleanValue() && !(stack.getItem() instanceof ItemAppleGold)) {
            return true;
        }
        if (stack.getItem() instanceof ItemHoe || stack.getItem() instanceof ItemTool || stack.getItem() instanceof ItemSword || stack.getItem() instanceof ItemArmor) {
            return true;
        }
        if ((stack.getItem() instanceof ItemBow || stack.getItem().getUnlocalizedName().contains("arrow")) && ((Boolean)this.Archery.getValue()).booleanValue()) {
            return true;
        }
        return stack.getItem().getUnlocalizedName().contains("tnt") || stack.getItem().getUnlocalizedName().contains("stick") || stack.getItem().getUnlocalizedName().contains("egg") || stack.getItem().getUnlocalizedName().contains("string") || stack.getItem().getUnlocalizedName().contains("cake") || stack.getItem().getUnlocalizedName().contains("mushroom") || stack.getItem().getUnlocalizedName().contains("flint") || stack.getItem().getUnlocalizedName().contains("compass") || stack.getItem().getUnlocalizedName().contains("dyePowder") || stack.getItem().getUnlocalizedName().contains("feather") || stack.getItem().getUnlocalizedName().contains("bucket") || stack.getItem().getUnlocalizedName().contains("chest") && !stack.getDisplayName().toLowerCase().contains("collect") || stack.getItem().getUnlocalizedName().contains("snow") || stack.getItem().getUnlocalizedName().contains("fish") || stack.getItem().getUnlocalizedName().contains("enchant") || stack.getItem().getUnlocalizedName().contains("exp") || stack.getItem().getUnlocalizedName().contains("shears") || stack.getItem().getUnlocalizedName().contains("anvil") || stack.getItem().getUnlocalizedName().contains("torch") || stack.getItem().getUnlocalizedName().contains("seeds") || stack.getItem().getUnlocalizedName().contains("leather") || stack.getItem().getUnlocalizedName().contains("reeds") || stack.getItem().getUnlocalizedName().contains("skull") || stack.getItem().getUnlocalizedName().contains("record") || stack.getItem().getUnlocalizedName().contains("snowball") || stack.getItem() instanceof ItemGlassBottle || stack.getItem().getUnlocalizedName().contains("piston");
    }

    public ArrayList<Integer> getWhitelistedItem() {
        return this.whitelistedItems;
    }

    private int getBlockCount() {
        int blockCount = 0;
        int i = 0;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                Item item = is.getItem();
                if (is.getItem() instanceof ItemBlock && !Scaffold.blacklisted.contains(((ItemBlock)item).getBlock())) {
                    blockCount += is.stackSize;
                }
            }
            ++i;
        }
        return blockCount;
    }

    private void getBestPickaxe(int slot) {
        int i = 9;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (this.isBestPickaxe(is) && pickaxeSlot != i && !this.isBestWeapon(is)) {
                    if (!Minecraft.thePlayer.inventoryContainer.getSlot(pickaxeSlot).getHasStack()) {
                        this.swap(i, pickaxeSlot - 36);
                        this.timer.reset();
                        if (((Double)this.Delay.getValue()).longValue() > 0L) {
                            return;
                        }
                    } else if (!this.isBestPickaxe(Minecraft.thePlayer.inventoryContainer.getSlot(pickaxeSlot).getStack())) {
                        this.swap(i, pickaxeSlot - 36);
                        this.timer.reset();
                        if (((Double)this.Delay.getValue()).longValue() > 0L) {
                            return;
                        }
                    }
                }
            }
            ++i;
        }
    }

    private void getBestShovel(int slot) {
        int i = 9;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (this.isBestShovel(is) && shovelSlot != i && !this.isBestWeapon(is)) {
                    if (!Minecraft.thePlayer.inventoryContainer.getSlot(shovelSlot).getHasStack()) {
                        this.swap(i, shovelSlot - 36);
                        this.timer.reset();
                        if (((Double)this.Delay.getValue()).longValue() > 0L) {
                            return;
                        }
                    } else if (!this.isBestShovel(Minecraft.thePlayer.inventoryContainer.getSlot(shovelSlot).getStack())) {
                        this.swap(i, shovelSlot - 36);
                        this.timer.reset();
                        if (((Double)this.Delay.getValue()).longValue() > 0L) {
                            return;
                        }
                    }
                }
            }
            ++i;
        }
    }

    private void getBestAxe(int slot) {
        int i = 9;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (this.isBestAxe(is) && axeSlot != i && !this.isBestWeapon(is)) {
                    if (!Minecraft.thePlayer.inventoryContainer.getSlot(axeSlot).getHasStack()) {
                        this.swap(i, axeSlot - 36);
                        this.timer.reset();
                        if (((Double)this.Delay.getValue()).longValue() > 0L) {
                            return;
                        }
                    } else if (!this.isBestAxe(Minecraft.thePlayer.inventoryContainer.getSlot(axeSlot).getStack())) {
                        this.swap(i, axeSlot - 36);
                        this.timer.reset();
                        if (((Double)this.Delay.getValue()).longValue() > 0L) {
                            return;
                        }
                    }
                }
            }
            ++i;
        }
    }

    private boolean isBestPickaxe(ItemStack stack) {
        Item item = stack.getItem();
        if (!(item instanceof ItemPickaxe)) {
            return false;
        }
        float value = this.getToolEffect(stack);
        int i = 9;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (this.getToolEffect(is) > value && is.getItem() instanceof ItemPickaxe) {
                    return false;
                }
            }
            ++i;
        }
        return true;
    }

    private boolean isBestShovel(ItemStack stack) {
        Item item = stack.getItem();
        if (!(item instanceof ItemSpade)) {
            return false;
        }
        float value = this.getToolEffect(stack);
        int i = 9;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (this.getToolEffect(is) > value && is.getItem() instanceof ItemSpade) {
                    return false;
                }
            }
            ++i;
        }
        return true;
    }

    private boolean isBestAxe(ItemStack stack) {
        Item item = stack.getItem();
        if (!(item instanceof ItemAxe)) {
            return false;
        }
        float value = this.getToolEffect(stack);
        int i = 9;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (this.getToolEffect(is) > value && is.getItem() instanceof ItemAxe && !this.isBestWeapon(stack)) {
                    return false;
                }
            }
            ++i;
        }
        return true;
    }

    private float getToolEffect(ItemStack stack) {
        Item item = stack.getItem();
        if (!(item instanceof ItemTool)) {
            return 0.0f;
        }
        String name = item.getUnlocalizedName();
        ItemTool tool = (ItemTool)item;
        float value = 1.0f;
        if (item instanceof ItemPickaxe) {
            value = tool.getStrVsBlock(stack, Blocks.stone);
            if (name.toLowerCase().contains("gold")) {
                value -= 5.0f;
            }
        } else if (item instanceof ItemSpade) {
            value = tool.getStrVsBlock(stack, Blocks.dirt);
            if (name.toLowerCase().contains("gold")) {
                value -= 5.0f;
            }
        } else if (item instanceof ItemAxe) {
            value = tool.getStrVsBlock(stack, Blocks.log);
            if (name.toLowerCase().contains("gold")) {
                value -= 5.0f;
            }
        } else {
            return 1.0f;
        }
        value = (float)((double)value + (double)EnchantmentHelper.getEnchantmentLevel(Enchantment.efficiency.effectId, stack) * 0.0075);
        value = (float)((double)value + (double)EnchantmentHelper.getEnchantmentLevel(Enchantment.unbreaking.effectId, stack) / 100.0);
        return value;
    }

    private boolean isBadPotion(ItemStack stack) {
        if (stack != null && stack.getItem() instanceof ItemPotion) {
            ItemPotion potion = (ItemPotion)stack.getItem();
            if (potion.getEffects(stack) == null) {
                return true;
            }
            for (PotionEffect o : potion.getEffects(stack)) {
                PotionEffect effect = o;
                if (effect.getPotionID() != Potion.poison.getId() && effect.getPotionID() != Potion.harm.getId() && effect.getPotionID() != Potion.moveSlowdown.getId() && effect.getPotionID() != Potion.weakness.getId()) continue;
                return true;
            }
        }
        return false;
    }

    boolean invContainsType(int type) {
        int i = 9;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                Item item = is.getItem();
                if (item instanceof ItemArmor) {
                    ItemArmor armor = (ItemArmor)item;
                    if (type == armor.armorType) {
                        return true;
                    }
                }
            }
            ++i;
        }
        return false;
    }

    public void getBestArmor() {
        int type = 1;
        while (type < 5) {
            block9: {
                block8: {
                    if (!Minecraft.thePlayer.inventoryContainer.getSlot(4 + type).getHasStack()) break block8;
                    ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(4 + type).getStack();
                    if (AutoArmor.isBestArmor(is, type)) break block9;
                    this.drop(4 + type);
                }
                int i = 9;
                while (i < 45) {
                    if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                        ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                        if (AutoArmor.isBestArmor(is, type) && AutoArmor.getProtection(is) > 0.0f) {
                            this.shiftClick(i);
                            this.timer.reset();
                            if (((Double)this.Delay.getValue()).longValue() > 0L) {
                                return;
                            }
                        }
                    }
                    ++i;
                }
            }
            ++type;
        }
    }

    static enum EMode {
        Basic,
        OpenInv;

    }
}

