/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C16PacketClientStatus;

public class AutoArmor
extends Module {
    public static Numbers<Double> DELAY = new Numbers<Double>("DELAY", "DELAY", 1.0, 0.0, 5.0, 1.0);
    public static Mode<Enum> MODE = new Mode("MODE", "MODE", (Enum[])EMode.values(), (Enum)EMode.Vanilla);
    private TimerUtil timer = new TimerUtil();

    public AutoArmor() {
        super("AutoArmor", new String[]{"AutoArmor"}, ModuleType.Player);
        super.addValues(DELAY, MODE);
        super.setRemoved(true);
    }

    @EventHandler
    public void onEvent(EventPreUpdate event) {
        block10: {
            long delay = (long)((Double)DELAY.getValue()).intValue() * 100L;
            if (MODE.getValue() == EMode.OpenInv && !(AutoArmor.mc.currentScreen instanceof GuiInventory)) {
                return;
            }
            if (AutoArmor.mc.currentScreen != null && !(AutoArmor.mc.currentScreen instanceof GuiInventory) && !(AutoArmor.mc.currentScreen instanceof GuiChat) || !this.timer.hasPassed(delay)) break block10;
            int type = 1;
            while (type < 5) {
                block12: {
                    block11: {
                        if (!Minecraft.thePlayer.inventoryContainer.getSlot(4 + type).getHasStack()) break block11;
                        ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(4 + type).getStack();
                        if (AutoArmor.isBestArmor(is, type)) break block12;
                        if (MODE.getValue() == EMode.Vanilla) {
                            Minecraft.thePlayer.sendQueue.addToSendQueue(new C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT));
                        }
                        this.drop(4 + type);
                    }
                    int i = 9;
                    while (i < 45) {
                        if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                            ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                            if (AutoArmor.isBestArmor(is, type) && AutoArmor.getProtection(is) > 0.0f) {
                                this.shiftClick(i);
                                this.timer.reset();
                                if (((Double)DELAY.getValue()).longValue() > 0L) {
                                    return;
                                }
                            }
                        }
                        ++i;
                    }
                }
                ++type;
            }
        }
    }

    static boolean isBestArmor(ItemStack stack, int type) {
        float prot = AutoArmor.getProtection(stack);
        String strType = "";
        if (type == 1) {
            strType = "helmet";
        } else if (type == 2) {
            strType = "chestplate";
        } else if (type == 3) {
            strType = "leggings";
        } else if (type == 4) {
            strType = "boots";
        }
        if (!stack.getUnlocalizedName().contains(strType)) {
            return false;
        }
        int i = 5;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (AutoArmor.getProtection(is) > prot && is.getUnlocalizedName().contains(strType)) {
                    return false;
                }
            }
            ++i;
        }
        return true;
    }

    private void shiftClick(int slot) {
        Minecraft.playerController.windowClick(Minecraft.thePlayer.inventoryContainer.windowId, slot, 0, 1, Minecraft.thePlayer);
    }

    private void drop(int slot) {
        Minecraft.playerController.windowClick(Minecraft.thePlayer.inventoryContainer.windowId, slot, 1, 4, Minecraft.thePlayer);
    }

    static float getProtection(ItemStack stack) {
        float prot = 0.0f;
        if (stack.getItem() instanceof ItemArmor) {
            ItemArmor armor = (ItemArmor)stack.getItem();
            prot = (float)((double)prot + ((double)armor.damageReduceAmount + (double)((100 - armor.damageReduceAmount) * EnchantmentHelper.getEnchantmentLevel(Enchantment.protection.effectId, stack)) * 0.0075));
            prot = (float)((double)prot + (double)EnchantmentHelper.getEnchantmentLevel(Enchantment.blastProtection.effectId, stack) / 100.0);
            prot = (float)((double)prot + (double)EnchantmentHelper.getEnchantmentLevel(Enchantment.fireProtection.effectId, stack) / 100.0);
            prot = (float)((double)prot + (double)EnchantmentHelper.getEnchantmentLevel(Enchantment.thorns.effectId, stack) / 100.0);
            prot = (float)((double)prot + (double)EnchantmentHelper.getEnchantmentLevel(Enchantment.unbreaking.effectId, stack) / 50.0);
            prot = (float)((double)prot + (double)EnchantmentHelper.getEnchantmentLevel(Enchantment.featherFalling.effectId, stack) / 100.0);
        }
        return prot;
    }

    public static enum EMode {
        Vanilla,
        OpenInv;

    }
}

