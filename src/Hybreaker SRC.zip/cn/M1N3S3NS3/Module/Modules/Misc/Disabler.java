/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  io.netty.util.internal.ThreadLocalRandom
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPacket;
import cn.M1N3S3NS3.API.Events.World.EventPacketReceive;
import cn.M1N3S3NS3.API.Events.World.EventPacketSend;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Events.World.EventTick;
import cn.M1N3S3NS3.API.Events.World.WorldReloadEvent;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import io.netty.util.internal.ThreadLocalRandom;
import java.awt.Color;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraft.network.play.server.S00PacketKeepAlive;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;

public class Disabler
extends Module {
    private final Numbers<Number> c0fmin = new Numbers<Double>("c0fMinDelay", "c0fMinDelay", 13.0, 0.0, 25.0, 1.0);
    private final Numbers<Number> c0fmax = new Numbers<Double>("c0fMaxDelay", "c0fMaxDelay", 15.0, 0.0, 25.0, 1.0);
    private final Numbers<Number> s00min = new Numbers<Double>("s00MinDelay", "s00MinDelay", 8.0, 0.0, 25.0, 1.0);
    private final Numbers<Number> s00max = new Numbers<Double>("s00MaxDelay", "s00MaxDelay", 10.0, 0.0, 25.0, 1.0);
    private final Numbers<Number> s00base = new Numbers<Double>("s00BaseDelay", "s00BaseDelay", 210.0, 0.0, 400.0, 10.0);
    private final Numbers<Number> LagBackPacketSendLimitMin = new Numbers<Double>("LagBackPacketSendLimitMin", "LagBackPacketSendLimitMin", 5.0, 0.0, 50.0, 1.0);
    private final Numbers<Number> LagBackPacketSendLimitMax = new Numbers<Double>("LagBackPacketSendLimitMax", "LagBackPacketSendLimitMax", 7.0, 0.0, 50.0, 1.0);
    private Option<Boolean> Tip = new Option<Boolean>("Tip", "Tip", false);
    private Option<Boolean> unStuck = new Option<Boolean>("unStuck", "unStuck", false);
    private final Numbers<Double> delay = new Numbers<Double>("Delay", 500.0, 50.0, 1000.0, 50.0);
    private final Option<Boolean> automated = new Option<Boolean>("Automated", true);
    private int setbackCount;
    private TimerUtil timer = new TimerUtil();
    public static LinkedList<C0FPacketConfirmTransaction> map2de = new LinkedList();
    public static LinkedHashMap<C00PacketKeepAlive, Long> map2 = new LinkedHashMap();
    public int coo = -1;
    public static AtomicBoolean switcher = new AtomicBoolean();
    public static int choose = 2;

    public Disabler() {
        super("Disabler", new String[]{"Disabler", "Disabler", "Disabler"}, ModuleType.Player);
        this.setColor(new Color(218, 97, 127).getRGB());
        this.addValues(this.automated, this.unStuck, this.Tip, this.delay, this.c0fmin, this.c0fmax, this.s00min, this.s00max, this.s00base, this.LagBackPacketSendLimitMin, this.LagBackPacketSendLimitMax);
    }

    @EventHandler
    public void packetEvent(EventPacket e) {
        if (((Boolean)this.unStuck.getValue()).booleanValue()) {
            if (e.isOutgoing()) {
                if (e.getPacket() instanceof C03PacketPlayer && (this.isStuck() || !((Boolean)this.automated.getValue()).booleanValue())) {
                    e.setCancelled(true);
                }
            } else if (e.getPacket() instanceof S08PacketPlayerPosLook) {
                this.setbackCount = !this.timer.hasReached((Double)this.delay.getValue()) ? ++this.setbackCount : 1;
                this.timer.reset();
            }
        }
    }

    @EventHandler
    public void moveEvent(EventPreUpdate e) {
        if (((Boolean)this.unStuck.getValue()).booleanValue() && (this.isStuck() || !((Boolean)this.automated.getValue()).booleanValue())) {
            Minecraft.thePlayer.motionX = 0.0;
            e.setX(0.0);
            Minecraft.thePlayer.motionY = 0.0;
            EventPreUpdate.setY(0.0);
            Minecraft.thePlayer.motionZ = 0.0;
            e.setZ(0.0);
        }
    }

    private boolean isStuck() {
        return this.setbackCount > 5 && !this.timer.hasReached((Double)this.delay.getValue());
    }

    @Override
    public void onEnable() {
    }

    @Override
    public void onDisable() {
        while (!map2de.isEmpty()) {
            C0FPacketConfirmTransaction p = map2de.poll();
            mc.getNetHandler().getNetworkManager().sendPacket(p);
        }
        map2.entrySet().stream().forEachOrdered(entry -> {
            mc.getNetHandler().getNetworkManager().sendPacket((Packet)entry.getKey());
            map2.remove(entry.getKey());
        });
    }

    @EventHandler
    private void Respawn(WorldReloadEvent e) {
        map2 = new LinkedHashMap();
        map2.clear();
        map2de.clear();
        this.coo = -1;
        switcher.set(false);
    }

    @EventHandler
    public void onUpdate(EventPreUpdate e) {
        this.setSuffix("Hypixel");
        if (!map2de.isEmpty() && Minecraft.thePlayer.ticksExisted % ThreadLocalRandom.current().nextInt(((Number)this.c0fmin.getValue()).intValue(), ((Number)this.c0fmax.getValue()).intValue()) == 0) {
            C0FPacketConfirmTransaction p = map2de.poll();
            mc.getNetHandler().getNetworkManager().sendPacketNoEvent(p);
        }
    }

    @EventHandler
    public void onTick(EventTick e) {
        map2.entrySet().stream().filter(entry -> (Long)entry.getValue() <= System.currentTimeMillis()).forEachOrdered(entry -> {
            mc.getNetHandler().getNetworkManager().sendPacket((Packet)entry.getKey());
            map2.remove(entry.getKey());
        });
    }

    @EventHandler
    public void C0F_Send(EventPacketSend e) {
        if (EventPacketSend.getPacket() instanceof C0FPacketConfirmTransaction) {
            C0FPacketConfirmTransaction packet = (C0FPacketConfirmTransaction)EventPacketSend.getPacket();
            if (packet.getWindowId() != 0) {
                choose = packet.getWindowId();
            }
            if (packet.getWindowId() == 0) {
                if (Minecraft.thePlayer != null) {
                    if (Minecraft.theWorld != null) {
                        if (switcher.get()) {
                            if (packet.uid < 0) {
                                if (ThreadLocalRandom.current().nextBoolean()) {
                                    packet.windowId = choose;
                                    packet.uid = (short)Math.abs(packet.uid);
                                }
                                map2de.offer(packet);
                            } else {
                                Minecraft.thePlayer.sendQueue.addToSendQueue(packet);
                            }
                            e.setCancelled(true);
                        }
                        if (Math.abs(packet.getUid()) - Math.abs(this.coo) == 1) {
                            switcher.set(true);
                        }
                        this.coo = packet.getUid();
                    }
                }
            }
        }
    }

    @EventHandler
    public void S00_RECE(EventPacketReceive e) {
        if (EventPacketReceive.getPacket() instanceof S00PacketKeepAlive) {
            S00PacketKeepAlive ke = (S00PacketKeepAlive)EventPacketReceive.getPacket();
            ke.id = ke.id;
            map2.put(new C00PacketKeepAlive(ke.func_149134_c()), System.currentTimeMillis() + ((Number)this.s00base.getValue()).longValue() + (long)ThreadLocalRandom.current().nextInt(((Number)this.s00min.getValue()).intValue(), ((Number)this.s00max.getValue()).intValue()));
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void PAUSE(EventPacketReceive e) {
        if (EventPacketReceive.getPacket() instanceof S08PacketPlayerPosLook && !map2de.isEmpty()) {
            while (!map2de.isEmpty()) {
                C0FPacketConfirmTransaction p = map2de.poll();
                mc.getNetHandler().getNetworkManager().sendPacket(p);
            }
        }
    }
}

