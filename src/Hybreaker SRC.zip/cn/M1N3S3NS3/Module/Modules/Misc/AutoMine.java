/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.WaitTimer;
import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockOre;
import net.minecraft.block.BlockRedstoneOre;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class AutoMine
extends Module {
    private EnumFacing facing = EnumFacing.EAST;
    private final WaitTimer skipCheckTimer = new WaitTimer();
    static double max = Minecraft.theWorld == null ? 256 : Minecraft.theWorld.getHeight();
    public static Numbers<Double> blockhight = new Numbers<Double>("BlockHeight", 16.0, 1.0, max, 1.0);

    public AutoMine() {
        super("AutoMine", new String[]{"Automine"}, ModuleType.Player);
        this.addValues(blockhight);
    }

    @Override
    public void onEnable() {
        this.facing = EnumFacing.fromAngle(Minecraft.thePlayer.rotationYaw);
        this.skipCheckTimer.time = 5000L;
        super.onEnable();
    }

    /*
     * Unable to fully structure code
     */
    @EventHandler
    public void onUpdate(EventPreUpdate event) {
        block36: {
            block34: {
                block35: {
                    this.setSuffix("Script " + AutoMine.blockhight.getValue());
                    toFace = new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ).offset(this.facing);
                    foundItem = false;
                    foundOre = false;
                    if (!this.skipCheckTimer.hasTimeElapsed(5000L, false)) break block34;
                    under = AutoMine.getBlockRelativeToEntity(Minecraft.thePlayer, -0.01);
                    stateUnder = AutoMine.getBlockState(AutoMine.getBlockPosRelativeToEntity(Minecraft.thePlayer, -0.01));
                    theItem = null;
                    for (EntityItem item : AutoMine.getNearbyItems(5)) {
                        if (!Minecraft.thePlayer.canEntityBeSeen(item) || item.ticksExisted <= 20 || item.ticksExisted >= 150) continue;
                        foundItem = true;
                        theItem = item;
                    }
                    if (!foundItem) break block35;
                    AutoMine.faceEntity(theItem);
                    Minecraft.thePlayer.moveFlying(0.0f, 1.0f, 0.1f);
                    if (theItem.posY > Minecraft.thePlayer.posY) {
                        if (Minecraft.thePlayer.onGround) {
                            Minecraft.thePlayer.jump();
                        }
                    }
                    break block36;
                }
                x = -3;
                while (x <= 3) {
                    y = -3;
                    while (y <= 5) {
                        z = -3;
                        while (z <= 3) {
                            block37: {
                                block39: {
                                    block38: {
                                        blockPos = new BlockPos(Minecraft.thePlayer.posX + (double)x, Minecraft.thePlayer.posY + (double)y, Minecraft.thePlayer.posZ + (double)z);
                                        block = AutoMine.getBlock(blockPos);
                                        state = AutoMine.getBlockState(blockPos);
                                        if (state.getBlock().getMaterial() == Material.air) break block37;
                                        if (!(block instanceof BlockLiquid)) break block38;
                                        trace0 = Minecraft.theWorld.rayTraceBlocks(new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ), new Vec3((double)blockPos.getX() + 0.5, (double)blockPos.getY() + 0.5, (double)blockPos.getZ() + 0.5), true, false, true);
                                        if (trace0.getBlockPos() != null) {
                                            blockPosTrace = trace0.getBlockPos();
                                            blockTrace = AutoMine.getBlock(blockPosTrace);
                                            if (blockTrace instanceof BlockLiquid) {
                                                this.facing = this.facing.getOpposite();
                                                toFace = new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ).offset(this.facing);
                                                if (AutoMine.isBlockPosAir(toFace)) {
                                                    toFace = toFace.down();
                                                }
                                                this.skipCheckTimer.reset();
                                                break;
                                            } else {
                                                ** GOTO lbl68
                                            }
                                        }
                                        break block37;
                                    }
                                    if (!(block instanceof BlockOre) && !(block instanceof BlockRedstoneOre)) break block37;
                                    trace0 = Minecraft.theWorld.rayTraceBlocks(new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ), new Vec3((double)blockPos.getX() + 0.5, (double)blockPos.getY() + 0.5, (double)blockPos.getZ() + 0.5), true, false, true);
                                    if (trace0.getBlockPos() == null) break block37;
                                    blockPosTrace = trace0.getBlockPos();
                                    blockTrace = AutoMine.getBlock(blockPosTrace);
                                    dist = AutoMine.getVec3(blockPos).distanceTo(AutoMine.getVec3(blockPosTrace));
                                    xx = Minecraft.thePlayer.posX - ((double)blockPosTrace.getX() + 0.5);
                                    yy = Minecraft.thePlayer.posY - ((double)blockPosTrace.getY() + 0.5 - (double)Minecraft.thePlayer.getEyeHeight());
                                    zz = Minecraft.thePlayer.posZ - ((double)blockPosTrace.getZ() + 0.5);
                                    dist0 = Math.sqrt(x * x + y * y + z * z);
                                    if (!(dist0 >= 1.5)) break block39;
                                    yaw = AutoMine.getFacePos(AutoMine.getVec3(blockPosTrace))[0];
                                    if ((yaw = AutoMine.normalizeAngle(yaw)) == 45.0f || yaw == -45.0f || yaw == 135.0f || yaw == -135.0f) break block37;
                                }
                                if (dist <= 0.0) {
                                    toFace = blockPosTrace;
                                    foundOre = true;
                                    break;
                                }
                            }
                            ++z;
                        }
                        ++y;
                    }
                    ++x;
                }
                if (foundOre) {
                    AutoMine.faceBlock(toFace);
                    if (!AutoMine.isBlockPosAir(toFace)) {
                        this.mineBlock(toFace);
                    }
                } else if (Minecraft.thePlayer.posY > (Double)AutoMine.blockhight.getValue()) {
                    if (stateUnder.getBlock().getMaterial() != Material.air) {
                        this.mineBlockUnderPlayer();
                    } else if (Minecraft.thePlayer.onGround) {
                        Minecraft.thePlayer.moveFlying(0.0f, 0.5f, 0.1f);
                    }
                } else {
                    if (AutoMine.isBlockPosAir(toFace)) {
                        if (this.isBlockPosSafe(toFace = toFace.down())) {
                            if (AutoMine.isBlockPosAir(toFace)) {
                                if (Minecraft.thePlayer.onGround) {
                                    Minecraft.thePlayer.moveFlying(0.0f, 1.0f, 0.1f);
                                }
                            }
                        } else {
                            this.facing = EnumFacing.fromAngle(Minecraft.thePlayer.rotationYaw + 90.0f);
                            toFace = new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ).offset(this.facing);
                            if (!this.isBlockPosSafe(toFace)) {
                                this.facing = EnumFacing.fromAngle(Minecraft.thePlayer.rotationYaw - 90.0f);
                                toFace = new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ).offset(this.facing);
                                if (!this.isBlockPosSafe(toFace.down())) {
                                    this.facing = EnumFacing.fromAngle(Minecraft.thePlayer.rotationYaw + 180.0f);
                                    toFace = new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ).offset(this.facing);
                                }
                            }
                        }
                    }
                    if (AutoMine.isBlockPosAir(toFace)) {
                        toFace = new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ).offset(this.facing);
                    }
                    AutoMine.faceBlock(toFace);
                    if (!AutoMine.isBlockPosAir(toFace)) {
                        this.mineBlock(toFace);
                    }
                }
                break block36;
            }
            if (Minecraft.thePlayer.onGround) {
                Minecraft.thePlayer.moveFlying(0.0f, 1.0f, 0.1f);
            }
            if (AutoMine.isBlockPosAir(toFace)) {
                toFace = toFace.down();
            }
            AutoMine.faceBlock(toFace);
            if (!AutoMine.isBlockPosAir(toFace)) {
                this.mineBlock(toFace);
            }
        }
    }

    public void mineBlockUnderPlayer() {
        BlockPos pos = AutoMine.getBlockPosRelativeToEntity(Minecraft.thePlayer, -0.01);
        this.mineBlock(pos);
    }

    public void mineBlock(BlockPos pos) {
        Block block = AutoMine.getBlock(pos);
        AutoMine.faceBlock(pos);
        Minecraft.thePlayer.swingItem();
        Minecraft.playerController.onPlayerDamageBlock(pos, EnumFacing.UP);
    }

    public boolean isBlockPosSafe(BlockPos pos) {
        return this.checkBlockPos(pos, 10);
    }

    public boolean checkBlockPos(BlockPos pos, int checkHeight) {
        boolean safe = true;
        boolean blockInWay = false;
        int fallDist = 0;
        if (AutoMine.getBlock(pos).getMaterial() == Material.lava || AutoMine.getBlock(pos).getMaterial() == Material.water) {
            return false;
        }
        if (AutoMine.getBlock(pos.up(1)).getMaterial() == Material.lava || AutoMine.getBlock(pos.up(1)).getMaterial() == Material.water) {
            return false;
        }
        if (AutoMine.getBlock(pos.up(2)).getMaterial() == Material.lava || AutoMine.getBlock(pos.up(2)).getMaterial() == Material.water) {
            return false;
        }
        int i = 1;
        while (i < checkHeight + 1) {
            BlockPos pos2 = pos.down(i);
            Block block = AutoMine.getBlock(pos2);
            if (block.getMaterial() == Material.air) {
                if (!blockInWay) {
                    ++fallDist;
                }
            } else {
                if (!(blockInWay || block.getMaterial() != Material.lava && block.getMaterial() != Material.water)) {
                    return false;
                }
                if (!blockInWay) {
                    blockInWay = true;
                }
            }
            ++i;
        }
        if (fallDist > 2) {
            safe = false;
        }
        return safe;
    }

    public static Block getBlockRelativeToEntity(Entity en, double d) {
        return AutoMine.getBlock(new BlockPos(en.posX, en.posY + d, en.posZ));
    }

    public static Block getBlock(BlockPos pos) {
        return Minecraft.theWorld.getBlockState(pos).getBlock();
    }

    public static BlockPos getBlockPosRelativeToEntity(Entity en, double d) {
        return new BlockPos(en.posX, en.posY + d, en.posZ);
    }

    public static IBlockState getBlockState(BlockPos blockPos) {
        return Minecraft.theWorld.getBlockState(blockPos);
    }

    public static ArrayList<EntityItem> getNearbyItems(int range) {
        ArrayList<EntityItem> eList = new ArrayList<EntityItem>();
        Minecraft.getMinecraft();
        for (Entity o : Minecraft.theWorld.getLoadedEntityList()) {
            if (!(o instanceof EntityItem)) continue;
            EntityItem e = (EntityItem)o;
            Minecraft.getMinecraft();
            if (Minecraft.thePlayer.getDistanceToEntity(e) >= (float)range) continue;
            eList.add(e);
        }
        return eList;
    }

    public static void faceEntity(Entity en) {
        AutoMine.facePos(new Vec3(en.posX - 0.5, en.posY + ((double)en.getEyeHeight() - (double)en.height / 1.5), en.posZ - 0.5));
    }

    public static void facePos(Vec3 vec) {
        Minecraft.getMinecraft();
        double diffX = vec.xCoord + 0.5 - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        double diffY = vec.yCoord + 0.5 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        Minecraft.getMinecraft();
        double diffZ = vec.zCoord + 0.5 - Minecraft.thePlayer.posZ;
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.thePlayer.rotationYaw += MathHelper.wrapAngleTo180_float(yaw - Minecraft.thePlayer.rotationYaw);
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.thePlayer.rotationPitch += MathHelper.wrapAngleTo180_float(pitch - Minecraft.thePlayer.rotationPitch);
    }

    public static boolean isBlockPosAir(BlockPos blockPos) {
        return Minecraft.theWorld.getBlockState(blockPos).getBlock().getMaterial() == Material.air;
    }

    public static Vec3 getVec3(BlockPos blockPos) {
        return new Vec3(blockPos.getX(), blockPos.getY(), blockPos.getZ());
    }

    public static float[] getFacePos(Vec3 vec) {
        Minecraft.getMinecraft();
        double diffX = vec.xCoord + 0.5 - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        double diffY = vec.yCoord + 0.5 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        Minecraft.getMinecraft();
        double diffZ = vec.zCoord + 0.5 - Minecraft.thePlayer.posZ;
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0 / Math.PI));
        float[] fArray = new float[2];
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        fArray[0] = Minecraft.thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(yaw - Minecraft.thePlayer.rotationYaw);
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        fArray[1] = Minecraft.thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float(pitch - Minecraft.thePlayer.rotationPitch);
        return fArray;
    }

    public static float normalizeAngle(float angle) {
        return (angle + 360.0f) % 360.0f;
    }

    public static void faceBlock(BlockPos blockPos) {
        AutoMine.facePos(AutoMine.getVec3(blockPos));
    }
}

