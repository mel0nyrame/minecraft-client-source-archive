/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPacket;
import cn.M1N3S3NS3.API.Events.World.EventPostUpdate;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemTool;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class SpeedMine
extends Module {
    private BlockPos blockPos;
    private EnumFacing facing;
    private boolean digging;
    private float damage;
    public Numbers<Double> Speed = new Numbers<Double>("SpeedMine", 1.4, 0.0, 3.0, 0.1);
    private Option<Boolean> auto = new Option<Boolean>("SpeedMine_AutoSpeed", true);

    public SpeedMine() {
        super("SpeedMine", new String[]{"SpeedMine", "fastmine"}, ModuleType.Player);
        this.addValues(this.Speed, this.auto);
    }

    /*
     * Unable to fully structure code
     */
    @EventHandler
    public void onpreupdate(EventPreUpdate e) {
        Minecraft.playerController.blockHitDelay = 0;
        if (!Minecraft.thePlayer.inventory.a()) ** GOTO lbl-1000
        if (Minecraft.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemTool) {
            v0 = 0.6f;
        } else lbl-1000:
        // 2 sources

        {
            v0 = 0.675f;
        }
        f10 = v0;
        if (Minecraft.playerController.curBlockDamageMP > f10) {
            Minecraft.playerController.curBlockDamageMP = 1.0f;
        }
    }

    @EventHandler
    void onPacket(EventPacket event) {
        Packet p = event.getPacket();
        if (event.isOutgoing() && p instanceof C07PacketPlayerDigging) {
            if (!Minecraft.playerController.isInCreativeMode()) {
                C07PacketPlayerDigging c07PacketPlayerDigging = (C07PacketPlayerDigging)p;
                if (C07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                    this.digging = true;
                    this.blockPos = c07PacketPlayerDigging.getPosition();
                    this.facing = c07PacketPlayerDigging.getFacing();
                    this.damage = 0.0f;
                } else if (C07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK || C07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
                    this.digging = false;
                    this.blockPos = null;
                    this.facing = null;
                }
            }
        }
    }

    @EventHandler
    public void onUpdate(EventPostUpdate event) {
        Minecraft.playerController.blockHitDelay = 0;
        if (this.digging) {
            if (!Minecraft.playerController.isInCreativeMode()) {
                Block block = Minecraft.theWorld.getBlockState(this.blockPos).getBlock();
                this.damage += block.getPlayerRelativeBlockHardness(Minecraft.thePlayer, Minecraft.theWorld, this.blockPos) * ((Double)this.Speed.getValue()).floatValue();
                if (this.damage >= 1.0f) {
                    Minecraft.theWorld.setBlockState(this.blockPos, Blocks.air.getDefaultState(), 11);
                    Minecraft.thePlayer.sendQueue.getNetworkManager().sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.blockPos, this.facing));
                    this.damage = 0.0f;
                    this.digging = false;
                }
            }
        }
    }
}

