/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Misc;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPacketSend;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Move.Flight;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.AxisAlignedBB;

public class NoFall
extends Module {
    public NoFall() {
        super("NoFall", new String[]{"nofalldamage", "nofall"}, ModuleType.Player);
        this.setColor(new Color(242, 137, 73).getRGB());
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    private static boolean checkVoid(EntityLivingBase entity) {
        int x = -1;
        while (x <= 0) {
            int z = -1;
            while (z <= 0) {
                if (NoFall.isVoid(x, z, entity)) {
                    return true;
                }
                ++z;
            }
            ++x;
        }
        return false;
    }

    private static boolean isVoid(int x, int z, EntityLivingBase entity) {
        Client.getModuleManager();
        if (ModuleManager.getModuleByClass(Flight.class).isEnabled()) {
            return false;
        }
        if (Minecraft.thePlayer.posY < 0.0) {
            return true;
        }
        int off = 0;
        while ((double)off < entity.posY + 2.0) {
            AxisAlignedBB bb = entity.getEntityBoundingBox().offset(x, -off, z);
            if (Minecraft.theWorld.getCollidingBoundingBoxes(entity, bb).isEmpty()) {
                off += 2;
                continue;
            }
            return false;
        }
        return true;
    }

    @EventHandler
    public void onUpdate(EventPacketSend e) {
        if (EventPacketSend.getPacket() instanceof C03PacketPlayer) {
            if (PlayerCapabilities.isFlying || Minecraft.thePlayer.capabilities.disableDamage || Minecraft.thePlayer.motionY >= 0.0) {
                return;
            }
            C03PacketPlayer event = (C03PacketPlayer)EventPacketSend.getPacket();
            if (event.isMoving() && Minecraft.thePlayer.fallDistance > 2.0f && Minecraft.thePlayer.fallDistance < 16.0f && !NoFall.checkVoid(Minecraft.thePlayer)) {
                e.setCancelled(true);
                mc.getNetHandler().getNetworkManager().sendPacketNoEvent(new C03PacketPlayer.C04PacketPlayerPosition(event.x, event.y, event.z, event.onGround));
            }
        }
    }

    @EventHandler
    public void onUpdate(EventPreUpdate e) {
        this.setSuffix("Packet");
        if (PlayerCapabilities.isFlying || Minecraft.thePlayer.capabilities.disableDamage || Minecraft.thePlayer.motionY >= 0.0) {
            return;
        }
        if (Minecraft.thePlayer.fallDistance > 3.0f && !NoFall.checkVoid(Minecraft.thePlayer)) {
            mc.getNetHandler().getNetworkManager().sendPacketNoEvent(new C03PacketPlayer(true));
        }
    }
}

