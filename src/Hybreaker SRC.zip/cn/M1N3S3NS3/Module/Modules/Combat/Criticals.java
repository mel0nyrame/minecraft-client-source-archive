/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Combat;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPacketSend;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.KillAura;
import cn.M1N3S3NS3.Module.Modules.Move.Flight;
import cn.M1N3S3NS3.Module.Modules.Move.Speed;
import cn.M1N3S3NS3.Util.timer.MSTimer;
import java.awt.Color;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.client.C03PacketPlayer;

public class Criticals
extends Module {
    private Mode mode = new Mode("Mode", "mode", (Enum[])CritMode.values(), (Enum)CritMode.NoGround);
    private final MSTimer timer = new MSTimer();
    private final MSTimer prevent = new MSTimer();
    EntityLivingBase target1;
    int p;
    private static final Option<Boolean> Speed = new Option<Boolean>("SPeed", "SPeed", true);
    private final Numbers<Number> hurtTimeValue = new Numbers<Double>("HurtTime", "HurtTime", 10.0, 0.0, 20.0, 1.0);
    private final Numbers<Number> delayValue = new Numbers<Double>("Delay", "Delay", 25.0, 0.0, 100.0, 1.0);
    public float fallDis;
    public boolean fall;
    public double y;
    private int v;

    public Criticals() {
        super("Criticals", new String[]{"Criticals"}, ModuleType.Combat);
        this.setColor(new Color(235, 194, 138).getRGB());
        this.addValues(this.mode, Speed, this.hurtTimeValue, this.delayValue);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @EventHandler
    public void update(EventPreUpdate event) {
        if (this.mode.getValue().equals((Object)CritMode.NoGround)) {
            this.setSuffix("NoGround");
        } else {
            this.setSuffix("Unnamed");
        }
    }

    @EventHandler
    public void onPacketsend(EventPacketSend e) {
        if (this.mode.getValue().equals((Object)CritMode.NoGround) && ModuleManager.getModuleByClass(KillAura.class).isEnabled() && EventPacketSend.getPacket() instanceof C03PacketPlayer) {
            if (!Minecraft.thePlayer.onGround) {
                return;
            }
            if (KillAura.curTarget != null) {
                ++this.v;
                if (this.v == 1) {
                    System.err.println("C03");
                }
                C03PacketPlayer var9 = (C03PacketPlayer)EventPacketSend.getPacket();
                ((C03PacketPlayer)EventPacketSend.packet).onGround = false;
            }
            this.v = 0;
        }
    }

    void packetCrit(EntityLivingBase target) {
        block7: {
            block5: {
                block6: {
                    if (!Minecraft.thePlayer.onGround) break block5;
                    if (Minecraft.thePlayer.isOnLadder()) break block5;
                    if (Minecraft.thePlayer.isInWeb) break block5;
                    if (Minecraft.thePlayer.isInWater()) break block5;
                    if (Minecraft.thePlayer.isInLava()) break block5;
                    if (Minecraft.thePlayer.ridingEntity != null || (float)target.hurtTime > ((Number)this.hurtTimeValue.getValue()).floatValue()) break block5;
                    if (((Boolean)Speed.getValue()).booleanValue()) break block6;
                    Client.getModuleManager();
                    if (ModuleManager.getModuleByClass(Speed.class).isEnabled()) break block5;
                }
                Client.getModuleManager();
                if (!ModuleManager.getModuleByClass(Flight.class).isEnabled() && this.timer.hasTimePassed(((Number)this.delayValue.getValue()).longValue() * 10L)) break block7;
            }
            return;
        }
        if (this.mode.getValue() == CritMode.Hypixel) {
            NetworkManager var1 = Minecraft.thePlayer.sendQueue.getNetworkManager();
            Double curX = Minecraft.thePlayer.posX;
            Double curY = Minecraft.thePlayer.posY;
            Double curZ = Minecraft.thePlayer.posZ;
            Double[] doubleArray = new Double[]{0.114514, 0.0114514};
            int n = doubleArray.length;
            int n2 = 0;
            while (n2 < n) {
                Double offset = doubleArray[n2];
                var1.sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(curX, curY + offset, curZ, false));
                ++n2;
            }
            this.timer.reset();
        }
    }

    private static int randomNumber(double min, double max) {
        Random random = new Random();
        return (int)(min + random.nextDouble() * (max - min));
    }

    static enum CritMode {
        Hypixel,
        NoGround;

    }
}

