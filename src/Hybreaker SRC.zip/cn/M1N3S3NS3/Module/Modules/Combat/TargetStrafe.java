/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.util.glu.Cylinder
 */
package cn.M1N3S3NS3.Module.Modules.Combat;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender3D;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.KillAura;
import cn.M1N3S3NS3.Module.Modules.Move.Flight;
import cn.M1N3S3NS3.Module.Modules.Move.Speed;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.Util.MoveUtils;
import cn.M1N3S3NS3.Util.RotationUtil;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;

public class TargetStrafe
extends Module {
    private static Numbers<Double> distance = new Numbers<Double>("Radius", "Radius", 2.0, 1.0, 3.0, 0.25);
    private static Numbers<Double> lol = new Numbers<Double>("Sides", "Sides", 9.0, 5.0, 25.0, 1.0);
    private static Option<Boolean> render = new Option<Boolean>("Render", "Render", true);
    private static Option<Boolean> space = new Option<Boolean>("Space", "Space", true);
    private TimerUtil switchTimer = new TimerUtil();
    public static int direction = -1;
    private static boolean strafing = false;

    public TargetStrafe() {
        super("TargetStrafe", new String[]{"ts", "strafe"}, ModuleType.Move);
        this.setColor(new Color(158, 205, 125).getRGB());
        this.addValues(distance, lol, render, space);
    }

    @EventHandler
    public void onUpdate(EventPreUpdate eu) {
        if (Minecraft.thePlayer.isCollidedHorizontally && this.switchTimer.hasReached(200.0)) {
            direction = -direction;
            this.switchTimer.reset();
        }
    }

    @EventHandler
    public void onRender3D(EventRender3D e) {
        if (TargetStrafe.canStrafe() && ((Boolean)render.getValue()).booleanValue()) {
            TargetStrafe.drawCircle2(KillAura.curTarget, new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue()).getRGB(), e);
        }
    }

    public static boolean starfe(double moveSpeed) {
        strafing = true;
        if (!TargetStrafe.canStrafe()) {
            return false;
        }
        float[] rots = RotationUtil.getRotations(KillAura.curTarget);
        double dist = Minecraft.thePlayer.getDistanceToEntity(KillAura.curTarget);
        if (dist >= (Double)distance.getValue()) {
            MoveUtils.setMotionWithValues(moveSpeed - 0.0, rots[0], 1.0, direction);
        } else {
            MoveUtils.setMotionWithValues(moveSpeed, rots[0], 0.0, direction);
        }
        return true;
    }

    public boolean isAboveVoid() {
        int i = (int)Math.ceil(Minecraft.thePlayer.posY);
        while (i >= 0) {
            double var10004 = i;
            if (Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, var10004, Minecraft.thePlayer.posZ)).getBlock() != Blocks.air) {
                return false;
            }
            --i;
        }
        return true;
    }

    public static boolean canStrafe() {
        block4: {
            block5: {
                if (((Boolean)space.getValue()).booleanValue() && !TargetStrafe.mc.gameSettings.keyBindJump.isKeyDown()) {
                    return false;
                }
                Client.getModuleManager();
                if (!ModuleManager.getModuleByClass(TargetStrafe.class).isEnabled() || !MoveUtils.isMoving() || KillAura.curTarget == null) break block4;
                Client.getModuleManager();
                if (ModuleManager.getModuleByClass(Speed.class).isEnabled()) break block5;
                Client.getModuleManager();
                if (!ModuleManager.getModuleByClass(Flight.class).isEnabled()) break block4;
            }
            return true;
        }
        return false;
    }

    public static void drawCircle2(EntityLivingBase entity, int color, EventRender3D e) {
        double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)e.getPartialTicks() - RenderManager.renderPosX;
        double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)e.getPartialTicks() - RenderManager.renderPosY;
        double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)e.getPartialTicks() - RenderManager.renderPosZ;
        GL11.glPushMatrix();
        GL11.glTranslated((double)x, (double)y, (double)z);
        GL11.glRotatef((float)(-entity.width), (float)0.0f, (float)1.0f, (float)0.0f);
        TargetStrafe.glColor(color);
        TargetStrafe.enableSmoothLine(1.0f);
        Cylinder c = new Cylinder();
        GL11.glRotatef((float)-90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
        c.setDrawStyle(100011);
        c.draw(((Double)distance.getValue()).floatValue(), ((Double)distance.getValue()).floatValue() + 0.005f, 0.005f, ((Double)lol.getValue()).intValue(), 1);
        c.draw(((Double)distance.getValue()).floatValue() + 0.005f, ((Double)distance.getValue()).floatValue() + 0.01f, 0.005f, ((Double)lol.getValue()).intValue(), 1);
        c.draw(((Double)distance.getValue()).floatValue() + 0.01f, ((Double)distance.getValue()).floatValue() + 0.015f, 0.005f, ((Double)lol.getValue()).intValue(), 1);
        c.draw(((Double)distance.getValue()).floatValue() + 0.015f, ((Double)distance.getValue()).floatValue() + 0.02f, 0.005f, ((Double)lol.getValue()).intValue(), 1);
        c.draw(((Double)distance.getValue()).floatValue() + 0.02f, ((Double)distance.getValue()).floatValue() + 0.025f, 0.005f, ((Double)lol.getValue()).intValue(), 1);
        TargetStrafe.disableSmoothLine();
        GL11.glPopMatrix();
    }

    public static void glColor(int hex) {
        float alpha = (float)(hex >> 24 & 0xFF) / 255.0f;
        float red = (float)(hex >> 16 & 0xFF) / 255.0f;
        float green = (float)(hex >> 8 & 0xFF) / 255.0f;
        float blue = (float)(hex & 0xFF) / 255.0f;
        GL11.glColor4f((float)red, (float)green, (float)blue, (float)(alpha == 0.0f ? 1.0f : alpha));
    }

    public static void enableSmoothLine(float width) {
        GL11.glDisable((int)3008);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GL11.glLineWidth((float)width);
    }

    public static void disableSmoothLine() {
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3008);
        GL11.glDepthMask((boolean)true);
        GL11.glCullFace((int)1029);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }
}

