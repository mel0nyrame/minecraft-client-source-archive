/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Combat;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPacket;
import cn.M1N3S3NS3.API.Events.World.EventPacketReceive;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.FriendManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.Math.UtilRotation;
import java.awt.Color;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S27PacketExplosion;
import net.minecraft.scoreboard.ScorePlayerTeam;

public class Velocity
extends Module {
    private Mode<Enum> mode = new Mode("Mode", "mode", (Enum[])Velocti.values(), (Enum)Velocti.Player);
    private Numbers<Double> Vertical = new Numbers<Double>("Vertical", "Vertical", 0.0, 0.0, 100.0, 1.0);
    private Numbers<Double> Horizontal = new Numbers<Double>("Horizontal", "Horizontal", 0.0, 0.0, 100.0, 1.0);
    private Numbers<Double> Chance = new Numbers<Double>("Chance", "Chance", 1.0, 0.0, 1.0, 0.01);
    public static Option<Boolean> WATERCHECK = new Option<Boolean>("Only in combat", "Only in combat", false);
    public boolean players = true;
    public boolean mobs = true;
    public boolean animals = false;
    public boolean weapon = true;
    public boolean teams = true;
    public boolean invisible = false;
    public boolean inInventory = false;

    public Velocity() {
        super("Velocity", new String[]{"velocity", "antiknockback", "antikb"}, ModuleType.Combat);
        this.addValues(this.mode, this.Vertical, this.Horizontal, this.Chance, WATERCHECK);
        this.setColor(new Color(191, 191, 191).getRGB());
    }

    @EventHandler
    private void onPacket(EventPacket e) {
        if (e.isIncoming() && this.mode.getValue() == Velocti.Cancel) {
            if (e.getPacket() instanceof S12PacketEntityVelocity) {
                S12PacketEntityVelocity s12PacketEntityVelocity = (S12PacketEntityVelocity)e.getPacket();
                if (Minecraft.thePlayer != null && Minecraft.thePlayer.getEntityId() == s12PacketEntityVelocity.getEntityID()) {
                    e.setCancelled(true);
                }
            } else if (e.getPacket() instanceof S27PacketExplosion) {
                e.setCancelled(true);
            }
        }
    }

    public boolean isTargetValid2(Entity target) {
        Minecraft mc;
        if (target.isInvisible() && !this.invisible) {
            return false;
        }
        if (!this.inInventory) {
            mc = Minecraft.getMinecraft();
            if (mc.currentScreen != null) {
                return false;
            }
        }
        if (target instanceof EntityMob) {
            if (!this.mobs) {
                return false;
            }
        } else if (target instanceof EntityAnimal) {
            if (!this.animals) {
                return false;
            }
        } else if (target instanceof EntityPlayer) {
            if (this.teams) {
                ScorePlayerTeam playerteam;
                mc = Minecraft.getMinecraft();
                EntityPlayer player = (EntityPlayer)target;
                if (Minecraft.thePlayer.getTeam() != null && (playerteam = (ScorePlayerTeam)Minecraft.thePlayer.getTeam()).getMembershipCollection().contains(player.getGameProfile().getName())) {
                    return false;
                }
            }
            if (!this.players) {
                return false;
            }
        } else {
            return false;
        }
        return true;
    }

    protected boolean isTargetValid(Entity entity) {
        if (entity == null) {
            return false;
        }
        if (!entity.isEntityAlive()) {
            return false;
        }
        if (!this.isTargetValid(entity)) {
            return false;
        }
        if (!Minecraft.thePlayer.canEntityBeSeen(entity)) {
            return false;
        }
        if ((double)Minecraft.thePlayer.getDistanceToEntity(entity) > 6.0) {
            return false;
        }
        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer)entity;
            Client.instance.getFriendManager();
            if (FriendManager.isFriend(player.getGameProfile().getName())) {
                return false;
            }
        }
        return true;
    }

    @EventHandler
    private void onPacke3t(EventPacketReceive e) {
        this.setSuffix(this.mode.getValue() == Velocti.Player ? String.valueOf(((Double)this.Horizontal.getValue()).intValue()) + "% " + ((Double)this.Vertical.getValue()).intValue() + "%" : this.mode.getValue());
        if (this.mode.getValue() == Velocti.Player) {
            if (Minecraft.thePlayer == null) {
                return;
            }
            if (Minecraft.theWorld == null) {
                return;
            }
            if (((Boolean)WATERCHECK.getValue()).booleanValue()) {
                boolean ya = true;
                Iterator<Entity> iterator = Minecraft.theWorld.getLoadedEntityList().iterator();
                while (iterator.hasNext()) {
                    double d;
                    Entity e1;
                    Entity en = e1 = iterator.next();
                    if (en == Minecraft.thePlayer || !this.isTargetValid(en)) continue;
                    float yaw = UtilRotation.getAngles(en)[1];
                    double yawdistance = UtilRotation.getDistanceBetweenAngles(yaw, Minecraft.thePlayer.rotationYaw);
                    if (d >= 50.0) continue;
                    ya = true;
                    break;
                }
                if (!ya) {
                    return;
                }
            }
            double horizontalMultiplier = (Double)this.Horizontal.getValue() / 100.0;
            double verticalMultiplier = (Double)this.Vertical.getValue() / 100.0;
            if ((Double)this.Chance.getValue() >= random.nextDouble() && EventPacketReceive.getPacket() instanceof S12PacketEntityVelocity) {
                S12PacketEntityVelocity packet = (S12PacketEntityVelocity)EventPacketReceive.getPacket();
                if (packet.getEntityID() != Minecraft.thePlayer.getEntityId()) {
                    return;
                }
                packet.motionX *= (int)horizontalMultiplier;
                packet.motionZ *= (int)horizontalMultiplier;
                packet.motionY *= (int)verticalMultiplier;
            }
            if ((Double)this.Chance.getValue() >= random.nextDouble() && EventPacketReceive.getPacket() instanceof S27PacketExplosion) {
                S27PacketExplosion packet2 = (S27PacketExplosion)EventPacketReceive.getPacket();
                packet2.field_149152_f = (float)((double)packet2.func_149149_c() * horizontalMultiplier);
                packet2.field_149159_h = (float)((double)packet2.func_149147_e() * horizontalMultiplier);
                packet2.field_149153_g = (float)((double)packet2.func_149144_d() * verticalMultiplier);
            }
        }
    }

    static enum Velocti {
        Cancel,
        Player;

    }
}

