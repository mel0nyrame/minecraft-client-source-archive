/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Combat;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPostUpdate;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.player.EntityPlayer;

public class AntiBot
extends Module {
    private static final Mode<Enum> modeValue = new Mode("Mode", "Bot mode", (Enum[])modeEnums.values(), (Enum)modeEnums.Hypixel);
    private static final Numbers<Number> livingTicksValue = new Numbers<Double>("Living Ticks", "Living mode custom ticks", 80.0, 0.0, 100.0, 10.0);
    private static final ArrayList<Integer> ground = new ArrayList();

    public AntiBot() {
        super("AntiBot", new String[]{"AntiBot"}, ModuleType.Combat);
        this.addValues(modeValue, livingTicksValue);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        ground.clear();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        ground.clear();
    }

    @EventHandler
    void onUpdate(EventPostUpdate event) {
        this.setSuffix(((Enum)modeValue.getValue()).name());
        if (Minecraft.thePlayer.ticksExisted <= 1) {
            ground.clear();
        }
        if (modeValue.getValue() == modeEnums.Hypixel) {
            for (EntityPlayer entity : Minecraft.theWorld.playerEntities) {
                this.removeHypixelBot(entity);
            }
        }
        ground.addAll(this.getLivingPlayers().stream().filter(entityPlayer -> entityPlayer.onGround && !ground.contains(entityPlayer.getEntityId())).map(Entity::getEntityId).collect(Collectors.toList()));
    }

    private ArrayList<EntityPlayer> getLivingPlayers() {
        return (ArrayList)Arrays.asList((EntityPlayer[])Minecraft.theWorld.loadedEntityList.stream().filter(entity -> entity instanceof EntityPlayer).filter(entity -> entity != Minecraft.thePlayer).map(entity -> (EntityPlayer)entity).toArray(EntityPlayer[]::new));
    }

    private static boolean inTab(EntityLivingBase entity) {
        for (NetworkPlayerInfo item : mc.getNetHandler().getPlayerInfoMap()) {
            NetworkPlayerInfo playerInfo = item;
            if (playerInfo == null || playerInfo.getGameProfile() == null || !playerInfo.getGameProfile().getName().contains(entity.getName())) continue;
            return true;
        }
        return false;
    }

    private static boolean isMineplexNPC(EntityLivingBase entity) {
        String custom = entity.getCustomNameTag();
        if (entity instanceof EntityPlayer && !(entity instanceof EntityPlayerSP)) {
            if (Minecraft.thePlayer.ticksExisted > 40 && custom.equals("")) {
                return true;
            }
        }
        return false;
    }

    private static boolean isHypixelNPC(EntityLivingBase entity) {
        String formatted = entity.getDisplayName().getFormattedText();
        if (!formatted.startsWith("\u00a7") && formatted.endsWith("\u00a7r")) {
            return true;
        }
        if (ground.contains(entity.getEntityId())) {
            return true;
        }
        return formatted.contains("\u00a78[NPC]");
    }

    private boolean removeHypixelBot(EntityLivingBase entity) {
        if (entity instanceof EntityWither && entity.isInvisible()) {
            return true;
        }
        if (!AntiBot.inTab(entity) && !AntiBot.isHypixelNPC(entity) && entity.isEntityAlive()) {
            if (entity != Minecraft.thePlayer) {
                Minecraft.theWorld.removeEntity(entity);
                return true;
            }
        }
        return false;
    }

    public static boolean isBot(EntityLivingBase entity) {
        block9: {
            block8: {
                Client.instance.getModuleManager();
                if (!ModuleManager.getModuleByClass(AntiBot.class).isEnabled()) break block8;
                if (entity != Minecraft.thePlayer) break block9;
            }
            return false;
        }
        if ((modeValue.getValue() == modeEnums.Living || modeValue.getValue() == modeEnums.Advanced) && entity.ticksExisted > ((Number)livingTicksValue.getValue()).intValue()) {
            return true;
        }
        if (modeValue.getValue() == modeEnums.Advanced && !ground.contains(entity.getEntityId())) {
            return true;
        }
        if (modeValue.getValue() == modeEnums.BrokenID && entity.getEntityId() > 1000000) {
            return true;
        }
        if (modeValue.getValue() == modeEnums.Tab && !AntiBot.inTab(entity)) {
            return true;
        }
        if (modeValue.getValue() == modeEnums.Hypixel && AntiBot.isHypixelNPC(entity)) {
            return true;
        }
        return modeValue.getValue() == modeEnums.Mineplex && AntiBot.isMineplexNPC(entity);
    }

    private static enum modeEnums {
        Living,
        Advanced,
        BrokenID,
        Tab,
        Hypixel,
        Mineplex;

    }
}

