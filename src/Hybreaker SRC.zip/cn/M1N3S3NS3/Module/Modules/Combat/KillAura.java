/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  javax.vecmath.Vector2f
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.util.glu.Cylinder
 */
package cn.M1N3S3NS3.Module.Modules.Combat;

import cn.M1N3S3NS3.API.EventBus;
import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender3D;
import cn.M1N3S3NS3.API.Events.World.EventAttack;
import cn.M1N3S3NS3.API.Events.World.EventPacket;
import cn.M1N3S3NS3.API.Events.World.EventPostUpdate;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.FriendManager;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.AntiBot;
import cn.M1N3S3NS3.Module.Modules.Combat.AutoPot;
import cn.M1N3S3NS3.Module.Modules.Combat.Criticals;
import cn.M1N3S3NS3.Module.Modules.Misc.Teams;
import cn.M1N3S3NS3.Module.Modules.Move.Scaffold;
import cn.M1N3S3NS3.Module.Modules.Move.Speed;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.notification.Notification;
import cn.M1N3S3NS3.Util.Math.MathUtil;
import cn.M1N3S3NS3.Util.Math.RotationUtil;
import cn.M1N3S3NS3.Util.MathUtils;
import cn.M1N3S3NS3.Util.PlayerUtils;
import cn.M1N3S3NS3.Util.Render.ColorUtils;
import cn.M1N3S3NS3.Util.Render.RenderUtil;
import cn.M1N3S3NS3.Util.RotationUtils;
import cn.M1N3S3NS3.Util.Wrapper;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import javax.vecmath.Vector2f;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySnowman;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;

public class KillAura
extends Module {
    private final TimerUtil attackTimer = new TimerUtil();
    public static EntityLivingBase curTarget;
    public static EntityLivingBase blockTarget;
    public Mode<Enum> hand = new Mode("Rotation", "Rotation", (Enum[])handMode.values(), (Enum)handMode.Predict);
    public ArrayList<EntityLivingBase> targetList = new ArrayList();
    private int index;
    private int xd;
    int hitCounter;
    private final TimerUtil blockPreventFlagTimer = new TimerUtil();
    public static float yaw;
    public static float pitch;
    public static float progressYaw;
    public static float progressPitch;
    public static EntityLivingBase vip;
    public static float[] facing12;
    private float[] facing01;
    private float[] facing11;
    private float[] facing21;
    private float[] facing31;
    private float[] facing41;
    private Numbers<Double> aps = new Numbers<Double>("aps", "aps", 17.0, 1.0, 20.0, 1.0);
    public static final Option<Boolean> playerValue;
    public static final Option<Boolean> animalValue;
    public static final Option<Boolean> monsterValue;
    public static final Option<Boolean> neutralValue;
    public static final Option<Boolean> preferValue;
    public static final Option<Boolean> deathValue;
    public static final Option<Boolean> multi;
    public static final Option<Boolean> invisibleValue;
    public static final Option<Boolean> throughWallValue;
    public static final Option<Boolean> preventFlagValue;
    public static final Option<Boolean> autoBlockValue;
    public static final Option<Boolean> yawValue;
    public static final Option<Boolean> pitchValue;
    public static final Option<Boolean> attackKey;
    public static final Option<Boolean> blockHit;
    public static final Option<Boolean> suffix;
    public static final Option<Boolean> randomValue;
    public final Option<Boolean> lockView = new Option<Boolean>("LockView", true);
    public final Numbers<Number> switchDelayValue = new Numbers<Double>("SwitchDelay", "SwitchDelay", 15.0, 0.0, 20.0, 0.5);
    public final Numbers<Number> rangeValue = new Numbers<Double>("Range", "Range", 4.2, 1.0, 8.0, 0.05);
    public final Numbers<Number> aimValue = new Numbers<Double>("Aim", "Aim", 1.6, 0.0, 1.6, 0.1);
    public final Numbers<Number> blockRangeValue = new Numbers<Double>("BlockRange", "BlockRange", 5.0, 1.0, 15.0, 0.05);
    public final Numbers<Number> wallRangeValue = new Numbers<Double>("WallRange", "WallRange", 4.2, 1.0, 5.0, 0.05);
    public final Numbers<Number> fovValue = new Numbers<Double>("Fov", "Fov", 180.0, 10.0, 180.0, 10.0);
    public final Numbers<Number> angleValue = new Numbers<Double>("AngleStep", "AngleStep", 180.0, 0.0, 180.0, 1.0);
    private Vector2f lastAngles = new Vector2f(0.0f, 0.0f);
    public float fallDis;
    public boolean fall;
    private boolean CRIT;
    public double y;
    private Mode<Enum> Priority = new Mode("Priority", "Priority", (Enum[])priority.values(), (Enum)priority.Health1);
    private Mode<Enum> mode = new Mode("Mode", (Enum[])AuraMode.values(), (Enum)AuraMode.Switch);
    private Mode<Enum> mode2 = new Mode("ESP", (Enum[])ESPMode.values(), (Enum)ESPMode.Vape);
    public static boolean blocking;
    public Option<Boolean> HeadRotation = new Option<Boolean>("HeadRotation", "HeadRotation", false);
    private Comparator<Entity> angleComparator = Comparator.comparingDouble(e2 -> RotationUtil.getRotations(e2)[0]);
    float[] lastRotation;
    public static float sYaw;
    public static float sPitch;
    public static float aacB;
    int[] randoms;
    public boolean ready;
    private final TimerUtil switchTimer;
    private Entity curtarget;
    private float[] neededRotations;
    private float[] currentRotations;
    private float[] lastRotations;
    private float upAndDownPitch;
    private boolean AIMed;
    public final Numbers<Number> multiMaxTarget;

    static {
        playerValue = new Option<Boolean>("Player", "Player", true);
        animalValue = new Option<Boolean>("Animal", "Animal", false);
        monsterValue = new Option<Boolean>("Monster", "Monster", false);
        neutralValue = new Option<Boolean>("Neutral", "Neutral", false);
        preferValue = new Option<Boolean>("Prefer", "Prefer", false);
        deathValue = new Option<Boolean>("Death", "Death", true);
        multi = new Option<Boolean>("Multi", "Multi", false);
        invisibleValue = new Option<Boolean>("Invisible", "invisible", false);
        throughWallValue = new Option<Boolean>("ThroughWall", "ThroughWall", false);
        preventFlagValue = new Option<Boolean>("Flag", "Flag", true);
        autoBlockValue = new Option<Boolean>("AutoBlock", "AutoBlock", false);
        yawValue = new Option<Boolean>("Yaw", "Yaw", false);
        pitchValue = new Option<Boolean>("Pitch", "Pitch", false);
        attackKey = new Option<Boolean>("On attack key", "On attack key", false);
        blockHit = new Option<Boolean>("Digging check", "Digging check", false);
        suffix = new Option<Boolean>("suffix", "suffix", false);
        randomValue = new Option<Boolean>("Random", "Random", false);
    }

    public KillAura() {
        super("Kill Aura", new String[]{"ka", "aura", "killa"}, ModuleType.Combat);
        int[] nArray = new int[3];
        nArray[1] = 1;
        this.randoms = nArray;
        this.switchTimer = new TimerUtil();
        this.neededRotations = new float[2];
        this.currentRotations = new float[2];
        this.lastRotations = new float[2];
        this.multiMaxTarget = new Numbers<Double>("multiMaxTarget", "multiMaxTarget", 20.0, 0.0, 20.0, 1.0);
        this.setColor(new Color(226, 54, 30).getRGB());
        this.addValues(this.hand, this.mode, this.mode2, this.Priority, this.multiMaxTarget, this.aimValue, this.aps, this.fovValue, this.angleValue, this.switchDelayValue, this.wallRangeValue, this.blockRangeValue, this.rangeValue, multi, playerValue, animalValue, monsterValue, neutralValue, preferValue, deathValue, invisibleValue, preventFlagValue, throughWallValue, autoBlockValue, this.HeadRotation, attackKey, blockHit, this.lockView, yawValue, pitchValue, randomValue, suffix);
    }

    public boolean isBlocking2() {
        return blocking;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (Minecraft.thePlayer != null) {
            this.lastAngles.x = Minecraft.thePlayer.rotationYaw;
        }
        this.targetList.clear();
        curTarget = null;
        blockTarget = null;
        if (((Boolean)autoBlockValue.getValue()).booleanValue() && blocking) {
            this.unblock(true);
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.attackTimer.reset();
        progressYaw = Minecraft.thePlayer.rotationYaw;
        yaw = Minecraft.thePlayer.rotationYaw;
        progressYaw = (float)this.normalise(Minecraft.thePlayer.rotationYaw, -180.0, 180.0);
        yaw = (float)this.normalise(Minecraft.thePlayer.rotationYaw, -180.0, 180.0);
        progressPitch = Minecraft.thePlayer.rotationPitch;
        pitch = Minecraft.thePlayer.rotationPitch;
        this.targetList.clear();
        curTarget = null;
        blockTarget = null;
        if (Minecraft.thePlayer != null) {
            sYaw = Minecraft.thePlayer.rotationYaw;
            sPitch = Minecraft.thePlayer.rotationPitch;
            this.lastAngles.x = Minecraft.thePlayer.rotationYaw;
        }
        blocking = Minecraft.thePlayer.isBlocking();
        this.blockPreventFlagTimer.reset();
        aacB = 0.0f;
        this.index = 0;
        this.switchTimer.reset();
    }

    double normalise(double value, double start, double end) {
        double width = end - start;
        double offsetValue = value - start;
        return offsetValue - Math.floor(offsetValue / width) * width + start;
    }

    private static boolean isLookingAtEntity(float yaw, float pitch, Entity entity, double range, boolean rayTrace) {
        EntityPlayerSP player = Wrapper.getPlayer();
        Vec3 src = Wrapper.getPlayer().getPositionEyes(1.0f);
        Vec3 rotationVec = Entity.getVectorForRotation(pitch, yaw);
        Vec3 dest = src.addVector(rotationVec.xCoord * range, rotationVec.yCoord * range, rotationVec.zCoord * range);
        MovingObjectPosition obj = Wrapper.getWorld().rayTraceBlocks(src, dest, false, false, true);
        if (obj == null) {
            return false;
        }
        if (obj.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
            if (rayTrace) {
                return false;
            }
            if ((double)player.getDistanceToEntity(entity) > 3.0) {
                return false;
            }
        }
        return entity.getEntityBoundingBox().expand(0.1f, 0.1f, 0.1f).calculateIntercept(src, dest) != null;
    }

    private boolean hasSword(EntityPlayer playerIn) {
        return playerIn.inventory.getCurrentItem() != null && playerIn.inventory.getCurrentItem().getItem() instanceof ItemSword;
    }

    private static int randomNumber(double min, double max) {
        Random random = new Random();
        return (int)(min + random.nextDouble() * (max - min));
    }

    @EventHandler
    public final void On(EventPreUpdate event) {
        if (((Boolean)multi.getValue()).booleanValue()) {
            this.setSuffix("Multi");
        } else {
            this.setSuffix(this.mode.getValue());
        }
    }

    private void updateTargets() {
        this.targetList.clear();
        List entities = Minecraft.theWorld.loadedEntityList;
        int entitiesSize = entities.size();
        int i = 0;
        while (i < entitiesSize) {
            EntityLivingBase entityLivingBase;
            Entity entity = (Entity)entities.get(i);
            if (entity instanceof EntityLivingBase && this.getEntityValid(entityLivingBase = (EntityLivingBase)entity)) {
                this.targetList.add(entityLivingBase);
            }
            ++i;
        }
    }

    /*
     * Unable to fully structure code
     */
    @EventHandler
    private void onUpdate(EventPreUpdate event) {
        block77: {
            block78: {
                block79: {
                    block74: {
                        block76: {
                            block75: {
                                Client.getModuleManager();
                                if (!ModuleManager.getModuleByClass(Criticals.class).isEnabled()) ** GOTO lbl-1000
                                Client.getModuleManager();
                                if (!ModuleManager.getModuleByClass(Speed.class).isEnabled()) {
                                    v0 = true;
                                } else lbl-1000:
                                // 2 sources

                                {
                                    v0 = false;
                                }
                                crits = v0;
                                KillAura.blockTarget = null;
                                this.updateTargets();
                                if (!((Boolean)KillAura.autoBlockValue.getValue()).equals(false)) break block74;
                                if (!KillAura.mc.gameSettings.keyBindAttack.getIsKeyPressed() && ((Boolean)KillAura.attackKey.getValue()).booleanValue()) break block75;
                                if (!((Boolean)KillAura.blockHit.getValue()).booleanValue()) break block76;
                                if (!Minecraft.playerController.isHittingBlock) break block76;
                            }
                            return;
                        }
                        if (this.isBlocking()) {
                            if (Minecraft.thePlayer.isMoving()) {
                                KillAura.mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                            }
                        }
                    }
                    if (Minecraft.thePlayer.ticksExisted <= 1 && ((Boolean)KillAura.deathValue.getValue()).booleanValue()) {
                        Client.instance.getNotificationManager().getNotifications().add(new Notification("Disabled aura due to death"));
                        this.setEnabled(false);
                        return;
                    }
                    KillAura.blockTarget = null;
                    for (Entity entity : Minecraft.theWorld.getLoadedEntityList()) {
                        if (!((Boolean)KillAura.autoBlockValue.getValue()).booleanValue()) break;
                        if (!(entity instanceof EntityLivingBase) || !this.getEntityValidBlock(livingBase = (EntityLivingBase)entity)) continue;
                        KillAura.blockTarget = livingBase;
                    }
                    KillAura.curTarget = null;
                    this.targetList.clear();
                    this.clearcurTargets();
                    for (Entity entity : Minecraft.theWorld.getLoadedEntityList()) {
                        if (!(entity instanceof EntityLivingBase) || !this.getEntityValid(livingBase = (EntityLivingBase)entity)) continue;
                        if (KillAura.vip == livingBase) {
                            this.targetList.clear();
                            this.targetList.add(livingBase);
                            break;
                        }
                        this.targetList.add(livingBase);
                    }
                    this.sortList(this.targetList);
                    if (((Boolean)KillAura.preferValue.getValue()).booleanValue()) {
                        for (EntityLivingBase entityLivingBase : this.targetList) {
                            if (!(entityLivingBase instanceof EntityWither)) continue;
                            this.targetList.clear();
                            this.targetList.add(entityLivingBase);
                            break;
                        }
                    }
                    if (this.switchTimer.hasPassed((long)((Number)this.switchDelayValue.getValue()).intValue() * 100L) && this.targetList.size() > 1) {
                        this.switchTimer.reset();
                        ++this.index;
                    }
                    if (this.index >= this.targetList.size()) {
                        this.index = 0;
                    }
                    if (!this.targetList.isEmpty()) {
                        KillAura.curTarget = this.targetList.get(this.mode.getValue() == AuraMode.Switch ? this.index : 0);
                    }
                    if (KillAura.curTarget == null) break block77;
                    if (!((Boolean)KillAura.autoBlockValue.getValue()).equals(false)) break block78;
                    if (!KillAura.mc.gameSettings.keyBindAttack.getIsKeyPressed() && ((Boolean)KillAura.attackKey.getValue()).booleanValue()) break block79;
                    if (!((Boolean)KillAura.blockHit.getValue()).booleanValue()) break block78;
                    if (!Minecraft.playerController.isHittingBlock) break block78;
                }
                return;
            }
            this.hand.getValue();
            if (this.hand.getValue() == handMode.Predict) {
                NeedRotation = RotationUtils.getRotationsForAura(KillAura.curTarget, ((Number)this.rangeValue.getValue()).floatValue() + 1.0f);
                if (NeedRotation == null) {
                    this.AIMed = false;
                    return;
                }
                if (((Boolean)this.lockView.getValue()).booleanValue()) {
                    Minecraft.thePlayer.rotationYaw = NeedRotation[0];
                } else if (((Boolean)KillAura.yawValue.getValue()).booleanValue()) {
                    event.setYaw(NeedRotation[0]);
                }
                if (((Boolean)KillAura.pitchValue.getValue()).booleanValue()) {
                    event.setPitch(NeedRotation[1]);
                }
                if (((Boolean)KillAura.yawValue.getValue()).booleanValue()) {
                    Minecraft.thePlayer.rotationYawHead = NeedRotation[0];
                }
                if (((Boolean)KillAura.pitchValue.getValue()).booleanValue()) {
                    Minecraft.thePlayer.rotationPitchHead = NeedRotation[1];
                    RendererLivingEntity.SetPitchY(NeedRotation[1]);
                }
                this.AIMed = true;
            }
            if (this.hand.getValue() == handMode.Fast) {
                speed = 10;
                horizontalSpeed = MathUtil.getRandomInRange(90.0f, 100.0f);
                verticalSpeed = MathUtil.getRandomInRange(80.0f, 90.0f);
                if (KillAura.progressYaw > KillAura.yaw) {
                    KillAura.progressYaw = (float)((double)KillAura.progressYaw + ((double)((KillAura.yaw - KillAura.progressYaw) / horizontalSpeed) + 0.1));
                } else if (KillAura.progressYaw < KillAura.yaw) {
                    KillAura.progressYaw = (float)((double)KillAura.progressYaw + ((double)((KillAura.yaw - KillAura.progressYaw) / horizontalSpeed) + 0.1));
                }
                if (KillAura.progressPitch > KillAura.pitch) {
                    KillAura.progressPitch = (float)((double)KillAura.progressPitch + ((double)((KillAura.pitch - KillAura.progressPitch) / verticalSpeed) + 0.1));
                } else if (KillAura.progressPitch < KillAura.pitch) {
                    KillAura.progressPitch = (float)((double)KillAura.progressPitch + ((double)((KillAura.pitch - KillAura.progressPitch) / verticalSpeed) + 0.1));
                }
                if (((Boolean)this.lockView.getValue()).booleanValue()) {
                    Minecraft.thePlayer.rotationYaw = KillAura.yaw;
                } else if (((Boolean)KillAura.yawValue.getValue()).booleanValue()) {
                    event.setYaw(KillAura.yaw);
                }
                if (((Boolean)KillAura.pitchValue.getValue()).booleanValue()) {
                    event.setPitch(KillAura.pitch);
                }
                if (((Boolean)KillAura.yawValue.getValue()).booleanValue()) {
                    Minecraft.thePlayer.rotationYawHead = KillAura.yaw;
                }
                if (((Boolean)KillAura.pitchValue.getValue()).booleanValue()) {
                    Minecraft.thePlayer.rotationPitchHead = KillAura.pitch;
                    RendererLivingEntity.SetPitchY(KillAura.pitch);
                }
            }
            if (this.hand.getValue() == handMode.Zenith) {
                var7 = this.customRots(event, KillAura.curTarget);
                KillAura.aacB /= 2.0f;
                if (((Boolean)this.lockView.getValue()).booleanValue()) {
                    Minecraft.thePlayer.rotationYaw = var7[0];
                } else if (((Boolean)KillAura.yawValue.getValue()).booleanValue()) {
                    event.setYaw(var7[0]);
                }
                if (((Boolean)KillAura.pitchValue.getValue()).booleanValue()) {
                    event.setPitch(var7[1]);
                }
                if (((Boolean)KillAura.yawValue.getValue()).booleanValue()) {
                    Minecraft.thePlayer.rotationYawHead = var7[0];
                }
                if (((Boolean)KillAura.pitchValue.getValue()).booleanValue()) {
                    Minecraft.thePlayer.rotationPitchHead = var7[1];
                    RendererLivingEntity.SetPitchY(var7[1]);
                }
            }
            if (this.hand.getValue() == handMode.Slient) {
                new Random();
                this.facing11 = this.getRotations(KillAura.curTarget);
                this.facing21 = this.ExgetHypixelRotationsNeededBlock(KillAura.curTarget.posX, KillAura.curTarget.posY, KillAura.curTarget.posZ);
                this.facing31 = KillAura.ExgetRotationFromPosition(KillAura.curTarget.posX, KillAura.curTarget.posY, KillAura.curTarget.posZ);
                this.facing41 = this.getRotationsNeededBlock(KillAura.curTarget.posX, KillAura.curTarget.posY, KillAura.curTarget.posZ);
                var8 = 0;
                while (var8 <= 3) {
                    switch (KillAura.randomNumber(1.0, 2.0)) {
                        case 1: {
                            KillAura.facing12 = this.facing11;
                            break;
                        }
                        case 2: {
                            KillAura.facing12 = this.facing21;
                            break;
                        }
                        case 3: {
                            KillAura.facing12 = this.facing31;
                            break;
                        }
                        case 4: {
                            KillAura.facing12 = this.facing41;
                        }
                    }
                    ++var8;
                }
                if (KillAura.facing12.length >= 0) {
                    if (((Boolean)this.lockView.getValue()).booleanValue()) {
                        Minecraft.thePlayer.rotationYaw = KillAura.facing12[0];
                    } else if (((Boolean)KillAura.yawValue.getValue()).booleanValue()) {
                        event.setYaw(KillAura.facing12[0]);
                    }
                    if (((Boolean)KillAura.pitchValue.getValue()).booleanValue()) {
                        event.setPitch(KillAura.facing12[1]);
                    }
                }
                if (((Boolean)KillAura.yawValue.getValue()).booleanValue()) {
                    Minecraft.thePlayer.rotationYawHead = KillAura.facing12[0];
                }
                if (((Boolean)KillAura.pitchValue.getValue()).booleanValue()) {
                    Minecraft.thePlayer.rotationPitchHead = KillAura.facing12[1];
                    RendererLivingEntity.SetPitchY(KillAura.facing12[1]);
                }
            }
        }
        if (((Boolean)KillAura.autoBlockValue.getValue()).booleanValue()) {
            if (KillAura.blockTarget != null) {
                if (this.hasSword(Minecraft.thePlayer)) {
                    if (!KillAura.blocking) {
                        this.blockPreventFlagTimer.reset();
                    } else if (this.blockPreventFlagTimer.hasPassed(30L) && ((Boolean)KillAura.preventFlagValue.getValue()).booleanValue()) {
                        this.unblock(false);
                        this.blockPreventFlagTimer.reset();
                    }
                } else if (KillAura.blocking) {
                    this.unblock(true);
                }
            } else if (KillAura.blocking) {
                this.unblock(true);
            }
        }
    }

    @EventHandler
    public void onPacket1212(EventPacket event) {
        if (this.hand.getValue() == handMode.Fast) {
            if (curTarget != null) {
                double posX = KillAura.curTarget.posX - Minecraft.thePlayer.posX;
                double posZ = KillAura.curTarget.posZ - Minecraft.thePlayer.posZ;
                double posY = KillAura.curTarget.posY - 3.5 + (double)curTarget.getEyeHeight() - Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight();
                double helper = MathHelper.sqrt_double(posX * posX + posZ * posZ);
                float newYaw = (float)Math.toDegrees(-Math.atan(posX / posZ));
                float newPitch = (float)(-Math.toDegrees(Math.atan(posY / helper)));
                if (posZ < 0.0 && posX < 0.0) {
                    newYaw = (float)(90.0 + Math.toDegrees(Math.atan(posZ / posX)));
                } else if (posZ < 0.0 && posX > 0.0) {
                    newYaw = (float)(-90.0 + Math.toDegrees(Math.atan(posZ / posX)));
                }
                if (event.getPacket() instanceof C03PacketPlayer || event.getPacket() instanceof C03PacketPlayer.C05PacketPlayerLook || event.getPacket() instanceof C03PacketPlayer.C06PacketPlayerPosLook) {
                    event.setPacket(new C03PacketPlayer.C06PacketPlayerPosLook(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ, progressYaw, progressPitch, Minecraft.thePlayer.onGround));
                    yaw = newYaw;
                    pitch = newPitch;
                }
            } else {
                progressYaw = (float)this.normalise(Minecraft.thePlayer.rotationYaw, -180.0, 180.0);
                yaw = (float)this.normalise(Minecraft.thePlayer.rotationYaw, -180.0, 180.0);
                progressPitch = Minecraft.thePlayer.rotationPitch;
                pitch = Minecraft.thePlayer.rotationPitch;
            }
        }
    }

    private void block(boolean setItemInUseCount) {
        Minecraft.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(Minecraft.thePlayer.inventory.getCurrentItem()));
        if (setItemInUseCount) {
            Minecraft.thePlayer.setItemInUseCount(Minecraft.thePlayer.inventory.getCurrentItem().getMaxItemUseDuration());
        }
        blocking = true;
    }

    private void unblock(boolean setItemInUseCount) {
        Minecraft.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        if (setItemInUseCount) {
            Minecraft.thePlayer.setItemInUseCount(0);
        }
        blocking = false;
    }

    public void clearcurTargets() {
        curTarget = null;
        this.targetList.clear();
        for (EntityLivingBase ent : this.targetList) {
            if (this.getEntityValidBlock(ent)) continue;
            this.targetList.remove(ent);
        }
    }

    private boolean isBlocking() {
        if (PlayerUtils.isHoldingSword()) {
            if (Minecraft.thePlayer.isBlocking() && !blocking) {
                return true;
            }
        }
        return false;
    }

    public boolean isMoving() {
        if (!Minecraft.thePlayer.isCollidedHorizontally) {
            if (!Minecraft.thePlayer.isSneaking()) {
                if (MovementInput.moveForward == 0.0f) {
                    if (MovementInput.moveStrafe == 0.0f) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }

    private boolean shouldAttack() {
        return this.attackTimer.hasReached(1000.0 / ((Double)this.aps.getValue() + MathUtil.randomDouble(0.0, 5.0)));
    }

    @EventHandler
    private void onUpdatePost(EventPostUpdate e) {
        block36: {
            block39: {
                block40: {
                    block38: {
                        block37: {
                            block33: {
                                block35: {
                                    block34: {
                                        if (!this.AIMed) {
                                            return;
                                        }
                                        if (!((Boolean)autoBlockValue.getValue()).equals(false)) break block33;
                                        if (!KillAura.mc.gameSettings.keyBindAttack.getIsKeyPressed() && ((Boolean)attackKey.getValue()).booleanValue()) break block34;
                                        if (!((Boolean)blockHit.getValue()).booleanValue()) break block35;
                                        if (!Minecraft.playerController.isHittingBlock) break block35;
                                    }
                                    return;
                                }
                                if (this.isBlocking()) {
                                    if (Minecraft.thePlayer.isMoving()) {
                                        mc.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(Minecraft.thePlayer.getCurrentEquippedItem()));
                                    }
                                }
                            }
                            if (curTarget == null) break block36;
                            if (Scaffold.isRotating() || AutoPot.isPotting()) break block37;
                            if (!Client.instance.getModuleManager().getNetWorkAssist().isLagging()) break block38;
                        }
                        this.attackTimer.reset();
                        return;
                    }
                    if (!this.shouldAttack()) break block36;
                    if (!((Boolean)autoBlockValue.getValue()).booleanValue()) break block39;
                    if (!this.hasSword(Minecraft.thePlayer)) break block39;
                    if (blocking) break block40;
                    if (!Minecraft.thePlayer.isBlocking()) break block39;
                }
                this.unblock(false);
            }
            EventBus.getInstance().register(new EventAttack(curTarget, true));
            Client.getModuleManager();
            Criticals cri = (Criticals)ModuleManager.getModuleByClass(Criticals.class);
            if (cri.isEnabled()) {
                cri.packetCrit(curTarget);
            }
            if (((Boolean)multi.getValue()).booleanValue()) {
                int targets = 0;
                Iterator<EntityLivingBase> iterator = this.targetList.iterator();
                while (iterator.hasNext()) {
                    if (targets < ((Number)this.multiMaxTarget.getValue()).intValue()) {
                        Entity entity = iterator.next();
                        if (!this.getEntityValid((EntityLivingBase)entity)) continue;
                        Minecraft.thePlayer.swingItem();
                        Minecraft.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(entity, C02PacketUseEntity.Action.ATTACK));
                        ++targets;
                        continue;
                    }
                    break;
                }
            } else {
                Minecraft.thePlayer.swingItem();
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity((Entity)curTarget, C02PacketUseEntity.Action.ATTACK));
            }
            EventBus.getInstance().register(new EventAttack(curTarget, false));
            if (EnchantmentHelper.getModifierForCreature(Minecraft.thePlayer.getHeldItem(), curTarget.getCreatureAttribute()) > 0.0f) {
                Minecraft.thePlayer.onEnchantmentCritical(curTarget);
            }
            if (Minecraft.thePlayer.fallDistance > 0.0f) {
                if (!Minecraft.thePlayer.onGround) {
                    if (!Minecraft.thePlayer.isOnLadder()) {
                        if (!Minecraft.thePlayer.isInWater()) {
                            if (!Minecraft.thePlayer.isPotionActive(Potion.blindness)) {
                                if (Minecraft.thePlayer.ridingEntity == null) {
                                    Minecraft.thePlayer.onCriticalHit(curTarget);
                                }
                            }
                        }
                    }
                }
            }
            this.attackTimer.reset();
        }
        if (((Boolean)autoBlockValue.getValue()).booleanValue() && blockTarget != null) {
            if (this.hasSword(Minecraft.thePlayer) && !blocking) {
                this.block(true);
            }
        }
    }

    /*
     * Unable to fully structure code
     */
    private boolean getEntityValid(EntityLivingBase entity) {
        block15: {
            block14: {
                block13: {
                    Client.getModuleManager();
                    antibots = (AntiBot)ModuleManager.getModuleByClass(AntiBot.class);
                    if (!Minecraft.thePlayer.isEntityAlive()) break block13;
                    if (Minecraft.thePlayer.isPlayerSleeping()) break block13;
                    if (Minecraft.thePlayer.isDead) break block13;
                    if (Minecraft.thePlayer.getHealth() <= 0.0f) break block13;
                    if (Minecraft.thePlayer.getDistanceToEntity(entity) > ((Number)this.rangeValue.getValue()).floatValue() || !entity.isEntityAlive() || entity.isDead || entity.getHealth() <= 0.0f || entity instanceof EntityArmorStand || Teams.isOnSameTeam(entity) || AntiBot.isBot(entity) || this.notInFov(entity)) break block13;
                    if (entity != Minecraft.thePlayer) break block14;
                }
                return false;
            }
            if (!(entity instanceof EntityPlayer)) break block15;
            player = (EntityPlayer)entity;
            if (FriendManager.isFriend(player.getName())) {
                return false;
            }
            if (!((Boolean)KillAura.playerValue.getValue()).booleanValue()) {
                return false;
            }
            if (player.isPlayerSleeping()) {
                return false;
            }
            if (!((Boolean)KillAura.throughWallValue.getValue()).booleanValue()) ** GOTO lbl-1000
            if (!(Minecraft.thePlayer.getDistanceToEntity(player) > ((Number)this.wallRangeValue.getValue()).floatValue())) {
                v0 = false;
            } else lbl-1000:
            // 2 sources

            {
                v0 = wallChecks = true;
            }
            if (!RotationUtil.canEntityBeSeen(player) && wallChecks) {
                return false;
            }
            if (player.isPotionActive(Potion.invisibility) && !((Boolean)KillAura.invisibleValue.getValue()).booleanValue()) {
                return false;
            }
        }
        if (entity instanceof EntityAnimal) {
            return (Boolean)KillAura.animalValue.getValue();
        }
        if (entity instanceof EntityMob) {
            return (Boolean)KillAura.monsterValue.getValue();
        }
        if (entity instanceof EntityVillager || entity instanceof EntityIronGolem || entity instanceof EntitySnowman) {
            return (Boolean)KillAura.neutralValue.getValue();
        }
        return true;
    }

    private boolean getVIPValid(EntityWither entity) {
        if (((Boolean)neutralValue.getValue()).booleanValue()) {
            if (Minecraft.thePlayer.isEntityAlive()) {
                if (!Minecraft.thePlayer.isPlayerSleeping()) {
                    if (!Minecraft.thePlayer.isDead) {
                        if (Minecraft.thePlayer.getHealth() > 0.0f) {
                            if (Minecraft.thePlayer.getDistanceToEntity(entity) <= ((Number)this.rangeValue.getValue()).floatValue() && !Teams.isOnSameTeam(entity) && !AntiBot.isBot(entity) && !this.notInFov(entity)) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public static boolean isOnTeam(EntityLivingBase en) {
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.getDisplayName().getUnformattedText().startsWith("\u00a7")) {
            Minecraft.getMinecraft();
            if (Minecraft.thePlayer.getDisplayName().getUnformattedText().length() <= 2 || en.getDisplayName().getUnformattedText().length() <= 2) {
                return false;
            }
            Minecraft.getMinecraft();
            if (Minecraft.thePlayer.getDisplayName().getUnformattedText().substring(0, 2).equals(en.getDisplayName().getUnformattedText().substring(0, 2))) {
                return true;
            }
        }
        return false;
    }

    private boolean getEntityValidBlock(EntityLivingBase entity) {
        block12: {
            block11: {
                if (!Minecraft.thePlayer.isEntityAlive()) break block11;
                if (Minecraft.thePlayer.isPlayerSleeping()) break block11;
                if (Minecraft.thePlayer.isDead) break block11;
                if (Minecraft.thePlayer.getHealth() <= 0.0f) break block11;
                if (Minecraft.thePlayer.getDistanceToEntity(entity) > ((Number)this.blockRangeValue.getValue()).floatValue() || !entity.isEntityAlive() || entity.isDead || entity.getHealth() <= 0.0f || entity instanceof EntityArmorStand || Teams.isOnSameTeam(entity) || AntiBot.isBot(entity) || this.notInFov(entity)) break block11;
                if (entity != Minecraft.thePlayer) break block12;
            }
            return false;
        }
        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer)entity;
            if (FriendManager.isFriend(player.getName())) {
                return false;
            }
            if (!((Boolean)playerValue.getValue()).booleanValue()) {
                return false;
            }
            if (player.isPlayerSleeping()) {
                return false;
            }
            if (player.isPotionActive(Potion.invisibility) && !((Boolean)invisibleValue.getValue()).booleanValue()) {
                return false;
            }
        }
        if (entity instanceof EntityAnimal) {
            return (Boolean)animalValue.getValue();
        }
        if (entity instanceof EntityMob) {
            return (Boolean)monsterValue.getValue();
        }
        if (entity instanceof EntityVillager || entity instanceof EntityIronGolem || entity instanceof EntitySnowman) {
            return (Boolean)neutralValue.getValue();
        }
        return true;
    }

    private boolean notInFov(Entity entity) {
        return !(Math.abs(RotationUtil.getYawDifference(Minecraft.thePlayer.rotationYaw, entity.posX, entity.posY, entity.posZ)) <= ((Number)this.fovValue.getValue()).floatValue());
    }

    private void sortList(List<EntityLivingBase> weed) {
        if (this.Priority.getValue() == priority.Distance) {
            weed.sort(Comparator.comparingDouble(o -> RotationUtils.getRotations(o)[0]));
        }
        if (this.Priority.getValue() == priority.Health1) {
            weed.sort(Comparator.comparingDouble(EntityLivingBase::getHealth));
        }
        if (this.Priority.getValue() == priority.Fov) {
            weed.sort(Comparator.comparingDouble(o -> Math.abs(RotationUtils.getYawChange(o.posX, o.posZ))));
        }
    }

    public static int getAstolfoRainbow(int v1) {
        double d;
        double length = 1.6;
        double delay = Math.ceil((double)(System.currentTimeMillis() + (long)((double)v1 * length)) / 5.0);
        float rainbow = (double)((float)(d / 360.0)) < 0.5 ? -((float)(delay / 360.0)) : (float)((delay %= 360.0) / 360.0);
        return Color.getHSBColor(rainbow, 0.6f, 1.0f).getRGB();
    }

    @EventHandler
    public void onRender3D2(EventRender3D event) {
        if (curTarget != null && this.mode2.getValue() == ESPMode.Vape && !KillAura.curTarget.isDead) {
            mc.getRenderManager();
            double x1 = KillAura.curTarget.lastTickPosX + (KillAura.curTarget.posX - KillAura.curTarget.lastTickPosX) * (double)Minecraft.getMinecraft().timer.renderPartialTicks - RenderManager.renderPosX;
            mc.getRenderManager();
            double y1 = KillAura.curTarget.lastTickPosY + (KillAura.curTarget.posY - KillAura.curTarget.lastTickPosY) * (double)Minecraft.getMinecraft().timer.renderPartialTicks - RenderManager.renderPosY;
            mc.getRenderManager();
            double z1 = KillAura.curTarget.lastTickPosZ + (KillAura.curTarget.posZ - KillAura.curTarget.lastTickPosZ) * (double)Minecraft.getMinecraft().timer.renderPartialTicks - RenderManager.renderPosZ;
            double width = KillAura.curTarget.getEntityBoundingBox().maxX - KillAura.curTarget.getEntityBoundingBox().minX - 0.2;
            double height = KillAura.curTarget.getEntityBoundingBox().maxY - KillAura.curTarget.getEntityBoundingBox().minY + 0.05;
            float red = 220.0f - (float)(KillAura.curTarget.hurtTime * 5) / 255.0f;
            float green = (float)(KillAura.curTarget.hurtTime * 10) / 255.0f;
            float blue = (float)(KillAura.curTarget.hurtTime * 2) / 255.0f;
            float alpha = (float)(80 + KillAura.curTarget.hurtTime * 10) / 255.0f;
            RenderUtil.drawEntityESP(x1, y1, z1, width, height, red, green, blue, alpha, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f);
        }
    }

    public static void drawCircle(EntityLivingBase entity, int color, EventRender3D e) {
        double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)e.getPartialTicks() - RenderManager.renderPosX;
        double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)e.getPartialTicks() - RenderManager.renderPosY;
        double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)e.getPartialTicks() - RenderManager.renderPosZ;
        float radius = 0.2f;
        int side = 4;
        GL11.glPushMatrix();
        GL11.glTranslated((double)x, (double)(y + 2.0), (double)z);
        GL11.glRotatef((float)(-entity.width), (float)0.0f, (float)1.0f, (float)0.0f);
        KillAura.glColor(color);
        KillAura.enableSmoothLine(1.0f);
        Cylinder c = new Cylinder();
        GL11.glRotatef((float)-90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
        c.setDrawStyle(100012);
        c.draw(0.0f, radius, 0.3f, side, 1);
        c.setDrawStyle(100012);
        GL11.glTranslated((double)0.0, (double)0.0, (double)0.3);
        c.draw(radius, 0.0f, 0.3f, side, 1);
        GL11.glRotatef((float)90.0f, (float)0.0f, (float)0.0f, (float)1.0f);
        c.setDrawStyle(100011);
        GL11.glTranslated((double)0.0, (double)0.0, (double)-0.3);
        c.draw(0.0f, radius, 0.3f, side, 1);
        c.setDrawStyle(100011);
        GL11.glTranslated((double)0.0, (double)0.0, (double)0.3);
        c.draw(radius, 0.0f, 0.3f, side, 1);
        KillAura.disableSmoothLine();
        GL11.glPopMatrix();
    }

    @EventHandler
    public void onRender3D(EventRender3D event) {
        double z1;
        double y1;
        double z;
        double y;
        double x;
        EntityLivingBase entity2;
        if (this.mode2.getValue() == ESPMode.Exhibition) {
            entity2 = curTarget;
            mc.getRenderManager();
            x = entity2.lastTickPosX + (entity2.posX - entity2.lastTickPosX) * (double)KillAura.mc.timer.renderPartialTicks - RenderManager.renderPosX;
            mc.getRenderManager();
            y = entity2.lastTickPosY + (entity2.posY - entity2.lastTickPosY) * (double)KillAura.mc.timer.renderPartialTicks - RenderManager.renderPosY;
            mc.getRenderManager();
            z = entity2.lastTickPosZ + (entity2.posZ - entity2.lastTickPosZ) * (double)KillAura.mc.timer.renderPartialTicks - RenderManager.renderPosZ;
            KillAura.drawCircle(entity2, entity2.hurtTime >= 1 ? new Color(255, 0, 0, 160).getRGB() : new Color(((Double)HUD.r.getValue()).intValue(), ((Double)HUD.g.getValue()).intValue(), ((Double)HUD.b.getValue()).intValue(), 160).getRGB(), event);
        }
        if (this.mode2.getValue() == ESPMode.Cylinder) {
            double posX = KillAura.curTarget.lastTickPosX + (KillAura.curTarget.posX - KillAura.curTarget.lastTickPosX) * (double)event.getPartialTicks() - RenderManager.renderPosX;
            double posY = KillAura.curTarget.lastTickPosY + (KillAura.curTarget.posY - KillAura.curTarget.lastTickPosY) * (double)event.getPartialTicks() - RenderManager.renderPosY;
            double posZ = KillAura.curTarget.lastTickPosZ + (KillAura.curTarget.posZ - KillAura.curTarget.lastTickPosZ) * (double)event.getPartialTicks() - RenderManager.renderPosZ;
            if (KillAura.curTarget.hurtTime > 0) {
                RenderUtil.drawWolframEntityESP(curTarget, new Color(255, 102, 113).getRGB(), posX, posY, posZ);
            } else {
                RenderUtil.drawWolframEntityESP(curTarget, new Color(186, 100, 200).getRGB(), posX, posY, posZ);
            }
        }
        if (this.mode2.getValue() == ESPMode.Rainbow) {
            float alpha;
            float blue;
            float green;
            float red;
            mc.getRenderManager();
            double x1 = KillAura.curTarget.lastTickPosX + (KillAura.curTarget.posX - KillAura.curTarget.lastTickPosX) * (double)KillAura.mc.timer.renderPartialTicks - RenderManager.renderPosX;
            mc.getRenderManager();
            y1 = KillAura.curTarget.lastTickPosY + (KillAura.curTarget.posY - KillAura.curTarget.lastTickPosY) * (double)KillAura.mc.timer.renderPartialTicks - RenderManager.renderPosY;
            mc.getRenderManager();
            z1 = KillAura.curTarget.lastTickPosZ + (KillAura.curTarget.posZ - KillAura.curTarget.lastTickPosZ) * (double)KillAura.mc.timer.renderPartialTicks - RenderManager.renderPosZ;
            double width = KillAura.curTarget.getEntityBoundingBox().maxX - KillAura.curTarget.getEntityBoundingBox().minX - 0.2;
            double height = KillAura.curTarget.getEntityBoundingBox().maxY - KillAura.curTarget.getEntityBoundingBox().minY + 0.05;
            if (KillAura.curTarget.hurtTime == 10) {
                red = (float)ColorUtils.getRainbow().getRed() / 255.0f;
                green = (float)ColorUtils.getRainbow().getGreen() / 255.0f;
                blue = (float)ColorUtils.getRainbow().getBlue() / 255.0f;
                alpha = (float)(80 + KillAura.curTarget.hurtTime * 10) / 255.0f;
            } else {
                red = (float)ColorUtils.getRainbow().getRed() / 255.0f;
                green = (float)ColorUtils.getRainbow().getGreen() / 255.0f;
                blue = (float)ColorUtils.getRainbow().getBlue() / 255.0f;
                alpha = (float)(80 + KillAura.curTarget.hurtTime * 10) / 255.0f;
            }
            RenderUtil.drawEntityESP(x1, y1, z1, width, height, red, green, blue, alpha, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f);
        }
        if (this.mode2.getValue() == ESPMode.New) {
            float lineWdith1;
            float lineAlpha1;
            float lineBlue1;
            float lineGreen1;
            float lineRed1;
            float alpha1;
            float green1;
            mc.getRenderManager();
            double x1 = KillAura.curTarget.lastTickPosX + (KillAura.curTarget.posX - KillAura.curTarget.lastTickPosX) * (double)KillAura.mc.timer.renderPartialTicks - RenderManager.renderPosX;
            mc.getRenderManager();
            y1 = KillAura.curTarget.lastTickPosY + (KillAura.curTarget.posY - KillAura.curTarget.lastTickPosY) * (double)KillAura.mc.timer.renderPartialTicks - RenderManager.renderPosY;
            mc.getRenderManager();
            z1 = KillAura.curTarget.lastTickPosZ + (KillAura.curTarget.posZ - KillAura.curTarget.lastTickPosZ) * (double)KillAura.mc.timer.renderPartialTicks - RenderManager.renderPosZ;
            if (curTarget instanceof EntityPlayer) {
                double width1 = KillAura.curTarget.getEntityBoundingBox().maxX - KillAura.curTarget.getEntityBoundingBox().minX - 0.35;
                double height1 = KillAura.curTarget.getEntityBoundingBox().maxY - KillAura.curTarget.getEntityBoundingBox().minY;
                float red1 = KillAura.curTarget.hurtTime > 0 ? 1.0f : 0.0f;
                green1 = KillAura.curTarget.hurtTime > 0 ? 0.2f : 1.0f;
                float blue1 = KillAura.curTarget.hurtTime > 0 ? 0.0f : 0.2f;
                alpha1 = 0.2f;
                lineRed1 = KillAura.curTarget.hurtTime > 0 ? 1.0f : 0.0f;
                lineGreen1 = KillAura.curTarget.hurtTime > 0 ? 0.2f : 1.0f;
                lineBlue1 = KillAura.curTarget.hurtTime > 0 ? 0.0f : 0.2f;
                lineAlpha1 = 0.2f;
                lineWdith1 = 2.0f;
                RenderUtil.drawEntityESP(x1, y1, z1, width1, height1, red1, green1, blue1, 0.2f, lineRed1, lineGreen1, lineBlue1, 0.2f, 2.0f);
            } else {
                double width1 = KillAura.curTarget.getEntityBoundingBox().maxX - KillAura.curTarget.getEntityBoundingBox().minX - 0.35;
                double height1 = KillAura.curTarget.getEntityBoundingBox().maxY - KillAura.curTarget.getEntityBoundingBox().minY;
                float red1 = KillAura.curTarget.hurtTime > 0 ? 1.0f : 0.0f;
                green1 = KillAura.curTarget.hurtTime > 0 ? 0.2f : 1.0f;
                float blue1 = KillAura.curTarget.hurtTime > 0 ? 0.0f : 0.2f;
                alpha1 = 0.2f;
                lineRed1 = KillAura.curTarget.hurtTime > 0 ? 1.0f : 0.0f;
                lineGreen1 = KillAura.curTarget.hurtTime > 0 ? 0.2f : 1.0f;
                lineBlue1 = KillAura.curTarget.hurtTime > 0 ? 0.0f : 0.2f;
                lineAlpha1 = 0.2f;
                lineWdith1 = 2.0f;
                RenderUtil.drawEntityESP(x1, y1, z1, width1, height1, red1, green1, blue1, 0.2f, lineRed1, lineGreen1, lineBlue1, 0.2f, 2.0f);
            }
        }
        if (this.mode2.getValue() == ESPMode.Power) {
            if (this.targetList.isEmpty()) {
                if (blockTarget != null) {
                    entity2 = blockTarget;
                    double d = entity2.lastTickPosX + (entity2.posX - entity2.lastTickPosX) * (double)KillAura.mc.timer.renderPartialTicks;
                    mc.getRenderManager();
                    x = d - RenderManager.renderPosX;
                    double d2 = entity2.lastTickPosY + (entity2.posY - entity2.lastTickPosY) * (double)KillAura.mc.timer.renderPartialTicks;
                    mc.getRenderManager();
                    y = d2 - RenderManager.renderPosY;
                    double d3 = entity2.lastTickPosZ + (entity2.posZ - entity2.lastTickPosZ) * (double)KillAura.mc.timer.renderPartialTicks;
                    mc.getRenderManager();
                    z = d3 - RenderManager.renderPosZ;
                    double height = entity2.getEntityBoundingBox().maxY - entity2.getEntityBoundingBox().minY + 0.1;
                    double fx = entity2.getEntityBoundingBox().maxX - entity2.getEntityBoundingBox().minX;
                    double fz = entity2.getEntityBoundingBox().maxZ - entity2.getEntityBoundingBox().minZ;
                    double width = Math.sqrt(fx * fx + fz * fz) - 0.5;
                    float red = 1.0f;
                    float green = entity2.hurtTime > 0 ? 0.0f : 0.2f;
                    float blue = entity2.hurtTime > 0 ? 0.0f : 0.2f;
                    RenderUtil.drawBoundingBox(x, y += height / 2.0 + height / 4.0 - 0.05, z, width, 0.1, 1.0f, green, blue, 0.7f);
                }
            } else {
                for (EntityLivingBase entity2 : this.targetList) {
                    float blue;
                    double d = entity2.lastTickPosX + (entity2.posX - entity2.lastTickPosX) * (double)KillAura.mc.timer.renderPartialTicks;
                    mc.getRenderManager();
                    double x2 = d - RenderManager.renderPosX;
                    double d4 = entity2.lastTickPosY + (entity2.posY - entity2.lastTickPosY) * (double)KillAura.mc.timer.renderPartialTicks;
                    mc.getRenderManager();
                    double y2 = d4 - RenderManager.renderPosY;
                    double d5 = entity2.lastTickPosZ + (entity2.posZ - entity2.lastTickPosZ) * (double)KillAura.mc.timer.renderPartialTicks;
                    mc.getRenderManager();
                    double z2 = d5 - RenderManager.renderPosZ;
                    double height = entity2.getEntityBoundingBox().maxY - entity2.getEntityBoundingBox().minY + 0.1;
                    double fx = entity2.getEntityBoundingBox().maxX - entity2.getEntityBoundingBox().minX;
                    double fz = entity2.getEntityBoundingBox().maxZ - entity2.getEntityBoundingBox().minZ;
                    double width = Math.sqrt(fx * fx + fz * fz) - 0.5;
                    y2 += height / 2.0 + height / 4.0 - 0.05;
                    float red = 1.0f;
                    float green = entity2.hurtTime > 0 ? 0.0f : 0.2f;
                    float f = blue = entity2.hurtTime > 0 ? 0.0f : 0.2f;
                    if (entity2 == curTarget) {
                        RenderUtil.drawBoundingBox(x2, y2, z2, width, 0.1, 1.0f, green, blue, 0.7f);
                        continue;
                    }
                    RenderUtil.drawBoundingBox(x2, y2, z2, width, 0.1, 1.0f, 1.0f, 1.0f, 0.4f);
                }
            }
        }
        this.mode2.getValue();
        entity2 = curTarget;
        if (this.mode2.getValue() == ESPMode.Jello && entity2 != null && !KillAura.curTarget.isDead) {
            this.esp(curTarget, EventRender3D.ticks);
        }
    }

    public void esp(Entity entity, float partialTicks) {
        this.onecircle(entity, partialTicks, 0.6f, 0.0f);
    }

    public void onecircle(Entity entity, float partialTicks, float alpha, float yoffset) {
        double shit = entity.getEntityBoundingBox().maxY - entity.posY - 0.9;
        double d = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)partialTicks;
        mc.getRenderManager();
        double x = d - RenderManager.viewerPosX;
        double d2 = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)partialTicks;
        mc.getRenderManager();
        double y = d2 - RenderManager.viewerPosY + Math.sin((double)System.currentTimeMillis() * 0.0045) * shit + shit + (double)yoffset;
        double d3 = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)partialTicks;
        mc.getRenderManager();
        double z = d3 - RenderManager.viewerPosZ;
        Cylinder c = new Cylinder();
        GL11.glPushMatrix();
        GL11.glDisable((int)2896);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)2848);
        GL11.glDepthMask((boolean)false);
        GlStateManager.translate(x, y, z);
        GlStateManager.color(1.0f, 1.0f, 1.0f, alpha);
        GlStateManager.rotate(180.0f, 90.0f, 0.0f, 2.0f);
        GlStateManager.rotate(180.0f, 0.0f, 90.0f, 90.0f);
        c.setDrawStyle(100011);
        c.draw(0.8f, 0.8f, 0.0f, 360, 0);
        GL11.glDisable((int)2848);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2896);
        GL11.glEnable((int)3553);
        GL11.glPopMatrix();
    }

    public static void glColor(int hex) {
        float alpha = (float)(hex >> 24 & 0xFF) / 255.0f;
        float red = (float)(hex >> 16 & 0xFF) / 255.0f;
        float green = (float)(hex >> 8 & 0xFF) / 255.0f;
        float blue = (float)(hex & 0xFF) / 255.0f;
        GL11.glColor4f((float)red, (float)green, (float)blue, (float)(alpha == 0.0f ? 1.0f : alpha));
    }

    public static void enableSmoothLine(float width) {
        GL11.glDisable((int)3008);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glEnable((int)2884);
        GL11.glEnable((int)2848);
        GL11.glHint((int)3154, (int)4354);
        GL11.glHint((int)3155, (int)4354);
        GL11.glLineWidth((float)width);
    }

    public static void disableSmoothLine() {
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)3008);
        GL11.glDepthMask((boolean)true);
        GL11.glCullFace((int)1029);
        GL11.glDisable((int)2848);
        GL11.glHint((int)3154, (int)4352);
        GL11.glHint((int)3155, (int)4352);
    }

    public static void drawCylinderESP(EntityLivingBase entity, int color, double x, double y, double z) {
        GL11.glPushMatrix();
        GL11.glTranslated((double)x, (double)y, (double)z);
        GL11.glRotatef((float)(-entity.width), (float)0.0f, (float)1.0f, (float)0.0f);
        KillAura.glColor(new Color(1, 89, 1, 150).getRGB());
        KillAura.enableSmoothLine(2.0f);
        Cylinder c = new Cylinder();
        GL11.glRotatef((float)-90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
        c.setDrawStyle(100011);
        c.draw(0.0f, 0.2f, 0.5f, 4, 200);
        KillAura.disableSmoothLine();
        GL11.glPopMatrix();
        GL11.glPushMatrix();
        GL11.glTranslated((double)x, (double)(y + 0.5), (double)z);
        GL11.glRotatef((float)(-entity.width), (float)0.0f, (float)1.0f, (float)0.0f);
        KillAura.glColor(new Color(2, 168, 2, 150).getRGB());
        KillAura.enableSmoothLine(2.0f);
        GL11.glRotatef((float)-90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
        c.setDrawStyle(100011);
        c.draw(0.2f, 0.0f, 0.5f, 4, 200);
        KillAura.disableSmoothLine();
        GL11.glPopMatrix();
    }

    public static void drawCrystalESP(EntityLivingBase entity, int color, double x, double y, double z) {
        int i = 1;
        while (i < 20) {
            Color rainbow = new Color(Color.HSBtoRGB((float)((double)Minecraft.thePlayer.ticksExisted / 50.0 + Math.sin((double)i / 50.0)) % 1.0f, 0.8f, 1.0f));
            GL11.glPushMatrix();
            GL11.glTranslated((double)x, (double)y, (double)z);
            KillAura.glColor(rainbow.getRGB());
            KillAura.enableSmoothLine(1.0f);
            Cylinder c = new Cylinder();
            GL11.glRotatef((float)-90.0f, (float)1.0f, (float)0.0f, (float)0.0f);
            c.setDrawStyle(100011);
            c.draw(0.02f, 0.02f, 0.0f, 12, 0);
            KillAura.disableSmoothLine();
            GL11.glPopMatrix();
            ++i;
        }
    }

    private float getYawDifference(float currentYaw, float neededYaw) {
        float yawDifference = neededYaw - currentYaw;
        if (yawDifference > 180.0f) {
            yawDifference = -(360.0f - neededYaw + currentYaw);
        } else if (yawDifference < -180.0f) {
            yawDifference = 360.0f - currentYaw + neededYaw;
        }
        return yawDifference;
    }

    private static float[] getRotations(Entity entity, float prevYaw, float prevPitch, float aimSpeed) {
        EntityPlayerSP player = Wrapper.getPlayer();
        double xDist = entity.posX - player.posX;
        double zDist = entity.posZ - player.posZ;
        AxisAlignedBB entityBB = entity.getEntityBoundingBox().expand(0.1f, 0.1f, 0.1f);
        double playerEyePos = player.posY + (double)player.getEyeHeight();
        double yDist = playerEyePos > entityBB.maxY ? entityBB.maxY - playerEyePos : (playerEyePos < entityBB.minY ? entityBB.minY - playerEyePos : 0.0);
        double fDist = MathHelper.sqrt_double(xDist * xDist + zDist * zDist);
        float yaw = KillAura.interpolateRotation(prevYaw, (float)(StrictMath.atan2(zDist, xDist) * 57.29577951308232) - 90.0f, aimSpeed);
        float pitch = KillAura.interpolateRotation(prevPitch, (float)(-(StrictMath.atan2(yDist, fDist) * 57.29577951308232)), aimSpeed);
        return new float[]{yaw, pitch};
    }

    private static float getAngleDifference(float a, float b) {
        return ((a - b) % 360.0f + 540.0f) % 360.0f - 180.0f;
    }

    public float fixedSensitivity(float sensitivity, float x) {
        float f = sensitivity * 0.6f + 0.2f;
        float gcd = f * f * f * 1.2f;
        return x - x % gcd;
    }

    private float[] getRotationNeededHypixelBetter(Entity p) {
        double d1 = p.posX - Minecraft.thePlayer.posX;
        double d2 = p.posY + (double)p.getEyeHeight() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        double d3 = p.posZ - Minecraft.thePlayer.posZ;
        double d4 = Math.sqrt(d1 * d1 + d3 * d3);
        float f1 = (float)(Math.atan2(d3, d1) * 180.0 / Math.PI) - 90.0f;
        float f2 = (float)(-Math.atan2(d2, d4) * 180.0 / Math.PI);
        return new float[]{f1, f2};
    }

    public static float[] getRotationFromPosition(double x, double z, double y) {
        double xDiff = x - Minecraft.thePlayer.posX;
        double zDiff = z - Minecraft.thePlayer.posZ;
        double yDiff = y - Minecraft.thePlayer.posY - 1.2;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    private static float[] getRotations2(Entity entity) {
        float pitch;
        boolean close;
        EntityPlayerSP player = Wrapper.getPlayer();
        double xDist = entity.posX - player.posX;
        double zDist = entity.posZ - player.posZ;
        double yDist = entity.posY - player.posY;
        double dist = StrictMath.sqrt(xDist * xDist + zDist * zDist);
        AxisAlignedBB entityBB = entity.getEntityBoundingBox().expand(0.1f, 0.1f, 0.1f);
        double playerEyePos = player.posY + (double)player.getEyeHeight();
        boolean bl = close = dist < 2.0 && Math.abs(yDist) < 2.0;
        if (close && playerEyePos > entityBB.minY) {
            pitch = 60.0f;
        } else {
            yDist = playerEyePos > entityBB.maxY ? entityBB.maxY - playerEyePos : (playerEyePos < entityBB.minY ? entityBB.minY - playerEyePos : 0.0);
            pitch = (float)(-(StrictMath.atan2(yDist, dist) * 57.29577951308232));
        }
        float yaw = (float)(StrictMath.atan2(zDist, xDist) * 57.29577951308232) - 90.0f;
        if (close) {
            int inc = dist < 1.0 ? 180 : 90;
            yaw = Math.round(yaw / (float)inc) * inc;
        }
        return new float[]{yaw, pitch};
    }

    public float[] customRots(EventPreUpdate em, EntityLivingBase ent) {
        double randomYaw = 0.05;
        double randomPitch = 0.05;
        float[] rotsN = this.getCustomRotsChange(sYaw, sPitch, KillAura.curTarget.posX + (double)KillAura.randomNumber(1.0, -1.0) * randomYaw, KillAura.curTarget.posY + (double)KillAura.randomNumber(1.0, -1.0) * randomPitch, KillAura.curTarget.posZ + (double)KillAura.randomNumber(1.0, -1.0) * randomYaw);
        float targetYaw = rotsN[0];
        float yawFactor = targetYaw * targetYaw / (4.7f * targetYaw);
        if (targetYaw < 5.0f) {
            yawFactor = targetYaw * targetYaw / (3.7f * targetYaw);
        }
        if (Math.abs(yawFactor) > 7.0f) {
            aacB = yawFactor * 7.0f;
            yawFactor = targetYaw * targetYaw / (3.7f * targetYaw);
        } else {
            yawFactor = targetYaw * targetYaw / (6.7f * targetYaw) + aacB;
        }
        em.setYaw(sYaw + yawFactor);
        float targetPitch = rotsN[1];
        float pitchFactor = targetPitch / 3.7f;
        em.setPitch(sPitch + pitchFactor);
        return new float[]{sYaw += yawFactor, sPitch += pitchFactor};
    }

    public float[] getCustomRotsChange(float yaw, float pitch, double x, double y, double z) {
        double xDiff = x - Minecraft.thePlayer.posX;
        double zDiff = z - Minecraft.thePlayer.posZ;
        double yDiff = y - Minecraft.thePlayer.posY;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        double mult = 1.0 / (dist + 1.0E-4) * 2.0;
        if (mult > 0.2) {
            mult = 0.2;
        }
        if (!Minecraft.theWorld.getEntitiesWithinAABBExcludingEntity(Minecraft.thePlayer, Minecraft.thePlayer.boundingBox).contains(curTarget)) {
            x += 0.3 * (double)this.randoms[0];
            y -= 0.4 + mult * (double)this.randoms[1];
            z += 0.3 * (double)this.randoms[2];
        }
        xDiff = x - Minecraft.thePlayer.posX;
        zDiff = z - Minecraft.thePlayer.posZ;
        yDiff = y - Minecraft.thePlayer.posY;
        float yawToEntity = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitchToEntity = (float)(-(Math.atan2(yDiff, dist) * 180.0 / Math.PI));
        return new float[]{MathHelper.wrapAngleTo180_float(-(yaw - yawToEntity)), -MathHelper.wrapAngleTo180_float(pitch - pitchToEntity) - 2.5f};
    }

    public float[] getRotations(EntityLivingBase e, EventPreUpdate event) {
        float[] targetYaw = this.getRotations(e);
        float yaw = 0.0f;
        float speed = (float)ThreadLocalRandom.current().nextDouble(2.0, 2.7);
        float yawDifference = event.getLastYaw() - targetYaw[0];
        yaw = event.getLastYaw() - yawDifference / speed;
        float pitch = 0.0f;
        float pitchDifference = event.getLastPitch() - targetYaw[1];
        pitch = event.getLastPitch() - pitchDifference / speed;
        return new float[]{yaw, pitch};
    }

    public float[] getRotations1(EntityLivingBase e, EventPreUpdate event) {
        float[] rots = RotationUtils.getRotations(e);
        return new float[]{rots[0] + (float)KillAura.randomNumber(3.0, -3.0), rots[1] + (float)KillAura.randomNumber(3.0, -3.0)};
    }

    public float[] zenithgetRotations(EntityLivingBase e, EventPreUpdate event) {
        float[] targetYaw = this.getRotations(e);
        float yaw = 0.0f;
        float speed = (float)ThreadLocalRandom.current().nextDouble(3.5, 4.2);
        float yawDifference = event.getLastYaw() - targetYaw[0];
        yaw = event.getLastYaw() - yawDifference / 3.0f;
        float pitch = 0.0f;
        float pitchDifference = event.getLastPitch() - targetYaw[1];
        pitch = event.getLastPitch() - pitchDifference / speed;
        return new float[]{yaw, pitch};
    }

    public float[] getRotationsNeededBlock(double x, double y, double z) {
        Minecraft.getMinecraft();
        double diffX = x + 0.5 - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double diffZ = z + 0.5 - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        double diffY = y - Minecraft.thePlayer.posY - 0.2;
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-Math.atan2(diffY, dist) * 180.0 / Math.PI);
        float[] fArray = new float[2];
        Minecraft.getMinecraft();
        fArray[0] = Minecraft.thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(yaw - (float)((Number)this.angleValue.getValue()).doubleValue());
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        fArray[1] = Minecraft.thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float(pitch - Minecraft.thePlayer.rotationPitch);
        return fArray;
    }

    public static float[] getNeededRotations(Vec3 vec) {
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        double d = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight();
        Minecraft.getMinecraft();
        Vec3 eyesPos = new Vec3(Minecraft.thePlayer.posX, d, Minecraft.thePlayer.posZ);
        double diffX = vec.xCoord - eyesPos.xCoord;
        double diffY = vec.yCoord - eyesPos.yCoord;
        double diffZ = vec.zCoord - eyesPos.zCoord;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[]{MathHelper.wrapAngleTo180_float(yaw), MathHelper.wrapAngleTo180_float(pitch)};
    }

    private static float interpolateRotation(float prev, float now, float maxTurn) {
        float var4 = MathHelper.wrapAngleTo180_float(now - prev);
        if (var4 > maxTurn) {
            var4 = maxTurn;
        }
        if (var4 < -maxTurn) {
            var4 = -maxTurn;
        }
        return prev + var4;
    }

    public float[] getRotations(Entity entity) {
        if (entity == null) {
            return null;
        }
        Minecraft.getMinecraft();
        double diffX = entity.posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double diffZ = entity.posZ - Minecraft.thePlayer.posZ;
        double diffY = ((Boolean)randomValue.getValue()).booleanValue() ? entity.posY - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()) + MathUtils.getRandom(0.0, 1.6) : entity.posY - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()) + ((Number)this.aimValue.getValue()).doubleValue();
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-Math.atan2(diffY, dist) * 180.0 / Math.PI);
        return new float[]{yaw, pitch};
    }

    public float[] ExgetHypixelRotationsNeededBlock(double x2, double y2, double z2) {
        Minecraft.getMinecraft();
        double diffX = x2 + 0.5 - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double diffZ = z2 + 0.5 - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        double diffY = y2 - Minecraft.thePlayer.posY - 0.2;
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-Math.atan2(diffY, dist) * 180.0 / Math.PI);
        float[] arrf = new float[2];
        Minecraft.getMinecraft();
        arrf[0] = Minecraft.thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(yaw - (float)((Number)this.angleValue.getValue()).doubleValue());
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        arrf[1] = Minecraft.thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float(pitch - Minecraft.thePlayer.rotationPitch);
        return arrf;
    }

    public static float[] ExgetRotationFromPosition(double x, double z, double y) {
        Minecraft.getMinecraft();
        double xDiff = x - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double zDiff = z - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        double yDiff = y - Minecraft.thePlayer.posY - 1.2;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }

    public float[] getRotationsGucel(Entity entity) {
        double xDiff = entity.posX - Minecraft.thePlayer.posX;
        double yDiff = entity.posY - Minecraft.thePlayer.posY;
        double zDiff = entity.posZ - Minecraft.thePlayer.posZ;
        MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float newYaw = (float)Math.toDegrees(-Math.atan(xDiff / zDiff));
        if (zDiff < 0.0 && xDiff < 0.0) {
            newYaw = (float)(90.0 + Math.toDegrees(Math.atan(zDiff / xDiff)));
        } else if (zDiff < 0.0 && xDiff > 0.0) {
            newYaw = (float)(-90.0 + Math.toDegrees(Math.atan(zDiff / xDiff)));
        }
        float newPitch = (float)(-Math.atan2(entity.posY + (double)entity.getEyeHeight() / 0.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
        if (yDiff > -0.25 && yDiff < 0.25) {
            newPitch = (float)(-Math.atan2(entity.posY + (double)entity.getEyeHeight() / HitLocation.CHEST.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
        } else if (yDiff > -0.25) {
            newPitch = (float)(-Math.atan2(entity.posY + (double)entity.getEyeHeight() / HitLocation.FEET.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
        } else if (yDiff < 0.25) {
            newPitch = (float)(-Math.atan2(entity.posY + (double)entity.getEyeHeight() / HitLocation.HEAD.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
        }
        return new float[]{newYaw, newPitch};
    }

    public static float[] getRotationToEntity(EntityLivingBase target) {
        double posX = target.posX;
        Minecraft.getMinecraft();
        double xDiff = posX - Minecraft.thePlayer.posX;
        double posY = target.posY;
        Minecraft.getMinecraft();
        double yDiff = posY - Minecraft.thePlayer.posY;
        double posZ = target.posZ;
        Minecraft.getMinecraft();
        double zDiff = posZ - Minecraft.thePlayer.posZ;
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
        double n = target.posY + (double)target.getEyeHeight() / 0.0;
        Minecraft.getMinecraft();
        double posY2 = Minecraft.thePlayer.posY;
        Minecraft.getMinecraft();
        float pitch = (float)(-Math.atan2(n - (posY2 + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
        if (yDiff > -0.2 && yDiff < 0.2) {
            double n2 = target.posY + (double)target.getEyeHeight() / HitLocation.CHEST.getOffset();
            Minecraft.getMinecraft();
            double posY3 = Minecraft.thePlayer.posY;
            Minecraft.getMinecraft();
            pitch = (float)(-Math.atan2(n2 - (posY3 + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
        } else if (yDiff > -0.2) {
            double n3 = target.posY + (double)target.getEyeHeight() / HitLocation.FEET.getOffset();
            Minecraft.getMinecraft();
            double posY4 = Minecraft.thePlayer.posY;
            Minecraft.getMinecraft();
            pitch = (float)(-Math.atan2(n3 - (posY4 + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
        } else if (yDiff < 0.3) {
            double n4 = target.posY + (double)target.getEyeHeight() / HitLocation.HEAD.getOffset();
            Minecraft.getMinecraft();
            double posY5 = Minecraft.thePlayer.posY;
            Minecraft.getMinecraft();
            pitch = (float)(-Math.atan2(n4 - (posY5 + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
        }
        return new float[]{yaw, pitch};
    }

    public static EntityLivingBase getTarget() {
        return curTarget;
    }

    public static EntityLivingBase getBlockTarget() {
        return blockTarget;
    }

    static enum AuraMode {
        Switch,
        Multi,
        Single;

    }

    static enum ESPMode {
        None,
        Vape,
        Jello,
        Power,
        Cylinder,
        New,
        Rainbow,
        Exhibition;

    }

    static enum HitLocation {
        AUTO(0.0),
        HEAD(1.0),
        CHEST(1.5),
        FEET(3.5);

        private double offset;

        private HitLocation(double offset) {
            this.offset = offset;
        }

        public double getOffset() {
            return this.offset;
        }
    }

    public static enum handMode {
        Slient,
        NorotSet,
        Zenith,
        Predict,
        Fast;

    }

    static enum priority {
        Distance,
        Health1,
        Fov;

    }
}

