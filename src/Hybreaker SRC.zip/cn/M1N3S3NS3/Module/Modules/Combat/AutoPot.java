/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Combat;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPostUpdate;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Util.InventoryUtil;
import cn.M1N3S3NS3.Util.PlayerUtil;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import java.util.Iterator;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class AutoPot
extends Module {
    private static boolean potting;
    private int slot;
    private int last;
    private final TimerUtil timer = new TimerUtil();
    private final Option<Boolean> healthValue = new Option<Boolean>("Health", "Health", true);
    private final Option<Boolean> speedValue = new Option<Boolean>("SpeedPot", "SpeedPot", true);
    private final Option<Boolean> jumpValue = new Option<Boolean>("JumpPot", "JumpPot", true);
    private final Numbers<Number> potHealthValue = new Numbers<Double>("PotHealth", "PotHealth", 15.0, 3.0, 20.0, 1.0);

    public AutoPot() {
        super("AutoPot", new String[]{"AutoPot"}, ModuleType.Combat);
        this.addValues(this.healthValue, this.speedValue, this.jumpValue, this.potHealthValue);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        potting = false;
        this.slot = -1;
        this.last = -1;
        this.timer.reset();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        potting = false;
    }

    @EventHandler
    void onUpdate(EventPreUpdate event) {
        this.slot = this.getSlot();
        if (this.timer.hasPassed(1000L)) {
            int regenId = Potion.regeneration.getId();
            if (!Minecraft.thePlayer.isPotionActive(regenId) && !potting) {
                if (Minecraft.thePlayer.onGround && ((Boolean)this.healthValue.getValue()).booleanValue()) {
                    if ((double)Minecraft.thePlayer.getHealth() <= ((Number)this.potHealthValue.getValue()).doubleValue() && this.hasPot(regenId)) {
                        int cum = this.hasPot(regenId, this.slot);
                        if (cum != -1) {
                            InventoryUtil.swap(cum, this.slot);
                        }
                        this.last = Minecraft.thePlayer.inventory.currentItem;
                        Minecraft.thePlayer.inventory.currentItem = this.slot;
                        event.setPitch((Boolean)this.jumpValue.getValue() != false && !PlayerUtil.MovementInput() ? -90 : (PlayerUtil.MovementInput() ? 85 : 90));
                        if (((Boolean)this.jumpValue.getValue()).booleanValue() && !PlayerUtil.MovementInput()) {
                            Minecraft.thePlayer.motionY = 0.41999998688698 + (double)PlayerUtil.getJumpEffect() * 0.1;
                            PlayerUtil.setSpeed(0.0);
                        }
                        potting = true;
                        this.timer.reset();
                    }
                }
            }
            int speedId = Potion.moveSpeed.getId();
            if (!Minecraft.thePlayer.isPotionActive(speedId) && !potting) {
                if (Minecraft.thePlayer.onGround && ((Boolean)this.speedValue.getValue()).booleanValue() && this.hasPot(speedId)) {
                    int cum = this.hasPot(speedId, this.slot);
                    if (cum != -1) {
                        InventoryUtil.swap(cum, this.slot);
                    }
                    this.last = Minecraft.thePlayer.inventory.currentItem;
                    Minecraft.thePlayer.inventory.currentItem = this.slot;
                    event.setPitch((Boolean)this.jumpValue.getValue() != false && !PlayerUtil.MovementInput() ? -90 : (PlayerUtil.MovementInput() ? 85 : 90));
                    if (((Boolean)this.jumpValue.getValue()).booleanValue() && !PlayerUtil.MovementInput()) {
                        Minecraft.thePlayer.motionY = 0.41999998688698 + (double)PlayerUtil.getJumpEffect() * 0.1;
                        PlayerUtil.setSpeed(0.0);
                    }
                    potting = true;
                    this.timer.reset();
                }
            }
        }
    }

    @EventHandler
    void onUpdate(EventPostUpdate event) {
        if (potting) {
            if (Minecraft.thePlayer.inventory.getCurrentItem() != null) {
                if (Minecraft.playerController.sendUseItem(Minecraft.thePlayer, Minecraft.theWorld, Minecraft.thePlayer.inventory.getCurrentItem())) {
                    AutoPot.mc.entityRenderer.itemRenderer.resetEquippedProgress2();
                }
            }
            if (this.last != -1) {
                Minecraft.thePlayer.inventory.currentItem = this.last;
            }
            potting = false;
            this.last = -1;
        }
    }

    private int hasPot(int id, int targetSlot) {
        int i = 9;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                PotionEffect effect;
                ItemPotion pot;
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (is.getItem() instanceof ItemPotion && !(pot = (ItemPotion)is.getItem()).getEffects(is).isEmpty() && (effect = pot.getEffects(is).get(0)).getPotionID() == id && ItemPotion.isSplash(is.getItemDamage()) && this.isBestPot(pot, is) && 36 + targetSlot != i) {
                    return i;
                }
            }
            ++i;
        }
        return -1;
    }

    private boolean hasPot(int id) {
        int i = 9;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                PotionEffect effect;
                ItemPotion pot;
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (is.getItem() instanceof ItemPotion && !(pot = (ItemPotion)is.getItem()).getEffects(is).isEmpty() && (effect = pot.getEffects(is).get(0)).getPotionID() == id && ItemPotion.isSplash(is.getItemDamage()) && this.isBestPot(pot, is)) {
                    return true;
                }
            }
            ++i;
        }
        return false;
    }

    private boolean isBestPot(ItemPotion potion, ItemStack stack) {
        if (potion.getEffects(stack) == null || potion.getEffects(stack).size() != 1) {
            return false;
        }
        PotionEffect effect = potion.getEffects(stack).get(0);
        int potionID = effect.getPotionID();
        int amplifier = effect.getAmplifier();
        int duration = effect.getDuration();
        int i = 9;
        while (i < 45) {
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemPotion pot;
                ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                if (is.getItem() instanceof ItemPotion && (pot = (ItemPotion)is.getItem()).getEffects(is) != null) {
                    Iterator<PotionEffect> iterator = pot.getEffects(is).iterator();
                    while (iterator.hasNext()) {
                        PotionEffect o;
                        PotionEffect effects = o = iterator.next();
                        int id = effects.getPotionID();
                        int ampl = effects.getAmplifier();
                        int dur = effects.getDuration();
                        if (id != potionID || !ItemPotion.isSplash(is.getItemDamage())) continue;
                        if (ampl > amplifier) {
                            return false;
                        }
                        if (ampl != amplifier || dur <= duration) continue;
                        return false;
                    }
                }
            }
            ++i;
        }
        return true;
    }

    private int getSlot() {
        int spoofSlot = 8;
        int i = 36;
        while (i < 45) {
            if (!Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                spoofSlot = i - 36;
                break;
            }
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack().getItem() instanceof ItemPotion) {
                spoofSlot = i - 36;
                break;
            }
            ++i;
        }
        return spoofSlot;
    }

    public static boolean isPotting() {
        return potting;
    }
}

