/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.input.Mouse
 */
package cn.M1N3S3NS3.Module.Modules.Legit;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.KillAura;
import cn.M1N3S3NS3.Util.PlayerUtil;
import cn.M1N3S3NS3.Util.timer.TimeHelper;
import java.awt.Color;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class AutoClicker
extends Module {
    public TimeHelper time = new TimeHelper();
    private long nextDelay = 0L;
    long lastMSInventory = -1L;
    public static Numbers<Double> cpsmin = new Numbers<Double>("CPSMin", "CPSMin", 8.0, 2.0, 20.0, 1.0);
    public static Numbers<Double> cpsmax = new Numbers<Double>("CPSMax", "CPSMax", 8.0, 2.0, 20.0, 1.0);
    protected Random r = new Random();
    protected long lastMS = -1L;
    public Option<Boolean> ab = new Option<Boolean>("BlockHit", "BlockHit", true);
    public Option<Boolean> BreakBlock = new Option<Boolean>("BreakBlock", "BreakBlock", true);
    public Option<Boolean> InvClicker = new Option<Boolean>("Inventory", "Inventory", false);
    public static int Click;
    public static boolean Clicked;
    private double delay = 0.0;
    private TimeHelper time2 = new TimeHelper();
    private TimeHelper time3 = new TimeHelper();

    public AutoClicker() {
        super("AutoClicker", new String[]{"AutoClicker"}, ModuleType.Ghost);
        this.setColor(new Color(208, 30, 142).getRGB());
        super.addValues(cpsmin, cpsmax, this.ab, this.InvClicker, this.BreakBlock);
    }

    private void delay() {
        float minCps = ((Double)cpsmin.getValue()).floatValue();
        float maxCps = ((Double)cpsmax.getValue()).floatValue();
        float minDelay = 1000.0f / minCps;
        float maxDelay = 1000.0f / maxCps;
        this.delay = (double)maxDelay + this.r.nextDouble() * (double)(minDelay - maxDelay);
    }

    @EventHandler
    private void onUpdate(EventPreUpdate event) {
        BlockPos bp = Minecraft.thePlayer.rayTrace(6.0, 0.0f).getBlockPos();
        boolean isblock = Minecraft.theWorld.getBlockState(bp).getBlock() != Blocks.air && AutoClicker.mc.objectMouseOver.typeOfHit != MovingObjectPosition.MovingObjectType.ENTITY;
        boolean bl = isblock;
        if (!((Boolean)this.BreakBlock.getValue()).booleanValue()) {
            isblock = false;
        }
        if (this.time2.delay(this.delay) && !this.time2.delay(this.delay + this.delay / 2.0)) {
            Clicked = true;
        }
        if (this.time2.delay(this.delay + this.delay - 1.0)) {
            Clicked = false;
            this.time2.reset();
        }
        Client.instance.getModuleManager();
        if (!ModuleManager.getModuleByClass(KillAura.class).isEnabled() && Mouse.isButtonDown((int)0) && this.time.delay(this.delay) && AutoClicker.mc.currentScreen == null && !isblock) {
            PlayerUtil.blockHit(AutoClicker.mc.objectMouseOver.entityHit, (Boolean)this.ab.getValue());
            AutoClicker.mc.leftClickCounter = 0;
            mc.clickMouse();
            this.delay();
            this.time.reset();
        }
    }

    @EventHandler
    private void invClicks(EventPreUpdate event) {
        if (!Keyboard.isKeyDown((int)42)) {
            return;
        }
        if (AutoClicker.mc.currentScreen instanceof GuiContainer && ((Boolean)this.InvClicker.getValue()).booleanValue()) {
            float invClickDelay = 1000.0f / ((Double)cpsmax.getValue()).floatValue() + (float)this.r.nextInt(50);
            if (Mouse.isButtonDown((int)0) && this.time3.delay(invClickDelay)) {
                try {
                    AutoClicker.mc.currentScreen.InventoryClicks();
                    this.time3.reset();
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
        }
    }
}

