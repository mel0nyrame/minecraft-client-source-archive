/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Legit;

import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import com.darkmagician6.eventapi.EventTarget;
import java.awt.Color;
import java.awt.Toolkit;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;

public class Reach
extends Module {
    private long lastAttack;
    private String rangeText;
    private Numbers<Double> X = new Numbers<Double>("RenderX", "RenderX", 5.0, 0.0, Toolkit.getDefaultToolkit().getScreenSize().getWidth(), 10.0);
    private Numbers<Double> Y = new Numbers<Double>("RenderY", "RenderY", 150.0, 0.0, Toolkit.getDefaultToolkit().getScreenSize().getHeight(), 10.0);
    private double reach = 3.9f;
    public static Numbers<Double> BuildingReach = new Numbers<Double>("BuildingReach", "BuildingReach", 4.0, 3.0, 8.0, 0.1);
    public static Option<Boolean> ReachRender = new Option<Boolean>("ReachRender", "ReachRender", false);
    public static Option<Boolean> RechDisplay = new Option<Boolean>("RechDisplay", "RechDisplay", false);
    public static Option<Boolean> Vertical = new Option<Boolean>("Vertical", "Vertical", false);
    public static Option<Boolean> OnlySprint = new Option<Boolean>("OnlySprint", "OnlySprint", false);
    public static Option<Boolean> GHOST = new Option<Boolean>("Ghost Test", "Ghost Test", false);

    public Reach() {
        super("Reach", new String[]{"Reach"}, ModuleType.Ghost);
        this.setColor(new Color(208, 30, 142).getRGB());
        super.addValues(this.X, this.Y, BuildingReach, Vertical, OnlySprint, GHOST);
    }

    @EventTarget
    public void onUpdate(EventPreUpdate event) {
        this.reach = ((Boolean)GHOST.getValue()).booleanValue() ? (Math.random() > (double)0.2f ? 4.4 : 3.9) : ((Number)BuildingReach.getValue()).doubleValue();
    }

    public static boolean canReach(EntityLivingBase e) {
        if (e == null) {
            return false;
        }
        if (((Boolean)Vertical.getValue()).booleanValue()) {
            if (Minecraft.thePlayer.posY > e.posY) {
                return false;
            }
        }
        if (((Boolean)OnlySprint.getValue()).booleanValue()) {
            if (!Minecraft.thePlayer.isSprinting()) {
                return false;
            }
        }
        return true;
    }
}

