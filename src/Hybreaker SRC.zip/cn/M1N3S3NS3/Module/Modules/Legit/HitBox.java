/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.Module.Modules.Legit;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Misc.MouseEvent;
import cn.M1N3S3NS3.API.Events.Render.EventRender3D;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Combat.AntiBot;
import cn.M1N3S3NS3.Module.Modules.Legit.Reach;
import cn.M1N3S3NS3.Module.Modules.Misc.Teams;
import java.awt.Color;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;

public class HitBox
extends Module {
    private static Entity pE;
    private static MovingObjectPosition mv;
    private final Option<Boolean> b = new Option<Boolean>("Show new Hitbox", "Show new Hitbox", true);
    public static final Numbers a;

    static {
        a = new Numbers<Double>("Multiplier", "Multiplier", 0.1, 0.1, 1.0, 0.01);
    }

    public HitBox() {
        super("HitBox", new String[]{"HitBox", "HitBox"}, ModuleType.Ghost);
        this.addValues(this.b, a);
    }

    @Override
    public void update() {
        HitBox.gmo(1.0f);
    }

    public static boolean e() {
        if (Minecraft.thePlayer != null) {
            if (Minecraft.theWorld != null) {
                return true;
            }
        }
        return false;
    }

    @EventHandler
    public void r1(EventRender3D e) {
        if (!((Boolean)this.b.getValue()).booleanValue() || !HitBox.e()) {
            return;
        }
        for (Entity en : Minecraft.theWorld.loadedEntityList) {
            if (en == Minecraft.thePlayer || !(en instanceof EntityLivingBase) || ((EntityLivingBase)en).deathTime != 0 || en instanceof EntityArmorStand || en.isInvisible()) continue;
            this.rh(en, Color.WHITE);
        }
    }

    public static double exp(Entity en) {
        if (!ModuleManager.getModuleByClass(HitBox.class).isEnabled() || AntiBot.isBot((EntityLivingBase)en)) {
            return 1.0;
        }
        return (Double)a.getValue();
    }

    public static void gmo(float partialTicks) {
        if (mc.getRenderViewEntity() != null) {
            if (Minecraft.theWorld != null) {
                HitBox.mc.pointedEntity = null;
                pE = null;
                double d0 = 3.0;
                mv = mc.getRenderViewEntity().rayTrace(d0, partialTicks);
                double d2 = d0;
                Vec3 vec3 = mc.getRenderViewEntity().getPositionEyes(partialTicks);
                if (mv != null) {
                    d2 = HitBox.mv.hitVec.distanceTo(vec3);
                }
                Vec3 vec4 = mc.getRenderViewEntity().getLook(partialTicks);
                Vec3 vec5 = vec3.addVector(vec4.xCoord * d0, vec4.yCoord * d0, vec4.zCoord * d0);
                Vec3 vec6 = null;
                float f1 = 1.0f;
                List<Entity> list = Minecraft.theWorld.getEntitiesWithinAABBExcludingEntity(mc.getRenderViewEntity(), mc.getRenderViewEntity().getEntityBoundingBox().addCoord(vec4.xCoord * d0, vec4.yCoord * d0, vec4.zCoord * d0).expand(f1, f1, f1));
                double d3 = d2;
                int i = 0;
                while (i < list.size()) {
                    Entity entity = list.get(i);
                    if (entity.canBeCollidedWith()) {
                        double d4;
                        float ex = (float)((double)entity.getCollisionBorderSize() * HitBox.exp(entity));
                        AxisAlignedBB ax2 = entity.getEntityBoundingBox().expand(ex, ex, ex);
                        MovingObjectPosition mop = ax2.calculateIntercept(vec3, vec5);
                        if (ax2.isVecInside(vec3)) {
                            if (0.0 < d3 || d3 == 0.0) {
                                pE = entity;
                                vec6 = mop == null ? vec3 : mop.hitVec;
                                d3 = 0.0;
                            }
                        } else if (mop != null && ((d4 = vec3.distanceTo(mop.hitVec)) < d3 || d3 == 0.0)) {
                            if (entity == HitBox.mc.getRenderViewEntity().ridingEntity) {
                                if (d3 == 0.0) {
                                    pE = entity;
                                    vec6 = mop.hitVec;
                                }
                            } else {
                                pE = entity;
                                vec6 = mop.hitVec;
                                d3 = d4;
                            }
                        }
                    }
                    ++i;
                }
                if (pE != null && (d3 < d2 || mv == null)) {
                    mv = new MovingObjectPosition(pE, vec6);
                    if (pE instanceof EntityLivingBase || pE instanceof EntityItemFrame) {
                        HitBox.mc.pointedEntity = pE;
                    }
                }
            }
        }
    }

    private void rh(Entity e, Color c) {
        if (e == null || !(e instanceof EntityLivingBase)) {
            return;
        }
        double d = e.lastTickPosX + (e.posX - e.lastTickPosX) * (double)Minecraft.getMinecraft().timer.renderPartialTicks;
        mc.getRenderManager();
        double x = d - RenderManager.viewerPosX;
        double d2 = e.lastTickPosY + (e.posY - e.lastTickPosY) * (double)Minecraft.getMinecraft().timer.renderPartialTicks;
        mc.getRenderManager();
        double y = d2 - RenderManager.viewerPosY;
        double d3 = e.lastTickPosZ + (e.posZ - e.lastTickPosZ) * (double)Minecraft.getMinecraft().timer.renderPartialTicks;
        mc.getRenderManager();
        double z = d3 - RenderManager.viewerPosZ;
        float ex = (float)((double)e.getCollisionBorderSize() * (Double)a.getValue());
        AxisAlignedBB bbox = e.getEntityBoundingBox().expand(ex, ex, ex);
        AxisAlignedBB axis = new AxisAlignedBB(bbox.minX - e.posX + x, bbox.minY - e.posY + y, bbox.minZ - e.posZ + z, bbox.maxX - e.posX + x, bbox.maxY - e.posY + y, bbox.maxZ - e.posZ + z);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glLineWidth((float)2.0f);
        GL11.glColor3d((double)c.getRed(), (double)c.getGreen(), (double)c.getBlue());
        RenderGlobal.drawSelectionBoundingBox(axis);
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
    }

    @EventHandler
    void onUpdate(MouseEvent e) {
        block6: {
            block5: {
                if (Teams.isOnSameTeam(pE)) {
                    return;
                }
                if (!HitBox.e()) break block5;
                Client.getModuleManager();
                if (!ModuleManager.getModuleByClass(Reach.class).isEnabled()) break block6;
            }
            return;
        }
        if (e.button == 0 && e.buttonstate && mv != null) {
            HitBox.mc.objectMouseOver = mv;
        }
    }
}

