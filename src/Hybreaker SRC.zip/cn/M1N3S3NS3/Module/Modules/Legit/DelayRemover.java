/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Legit;

import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.World.EventPreUpdate;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import java.lang.reflect.Field;
import net.minecraft.client.Minecraft;

public class DelayRemover
extends Module {
    private Field l = null;
    private final Option<Boolean> dance = new Option<Boolean>("Dance", "Dance", true);

    public DelayRemover() {
        super("DelayRemover", new String[]{"DelayRemover", "DelayRemover"}, ModuleType.Ghost);
    }

    @Override
    public void onEnable() {
        try {
            this.l = Minecraft.class.getDeclaredField(new String(new char[]{'f', 'i', 'e', 'l', 'd', '_', '7', '1', '4', '2', '9', '_', 'W'}));
        }
        catch (Exception er) {
            try {
                this.l = Minecraft.class.getDeclaredField(new String(new char[]{'l', 'e', 'f', 't', 'C', 'l', 'i', 'c', 'k', 'C', 'o', 'u', 'n', 't', 'e', 'r'}));
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        if (this.l != null) {
            this.l.setAccessible(true);
        } else {
            this.setEnabled(false);
        }
    }

    @EventHandler
    void onUpdate(EventPreUpdate event) {
        block5: {
            block7: {
                block6: {
                    if (Minecraft.thePlayer == null) break block5;
                    if (Minecraft.theWorld == null || this.l == null) break block5;
                    if (!DelayRemover.mc.inGameHasFocus) break block6;
                    if (!Minecraft.thePlayer.capabilities.isCreativeMode) break block7;
                }
                return;
            }
            try {
                this.l.set(mc, 0);
            }
            catch (IllegalAccessException illegalAccessException) {
            }
            catch (IndexOutOfBoundsException indexOutOfBoundsException) {
                // empty catch block
            }
        }
    }
}

