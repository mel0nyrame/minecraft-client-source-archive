/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Legit;

import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import java.awt.Color;

public class KeepSprint
extends Module {
    public KeepSprint() {
        super("KeepSprint", new String[]{"KeepSprint"}, ModuleType.Ghost);
        this.setColor(new Color(208, 30, 142).getRGB());
    }
}

