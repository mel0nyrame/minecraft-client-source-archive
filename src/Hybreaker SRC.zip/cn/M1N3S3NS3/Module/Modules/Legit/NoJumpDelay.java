/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.Modules.Legit;

import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;

public class NoJumpDelay
extends Module {
    private boolean down;

    public NoJumpDelay() {
        super("NoJumpDelay", new String[]{"NoJumpDelay", "NoJumpDelay"}, ModuleType.Ghost);
    }

    @Override
    public void onEnable() {
    }
}

