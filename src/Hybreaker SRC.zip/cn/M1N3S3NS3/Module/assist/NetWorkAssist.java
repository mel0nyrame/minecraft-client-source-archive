/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.assist;

import cn.M1N3S3NS3.API.EventBus;
import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.API.Events.World.EventPacketReceive;
import cn.M1N3S3NS3.API.Events.World.EventPacketSend;
import cn.M1N3S3NS3.API.Events.World.EventPostUpdate;
import cn.M1N3S3NS3.Util.timer.TimerUtil;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;

public class NetWorkAssist {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private int inComing;
    private int outGoing;
    private final ArrayList<Integer> inComingList = new ArrayList();
    private final ArrayList<Integer> outGoingList = new ArrayList();
    private final TimerUtil timer = new TimerUtil();
    private final TimerUtil lag = new TimerUtil();

    public void init() {
        EventBus.getInstance().register(this);
        this.resetStuff();
    }

    private void resetStuff() {
        this.inComing = 0;
        this.outGoing = 0;
        this.inComingList.clear();
        this.outGoingList.clear();
        this.timer.reset();
    }

    @EventHandler
    void onUpdate(EventPostUpdate event) {
        if (this.timer.hasReached(700.0)) {
            this.inComingList.add(this.inComing);
            this.inComing = 0;
            this.outGoingList.add(this.outGoing);
            this.outGoing = 0;
            this.timer.reset();
        }
    }

    @EventHandler
    void onPacket(EventPacketSend event) {
        ++this.outGoing;
    }

    @EventHandler
    void onOverlay(EventRender2D event) {
    }

    @EventHandler
    void onPacket(EventPacketReceive event) {
        ++this.inComing;
    }

    public ArrayList<Integer> getInComingList() {
        return this.inComingList;
    }

    public ArrayList<Integer> getOutGoingList() {
        return this.outGoingList;
    }

    public boolean isLagging() {
        return this.inComingList.get(this.inComingList.size() - 1) == 0;
    }
}

