/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module.assist;

import cn.M1N3S3NS3.API.EventBus;
import cn.M1N3S3NS3.API.EventHandler;
import cn.M1N3S3NS3.API.Events.Render.EventRender2D;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Modules.Move.Scaffold;
import cn.M1N3S3NS3.Util.Render.TranslateUtil;
import cn.M1N3S3NS3.font.cfont.CFontRenderer;

public class ScaffoldAssist {
    private Scaffold scaffold;
    private TranslateUtil translate;
    private TranslateUtil position;

    public void init() {
        EventBus.getInstance().register(this);
        this.scaffold = new Scaffold();
        this.translate = new TranslateUtil(0.0f, 0.0f);
        this.position = new TranslateUtil(0.0f, 0.0f);
    }

    @EventHandler
    void onOverlay(EventRender2D event) {
        Client.getModuleManager();
        if (ModuleManager.getModuleByClass(Scaffold.class).isEnabled()) {
            Client.instance.getModuleManager();
            this.translate.interpolate(ModuleManager.getModuleByClass(Scaffold.class).isEnabled() ? 255 : 0, 0.0f, 0.3f);
            Client.instance.getModuleManager();
            this.position.interpolate(0.0f, ModuleManager.getModuleByClass(Scaffold.class).isEnabled() ? 80 : 60, 0.01f);
            CFontRenderer cFontRenderer = Client.instance.getFontManager().arial18;
        }
    }
}

