/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.Module;

public enum ModuleType {
    Combat,
    Render,
    Move,
    Player,
    Ghost;

}

