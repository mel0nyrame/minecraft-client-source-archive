/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package cn.M1N3S3NS3.Module;

import cn.M1N3S3NS3.API.EventBus;
import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Manager.FileManager;
import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module$1;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Render.HUD;
import cn.M1N3S3NS3.UI.notification.Notification;
import cn.M1N3S3NS3.Util.Color.ColorUtil;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.input.Keyboard;

public class Module {
    public String name;
    private float animationX;
    private float animationY;
    private String suffix;
    private int color;
    private String[] alias;
    private boolean enabled;
    private boolean render = false;
    private boolean wasLower;
    public boolean enabledOnStartup = false;
    public int key;
    public int anim;
    public int clickanim;
    final ArrayList<Value<?>> values = new ArrayList();
    public static int EnabledCount = 0;
    public ModuleType type;
    private boolean removed;
    private String cusname;
    public static Minecraft mc = Minecraft.getMinecraft();
    public static Random random = new Random();
    private int curX;
    public boolean init;
    private final int randomColor;
    HUD hud;

    public Module(String name, String[] alias, ModuleType type) {
        Client.instance.getModuleManager();
        this.hud = (HUD)ModuleManager.getModuleByClass(HUD.class);
        this.name = name;
        this.alias = alias;
        this.type = type;
        this.suffix = "";
        this.key = 0;
        this.removed = false;
        this.enabled = false;
        this.cusname = null;
        this.render = false;
        this.wasLower = false;
        this.curX = -1;
        this.init = false;
        this.randomColor = ColorUtil.getRandomColor().getRGB();
    }

    public String getName() {
        if (this.wasLower) {
            return this.name.toLowerCase();
        }
        return this.name;
    }

    public String getCustomName() {
        return this.cusname;
    }

    public void setCustomName(String name) {
        this.cusname = name;
    }

    public String[] getAlias() {
        return this.alias;
    }

    public boolean wasToLower() {
        return this.wasLower;
    }

    public void setToLower(boolean toLower) {
        this.wasLower = toLower;
    }

    public ModuleType getType() {
        return this.type;
    }

    public void setRender(boolean b) {
        this.render = b;
    }

    public boolean getRender() {
        return this.render;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public float getAnimationX() {
        return this.animationX;
    }

    public float getAnimationY() {
        return this.animationY;
    }

    public void setAnimationX(float animationX) {
        this.animationX = animationX;
    }

    public void setAnimationY(float animationY) {
        this.animationY = animationY;
    }

    public boolean wasRemoved() {
        return this.removed;
    }

    public void setRemoved(boolean removed) {
        this.removed = removed;
    }

    public String getSuffix() {
        return this.suffix;
    }

    public void setSuffix(Object obj) {
        String suffix = obj.toString();
        if (HUD.Tags.getValue() == HUD.TagMode.Box) {
            String string = this.suffix = suffix.isEmpty() ? suffix : String.format("%s", (Object)((Object)EnumChatFormatting.GRAY) + "[" + suffix + "]");
        }
        if (HUD.Tags.getValue() == HUD.TagMode.None) {
            String string = this.suffix = suffix.isEmpty() ? suffix : String.format("%s", (Object)((Object)EnumChatFormatting.GRAY) + "(" + suffix + ")");
        }
        if (HUD.Tags.getValue() == HUD.TagMode.Null) {
            String string = this.suffix = suffix.isEmpty() ? suffix : String.format("%s", (Object)((Object)EnumChatFormatting.GRAY) + suffix);
        }
        if (HUD.Tags.getValue() == HUD.TagMode.Hyphen) {
            this.suffix = suffix.isEmpty() ? suffix : String.format("%s", (Object)((Object)EnumChatFormatting.GRAY) + "- " + suffix);
        }
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if (enabled) {
            ++EnabledCount;
            this.onEnable();
            this.setRender(true);
            if (((Boolean)HUD.enableNotifications.getValue()).booleanValue()) {
                Client.instance.getNotificationManager().getNotifications().add(new Notification(String.valueOf(this.name) + " was Enabled"));
            }
            if (ModuleManager.loaded && Minecraft.theWorld != null && !Objects.equals(this.getName(), "ClickGui")) {
                Minecraft.thePlayer.playSound("random.click", 0.2f, this.enabled ? 0.6f : 0.5f);
            }
            EventBus.getInstance().register(this);
        } else {
            if (ModuleManager.loaded && Minecraft.theWorld != null && !Objects.equals(this.getName(), "ClickGui")) {
                Minecraft.thePlayer.playSound("random.click", 0.2f, this.enabled ? 0.6f : 0.5f);
            }
            if (((Boolean)HUD.enableNotifications.getValue()).booleanValue()) {
                Client.instance.getNotificationManager().getNotifications().add(new Notification(String.valueOf(this.name) + " was Disabled"));
            }
            EventBus.getInstance().unregister(this);
            this.onDisable();
        }
    }

    public void setColor(int color) {
        this.color = color;
    }

    public int getColor() {
        return this.color;
    }

    public void addValues(Value ... values) {
        Value[] var5 = values;
        int var4 = values.length;
        int var3 = 0;
        while (var3 < var4) {
            Value value = var5[var3];
            this.values.add(value);
            ++var3;
        }
    }

    public ArrayList<Value<?>> getValues() {
        return this.values;
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
        String content = "";
        for (Module m : ModuleManager.getModules()) {
            content = String.valueOf(content) + String.format("%s:%s%s", m.getName(), Keyboard.getKeyName((int)m.getKey()), System.lineSeparator());
        }
        FileManager.save("Binds.txt", content, false);
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    /*
     * Unable to fully structure code
     */
    public void makeCommand() {
        if (this.values.size() > 0) {
            options = "";
            other = "";
            for (Value<?> v : this.values) {
                if (v instanceof Mode) continue;
                options = options.isEmpty() != false ? String.valueOf(String.valueOf(options)) + v.getName() : String.valueOf(String.valueOf(options)) + String.format(", %s", new Object[]{v.getName()});
            }
            var4 = this.values.iterator();
            block1: while (true) {
                if (!var4.hasNext()) {
                    Client.instance.getCommandManager().add(new Module$1(this, this.name, this.alias, String.format("%s%s", new Object[]{options.isEmpty() != false ? "" : String.format("%s,", new Object[]{options}), other.isEmpty() != false ? "" : String.format("%s", new Object[]{other})}), "Setup this module"));
                    return;
                }
                v = var4.next();
                if (!(v instanceof Mode)) continue;
                mode = (Mode)v;
                modes = mode.getModes();
                length = modes.length;
                i = 0;
                while (true) {
                    if (i < length) ** break;
                    continue block1;
                    e = modes[i];
                    other = other.isEmpty() != false ? String.valueOf(String.valueOf(other)) + e.name().toLowerCase() : String.valueOf(String.valueOf(other)) + String.format(", %s", new Object[]{e.name().toLowerCase()});
                    ++i;
                }
                break;
            }
        }
    }

    public void update() {
    }

    public void guiUpdate() {
    }

    public int getRandomColor() {
        return this.randomColor;
    }

    public void toggle() {
        this.setEnabled(!this.isEnabled());
    }

    public void setX(int X) {
        this.curX = X;
    }

    public int getX() {
        return this.curX;
    }
}

