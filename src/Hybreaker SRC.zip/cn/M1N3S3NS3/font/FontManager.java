/*
 * Decompiled with CFR 0.151.
 */
package cn.M1N3S3NS3.font;

import cn.M1N3S3NS3.font.cfont.CFontRenderer;
import java.awt.Font;
import java.io.InputStream;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

public class FontManager {
    public CFontRenderer Tahoma10 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Tahoma.ttf", 10), true, true);
    public CFontRenderer arial12 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 12), true, true);
    public CFontRenderer arial14 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 14), true, true);
    public CFontRenderer arial16 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 16), true, true);
    public CFontRenderer arial17 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 17), true, true);
    public CFontRenderer arial18 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 18), true, true);
    public CFontRenderer arial20 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 20), true, true);
    public CFontRenderer arial22 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 22), true, true);
    public CFontRenderer arial24 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 24), true, true);
    public CFontRenderer arial26 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 26), true, true);
    public CFontRenderer arial28 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 28), true, true);
    public CFontRenderer logo32 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/logo.ttf", 32), true, true);
    public CFontRenderer arial32 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 32), true, true);
    public CFontRenderer arial40 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 40), true, true);
    public CFontRenderer arial42 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 42), true, true);
    public CFontRenderer logo24 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/other.ttf", 24), true, true);
    public CFontRenderer logo16 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/other.ttf", 12), true, true);
    public CFontRenderer logo18 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/other.ttf", 18), true, true);
    public CFontRenderer logo17 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/other.ttf", 17), true, true);
    public CFontRenderer logo10 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/other.ttf", 10), true, true);
    public CFontRenderer logo11 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/other.ttf", 11), true, true);
    public CFontRenderer logo13 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/other.ttf", 13), true, true);
    public static CFontRenderer splash40 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 40), true, true);
    public static CFontRenderer splash18 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Hud.ttf", 18), true, true);
    public CFontRenderer Tahoma16 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Tahoma.ttf", 16), true, true);
    public CFontRenderer Tahoma14 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Tahoma.ttf", 14), true, true);
    public CFontRenderer Tahoma18 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Tahoma.ttf", 18), true, true);
    public CFontRenderer Tahoma17 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/Tahoma.ttf", 17), true, true);
    public CFontRenderer moon18 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/moonfont.ttf", 18), true, true);
    public CFontRenderer moon17 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/moonfont.ttf", 17), true, true);
    public CFontRenderer SF18 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/roboto.ttf", 18), true, true);
    public CFontRenderer SF17 = new CFontRenderer(FontManager.getFont("ZenithAssets/FONT/roboto.ttf", 17), true, true);

    private static Font getFontOTF(String name, int size) {
        Font font;
        try {
            InputStream is = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation(name)).getInputStream();
            font = Font.createFont(0, is);
            font = font.deriveFont(0, size);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        return font;
    }

    private static Font getFont(String location, int size) {
        Font font;
        try {
            InputStream is = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation(location)).getInputStream();
            font = Font.createFont(0, is);
            font = font.deriveFont(0, size);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        return font;
    }
}

