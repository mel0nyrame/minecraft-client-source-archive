/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package cn.M1N3S3NS3.particle;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

public class Render3DUtil {
    private static final Frustum frustrum = new Frustum();

    public static double interpolate(double current, double old, double scale) {
        return old + (current - old) * scale;
    }

    public static boolean isInViewFrustrum(Entity entity) {
        return Render3DUtil.isInViewFrustrum(entity.getEntityBoundingBox()) || entity.ignoreFrustumCheck;
    }

    private static boolean isInViewFrustrum(AxisAlignedBB bb) {
        Entity current = Minecraft.getMinecraft().getRenderViewEntity();
        frustrum.setPosition(current.posX, current.posY, current.posZ);
        return frustrum.isBoundingBoxInFrustum(bb);
    }

    public static void drawBoundingBox(AxisAlignedBB axisalignedbb) {
        GL11.glBegin((int)7);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.minY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.maxY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.minY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.maxY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.minY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.maxY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.minY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.maxY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.maxY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.minY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.maxY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.minY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.maxY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.minY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.maxY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.minY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.maxY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.maxY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.maxY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.maxY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.maxY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.maxY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.maxY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.maxY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.minY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.minY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.minY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.minY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.minY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.minY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.minY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.minY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.minY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.maxY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.minY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.maxY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.minY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.maxY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.minY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.maxY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.maxY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.minY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.maxY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.minX, (double)axisalignedbb.minY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.maxY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.minY, (double)axisalignedbb.minZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.maxY, (double)axisalignedbb.maxZ);
        GL11.glVertex3d((double)axisalignedbb.maxX, (double)axisalignedbb.minY, (double)axisalignedbb.maxZ);
        GL11.glEnd();
    }
}

