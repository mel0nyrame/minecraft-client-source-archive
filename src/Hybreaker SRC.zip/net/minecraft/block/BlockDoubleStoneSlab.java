/*
 * Decompiled with CFR 0.151.
 */
package net.minecraft.block;

import net.minecraft.block.BlockStoneSlab;

public class BlockDoubleStoneSlab
extends BlockStoneSlab {
    @Override
    public boolean isDouble() {
        return true;
    }
}

