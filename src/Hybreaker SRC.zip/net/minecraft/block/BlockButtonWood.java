/*
 * Decompiled with CFR 0.151.
 */
package net.minecraft.block;

import net.minecraft.block.BlockButton;

public class BlockButtonWood
extends BlockButton {
    protected BlockButtonWood() {
        super(true);
    }
}

