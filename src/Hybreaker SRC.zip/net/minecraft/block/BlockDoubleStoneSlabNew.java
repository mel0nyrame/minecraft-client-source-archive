/*
 * Decompiled with CFR 0.151.
 */
package net.minecraft.block;

import net.minecraft.block.BlockStoneSlabNew;

public class BlockDoubleStoneSlabNew
extends BlockStoneSlabNew {
    @Override
    public boolean isDouble() {
        return true;
    }
}

