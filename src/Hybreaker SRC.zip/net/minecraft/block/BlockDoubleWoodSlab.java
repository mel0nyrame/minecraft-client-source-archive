/*
 * Decompiled with CFR 0.151.
 */
package net.minecraft.block;

import net.minecraft.block.BlockWoodSlab;

public class BlockDoubleWoodSlab
extends BlockWoodSlab {
    @Override
    public boolean isDouble() {
        return true;
    }
}

