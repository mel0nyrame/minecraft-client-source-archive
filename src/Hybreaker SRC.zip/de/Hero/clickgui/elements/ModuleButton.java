/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package de.Hero.clickgui.elements;

import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.API.Value.Value;
import cn.M1N3S3NS3.Client;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Util.Chat.Helper;
import de.Hero.clickgui.Panel;
import de.Hero.clickgui.elements.Element;
import de.Hero.clickgui.elements.menu.ElementCheckBox;
import de.Hero.clickgui.elements.menu.ElementComboBox;
import de.Hero.clickgui.elements.menu.ElementSlider;
import de.Hero.clickgui.util.ColorUtil;
import de.Hero.clickgui.util.FontUtil;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class ModuleButton {
    public Module mod;
    public ArrayList<Element> menuelements;
    public Panel parent;
    public double x;
    public double y;
    public double width;
    public double height;
    public boolean extended = false;
    public boolean listening = false;

    public ModuleButton(Module imod, Panel pl) {
        this.mod = imod;
        this.height = 16.0;
        this.parent = pl;
        this.menuelements = new ArrayList();
        if (imod.getValues().size() != 0) {
            for (Value<?> s : imod.getValues()) {
                if (s instanceof Option) {
                    this.menuelements.add(new ElementCheckBox(this, (Option)s));
                    continue;
                }
                if (s instanceof Numbers) {
                    this.menuelements.add(new ElementSlider(this, (Numbers)s));
                    continue;
                }
                if (!(s instanceof Mode)) continue;
                this.menuelements.add(new ElementComboBox(this, (Mode)s));
            }
        }
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        int textcolor;
        Color temp = ColorUtil.getClickGUIColor();
        int color = new Color(temp.getRed(), temp.getGreen(), temp.getBlue()).getRGB();
        int n = textcolor = this.mod.isEnabled() ? color : new Color(255, 255, 255).getRGB();
        if (this.isHovered(mouseX, mouseY)) {
            textcolor = new Color(136, 136, 136).getRGB();
        }
        FontUtil.drawString(this.mod.getName(), this.x + 1.0, this.y + 4.0, textcolor);
    }

    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (!this.isHovered(mouseX, mouseY)) {
            return false;
        }
        if (mouseButton == 0) {
            this.mod.setEnabled(!this.mod.isEnabled());
            Minecraft.getMinecraft();
            Minecraft.thePlayer.playSound("random.click", 0.5f, 0.5f);
        } else if (mouseButton == 1) {
            if (this.menuelements != null && this.menuelements.size() > 0) {
                boolean b = !this.extended;
                Client.instance.clickgui.closeAllSettings();
                this.extended = b;
                if (this.extended) {
                    Minecraft.getMinecraft();
                    Minecraft.thePlayer.playSound("tile.piston.out", 1.0f, 1.0f);
                } else {
                    Minecraft.getMinecraft();
                    Minecraft.thePlayer.playSound("tile.piston.in", 1.0f, 1.0f);
                }
            }
        } else if (mouseButton == 2) {
            this.listening = true;
        }
        return true;
    }

    public boolean keyTyped(char typedChar, int keyCode) throws IOException {
        if (this.listening) {
            if (keyCode != 1) {
                Helper.sendMessage("Bound '" + this.mod.getName() + "'" + " to '" + Keyboard.getKeyName((int)keyCode) + "'");
                this.mod.setKey(keyCode);
            } else {
                Helper.sendMessage("Unbound '" + this.mod.getName() + "'");
                this.mod.setKey(0);
            }
            this.listening = false;
            return true;
        }
        return false;
    }

    public boolean isHovered(int mouseX, int mouseY) {
        return (double)mouseX >= this.x && (double)mouseX <= this.x + this.width && (double)mouseY >= this.y && (double)mouseY <= this.y + this.height;
    }
}

