/*
 * Decompiled with CFR 0.151.
 */
package de.Hero.clickgui.elements.menu;

import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import de.Hero.clickgui.elements.Element;
import de.Hero.clickgui.elements.ModuleButton;
import de.Hero.clickgui.util.ColorUtil;
import de.Hero.clickgui.util.FontUtil;
import java.awt.Color;
import net.minecraft.client.gui.Gui;

public class ElementCheckBox
extends Element {
    public ElementCheckBox(ModuleButton iparent, Option iset) {
        this.parent = iparent;
        this.set = iset;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        Color temp = ColorUtil.getClickGUIColor();
        int color = new Color(temp.getRed(), temp.getGreen(), temp.getBlue(), 200).getRGB();
        Gui.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, -15066598);
        FontLoaders.Comfortaa16.drawString(this.setstrg, (float)this.x + 15.0f, (float)(this.y + (double)(FontUtil.getFontHeight() / 2) + 1.0), -1);
        Gui.drawRect(this.x + 1.0, this.y + 2.0, this.x + 12.0, this.y + 13.0, (Boolean)this.set.getValue() != false ? color : -16777216);
        if (this.isCheckHovered(mouseX, mouseY)) {
            Gui.drawRect(this.x + 1.0, this.y + 2.0, this.x + 12.0, this.y + 13.0, 0x55111111);
        }
    }

    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0 && this.isCheckHovered(mouseX, mouseY)) {
            this.set.setValue((Boolean)this.set.getValue() == false);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    public boolean isCheckHovered(int mouseX, int mouseY) {
        return (double)mouseX >= this.x + 1.0 && (double)mouseX <= this.x + 12.0 && (double)mouseY >= this.y + 2.0 && (double)mouseY <= this.y + 13.0;
    }
}

