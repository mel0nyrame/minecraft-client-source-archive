/*
 * Decompiled with CFR 0.151.
 */
package de.Hero.clickgui.elements.menu;

import cn.M1N3S3NS3.API.Value.Mode;
import de.Hero.clickgui.elements.Element;
import de.Hero.clickgui.elements.ModuleButton;
import de.Hero.clickgui.util.ColorUtil;
import de.Hero.clickgui.util.FontUtil;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;

public class ElementComboBox
extends Element {
    public ElementComboBox(ModuleButton iparent, Mode iset) {
        this.parent = iparent;
        this.set = iset;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        Color temp = ColorUtil.getClickGUIColor();
        int color = new Color(temp.getRed(), temp.getGreen(), temp.getBlue(), 150).getRGB();
        Gui.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, -15066598);
        FontUtil.drawTotalCenteredString(this.setstrg, this.x + this.width / 2.0, this.y + 7.0, -1);
        int clr1 = color;
        int clr2 = temp.getRGB();
        Gui.drawRect(this.x, this.y + 14.0, this.x + this.width, this.y + 15.0, 0x77000000);
        if (this.comboextended) {
            Gui.drawRect(this.x, this.y + 15.0, this.x + this.width, this.y + this.height, -1441656302);
            double ay2 = this.y + 15.0;
            Enum[] enumArray = ((Mode)this.set).getModes();
            int n = enumArray.length;
            int n2 = 0;
            while (n2 < n) {
                Enum sld = enumArray[n2];
                String elementtitle = String.valueOf(sld.name().substring(0, 1).toUpperCase()) + sld.name().substring(1, sld.name().length());
                FontUtil.drawCenteredString(elementtitle, this.x + this.width / 2.0, ay2 + 2.0, -1);
                if (sld.name().equalsIgnoreCase(((Mode)this.set).getValue().toString())) {
                    Gui.drawRect(this.x, ay2, this.x + 1.5, ay2 + (double)FontUtil.getFontHeight() + 2.0, clr1);
                }
                if ((double)mouseX >= this.x && (double)mouseX <= this.x + this.width && (double)mouseY >= ay2 && (double)mouseY < ay2 + (double)FontUtil.getFontHeight() + 2.0) {
                    Gui.drawRect(this.x + this.width - 1.2, ay2, this.x + this.width, ay2 + (double)FontUtil.getFontHeight() + 2.0, clr2);
                }
                ay2 += (double)(FontUtil.getFontHeight() + 2);
                ++n2;
            }
        }
    }

    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0) {
            if (this.isButtonHovered(mouseX, mouseY)) {
                this.comboextended = !this.comboextended;
                return true;
            }
            if (!this.comboextended) {
                return false;
            }
            double ay2 = this.y + 15.0;
            Enum[] enumArray = ((Mode)this.set).getModes();
            int n = enumArray.length;
            int n2 = 0;
            while (n2 < n) {
                Enum slcd = enumArray[n2];
                if ((double)mouseX >= this.x && (double)mouseX <= this.x + this.width && (double)mouseY >= ay2 && (double)mouseY <= ay2 + (double)FontUtil.getFontHeight() + 2.0) {
                    Minecraft.getMinecraft();
                    Minecraft.thePlayer.playSound("tile.piston.in", 20.0f, 20.0f);
                    if (this.clickgui != null && this.set != null) {
                        ((Mode)this.set).setMode(slcd.name());
                    }
                    return true;
                }
                ay2 += (double)(FontUtil.getFontHeight() + 2);
                ++n2;
            }
        }
        return super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    public boolean isButtonHovered(int mouseX, int mouseY) {
        return (double)mouseX >= this.x && (double)mouseX <= this.x + this.width && (double)mouseY >= this.y && (double)mouseY <= this.y + 15.0;
    }
}

