/*
 * Decompiled with CFR 0.151.
 */
package de.Hero.clickgui.elements;

import cn.M1N3S3NS3.API.Value.Mode;
import cn.M1N3S3NS3.API.Value.Numbers;
import cn.M1N3S3NS3.API.Value.Option;
import cn.M1N3S3NS3.API.Value.Value;
import de.Hero.clickgui.ClickGUI;
import de.Hero.clickgui.elements.ModuleButton;
import de.Hero.clickgui.util.FontUtil;

public class Element {
    public ClickGUI clickgui;
    public ModuleButton parent;
    public Value set;
    public double offset;
    public double x;
    public double y;
    public double width;
    public double height;
    public String setstrg;
    public boolean comboextended;

    public void setup() {
        this.clickgui = this.parent.parent.clickgui;
    }

    public void update() {
        this.x = this.parent.x + this.parent.width + 2.0;
        this.y = this.parent.y + this.offset;
        this.width = this.parent.width + 10.0;
        this.height = 15.0;
        String sname = this.set.getName();
        if (this.set instanceof Option) {
            this.setstrg = String.valueOf(sname.substring(0, 1).toUpperCase()) + sname.substring(1, sname.length());
            double textx = this.x + this.width - (double)FontUtil.getStringWidth(this.setstrg);
            if (textx < this.x + 13.0) {
                this.width += this.x + 13.0 - textx + 1.0;
            }
        } else if (this.set instanceof Mode) {
            this.height = this.comboextended ? ((Mode)this.set).getModes().length * (FontUtil.getFontHeight() + 2) + 15 : 15;
            this.setstrg = String.valueOf(sname.substring(0, 1).toUpperCase()) + sname.substring(1, sname.length());
            int longest = FontUtil.getStringWidth(this.setstrg);
            Enum[] enumArray = ((Mode)this.set).getModes();
            int n = enumArray.length;
            int n2 = 0;
            while (n2 < n) {
                Enum s = enumArray[n2];
                int temp = FontUtil.getStringWidth(s.name());
                if (temp > longest) {
                    longest = temp;
                }
                ++n2;
            }
            double textx = this.x + this.width - (double)longest;
            if (textx < this.x) {
                this.width += this.x - textx + 1.0;
            }
        } else if (this.set instanceof Numbers) {
            this.setstrg = String.valueOf(sname.substring(0, 1).toUpperCase()) + sname.substring(1, sname.length());
            String displayval = "" + (double)Math.round((Double)this.set.getValue() * 100.0) / 100.0;
            String displaymax = "" + (double)Math.round(((Number)((Numbers)this.set).getMaximum()).doubleValue() * 100.0) / 100.0;
            double textx = this.x + this.width - (double)FontUtil.getStringWidth(this.setstrg) - (double)FontUtil.getStringWidth(displaymax) - 4.0;
            if (textx < this.x) {
                this.width += this.x - textx + 1.0;
            }
        }
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
    }

    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        return this.isHovered(mouseX, mouseY);
    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
    }

    public boolean isHovered(int mouseX, int mouseY) {
        return (double)mouseX >= this.x && (double)mouseX <= this.x + this.width && (double)mouseY >= this.y && (double)mouseY <= this.y + this.height;
    }
}

