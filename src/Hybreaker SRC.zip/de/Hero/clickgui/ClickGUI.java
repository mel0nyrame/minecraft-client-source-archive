/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.opengl.GL11
 */
package de.Hero.clickgui;

import cn.M1N3S3NS3.Manager.ModuleManager;
import cn.M1N3S3NS3.Module.Module;
import cn.M1N3S3NS3.Module.ModuleType;
import cn.M1N3S3NS3.Module.Modules.Render.ClickGui;
import de.Hero.clickgui.Panel;
import de.Hero.clickgui.elements.Element;
import de.Hero.clickgui.elements.ModuleButton;
import de.Hero.clickgui.elements.menu.ElementSlider;
import de.Hero.clickgui.util.AnimationUtil;
import de.Hero.clickgui.util.ColorUtil;
import de.Hero.clickgui.util.FontUtil;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class ClickGUI
extends GuiScreen {
    public static ArrayList<Panel> panels;
    public static ArrayList<Panel> rpanels;
    private ModuleButton mb = null;
    public float anim = 75.0f;

    public ClickGUI() {
        FontUtil.setupFontUtils();
        panels = new ArrayList();
        double pwidth = 100.0;
        double pheight = 15.0;
        double px = 10.0;
        double py = 10.0;
        double pxplus = pwidth + 10.0;
        ModuleType[] moduleTypeArray = ModuleType.values();
        int n = moduleTypeArray.length;
        int n2 = 0;
        while (n2 < n) {
            final ModuleType c = moduleTypeArray[n2];
            String title = String.valueOf(Character.toUpperCase(c.name().toLowerCase().charAt(0))) + c.name().toLowerCase().substring(1);
            panels.add(new Panel(title, px, py, pwidth, pheight, false, this){

                @Override
                public void setup() {
                    for (Module m : ModuleManager.modules) {
                        if (!m.getType().equals((Object)c)) continue;
                        this.Elements.add(new ModuleButton(m, this));
                    }
                }
            });
            px += pxplus;
            ++n2;
        }
        rpanels = new ArrayList();
        for (Panel p : panels) {
            rpanels.add(p);
        }
        Collections.reverse(rpanels);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.anim = AnimationUtil.moveUD(this.anim, 0.0f, 0.09f, 0.04f);
        GlStateManager.rotate(this.anim, 0.0f, 0.0f, 0.0f);
        GL11.glDisable((int)2929);
        for (Panel p : panels) {
            p.drawScreen(mouseX, mouseY, partialTicks);
        }
        ScaledResolution s = new ScaledResolution(this.mc);
        this.mb = null;
        block1: for (Panel p : panels) {
            if (p == null || !p.visible || !p.extended || p.Elements == null || p.Elements.size() <= 0) continue;
            for (ModuleButton e : p.Elements) {
                if (!e.listening) continue;
                this.mb = e;
                break block1;
            }
        }
        for (Panel panel : panels) {
            if (!panel.extended || !panel.visible || panel.Elements == null) continue;
            for (ModuleButton b : panel.Elements) {
                if (!b.extended || b.menuelements == null || b.menuelements.isEmpty()) continue;
                double off = 0.0;
                Color temp = ColorUtil.getClickGUIColor().darker();
                int outlineColor = new Color(temp.getRed(), temp.getGreen(), temp.getBlue(), 170).getRGB();
                for (Element e : b.menuelements) {
                    e.offset = off;
                    e.update();
                    e.drawScreen(mouseX, mouseY, partialTicks);
                    off += e.height;
                }
            }
        }
        if (this.mb != null) {
            ClickGUI.drawRect(0, 0, this.width, this.height, -2012213232);
            GL11.glPushMatrix();
            GL11.glTranslatef((float)(ScaledResolution.getScaledWidth() / 2), (float)(ScaledResolution.getScaledHeight() / 2), (float)0.0f);
            GL11.glScalef((float)4.0f, (float)4.0f, (float)0.0f);
            FontUtil.drawTotalCenteredStringWithShadow("Listening...", 0.0, -10.0, -1);
            GL11.glScalef((float)0.5f, (float)0.5f, (float)0.0f);
            FontUtil.drawTotalCenteredStringWithShadow("Press 'ESCAPE' to unbind " + this.mb.mod.getName() + (this.mb.mod.getKey() > -1 ? " (" + Keyboard.getKeyName((int)this.mb.mod.getKey()) + ")" : ""), 0.0, 0.0, -1);
            GL11.glPopMatrix();
        }
        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (this.mb != null) {
            return;
        }
        for (Panel panel : rpanels) {
            if (!panel.extended || !panel.visible || panel.Elements == null) continue;
            for (ModuleButton b : panel.Elements) {
                if (!b.extended) continue;
                for (Element e : b.menuelements) {
                    if (!e.mouseClicked(mouseX, mouseY, mouseButton)) continue;
                    return;
                }
            }
        }
        for (Panel p : rpanels) {
            if (!p.mouseClicked(mouseX, mouseY, mouseButton)) continue;
            return;
        }
        try {
            super.mouseClicked(mouseX, mouseY, mouseButton);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        if (this.mb != null) {
            return;
        }
        for (Panel panel : rpanels) {
            if (!panel.extended || !panel.visible || panel.Elements == null) continue;
            for (ModuleButton b : panel.Elements) {
                if (!b.extended) continue;
                for (Element e : b.menuelements) {
                    e.mouseReleased(mouseX, mouseY, state);
                }
            }
        }
        for (Panel p : rpanels) {
            p.mouseReleased(mouseX, mouseY, state);
        }
        super.mouseReleased(mouseX, mouseY, state);
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) {
        for (Panel p : rpanels) {
            if (p == null || !p.visible || !p.extended || p.Elements == null || p.Elements.size() <= 0) continue;
            for (ModuleButton e : p.Elements) {
                try {
                    if (!e.keyTyped(typedChar, keyCode)) continue;
                    return;
                }
                catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        }
        try {
            super.keyTyped(typedChar, keyCode);
        }
        catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    @Override
    public void initGui() {
        if (ClickGui.panels != null && ClickGui.rpanels != null) {
            panels = ClickGui.panels;
            rpanels = ClickGui.rpanels;
        }
        if (OpenGlHelper.shadersSupported && Minecraft.thePlayer instanceof EntityPlayer) {
            if (this.mc.entityRenderer.theShaderGroup != null) {
                this.mc.entityRenderer.theShaderGroup.deleteShaderGroup();
            }
            this.mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
        }
    }

    @Override
    public void onGuiClosed() {
        ClickGui.panels = panels;
        ClickGui.rpanels = rpanels;
        if (this.mc.entityRenderer.theShaderGroup != null) {
            this.mc.entityRenderer.theShaderGroup.deleteShaderGroup();
            this.mc.entityRenderer.theShaderGroup = null;
        }
        for (Panel panel : rpanels) {
            if (!panel.extended || !panel.visible || panel.Elements == null) continue;
            for (ModuleButton b : panel.Elements) {
                if (!b.extended) continue;
                for (Element e : b.menuelements) {
                    if (!(e instanceof ElementSlider)) continue;
                    ((ElementSlider)e).dragging = false;
                }
            }
        }
    }

    public void closeAllSettings() {
        for (Panel p : rpanels) {
            if (p == null || !p.visible || !p.extended || p.Elements == null || p.Elements.size() <= 0) continue;
            for (ModuleButton moduleButton : p.Elements) {
            }
        }
    }
}

