/*
 * Decompiled with CFR 0.151.
 */
package de.Hero.clickgui.util;

import java.awt.Color;

public class ColorUtil {
    public static Color getClickGUIColor() {
        return new Color(63, 136, 255);
    }
}

