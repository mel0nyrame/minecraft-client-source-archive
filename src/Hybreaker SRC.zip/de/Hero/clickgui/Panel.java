/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package de.Hero.clickgui;

import cn.M1N3S3NS3.UI.Astolfo.Button;
import cn.M1N3S3NS3.UI.Font.FontLoaders;
import de.Hero.clickgui.ClickGUI;
import de.Hero.clickgui.elements.ModuleButton;
import de.Hero.clickgui.util.ColorUtil;
import java.awt.Color;
import java.util.ArrayList;
import net.minecraft.client.gui.Gui;
import org.lwjgl.opengl.GL11;

public class Panel {
    public String title;
    public double x;
    public double y;
    private double x2;
    private double y2;
    public double width;
    public double height;
    public boolean dragging;
    public boolean extended;
    public boolean visible;
    public int expand;
    public ArrayList<ModuleButton> Elements = new ArrayList();
    public ClickGUI clickgui;

    public Panel(String ititle, double ix, double iy, double iwidth, double iheight, boolean iextended, ClickGUI parent) {
        this.title = ititle;
        this.x = ix;
        this.y = iy;
        this.width = iwidth;
        this.height = iheight;
        this.extended = iextended;
        this.dragging = false;
        this.visible = true;
        this.clickgui = parent;
        this.setup();
    }

    public void setup() {
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        if (!this.visible) {
            return;
        }
        if (this.dragging) {
            this.x = this.x2 + (double)mouseX;
            this.y = this.y2 + (double)mouseY;
        }
        Color temp = ColorUtil.getClickGUIColor().darker();
        int outlineColor = new Color(temp.getRed(), temp.getGreen(), temp.getBlue(), 170).getRGB();
        int height2 = (int)((double)(this.Elements.size() + 2) * this.height);
        this.expand = this.extended ? (this.expand + 5 < height2 ? (this.expand = this.expand + 5) : height2) : 0;
        Gui.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, new Color(18, 18, 18).getRGB());
        FontLoaders.Comfortaa19.drawString(this.title.toUpperCase(), (float)(this.x + this.width / 2.0 - (double)(FontLoaders.Comfortaa19.getStringWidth(this.title.toUpperCase()) / 2)), (float)this.y + 5.0f, -1052689);
        GL11.glPushMatrix();
        GL11.glEnable((int)3089);
        Button.doGlScissor((int)this.x, (int)this.y, (int)this.width, this.expand);
        if (this.extended && !this.Elements.isEmpty()) {
            double startY = this.y + this.height;
            int epanelcolor = -1156246251;
            for (ModuleButton et : this.Elements) {
                Gui.drawRect(this.x, startY, this.x + this.width, startY + et.height, new Color(26, 26, 26).getRGB());
                et.x = this.x + 2.0;
                et.y = startY;
                et.width = this.width - 4.0;
                et.drawScreen(mouseX, mouseY, partialTicks);
                startY += et.height;
                if (et != this.Elements.get(this.Elements.size() - 2)) continue;
                Gui.drawRect(this.x, startY + et.height, this.x + this.width, startY + et.height + 1.0, ColorUtil.getClickGUIColor().getRGB());
            }
            Gui.drawRect(this.x, startY + 1.0, this.x + this.width, startY + 1.0, epanelcolor);
        }
        GL11.glDisable((int)3089);
        GL11.glPopMatrix();
    }

    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (!this.visible) {
            return false;
        }
        if (mouseButton == 0 && this.isHovered(mouseX, mouseY)) {
            this.x2 = this.x - (double)mouseX;
            this.y2 = this.y - (double)mouseY;
            this.dragging = true;
            return true;
        }
        if (mouseButton == 1 && this.isHovered(mouseX, mouseY)) {
            this.extended = !this.extended;
            return true;
        }
        if (this.extended) {
            for (ModuleButton et : this.Elements) {
                if (!et.mouseClicked(mouseX, mouseY, mouseButton)) continue;
                return true;
            }
        }
        return false;
    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
        if (!this.visible) {
            return;
        }
        if (state == 0) {
            this.dragging = false;
        }
    }

    public boolean isHovered(int mouseX, int mouseY) {
        return (double)mouseX >= this.x && (double)mouseX <= this.x + this.width && (double)mouseY >= this.y && (double)mouseY <= this.y + this.height;
    }
}

