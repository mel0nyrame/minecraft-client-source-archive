package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.UnicodeFont;
import org.newdawn.slick.font.effects.ColorEffect;

import java.awt.*;

public class UnicodeFontRenderer extends FontRenderer {
    private final UnicodeFont font;

    @SuppressWarnings("unchecked")
    public UnicodeFontRenderer(Font awtFont) {
        super(Minecraft.getMinecraft().gameSettings, new ResourceLocation("textures/font/ascii.png"), Minecraft.getMinecraft().getTextureManager(), false);
        font = new UnicodeFont(awtFont);
        font.addAsciiGlyphs();
        font.getEffects().add(new ColorEffect(Color.WHITE));

        try {
            font.loadGlyphs();
        } catch (SlickException exception) {
            throw new RuntimeException(exception);
        }

        String alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789";
        FONT_HEIGHT = font.getHeight(alphabet) / 2;
    }

    @Override
    public int drawString(String string, int x, int y, int color) {
        if (string == null) {
            return -1;
        }

        GL11.glPushMatrix();
        GL11.glScaled((double) 0.5, (double) 0.5, (double) 0.5);
        boolean blend = GL11.glIsEnabled((int) GL11.GL_BLEND);
        boolean lighting = GL11.glIsEnabled((int) GL11.GL_LIGHTING);
        boolean texture = GL11.glIsEnabled((int) GL11.GL_TEXTURE_2D);

        if (!blend) {
            GL11.glEnable((int) GL11.GL_BLEND);
        }

        if (lighting) {
            GL11.glDisable((int) GL11.GL_LIGHTING);
        }

        if (texture) {
            GL11.glDisable((int) GL11.GL_TEXTURE_2D);
        }

        GL11.glBlendFunc((int) GL11.GL_SRC_ALPHA, (int) GL11.GL_ONE_MINUS_SRC_ALPHA);
        this.font.drawString(x *= 2, y *= 2, string, new org.newdawn.slick.Color(color));

        if (texture) {
            GL11.glEnable((int) GL11.GL_TEXTURE_2D);
        }

        if (lighting) {
            GL11.glEnable((int) GL11.GL_LIGHTING);
        }

        if (!blend) {
            GL11.glDisable((int) GL11.GL_BLEND);
        }

        GL11.glPopMatrix();
        return this.getStringWidth(string);
    }

    @Override
    public int func_175063_a(String string, float x, float y, int color) {
        return drawString(string, (int) x, (int) y, color);
    }

    @Override
    public int getCharWidth(char c) {
        return getStringWidth(Character.toString(c));
    }

    @Override
    public int getStringWidth(String string) {
        return font.getWidth(string) / 2;
    }

    public int getStringHeight(String string) {
        return font.getHeight(string) / 2;
    }
}