package net.minecraft.client;

public class AnvilConverterException extends Exception {
    //// = "CL_00000599";

    public AnvilConverterException(String p_i2160_1_) {
        super(p_i2160_1_);
    }
}
