package net.minecraft.block;

public class BlockYellowFlower extends BlockFlower {
    //// = "CL_00002045";

    public BlockFlower.EnumFlowerColor func_176495_j() {
        return BlockFlower.EnumFlowerColor.YELLOW;
    }
}
