package net.minecraft.block;

public class BlockHalfStoneSlabNew extends BlockStoneSlabNew {
    //// = "CL_00002110";

    public boolean isDouble() {
        return false;
    }
}
