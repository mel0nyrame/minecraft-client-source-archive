package net.minecraft.block;

public class BlockRedFlower extends BlockFlower {
    //// = "CL_00002073";

    public BlockFlower.EnumFlowerColor func_176495_j() {
        return BlockFlower.EnumFlowerColor.RED;
    }
}
