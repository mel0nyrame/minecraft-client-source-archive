package me.satisfactory.base.hero.clickgui.component.components;

import me.satisfactory.base.Base;
import me.satisfactory.base.hero.clickgui.component.Component;
import me.satisfactory.base.hero.clickgui.component.Frame;
import me.satisfactory.base.hero.clickgui.component.components.sub.Checkbox;
import me.satisfactory.base.hero.clickgui.component.components.sub.Keybind;
import me.satisfactory.base.hero.clickgui.component.components.sub.ModeButton;
import me.satisfactory.base.hero.clickgui.component.components.sub.Slider;
import me.satisfactory.base.module.Module;
import me.satisfactory.base.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;

public class Button extends Component {
    public Module mod;
    public Frame parent;
    public int offset;
    public boolean open;
    private boolean isHovered;
    private ArrayList<Component> subcomponents;

    public Button(Module mod, Frame parent, int offset) {
        this.mod = mod;
        this.parent = parent;
        this.offset = offset;
        this.subcomponents = new ArrayList<Component>();
        this.open = false;
        int opY = offset + 12;

        if (!mod.getModes().isEmpty()) {
            this.subcomponents.add(new ModeButton(this, mod, opY));
            opY += 12;
        }

        if (Base.INSTANCE.getSettingManager().getSettingsByMod(mod) != null) {
            for (Setting s : Base.INSTANCE.getSettingManager().getSettingsByMod(mod)) {
                if (s.isSlider()) {
                    this.subcomponents.add(new Slider(s, this, opY));
                    opY += 12;
                }

                if (s.isCheck()) {
                    this.subcomponents.add(new Checkbox(s, this, opY));
                    opY += 12;
                }
            }
        }

        this.subcomponents.add(new Keybind(this, opY));
    }

    @Override
    public void setOff(int newOff) {
        offset = newOff;
        int opY = offset + 12;

        for (Component comp : this.subcomponents) {
            comp.setOff(opY);
            opY += 12;
        }
    }

    @Override
    public void renderComponent() {
        Gui.drawRect(parent.getX(), this.parent.getY() + this.offset, parent.getX() + parent.getWidth(), this.parent.getY() + 12 + this.offset, this.isHovered ? (this.mod.isEnabled() ? new Color(0xFF222222).darker().getRGB() : 0xFF222222) : (this.mod.isEnabled() ? new Color(14, 14, 14).getRGB() : 0xFF111111));
        //Gui.drawRect(parent.getX() + parent.getWidth() - 1, this.parent.getY() + this.offset, parent.getX() + parent.getWidth(), this.parent.getY() + 12 + this.offset, clickGuiFont.color);
        //Gui.drawRect(parent.getX(), this.parent.getY() + this.offset, parent.getX() + 1, this.parent.getY() + 12 + this.offset, clickGuiFont.color);
        GL11.glPushMatrix();
        GL11.glScalef(0.5f, 0.5f, 0.5f);
        Minecraft.getMinecraft().fontRendererObj.drawString(this.mod.getName(), (parent.getX() + 2) * 2, (parent.getY() + offset + 2) * 2 + 4, this.mod.isEnabled() ? 0x999999 : -1);

        if (this.subcomponents.size() > 2 || !mod.getModes().isEmpty()) {
            Minecraft.getMinecraft().fontRendererObj.drawString(this.open ? "-" : "+", (parent.getX() + parent.getWidth() - 10) * 2, (parent.getY() + offset + 2) * 2 + 4, -1);
        }

        GL11.glPopMatrix();

        if (this.open) {
            if (!this.subcomponents.isEmpty()) {
                for (Component comp : this.subcomponents) {
                    comp.renderComponent();
                }

                Gui.drawRect(parent.getX() + 1, parent.getY() + this.offset + 12, parent.getX() + 0, parent.getY() + this.offset + ((this.subcomponents.size() + 1) * 12), Base.INSTANCE.GetMainColor());
                //Gui.drawRect(parent.getX() + 87, parent.getY() + this.offset + 12, parent.getX() + 88, parent.getY() + this.offset + ((this.subcomponents.size() + 1) * 12), clickGuiFont.color);
                //Gui.drawRect(parent.getX() + 88, parent.getY() + this.offset + 12, parent.getX() + 0,  parent.getY() + this.offset + 11, clickGuiFont.color);
                //Gui.drawRect(parent.getX() + 88, parent.getY() + this.offset + ((this.subcomponents.size() + 1) * 12) - 1, parent.getX() + 0, parent.getY() + this.offset + ((this.subcomponents.size() + 1) * 12), clickGuiFont.color);
            }
        }
    }

    @Override
    public int getHeight() {
        if (this.open) {
            return (12 * (this.subcomponents.size() + 1));
        }

        return 12;
    }

    @Override
    public void updateComponent(int mouseX, int mouseY) {
        this.isHovered = isMouseOnButton(mouseX, mouseY);

        if (!this.subcomponents.isEmpty()) {
            for (Component comp : this.subcomponents) {
                comp.updateComponent(mouseX, mouseY);
            }
        }
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (isMouseOnButton(mouseX, mouseY) && button == 0) {
            this.mod.toggle();
        }

        if (isMouseOnButton(mouseX, mouseY) && button == 1) {
            this.open = !this.open;
            this.parent.refresh();
        }

        for (Component comp : this.subcomponents) {
            comp.mouseClicked(mouseX, mouseY, button);
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int mouseButton) {
        for (Component comp : this.subcomponents) {
            comp.mouseReleased(mouseX, mouseY, mouseButton);
        }
    }

    @Override
    public void keyTyped(char typedChar, int key) {
        for (Component comp : this.subcomponents) {
            comp.keyTyped(typedChar, key);
        }
    }

    public boolean isMouseOnButton(int x, int y) {
        if (x > parent.getX() && x < parent.getX() + parent.getWidth() && y > this.parent.getY() + this.offset && y < this.parent.getY() + 12 + this.offset) {
            return true;
        }

        return false;
    }
}
