package me.satisfactory.base.setting;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface DoubleSetting {
    String name();

    double currentValue();

    double minValue();

    double maxValue();

    boolean onlyInt();
}
