package me.satisfactory.base.module;

public class Flight extends Module {

	public Flight(String name, int keybind, Category category) {
		super(name, keybind, category);
		// TODO Auto-generated constructor stub
	}

}
