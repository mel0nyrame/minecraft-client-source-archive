package me.satisfactory.base.events;

import me.satisfactory.base.events.event.Event;

/**
 * @author Zarzel.
 * @since 29/06/2017
 */
public class EventMouse implements Event {
    private int key;

    public EventMouse(int key) {
        this.key = key;
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }
}
