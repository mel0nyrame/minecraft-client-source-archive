package me.remixclient.client.modules.movement.longjump;

import me.satisfactory.base.utils.MiscellaneousUtil;
import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.movement.Longjump;
import me.satisfactory.base.events.EventMove;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import net.minecraft.client.Minecraft;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovementInput;

import java.math.BigDecimal;
import java.math.RoundingMode;
import me.satisfactory.base.events.EventTick;
/**
 * @author Mees
 * @since 18/06/2017
 */
public class NCP extends Mode<Longjump> {

    private int stage;
    private double moveSpeed;
    private double lastDist;


    public NCP(Longjump parent) {
        super(parent, "NCP");
    }


    @Override
    public void onEnable() {
        this.moveSpeed = MiscellaneousUtil.getBaseMoveSpeed();
        mc.thePlayer.motionX = 0;
        mc.thePlayer.motionZ = 0;
        this.stage = 0;
        super.onEnable();
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate event) {
        double xDist = mc.thePlayer.posX - mc.thePlayer.prevPosX;
        double zDist = mc.thePlayer.posZ - mc.thePlayer.prevPosZ;
        this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
    }

    @Subscriber
    public void eventMove(EventMove event) {
        MovementInput movementInput = mc.thePlayer.movementInput;
        float forward = movementInput.moveForward;
        float strafe = movementInput.moveStrafe;
        float yaw = Minecraft.getMinecraft().thePlayer.rotationYaw;
        double round = this.parent.round(mc.thePlayer.posY - (int) mc.thePlayer.posY, 3);

        if ((this.stage == 1) && ((mc.thePlayer.moveForward != 0.0F) || (mc.thePlayer.moveStrafing != 0.0F))) {
            this.stage = 2;
            this.moveSpeed = (1.38D * MiscellaneousUtil.getBaseMoveSpeed() - 0.01D);
        } else if (this.stage == 2) {
            this.stage = 3;
            mc.thePlayer.motionY = 0.399399995803833D;
            event.y = 0.399399995803833D;
            this.moveSpeed *= 2.149D;
        } else if (this.stage == 3) {
            this.stage = 4;
            double difference = 0.66D * (this.lastDist - MiscellaneousUtil.getBaseMoveSpeed());
            this.moveSpeed = (this.lastDist - difference) * 2.5;
        } else {
            if ((mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer,
                    mc.thePlayer.boundingBox.offset(0.0D, mc.thePlayer.motionY, 0.0D)).size() > 0)
                    || (mc.thePlayer.isCollidedVertically)) {
                this.stage = 1;
            }

            this.moveSpeed = (this.lastDist - this.lastDist / 159.0D);

            if (mc.thePlayer.motionY < -0.1) {
                // mc.thePlayer.motionY += 0.05;
            }
        }

        this.moveSpeed = Math.max(this.moveSpeed, MiscellaneousUtil.getBaseMoveSpeed());

        if ((forward == 0.0F) && (strafe == 0.0F)) {
            event.x = 0.0D;
            event.z = 0.0D;
        } else if (forward != 0.0F) {
            if (strafe >= 1.0F) {
                yaw += (forward > 0.0F ? -45 : 45);
                strafe = 0.0F;
            } else if (strafe <= -1.0F) {
                yaw += (forward > 0.0F ? 45 : -45);
                strafe = 0.0F;
            }

            if (forward > 0.0F) {
                forward = 1.0F;
            } else if (forward < 0.0F) {
                forward = -1.0F;
            }
        }

        double mx = Math.cos(Math.toRadians(yaw + 90.0F));
        double mz = Math.sin(Math.toRadians(yaw + 90.0F));
        event.x = (forward * this.moveSpeed * mx + strafe * this.moveSpeed * mz);
        event.z = (forward * this.moveSpeed * mz - strafe * this.moveSpeed * mx);
    }

}
