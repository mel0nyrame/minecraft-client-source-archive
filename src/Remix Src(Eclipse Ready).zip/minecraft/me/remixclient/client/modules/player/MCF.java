package me.remixclient.client.modules.player;

import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * @author Mees
 * @since 18/06/2017
 */

public class MCF extends Module {
    public MCF() {
        super("MCF", Keyboard.KEY_NONE, Category.PLAYER);
    }
}
