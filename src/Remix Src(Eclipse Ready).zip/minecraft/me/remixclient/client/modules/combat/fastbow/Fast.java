package me.remixclient.client.modules.combat.fastbow;

import pw.stamina.causam.scan.method.model.Subscriber;
import me.remixclient.client.modules.combat.Fastbow;
import me.satisfactory.base.events.EventPlayerUpdate;
import me.satisfactory.base.module.Mode;
import net.minecraft.item.ItemBow;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C07PacketPlayerDigging.Action;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class Fast extends Mode<Fastbow> {
    public Fast(Fastbow parent) {
        super(parent, "Fast");
    }

    @Subscriber
    public void onUpdate(EventPlayerUpdate tick) {
        if (mc.thePlayer.inventory.getCurrentItem() == null) {
            return;
        }

        if (!mc.thePlayer.onGround) {
            // return;
        }

        if (mc.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemBow && mc.gameSettings.keyBindUseItem.pressed) {
            mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.inventory.getCurrentItem());
            mc.thePlayer.inventory.getCurrentItem().getItem().onItemRightClick(mc.thePlayer.inventory.getCurrentItem(), mc.theWorld, mc.thePlayer);

            for (int i = 0; i < 20; i++) {
                mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(false));
            }

            mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(Action.RELEASE_USE_ITEM, new BlockPos(0, 0, 0), EnumFacing.DOWN));
            mc.thePlayer.inventory.getCurrentItem().getItem().onPlayerStoppedUsing(mc.thePlayer.inventory.getCurrentItem(), mc.theWorld, mc.thePlayer, 100000);
        }
    }
}
