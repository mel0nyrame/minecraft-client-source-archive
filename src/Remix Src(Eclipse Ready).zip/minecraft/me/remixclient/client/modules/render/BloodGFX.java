package me.remixclient.client.modules.render;

import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * @author Zarzel.
 * @since 18/06/2017
 */
public class BloodGFX extends Module {
    public BloodGFX() {
        super("BloodGFX", Keyboard.KEY_NONE, Category.RENDER);
    }
}
