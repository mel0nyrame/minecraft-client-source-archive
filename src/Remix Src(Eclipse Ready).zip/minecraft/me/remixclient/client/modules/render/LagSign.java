package me.remixclient.client.modules.render;

import me.satisfactory.base.module.Category;
import me.satisfactory.base.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * @author Mees
 * @since 18/06/2017
 */

public class LagSign extends Module {
    public LagSign() {
        super("LagSign", Keyboard.KEY_NONE, Category.RENDER);
    }
}
