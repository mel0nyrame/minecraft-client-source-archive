package me.remixclient.client.commands;

import me.satisfactory.base.Base;
import me.satisfactory.base.command.Command;
import me.satisfactory.base.relations.FriendManager;
import me.satisfactory.base.utils.MiscellaneousUtil;

/**
 * @author Mees
 * @since 18/06/2017
 */
public class CommandFriend extends Command {
    public CommandFriend() {
        super("Friend", "friend");
        FriendManager friendMnger;
    }

    public void execute(String[] args) {
        if (args.length != 2 && args.length != 3) {
            MiscellaneousUtil.sendInfo("Something went wrong! Please try .friend <add/remove> <name>");
        } else {
            if (args.length == 2) {
                MiscellaneousUtil.addChatMessage("" + args[0]);

                if (args[0].equalsIgnoreCase("add")) {
                    Base.INSTANCE.getFriendManager().addFriendNoAlias(args[1]);
                    MiscellaneousUtil.sendInfo("Successfully added '" + args[1] + "' as friend!");
                } else if (args[0].equalsIgnoreCase("remove")) {
                    Base.INSTANCE.getFriendManager().removeFriend(args[1]);
                    MiscellaneousUtil.sendInfo("Successfully removed '" + args[1] + " as friend!");
                } else {
                    MiscellaneousUtil.sendInfo("Something went wrong! Please try .friend <add/remove> <name>");
                }
            } else if (args.length == 3) {
                Base.INSTANCE.getFriendManager().addFriend(args[1], args[2]);
                MiscellaneousUtil.sendInfo("Successfully added '" + args[1] + "' as friend! He/She will now be known as '" + args[2] + "'");
            }
        }
    }
}