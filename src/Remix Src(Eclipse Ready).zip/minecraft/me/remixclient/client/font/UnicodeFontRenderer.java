package me.remixclient.client.font;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.UnicodeFont;
import org.newdawn.slick.font.effects.ColorEffect;

import java.awt.*;

public class UnicodeFontRenderer extends FontRenderer {
    private final UnicodeFont font;

    public UnicodeFontRenderer(Font awtFont) {
        super(Minecraft.getMinecraft().gameSettings, new ResourceLocation("textures/font/ascii.png"), Minecraft.getMinecraft().getTextureManager(), false);
        this.font = new UnicodeFont(awtFont);
        this.font.addAsciiGlyphs();
        this.font.getEffects().add(new ColorEffect(Color.WHITE));

        try {
            this.font.loadGlyphs();
        } catch (SlickException var3) {
            throw new RuntimeException(var3);
        }

        String alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ123456789";
        this.FONT_HEIGHT = this.font.getHeight(alphabet) / 2;
    }

    public int drawString(String string, float x, float y, int color) {
        if (string == null) {
            return 0;
        } else {
            GL11.glPushMatrix();
            GL11.glScaled(0.5D, 0.5D, 0.5D);
            boolean blend = GL11.glIsEnabled(GL11.GL_BLEND);
            boolean lighting = GL11.glIsEnabled(GL11.GL_LIGHTING);
            boolean texture = GL11.glIsEnabled(GL11.GL_TEXTURE_2D);

            if (!blend) {
                GL11.glEnable(GL11.GL_BLEND);
            }

            if (lighting) {
                GL11.glDisable(GL11.GL_LIGHTING);
            }

            if (texture) {
                GL11.glDisable(GL11.GL_TEXTURE_2D);
            }

            x *= 2.0F;
            y *= 2.0F;
            this.font.drawString(x, y, string, new org.newdawn.slick.Color(color));

            if (texture) {
                GL11.glEnable(GL11.GL_TEXTURE_2D);
            }

            if (lighting) {
                GL11.glEnable(GL11.GL_LIGHTING);
            }

            if (!blend) {
                GL11.glDisable(GL11.GL_BLEND);
            }

            GlStateManager.color(0.0F, 0.0F, 0.0F);
            GL11.glPopMatrix();
            GlStateManager.bindCurrentTexture();
            return (int) x;
        }
    }

    public float drawStringWithShadow(String text, float x, float y, int color) {
        this.drawString(text, x + 1.0F, y + 1.0F, -16777216);
        return this.drawString(text, x, y, color);
    }

    public int getCharWidth(char c) {
        return this.getStringWidth(Character.toString(c));
    }

    public int getStringWidth(String string) {
        return this.font.getWidth(string) / 2;
    }

    public int getStringHeight(String string) {
        return this.font.getHeight(string) / 2;
    }

    public void drawCenteredString(String text, float x, float y, int color) {
        this.drawString(text, x - (float) (this.getStringWidth(text) / 2), y, color);
    }
}
