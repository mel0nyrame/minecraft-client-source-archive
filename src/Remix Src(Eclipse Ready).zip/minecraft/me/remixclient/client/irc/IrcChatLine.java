package me.remixclient.client.irc;

public class IrcChatLine {
    private int index;
    private String line, sender;
    private boolean read;

    public IrcChatLine(int index, String line, String sender, boolean read) {
        this.index = index;
        this.line = line;
        this.sender = sender;
        this.read = read;
    }

    public IrcChatLine1(int index2, String chatMessage, String sourceNick, boolean read2) {
		// TODO Auto-generated constructor stub
	}

	public void IrcChatLine11(int chatLine, String replace, String name, boolean read2) {
		// TODO Auto-generated constructor stub
	}

	public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public String getLine() {
        return line;
    }

    public void setLine(String line) {
        this.line = line;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public boolean isRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

	
		
}

