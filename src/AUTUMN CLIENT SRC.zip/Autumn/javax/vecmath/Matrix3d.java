/*
 * Decompiled with CFR 0.148.
 */
package javax.vecmath;

import java.io.PrintStream;
import java.io.Serializable;
import javax.vecmath.AxisAngle4d;
import javax.vecmath.AxisAngle4f;
import javax.vecmath.Matrix3f;
import javax.vecmath.Quat4d;
import javax.vecmath.Quat4f;
import javax.vecmath.SingularMatrixException;
import javax.vecmath.Tuple3d;
import javax.vecmath.VecMathI18N;
import javax.vecmath.VecMathUtil;
import javax.vecmath.Vector3d;

public class Matrix3d
implements Serializable,
Cloneable {
    static final long serialVersionUID = 6837536777072402710L;
    public double m00;
    public double m01;
    public double m02;
    public double m10;
    public double m11;
    public double m12;
    public double m20;
    public double m21;
    public double m22;
    private static final double EPS = 1.110223024E-16;
    private static final double ERR_EPS = 1.0E-8;
    private static double xin;
    private static double yin;
    private static double zin;
    private static double xout;
    private static double yout;
    private static double zout;

    public Matrix3d(double d, double d2, double d3, double d4, double d5, double d6, double d7, double d8, double d9) {
        this.m00 = d;
        this.m01 = d2;
        this.m02 = d3;
        this.m10 = d4;
        this.m11 = d5;
        this.m12 = d6;
        this.m20 = d7;
        this.m21 = d8;
        this.m22 = d9;
    }

    public Matrix3d(double[] arrd) {
        this.m00 = arrd[0];
        this.m01 = arrd[1];
        this.m02 = arrd[2];
        this.m10 = arrd[3];
        this.m11 = arrd[4];
        this.m12 = arrd[5];
        this.m20 = arrd[6];
        this.m21 = arrd[7];
        this.m22 = arrd[8];
    }

    public Matrix3d(Matrix3d matrix3d) {
        this.m00 = matrix3d.m00;
        this.m01 = matrix3d.m01;
        this.m02 = matrix3d.m02;
        this.m10 = matrix3d.m10;
        this.m11 = matrix3d.m11;
        this.m12 = matrix3d.m12;
        this.m20 = matrix3d.m20;
        this.m21 = matrix3d.m21;
        this.m22 = matrix3d.m22;
    }

    public Matrix3d(Matrix3f matrix3f) {
        this.m00 = matrix3f.m00;
        this.m01 = matrix3f.m01;
        this.m02 = matrix3f.m02;
        this.m10 = matrix3f.m10;
        this.m11 = matrix3f.m11;
        this.m12 = matrix3f.m12;
        this.m20 = matrix3f.m20;
        this.m21 = matrix3f.m21;
        this.m22 = matrix3f.m22;
    }

    public Matrix3d() {
        this.m00 = 0.0;
        this.m01 = 0.0;
        this.m02 = 0.0;
        this.m10 = 0.0;
        this.m11 = 0.0;
        this.m12 = 0.0;
        this.m20 = 0.0;
        this.m21 = 0.0;
        this.m22 = 0.0;
    }

    public String toString() {
        return this.m00 + ", " + this.m01 + ", " + this.m02 + "\n" + this.m10 + ", " + this.m11 + ", " + this.m12 + "\n" + this.m20 + ", " + this.m21 + ", " + this.m22 + "\n";
    }

    public final void setIdentity() {
        this.m00 = 1.0;
        this.m01 = 0.0;
        this.m02 = 0.0;
        this.m10 = 0.0;
        this.m11 = 1.0;
        this.m12 = 0.0;
        this.m20 = 0.0;
        this.m21 = 0.0;
        this.m22 = 1.0;
    }

    public final void setScale(double d) {
        double[] arrd = new double[9];
        double[] arrd2 = new double[3];
        this.getScaleRotate(arrd2, arrd);
        this.m00 = arrd[0] * d;
        this.m01 = arrd[1] * d;
        this.m02 = arrd[2] * d;
        this.m10 = arrd[3] * d;
        this.m11 = arrd[4] * d;
        this.m12 = arrd[5] * d;
        this.m20 = arrd[6] * d;
        this.m21 = arrd[7] * d;
        this.m22 = arrd[8] * d;
    }

    public final void setElement(int n, int n2, double d) {
        block0 : switch (n) {
            case 0: {
                switch (n2) {
                    case 0: {
                        this.m00 = d;
                        break block0;
                    }
                    case 1: {
                        this.m01 = d;
                        break block0;
                    }
                    case 2: {
                        this.m02 = d;
                        break block0;
                    }
                }
                throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d0"));
            }
            case 1: {
                switch (n2) {
                    case 0: {
                        this.m10 = d;
                        break block0;
                    }
                    case 1: {
                        this.m11 = d;
                        break block0;
                    }
                    case 2: {
                        this.m12 = d;
                        break block0;
                    }
                }
                throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d0"));
            }
            case 2: {
                switch (n2) {
                    case 0: {
                        this.m20 = d;
                        break block0;
                    }
                    case 1: {
                        this.m21 = d;
                        break block0;
                    }
                    case 2: {
                        this.m22 = d;
                        break block0;
                    }
                }
                throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d0"));
            }
            default: {
                throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d0"));
            }
        }
    }

    public final double getElement(int n, int n2) {
        switch (n) {
            case 0: {
                switch (n2) {
                    case 0: {
                        return this.m00;
                    }
                    case 1: {
                        return this.m01;
                    }
                    case 2: {
                        return this.m02;
                    }
                }
                break;
            }
            case 1: {
                switch (n2) {
                    case 0: {
                        return this.m10;
                    }
                    case 1: {
                        return this.m11;
                    }
                    case 2: {
                        return this.m12;
                    }
                }
                break;
            }
            case 2: {
                switch (n2) {
                    case 0: {
                        return this.m20;
                    }
                    case 1: {
                        return this.m21;
                    }
                    case 2: {
                        return this.m22;
                    }
                }
                break;
            }
        }
        throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d1"));
    }

    public final void getRow(int n, Vector3d vector3d) {
        if (n == 0) {
            vector3d.x = this.m00;
            vector3d.y = this.m01;
            vector3d.z = this.m02;
        } else if (n == 1) {
            vector3d.x = this.m10;
            vector3d.y = this.m11;
            vector3d.z = this.m12;
        } else if (n == 2) {
            vector3d.x = this.m20;
            vector3d.y = this.m21;
            vector3d.z = this.m22;
        } else {
            throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d2"));
        }
    }

    public final void getRow(int n, double[] arrd) {
        if (n == 0) {
            arrd[0] = this.m00;
            arrd[1] = this.m01;
            arrd[2] = this.m02;
        } else if (n == 1) {
            arrd[0] = this.m10;
            arrd[1] = this.m11;
            arrd[2] = this.m12;
        } else if (n == 2) {
            arrd[0] = this.m20;
            arrd[1] = this.m21;
            arrd[2] = this.m22;
        } else {
            throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d2"));
        }
    }

    public final void getColumn(int n, Vector3d vector3d) {
        if (n == 0) {
            vector3d.x = this.m00;
            vector3d.y = this.m10;
            vector3d.z = this.m20;
        } else if (n == 1) {
            vector3d.x = this.m01;
            vector3d.y = this.m11;
            vector3d.z = this.m21;
        } else if (n == 2) {
            vector3d.x = this.m02;
            vector3d.y = this.m12;
            vector3d.z = this.m22;
        } else {
            throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d4"));
        }
    }

    public final void getColumn(int n, double[] arrd) {
        if (n == 0) {
            arrd[0] = this.m00;
            arrd[1] = this.m10;
            arrd[2] = this.m20;
        } else if (n == 1) {
            arrd[0] = this.m01;
            arrd[1] = this.m11;
            arrd[2] = this.m21;
        } else if (n == 2) {
            arrd[0] = this.m02;
            arrd[1] = this.m12;
            arrd[2] = this.m22;
        } else {
            throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d4"));
        }
    }

    public final void setRow(int n, double d, double d2, double d3) {
        switch (n) {
            case 0: {
                this.m00 = d;
                this.m01 = d2;
                this.m02 = d3;
                break;
            }
            case 1: {
                this.m10 = d;
                this.m11 = d2;
                this.m12 = d3;
                break;
            }
            case 2: {
                this.m20 = d;
                this.m21 = d2;
                this.m22 = d3;
                break;
            }
            default: {
                throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d6"));
            }
        }
    }

    public final void setRow(int n, Vector3d vector3d) {
        switch (n) {
            case 0: {
                this.m00 = vector3d.x;
                this.m01 = vector3d.y;
                this.m02 = vector3d.z;
                break;
            }
            case 1: {
                this.m10 = vector3d.x;
                this.m11 = vector3d.y;
                this.m12 = vector3d.z;
                break;
            }
            case 2: {
                this.m20 = vector3d.x;
                this.m21 = vector3d.y;
                this.m22 = vector3d.z;
                break;
            }
            default: {
                throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d6"));
            }
        }
    }

    public final void setRow(int n, double[] arrd) {
        switch (n) {
            case 0: {
                this.m00 = arrd[0];
                this.m01 = arrd[1];
                this.m02 = arrd[2];
                break;
            }
            case 1: {
                this.m10 = arrd[0];
                this.m11 = arrd[1];
                this.m12 = arrd[2];
                break;
            }
            case 2: {
                this.m20 = arrd[0];
                this.m21 = arrd[1];
                this.m22 = arrd[2];
                break;
            }
            default: {
                throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d6"));
            }
        }
    }

    public final void setColumn(int n, double d, double d2, double d3) {
        switch (n) {
            case 0: {
                this.m00 = d;
                this.m10 = d2;
                this.m20 = d3;
                break;
            }
            case 1: {
                this.m01 = d;
                this.m11 = d2;
                this.m21 = d3;
                break;
            }
            case 2: {
                this.m02 = d;
                this.m12 = d2;
                this.m22 = d3;
                break;
            }
            default: {
                throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d9"));
            }
        }
    }

    public final void setColumn(int n, Vector3d vector3d) {
        switch (n) {
            case 0: {
                this.m00 = vector3d.x;
                this.m10 = vector3d.y;
                this.m20 = vector3d.z;
                break;
            }
            case 1: {
                this.m01 = vector3d.x;
                this.m11 = vector3d.y;
                this.m21 = vector3d.z;
                break;
            }
            case 2: {
                this.m02 = vector3d.x;
                this.m12 = vector3d.y;
                this.m22 = vector3d.z;
                break;
            }
            default: {
                throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d9"));
            }
        }
    }

    public final void setColumn(int n, double[] arrd) {
        switch (n) {
            case 0: {
                this.m00 = arrd[0];
                this.m10 = arrd[1];
                this.m20 = arrd[2];
                break;
            }
            case 1: {
                this.m01 = arrd[0];
                this.m11 = arrd[1];
                this.m21 = arrd[2];
                break;
            }
            case 2: {
                this.m02 = arrd[0];
                this.m12 = arrd[1];
                this.m22 = arrd[2];
                break;
            }
            default: {
                throw new ArrayIndexOutOfBoundsException(VecMathI18N.getString("Matrix3d9"));
            }
        }
    }

    public final double getScale() {
        double[] arrd = new double[3];
        double[] arrd2 = new double[9];
        this.getScaleRotate(arrd, arrd2);
        return Matrix3d.max3(arrd);
    }

    public final void add(double d) {
        this.m00 += d;
        this.m01 += d;
        this.m02 += d;
        this.m10 += d;
        this.m11 += d;
        this.m12 += d;
        this.m20 += d;
        this.m21 += d;
        this.m22 += d;
    }

    public final void add(double d, Matrix3d matrix3d) {
        this.m00 = matrix3d.m00 + d;
        this.m01 = matrix3d.m01 + d;
        this.m02 = matrix3d.m02 + d;
        this.m10 = matrix3d.m10 + d;
        this.m11 = matrix3d.m11 + d;
        this.m12 = matrix3d.m12 + d;
        this.m20 = matrix3d.m20 + d;
        this.m21 = matrix3d.m21 + d;
        this.m22 = matrix3d.m22 + d;
    }

    public final void add(Matrix3d matrix3d, Matrix3d matrix3d2) {
        this.m00 = matrix3d.m00 + matrix3d2.m00;
        this.m01 = matrix3d.m01 + matrix3d2.m01;
        this.m02 = matrix3d.m02 + matrix3d2.m02;
        this.m10 = matrix3d.m10 + matrix3d2.m10;
        this.m11 = matrix3d.m11 + matrix3d2.m11;
        this.m12 = matrix3d.m12 + matrix3d2.m12;
        this.m20 = matrix3d.m20 + matrix3d2.m20;
        this.m21 = matrix3d.m21 + matrix3d2.m21;
        this.m22 = matrix3d.m22 + matrix3d2.m22;
    }

    public final void add(Matrix3d matrix3d) {
        this.m00 += matrix3d.m00;
        this.m01 += matrix3d.m01;
        this.m02 += matrix3d.m02;
        this.m10 += matrix3d.m10;
        this.m11 += matrix3d.m11;
        this.m12 += matrix3d.m12;
        this.m20 += matrix3d.m20;
        this.m21 += matrix3d.m21;
        this.m22 += matrix3d.m22;
    }

    public final void sub(Matrix3d matrix3d, Matrix3d matrix3d2) {
        this.m00 = matrix3d.m00 - matrix3d2.m00;
        this.m01 = matrix3d.m01 - matrix3d2.m01;
        this.m02 = matrix3d.m02 - matrix3d2.m02;
        this.m10 = matrix3d.m10 - matrix3d2.m10;
        this.m11 = matrix3d.m11 - matrix3d2.m11;
        this.m12 = matrix3d.m12 - matrix3d2.m12;
        this.m20 = matrix3d.m20 - matrix3d2.m20;
        this.m21 = matrix3d.m21 - matrix3d2.m21;
        this.m22 = matrix3d.m22 - matrix3d2.m22;
    }

    public final void sub(Matrix3d matrix3d) {
        this.m00 -= matrix3d.m00;
        this.m01 -= matrix3d.m01;
        this.m02 -= matrix3d.m02;
        this.m10 -= matrix3d.m10;
        this.m11 -= matrix3d.m11;
        this.m12 -= matrix3d.m12;
        this.m20 -= matrix3d.m20;
        this.m21 -= matrix3d.m21;
        this.m22 -= matrix3d.m22;
    }

    public final void transpose() {
        double d = this.m10;
        this.m10 = this.m01;
        this.m01 = d;
        d = this.m20;
        this.m20 = this.m02;
        this.m02 = d;
        d = this.m21;
        this.m21 = this.m12;
        this.m12 = d;
    }

    public final void transpose(Matrix3d matrix3d) {
        if (this != matrix3d) {
            this.m00 = matrix3d.m00;
            this.m01 = matrix3d.m10;
            this.m02 = matrix3d.m20;
            this.m10 = matrix3d.m01;
            this.m11 = matrix3d.m11;
            this.m12 = matrix3d.m21;
            this.m20 = matrix3d.m02;
            this.m21 = matrix3d.m12;
            this.m22 = matrix3d.m22;
        } else {
            this.transpose();
        }
    }

    public final void set(Quat4d quat4d) {
        this.m00 = 1.0 - 2.0 * quat4d.y * quat4d.y - 2.0 * quat4d.z * quat4d.z;
        this.m10 = 2.0 * (quat4d.x * quat4d.y + quat4d.w * quat4d.z);
        this.m20 = 2.0 * (quat4d.x * quat4d.z - quat4d.w * quat4d.y);
        this.m01 = 2.0 * (quat4d.x * quat4d.y - quat4d.w * quat4d.z);
        this.m11 = 1.0 - 2.0 * quat4d.x * quat4d.x - 2.0 * quat4d.z * quat4d.z;
        this.m21 = 2.0 * (quat4d.y * quat4d.z + quat4d.w * quat4d.x);
        this.m02 = 2.0 * (quat4d.x * quat4d.z + quat4d.w * quat4d.y);
        this.m12 = 2.0 * (quat4d.y * quat4d.z - quat4d.w * quat4d.x);
        this.m22 = 1.0 - 2.0 * quat4d.x * quat4d.x - 2.0 * quat4d.y * quat4d.y;
    }

    public final void set(AxisAngle4d axisAngle4d) {
        double d = Math.sqrt(axisAngle4d.x * axisAngle4d.x + axisAngle4d.y * axisAngle4d.y + axisAngle4d.z * axisAngle4d.z);
        if (d < 1.110223024E-16) {
            this.m00 = 1.0;
            this.m01 = 0.0;
            this.m02 = 0.0;
            this.m10 = 0.0;
            this.m11 = 1.0;
            this.m12 = 0.0;
            this.m20 = 0.0;
            this.m21 = 0.0;
            this.m22 = 1.0;
        } else {
            d = 1.0 / d;
            double d2 = axisAngle4d.x * d;
            double d3 = axisAngle4d.y * d;
            double d4 = axisAngle4d.z * d;
            double d5 = Math.sin(axisAngle4d.angle);
            double d6 = Math.cos(axisAngle4d.angle);
            double d7 = 1.0 - d6;
            double d8 = axisAngle4d.x * axisAngle4d.z;
            double d9 = axisAngle4d.x * axisAngle4d.y;
            double d10 = axisAngle4d.y * axisAngle4d.z;
            this.m00 = d7 * d2 * d2 + d6;
            this.m01 = d7 * d9 - d5 * d4;
            this.m02 = d7 * d8 + d5 * d3;
            this.m10 = d7 * d9 + d5 * d4;
            this.m11 = d7 * d3 * d3 + d6;
            this.m12 = d7 * d10 - d5 * d2;
            this.m20 = d7 * d8 - d5 * d3;
            this.m21 = d7 * d10 + d5 * d2;
            this.m22 = d7 * d4 * d4 + d6;
        }
    }

    public final void set(Quat4f quat4f) {
        this.m00 = 1.0 - 2.0 * (double)quat4f.y * (double)quat4f.y - 2.0 * (double)quat4f.z * (double)quat4f.z;
        this.m10 = 2.0 * (double)(quat4f.x * quat4f.y + quat4f.w * quat4f.z);
        this.m20 = 2.0 * (double)(quat4f.x * quat4f.z - quat4f.w * quat4f.y);
        this.m01 = 2.0 * (double)(quat4f.x * quat4f.y - quat4f.w * quat4f.z);
        this.m11 = 1.0 - 2.0 * (double)quat4f.x * (double)quat4f.x - 2.0 * (double)quat4f.z * (double)quat4f.z;
        this.m21 = 2.0 * (double)(quat4f.y * quat4f.z + quat4f.w * quat4f.x);
        this.m02 = 2.0 * (double)(quat4f.x * quat4f.z + quat4f.w * quat4f.y);
        this.m12 = 2.0 * (double)(quat4f.y * quat4f.z - quat4f.w * quat4f.x);
        this.m22 = 1.0 - 2.0 * (double)quat4f.x * (double)quat4f.x - 2.0 * (double)quat4f.y * (double)quat4f.y;
    }

    public final void set(AxisAngle4f axisAngle4f) {
        double d = Math.sqrt(axisAngle4f.x * axisAngle4f.x + axisAngle4f.y * axisAngle4f.y + axisAngle4f.z * axisAngle4f.z);
        if (d < 1.110223024E-16) {
            this.m00 = 1.0;
            this.m01 = 0.0;
            this.m02 = 0.0;
            this.m10 = 0.0;
            this.m11 = 1.0;
            this.m12 = 0.0;
            this.m20 = 0.0;
            this.m21 = 0.0;
            this.m22 = 1.0;
        } else {
            d = 1.0 / d;
            double d2 = (double)axisAngle4f.x * d;
            double d3 = (double)axisAngle4f.y * d;
            double d4 = (double)axisAngle4f.z * d;
            double d5 = Math.sin(axisAngle4f.angle);
            double d6 = Math.cos(axisAngle4f.angle);
            double d7 = 1.0 - d6;
            double d8 = d2 * d4;
            double d9 = d2 * d3;
            double d10 = d3 * d4;
            this.m00 = d7 * d2 * d2 + d6;
            this.m01 = d7 * d9 - d5 * d4;
            this.m02 = d7 * d8 + d5 * d3;
            this.m10 = d7 * d9 + d5 * d4;
            this.m11 = d7 * d3 * d3 + d6;
            this.m12 = d7 * d10 - d5 * d2;
            this.m20 = d7 * d8 - d5 * d3;
            this.m21 = d7 * d10 + d5 * d2;
            this.m22 = d7 * d4 * d4 + d6;
        }
    }

    public final void set(Matrix3f matrix3f) {
        this.m00 = matrix3f.m00;
        this.m01 = matrix3f.m01;
        this.m02 = matrix3f.m02;
        this.m10 = matrix3f.m10;
        this.m11 = matrix3f.m11;
        this.m12 = matrix3f.m12;
        this.m20 = matrix3f.m20;
        this.m21 = matrix3f.m21;
        this.m22 = matrix3f.m22;
    }

    public final void set(Matrix3d matrix3d) {
        this.m00 = matrix3d.m00;
        this.m01 = matrix3d.m01;
        this.m02 = matrix3d.m02;
        this.m10 = matrix3d.m10;
        this.m11 = matrix3d.m11;
        this.m12 = matrix3d.m12;
        this.m20 = matrix3d.m20;
        this.m21 = matrix3d.m21;
        this.m22 = matrix3d.m22;
    }

    public final void set(double[] arrd) {
        this.m00 = arrd[0];
        this.m01 = arrd[1];
        this.m02 = arrd[2];
        this.m10 = arrd[3];
        this.m11 = arrd[4];
        this.m12 = arrd[5];
        this.m20 = arrd[6];
        this.m21 = arrd[7];
        this.m22 = arrd[8];
    }

    public final void invert(Matrix3d matrix3d) {
        this.invertGeneral(matrix3d);
    }

    public final void invert() {
        this.invertGeneral(this);
    }

    private final void invertGeneral(Matrix3d matrix3d) {
        double[] arrd = new double[9];
        int[] arrn = new int[3];
        double[] arrd2 = new double[]{matrix3d.m00, matrix3d.m01, matrix3d.m02, matrix3d.m10, matrix3d.m11, matrix3d.m12, matrix3d.m20, matrix3d.m21, matrix3d.m22};
        if (!Matrix3d.luDecomposition(arrd2, arrn)) {
            throw new SingularMatrixException(VecMathI18N.getString("Matrix3d12"));
        }
        for (int i = 0; i < 9; ++i) {
            arrd[i] = 0.0;
        }
        arrd[0] = 1.0;
        arrd[4] = 1.0;
        arrd[8] = 1.0;
        Matrix3d.luBacksubstitution(arrd2, arrn, arrd);
        this.m00 = arrd[0];
        this.m01 = arrd[1];
        this.m02 = arrd[2];
        this.m10 = arrd[3];
        this.m11 = arrd[4];
        this.m12 = arrd[5];
        this.m20 = arrd[6];
        this.m21 = arrd[7];
        this.m22 = arrd[8];
    }

    static boolean luDecomposition(double[] arrd, int[] arrn) {
        int n;
        double[] arrd2 = new double[3];
        int n2 = 0;
        int n3 = 0;
        int n4 = 3;
        while (n4-- != 0) {
            double d = 0.0;
            n = 3;
            while (n-- != 0) {
                double d2 = arrd[n2++];
                if (!((d2 = Math.abs(d2)) > d)) continue;
                d = d2;
            }
            if (d == 0.0) {
                return false;
            }
            arrd2[n3++] = 1.0 / d;
        }
        n = 0;
        for (n4 = 0; n4 < 3; ++n4) {
            double d;
            double d3;
            int n5;
            int n6;
            int n7;
            for (n2 = 0; n2 < n4; ++n2) {
                n7 = n + 3 * n2 + n4;
                d3 = arrd[n7];
                int n8 = n2;
                n6 = n + 3 * n2;
                n5 = n + n4;
                while (n8-- != 0) {
                    d3 -= arrd[n6] * arrd[n5];
                    ++n6;
                    n5 += 3;
                }
                arrd[n7] = d3;
            }
            double d4 = 0.0;
            n3 = -1;
            for (n2 = n4; n2 < 3; ++n2) {
                double d5;
                n7 = n + 3 * n2 + n4;
                d3 = arrd[n7];
                int n9 = n4;
                n6 = n + 3 * n2;
                n5 = n + n4;
                while (n9-- != 0) {
                    d3 -= arrd[n6] * arrd[n5];
                    ++n6;
                    n5 += 3;
                }
                arrd[n7] = d3;
                d = arrd2[n2] * Math.abs(d3);
                if (!(d5 >= d4)) continue;
                d4 = d;
                n3 = n2;
            }
            if (n3 < 0) {
                throw new RuntimeException(VecMathI18N.getString("Matrix3d13"));
            }
            if (n4 != n3) {
                int n10 = 3;
                n6 = n + 3 * n3;
                n5 = n + 3 * n4;
                while (n10-- != 0) {
                    d = arrd[n6];
                    arrd[n6++] = arrd[n5];
                    arrd[n5++] = d;
                }
                arrd2[n3] = arrd2[n4];
            }
            arrn[n4] = n3;
            if (arrd[n + 3 * n4 + n4] == 0.0) {
                return false;
            }
            if (n4 == 2) continue;
            d = 1.0 / arrd[n + 3 * n4 + n4];
            n7 = n + 3 * (n4 + 1) + n4;
            n2 = 2 - n4;
            while (n2-- != 0) {
                int n11 = n7;
                arrd[n11] = arrd[n11] * d;
                n7 += 3;
            }
        }
        return true;
    }

    static void luBacksubstitution(double[] arrd, int[] arrn, double[] arrd2) {
        int n = 0;
        for (int i = 0; i < 3; ++i) {
            int n2;
            int n3 = i;
            int n4 = -1;
            for (int j = 0; j < 3; ++j) {
                int n5 = arrn[n + j];
                double d = arrd2[n3 + 3 * n5];
                arrd2[n3 + 3 * n5] = arrd2[n3 + 3 * j];
                if (n4 >= 0) {
                    n2 = j * 3;
                    for (int k = n4; k <= j - 1; ++k) {
                        d -= arrd[n2 + k] * arrd2[n3 + 3 * k];
                    }
                } else if (d != 0.0) {
                    n4 = j;
                }
                arrd2[n3 + 3 * j] = d;
            }
            n2 = 6;
            int n6 = n3 + 6;
            arrd2[n6] = arrd2[n6] / arrd[n2 + 2];
            arrd2[n3 + 3] = (arrd2[n3 + 3] - arrd[(n2 -= 3) + 2] * arrd2[n3 + 6]) / arrd[n2 + 1];
            arrd2[n3 + 0] = (arrd2[n3 + 0] - arrd[(n2 -= 3) + 1] * arrd2[n3 + 3] - arrd[n2 + 2] * arrd2[n3 + 6]) / arrd[n2 + 0];
        }
    }

    public final double determinant() {
        double d = this.m00 * (this.m11 * this.m22 - this.m12 * this.m21) + this.m01 * (this.m12 * this.m20 - this.m10 * this.m22) + this.m02 * (this.m10 * this.m21 - this.m11 * this.m20);
        return d;
    }

    public final void set(double d) {
        this.m00 = d;
        this.m01 = 0.0;
        this.m02 = 0.0;
        this.m10 = 0.0;
        this.m11 = d;
        this.m12 = 0.0;
        this.m20 = 0.0;
        this.m21 = 0.0;
        this.m22 = d;
    }

    public final void rotX(double d) {
        double d2 = Math.sin(d);
        double d3 = Math.cos(d);
        this.m00 = 1.0;
        this.m01 = 0.0;
        this.m02 = 0.0;
        this.m10 = 0.0;
        this.m11 = d3;
        this.m12 = -d2;
        this.m20 = 0.0;
        this.m21 = d2;
        this.m22 = d3;
    }

    public final void rotY(double d) {
        double d2;
        double d3 = Math.sin(d);
        this.m00 = d2 = Math.cos(d);
        this.m01 = 0.0;
        this.m02 = d3;
        this.m10 = 0.0;
        this.m11 = 1.0;
        this.m12 = 0.0;
        this.m20 = -d3;
        this.m21 = 0.0;
        this.m22 = d2;
    }

    public final void rotZ(double d) {
        double d2;
        double d3 = Math.sin(d);
        this.m00 = d2 = Math.cos(d);
        this.m01 = -d3;
        this.m02 = 0.0;
        this.m10 = d3;
        this.m11 = d2;
        this.m12 = 0.0;
        this.m20 = 0.0;
        this.m21 = 0.0;
        this.m22 = 1.0;
    }

    public final void mul(double d) {
        this.m00 *= d;
        this.m01 *= d;
        this.m02 *= d;
        this.m10 *= d;
        this.m11 *= d;
        this.m12 *= d;
        this.m20 *= d;
        this.m21 *= d;
        this.m22 *= d;
    }

    public final void mul(double d, Matrix3d matrix3d) {
        this.m00 = d * matrix3d.m00;
        this.m01 = d * matrix3d.m01;
        this.m02 = d * matrix3d.m02;
        this.m10 = d * matrix3d.m10;
        this.m11 = d * matrix3d.m11;
        this.m12 = d * matrix3d.m12;
        this.m20 = d * matrix3d.m20;
        this.m21 = d * matrix3d.m21;
        this.m22 = d * matrix3d.m22;
    }

    public final void mul(Matrix3d matrix3d) {
        double d = this.m00 * matrix3d.m00 + this.m01 * matrix3d.m10 + this.m02 * matrix3d.m20;
        double d2 = this.m00 * matrix3d.m01 + this.m01 * matrix3d.m11 + this.m02 * matrix3d.m21;
        double d3 = this.m00 * matrix3d.m02 + this.m01 * matrix3d.m12 + this.m02 * matrix3d.m22;
        double d4 = this.m10 * matrix3d.m00 + this.m11 * matrix3d.m10 + this.m12 * matrix3d.m20;
        double d5 = this.m10 * matrix3d.m01 + this.m11 * matrix3d.m11 + this.m12 * matrix3d.m21;
        double d6 = this.m10 * matrix3d.m02 + this.m11 * matrix3d.m12 + this.m12 * matrix3d.m22;
        double d7 = this.m20 * matrix3d.m00 + this.m21 * matrix3d.m10 + this.m22 * matrix3d.m20;
        double d8 = this.m20 * matrix3d.m01 + this.m21 * matrix3d.m11 + this.m22 * matrix3d.m21;
        double d9 = this.m20 * matrix3d.m02 + this.m21 * matrix3d.m12 + this.m22 * matrix3d.m22;
        this.m00 = d;
        this.m01 = d2;
        this.m02 = d3;
        this.m10 = d4;
        this.m11 = d5;
        this.m12 = d6;
        this.m20 = d7;
        this.m21 = d8;
        this.m22 = d9;
    }

    public final void mul(Matrix3d matrix3d, Matrix3d matrix3d2) {
        if (this != matrix3d && this != matrix3d2) {
            this.m00 = matrix3d.m00 * matrix3d2.m00 + matrix3d.m01 * matrix3d2.m10 + matrix3d.m02 * matrix3d2.m20;
            this.m01 = matrix3d.m00 * matrix3d2.m01 + matrix3d.m01 * matrix3d2.m11 + matrix3d.m02 * matrix3d2.m21;
            this.m02 = matrix3d.m00 * matrix3d2.m02 + matrix3d.m01 * matrix3d2.m12 + matrix3d.m02 * matrix3d2.m22;
            this.m10 = matrix3d.m10 * matrix3d2.m00 + matrix3d.m11 * matrix3d2.m10 + matrix3d.m12 * matrix3d2.m20;
            this.m11 = matrix3d.m10 * matrix3d2.m01 + matrix3d.m11 * matrix3d2.m11 + matrix3d.m12 * matrix3d2.m21;
            this.m12 = matrix3d.m10 * matrix3d2.m02 + matrix3d.m11 * matrix3d2.m12 + matrix3d.m12 * matrix3d2.m22;
            this.m20 = matrix3d.m20 * matrix3d2.m00 + matrix3d.m21 * matrix3d2.m10 + matrix3d.m22 * matrix3d2.m20;
            this.m21 = matrix3d.m20 * matrix3d2.m01 + matrix3d.m21 * matrix3d2.m11 + matrix3d.m22 * matrix3d2.m21;
            this.m22 = matrix3d.m20 * matrix3d2.m02 + matrix3d.m21 * matrix3d2.m12 + matrix3d.m22 * matrix3d2.m22;
        } else {
            double d = matrix3d.m00 * matrix3d2.m00 + matrix3d.m01 * matrix3d2.m10 + matrix3d.m02 * matrix3d2.m20;
            double d2 = matrix3d.m00 * matrix3d2.m01 + matrix3d.m01 * matrix3d2.m11 + matrix3d.m02 * matrix3d2.m21;
            double d3 = matrix3d.m00 * matrix3d2.m02 + matrix3d.m01 * matrix3d2.m12 + matrix3d.m02 * matrix3d2.m22;
            double d4 = matrix3d.m10 * matrix3d2.m00 + matrix3d.m11 * matrix3d2.m10 + matrix3d.m12 * matrix3d2.m20;
            double d5 = matrix3d.m10 * matrix3d2.m01 + matrix3d.m11 * matrix3d2.m11 + matrix3d.m12 * matrix3d2.m21;
            double d6 = matrix3d.m10 * matrix3d2.m02 + matrix3d.m11 * matrix3d2.m12 + matrix3d.m12 * matrix3d2.m22;
            double d7 = matrix3d.m20 * matrix3d2.m00 + matrix3d.m21 * matrix3d2.m10 + matrix3d.m22 * matrix3d2.m20;
            double d8 = matrix3d.m20 * matrix3d2.m01 + matrix3d.m21 * matrix3d2.m11 + matrix3d.m22 * matrix3d2.m21;
            double d9 = matrix3d.m20 * matrix3d2.m02 + matrix3d.m21 * matrix3d2.m12 + matrix3d.m22 * matrix3d2.m22;
            this.m00 = d;
            this.m01 = d2;
            this.m02 = d3;
            this.m10 = d4;
            this.m11 = d5;
            this.m12 = d6;
            this.m20 = d7;
            this.m21 = d8;
            this.m22 = d9;
        }
    }

    public final void mulNormalize(Matrix3d matrix3d) {
        double[] arrd = new double[9];
        double[] arrd2 = new double[9];
        double[] arrd3 = new double[3];
        arrd[0] = this.m00 * matrix3d.m00 + this.m01 * matrix3d.m10 + this.m02 * matrix3d.m20;
        arrd[1] = this.m00 * matrix3d.m01 + this.m01 * matrix3d.m11 + this.m02 * matrix3d.m21;
        arrd[2] = this.m00 * matrix3d.m02 + this.m01 * matrix3d.m12 + this.m02 * matrix3d.m22;
        arrd[3] = this.m10 * matrix3d.m00 + this.m11 * matrix3d.m10 + this.m12 * matrix3d.m20;
        arrd[4] = this.m10 * matrix3d.m01 + this.m11 * matrix3d.m11 + this.m12 * matrix3d.m21;
        arrd[5] = this.m10 * matrix3d.m02 + this.m11 * matrix3d.m12 + this.m12 * matrix3d.m22;
        arrd[6] = this.m20 * matrix3d.m00 + this.m21 * matrix3d.m10 + this.m22 * matrix3d.m20;
        arrd[7] = this.m20 * matrix3d.m01 + this.m21 * matrix3d.m11 + this.m22 * matrix3d.m21;
        arrd[8] = this.m20 * matrix3d.m02 + this.m21 * matrix3d.m12 + this.m22 * matrix3d.m22;
        Matrix3d.compute_svd(arrd, arrd3, arrd2);
        this.m00 = arrd2[0];
        this.m01 = arrd2[1];
        this.m02 = arrd2[2];
        this.m10 = arrd2[3];
        this.m11 = arrd2[4];
        this.m12 = arrd2[5];
        this.m20 = arrd2[6];
        this.m21 = arrd2[7];
        this.m22 = arrd2[8];
    }

    public final void mulNormalize(Matrix3d matrix3d, Matrix3d matrix3d2) {
        double[] arrd = new double[9];
        double[] arrd2 = new double[9];
        double[] arrd3 = new double[3];
        arrd[0] = matrix3d.m00 * matrix3d2.m00 + matrix3d.m01 * matrix3d2.m10 + matrix3d.m02 * matrix3d2.m20;
        arrd[1] = matrix3d.m00 * matrix3d2.m01 + matrix3d.m01 * matrix3d2.m11 + matrix3d.m02 * matrix3d2.m21;
        arrd[2] = matrix3d.m00 * matrix3d2.m02 + matrix3d.m01 * matrix3d2.m12 + matrix3d.m02 * matrix3d2.m22;
        arrd[3] = matrix3d.m10 * matrix3d2.m00 + matrix3d.m11 * matrix3d2.m10 + matrix3d.m12 * matrix3d2.m20;
        arrd[4] = matrix3d.m10 * matrix3d2.m01 + matrix3d.m11 * matrix3d2.m11 + matrix3d.m12 * matrix3d2.m21;
        arrd[5] = matrix3d.m10 * matrix3d2.m02 + matrix3d.m11 * matrix3d2.m12 + matrix3d.m12 * matrix3d2.m22;
        arrd[6] = matrix3d.m20 * matrix3d2.m00 + matrix3d.m21 * matrix3d2.m10 + matrix3d.m22 * matrix3d2.m20;
        arrd[7] = matrix3d.m20 * matrix3d2.m01 + matrix3d.m21 * matrix3d2.m11 + matrix3d.m22 * matrix3d2.m21;
        arrd[8] = matrix3d.m20 * matrix3d2.m02 + matrix3d.m21 * matrix3d2.m12 + matrix3d.m22 * matrix3d2.m22;
        Matrix3d.compute_svd(arrd, arrd3, arrd2);
        this.m00 = arrd2[0];
        this.m01 = arrd2[1];
        this.m02 = arrd2[2];
        this.m10 = arrd2[3];
        this.m11 = arrd2[4];
        this.m12 = arrd2[5];
        this.m20 = arrd2[6];
        this.m21 = arrd2[7];
        this.m22 = arrd2[8];
    }

    public final void mulTransposeBoth(Matrix3d matrix3d, Matrix3d matrix3d2) {
        if (this != matrix3d && this != matrix3d2) {
            this.m00 = matrix3d.m00 * matrix3d2.m00 + matrix3d.m10 * matrix3d2.m01 + matrix3d.m20 * matrix3d2.m02;
            this.m01 = matrix3d.m00 * matrix3d2.m10 + matrix3d.m10 * matrix3d2.m11 + matrix3d.m20 * matrix3d2.m12;
            this.m02 = matrix3d.m00 * matrix3d2.m20 + matrix3d.m10 * matrix3d2.m21 + matrix3d.m20 * matrix3d2.m22;
            this.m10 = matrix3d.m01 * matrix3d2.m00 + matrix3d.m11 * matrix3d2.m01 + matrix3d.m21 * matrix3d2.m02;
            this.m11 = matrix3d.m01 * matrix3d2.m10 + matrix3d.m11 * matrix3d2.m11 + matrix3d.m21 * matrix3d2.m12;
            this.m12 = matrix3d.m01 * matrix3d2.m20 + matrix3d.m11 * matrix3d2.m21 + matrix3d.m21 * matrix3d2.m22;
            this.m20 = matrix3d.m02 * matrix3d2.m00 + matrix3d.m12 * matrix3d2.m01 + matrix3d.m22 * matrix3d2.m02;
            this.m21 = matrix3d.m02 * matrix3d2.m10 + matrix3d.m12 * matrix3d2.m11 + matrix3d.m22 * matrix3d2.m12;
            this.m22 = matrix3d.m02 * matrix3d2.m20 + matrix3d.m12 * matrix3d2.m21 + matrix3d.m22 * matrix3d2.m22;
        } else {
            double d = matrix3d.m00 * matrix3d2.m00 + matrix3d.m10 * matrix3d2.m01 + matrix3d.m20 * matrix3d2.m02;
            double d2 = matrix3d.m00 * matrix3d2.m10 + matrix3d.m10 * matrix3d2.m11 + matrix3d.m20 * matrix3d2.m12;
            double d3 = matrix3d.m00 * matrix3d2.m20 + matrix3d.m10 * matrix3d2.m21 + matrix3d.m20 * matrix3d2.m22;
            double d4 = matrix3d.m01 * matrix3d2.m00 + matrix3d.m11 * matrix3d2.m01 + matrix3d.m21 * matrix3d2.m02;
            double d5 = matrix3d.m01 * matrix3d2.m10 + matrix3d.m11 * matrix3d2.m11 + matrix3d.m21 * matrix3d2.m12;
            double d6 = matrix3d.m01 * matrix3d2.m20 + matrix3d.m11 * matrix3d2.m21 + matrix3d.m21 * matrix3d2.m22;
            double d7 = matrix3d.m02 * matrix3d2.m00 + matrix3d.m12 * matrix3d2.m01 + matrix3d.m22 * matrix3d2.m02;
            double d8 = matrix3d.m02 * matrix3d2.m10 + matrix3d.m12 * matrix3d2.m11 + matrix3d.m22 * matrix3d2.m12;
            double d9 = matrix3d.m02 * matrix3d2.m20 + matrix3d.m12 * matrix3d2.m21 + matrix3d.m22 * matrix3d2.m22;
            this.m00 = d;
            this.m01 = d2;
            this.m02 = d3;
            this.m10 = d4;
            this.m11 = d5;
            this.m12 = d6;
            this.m20 = d7;
            this.m21 = d8;
            this.m22 = d9;
        }
    }

    public final void mulTransposeRight(Matrix3d matrix3d, Matrix3d matrix3d2) {
        if (this != matrix3d && this != matrix3d2) {
            this.m00 = matrix3d.m00 * matrix3d2.m00 + matrix3d.m01 * matrix3d2.m01 + matrix3d.m02 * matrix3d2.m02;
            this.m01 = matrix3d.m00 * matrix3d2.m10 + matrix3d.m01 * matrix3d2.m11 + matrix3d.m02 * matrix3d2.m12;
            this.m02 = matrix3d.m00 * matrix3d2.m20 + matrix3d.m01 * matrix3d2.m21 + matrix3d.m02 * matrix3d2.m22;
            this.m10 = matrix3d.m10 * matrix3d2.m00 + matrix3d.m11 * matrix3d2.m01 + matrix3d.m12 * matrix3d2.m02;
            this.m11 = matrix3d.m10 * matrix3d2.m10 + matrix3d.m11 * matrix3d2.m11 + matrix3d.m12 * matrix3d2.m12;
            this.m12 = matrix3d.m10 * matrix3d2.m20 + matrix3d.m11 * matrix3d2.m21 + matrix3d.m12 * matrix3d2.m22;
            this.m20 = matrix3d.m20 * matrix3d2.m00 + matrix3d.m21 * matrix3d2.m01 + matrix3d.m22 * matrix3d2.m02;
            this.m21 = matrix3d.m20 * matrix3d2.m10 + matrix3d.m21 * matrix3d2.m11 + matrix3d.m22 * matrix3d2.m12;
            this.m22 = matrix3d.m20 * matrix3d2.m20 + matrix3d.m21 * matrix3d2.m21 + matrix3d.m22 * matrix3d2.m22;
        } else {
            double d = matrix3d.m00 * matrix3d2.m00 + matrix3d.m01 * matrix3d2.m01 + matrix3d.m02 * matrix3d2.m02;
            double d2 = matrix3d.m00 * matrix3d2.m10 + matrix3d.m01 * matrix3d2.m11 + matrix3d.m02 * matrix3d2.m12;
            double d3 = matrix3d.m00 * matrix3d2.m20 + matrix3d.m01 * matrix3d2.m21 + matrix3d.m02 * matrix3d2.m22;
            double d4 = matrix3d.m10 * matrix3d2.m00 + matrix3d.m11 * matrix3d2.m01 + matrix3d.m12 * matrix3d2.m02;
            double d5 = matrix3d.m10 * matrix3d2.m10 + matrix3d.m11 * matrix3d2.m11 + matrix3d.m12 * matrix3d2.m12;
            double d6 = matrix3d.m10 * matrix3d2.m20 + matrix3d.m11 * matrix3d2.m21 + matrix3d.m12 * matrix3d2.m22;
            double d7 = matrix3d.m20 * matrix3d2.m00 + matrix3d.m21 * matrix3d2.m01 + matrix3d.m22 * matrix3d2.m02;
            double d8 = matrix3d.m20 * matrix3d2.m10 + matrix3d.m21 * matrix3d2.m11 + matrix3d.m22 * matrix3d2.m12;
            double d9 = matrix3d.m20 * matrix3d2.m20 + matrix3d.m21 * matrix3d2.m21 + matrix3d.m22 * matrix3d2.m22;
            this.m00 = d;
            this.m01 = d2;
            this.m02 = d3;
            this.m10 = d4;
            this.m11 = d5;
            this.m12 = d6;
            this.m20 = d7;
            this.m21 = d8;
            this.m22 = d9;
        }
    }

    public final void mulTransposeLeft(Matrix3d matrix3d, Matrix3d matrix3d2) {
        if (this != matrix3d && this != matrix3d2) {
            this.m00 = matrix3d.m00 * matrix3d2.m00 + matrix3d.m10 * matrix3d2.m10 + matrix3d.m20 * matrix3d2.m20;
            this.m01 = matrix3d.m00 * matrix3d2.m01 + matrix3d.m10 * matrix3d2.m11 + matrix3d.m20 * matrix3d2.m21;
            this.m02 = matrix3d.m00 * matrix3d2.m02 + matrix3d.m10 * matrix3d2.m12 + matrix3d.m20 * matrix3d2.m22;
            this.m10 = matrix3d.m01 * matrix3d2.m00 + matrix3d.m11 * matrix3d2.m10 + matrix3d.m21 * matrix3d2.m20;
            this.m11 = matrix3d.m01 * matrix3d2.m01 + matrix3d.m11 * matrix3d2.m11 + matrix3d.m21 * matrix3d2.m21;
            this.m12 = matrix3d.m01 * matrix3d2.m02 + matrix3d.m11 * matrix3d2.m12 + matrix3d.m21 * matrix3d2.m22;
            this.m20 = matrix3d.m02 * matrix3d2.m00 + matrix3d.m12 * matrix3d2.m10 + matrix3d.m22 * matrix3d2.m20;
            this.m21 = matrix3d.m02 * matrix3d2.m01 + matrix3d.m12 * matrix3d2.m11 + matrix3d.m22 * matrix3d2.m21;
            this.m22 = matrix3d.m02 * matrix3d2.m02 + matrix3d.m12 * matrix3d2.m12 + matrix3d.m22 * matrix3d2.m22;
        } else {
            double d = matrix3d.m00 * matrix3d2.m00 + matrix3d.m10 * matrix3d2.m10 + matrix3d.m20 * matrix3d2.m20;
            double d2 = matrix3d.m00 * matrix3d2.m01 + matrix3d.m10 * matrix3d2.m11 + matrix3d.m20 * matrix3d2.m21;
            double d3 = matrix3d.m00 * matrix3d2.m02 + matrix3d.m10 * matrix3d2.m12 + matrix3d.m20 * matrix3d2.m22;
            double d4 = matrix3d.m01 * matrix3d2.m00 + matrix3d.m11 * matrix3d2.m10 + matrix3d.m21 * matrix3d2.m20;
            double d5 = matrix3d.m01 * matrix3d2.m01 + matrix3d.m11 * matrix3d2.m11 + matrix3d.m21 * matrix3d2.m21;
            double d6 = matrix3d.m01 * matrix3d2.m02 + matrix3d.m11 * matrix3d2.m12 + matrix3d.m21 * matrix3d2.m22;
            double d7 = matrix3d.m02 * matrix3d2.m00 + matrix3d.m12 * matrix3d2.m10 + matrix3d.m22 * matrix3d2.m20;
            double d8 = matrix3d.m02 * matrix3d2.m01 + matrix3d.m12 * matrix3d2.m11 + matrix3d.m22 * matrix3d2.m21;
            double d9 = matrix3d.m02 * matrix3d2.m02 + matrix3d.m12 * matrix3d2.m12 + matrix3d.m22 * matrix3d2.m22;
            this.m00 = d;
            this.m01 = d2;
            this.m02 = d3;
            this.m10 = d4;
            this.m11 = d5;
            this.m12 = d6;
            this.m20 = d7;
            this.m21 = d8;
            this.m22 = d9;
        }
    }

    public final void normalize() {
        double[] arrd = new double[9];
        double[] arrd2 = new double[3];
        this.getScaleRotate(arrd2, arrd);
        this.m00 = arrd[0];
        this.m01 = arrd[1];
        this.m02 = arrd[2];
        this.m10 = arrd[3];
        this.m11 = arrd[4];
        this.m12 = arrd[5];
        this.m20 = arrd[6];
        this.m21 = arrd[7];
        this.m22 = arrd[8];
    }

    public final void normalize(Matrix3d matrix3d) {
        double[] arrd = new double[9];
        double[] arrd2 = new double[9];
        double[] arrd3 = new double[3];
        arrd[0] = matrix3d.m00;
        arrd[1] = matrix3d.m01;
        arrd[2] = matrix3d.m02;
        arrd[3] = matrix3d.m10;
        arrd[4] = matrix3d.m11;
        arrd[5] = matrix3d.m12;
        arrd[6] = matrix3d.m20;
        arrd[7] = matrix3d.m21;
        arrd[8] = matrix3d.m22;
        Matrix3d.compute_svd(arrd, arrd3, arrd2);
        this.m00 = arrd2[0];
        this.m01 = arrd2[1];
        this.m02 = arrd2[2];
        this.m10 = arrd2[3];
        this.m11 = arrd2[4];
        this.m12 = arrd2[5];
        this.m20 = arrd2[6];
        this.m21 = arrd2[7];
        this.m22 = arrd2[8];
    }

    public final void normalizeCP() {
        double d = 1.0 / Math.sqrt(this.m00 * this.m00 + this.m10 * this.m10 + this.m20 * this.m20);
        this.m00 *= d;
        this.m10 *= d;
        this.m20 *= d;
        d = 1.0 / Math.sqrt(this.m01 * this.m01 + this.m11 * this.m11 + this.m21 * this.m21);
        this.m01 *= d;
        this.m11 *= d;
        this.m21 *= d;
        this.m02 = this.m10 * this.m21 - this.m11 * this.m20;
        this.m12 = this.m01 * this.m20 - this.m00 * this.m21;
        this.m22 = this.m00 * this.m11 - this.m01 * this.m10;
    }

    public final void normalizeCP(Matrix3d matrix3d) {
        double d = 1.0 / Math.sqrt(matrix3d.m00 * matrix3d.m00 + matrix3d.m10 * matrix3d.m10 + matrix3d.m20 * matrix3d.m20);
        this.m00 = matrix3d.m00 * d;
        this.m10 = matrix3d.m10 * d;
        this.m20 = matrix3d.m20 * d;
        d = 1.0 / Math.sqrt(matrix3d.m01 * matrix3d.m01 + matrix3d.m11 * matrix3d.m11 + matrix3d.m21 * matrix3d.m21);
        this.m01 = matrix3d.m01 * d;
        this.m11 = matrix3d.m11 * d;
        this.m21 = matrix3d.m21 * d;
        this.m02 = this.m10 * this.m21 - this.m11 * this.m20;
        this.m12 = this.m01 * this.m20 - this.m00 * this.m21;
        this.m22 = this.m00 * this.m11 - this.m01 * this.m10;
    }

    public boolean equals(Matrix3d matrix3d) {
        try {
            return this.m00 == matrix3d.m00 && this.m01 == matrix3d.m01 && this.m02 == matrix3d.m02 && this.m10 == matrix3d.m10 && this.m11 == matrix3d.m11 && this.m12 == matrix3d.m12 && this.m20 == matrix3d.m20 && this.m21 == matrix3d.m21 && this.m22 == matrix3d.m22;
        }
        catch (NullPointerException nullPointerException) {
            return false;
        }
    }

    public boolean equals(Object object) {
        try {
            Matrix3d matrix3d = (Matrix3d)object;
            return this.m00 == matrix3d.m00 && this.m01 == matrix3d.m01 && this.m02 == matrix3d.m02 && this.m10 == matrix3d.m10 && this.m11 == matrix3d.m11 && this.m12 == matrix3d.m12 && this.m20 == matrix3d.m20 && this.m21 == matrix3d.m21 && this.m22 == matrix3d.m22;
        }
        catch (ClassCastException classCastException) {
            return false;
        }
        catch (NullPointerException nullPointerException) {
            return false;
        }
    }

    public boolean epsilonEquals(Matrix3d matrix3d, double d) {
        double d2 = this.m00 - matrix3d.m00;
        double d3 = d2 < 0.0 ? -d2 : d2;
        if (d3 > d) {
            return false;
        }
        d2 = this.m01 - matrix3d.m01;
        double d4 = d2 < 0.0 ? -d2 : d2;
        if (d4 > d) {
            return false;
        }
        d2 = this.m02 - matrix3d.m02;
        double d5 = d2 < 0.0 ? -d2 : d2;
        if (d5 > d) {
            return false;
        }
        d2 = this.m10 - matrix3d.m10;
        double d6 = d2 < 0.0 ? -d2 : d2;
        if (d6 > d) {
            return false;
        }
        d2 = this.m11 - matrix3d.m11;
        double d7 = d2 < 0.0 ? -d2 : d2;
        if (d7 > d) {
            return false;
        }
        d2 = this.m12 - matrix3d.m12;
        double d8 = d2 < 0.0 ? -d2 : d2;
        if (d8 > d) {
            return false;
        }
        d2 = this.m20 - matrix3d.m20;
        double d9 = d2 < 0.0 ? -d2 : d2;
        if (d9 > d) {
            return false;
        }
        d2 = this.m21 - matrix3d.m21;
        double d10 = d2 < 0.0 ? -d2 : d2;
        if (d10 > d) {
            return false;
        }
        d2 = this.m22 - matrix3d.m22;
        double d11 = d2 < 0.0 ? -d2 : d2;
        return !(d11 > d);
    }

    public int hashCode() {
        long l = 1L;
        l = 31L * l + VecMathUtil.doubleToLongBits(this.m00);
        l = 31L * l + VecMathUtil.doubleToLongBits(this.m01);
        l = 31L * l + VecMathUtil.doubleToLongBits(this.m02);
        l = 31L * l + VecMathUtil.doubleToLongBits(this.m10);
        l = 31L * l + VecMathUtil.doubleToLongBits(this.m11);
        l = 31L * l + VecMathUtil.doubleToLongBits(this.m12);
        l = 31L * l + VecMathUtil.doubleToLongBits(this.m20);
        l = 31L * l + VecMathUtil.doubleToLongBits(this.m21);
        l = 31L * l + VecMathUtil.doubleToLongBits(this.m22);
        return (int)(l ^ l >> 32);
    }

    public final void setZero() {
        this.m00 = 0.0;
        this.m01 = 0.0;
        this.m02 = 0.0;
        this.m10 = 0.0;
        this.m11 = 0.0;
        this.m12 = 0.0;
        this.m20 = 0.0;
        this.m21 = 0.0;
        this.m22 = 0.0;
    }

    public final void negate() {
        this.m00 = -this.m00;
        this.m01 = -this.m01;
        this.m02 = -this.m02;
        this.m10 = -this.m10;
        this.m11 = -this.m11;
        this.m12 = -this.m12;
        this.m20 = -this.m20;
        this.m21 = -this.m21;
        this.m22 = -this.m22;
    }

    public final void negate(Matrix3d matrix3d) {
        this.m00 = -matrix3d.m00;
        this.m01 = -matrix3d.m01;
        this.m02 = -matrix3d.m02;
        this.m10 = -matrix3d.m10;
        this.m11 = -matrix3d.m11;
        this.m12 = -matrix3d.m12;
        this.m20 = -matrix3d.m20;
        this.m21 = -matrix3d.m21;
        this.m22 = -matrix3d.m22;
    }

    public final void transform(Tuple3d tuple3d) {
        double d = this.m00 * tuple3d.x + this.m01 * tuple3d.y + this.m02 * tuple3d.z;
        double d2 = this.m10 * tuple3d.x + this.m11 * tuple3d.y + this.m12 * tuple3d.z;
        double d3 = this.m20 * tuple3d.x + this.m21 * tuple3d.y + this.m22 * tuple3d.z;
        tuple3d.set(d, d2, d3);
    }

    public final void transform(Tuple3d tuple3d, Tuple3d tuple3d2) {
        double d = this.m00 * tuple3d.x + this.m01 * tuple3d.y + this.m02 * tuple3d.z;
        double d2 = this.m10 * tuple3d.x + this.m11 * tuple3d.y + this.m12 * tuple3d.z;
        tuple3d2.z = this.m20 * tuple3d.x + this.m21 * tuple3d.y + this.m22 * tuple3d.z;
        tuple3d2.x = d;
        tuple3d2.y = d2;
    }

    final void getScaleRotate(double[] arrd, double[] arrd2) {
        double[] arrd3 = new double[]{this.m00, this.m01, this.m02, this.m10, this.m11, this.m12, this.m20, this.m21, this.m22};
        Matrix3d.compute_svd(arrd3, arrd, arrd2);
    }

    static void compute_svd(double[] arrd, double[] arrd2, double[] arrd3) {
        int n;
        double d;
        double[] arrd4 = new double[9];
        double[] arrd5 = new double[9];
        double[] arrd6 = new double[9];
        double[] arrd7 = new double[9];
        double[] arrd8 = arrd6;
        double[] arrd9 = arrd7;
        double[] arrd10 = new double[9];
        double[] arrd11 = new double[3];
        double[] arrd12 = new double[3];
        int n2 = 0;
        for (n = 0; n < 9; ++n) {
            arrd10[n] = arrd[n];
        }
        if (arrd[3] * arrd[3] < 1.110223024E-16) {
            arrd4[0] = 1.0;
            arrd4[1] = 0.0;
            arrd4[2] = 0.0;
            arrd4[3] = 0.0;
            arrd4[4] = 1.0;
            arrd4[5] = 0.0;
            arrd4[6] = 0.0;
            arrd4[7] = 0.0;
            arrd4[8] = 1.0;
        } else if (arrd[0] * arrd[0] < 1.110223024E-16) {
            arrd8[0] = arrd[0];
            arrd8[1] = arrd[1];
            arrd8[2] = arrd[2];
            arrd[0] = arrd[3];
            arrd[1] = arrd[4];
            arrd[2] = arrd[5];
            arrd[3] = -arrd8[0];
            arrd[4] = -arrd8[1];
            arrd[5] = -arrd8[2];
            arrd4[0] = 0.0;
            arrd4[1] = 1.0;
            arrd4[2] = 0.0;
            arrd4[3] = -1.0;
            arrd4[4] = 0.0;
            arrd4[5] = 0.0;
            arrd4[6] = 0.0;
            arrd4[7] = 0.0;
            arrd4[8] = 1.0;
        } else {
            d = 1.0 / Math.sqrt(arrd[0] * arrd[0] + arrd[3] * arrd[3]);
            double d2 = arrd[0] * d;
            double d3 = arrd[3] * d;
            arrd8[0] = d2 * arrd[0] + d3 * arrd[3];
            arrd8[1] = d2 * arrd[1] + d3 * arrd[4];
            arrd8[2] = d2 * arrd[2] + d3 * arrd[5];
            arrd[3] = -d3 * arrd[0] + d2 * arrd[3];
            arrd[4] = -d3 * arrd[1] + d2 * arrd[4];
            arrd[5] = -d3 * arrd[2] + d2 * arrd[5];
            arrd[0] = arrd8[0];
            arrd[1] = arrd8[1];
            arrd[2] = arrd8[2];
            arrd4[0] = d2;
            arrd4[1] = d3;
            arrd4[2] = 0.0;
            arrd4[3] = -d3;
            arrd4[4] = d2;
            arrd4[5] = 0.0;
            arrd4[6] = 0.0;
            arrd4[7] = 0.0;
            arrd4[8] = 1.0;
        }
        if (!(arrd[6] * arrd[6] < 1.110223024E-16)) {
            if (arrd[0] * arrd[0] < 1.110223024E-16) {
                arrd8[0] = arrd[0];
                arrd8[1] = arrd[1];
                arrd8[2] = arrd[2];
                arrd[0] = arrd[6];
                arrd[1] = arrd[7];
                arrd[2] = arrd[8];
                arrd[6] = -arrd8[0];
                arrd[7] = -arrd8[1];
                arrd[8] = -arrd8[2];
                arrd8[0] = arrd4[0];
                arrd8[1] = arrd4[1];
                arrd8[2] = arrd4[2];
                arrd4[0] = arrd4[6];
                arrd4[1] = arrd4[7];
                arrd4[2] = arrd4[8];
                arrd4[6] = -arrd8[0];
                arrd4[7] = -arrd8[1];
                arrd4[8] = -arrd8[2];
            } else {
                d = 1.0 / Math.sqrt(arrd[0] * arrd[0] + arrd[6] * arrd[6]);
                double d4 = arrd[0] * d;
                double d5 = arrd[6] * d;
                arrd8[0] = d4 * arrd[0] + d5 * arrd[6];
                arrd8[1] = d4 * arrd[1] + d5 * arrd[7];
                arrd8[2] = d4 * arrd[2] + d5 * arrd[8];
                arrd[6] = -d5 * arrd[0] + d4 * arrd[6];
                arrd[7] = -d5 * arrd[1] + d4 * arrd[7];
                arrd[8] = -d5 * arrd[2] + d4 * arrd[8];
                arrd[0] = arrd8[0];
                arrd[1] = arrd8[1];
                arrd[2] = arrd8[2];
                arrd8[0] = d4 * arrd4[0];
                arrd8[1] = d4 * arrd4[1];
                arrd4[2] = d5;
                arrd8[6] = -arrd4[0] * d5;
                arrd8[7] = -arrd4[1] * d5;
                arrd4[8] = d4;
                arrd4[0] = arrd8[0];
                arrd4[1] = arrd8[1];
                arrd4[6] = arrd8[6];
                arrd4[7] = arrd8[7];
            }
        }
        if (arrd[2] * arrd[2] < 1.110223024E-16) {
            arrd5[0] = 1.0;
            arrd5[1] = 0.0;
            arrd5[2] = 0.0;
            arrd5[3] = 0.0;
            arrd5[4] = 1.0;
            arrd5[5] = 0.0;
            arrd5[6] = 0.0;
            arrd5[7] = 0.0;
            arrd5[8] = 1.0;
        } else if (arrd[1] * arrd[1] < 1.110223024E-16) {
            arrd8[2] = arrd[2];
            arrd8[5] = arrd[5];
            arrd8[8] = arrd[8];
            arrd[2] = -arrd[1];
            arrd[5] = -arrd[4];
            arrd[8] = -arrd[7];
            arrd[1] = arrd8[2];
            arrd[4] = arrd8[5];
            arrd[7] = arrd8[8];
            arrd5[0] = 1.0;
            arrd5[1] = 0.0;
            arrd5[2] = 0.0;
            arrd5[3] = 0.0;
            arrd5[4] = 0.0;
            arrd5[5] = -1.0;
            arrd5[6] = 0.0;
            arrd5[7] = 1.0;
            arrd5[8] = 0.0;
        } else {
            d = 1.0 / Math.sqrt(arrd[1] * arrd[1] + arrd[2] * arrd[2]);
            double d6 = arrd[1] * d;
            double d7 = arrd[2] * d;
            arrd8[1] = d6 * arrd[1] + d7 * arrd[2];
            arrd[2] = -d7 * arrd[1] + d6 * arrd[2];
            arrd[1] = arrd8[1];
            arrd8[4] = d6 * arrd[4] + d7 * arrd[5];
            arrd[5] = -d7 * arrd[4] + d6 * arrd[5];
            arrd[4] = arrd8[4];
            arrd8[7] = d6 * arrd[7] + d7 * arrd[8];
            arrd[8] = -d7 * arrd[7] + d6 * arrd[8];
            arrd[7] = arrd8[7];
            arrd5[0] = 1.0;
            arrd5[1] = 0.0;
            arrd5[2] = 0.0;
            arrd5[3] = 0.0;
            arrd5[4] = d6;
            arrd5[5] = -d7;
            arrd5[6] = 0.0;
            arrd5[7] = d7;
            arrd5[8] = d6;
        }
        if (!(arrd[7] * arrd[7] < 1.110223024E-16)) {
            if (arrd[4] * arrd[4] < 1.110223024E-16) {
                arrd8[3] = arrd[3];
                arrd8[4] = arrd[4];
                arrd8[5] = arrd[5];
                arrd[3] = arrd[6];
                arrd[4] = arrd[7];
                arrd[5] = arrd[8];
                arrd[6] = -arrd8[3];
                arrd[7] = -arrd8[4];
                arrd[8] = -arrd8[5];
                arrd8[3] = arrd4[3];
                arrd8[4] = arrd4[4];
                arrd8[5] = arrd4[5];
                arrd4[3] = arrd4[6];
                arrd4[4] = arrd4[7];
                arrd4[5] = arrd4[8];
                arrd4[6] = -arrd8[3];
                arrd4[7] = -arrd8[4];
                arrd4[8] = -arrd8[5];
            } else {
                d = 1.0 / Math.sqrt(arrd[4] * arrd[4] + arrd[7] * arrd[7]);
                double d8 = arrd[4] * d;
                double d9 = arrd[7] * d;
                arrd8[3] = d8 * arrd[3] + d9 * arrd[6];
                arrd[6] = -d9 * arrd[3] + d8 * arrd[6];
                arrd[3] = arrd8[3];
                arrd8[4] = d8 * arrd[4] + d9 * arrd[7];
                arrd[7] = -d9 * arrd[4] + d8 * arrd[7];
                arrd[4] = arrd8[4];
                arrd8[5] = d8 * arrd[5] + d9 * arrd[8];
                arrd[8] = -d9 * arrd[5] + d8 * arrd[8];
                arrd[5] = arrd8[5];
                arrd8[3] = d8 * arrd4[3] + d9 * arrd4[6];
                arrd4[6] = -d9 * arrd4[3] + d8 * arrd4[6];
                arrd4[3] = arrd8[3];
                arrd8[4] = d8 * arrd4[4] + d9 * arrd4[7];
                arrd4[7] = -d9 * arrd4[4] + d8 * arrd4[7];
                arrd4[4] = arrd8[4];
                arrd8[5] = d8 * arrd4[5] + d9 * arrd4[8];
                arrd4[8] = -d9 * arrd4[5] + d8 * arrd4[8];
                arrd4[5] = arrd8[5];
            }
        }
        arrd9[0] = arrd[0];
        arrd9[1] = arrd[4];
        arrd9[2] = arrd[8];
        arrd11[0] = arrd[1];
        arrd11[1] = arrd[5];
        if (!(arrd11[0] * arrd11[0] < 1.110223024E-16) || !(arrd11[1] * arrd11[1] < 1.110223024E-16)) {
            Matrix3d.compute_qr(arrd9, arrd11, arrd4, arrd5);
        }
        arrd12[0] = arrd9[0];
        arrd12[1] = arrd9[1];
        arrd12[2] = arrd9[2];
        if (Matrix3d.almostEqual(Math.abs(arrd12[0]), 1.0) && Matrix3d.almostEqual(Math.abs(arrd12[1]), 1.0) && Matrix3d.almostEqual(Math.abs(arrd12[2]), 1.0)) {
            for (n = 0; n < 3; ++n) {
                if (!(arrd12[n] < 0.0)) continue;
                ++n2;
            }
            if (n2 == 0 || n2 == 2) {
                arrd2[2] = 1.0;
                arrd2[1] = 1.0;
                arrd2[0] = 1.0;
                for (n = 0; n < 9; ++n) {
                    arrd3[n] = arrd10[n];
                }
                return;
            }
        }
        Matrix3d.transpose_mat(arrd4, arrd6);
        Matrix3d.transpose_mat(arrd5, arrd7);
        Matrix3d.svdReorder(arrd, arrd6, arrd7, arrd12, arrd3, arrd2);
    }

    static void svdReorder(double[] arrd, double[] arrd2, double[] arrd3, double[] arrd4, double[] arrd5, double[] arrd6) {
        int[] arrn = new int[3];
        int[] arrn2 = new int[3];
        double[] arrd7 = new double[3];
        double[] arrd8 = new double[9];
        if (arrd4[0] < 0.0) {
            arrd4[0] = -arrd4[0];
            arrd3[0] = -arrd3[0];
            arrd3[1] = -arrd3[1];
            arrd3[2] = -arrd3[2];
        }
        if (arrd4[1] < 0.0) {
            arrd4[1] = -arrd4[1];
            arrd3[3] = -arrd3[3];
            arrd3[4] = -arrd3[4];
            arrd3[5] = -arrd3[5];
        }
        if (arrd4[2] < 0.0) {
            arrd4[2] = -arrd4[2];
            arrd3[6] = -arrd3[6];
            arrd3[7] = -arrd3[7];
            arrd3[8] = -arrd3[8];
        }
        Matrix3d.mat_mul(arrd2, arrd3, arrd8);
        if (Matrix3d.almostEqual(Math.abs(arrd4[0]), Math.abs(arrd4[1])) && Matrix3d.almostEqual(Math.abs(arrd4[1]), Math.abs(arrd4[2]))) {
            int n;
            for (n = 0; n < 9; ++n) {
                arrd5[n] = arrd8[n];
            }
            for (n = 0; n < 3; ++n) {
                arrd6[n] = arrd4[n];
            }
        } else {
            int n;
            int n2;
            int n3;
            if (arrd4[0] > arrd4[1]) {
                if (arrd4[0] > arrd4[2]) {
                    if (arrd4[2] > arrd4[1]) {
                        arrn[0] = 0;
                        arrn[1] = 2;
                        arrn[2] = 1;
                    } else {
                        arrn[0] = 0;
                        arrn[1] = 1;
                        arrn[2] = 2;
                    }
                } else {
                    arrn[0] = 2;
                    arrn[1] = 0;
                    arrn[2] = 1;
                }
            } else if (arrd4[1] > arrd4[2]) {
                if (arrd4[2] > arrd4[0]) {
                    arrn[0] = 1;
                    arrn[1] = 2;
                    arrn[2] = 0;
                } else {
                    arrn[0] = 1;
                    arrn[1] = 0;
                    arrn[2] = 2;
                }
            } else {
                arrn[0] = 2;
                arrn[1] = 1;
                arrn[2] = 0;
            }
            arrd7[0] = arrd[0] * arrd[0] + arrd[1] * arrd[1] + arrd[2] * arrd[2];
            arrd7[1] = arrd[3] * arrd[3] + arrd[4] * arrd[4] + arrd[5] * arrd[5];
            arrd7[2] = arrd[6] * arrd[6] + arrd[7] * arrd[7] + arrd[8] * arrd[8];
            if (arrd7[0] > arrd7[1]) {
                if (arrd7[0] > arrd7[2]) {
                    if (arrd7[2] > arrd7[1]) {
                        n3 = 0;
                        n2 = 1;
                        n = 2;
                    } else {
                        n3 = 0;
                        n = 1;
                        n2 = 2;
                    }
                } else {
                    n2 = 0;
                    n3 = 1;
                    n = 2;
                }
            } else if (arrd7[1] > arrd7[2]) {
                if (arrd7[2] > arrd7[0]) {
                    n = 0;
                    n2 = 1;
                    n3 = 2;
                } else {
                    n = 0;
                    n3 = 1;
                    n2 = 2;
                }
            } else {
                n2 = 0;
                n = 1;
                n3 = 2;
            }
            int n4 = arrn[n3];
            arrd6[0] = arrd4[n4];
            n4 = arrn[n];
            arrd6[1] = arrd4[n4];
            n4 = arrn[n2];
            arrd6[2] = arrd4[n4];
            n4 = arrn[n3];
            arrd5[0] = arrd8[n4];
            n4 = arrn[n3] + 3;
            arrd5[3] = arrd8[n4];
            n4 = arrn[n3] + 6;
            arrd5[6] = arrd8[n4];
            n4 = arrn[n];
            arrd5[1] = arrd8[n4];
            n4 = arrn[n] + 3;
            arrd5[4] = arrd8[n4];
            n4 = arrn[n] + 6;
            arrd5[7] = arrd8[n4];
            n4 = arrn[n2];
            arrd5[2] = arrd8[n4];
            n4 = arrn[n2] + 3;
            arrd5[5] = arrd8[n4];
            n4 = arrn[n2] + 6;
            arrd5[8] = arrd8[n4];
        }
    }

    static int compute_qr(double[] arrd, double[] arrd2, double[] arrd3, double[] arrd4) {
        double d;
        double d2;
        double[] arrd5 = new double[2];
        double[] arrd6 = new double[2];
        double[] arrd7 = new double[2];
        double[] arrd8 = new double[2];
        double[] arrd9 = new double[9];
        double d3 = 1.0;
        double d4 = -1.0;
        boolean bl = false;
        int n = 1;
        if (Math.abs(arrd2[1]) < 4.89E-15 || Math.abs(arrd2[0]) < 4.89E-15) {
            bl = true;
        }
        for (int i = 0; i < 10 && !bl; ++i) {
            double d5 = Matrix3d.compute_shift(arrd[1], arrd2[1], arrd[2]);
            double d6 = (Math.abs(arrd[0]) - d5) * (Matrix3d.d_sign(d3, arrd[0]) + d5 / arrd[0]);
            double d7 = arrd2[0];
            double d8 = Matrix3d.compute_rot(d6, d7, arrd8, arrd6, 0, n);
            d6 = arrd6[0] * arrd[0] + arrd8[0] * arrd2[0];
            arrd2[0] = arrd6[0] * arrd2[0] - arrd8[0] * arrd[0];
            d7 = arrd8[0] * arrd[1];
            arrd[1] = arrd6[0] * arrd[1];
            d8 = Matrix3d.compute_rot(d6, d7, arrd7, arrd5, 0, n);
            n = 0;
            arrd[0] = d8;
            d6 = arrd5[0] * arrd2[0] + arrd7[0] * arrd[1];
            arrd[1] = arrd5[0] * arrd[1] - arrd7[0] * arrd2[0];
            d7 = arrd7[0] * arrd2[1];
            arrd2[1] = arrd5[0] * arrd2[1];
            arrd2[0] = d8 = Matrix3d.compute_rot(d6, d7, arrd8, arrd6, 1, n);
            d6 = arrd6[1] * arrd[1] + arrd8[1] * arrd2[1];
            arrd2[1] = arrd6[1] * arrd2[1] - arrd8[1] * arrd[1];
            d7 = arrd8[1] * arrd[2];
            arrd[2] = arrd6[1] * arrd[2];
            arrd[1] = d8 = Matrix3d.compute_rot(d6, d7, arrd7, arrd5, 1, n);
            d6 = arrd5[1] * arrd2[1] + arrd7[1] * arrd[2];
            arrd[2] = arrd5[1] * arrd[2] - arrd7[1] * arrd2[1];
            arrd2[1] = d6;
            d2 = arrd3[0];
            arrd3[0] = arrd5[0] * d2 + arrd7[0] * arrd3[3];
            arrd3[3] = -arrd7[0] * d2 + arrd5[0] * arrd3[3];
            d2 = arrd3[1];
            arrd3[1] = arrd5[0] * d2 + arrd7[0] * arrd3[4];
            arrd3[4] = -arrd7[0] * d2 + arrd5[0] * arrd3[4];
            d2 = arrd3[2];
            arrd3[2] = arrd5[0] * d2 + arrd7[0] * arrd3[5];
            arrd3[5] = -arrd7[0] * d2 + arrd5[0] * arrd3[5];
            d2 = arrd3[3];
            arrd3[3] = arrd5[1] * d2 + arrd7[1] * arrd3[6];
            arrd3[6] = -arrd7[1] * d2 + arrd5[1] * arrd3[6];
            d2 = arrd3[4];
            arrd3[4] = arrd5[1] * d2 + arrd7[1] * arrd3[7];
            arrd3[7] = -arrd7[1] * d2 + arrd5[1] * arrd3[7];
            d2 = arrd3[5];
            arrd3[5] = arrd5[1] * d2 + arrd7[1] * arrd3[8];
            arrd3[8] = -arrd7[1] * d2 + arrd5[1] * arrd3[8];
            d = arrd4[0];
            arrd4[0] = arrd6[0] * d + arrd8[0] * arrd4[1];
            arrd4[1] = -arrd8[0] * d + arrd6[0] * arrd4[1];
            d = arrd4[3];
            arrd4[3] = arrd6[0] * d + arrd8[0] * arrd4[4];
            arrd4[4] = -arrd8[0] * d + arrd6[0] * arrd4[4];
            d = arrd4[6];
            arrd4[6] = arrd6[0] * d + arrd8[0] * arrd4[7];
            arrd4[7] = -arrd8[0] * d + arrd6[0] * arrd4[7];
            d = arrd4[1];
            arrd4[1] = arrd6[1] * d + arrd8[1] * arrd4[2];
            arrd4[2] = -arrd8[1] * d + arrd6[1] * arrd4[2];
            d = arrd4[4];
            arrd4[4] = arrd6[1] * d + arrd8[1] * arrd4[5];
            arrd4[5] = -arrd8[1] * d + arrd6[1] * arrd4[5];
            d = arrd4[7];
            arrd4[7] = arrd6[1] * d + arrd8[1] * arrd4[8];
            arrd4[8] = -arrd8[1] * d + arrd6[1] * arrd4[8];
            arrd9[0] = arrd[0];
            arrd9[1] = arrd2[0];
            arrd9[2] = 0.0;
            arrd9[3] = 0.0;
            arrd9[4] = arrd[1];
            arrd9[5] = arrd2[1];
            arrd9[6] = 0.0;
            arrd9[7] = 0.0;
            arrd9[8] = arrd[2];
            if (!(Math.abs(arrd2[1]) < 4.89E-15) && !(Math.abs(arrd2[0]) < 4.89E-15)) continue;
            bl = true;
        }
        if (Math.abs(arrd2[1]) < 4.89E-15) {
            Matrix3d.compute_2X2(arrd[0], arrd2[0], arrd[1], arrd, arrd7, arrd5, arrd8, arrd6, 0);
            d2 = arrd3[0];
            arrd3[0] = arrd5[0] * d2 + arrd7[0] * arrd3[3];
            arrd3[3] = -arrd7[0] * d2 + arrd5[0] * arrd3[3];
            d2 = arrd3[1];
            arrd3[1] = arrd5[0] * d2 + arrd7[0] * arrd3[4];
            arrd3[4] = -arrd7[0] * d2 + arrd5[0] * arrd3[4];
            d2 = arrd3[2];
            arrd3[2] = arrd5[0] * d2 + arrd7[0] * arrd3[5];
            arrd3[5] = -arrd7[0] * d2 + arrd5[0] * arrd3[5];
            d = arrd4[0];
            arrd4[0] = arrd6[0] * d + arrd8[0] * arrd4[1];
            arrd4[1] = -arrd8[0] * d + arrd6[0] * arrd4[1];
            d = arrd4[3];
            arrd4[3] = arrd6[0] * d + arrd8[0] * arrd4[4];
            arrd4[4] = -arrd8[0] * d + arrd6[0] * arrd4[4];
            d = arrd4[6];
            arrd4[6] = arrd6[0] * d + arrd8[0] * arrd4[7];
            arrd4[7] = -arrd8[0] * d + arrd6[0] * arrd4[7];
        } else {
            Matrix3d.compute_2X2(arrd[1], arrd2[1], arrd[2], arrd, arrd7, arrd5, arrd8, arrd6, 1);
            d2 = arrd3[3];
            arrd3[3] = arrd5[0] * d2 + arrd7[0] * arrd3[6];
            arrd3[6] = -arrd7[0] * d2 + arrd5[0] * arrd3[6];
            d2 = arrd3[4];
            arrd3[4] = arrd5[0] * d2 + arrd7[0] * arrd3[7];
            arrd3[7] = -arrd7[0] * d2 + arrd5[0] * arrd3[7];
            d2 = arrd3[5];
            arrd3[5] = arrd5[0] * d2 + arrd7[0] * arrd3[8];
            arrd3[8] = -arrd7[0] * d2 + arrd5[0] * arrd3[8];
            d = arrd4[1];
            arrd4[1] = arrd6[0] * d + arrd8[0] * arrd4[2];
            arrd4[2] = -arrd8[0] * d + arrd6[0] * arrd4[2];
            d = arrd4[4];
            arrd4[4] = arrd6[0] * d + arrd8[0] * arrd4[5];
            arrd4[5] = -arrd8[0] * d + arrd6[0] * arrd4[5];
            d = arrd4[7];
            arrd4[7] = arrd6[0] * d + arrd8[0] * arrd4[8];
            arrd4[8] = -arrd8[0] * d + arrd6[0] * arrd4[8];
        }
        return 0;
    }

    static double max(double d, double d2) {
        if (d > d2) {
            return d;
        }
        return d2;
    }

    static double min(double d, double d2) {
        if (d < d2) {
            return d;
        }
        return d2;
    }

    static double d_sign(double d, double d2) {
        double d3 = d >= 0.0 ? d : -d;
        return d2 >= 0.0 ? d3 : -d3;
    }

    static double compute_shift(double d, double d2, double d3) {
        double d4;
        double d5 = Math.abs(d);
        double d6 = Math.abs(d2);
        double d7 = Math.abs(d3);
        double d8 = Matrix3d.min(d5, d7);
        double d9 = Matrix3d.max(d5, d7);
        if (d8 == 0.0) {
            d4 = 0.0;
            if (d9 != 0.0) {
                double d10 = Matrix3d.min(d9, d6) / Matrix3d.max(d9, d6);
            }
        } else if (d6 < d9) {
            double d11 = d8 / d9 + 1.0;
            double d12 = (d9 - d8) / d9;
            double d13 = d6 / d9;
            double d14 = d13 * d13;
            double d15 = 2.0 / (Math.sqrt(d11 * d11 + d14) + Math.sqrt(d12 * d12 + d14));
            d4 = d8 * d15;
        } else {
            double d16 = d9 / d6;
            if (d16 == 0.0) {
                d4 = d8 * d9 / d6;
            } else {
                double d17 = d8 / d9 + 1.0;
                double d18 = (d9 - d8) / d9;
                double d19 = d17 * d16;
                double d20 = d18 * d16;
                double d21 = 1.0 / (Math.sqrt(d19 * d19 + 1.0) + Math.sqrt(d20 * d20 + 1.0));
                d4 = d8 * d21 * d16;
                d4 += d4;
            }
        }
        return d4;
    }

    static int compute_2X2(double d, double d2, double d3, double[] arrd, double[] arrd2, double[] arrd3, double[] arrd4, double[] arrd5, int n) {
        double d4;
        double d5;
        double d6 = 2.0;
        double d7 = 1.0;
        double d8 = arrd[0];
        double d9 = arrd[1];
        double d10 = 0.0;
        double d11 = 0.0;
        double d12 = 0.0;
        double d13 = 0.0;
        double d14 = 0.0;
        double d15 = d;
        double d16 = Math.abs(d15);
        double d17 = d3;
        double d18 = Math.abs(d3);
        int n2 = 1;
        boolean bl = d18 > d16;
        if (bl) {
            n2 = 3;
            double d19 = d15;
            d15 = d17;
            d17 = d19;
            d19 = d16;
            d16 = d18;
            d18 = d19;
        }
        if ((d5 = Math.abs(d4 = d2)) == 0.0) {
            arrd[1] = d18;
            arrd[0] = d16;
            d10 = 1.0;
            d11 = 1.0;
            d12 = 0.0;
            d13 = 0.0;
        } else {
            boolean bl2 = true;
            if (d5 > d16) {
                n2 = 2;
                if (d16 / d5 < 1.110223024E-16) {
                    bl2 = false;
                    d8 = d5;
                    d9 = d18 > 1.0 ? d16 / (d5 / d18) : d16 / d5 * d18;
                    d10 = 1.0;
                    d12 = d17 / d4;
                    d13 = 1.0;
                    d11 = d15 / d4;
                }
            }
            if (bl2) {
                double d20 = d16 - d18;
                double d21 = d20 == d16 ? 1.0 : d20 / d16;
                double d22 = d4 / d15;
                double d23 = 2.0 - d21;
                double d24 = d22 * d22;
                double d25 = d23 * d23;
                double d26 = Math.sqrt(d25 + d24);
                double d27 = d21 == 0.0 ? Math.abs(d22) : Math.sqrt(d21 * d21 + d24);
                double d28 = (d26 + d27) * 0.5;
                if (d5 > d16) {
                    n2 = 2;
                    if (d16 / d5 < 1.110223024E-16) {
                        bl2 = false;
                        d8 = d5;
                        d9 = d18 > 1.0 ? d16 / (d5 / d18) : d16 / d5 * d18;
                        d10 = 1.0;
                        d12 = d17 / d4;
                        d13 = 1.0;
                        d11 = d15 / d4;
                    }
                }
                if (bl2) {
                    d20 = d16 - d18;
                    d21 = d20 == d16 ? 1.0 : d20 / d16;
                    d22 = d4 / d15;
                    d23 = 2.0 - d21;
                    d24 = d22 * d22;
                    d25 = d23 * d23;
                    d26 = Math.sqrt(d25 + d24);
                    d27 = d21 == 0.0 ? Math.abs(d22) : Math.sqrt(d21 * d21 + d24);
                    d28 = (d26 + d27) * 0.5;
                    d9 = d18 / d28;
                    d8 = d16 * d28;
                    d23 = d24 == 0.0 ? (d21 == 0.0 ? Matrix3d.d_sign(d6, d15) * Matrix3d.d_sign(d7, d4) : d4 / Matrix3d.d_sign(d20, d15) + d22 / d23) : (d22 / (d26 + d23) + d22 / (d27 + d21)) * (d28 + 1.0);
                    d21 = Math.sqrt(d23 * d23 + 4.0);
                    d11 = 2.0 / d21;
                    d13 = d23 / d21;
                    d10 = (d11 + d13 * d22) / d28;
                    d12 = d17 / d15 * d13 / d28;
                }
            }
            if (bl) {
                arrd3[0] = d13;
                arrd2[0] = d11;
                arrd5[0] = d12;
                arrd4[0] = d10;
            } else {
                arrd3[0] = d10;
                arrd2[0] = d12;
                arrd5[0] = d11;
                arrd4[0] = d13;
            }
            if (n2 == 1) {
                d14 = Matrix3d.d_sign(d7, arrd5[0]) * Matrix3d.d_sign(d7, arrd3[0]) * Matrix3d.d_sign(d7, d);
            }
            if (n2 == 2) {
                d14 = Matrix3d.d_sign(d7, arrd4[0]) * Matrix3d.d_sign(d7, arrd3[0]) * Matrix3d.d_sign(d7, d2);
            }
            if (n2 == 3) {
                d14 = Matrix3d.d_sign(d7, arrd4[0]) * Matrix3d.d_sign(d7, arrd2[0]) * Matrix3d.d_sign(d7, d3);
            }
            arrd[n] = Matrix3d.d_sign(d8, d14);
            double d29 = d14 * Matrix3d.d_sign(d7, d) * Matrix3d.d_sign(d7, d3);
            arrd[n + 1] = Matrix3d.d_sign(d9, d29);
        }
        return 0;
    }

    static double compute_rot(double d, double d2, double[] arrd, double[] arrd2, int n, int n2) {
        double d3;
        double d4;
        double d5;
        if (d2 == 0.0) {
            d5 = 1.0;
            d3 = 0.0;
            d4 = d;
        } else if (d == 0.0) {
            d5 = 0.0;
            d3 = 1.0;
            d4 = d2;
        } else {
            double d6 = d;
            double d7 = d2;
            double d8 = Matrix3d.max(Math.abs(d6), Math.abs(d7));
            if (d8 >= 4.9947976805055876E145) {
                int n3 = 0;
                while (d8 >= 4.9947976805055876E145) {
                    ++n3;
                    d8 = Matrix3d.max(Math.abs(d6 *= 2.002083095183101E-146), Math.abs(d7 *= 2.002083095183101E-146));
                }
                d4 = Math.sqrt(d6 * d6 + d7 * d7);
                d5 = d6 / d4;
                d3 = d7 / d4;
                int n4 = n3;
                for (int i = 1; i <= n3; ++i) {
                    d4 *= 4.9947976805055876E145;
                }
            } else if (d8 <= 2.002083095183101E-146) {
                int n5 = 0;
                while (d8 <= 2.002083095183101E-146) {
                    ++n5;
                    d8 = Matrix3d.max(Math.abs(d6 *= 4.9947976805055876E145), Math.abs(d7 *= 4.9947976805055876E145));
                }
                d4 = Math.sqrt(d6 * d6 + d7 * d7);
                d5 = d6 / d4;
                d3 = d7 / d4;
                int n6 = n5;
                for (int i = 1; i <= n5; ++i) {
                    d4 *= 2.002083095183101E-146;
                }
            } else {
                d4 = Math.sqrt(d6 * d6 + d7 * d7);
                d5 = d6 / d4;
                d3 = d7 / d4;
            }
            if (Math.abs(d) > Math.abs(d2) && d5 < 0.0) {
                d5 = -d5;
                d3 = -d3;
                d4 = -d4;
            }
        }
        arrd[n] = d3;
        arrd2[n] = d5;
        return d4;
    }

    static void print_mat(double[] arrd) {
        for (int i = 0; i < 3; ++i) {
            System.out.println(arrd[i * 3 + 0] + " " + arrd[i * 3 + 1] + " " + arrd[i * 3 + 2] + "\n");
        }
    }

    static void print_det(double[] arrd) {
        double d = arrd[0] * arrd[4] * arrd[8] + arrd[1] * arrd[5] * arrd[6] + arrd[2] * arrd[3] * arrd[7] - arrd[2] * arrd[4] * arrd[6] - arrd[0] * arrd[5] * arrd[7] - arrd[1] * arrd[3] * arrd[8];
        System.out.println("det= " + d);
    }

    static void mat_mul(double[] arrd, double[] arrd2, double[] arrd3) {
        double[] arrd4 = new double[]{arrd[0] * arrd2[0] + arrd[1] * arrd2[3] + arrd[2] * arrd2[6], arrd[0] * arrd2[1] + arrd[1] * arrd2[4] + arrd[2] * arrd2[7], arrd[0] * arrd2[2] + arrd[1] * arrd2[5] + arrd[2] * arrd2[8], arrd[3] * arrd2[0] + arrd[4] * arrd2[3] + arrd[5] * arrd2[6], arrd[3] * arrd2[1] + arrd[4] * arrd2[4] + arrd[5] * arrd2[7], arrd[3] * arrd2[2] + arrd[4] * arrd2[5] + arrd[5] * arrd2[8], arrd[6] * arrd2[0] + arrd[7] * arrd2[3] + arrd[8] * arrd2[6], arrd[6] * arrd2[1] + arrd[7] * arrd2[4] + arrd[8] * arrd2[7], arrd[6] * arrd2[2] + arrd[7] * arrd2[5] + arrd[8] * arrd2[8]};
        for (int i = 0; i < 9; ++i) {
            arrd3[i] = arrd4[i];
        }
    }

    static void transpose_mat(double[] arrd, double[] arrd2) {
        arrd2[0] = arrd[0];
        arrd2[1] = arrd[3];
        arrd2[2] = arrd[6];
        arrd2[3] = arrd[1];
        arrd2[4] = arrd[4];
        arrd2[5] = arrd[7];
        arrd2[6] = arrd[2];
        arrd2[7] = arrd[5];
        arrd2[8] = arrd[8];
    }

    static double max3(double[] arrd) {
        if (arrd[0] > arrd[1]) {
            if (arrd[0] > arrd[2]) {
                return arrd[0];
            }
            return arrd[2];
        }
        if (arrd[1] > arrd[2]) {
            return arrd[1];
        }
        return arrd[2];
    }

    private static final boolean almostEqual(double d, double d2) {
        double d3;
        double d4;
        if (d == d2) {
            return true;
        }
        double d5 = Math.abs(d - d2);
        double d6 = Math.abs(d);
        double d7 = d3 = d6 >= (d4 = Math.abs(d2)) ? d6 : d4;
        if (d5 < 1.0E-6) {
            return true;
        }
        return d5 / d3 < 1.0E-4;
    }

    public Object clone() {
        Matrix3d matrix3d = null;
        try {
            matrix3d = (Matrix3d)super.clone();
        }
        catch (CloneNotSupportedException cloneNotSupportedException) {
            throw new InternalError();
        }
        return matrix3d;
    }
}

