/*
 * Decompiled with CFR 0.148.
 */
package javax.vecmath;

public class SingularMatrixException
extends RuntimeException {
    public SingularMatrixException() {
    }

    public SingularMatrixException(String string) {
        super(string);
    }
}

