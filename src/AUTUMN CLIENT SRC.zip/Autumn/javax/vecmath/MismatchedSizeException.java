/*
 * Decompiled with CFR 0.148.
 */
package javax.vecmath;

public class MismatchedSizeException
extends RuntimeException {
    public MismatchedSizeException() {
    }

    public MismatchedSizeException(String string) {
        super(string);
    }
}

