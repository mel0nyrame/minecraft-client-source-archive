/*
 * Decompiled with CFR 0.148.
 */
package net.minecraft.block;

import net.minecraft.block.BlockButton;

public class BlockButtonStone
extends BlockButton {
    protected BlockButtonStone() {
        super(false);
    }
}

