/*
 * Decompiled with CFR 0.148.
 */
package net.minecraft.block;

import net.minecraft.block.BlockStoneSlabNew;

public class BlockHalfStoneSlabNew
extends BlockStoneSlabNew {
    @Override
    public boolean isDouble() {
        return false;
    }
}

