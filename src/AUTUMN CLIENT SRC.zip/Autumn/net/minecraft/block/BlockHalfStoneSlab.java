/*
 * Decompiled with CFR 0.148.
 */
package net.minecraft.block;

import net.minecraft.block.BlockStoneSlab;

public class BlockHalfStoneSlab
extends BlockStoneSlab {
    @Override
    public boolean isDouble() {
        return false;
    }
}

