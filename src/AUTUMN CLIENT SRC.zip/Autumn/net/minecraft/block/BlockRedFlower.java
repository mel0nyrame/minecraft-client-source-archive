/*
 * Decompiled with CFR 0.148.
 */
package net.minecraft.block;

import net.minecraft.block.BlockFlower;

public class BlockRedFlower
extends BlockFlower {
    @Override
    public BlockFlower.EnumFlowerColor getBlockType() {
        return BlockFlower.EnumFlowerColor.RED;
    }
}

