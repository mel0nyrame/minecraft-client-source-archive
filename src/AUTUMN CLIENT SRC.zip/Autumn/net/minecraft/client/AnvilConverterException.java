/*
 * Decompiled with CFR 0.148.
 */
package net.minecraft.client;

public class AnvilConverterException
extends Exception {
    public AnvilConverterException(String exceptionMessage) {
        super(exceptionMessage);
    }
}

