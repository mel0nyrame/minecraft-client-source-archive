/*
 * Decompiled with CFR 0.148.
 */
package net.minecraft.client.audio;

public interface ISoundEventAccessor<T> {
    public int getWeight();

    public T cloneEntry();
}

