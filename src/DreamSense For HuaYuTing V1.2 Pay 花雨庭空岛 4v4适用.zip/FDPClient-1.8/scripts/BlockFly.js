var scriptName = "BlockFly";
var scriptVersion = 1.5;
var scriptAuthor = "VectorDev";
var towerModule = moduleManager.getModule("Tower");
var scaffoldModule = moduleManager.getModule("Scaffold");

var TowerZ = new TowerZ();

var client;

function TowerZ() {
    this.getName = function() {
        return "BlockFly";
    };

    this.getDescription = function() {
        return "BlockFly";
    };

    this.getCategory = function() {
        return "World";
    };
	
			this.getTag = function() {
		return "HuaYuTing";
	};
	
    this.onEnable = function() {
    }
    this.onUpdate = function() {
        if (mc.gameSettings.keyBindJump.isKeyDown() && !mc.gameSettings.keyBindLeft.isKeyDown() && !mc.gameSettings.keyBindRight.isKeyDown() && !mc.gameSettings.keyBindForward.isKeyDown() && !mc.gameSettings.keyBindBack.isKeyDown()) {
			    mc.thePlayer.motionX = 0;
                mc.thePlayer.motionZ = 0;
                mc.thePlayer.jumpMovementFactor = 0;
				mc.thePlayer.onGround = false;
				towerModule.setState(true)
				scaffoldModule.setState(true)
}else{
			    towerModule.setState(false)
				scaffoldModule.setState(true)
		}
}
    this.onDisable = function () {
        towerModule.setState(false)
		scaffoldModule.setState(false)
    }
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(TowerZ);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}