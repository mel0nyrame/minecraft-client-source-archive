/// api_version=2
var script = registerScript({
    name: "HuaYuTingHop",
    version: "1.0",
    authors: ["LaoShui"]
});
var MovementUtils = Java.type('net.ccbluex.liquidbounce.utils.MovementUtils');
script.registerModule({
    name: "HuaYuTingHop",
    description: "HuaYuTingHop",
    category: "Movement",
    settings: {
	}
}, function (module) {
	module.on("enable", function () {
		mc.timer.timerSpeed = 0.999999;
    });
	module.on("disable", function () {
		mc.timer.timerSpeed = 1.0;
    });
	module.on("update", function () {
		if (mc.thePlayer.onGround && MovementUtils.isMoving()) {
			mc.thePlayer.jump();
		};
	});
});