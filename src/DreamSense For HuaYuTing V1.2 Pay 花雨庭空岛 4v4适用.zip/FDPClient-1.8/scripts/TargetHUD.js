
/// api_version=2
var script = registerScript({
    name: "TargetHUD",
    version: "6.9",
    authors: ["chocopie"]
});
var target
var Fonts = Java.type("net.ccbluex.liquidbounce.ui.font.Fonts");
var GL11 = Java.type("org.lwjgl.opengl.GL11");
var ScaledResolution = Java.type("net.minecraft.client.gui.ScaledResolution");
var Gui = Java.type("net.minecraft.client.gui.Gui");
var GuiInventory = Java.type("net.minecraft.client.gui.inventory.GuiInventory");
var KillAura = Java.type("net.ccbluex.liquidbounce.features.module.modules.combat.KillAura");
var LiquidBounce = Java.type("net.ccbluex.liquidbounce.LiquidBounce");
var Color = Java.type("java.awt.Color");
var EntityPlayer = Java.type("net.minecraft.entity.player.EntityPlayer")

script.registerModule({
    name: "TargetHUD",
    category: "Render", 
    description: "idk"
	
}, function (TargetHUD) {
    TargetHUD.on("enable", function() {
        target = null
    });
    TargetHUD.on("render2D", function(event) {
        var mcWidth = new ScaledResolution(mc).getScaledWidth();
        var mcHeight = new ScaledResolution(mc).getScaledHeight();
        fr = Fonts.font40;
		if ((LiquidBounce.moduleManager.getModule(KillAura.class)).target != null && (LiquidBounce.moduleManager.getModule(KillAura.class)).target instanceof EntityPlayer) {
            target = (LiquidBounce.moduleManager.getModule(KillAura.class)).target
		    var partialTicks = event.getPartialTicks(); 
			var currenthealth = target.getHealth().toFixed(1)
            var hp = mc.thePlayer.getHealth().toFixed(1);
			var maxhealth = target.getMaxHealth()
			var BGColor = new Color(23,23,25,203).getRGB();
			GL11.glPushMatrix();
			Gui.drawRect(mcWidth/2+15, mcHeight/2+44, mcWidth/2+135, mcHeight/2+83, BGColor);//BackGround
            Gui.drawRect(mcWidth/2+28, mcHeight/2+76.5, mcWidth/2+(toPercent(currenthealth,currenthealth)*1.03)+28, mcHeight/2+79.2, new Color(12,12,12,225).getRGB());
            Gui.drawRect(mcWidth/2+28, mcHeight/2+76.5, mcWidth/2+(toPercent(currenthealth,maxhealth)*1.03)+28, mcHeight/2+79.2, new Color(20, 221, 32).getRGB());
            fr.drawStringWithShadow(target.getName(),  mcWidth/2+45, mcHeight/2+49, 0xFFFFFF);
		    mc.fontRendererObj.drawStringWithShadow("§c❤",  mcWidth/2+17, mcHeight/2+73.3, 0xFFFFFF);
            if ((hp - currenthealth) > 0) {
				fr.drawStringWithShadow('Winning', mcWidth/2+45, mcHeight/2+64, 0x6CC312);
			}
			if ((hp - currenthealth) < 0) {
				fr.drawStringWithShadow('Losing', mcWidth/2+45, mcHeight/2+64, 0xFF3300);
			}
			if ((hp - currenthealth) == 0) {
				fr.drawStringWithShadow('Draw', mcWidth/2+45,mcHeight/2+64, 0xFFFF00);
			}
            //GuiInventory.drawEntityOnScreen(mcWidth/2+63,mcHeight/2+72, 22, target.rotationYaw, target.rotationPitch, target);
			GL11.glPopMatrix();
            //drawFace(target,360.7,237.2);
            drawFace(target,mcWidth/2+16.3,mcHeight/2+45.8);
		}
    });
});

function toPercent(num, total) { 
    return (Math.round(num / total * 10000) / 100);
}

function drawFace (target,x,y) {
	mc.getTextureManager().bindTexture(target.getLocationSkin());
	GL11.glEnable(GL11.GL_BLEND); GL11.glColor4f(1, 1, 1, 1);
	Gui.drawScaledCustomSizeModalRect(x, y, 8, 8, 8, 8, 27, 27, 64, 64);
	GL11.glDisable(GL11.GL_BLEND);
}

function argCheck(num,min,max){
    if(num>max){
        return max;
    }
    if(num<min){
        return min;
    }
    return num;
}