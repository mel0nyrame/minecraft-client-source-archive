var scriptName = "Title"
var scriptVersion = 1.0
var scriptAuthor = "none"
var Title = new Title()
var client
var S02PacketChat = Java.type('net.minecraft.network.play.server.S02PacketChat');

function Title() {
	var S = 0
	var HM = 0
	var M =0
	var H = 0
	var ticks = 0
	var packets = 0
	
	this.getName = function() {
        return "Title"
    }

    this.getDescription = function() {
        return "BetterTitle"
    }

    this.getCategory = function() {
        return "Fun"
    }
	
    this.onUpdate = function() {
	 HM += 1
	 if (HM ==20){
	  S = S + 1
	  HM = 0
     }
	 if (S ==60){
	  M = M +1
	  S = 0
	 }
	 if (M==60){
	  H = H+1
	  M = 0
	 }
		ticks += 1
	    if(ticks >= 10){
			ticks = 0
		    packets = 0
		}
		if(packets >= 2700){
			chat.print("§b[TiKing For HuaYuTing] §f警告 发包过多 [发包数量: " + packets + "]");
			chat.print("§b[TiKing For HuaYuTing] §f请暂时停止使用某些发包多的功能 如speed/scaffold/Phase/NoFall");
			chat.print("§b[TiKing For HuaYuTing] §f加载地图时也可能引发发包过多 请不要担心！");//这里可以改
			packets = 0
		}
	Display.setTitle(' TiKing For HuaYuTing丨您已进攻HuaYuTing:   '+H+'  H  '+M +'  M  '+S+'  S  当前发包量 ' + packets + ' 敢于尝试，就等于你已经向成功迈出了第一步')
	}
	
	this.onPacket = function(event) {
		packets++;
		var packet = event.getPacket();
		if(packet instanceof S02PacketChat) {
			if (packet.getChatComponent().getUnformattedText().match("Time+1H")){
			H = H + 1
			chat.print("§b[TiKing For HuaYuTing] §f成功");
			}
			if (packet.getChatComponent().getUnformattedText().match("Time+30M")){
			M = M + 30
			chat.print("§b[TiKing For HuaYuTing] §f成功");
			}
			if (packet.getChatComponent().getUnformattedText().match("重置")){
			M = 0
			H = 0
			S = 0
			chat.print("§b[TiKing For HuaYuTing] §f重置成功");
			}
		}
	}
}



var Display = Java.type('org.lwjgl.opengl.Display')

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(Title)
}

function onDisable() {
    moduleManager.unregisterModule(client)
}