package me.tojatta.api.utilities.angle;

import cn.Hanabi.utils.vector.impl.Vector3;
import me.spec.sensation.utils.Mafs;

import javax.vecmath.Vector3d;
import java.util.Random;

/**
 * Created by Tojatta on 12/17/2016.
 */
public class AngleUtility {
    private final float minYawSmoothing;
    private final float maxYawSmoothing;
    private final float minPitchSmoothing;
    private final float maxPitchSmoothing;
    private final Vector3<Float> delta;
    private final Angle smoothedAngle;
    private final Random random;
    private float height = Mafs.getRandomInRange(1.1F, 1.8F);

    public AngleUtility(float minYawSmoothing, float maxYawSmoothing, float minPitchSmoothing, float maxPitchSmoothing) {
        this.minYawSmoothing = minYawSmoothing;
        this.maxYawSmoothing = maxYawSmoothing;
        this.minPitchSmoothing = minPitchSmoothing;
        this.maxPitchSmoothing = maxPitchSmoothing;
        random = new Random();
        delta = new Vector3<>(0F, 0F, 0F);
        smoothedAngle = new Angle(0F, 0F);
    }

    public float randomFloat(float min, float max) {
        return min + (random.nextFloat() * (max - min));
    }

    public Angle calculateAngle(Vector3d destination, Vector3d source) {

        Angle angles = new Angle(0F, 0F);
        delta.setX(destination.getX() - source.getX())
                .setY((destination.getY() + height) - (source.getY() + height))
                .setZ(destination.getZ() - source.getZ());

        double hypotenuse = Math.hypot(delta.getX().doubleValue(), delta.getZ().doubleValue());
        float yawAtan = ((float) Math.atan2(delta.getZ().floatValue(), delta.getX().floatValue()));
        float pitchAtan = ((float) Math.atan2(delta.getY().floatValue(), hypotenuse));
        float deg = ((float) (180 / Math.PI));
        float yaw = ((yawAtan * deg) - 90F);
        float pitch = -(pitchAtan * deg);

        return angles.setYaw(yaw).setPitch(pitch).constrantAngle();
    }


    public Angle calculateAngle(Vector3<Double> destination, Vector3<Double> source) {

        Angle angles = new Angle(0F, 0F);
        delta.setX(destination.getX().floatValue() - source.getX().floatValue())
                .setY((destination.getY().floatValue() + height) - (source.getY().floatValue() + height))
                .setZ(destination.getZ().floatValue() - source.getZ().floatValue());

        double hypotenuse = Math.hypot(delta.getX().doubleValue(), delta.getZ().doubleValue());
        float yawAtan = ((float) Math.atan2(delta.getZ().floatValue(), delta.getX().floatValue()));
        float pitchAtan = ((float) Math.atan2(delta.getY().floatValue(), hypotenuse));
        float deg = ((float) (180 / Math.PI));
        float yaw = ((yawAtan * deg) - 90F);
        float pitch = -(pitchAtan * deg);

        return angles.setYaw(yaw).setPitch(pitch).constrantAngle();
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public Angle smoothAngle(Angle destination, Angle source, float pitch, float yaw) {
        return smoothedAngle
                .setYaw(source.getYaw() - destination.getYaw() - (Math.abs(source.getYaw() - destination.getYaw()) > 5 ? Math.abs(source.getYaw() - destination.getYaw()) / Math.abs(source.getYaw() - destination.getYaw()) * 2 / 2 : 0))
                .setPitch(source.getPitch() - destination.getPitch())
                .constrantAngle()
                .setYaw(source.getYaw() - smoothedAngle.getYaw() / yaw * randomFloat(minYawSmoothing, maxYawSmoothing))
                .constrantAngle()
                .setPitch(source.getPitch() - smoothedAngle.getPitch() / pitch * randomFloat(minPitchSmoothing, maxPitchSmoothing))
                .constrantAngle();
    }
    public Angle smoothAngle(Angle destination, Angle source) {
        return this.smoothedAngle.setYaw(source.getYaw() - destination.getYaw()).setPitch(source.getPitch() - destination.getPitch()).constrantAngle().setYaw(source.getYaw() - this.smoothedAngle.getYaw() / 100.0f * this.randomFloat(this.minYawSmoothing, this.maxYawSmoothing)).setPitch(source.getPitch() - this.smoothedAngle.getPitch() / 100.0f * this.randomFloat(this.minPitchSmoothing, this.maxPitchSmoothing)).constrantAngle();
    }
}