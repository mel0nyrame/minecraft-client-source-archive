package cn.Hanabi;

import cn.Hanabi.altmanager.AltFileManager;
import cn.Hanabi.command.CommandManager;
import cn.Hanabi.gui.ScoreBoardMove;
import cn.Hanabi.hmlProject.HMLManager;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.utils.Misc.ClientUtil;
import cn.Hanabi.utils.Misc.NukerUtil;
import cn.Hanabi.utils.Rotation.LBRotate;
import cn.Hanabi.utils.fileSystem.FileManager;
import cn.Hanabi.utils.fontmanager.FontManager;
import com.darkmagician6.eventapi.EventManager;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import org.jetbrains.annotations.NotNull;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;


public class Hanabi {
    @NotNull
    public static final String CLIENT_NAME = "Hanabi pro";
    @NotNull
    public static final String CLIENT_AUTHOR = ".Net Space";
    @NotNull
    public static final String CLIENT_DATE = "210709";
    @NotNull
    public static final double CLIENT_VERSION_NUMBER = 3.1;
    @NotNull
    public static final String CLIENT_VERSION = Client.onDebug ? CLIENT_VERSION_NUMBER + " " + "date: " + CLIENT_DATE : CLIENT_VERSION_NUMBER + " ";
    @NotNull
    public static final String CLIENT_INITIALS;


    public static Hanabi INSTANCE;


    static {
        List<Character> chars = new ArrayList<>();

        for (char c : CLIENT_NAME.toCharArray())
            if (Character.toUpperCase(c) == c)
                chars.add(c);

        char[] c = new char[chars.size()];

        for (int i = 0; i < chars.size(); i++) {
            c[i] = chars.get(i);
        }

        CLIENT_INITIALS = new String(c);

    }


    public ModManager moduleManager;
    public CommandManager commandManager;
    public FileManager fileManager;
    public FontManager fontManager;
    public LBRotate rotate;
    public boolean loadFont = true;
    public AltFileManager altFileMgr;
    public ScoreBoardMove sbm;
    public HMLManager hmlManager;

    public TrayIcon trayIcon;

    {
        this.log("SystemTray is not supported. Skipping...");
    }

    public Hanabi() {
        INSTANCE = this;
    }

    public TrayIcon getTrayIcon() {
        return this.trayIcon;
    }

    public void log(String message) {
        String prefix = "[" + CLIENT_NAME + "] ";
        System.out.println(prefix + message);
    }



    public void startClient() {
     
        hmlManager = new HMLManager();
        fileManager = new FileManager();
        commandManager = new CommandManager();
        moduleManager = new ModManager();
        fontManager = new FontManager();
        fontManager.initFonts();
        rotate = new LBRotate();
        EventManager.register(rotate);
        EventManager.register(new NukerUtil());

        (altFileMgr = new AltFileManager()).loadFiles();
        ClientUtil.notifications.clear();
        moduleManager.addModules();
        commandManager.addCommands();
        fileManager.load();

        try {
            this.trayIcon = new TrayIcon(Toolkit.getDefaultToolkit().createImage(new URL("https://gitee.com/VanillaMirror/Hanabi/raw/master/icon32.png")));
        } catch (MalformedURLException ignored) {
        }
        if (SystemTray.isSupported()) {
            this.trayIcon.setImageAutoSize(true);
            this.trayIcon.setToolTip("Hanabi Client " + " ~ VanillaMirror");
            PopupMenu popupMenu = new PopupMenu("Client settings");
            Menu moduleMenu = new Menu("Modules");
            Iterator var5 = this.moduleManager.getModules().iterator();
            while (var5.hasNext()) {
                final cn.Hanabi.modules.Mod m = (cn.Hanabi.modules.Mod) var5.next();
                final CheckboxMenuItem checkboxMenuItem = new CheckboxMenuItem(m.getName(), m.isEnabled());
                checkboxMenuItem.addItemListener(new ItemListener() {
                    public void itemStateChanged(ItemEvent e) {
                        m.toggleModule();
                        checkboxMenuItem.setState(m.isEnabled());
                    }
                });
                m.setCheckboxMenuItem(checkboxMenuItem);
                moduleMenu.add(checkboxMenuItem);
            }
            popupMenu.add(moduleMenu);
            popupMenu.addSeparator();
            MenuItem exitItem = new MenuItem("Exit");
            exitItem.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    Hanabi.this.trayIcon.displayMessage("HanabiClient - Notification", "See you soon.", TrayIcon.MessageType.INFO);
                    SystemTray.getSystemTray().remove(Hanabi.this.trayIcon);
                    FMLCommonHandler.instance().exitJava(-1337, true);
                }
            });
            popupMenu.add(exitItem);
            this.trayIcon.setPopupMenu(popupMenu);

            try {
                SystemTray.getSystemTray().add(this.trayIcon);
            } catch (AWTException var7) {
                this.log("Unable to add tray icon.");
            }

            this.trayIcon.displayMessage("HanabiClient", "Thank you for using Hanabi", TrayIcon.MessageType.NONE);
            Wrapper.notificationsAllowed(true);
        }

    }

    public void stopClient() {
        try {
            if (SystemTray.isSupported()) {
                Hanabi.INSTANCE.trayIcon.displayMessage("HanabiClient - Notification", "See you soon.", TrayIcon.MessageType.ERROR);
            } else {
                Hanabi.INSTANCE.log("SystemTray is not supported. Skipping...");
            }
            fileManager.save();
        } catch (Exception e) {
            System.err.println("Failed to save settings:");
            e.printStackTrace();
        }



    }

}
