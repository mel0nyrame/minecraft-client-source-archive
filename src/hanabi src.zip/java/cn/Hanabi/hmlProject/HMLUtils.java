package cn.Hanabi.hmlProject;

import java.util.List;

import cn.Hanabi.Client;
import cn.Hanabi.Hanabi;
import cn.Hanabi.command.Command;
import cn.Hanabi.command.CommandManager;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;

public class HMLUtils {
	public final static String CLIENT_NAME = Hanabi.CLIENT_NAME;
	public final static String CLIENT_VERSION = Hanabi.CLIENT_VERSION;
	public final static String USERNAME = Client.username;
	
	public static HML_ModManager MOD_MANAGER;
	public static HML_CommandManager COMMAND_MANAGER;
	
	public static void onModManagerLoad(ModManager manager) {
		MOD_MANAGER = new HML_ModManager(manager);
	}
	
	public static void onCommandManagerLoad(CommandManager commandManager) {
		COMMAND_MANAGER = new HML_CommandManager(commandManager);
		
	}
}

class HML_ModManager {
	ModManager manager;
	
	public HML_ModManager(ModManager modManager) {
		manager = modManager;
		Hanabi.INSTANCE.hmlManager.onModuleManagerLoading(this);
	}
	
	public Mod getMod(String name) {
        return ModManager.getModule(name);
    }
	
	public List<Mod> getModList() {
        return ModManager.getModList();
    }
	
	public boolean getModState(Mod mod) {
		return mod.getState();
	}
}

class HML_CommandManager {
	CommandManager manager;
	
	public HML_CommandManager(CommandManager commandManager) {
		manager = commandManager;
		Hanabi.INSTANCE.hmlManager.onCommandManagerLoading(this);
	}

	public void addCommand(Command command) {
		manager.addCommand(command);
	}
}