package cn.Hanabi.hmlProject;

import java.util.ArrayList;

public class HMLManager {
	public static ArrayList<HMLHook> hooks = new ArrayList<HMLHook>();
	
	public static boolean registerHook(HMLHook hook) {
		hooks.add(hook);
		return true;
	}
	
	public void onModuleManagerLoading(HML_ModManager hml_ModManager) {
		for (HMLHook hook : hooks) {
			hook.onModuleManagerLoading(hml_ModManager);
		}
	}
	
	public void onCommandManagerLoading(HML_CommandManager hml_CommandManager) {
		for (HMLHook hook : hooks) {
			hook.onCommandManagerLoading(hml_CommandManager);
		}
	}
}
