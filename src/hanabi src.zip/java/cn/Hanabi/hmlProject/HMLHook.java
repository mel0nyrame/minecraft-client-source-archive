package cn.Hanabi.hmlProject;

import cn.Hanabi.command.CommandManager;

public class HMLHook {
	/*
	 * Hanabi Module Loader Version.
	 * Hanabi模块加载器版本。
	 */
	public static final int HML_VERSION = 0;
	
	public String name;
	public int version;
	public String author;
	
	public HMLHook(String name, int version, String author){
		this.name = name;
		this.version = version;
		this.author = author;
	}

	public void onModuleManagerLoading(HML_ModManager hml_ModManager) {
		/* After loading all Modules of Hanabi, this event will be called.
		 * If you want to load your Modules before Hanabi Modules, use ClientStarted Event.
		 * 
		 * 当Hanabi的所有Modules被加载完后，这个事件将会被调用。
		 * 如果你想抢先Hanabi去加载Modules，请使用ClientStart事件。
		 */
		
	}
	
	public void onCommandManagerLoading(HML_CommandManager hml_CommandManager) {
		/* After loading all Commands of Hanabi, this event will be called.
		 * If you want to load your Commands before Hanabi Modules, use ClientStarted Event.
		 * 
		 * 当Hanabi的所有Commands被加载完后，这个事件将会被调用。
		 * 如果你想抢先Hanabi去加载Commands，请使用ClientStart事件。
		 */
		
	}
}
