package cn.Hanabi;

import net.minecraft.launchwrapper.LaunchClassLoader;

import java.lang.instrument.Instrumentation;

public class Injection {
    public static void agentmain(final String args, final Instrumentation instrumentation) {
        try {
            for (final Class<?> classes : instrumentation.getAllLoadedClasses()) {
                if (classes.getName().equals("net.minecraft.client.Minecraft")) {
                    LaunchClassLoader classLoader = (LaunchClassLoader)classes.getClassLoader();
                    classLoader.addURL(Hanabi.class.getProtectionDomain().getCodeSource().getLocation());
                    final Class<?> instance = classLoader.loadClass(Hanabi.class.getName());
                    instance.newInstance();
                    return;
                }
            }
        }
        catch (Exception e) {}
    }
}
