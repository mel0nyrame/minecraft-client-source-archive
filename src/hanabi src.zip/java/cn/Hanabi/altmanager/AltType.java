package cn.Hanabi.altmanager;

public enum AltType {
	ONEPLUS, TENPLUS, TWENTYPLUS
}