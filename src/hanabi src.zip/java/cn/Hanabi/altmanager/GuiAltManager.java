package cn.Hanabi.altmanager;

import cn.Hanabi.Hanabi;
import cn.Hanabi.utils.Misc.RenderUtil;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import com.thealtening.auth.TheAlteningAuthentication;
import com.thealtening.auth.service.AlteningServiceType;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GuiAltManager extends GuiScreen {
    public static String Api = null;
    private GuiButton login;
    private GuiButton remove;
    private GuiButton rename;
    private AltLoginThread loginThread;
    private int offset;
    public Alt selectedAlt;
    private String status;

    public GuiAltManager() {
        this.selectedAlt = null;
        this.status = EnumChatFormatting.GRAY + "Idle...";
    }

    public void actionPerformed(GuiButton button) {
        switch (button.id) {
            case 1: {
                (this.loginThread = new AltLoginThread(selectedAlt)).start();
                Hanabi.INSTANCE.altFileMgr.saveFiles();
                break;
            }
            case 2: {
                if (this.loginThread != null) {
                    this.loginThread = null;
                }
                AltManager.registry.remove(this.selectedAlt);
                this.status = "\247aRemoved.";
                try {
                    Hanabi.INSTANCE.altFileMgr.getFile(Alts.class).saveFile();
                } catch (Exception ex) {
                }
                this.selectedAlt = null;
                break;
            }
            case 3: {
                this.mc.displayGuiScreen(new GuiAddAlt(this));
                break;
            }
            case 4: {
                this.mc.displayGuiScreen(new GuiAltLogin(this));
                break;
            }
            case 5: {
                ArrayList<Alt> registry = AltManager.registry;
                Random random = new Random();
                if (registry.size() > 1) {
                    Alt randomAlt = registry.get(random.nextInt(AltManager.registry.size()));
                    (this.loginThread = new AltLoginThread(randomAlt)).start();
                } else {
                    this.status = EnumChatFormatting.RED + "There's no any alts!";
                }
                break;
            }
            case 6: {
                this.mc.displayGuiScreen(new GuiRenameAlt(this));
                break;
            }
            case 7: {
                this.mc.displayGuiScreen(null);
                break;
            }
            case 8: {
                AltManager.registry.clear();
                try {
                    Hanabi.INSTANCE.altFileMgr.getFile(Alts.class).loadFile();
                } catch (IOException e) {

                }
                this.status = "\247bReloaded!";
                break;
            }
            case 9: {
                mc.displayGuiScreen(new GuiMultiplayer(this));
                break;
            }
            case 10: {
                TheAlteningAuthentication.theAltening().updateService(AlteningServiceType.THEALTENING);
                break;
            }
            case 11: {
                TheAlteningAuthentication.theAltening().updateService(AlteningServiceType.MOJANG);
                break;
            }
            case 12: {
                if (java.awt.Desktop.isDesktopSupported()) {
                    try {
                        // 创建一个URI实例
                        java.net.URI uri = java.net.URI.create("http://mcbaozi.com");
                        // 获取当前系统桌面扩展
                        java.awt.Desktop dp = java.awt.Desktop.getDesktop();
                        // 判断系统桌面是否支持要执行的功能
                        if (dp.isSupported(java.awt.Desktop.Action.BROWSE)) {
                            // 获取系统默认浏览器打开链接
                            dp.browse(uri);
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                break;
            }
        }
    }

    private final ResourceLocation background = new ResourceLocation("textures/mainmenubackground.png");

    @Override
    public void drawScreen(final int par1, final int par2, final float par3) {
        this.drawDefaultBackground();
        if (Mouse.hasWheel()) {
            final int wheel = Mouse.getDWheel();
            if (wheel < 0) {
                this.offset += 26;
                if (this.offset < 0) {
                    this.offset = 0;
                }
            } else if (wheel > 0) {
                this.offset -= 26;
                if (this.offset < 0) {
                    this.offset = 0;
                }
            }
        }
        ScaledResolution res = new ScaledResolution(mc);
        int w = res.getScaledWidth();
        int h = res.getScaledHeight();
        GlStateManager.bindTexture(0);

        RenderUtil.drawRect(0, 0, res.getScaledWidth(), res.getScaledHeight(), getColor(0, 50));

        this.drawString(this.fontRendererObj, this.mc.getSession().getUsername(), 10, 10, 14540253);
        final FontRenderer fontRendererObj = this.fontRendererObj;
        final StringBuilder sb = new StringBuilder("Account Manager - ");
        this.drawCenteredString(fontRendererObj, sb.append(AltManager.registry.size()).append(" alts").toString(),
                this.width / 2, 10, -1);
        this.drawCenteredString(this.fontRendererObj,
                (this.loginThread == null) ? this.status : this.loginThread.getStatus(), this.width / 2, 20, -1);
        RenderUtil.drawOutlinedRect(50.0f, 33.0f, this.width - 50, this.height - 50, 1.0f, getColor(225, 50),
                getColor(160, 150));
        GL11.glPushMatrix();
        this.prepareScissorBox(0.0f, 33.0f, this.width, this.height - 50);
        GL11.glEnable(3089);
        int y = 38;
        for (final Alt alt : getAlts()) {
            if (isAltInArea(y)) {
                String name;
                if (alt.getMask().equals("")) {
                    name = alt.getUsername();
                } else {
                    name = alt.getMask();
                }
                String pass;
                if (alt.getPassword().equals("")) {
                    pass = "\247cCracked";
                } else {
                    pass = alt.getPassword().replaceAll(".", "*");
                }
                if (alt == this.selectedAlt) {
                    if (this.isMouseOverAlt(par1, par2, y - this.offset) && Mouse.isButtonDown(0)) {
                        RenderUtil.drawOutlinedRect(52.0f, y - this.offset - 4, this.width - 52, y - this.offset + 20,
                                1.0f, getColor(145, 50), -2142943931);
                    } else if (this.isMouseOverAlt(par1, par2, y - this.offset)) {
                        RenderUtil.drawOutlinedRect(52.0f, y - this.offset - 4, this.width - 52, y - this.offset + 20,
                                1.0f, getColor(145, 50), -2142088622);
                    } else {
                        RenderUtil.drawOutlinedRect(52.0f, y - this.offset - 4, this.width - 52, y - this.offset + 20,
                                1.0f, getColor(145, 50), -2144259791);
                    }
                } else if (this.isMouseOverAlt(par1, par2, y - this.offset) && Mouse.isButtonDown(0)) {
                    RenderUtil.drawOutlinedRect(52.0f, y - this.offset - 4, this.width - 52, y - this.offset + 20, 1.0f,
                            -getColor(145, 50), -2146101995);
                } else if (this.isMouseOverAlt(par1, par2, y - this.offset)) {
                    RenderUtil.drawOutlinedRect(52.0f, y - this.offset - 4, this.width - 52, y - this.offset + 20, 1.0f,
                            getColor(145, 50), -2145180893);
                }
                this.drawCenteredString(this.fontRendererObj, name, this.width / 2, y - this.offset, -1);
                this.drawCenteredString(this.fontRendererObj, pass, this.width / 2, y - this.offset + 10,
                        getColor(110));
                y += 26;
            }
        }
        GL11.glDisable(3089);
        GL11.glPopMatrix();

        super.drawScreen(par1, par2, par3);
        if (this.selectedAlt == null) {
            this.login.enabled = false;
            this.remove.enabled = false;
            this.rename.enabled = false;
        } else {
            this.login.enabled = true;
            this.remove.enabled = true;
            this.rename.enabled = true;
        }
        if (Keyboard.isKeyDown(200)) {
            this.offset -= 26;
        } else if (Keyboard.isKeyDown(208)) {
            this.offset += 26;
        }
        if (this.offset < 0) {
            this.offset = 0;
        }

        this.seatchField.drawTextBox();
        if (seatchField.getText().isEmpty() && !seatchField.isFocused()) {
            this.drawString(this.mc.fontRendererObj, "Search Alt", this.width / 2 - 264, this.height - 18, -1);
        }

    }

    public static int getColor(int red, int green, int blue, int alpha) {
        int color = 0;
        color |= alpha << 24;
        color |= red << 16;
        color |= green << 8;
        color |= blue;
        return color;
    }

    public static int getColor(Color color) {
        return getColor(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }

    public static int getColor(int brightness) {
        return getColor(brightness, brightness, brightness, 255);
    }

    public static int getColor(int brightness, int alpha) {
        return getColor(brightness, brightness, brightness, alpha);
    }

    private GuiTextField seatchField;

    @Override
    public void initGui() {
        // HANABI_VERIFY
        this.buttonList.add(this.login = new GuiButton(1, this.width / 2 - 122, this.height - 48, 100, 20, "Login"));
        this.buttonList.add(this.remove = new GuiButton(2, this.width / 2 - 16, this.height - 24, 100, 20, "Remove"));
        this.buttonList.add(new GuiButton(3, this.width / 2 + 4 + 86, this.height - 48, 100, 20, "Add"));
        this.buttonList.add(new GuiButton(4, this.width / 2 - 16, this.height - 48, 100, 20, "Direct Login"));
        this.buttonList.add(new GuiButton(5, this.width / 2 - 122, this.height - 24, 100, 20, "Random"));
        this.buttonList.add(this.rename = new GuiButton(6, this.width / 2 + 90, this.height - 24, 100, 20, "Edit"));
        this.buttonList.add(new GuiButton(7, this.width / 2 - 190, this.height - 24, 60, 20, "Back"));
        this.buttonList.add(new GuiButton(8, this.width / 2 - 190, this.height - 48, 60, 20, "Reload"));
        this.buttonList.add(new GuiButton(9, this.width / 2 - 268, this.height - 48, 68, 20, "MultPlayer"));
        this.buttonList.add(new GuiButton(10, this.width / 2 - 388, this.height - 48, 68, 20, "Altening"));
        this.buttonList.add(new GuiButton(11, this.width / 2 - 388, this.height - 24, 68, 20, "Mojang"));
        this.buttonList.add(new GuiButton(12, this.width / 2 + 196, this.height - 48, 100, 20, "Buy Account"));

        seatchField = new GuiTextField(99998, this.mc.fontRendererObj, this.width / 2 - 268, this.height - 21, 68, 14);
        this.login.enabled = false;
        this.remove.enabled = false;
        this.rename.enabled = false;
    }

    @Override
    protected void keyTyped(final char par1, final int par2) {
        seatchField.textboxKeyTyped(par1, par2);
        if ((par1 == '\t' || par1 == '\r') && seatchField.isFocused()) {
            seatchField.setFocused(!seatchField.isFocused());
        }

        try {
            super.keyTyped(par1, par2);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean isAltInArea(final int y) {
        return y - this.offset <= this.height - 50;
    }

    private boolean isMouseOverAlt(final int x, final int y, final int y1) {
        return x >= 52 && y >= y1 - 4 && x <= this.width - 52 && y <= y1 + 20 && x >= 0 && y >= 33 && x <= this.width
                && y <= this.height - 50;
    }

    @Override
    protected void mouseClicked(final int par1, final int par2, final int par3) {
        seatchField.mouseClicked(par1, par2, par3);
        if (this.offset < 0) {
            this.offset = 0;
        }
        int y = 38 - this.offset;
        for (final Alt alt : getAlts()) {
            if (isMouseOverAlt(par1, par2, y)) {
                if (alt == this.selectedAlt) {
                    this.actionPerformed(this.buttonList.get(0));
                    return;
                }
                this.selectedAlt = alt;
            }
            y += 26;
        }
        try {
            super.mouseClicked(par1, par2, par3);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private List<Alt> getAlts() {
        List<Alt> altList = new ArrayList<>();
        for (final Alt alt : AltManager.registry) {
            if (seatchField.getText().isEmpty()
                    || (alt.getMask().toLowerCase().contains(seatchField.getText().toLowerCase())
                    || alt.getUsername().toLowerCase().contains(seatchField.getText().toLowerCase()))) {
                altList.add(alt);
            }
        }
        return altList;
    }

    public void prepareScissorBox(final float x, final float y, final float x2, final float y2) {
        final ScaledResolution scale = new ScaledResolution(this.mc);
        final int factor = scale.getScaleFactor();
        GL11.glScissor((int) (x * factor), (int) ((scale.getScaledHeight() - y2) * factor), (int) ((x2 - x) * factor),
                (int) ((y2 - y) * factor));
    }

}
