package cn.Hanabi.events;

import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class EventPushOutOfBlocks extends EventCancellable {
}
