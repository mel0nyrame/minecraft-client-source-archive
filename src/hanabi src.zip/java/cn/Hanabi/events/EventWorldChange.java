package cn.Hanabi.events;

import com.darkmagician6.eventapi.events.Event;

public class EventWorldChange implements Event {
	
	public EventWorldChange() {
		
	}

}
