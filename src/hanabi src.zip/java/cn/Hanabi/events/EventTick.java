package cn.Hanabi.events;

import com.darkmagician6.eventapi.events.Event;

public class EventTick
  implements Event
{}