package cn.Hanabi.events;

import com.darkmagician6.eventapi.events.Event;

public class EventClickMouse implements Event {
	
	public EventClickMouse() {
		
	}

}
