package cn.Hanabi.events;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.types.EventType;

public class EventStep implements Event {
    /**
     * The step height.
     */
    private float height;
    private final EventType eventType;

    public EventStep(EventType eventType, float height) {
        this.eventType = eventType;
        this.height = height;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public EventType getEventType() {
        return eventType;
    }
}