package cn.Hanabi.utils;

import cn.Hanabi.Hanabi;
import com.google.gson.JsonObject;
import net.minecraft.client.Minecraft;
import net.minecraft.util.IChatComponent;
import net.minecraftforge.fml.common.FMLCommonHandler;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChatUtils {
	public static final String PRIMARY_COLOR = "§7";
	public static final String SECONDARY_COLOR = "§1";
	private static final String PREFIX = PRIMARY_COLOR + "[" + SECONDARY_COLOR + Hanabi.CLIENT_NAME + PRIMARY_COLOR
			+ "] ";

	public static void send(final String s) {
		JsonObject object = new JsonObject();
		object.addProperty("text", s);
		Minecraft.getMinecraft().thePlayer.addChatMessage(IChatComponent.Serializer.jsonToComponent(object.toString()));
	}

	public static void success(String s) {
		info(s);
	}

	public static void info(String s) {
		send(PREFIX + s);
	}

	public static void showMessageBox(String str) {
		showMessageBox(str, false);
	}
	
	public static void showMessageBox(String str, boolean exit) {
		new Notice(str, exit);
	}
}

class Notice extends JFrame {
	public Notice(String notice, boolean exit) {
		JLabel label = new JLabel(notice);
		Button bt = new Button(notice + "确定");
		bt.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (notice.contains(
						"你" + "妈" + "JAVA.SYSTEM".replaceAll("...........", "死") + "TEST".replaceAll("....", "了")) || notice.contains("失败")) {
					FMLCommonHandler.instance().exitJava(0, true);
				} else {
					if (!exit) {
						setVisible(false);
					} else {
						FMLCommonHandler.instance().exitJava(0, true);
					}
				}
				// 如果第一个参数是null，那么弹出的消息窗口，很可能就被置顶的窗口JFrame挡住了
				// 第一个窗口bt.getParent()父组件就是本窗口了，也可以写bt那么父组件就是按钮，都可以显示出来，
				// 但位置不同。bt.getParent()位于界面中央，更美观一点吧
			}
		});
		add(label);
		add(bt);
		setLayout(new FlowLayout());
		setTitle("提示");
		setSize(300, 80);
		setLocationRelativeTo(null);// 窗口居中
		setAlwaysOnTop(true);// 置顶
		setResizable(false);// 禁止缩放
		setVisible(true);
	}
}
