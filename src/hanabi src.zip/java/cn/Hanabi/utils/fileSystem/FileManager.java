package cn.Hanabi.utils.fileSystem;

import cn.Hanabi.Client;
import cn.Hanabi.Hanabi;
import cn.Hanabi.Wrapper;
import cn.Hanabi.altmanager.GuiAltManager;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.value.Value;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.FMLCommonHandler;

import org.lwjgl.input.Keyboard;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;

public class FileManager {
    private final String fileDir;
    private final Minecraft mc = Minecraft.getMinecraft();

    public FileManager() {
        this.fileDir = mc.mcDataDir.getAbsolutePath() + "/" + Hanabi.CLIENT_NAME;
        File fileFolder = new File(this.fileDir);
        if (!fileFolder.exists()) {
            fileFolder.mkdirs();
        }
    }

    public void save() throws Exception {
		File keyFile = new File(this.fileDir + "/keys.txt");
		File moduleFile = new File(this.fileDir + "/mods.txt");
		File valueFile = new File(this.fileDir + "/values.txt");
		File gen = new File(this.fileDir + "/gen.txt");

		try {
			// Key
			if (!keyFile.exists()) {
				keyFile.createNewFile();
			}
			PrintWriter keyPw = new PrintWriter(keyFile);
			for (Mod m : Hanabi.INSTANCE.moduleManager.getModules()) {
				String keyName = m.getKeybind() < 0 ? "None" : Keyboard.getKeyName(m.getKeybind());
				keyPw.write(m.getName() + ":" + keyName + "\n");
			}
			keyPw.close();

			// altgen
			if (!gen.exists()) {
				gen.createNewFile();
			}
			PrintWriter genPW = new PrintWriter(gen);
			if (GuiAltManager.Api != null)
			genPW.write(GuiAltManager.Api);
			genPW.close();
			// HANABI_VERIFY
			// HANABI_VERIFY
			/*
			 * try { if
			 * (!Hanabi.AES_UTILS.decrypt(Hanabi.HWID_VERIFY).contains(Wrapper.getHWID())) {
			 * FMLCommonHandler.instance().exitJava(0, true); Client.sleep = true; } } catch
			 * (Exception e) { FMLCommonHandler.instance().exitJava(0, true); Client.sleep =
			 * true; }
			 * 
			 */
			// Module
			if (!moduleFile.exists()) {
				moduleFile.createNewFile();
			}
			PrintWriter modulePw = new PrintWriter(moduleFile);
			for (Mod m : Hanabi.INSTANCE.moduleManager.getModules()) {
				modulePw.print(m.getName() + ":" + m.isEnabled() + "\n");
			}
			modulePw.close();

			// Value
			if (!valueFile.exists()) {
				valueFile.createNewFile();
			}
			PrintWriter valuePw = new PrintWriter(valueFile);
			for (Value value : Value.list) {
				String valueName = value.getValueName();
				if (value.isValueBoolean) {
					valuePw.print(valueName + ":b:" + value.getValueState() + "\n");
					continue;
				}
				if (value.isValueDouble) {
					valuePw.print(valueName + ":d:" + value.getValueState() + "\n");
					continue;
				}
				if (!value.isValueMode)
					continue;
				valuePw.print(valueName + ":s:" + value.getModeTitle() + ":" + value.getCurrentMode() + "\n");
			}
			valuePw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("resource")
	public void load() {
		File keyFile = new File(this.fileDir + "/keys.txt");
		File moduleFile = new File(this.fileDir + "/mods.txt");
		File valueFile = new File(this.fileDir + "/values.txt");
		File gen = new File(this.fileDir + "/gen.txt");

		try {
			// Key
			if (!keyFile.exists()) {
				keyFile.createNewFile();
			} else {
				String line;
				BufferedReader br = new BufferedReader(new FileReader(keyFile));
				while ((line = br.readLine()) != null) {
                    if (!line.contains(":"))
                        continue;
                    String[] split = line.split(":");
                    Mod m = ModManager.getModule(split[0]);
                    int key = Keyboard.getKeyIndex(split[1]);
                    if (m == null || key == -1)
                        continue;
                    m.setKeybind(key);
                }
			}
			// altgen
			if (!gen.exists()) {
				gen.createNewFile();
			} else {
				String result;
				BufferedReader br = new BufferedReader(new FileReader(gen));
				result = br.readLine();
				if (GuiAltManager.Api == null) {
					GuiAltManager.Api = result;
				}
		//		System.out.println(result);

			}

			// Module
			if (!moduleFile.exists()) {
				moduleFile.createNewFile();
			} else {
				String line;
				BufferedReader br = new BufferedReader(new FileReader(moduleFile));
				while ((line = br.readLine()) != null) {
                    if (!line.contains(":"))
                        continue;
                    String[] split = line.split(":");
                    Mod m = ModManager.getModule(split[0]);
                    boolean state = Boolean.parseBoolean(split[1]);
                    if (m == null)
                        continue;
                    try {
                        if (!m.getName().equals("Fly") && !m.getName().equals("Blink")
                                && !m.getName().equals("Scaffold")) {
                            m.setState(state, false);
                        } else {
                            m.setState(false, false);
                        }
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}

			// HANABI_VERIFY
			// HANABI_VERIFY
			/*
			 * try { if
			 * (!Hanabi.AES_UTILS.decrypt(Hanabi.HWID_VERIFY).contains(Wrapper.getHWID())) {
			 * FMLCommonHandler.instance().exitJava(0, true); Client.sleep = true; } } catch
			 * (Exception e) { FMLCommonHandler.instance().exitJava(0, true); Client.sleep =
			 * true; }
			 * 
			 */

			// Value
			if (!valueFile.exists()) {
				valueFile.createNewFile();
			} else {
				String line;
				BufferedReader br = new BufferedReader(new FileReader(valueFile));
				while ((line = br.readLine()) != null) {
					if (!line.contains(":"))
						continue;
					String[] split = line.split(":");
					for (Value value : Value.list) {
						if (!split[0].equalsIgnoreCase(value.getValueName()))
							continue;
						if (value.isValueBoolean && split[1].equalsIgnoreCase("b")) {
							value.setValueState(Boolean.parseBoolean(split[2]));
							continue;
						}
						if (value.isValueDouble && split[1].equalsIgnoreCase("d")) {
							value.setValueState(Double.parseDouble(split[2]));
							continue;
						}
						if (!value.isValueMode || !split[1].equalsIgnoreCase("s")
								|| !split[2].equalsIgnoreCase(value.getModeTitle()))
							continue;
						value.setCurrentMode(Integer.parseInt(split[3]));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
