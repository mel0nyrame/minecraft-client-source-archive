package cn.Hanabi.utils.TimeLocation;

public class Timer {

    private long pastMS;

    public final boolean delay(long delay) {
        if (System.currentTimeMillis() - pastMS > delay) {
            reset();
            return true;
        }
        return false;
    }

    public final boolean delay2(long delay) {
        return System.currentTimeMillis() - pastMS > delay;
    }

    public final void reset() {
        pastMS = System.currentTimeMillis();
        lastMS = System.currentTimeMillis();

    }

    public final long getPastMS() {
        return pastMS;
    }

    public long lastMS = System.currentTimeMillis();;


    public boolean hasTimeElapsed(long time, boolean reset) {

        if (System.currentTimeMillis()-lastMS > time) {

            if (reset)
                reset();

            return true;


        }else {
            return false;
        }

    }
}
