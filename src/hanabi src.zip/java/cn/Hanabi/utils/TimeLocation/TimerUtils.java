package cn.Hanabi.utils.TimeLocation;

import java.util.Random;

public class TimerUtils {
    private static long prevMS;
    private long currentMs = 0L;
    private long lastMs = -1L;

    public TimerUtils() {
        prevMS = 0L;
    }

    public static boolean hD(double d) {
        return getTime() - prevMS >= 1000.0D / d;
    }

    public static boolean hasRandomDelay(double d, Random rand) {
        return getTime() - prevMS >= 1000.0D / d;
    }

    public static void rt() {
        prevMS = getTime();
    }

    public static long getTime() {
        return System.nanoTime() / 1000000L;
    }

    public static boolean hasReached(long milliseconds) {
        return (float) (getTime() - prevMS) >= 1000.0F / (float) milliseconds;
    }

    public void updateMs() {
        this.currentMs = System.currentTimeMillis();
    }

    public void setLastMs() {
        this.lastMs = System.currentTimeMillis();
    }

    public boolean hasPassed(long Ms) {
        return this.currentMs > this.lastMs + Ms;
    }
}