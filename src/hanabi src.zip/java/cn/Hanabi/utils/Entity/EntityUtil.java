package cn.Hanabi.utils.Entity;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

public class EntityUtil {
   private static final Minecraft mc = Minecraft.getMinecraft();


   public static void tpRel(double x, double y, double z) {
      mc.thePlayer.setPosition(mc.thePlayer.posX + x, mc.thePlayer.posY + y, mc.thePlayer.posZ + z);
   }

   public static Entity getEntity(double distance) {
      return getEntity(distance, 0.0D, 0.0F) == null?null:(Entity)getEntity(distance, 0.0D, 0.0F)[0];
   }

   public static float getDistanceToEntity(EntityLivingBase entityLivingBase) {
      return mc.thePlayer.getDistanceToEntity(entityLivingBase);
   }
   public static MovingObjectPosition rayCast(final EntityPlayerSP player, final double x, final double y, final double z) {
      final HashSet<Entity> excluded = new HashSet<>();
      excluded.add(player);
      return tracePathD(player.worldObj, player.posX, player.posY + player.getEyeHeight(), player.posZ, x, y, z, 1.0f, excluded);
   }

   private static MovingObjectPosition tracePathD(final World w, final double posX, final double posY, final double posZ, final double v, final double v1, final double v2, final float borderSize, final HashSet<Entity> exclude) {
      return tracePath(w, (float) posX, (float) posY, (float) posZ, (float) v, (float) v1, (float) v2, borderSize, exclude);
   }
   private static MovingObjectPosition tracePath(final World world, final float x, final float y, final float z, final float tx, final float ty, final float tz, final float borderSize, final HashSet<Entity> excluded) {
      Vec3 startVec = new Vec3(x, y, z);
      Vec3 endVec = new Vec3(tx, ty, tz);
      final float minX = (x < tx) ? x : tx;
      final float minY = (y < ty) ? y : ty;
      final float minZ = (z < tz) ? z : tz;
      final float maxX = (x > tx) ? x : tx;
      final float maxY = (y > ty) ? y : ty;
      final float maxZ = (z > tz) ? z : tz;
      final AxisAlignedBB bb = new AxisAlignedBB(minX, minY, minZ, maxX, maxY, maxZ).expand(borderSize, borderSize, borderSize);
      final ArrayList<Entity> allEntities = (ArrayList<Entity>) world.getEntitiesWithinAABBExcludingEntity(null, bb);
      MovingObjectPosition blockHit = world.rayTraceBlocks(startVec, endVec);
      startVec = new Vec3(x, y, z);
      endVec = new Vec3(tx, ty, tz);
      Entity closestHitEntity = null;
      float closestHit = Float.POSITIVE_INFINITY;
      float currentHit;
      for (final Entity ent : allEntities) {
         if (ent.canBeCollidedWith() && !excluded.contains(ent)) {
            final float entBorder = ent.getCollisionBorderSize();
            AxisAlignedBB entityBb = ent.getEntityBoundingBox();
            if (entityBb == null) {
               continue;
            }
            entityBb = entityBb.expand(entBorder, entBorder, entBorder);
            final MovingObjectPosition intercept = entityBb.calculateIntercept(startVec, endVec);
            if (intercept == null) {
               continue;
            }
            currentHit = (float) intercept.hitVec.distanceTo(startVec);
            if (currentHit >= closestHit && currentHit != 0.0f) {
               continue;
            }
            closestHit = currentHit;
            closestHitEntity = ent;
         }
      }
      if (closestHitEntity != null) {
         blockHit = new MovingObjectPosition(closestHitEntity);
      }
      return blockHit;
   }


   public static Object[] getEntity(double distance, double expand, float partialTicks) {
      Entity var2 = mc.getRenderViewEntity();
      Entity entity = null;
      if(var2 != null && mc.theWorld != null) {
         mc.mcProfiler.startSection("pick");
         Vec3 var7 = var2.getPositionEyes(0.0F);
         Vec3 var8 = var2.getLook(0.0F);
         Vec3 var9 = var7.addVector(var8.xCoord * distance, var8.yCoord * distance, var8.zCoord * distance);
         Vec3 var10 = null;
         float var11 = 1.0F;
         List var12 = mc.theWorld.getEntitiesWithinAABBExcludingEntity(var2, var2.getEntityBoundingBox().addCoord(var8.xCoord * distance, var8.yCoord * distance, var8.zCoord * distance).expand(var11, var11, var11));
         double var13 = distance;

         for(int var15 = 0; var15 < var12.size(); ++var15) {
            Entity var16 = (Entity)var12.get(var15);
            if(var16.canBeCollidedWith()) {
               float var17 = var16.getCollisionBorderSize();
               AxisAlignedBB var18 = var16.getEntityBoundingBox().expand(var17, var17, var17);
               var18 = var18.expand(expand, expand, expand);
               MovingObjectPosition var19 = var18.calculateIntercept(var7, var9);
               if(var18.isVecInside(var7)) {
                  if(0.0D < var13 || var13 == 0.0D) {
                     entity = var16;
                     var10 = var19 == null?var7:var19.hitVec;
                     var13 = 0.0D;
                  }
               } else if(var19 != null) {
                  double var20 = var7.distanceTo(var19.hitVec);
                  if(var20 < var13 || var13 == 0.0D) {
                     boolean canRiderInteract = false;
                     if(var16 == var2.ridingEntity && !canRiderInteract) {
                        if(var13 == 0.0D) {
                           entity = var16;
                           var10 = var19.hitVec;
                        }
                     } else {
                        entity = var16;
                        var10 = var19.hitVec;
                        var13 = var20;
                     }
                  }
               }
            }
         }

         if(var13 < distance && !(entity instanceof EntityLivingBase) && !(entity instanceof EntityItemFrame)) {
            entity = null;
         }

         mc.mcProfiler.endSection();
         if(entity != null && var10 != null) {
            return new Object[]{entity, var10};
         } else {
            return null;
         }
      } else {
         return null;
      }
   }
}
