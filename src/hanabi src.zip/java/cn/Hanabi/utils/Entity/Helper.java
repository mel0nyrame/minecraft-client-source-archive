package cn.Hanabi.utils.Entity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;

public class Helper {
    public static Minecraft mc = Minecraft.getMinecraft();

// private static MathUtils mathUtils;

    public static boolean xray = false;
    public static Boolean DIF;
    public static HashSet blockIDs = new HashSet();
    public static int opacity;
    public static Boolean bypass = true;
    public static List<Block> dimblock = new ArrayList<Block>();
    public static ArrayList<BlockPos> glow = new ArrayList<BlockPos>();

    protected static List<Entity> getLoadedEntities() {
        Minecraft.getMinecraft();
        return mc().theWorld.loadedEntityList;
    }

    public static boolean hasArmor(EntityPlayer player) {
        if (player.inventory == null) {
            return false;
        }
        ItemStack boots = player.inventory.armorInventory[0];
        ItemStack pants = player.inventory.armorInventory[1];
        ItemStack chest = player.inventory.armorInventory[2];
        ItemStack head = player.inventory.armorInventory[3];
        return boots != null || pants != null || chest != null || head != null;
    }
    public static boolean containsID(int id) {
        return blockIDs.contains(id);
    }

    public static Minecraft mc() {
        return Minecraft.getMinecraft();
    }

    public static EntityPlayerSP player() {
        Helper.mc();
        return mc.thePlayer;
    }

    public static WorldClient world() {
        Helper.mc();
        return mc.theWorld;
    }

/* public static MathUtils mathUtils() {
     return mathUtils;
 }*/

    public static boolean onServer(String server) {
        return !mc.isSingleplayer() && Helper.mc.getCurrentServerData().serverIP.toLowerCase().contains(server);
    }
}


