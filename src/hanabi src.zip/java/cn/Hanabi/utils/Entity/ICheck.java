package cn.Hanabi.utils.Entity;

import net.minecraft.entity.Entity;

public interface ICheck {
    boolean validate(Entity var1);
}
