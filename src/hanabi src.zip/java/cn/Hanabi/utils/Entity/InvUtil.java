package cn.Hanabi.utils.Entity;

import com.google.common.collect.Multimap;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.init.Blocks;
import net.minecraft.item.*;
import net.minecraft.util.DamageSource;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

public class InvUtil {
	public static Minecraft mc = Minecraft.getMinecraft();

	private static double getSwordDamage(ItemStack itemStack) {
		double damage = 0.0;
		Optional attributeModifier = itemStack.getAttributeModifiers().values().stream().findFirst();
		if (attributeModifier.isPresent()) {
			damage = ((AttributeModifier) attributeModifier.get()).getAmount();
		}
		return damage += EnchantmentHelper.getModifierForCreature(itemStack, EnumCreatureAttribute.UNDEFINED);
	}

	public static ItemStack getStackInSlot(int slot) {
		return InvUtil.mc.thePlayer.inventory.getStackInSlot(slot);
	}

	/*
	 * Enabled aggressive exception aggregation
	 */
	public static boolean isBestArmorOfTypeInInv(ItemStack is) {
		try {
			int otherProt;
			ItemStack stack;
			ItemArmor otherArmor;
			if (is == null) {
				return false;
			}
			if (is.getItem() == null) {
				return false;
			}
			if (is.getItem() != null && !(is.getItem() instanceof ItemArmor)) {
				return false;
			}
			ItemArmor ia = (ItemArmor) is.getItem();
			int prot = InvUtil.getArmorProt(is);
			int i = 0;
			while (i < 4) {
				stack = InvUtil.mc.thePlayer.inventory.armorInventory[i];
				if (stack != null) {
					otherArmor = (ItemArmor) stack.getItem();
					if (otherArmor.armorType == ia.armorType && (otherProt = InvUtil.getArmorProt(stack)) >= prot) {
						return false;
					}
				}
				++i;
			}
			i = 0;
			while (i < InvUtil.mc.thePlayer.inventory.getSizeInventory() - 4) {
				stack = InvUtil.mc.thePlayer.inventory.getStackInSlot(i);
				if (stack != null && stack.getItem() instanceof ItemArmor) {
					otherArmor = (ItemArmor) stack.getItem();
					if (otherArmor.armorType == ia.armorType && otherArmor != ia
							&& (otherProt = InvUtil.getArmorProt(stack)) >= prot) {
						return false;
					}
				}
				++i;
			}
		} catch (Exception ia) {
			// empty catch block
		}
		return true;
	}

	public static boolean hotbarHas(Item item) {
		int index = 0;
		while (index <= 36) {
			ItemStack stack = Minecraft.getMinecraft().thePlayer.inventory.getStackInSlot(index);
			if (stack != null && stack.getItem() == item) {
				return true;
			}
			++index;
		}
		return false;
	}

	public static boolean hotbarHas(Item item, int slotID) {
		int index = 0;
		while (index <= 36) {
			ItemStack stack = Minecraft.getMinecraft().thePlayer.inventory.getStackInSlot(index);
			if (stack != null && stack.getItem() == item && InvUtil.getSlotID(stack.getItem()) == slotID) {
				return true;
			}
			++index;
		}
		return false;
	}

	public static int getSlotID(Item item) {
		int index = 0;
		while (index <= 36) {
			ItemStack stack = Minecraft.getMinecraft().thePlayer.inventory.getStackInSlot(index);
			if (stack != null && stack.getItem() == item) {
				return index;
			}
			++index;
		}
		return -1;
	}

	public static ItemStack getItemBySlotID(int slotID) {
		int index = 0;
		while (index <= 36) {
			ItemStack stack = Minecraft.getMinecraft().thePlayer.inventory.getStackInSlot(index);
			if (stack != null && InvUtil.getSlotID(stack.getItem()) == slotID) {
				return stack;
			}
			++index;
		}
		return null;
	}

	public static int getArmorProt(ItemStack i) {
		int armorprot = -1;
		if (i != null && i.getItem() != null && i.getItem() instanceof ItemArmor) {
			armorprot = ((ItemArmor) i.getItem()).getArmorMaterial().getDamageReductionAmount(InvUtil.getItemType(i))
					+ EnchantmentHelper.getEnchantmentModifierDamage(new ItemStack[] { i }, DamageSource.generic);
		}
		return armorprot;
	}

	public static int getBestSwordSlotID(ItemStack item, double damage) {
		int index = 0;
		while (index <= 36) {
			ItemStack stack = Minecraft.getMinecraft().thePlayer.inventory.getStackInSlot(index);
			if (stack != null && stack == item && InvUtil.getSwordDamage(stack) == InvUtil.getSwordDamage(item)) {
				return index;
			}
			++index;
		}
		return -1;
	}

	public static final int findBlock(boolean hotbar) {
		for (int i = hotbar ? 36 : 9; i < 45; i++) {
			final ItemStack stack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
			if (stack != null && stack.getItem() instanceof ItemBlock) {
				final Block block = ((ItemBlock) stack.getItem()).getBlock();
				if (block.isFullBlock()) {
					return i;
				}
			}
		}
		return -1;
	}

	public boolean isBestChest(int slot) {
		if (InvUtil.getStackInSlot(slot) != null && InvUtil.getStackInSlot(slot).getItem() != null
				&& InvUtil.getStackInSlot(slot).getItem() instanceof ItemArmor) {
			ItemArmor ia1;
			int slotProtection = ((ItemArmor) InvUtil.mc.thePlayer.inventory.getStackInSlot(slot).getItem())
					.getArmorMaterial()
					.getDamageReductionAmount(InvUtil.getItemType(InvUtil.mc.thePlayer.inventory.getStackInSlot(slot)))
					+ EnchantmentHelper.getEnchantmentModifierDamage(
							new ItemStack[] { InvUtil.mc.thePlayer.inventory.getStackInSlot(slot) },
							DamageSource.generic);
			if (InvUtil.mc.thePlayer.inventory.armorInventory[2] != null) {
				ItemArmor ia = (ItemArmor) InvUtil.mc.thePlayer.inventory.armorInventory[2].getItem();
				ItemStack is = InvUtil.mc.thePlayer.inventory.armorInventory[2];
				ia1 = (ItemArmor) InvUtil.getStackInSlot(slot).getItem();
				int otherProtection = ((ItemArmor) is.getItem()).getArmorMaterial()
						.getDamageReductionAmount(InvUtil.getItemType(is))
						+ EnchantmentHelper.getEnchantmentModifierDamage(new ItemStack[] { is }, DamageSource.generic);
				if (otherProtection > slotProtection || otherProtection == slotProtection) {
					return false;
				}
			}
			int i = 0;
			while (i < InvUtil.mc.thePlayer.inventory.getSizeInventory()) {
				if (InvUtil.getStackInSlot(i) != null
						&& InvUtil.mc.thePlayer.inventory.getStackInSlot(i).getItem() instanceof ItemArmor) {
					int otherProtection = ((ItemArmor) InvUtil.mc.thePlayer.inventory.getStackInSlot(i).getItem())
							.getArmorMaterial().getDamageReductionAmount(
									InvUtil.getItemType(InvUtil.mc.thePlayer.inventory.getStackInSlot(i)))
							+ EnchantmentHelper.getEnchantmentModifierDamage(
									new ItemStack[] { InvUtil.mc.thePlayer.inventory.getStackInSlot(i) },
									DamageSource.generic);
					ia1 = (ItemArmor) InvUtil.getStackInSlot(slot).getItem();
					ItemArmor ia2 = (ItemArmor) InvUtil.getStackInSlot(i).getItem();
					if (ia1.armorType == 1 && ia2.armorType == 1 && otherProtection > slotProtection) {
						return false;
					}
				}
				++i;
			}
		}
		return true;
	}

	public boolean isBestHelmet(int slot) {
		if (InvUtil.getStackInSlot(slot) != null && InvUtil.getStackInSlot(slot).getItem() != null
				&& InvUtil.getStackInSlot(slot).getItem() instanceof ItemArmor) {
			ItemArmor ia1;
			int slotProtection = ((ItemArmor) InvUtil.mc.thePlayer.inventory.getStackInSlot(slot).getItem())
					.getArmorMaterial()
					.getDamageReductionAmount(InvUtil.getItemType(InvUtil.mc.thePlayer.inventory.getStackInSlot(slot)))
					+ EnchantmentHelper.getEnchantmentModifierDamage(
							new ItemStack[] { InvUtil.mc.thePlayer.inventory.getStackInSlot(slot) },
							DamageSource.generic);
			if (InvUtil.mc.thePlayer.inventory.armorInventory[3] != null) {
				ItemArmor ia = (ItemArmor) InvUtil.mc.thePlayer.inventory.armorInventory[3].getItem();
				ItemStack is = InvUtil.mc.thePlayer.inventory.armorInventory[3];
				ia1 = (ItemArmor) InvUtil.getStackInSlot(slot).getItem();
				int otherProtection = ((ItemArmor) is.getItem()).getArmorMaterial()
						.getDamageReductionAmount(InvUtil.getItemType(is))
						+ EnchantmentHelper.getEnchantmentModifierDamage(new ItemStack[] { is }, DamageSource.generic);
				if (otherProtection > slotProtection || otherProtection == slotProtection) {
					return false;
				}
			}
			int i = 0;
			while (i < InvUtil.mc.thePlayer.inventory.getSizeInventory()) {
				if (InvUtil.getStackInSlot(i) != null
						&& InvUtil.mc.thePlayer.inventory.getStackInSlot(i).getItem() instanceof ItemArmor) {
					int otherProtection = ((ItemArmor) InvUtil.mc.thePlayer.inventory.getStackInSlot(i).getItem())
							.getArmorMaterial().getDamageReductionAmount(
									InvUtil.getItemType(InvUtil.mc.thePlayer.inventory.getStackInSlot(i)))
							+ EnchantmentHelper.getEnchantmentModifierDamage(
									new ItemStack[] { InvUtil.mc.thePlayer.inventory.getStackInSlot(i) },
									DamageSource.generic);
					ia1 = (ItemArmor) InvUtil.getStackInSlot(slot).getItem();
					ItemArmor ia2 = (ItemArmor) InvUtil.getStackInSlot(i).getItem();
					if (ia1.armorType == 0 && ia2.armorType == 0 && otherProtection > slotProtection) {
						return false;
					}
				}
				++i;
			}
		}
		return true;
	}

	public boolean isBestLeggings(int slot) {
		if (InvUtil.getStackInSlot(slot) != null && InvUtil.getStackInSlot(slot).getItem() != null
				&& InvUtil.getStackInSlot(slot).getItem() instanceof ItemArmor) {
			ItemArmor ia1;
			int slotProtection = ((ItemArmor) InvUtil.mc.thePlayer.inventory.getStackInSlot(slot).getItem())
					.getArmorMaterial()
					.getDamageReductionAmount(InvUtil.getItemType(InvUtil.mc.thePlayer.inventory.getStackInSlot(slot)))
					+ EnchantmentHelper.getEnchantmentModifierDamage(
							new ItemStack[] { InvUtil.mc.thePlayer.inventory.getStackInSlot(slot) },
							DamageSource.generic);
			if (InvUtil.mc.thePlayer.inventory.armorInventory[1] != null) {
				ItemArmor ia = (ItemArmor) InvUtil.mc.thePlayer.inventory.armorInventory[1].getItem();
				ItemStack is = InvUtil.mc.thePlayer.inventory.armorInventory[1];
				ia1 = (ItemArmor) InvUtil.getStackInSlot(slot).getItem();
				int otherProtection = ((ItemArmor) is.getItem()).getArmorMaterial()
						.getDamageReductionAmount(InvUtil.getItemType(is))
						+ EnchantmentHelper.getEnchantmentModifierDamage(new ItemStack[] { is }, DamageSource.generic);
				if (otherProtection > slotProtection || otherProtection == slotProtection) {
					return false;
				}
			}
			int i = 0;
			while (i < InvUtil.mc.thePlayer.inventory.getSizeInventory()) {
				if (InvUtil.getStackInSlot(i) != null
						&& InvUtil.mc.thePlayer.inventory.getStackInSlot(i).getItem() instanceof ItemArmor) {
					int otherProtection = ((ItemArmor) InvUtil.mc.thePlayer.inventory.getStackInSlot(i).getItem())
							.getArmorMaterial().getDamageReductionAmount(
									InvUtil.getItemType(InvUtil.mc.thePlayer.inventory.getStackInSlot(i)))
							+ EnchantmentHelper.getEnchantmentModifierDamage(
									new ItemStack[] { InvUtil.mc.thePlayer.inventory.getStackInSlot(i) },
									DamageSource.generic);
					ia1 = (ItemArmor) InvUtil.getStackInSlot(slot).getItem();
					ItemArmor ia2 = (ItemArmor) InvUtil.getStackInSlot(i).getItem();
					if (ia1.armorType == 2 && ia2.armorType == 2 && otherProtection > slotProtection) {
						return false;
					}
				}
				++i;
			}
		}
		return true;
	}

	public boolean isBestBoots(int slot) {
		if (InvUtil.getStackInSlot(slot) != null && InvUtil.getStackInSlot(slot).getItem() != null
				&& InvUtil.getStackInSlot(slot).getItem() instanceof ItemArmor) {
			ItemArmor ia1;
			int slotProtection = ((ItemArmor) InvUtil.mc.thePlayer.inventory.getStackInSlot(slot).getItem())
					.getArmorMaterial()
					.getDamageReductionAmount(InvUtil.getItemType(InvUtil.mc.thePlayer.inventory.getStackInSlot(slot)))
					+ EnchantmentHelper.getEnchantmentModifierDamage(
							new ItemStack[] { InvUtil.mc.thePlayer.inventory.getStackInSlot(slot) },
							DamageSource.generic);
			if (InvUtil.mc.thePlayer.inventory.armorInventory[0] != null) {
				ItemArmor ia = (ItemArmor) InvUtil.mc.thePlayer.inventory.armorInventory[0].getItem();
				ItemStack is = InvUtil.mc.thePlayer.inventory.armorInventory[0];
				ia1 = (ItemArmor) InvUtil.getStackInSlot(slot).getItem();
				int otherProtection = ((ItemArmor) is.getItem()).getArmorMaterial()
						.getDamageReductionAmount(InvUtil.getItemType(is))
						+ EnchantmentHelper.getEnchantmentModifierDamage(new ItemStack[] { is }, DamageSource.generic);
				if (otherProtection > slotProtection || otherProtection == slotProtection) {
					return false;
				}
			}
			int i = 0;
			while (i < InvUtil.mc.thePlayer.inventory.getSizeInventory()) {
				if (InvUtil.getStackInSlot(i) != null
						&& InvUtil.mc.thePlayer.inventory.getStackInSlot(i).getItem() instanceof ItemArmor) {
					int otherProtection = ((ItemArmor) InvUtil.mc.thePlayer.inventory.getStackInSlot(i).getItem())
							.getArmorMaterial().getDamageReductionAmount(
									InvUtil.getItemType(InvUtil.mc.thePlayer.inventory.getStackInSlot(i)))
							+ EnchantmentHelper.getEnchantmentModifierDamage(
									new ItemStack[] { InvUtil.mc.thePlayer.inventory.getStackInSlot(i) },
									DamageSource.generic);
					ia1 = (ItemArmor) InvUtil.getStackInSlot(slot).getItem();
					ItemArmor ia2 = (ItemArmor) InvUtil.getStackInSlot(i).getItem();
					if (ia1.armorType == 3 && ia2.armorType == 3 && otherProtection > slotProtection) {
						return false;
					}
				}
				++i;
			}
		}
		return true;
	}

	public static final boolean hasBlockInHotbar() {
		return findBlock(true) != -1;
	}

	public static int getItemType(ItemStack itemStack) {
		if (itemStack.getItem() instanceof ItemArmor) {
			ItemArmor armor = (ItemArmor) itemStack.getItem();
			return armor.armorType;
		}
		return -1;
	}

	public static float getItemDamage(ItemStack itemStack) {
		Iterator iterator;
		Multimap multimap = itemStack.getAttributeModifiers();
		if (!multimap.isEmpty() && (iterator = multimap.entries().iterator()).hasNext()) {
			Map.Entry entry = (Entry) iterator.next();
			AttributeModifier attributeModifier = (AttributeModifier) entry.getValue();
			double damage = attributeModifier.getOperation() != 1 && attributeModifier.getOperation() != 2
					? attributeModifier.getAmount()
					: attributeModifier.getAmount() * 100.0;
			return attributeModifier.getAmount() > 1.0 ? 1.0f + (float) damage : 1.0f;
		}
		return 1.0f;
	}

	public boolean hasItemMoreTimes(int slotIn) {
		boolean has = false;
		ArrayList<ItemStack> stacks = new ArrayList<ItemStack>();
		stacks.clear();
		int i = 0;
		while (i < InvUtil.mc.thePlayer.inventory.getSizeInventory()) {
			if (!stacks.contains(InvUtil.getStackInSlot(i))) {
				stacks.add(InvUtil.getStackInSlot(i));
			} else if (InvUtil.getStackInSlot(i) == InvUtil.getStackInSlot(slotIn)) {
				return true;
			}
			++i;
		}
		return false;
	}

	public int getBestWeaponInHotbar() {
		int originalSlot = InvUtil.mc.thePlayer.inventory.currentItem;
		int weaponSlot = -1;
		float weaponDamage = 1.0f;
		int slot = 0;
		while (slot < 9) {
			ItemStack itemStack = InvUtil.mc.thePlayer.inventory.getStackInSlot(slot);
			if (itemStack != null) {
				float damage = InvUtil.getItemDamage(itemStack);
				if ((damage += EnchantmentHelper.getModifierForCreature(itemStack,
						EnumCreatureAttribute.UNDEFINED)) > weaponDamage) {
					weaponDamage = damage;
					weaponSlot = slot;
				}
			}
			slot = (byte) (slot + 1);
		}
		if (weaponSlot != -1) {
			return weaponSlot;
		}
		return originalSlot;
	}

	public int getBestWeapon() {
		int originalSlot = InvUtil.mc.thePlayer.inventory.currentItem;
		int weaponSlot = -1;
		float weaponDamage = 1.0f;
		int slot = 0;
		while (slot < InvUtil.mc.thePlayer.inventory.getSizeInventory()) {
			ItemStack itemStack;
			if (InvUtil.getStackInSlot(slot) != null && (itemStack = InvUtil.getStackInSlot(slot)) != null
					&& itemStack.getItem() != null && itemStack.getItem() instanceof ItemSword) {
				float damage = InvUtil.getItemDamage(itemStack);
				if ((damage += EnchantmentHelper.getModifierForCreature(itemStack,
						EnumCreatureAttribute.UNDEFINED)) > weaponDamage) {
					weaponDamage = damage;
					weaponSlot = slot;
				}
			}
			slot = (byte) (slot + 1);
		}
		if (weaponSlot != -1) {
			return weaponSlot;
		}
		return originalSlot;
	}

	public int getArmorProt(int i) {
		int armorprot = -1;
		if (InvUtil.getStackInSlot(i) != null && InvUtil.getStackInSlot(i).getItem() != null
				&& InvUtil.getStackInSlot(i).getItem() instanceof ItemArmor) {
			armorprot = ((ItemArmor) InvUtil.mc.thePlayer.inventory.getStackInSlot(i).getItem()).getArmorMaterial()
					.getDamageReductionAmount(InvUtil.getItemType(InvUtil.mc.thePlayer.inventory.getStackInSlot(i)))
					+ EnchantmentHelper.getEnchantmentModifierDamage(
							new ItemStack[] { InvUtil.mc.thePlayer.inventory.getStackInSlot(i) }, DamageSource.generic);
		}
		return armorprot;
	}

	public static int getFirstItem(Item i1) {
		int i = 0;
		while (i < InvUtil.mc.thePlayer.inventory.getSizeInventory()) {
			if (InvUtil.getStackInSlot(i) != null && InvUtil.getStackInSlot(i).getItem() != null
					&& InvUtil.getStackInSlot(i).getItem() == i1) {
				return i;
			}
			++i;
		}
		return -1;
	}

	public static boolean isBestSword(ItemStack itemSword, int slot) {
		if (itemSword != null && itemSword.getItem() instanceof ItemSword) {
			int i = 0;
			while (i < InvUtil.mc.thePlayer.inventory.getSizeInventory()) {
				ItemStack iStack = InvUtil.mc.thePlayer.inventory.getStackInSlot(i);
				if (iStack != null && iStack.getItem() instanceof ItemSword
						&& InvUtil.getItemDamage(iStack) >= InvUtil.getItemDamage(itemSword) && slot != i) {
					return false;
				}
				++i;
			}
		}
		return true;
	}

	public static int findEmptySlot() {
		for (int i = 0; i < 8; i++) {
			if (mc.thePlayer.inventory.mainInventory[i] == null)
				return i;
		}

		return mc.thePlayer.inventory.currentItem + (mc.thePlayer.inventory.getCurrentItem() == null ? 0
				: ((mc.thePlayer.inventory.currentItem < 8) ? 1 : -1));
	}

	public static int findEmptySlot(int priority) {
		if (mc.thePlayer.inventory.mainInventory[priority] == null)
			return priority;

		return findEmptySlot();
	}

	public static void swapShift(int slot) {
		Minecraft.getMinecraft().playerController.windowClick(
				Minecraft.getMinecraft().thePlayer.inventoryContainer.windowId, slot, 0, 1,
				Minecraft.getMinecraft().thePlayer);
	}

	public static void swap(int slot, int hotbarNum) {
		Minecraft.getMinecraft().playerController.windowClick(
				Minecraft.getMinecraft().thePlayer.inventoryContainer.windowId, slot, hotbarNum, 2,
				Minecraft.getMinecraft().thePlayer);
	}

	public static boolean isFull() {
		return !Arrays.asList(mc.thePlayer.inventory.mainInventory).contains(null);
	}

	public static int armorSlotToNormalSlot(int armorSlot) {
		return 8 - armorSlot;
	}

	public static void block() {
		mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, mc.thePlayer.inventory.getCurrentItem());
	}

	public static ItemStack getCurrentItem() {
		return mc.thePlayer.getCurrentEquippedItem() == null ? new ItemStack(Blocks.air)
				: mc.thePlayer.getCurrentEquippedItem();
	}

	public static ItemStack getItemBySlot(int slot) {
		return mc.thePlayer.inventory.mainInventory[slot] == null ? new ItemStack(Blocks.air)
				: mc.thePlayer.inventory.mainInventory[slot];
	}

	public static List<ItemStack> getHotbarContent() {
		List<ItemStack> result = new ArrayList<>();
		for (int i = 0; i < 9; i++) {
			result.add(mc.thePlayer.inventory.mainInventory[i]);
		}
		return result;
	}

	public static List<ItemStack> getAllInventoryContent() {
		List<ItemStack> result = new ArrayList<>();
		for (int i = 0; i < 35; i++) {
			result.add(mc.thePlayer.inventory.mainInventory[i]);
		}
		return result;
	}

	public static List<ItemStack> getInventoryContent() {
		List<ItemStack> result = new ArrayList<>();
		for (int i = 9; i < 35; i++) {
			result.add(mc.thePlayer.inventory.mainInventory[i]);
		}
		return result;
	}

	public static int getEmptySlotInHotbar() {
		for (int i = 0; i < 9; i++) {
			if (mc.thePlayer.inventory.mainInventory[i] == null)
				return i;
		}
		return -1;
	}

	public static float getArmorScore(ItemStack itemStack) {
		if (itemStack == null || !(itemStack.getItem() instanceof ItemArmor))
			return -1;

		ItemArmor itemArmor = (ItemArmor) itemStack.getItem();
		float score = 0;

		// basic reduce amount
		score += itemArmor.damageReduceAmount;

		if (EnchantmentHelper.getEnchantments(itemStack).size() <= 0)
			score -= 0.1;

		int protection = EnchantmentHelper.getEnchantmentLevel(Enchantment.protection.effectId, itemStack);

		score += protection * 0.2;

		return score;
	}

	public static boolean hasWeapon() {
		if (mc.thePlayer.inventory.getCurrentItem() != null)
			return false;

		return (mc.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemAxe)
				|| (mc.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemSword);
	}

	public static boolean isHeldingSword() {
		return mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword;
	}

	public void dropSlot(int slot) {
		int windowId = new GuiInventory(InvUtil.mc.thePlayer).inventorySlots.windowId;
		InvUtil.mc.playerController.windowClick(windowId, slot, 1, 4, InvUtil.mc.thePlayer);
	}

	public boolean isBestSword(int slotIn) {
		return this.getBestWeapon() == slotIn;
	}


}
