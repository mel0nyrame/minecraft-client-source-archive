package cn.Hanabi.utils.Entity;

import com.darkmagician6.eventapi.EventTarget;

import cn.Hanabi.events.EventUpdate;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;

public class ServerUtils {
	Minecraft mc = Minecraft.getMinecraft();

	public static Server server = Server.Unknown;

	@EventTarget
	public void onTicks(EventUpdate e) {
		if (mc.isSingleplayer()) {
			server = Server.SinglePlayer;
		} else {
			ServerData data = mc.getCurrentServerData();
			String motd = data.serverMOTD;

			if (motd.contains("Hypixel")) {
				if (motd.contains("内测")) {
					server = Server.HypixelCN;
				} else {
					server = Server.Hypixel;
				}
			} else if (motd.contains("Mineplex")) {
				server = Server.Mineplex;
			} else if (motd.contains("CubeCraft")) {
				server = Server.CubeCraft;
			} else {
				server = Server.Unknown;
			}
		}
	}

	public enum Server {
		Hypixel, HypixelCN, Mineplex, CubeCraft, Unknown, SinglePlayer
	}
}
