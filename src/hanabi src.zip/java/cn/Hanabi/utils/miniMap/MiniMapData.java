package cn.Hanabi.utils.miniMap;

public class MiniMapData {
    private final int height;
    private final int width;
    int posXCenter = 0;
    int posZCenter = 0;
    int posXStart = 0;
    int posZStart = 0;
    byte[] blockData;

    public MiniMapData(int chunkRadius) {
        this.height = (1 + chunkRadius * 2) * 16;
        this.width = (1 + chunkRadius * 2) * 16;
        this.blockData = new byte[this.height * this.width];
    }

    public void fillInChunkData(MiniMapChunk miniMapChunk) {
        int i2 = Math.abs((miniMapChunk.getChunkX() << 4) - this.posXStart);
        int j2 = Math.abs((miniMapChunk.getChunkZ() << 4) - this.posZStart);
        int k2 = i2 + j2;
        int l2 = 0;
        for (byte b0 : miniMapChunk.getTopLayerData()) {
            if (l2 != 0 && l2 % 16 == 0) {
                k2 += this.width - 16;
            }
            this.blockData[k2] = b0;
            ++l2;
        }
    }

    public byte[] getBlockData() {
        return this.blockData;
    }
}

