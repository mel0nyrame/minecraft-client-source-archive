package cn.Hanabi.utils;

import com.google.gson.JsonObject;

import java.io.Reader;

import com.google.gson.JsonParser;

import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.UUID;
import java.util.Map;

public enum ProfileUtil {
    INSTANCE("INSTANCE", 0);

    private static final Map<String, UUID> CACHED_NAMES;
    private static final String NAME = "https://api.mojang.com/users/profiles/minecraft/%s";
    private static final String PROFILE = "https://sessionserver.mojang.com/session/minecraft/profile/%s";

    static {
        CACHED_NAMES = new HashMap<String, UUID>();
    }

    ProfileUtil(final String s, final int n) {
    }

    public UUID getUUID(final String name) {
        if (ProfileUtil.CACHED_NAMES.containsKey(name)) {
            return ProfileUtil.CACHED_NAMES.get(name);
        }
        try {
            final InputStreamReader uuidReader = new InputStreamReader(new URL(String.format("https://api.mojang.com/users/profiles/minecraft/%s", name)).openStream());
            final JsonObject jsonObject = new JsonParser().parse(uuidReader).getAsJsonObject();
            String unfomatted = jsonObject.get("id").getAsString();
            String formatted = "";
            int[] array;
            for (int length2 = (array = new int[]{8, 4, 4, 4, 12}).length, j = 0; j < length2; ++j) {
                final int length = array[j];
                formatted = formatted + "-";
                for (int i = 0; i < length; ++i) {
                    formatted = formatted + unfomatted.charAt(0);
                    unfomatted = unfomatted.substring(1);
                }
            }
            formatted = formatted.substring(1);
            final UUID uuid = UUID.fromString(formatted);
            ProfileUtil.CACHED_NAMES.put(name, uuid);
            return uuid;
        } catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }

    public String getName(final UUID uuid) {
        try {
            if (ProfileUtil.CACHED_NAMES.containsValue(uuid)) {
                return ProfileUtil.CACHED_NAMES.entrySet().stream().filter(entry -> uuid == entry.getValue()).findFirst().get().getKey();
            }
        } catch (Exception ex) {
        }
        try {
            final InputStreamReader uuidReader = new InputStreamReader(new URL(String.format("https://sessionserver.mojang.com/session/minecraft/profile/%s", uuid.toString().replaceAll("-", ""))).openStream());
            final JsonObject jsonObject = new JsonParser().parse(uuidReader).getAsJsonObject();
            final String name = jsonObject.get("name").getAsString();
            ProfileUtil.CACHED_NAMES.put(name, uuid);
            return name;
        } catch (Exception exception) {
            exception.printStackTrace();
            return "";
        }
    }
}
