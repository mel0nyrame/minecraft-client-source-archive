package cn.Hanabi.utils;

import cn.Hanabi.gui.particles.ParticleGenerator;
import org.lwjgl.opengl.GL11;

import net.minecraft.client.renderer.GlStateManager;

public final class ParticleUtils {

    private static final ParticleGenerator particleGenerator = new ParticleGenerator(100);

    public static void drawParticles(int mouseX, int mouseY) {
    	GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GL11.glEnable(GL11.GL_POLYGON_SMOOTH);
        particleGenerator.draw(mouseX, mouseY);
        GL11.glDisable(GL11.GL_POLYGON_SMOOTH);
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }
}