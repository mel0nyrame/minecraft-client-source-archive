package cn.Hanabi.utils.Rotation;

public class AimHelper {
    public static boolean looked;
}
