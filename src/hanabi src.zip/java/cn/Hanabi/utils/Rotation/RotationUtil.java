package cn.Hanabi.utils.Rotation;

import cn.Hanabi.Wrapper;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.injection.interfaces.IEntity;
import cn.Hanabi.modules.modules.combat.KillAura;
import cn.Hanabi.utils.Location;
import cn.Hanabi.utils.MathUtils;
import cn.Hanabi.utils.Misc.Vector3D;
import cn.Hanabi.utils.Vec3d;
import io.netty.util.internal.ThreadLocalRandom;
import me.tojatta.api.utilities.angle.Angle;
import me.tojatta.api.utilities.angle.AngleUtility;
import me.tojatta.api.utilities.vector.impl.Vector3;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.*;
import net.minecraft.world.World;

import javax.vecmath.Vector3d;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

public class RotationUtil {

    public static final List<Float> YAW_SPEEDS = null;
    private static final Minecraft mc = Minecraft.getMinecraft();
    private static final MathUtils randomUtil = new MathUtils();
    public static Rotation currentRotation;
    public static Rotation lastRotation = new Rotation(0.0F, 0.0F);
    public static boolean moveToRotation;
    public static float[] prevRotations = new float[2];


    public static float[] getRotations(EntityLivingBase ent) {
        double x = ent.posX;
        double z = ent.posZ;
        double y = ent.posY + (ent.getEyeHeight() / 2.0F);
        return getRotationFromPosition(x, z, y);
    }

    public static float roundTo360(float value) {
        return value % 360.0F;
    }

    public static float[] getRotationsWithUpdate(EntityLivingBase ent, EventPreMotion event) {
        double x = ent.posX;
        double z = ent.posZ;
        double y = ent.posY + (double)(ent.getEyeHeight() / 2.0 - 0.225);
        return getRotationFromPositionWithUpdate(x, z, y,event);
    }

    public static float[] getRotationFromPositionWithUpdate(double x, double z, double y,EventPreMotion event) {
        double xDiff = x - event.getX();
        double zDiff = z - event.getZ();
        double yDiff = y - event.getY() - 0.6D;
        double dist = (double) MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float) ((Math.atan2(zDiff, xDiff) * 180.0D / (Math.PI)) - 90.0F);
        float pitch = (float) (-(Math.atan2(yDiff, dist) * 180.0D / (Math.PI)));
        return new float[]{yaw, pitch};
    }

    public static float[] getNeededFacing(Vec3 target, Vec3 from) {
        double diffX = target.xCoord - from.xCoord;
        double diffY = target.yCoord - from.yCoord;
        double diffZ = target.zCoord - from.zCoord;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[]{MathHelper.wrapAngleTo180_float(yaw), MathHelper.wrapAngleTo180_float(pitch)};
    }



    public static float[] Rotation(Entity entity) {
        if (entity == null) {
            return null;
        } else {
            double diffX = entity.posX + (entity.posX - entity.lastTickPosX) * 2.0D - mc.thePlayer.posX;
            double diffZ = entity.posZ + (entity.posZ - entity.lastTickPosZ) * 2.0D - mc.thePlayer.posZ;
            double diffY;
            if (entity instanceof EntityLivingBase) {
                EntityLivingBase elb = (EntityLivingBase)entity;
                diffY = elb.posY + (double)elb.getEyeHeight() - (mc.thePlayer.posY + (double)mc.thePlayer.getEyeHeight());
            } else {
                diffY = (entity.getEntityBoundingBox().minY + entity.getEntityBoundingBox().maxY) / 2.0D - (mc.thePlayer.posY + (double)mc.thePlayer.getEyeHeight());
            }

            double dist = (double)MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
            float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0D / 3.141592653589793D) - 90.0F;
            float pitch = (float)(-(Math.atan2(diffY, dist) * 180.0D / 3.141592653589793D));
            return new float[]{yaw, pitch};
        }
    }

    
    public static float getYawChangeToEntity(Entity entity) {
        double deltaX = entity.posX - mc.thePlayer.posX;
        double deltaZ = entity.posZ - mc.thePlayer.posZ;
        double yawToEntity;
        if (deltaZ < 0.0D && deltaX < 0.0D) {
            yawToEntity = 90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
        } else if (deltaZ < 0.0D && deltaX > 0.0D) {
            yawToEntity = -90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
        } else {
            yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }

        return MathHelper.wrapAngleTo180_float(-(mc.thePlayer.rotationYaw - (float)yawToEntity));
    }

    public static float getPitchChangeToEntity(Entity entity) {
        double deltaX = entity.posX - mc.thePlayer.posX;
        double deltaZ = entity.posZ - mc.thePlayer.posZ;
        double deltaY = entity.posY - 1.6D + (double)entity.getEyeHeight() - mc.thePlayer.posY;
        double distanceXZ = (double)MathHelper.sqrt_double(deltaX * deltaX + deltaZ * deltaZ);
        double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));
        return -MathHelper.wrapAngleTo180_float(mc.thePlayer.rotationPitch - (float)pitchToEntity);
    }



    public static float[] getRotaions(Entity e) {
        final Vec3d eyesPos = new Vec3d(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight(), Minecraft.getMinecraft().thePlayer.posZ);
        final AxisAlignedBB bb = e.getEntityBoundingBox();
        final Vec3d vec = new Vec3d(bb.minX + (bb.maxX - bb.minX) * 0.5, bb.minY + (bb.maxY - bb.minY) * 0.5, bb.minZ + (bb.maxZ - bb.minZ) * 0.5);
        final double diffX = vec.xCoord - eyesPos.xCoord;
        final double diffY = vec.yCoord - eyesPos.yCoord;
        final double diffZ = vec.zCoord - eyesPos.zCoord;
        final double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        final float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        final float pitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[]{MathHelper.wrapAngleTo180_float(yaw), MathHelper.wrapAngleTo180_float(pitch)};
    }


    public static float[] getAngles(Entity entity) {
        float xDiff = (float)(entity.posX - - mc.thePlayer.posX);
        float yDiff = (float)(entity.getEntityBoundingBox().minY + (double)entity.getEyeHeight() - mc.thePlayer.getEntityBoundingBox().maxY);
        float zDiff = (float)(entity.posZ - - mc.thePlayer.posZ);
        float yaw = (float)(Math.atan2((double)zDiff, (double)xDiff) * 180.0 / 3.141592653589793 - 90.0);
        float pitch = (float)(-Math.toDegrees((double)Math.atan((double)((double)yDiff / Math.sqrt((double)(zDiff * zDiff + xDiff * xDiff))))));
        return new float[]{yaw, pitch};
    }

    public static float getYaw(Entity ent) {
        float x = (float) (ent.posX - mc.thePlayer.posX);
        float y = (float) (ent.posY - mc.thePlayer.posY);
        float z = (float) (ent.posZ - mc.thePlayer.posZ);
        float norm = (float) Math.sqrt(x * x + y * y + z * z);
        float var10000 = y / norm;
        float yaw = (float) (Math.atan2(x, z) * 57.29577951308232D);
        yaw = -yaw;
        return yaw;
    }


    public static float getPitch(Entity ent) {
        float x = (float) (ent.posX - mc.thePlayer.posX);
        float y = (float) (ent.posY - mc.thePlayer.posY);
        float z = (float) (ent.posZ - mc.thePlayer.posZ);
        float norm = (float) Math.sqrt(x * x + y * y + z * z);
        y /= norm;
        float pitch = (float) (Math.asin(y) * 57.29577951308232D);
        pitch = -pitch;
        return pitch;
    }


    public static float[] getSmoothNeededRotations(Vec3 vec, float yaw, float pitch) {
        final Vec3 eyesPos = getEyePos();
        final double diffX = vec.xCoord - eyesPos.xCoord;
        final double diffY = vec.yCoord - eyesPos.yCoord;
        final double diffZ = vec.zCoord - eyesPos.zCoord;
        final double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        final float rotationYaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        final float rotationPitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));

        return new float[]{
                updateRotation(mc.thePlayer.rotationYaw, rotationYaw, yaw / 4),
                updateRotation(mc.thePlayer.rotationPitch, rotationPitch, pitch / 4)
        };
    }

    public static float[] getAnglesSmooth(Entity e) {
        return new float[]{getYawChangeToEntitySmooth(e) + mc.thePlayer.rotationYaw, getPitchChangeToEntitySmooth(e) + mc.thePlayer.rotationPitch};
    }

    public static float getPitchChangeToEntitySmooth(Entity entity) {
        double deltaX = entity.posX - mc.thePlayer.posX;
        double deltaZ = entity.posZ - mc.thePlayer.posZ;
        double deltaY = entity.posY - mc.thePlayer.posY - 0.1D - 0.08D;
        double distanceXZ = (double)MathHelper.sqrt_double(deltaX * deltaX + deltaZ * deltaZ);
        double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));
        return -MathHelper.wrapAngleTo180_float(mc.thePlayer.rotationPitch - (float)pitchToEntity);
    }

    public static float getYawChangeToEntitySmooth(Entity entity) {
        double deltaX = entity.posX - mc.thePlayer.posX;
        double deltaZ = entity.posZ - mc.thePlayer.posZ;
        double yawToEntity;
        if (deltaZ < 0.0D && deltaX < 0.0D) {
            yawToEntity = 90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
        } else if (deltaZ < 0.0D && deltaX > 0.0D) {
            yawToEntity = -90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
        } else {
            yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }

        return MathHelper.wrapAngleTo180_float(-(mc.thePlayer.rotationYaw - (float)yawToEntity));
    }



    public static float wrapAngleTo65_float(float p_761420) {
        p_761420 %= 360.0F;

        if (p_761420 >= 65.0F) {
            p_761420 -= 360.0F;
        }

        if (p_761420 < -65.0F) {
            p_761420 += 360.0F;
        }

        return p_761420;
    }

    public static MovingObjectPosition rayCast(final EntityPlayerSP player, final double x, final double y, final double z) {
        final HashSet<Entity> excluded = new HashSet<>();
        excluded.add(player);
        return tracePathD(player.worldObj, player.posX, player.posY + player.getEyeHeight(), player.posZ, x, y, z, 1.0f, excluded);
    }

    private static MovingObjectPosition tracePathD(final World w, final double posX, final double posY, final double posZ, final double v, final double v1, final double v2, final float borderSize, final HashSet<Entity> exclude) {
        return tracePath(w, (float) posX, (float) posY, (float) posZ, (float) v, (float) v1, (float) v2, borderSize, exclude);
    }

    private static MovingObjectPosition tracePath(final World world, final float x, final float y, final float z, final float tx, final float ty, final float tz, final float borderSize, final HashSet<Entity> excluded) {
        Vec3 startVec = new Vec3(x, y, z);
        Vec3 endVec = new Vec3(tx, ty, tz);
        final float minX = (x < tx) ? x : tx;
        final float minY = (y < ty) ? y : ty;
        final float minZ = (z < tz) ? z : tz;
        final float maxX = (x > tx) ? x : tx;
        final float maxY = (y > ty) ? y : ty;
        final float maxZ = (z > tz) ? z : tz;
        final AxisAlignedBB bb = new AxisAlignedBB(minX, minY, minZ, maxX, maxY, maxZ).expand(borderSize, borderSize, borderSize);
        final ArrayList<Entity> allEntities = (ArrayList<Entity>) world.getEntitiesWithinAABBExcludingEntity(null, bb);
        MovingObjectPosition blockHit = world.rayTraceBlocks(startVec, endVec);
        startVec = new Vec3(x, y, z);
        endVec = new Vec3(tx, ty, tz);
        Entity closestHitEntity = null;
        float closestHit = Float.POSITIVE_INFINITY;
        float currentHit;
        for (final Entity ent : allEntities) {
            if (ent.canBeCollidedWith() && !excluded.contains(ent)) {
                final float entBorder = ent.getCollisionBorderSize();
                AxisAlignedBB entityBb = ent.getEntityBoundingBox();
                if (entityBb == null) {
                    continue;
                }
                entityBb = entityBb.expand(entBorder, entBorder, entBorder);
                final MovingObjectPosition intercept = entityBb.calculateIntercept(startVec, endVec);
                if (intercept == null) {
                    continue;
                }
                currentHit = (float) intercept.hitVec.distanceTo(startVec);
                if (currentHit >= closestHit && currentHit != 0.0f) {
                    continue;
                }
                closestHit = currentHit;
                closestHitEntity = ent;
            }
        }
        if (closestHitEntity != null) {
            blockHit = new MovingObjectPosition(closestHitEntity);
        }
        return blockHit;
    }

    public static Vec3 getEyePos() {
        return new Vec3(mc.thePlayer.posX, mc.thePlayer.posY + mc.thePlayer.getEyeHeight(), mc.thePlayer.posZ);
    }


    public static float[] getRots(Entity p_70625_1_, float p_70625_2_, float p_70625_3_) {
        Random r = new Random();
        boolean yup = r.nextBoolean();
        boolean rup = r.nextBoolean();
        double var4 = (p_70625_1_.posX) - Minecraft.getMinecraft().thePlayer.posX;
        double var8 = (p_70625_1_.posZ) - Minecraft.getMinecraft().thePlayer.posZ;
        double var6;

        if (p_70625_1_ instanceof EntityLivingBase) {
            EntityLivingBase var14 = (EntityLivingBase) p_70625_1_;
            var6 = (var14.posY - 0.5f) + (double) var14.getEyeHeight() - (Minecraft.getMinecraft().thePlayer.posY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
        } else {
            var6 = (p_70625_1_.getEntityBoundingBox().minY + p_70625_1_.getEntityBoundingBox().maxY) / 2.0D - (Minecraft.getMinecraft().thePlayer.posY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
        }

        double var141 = (double) MathHelper.sqrt_double(var4 * var4 + var8 * var8);
        float var12 = (float) (Math.atan2(var8, var4) * 180.0D / Math.PI) - 90.0F;
        float var13 = (float) (-(Math.atan2(var6, var141) * 180.0D / Math.PI));
        float pitch = updateRotation(Minecraft.getMinecraft().thePlayer.rotationPitch, var13, p_70625_3_);
        float yaw = updateRotation(Minecraft.getMinecraft().thePlayer.rotationYaw, var12, p_70625_2_);
        return new float[]{yaw, pitch};
    }





    public static float[] getAngle(float[] original, float[] rotations, float turnRate) {
        float distanceToAngle = getAngle(original, rotations);
        float[] newAngle = new float[]{0.0F, 0.0F};
        original = normalizeAngles(original);
        rotations = normalizeAngles(rotations);
        if (distanceToAngle < turnRate) {
            return rotations;
        } else {
            float oldYaw = original[0];
            float newYaw = rotations[0];
            float distanceYaw = Math.abs(oldYaw > newYaw ? oldYaw - newYaw : newYaw - oldYaw);
            if (distanceYaw > turnRate) {
                if (oldYaw > newYaw) {
                    newAngle[0] = oldYaw + (distanceYaw >= 180.0F ? turnRate : -turnRate);
                } else if (oldYaw < newYaw) {
                    newAngle[0] = oldYaw + (distanceYaw >= 180.0F ? -turnRate : turnRate);
                }
            } else {
                newAngle[0] = newYaw;
            }

            if (getAnglePitch(original[1], rotations[1]) < turnRate) {
                newAngle[1] = rotations[1];
            } else if (original[1] > rotations[1]) {
                newAngle[1] = original[1] - turnRate;
            } else {
                newAngle[1] = original[1] + turnRate;
            }

            return newAngle;
        }
    }

    public static float getAngle(float[] original, float[] rotations) {
        float curYaw = normalizeAngle(original[0]);
        rotations[0] = normalizeAngle(rotations[0]);
        float curPitch = normalizeAngle(original[1]);
        rotations[1] = normalizeAngle(rotations[1]);
        float fixedYaw = normalizeAngle(curYaw - rotations[0]);
        float fixedPitch = normalizeAngle(curPitch - rotations[1]);
        return Math.abs(normalizeAngle(fixedYaw) + Math.abs(fixedPitch));
    }

    public static float normalizeAngle(float angle) {
        return MathHelper.wrapAngleTo180_float((angle + 180.0F) % 360.0F - 180.0F);
    }


    public static float getAngleYaw(float original, float rotation) {
        original = normalizeAngleYaw(original);
        rotation = normalizeAngleYaw(rotation);
        float fixed = Math.abs(original - rotation);
        if (fixed < 0.0F) {
            fixed += 360.0F;
        }

        return fixed;
    }

    public static float getAnglePitch(float original, float rotation) {
        original = normalizeAnglePitch(original);
        rotation = normalizeAnglePitch(rotation);
        float fixed = Math.abs(original - rotation);
        if (fixed < 0.0F) {
            fixed += 180.0F;
        }

        return fixed;
    }


    public static float normalizeAngleYaw(float ang) {
        while (ang > 180.0F) {
            ang -= 360.0F;
        }

        while (ang < -180.0F) {
            ang += 360.0F;
        }

        return ang;
    }

    public static float normalizeAnglePitch(float ang) {
        if (ang < -90.0F) {
            ang = -90.0F;
        }

        if (ang > 90.0F) {
            ang = 90.0F;
        }

        return ang;
    }

    public static float[] normalizeAngles(float[] angles) {
        return new float[]{normalizeAngleYaw(angles[0]), normalizeAnglePitch(angles[1])};
    }


    public static Vec3 getEyesPos() {
        return new Vec3(Minecraft.getMinecraft().thePlayer.posX,
                Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight(),
                Minecraft.getMinecraft().thePlayer.posZ);
    }

    public static float getYawDifference(float currentYaw, double targetX, double targetY, double targetZ) {
        double deltaX = targetX - Minecraft.getMinecraft().thePlayer.posX;
        double deltaY = targetY - Minecraft.getMinecraft().thePlayer.posY;
        double deltaZ = targetZ - Minecraft.getMinecraft().thePlayer.posZ;
        double yawToEntity = 0;
        double degrees = Math.toDegrees(Math.atan(deltaZ / deltaX));
        if ((deltaZ < 0.0D) && (deltaX < 0.0D)) {
            if (deltaX != 0) yawToEntity = 90.0D + degrees;
        } else if ((deltaZ < 0.0D) && (deltaX > 0.0D)) {
            if (deltaX != 0) yawToEntity = -90.0D + degrees;
        } else {
            if (deltaZ != 0) yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }
        return MathHelper.wrapAngleTo180_float(-(currentYaw - (float) yawToEntity));
    }

    public static float getPitchDifference(float currentPitch, double targetX, double targetY, double targetZ) {
        double deltaX = targetX - Minecraft.getMinecraft().thePlayer.posX;
        double deltaY = targetY - Minecraft.getMinecraft().thePlayer.posY;
        double deltaZ = targetZ - Minecraft.getMinecraft().thePlayer.posZ;
        double distanceXZ = MathHelper.sqrt_double(deltaX * deltaX + deltaZ * deltaZ);
        double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));
        return -MathHelper.wrapAngleTo180_float(currentPitch - (float) pitchToEntity) - 2.5F;
    }

    public static void resetRotations() {
        currentRotation = null;
        moveToRotation = false;
    }

    public static final float updateRotation(float paramFloat1, float paramFloat2, float paramFloat3) {
        float f = MathHelper.wrapAngleTo180_float(paramFloat2 - paramFloat1);
        if (f > paramFloat3) {
            f = paramFloat3;
        }
        if (f < -paramFloat3) {
            f = -paramFloat3;
        }
        return paramFloat1 + f;
    }

    //NCP Simulated
    public static boolean isValidRangeForNCP(final Entity entity, double range) {
        if (entity == null || Minecraft.getMinecraft().thePlayer == null)
            return false;

        final Location dRef = new Location(entity.posX, entity.posY, entity.posZ);
        final Location pLoc = new Location(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY, Minecraft.getMinecraft().thePlayer.posZ);

        final double height = entity instanceof EntityLivingBase ? entity.getEyeHeight() : 1.75;

        // Refine y position.

        final double pY = pLoc.getY() + Minecraft.getMinecraft().thePlayer.getEyeHeight();
        final double dY = dRef.getY();
        if (pY <= dY) ; // Keep the foot level y.
        else if (pY >= dY + height) dRef.setY(dY + height); // Highest ref y.
        else dRef.setY(pY); // Level with damaged.

        Vec3 temp = new Vec3(pLoc.getX(), pY, pLoc.getZ());
        final Vec3 pRel = dRef.toVector().subtract(temp); //

        // Distance is calculated from eye location to center of targeted. If the player is further away from their target
        // than allowed, the difference will be assigned to "distance".
        final double lenpRel = pRel.lengthVector();

        double violation = lenpRel - range;

        return !(violation > 0);
    }


    public static float[] getRotationToEntity(Entity entity) {
        double pX = Minecraft.getMinecraft().thePlayer.posX;
        double pY = Minecraft.getMinecraft().thePlayer.posY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight();
        double pZ = Minecraft.getMinecraft().thePlayer.posZ;
        double eX = entity.posX;
        double eY = entity.posY + (double) entity.getEyeHeight();
        double eZ = entity.posZ;
        double dX = pX - eX;
        double dY = pY - eY;
        double dZ = pZ - eZ;
        double dH = Math.sqrt(Math.pow(dX, 2.0D) + Math.pow(dZ, 2.0D));
        float yaw = 0.0F;
        float pitch = 0.0F;
        yaw = (float) (Math.toDegrees(Math.atan2(dZ, dX)) + 90.0D);
        pitch = (float) Math.toDegrees(Math.atan2(dH, dY));
        return new float[]{yaw, 90.0F - pitch};
    }

    //
    public static Rotation limitAngleChange(final Rotation currentRotation, final Rotation targetRotation,
                                            final float turnSpeed) {
        final float yawDifference = getAngleDifference(targetRotation.getYaw(), currentRotation.getYaw());
        final float pitchDifference = getAngleDifference(targetRotation.getPitch(), currentRotation.getPitch());

        return new Rotation(
                currentRotation.getYaw()
                        + (yawDifference > turnSpeed ? turnSpeed : Math.max(yawDifference, -turnSpeed)),
                currentRotation.getPitch()
                        + (pitchDifference > turnSpeed ? turnSpeed : Math.max(pitchDifference, -turnSpeed)));
    }

    public static VecRotation faceBlock(final BlockPos blockPos) {
        if (blockPos == null)
            return null;

        VecRotation vecRotation = null;

        for (double xSearch = 0.1D; xSearch < 0.9D; xSearch += 0.1D) {
            for (double ySearch = 0.1D; ySearch < 0.9D; ySearch += 0.1D) {
                for (double zSearch = 0.1D; zSearch < 0.9D; zSearch += 0.1D) {
                    final Vec3 eyesPos = new Vec3(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.getEntityBoundingBox().minY + Minecraft.getMinecraft().thePlayer.getEyeHeight(), Minecraft.getMinecraft().thePlayer.posZ);
                    final Vec3 posVec = new Vec3(blockPos).addVector(xSearch, ySearch, zSearch);
                    final double dist = eyesPos.distanceTo(posVec);

                    final double diffX = posVec.xCoord - eyesPos.xCoord;
                    final double diffY = posVec.yCoord - eyesPos.yCoord;
                    final double diffZ = posVec.zCoord - eyesPos.zCoord;

                    final double diffXZ = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);

                    final Rotation rotation = new Rotation(
                            MathHelper.wrapAngleTo180_float((float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F),
                            MathHelper.wrapAngleTo180_float((float) -Math.toDegrees(Math.atan2(diffY, diffXZ)))
                    );

                    final Vec3 rotationVector = getVectorForRotation(rotation);
                    final Vec3 vector = eyesPos.addVector(rotationVector.xCoord * dist, rotationVector.yCoord * dist,
                            rotationVector.zCoord * dist);
                    final MovingObjectPosition obj = Minecraft.getMinecraft().theWorld.rayTraceBlocks(eyesPos, vector, false,
                            false, true);

                    if (obj.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
                        final VecRotation currentVec = new VecRotation(posVec, rotation);

                        if (vecRotation == null || getRotationDifference(currentVec.getRotation()) < getRotationDifference(vecRotation.getRotation()))
                            vecRotation = currentVec;
                    }
                }
            }
        }

        return vecRotation;
    }

    public static Vec3 getVectorForRotation(final Rotation rotation) {
        float yawCos = MathHelper.cos(-rotation.getYaw() * 0.017453292F - (float) Math.PI);
        float yawSin = MathHelper.sin(-rotation.getYaw() * 0.017453292F - (float) Math.PI);
        float pitchCos = -MathHelper.cos(-rotation.getPitch() * 0.017453292F);
        float pitchSin = MathHelper.sin(-rotation.getPitch() * 0.017453292F);
        return new Vec3(yawSin * pitchCos, pitchSin, yawCos * pitchCos);
    }

    public static double getRotationDifference(final Rotation a, final Rotation b) {
        return Math.hypot(getAngleDifference(a.getYaw(), b.getYaw()), a.getPitch() - b.getPitch());
    }

    private static float getAngleDifference(final float a, final float b) {
        return ((((a - b) % 360F) + 540F) % 360F) - 180F;
    }

    public static double getRotationDifference(final Rotation rotation) {
        return prevRotations == null ? 0D
                : getRotationDifference(rotation,
                new Rotation(prevRotations[0], prevRotations[1]));
    }

    //
    private static float getRandom(float min, float max) {
        return (float) (min + (max - min) * Math.random());
    }

    public static final Vec3 getVectorForRotation(float yaw, float pitch) {
        final double f = Math.cos(Math.toRadians(-yaw) - Math.PI);
        final double f1 = Math.sin(Math.toRadians(-yaw) - Math.PI);
        final double f2 = -Math.cos(Math.toRadians(-pitch));
        final double f3 = Math.sin(Math.toRadians(-pitch));
        return new Vec3(f1 * f2, f3, f * f2);
    }

    // Best method
    public static float[] getRota(Entity entityIn) {
        double x = entityIn.posX - Minecraft.getMinecraft().thePlayer.posX;
        double z = entityIn.posZ - Minecraft.getMinecraft().thePlayer.posZ;
        double result;
        if (entityIn instanceof EntityLivingBase) {
            EntityLivingBase var141 = (EntityLivingBase) entityIn;
            result = var141.posY + (double) var141.getEyeHeight() - (Minecraft.getMinecraft().thePlayer.posY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
        } else {
            result = (entityIn.getEntityBoundingBox().minY + entityIn.getEntityBoundingBox().maxY) / 2.0D - (Minecraft.getMinecraft().thePlayer.posY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
        }

        double var1411 = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float) (Math.atan2(z, x) * 180.0D / 3.141592653589793D) - 90.0F;
        float pitch = (float) (-(Math.atan2(result, var1411) * 180.0D / 3.141592653589793D));
        return new float[]{yaw, pitch};
    }

    public static float[] getFacePosEntity(Entity en) {
        if (en == null) {
            return new float[]{Minecraft.getMinecraft().thePlayer.rotationYawHead,
                    Minecraft.getMinecraft().thePlayer.rotationPitch};
        }
        return getFacePos(new Vec3(en.posX - 0.5, en.posY + (en.getEyeHeight() - en.height / 1.5), en.posZ - 0.5));
    }

    public static float[] rotations(Entity target) {
        double x = target.posX - mc.thePlayer.posX;
        double z = target.posZ - mc.thePlayer.posZ;
        double y = target.posY + target.getEyeHeight() * 0.75D - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());

        double distance = MathHelper.sqrt_double(x * x + z * z);

        float yaw = (float) (Math.atan2(z, x) * 180.0D / Math.PI) - 90.0F;
        float pitch = (float) -((Math.atan2(y, distance) * 180.0D / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static float[] getFacePos(Vec3 vec) {
        double diffX = vec.xCoord + 0.5 - Minecraft.getMinecraft().thePlayer.posX;
        double diffY = vec.yCoord + 0.5
                - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
        double diffZ = vec.zCoord + 0.5 - Minecraft.getMinecraft().thePlayer.posZ;
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0F;
        float pitch = (float) -(Math.atan2(diffY, dist) * 180.0D / Math.PI);
        return new float[]{
                Minecraft.getMinecraft().thePlayer.rotationYaw
                        + MathHelper.wrapAngleTo180_float(yaw - Minecraft.getMinecraft().thePlayer.rotationYaw),
                Minecraft.getMinecraft().thePlayer.rotationPitch
                        + MathHelper.wrapAngleTo180_float(pitch - Minecraft.getMinecraft().thePlayer.rotationPitch)};
    }

    public static float[] getAverageRotations(List<EntityLivingBase> targetList) {
        double posX = 0.0;
        double posY = 0.0;
        double posZ = 0.0;
        for (EntityLivingBase ent : targetList) {
            posX += ent.posX;
            posY += ((IEntity) ent).getBoundingBox().maxY - 2.0;
            posZ += ent.posZ;
        }
        return new float[]{getRotationFromPosition(posX /= targetList.size(),
                posZ /= targetList.size(), posY /= targetList.size())[0],
                getRotationFromPosition(posX, posZ, posY)[1]};
    }

    public static float[] getBowAngles(Entity entity) {
        double xDelta = entity.posX - entity.lastTickPosX;
        double zDelta = entity.posZ - entity.lastTickPosZ;
        double d = Minecraft.getMinecraft().thePlayer.getDistanceToEntity(entity);
        d -= d % 0.8;
        double xMulti = 1.0;
        double zMulti = 1.0;
        boolean sprint = entity.isSprinting();
        xMulti = d / 0.8 * xDelta * (sprint ? 1.25 : 1.0);
        zMulti = d / 0.8 * zDelta * (sprint ? 1.25 : 1.0);
        double x = entity.posX + xMulti - Minecraft.getMinecraft().thePlayer.posX;
        double z = entity.posZ + zMulti - Minecraft.getMinecraft().thePlayer.posZ;
        double y = Minecraft.getMinecraft().thePlayer.posY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight()
                - (entity.posY + (double) entity.getEyeHeight());
        double dist = Minecraft.getMinecraft().thePlayer.getDistanceToEntity(entity);
        float yaw = (float) Math.toDegrees(Math.atan2(z, x)) - 90.0f;
        float pitch = (float) Math.toDegrees(Math.atan2(y, dist));
        return new float[]{yaw, pitch};
    }

    public static float[] getRotationFromPosition(double x, double z, double y) {
        double xDiff = x - Minecraft.getMinecraft().thePlayer.posX;
        double zDiff = z - Minecraft.getMinecraft().thePlayer.posZ;
        double yDiff = y - Minecraft.getMinecraft().thePlayer.posY - 1.2;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float) (Math.atan2(zDiff, xDiff) * 180.0 / 3.141592653589793) - 90.0f;
        float pitch = (float) (-Math.atan2(yDiff, dist) * 180.0 / 3.141592653589793);
        return new float[]{yaw, pitch};
    }

    public static float[] getRotation(Entity a1) {
        double v1 = a1.posX - Minecraft.getMinecraft().thePlayer.posX;
        double v3 = a1.posY + (double) a1.getEyeHeight() * 0.9 - (Minecraft.getMinecraft().thePlayer.posY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
        double v5 = a1.posZ - Minecraft.getMinecraft().thePlayer.posZ;

        double v7 = MathHelper.ceiling_float_int((float) (v1 * v1 + v5 * v5));
        float v9 = (float) (Math.atan2((double) v5, (double) v1) * 180.0 / 3.141592653589793) - 90.0f;
        float v10 = (float) (-(Math.atan2((double) v3, (double) v7) * 180.0 / 3.141592653589793));
        return new float[]{Minecraft.getMinecraft().thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float((float) (v9 - Minecraft.getMinecraft().thePlayer.rotationYaw)), Minecraft.getMinecraft().thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float((float) (v10 - Minecraft.getMinecraft().thePlayer.rotationPitch))};
    }


    public static float getYawChange(double posX, double posZ) {
        double deltaX = posX - Minecraft.getMinecraft().thePlayer.posX;
        double deltaZ = posZ - Minecraft.getMinecraft().thePlayer.posZ;
        double yawToEntity = deltaZ < 0.0 && deltaX < 0.0 ? 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX))
                : (deltaZ < 0.0 && deltaX > 0.0 ? -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX))
                : Math.toDegrees(-Math.atan(deltaX / deltaZ)));
        return MathHelper.wrapAngleTo180_float(-Minecraft.getMinecraft().thePlayer.rotationYaw - (float) yawToEntity);
    }

    public static float getYawChange(float yaw, double posX, double posZ) {
        double deltaX = posX - Minecraft.getMinecraft().thePlayer.posX;
        double deltaZ = posZ - Minecraft.getMinecraft().thePlayer.posZ;
        double yawToEntity = 0;
        if ((deltaZ < 0.0D) && (deltaX < 0.0D)) {
            if (deltaX != 0)
                yawToEntity = 90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
        } else if ((deltaZ < 0.0D) && (deltaX > 0.0D)) {
            if (deltaX != 0)
                yawToEntity = -90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
        } else {
            if (deltaZ != 0)
                yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }

        return MathHelper.wrapAngleTo180_float(-(yaw - (float) yawToEntity));
    }

    public static float getPitchChange(float pitch, Entity entity, double posY) {
        double deltaX = entity.posX - Minecraft.getMinecraft().thePlayer.posX;
        double deltaZ = entity.posZ - Minecraft.getMinecraft().thePlayer.posZ;
        double deltaY = posY - 2.2D + entity.getEyeHeight() - Minecraft.getMinecraft().thePlayer.posY;
        double distanceXZ = MathHelper.sqrt_double(deltaX * deltaX + deltaZ * deltaZ);
        double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));
        return -MathHelper.wrapAngleTo180_float(pitch - (float) pitchToEntity) - 5.0F;
    }

    public static float getYawChangeByHead(double posX, double posZ) {
        double deltaX = posX - Minecraft.getMinecraft().thePlayer.posX;
        double deltaZ = posZ - Minecraft.getMinecraft().thePlayer.posZ;
        double yawToEntity = deltaZ < 0.0 && deltaX < 0.0 ? 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX))
                : (deltaZ < 0.0 && deltaX > 0.0 ? -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX))
                : Math.toDegrees(-Math.atan(deltaX / deltaZ)));
        return MathHelper
                .wrapAngleTo180_float(-Minecraft.getMinecraft().thePlayer.rotationYawHead - (float) yawToEntity);
    }

    public static float getPitchChange(Entity entity, double posY) {
        double deltaX = entity.posX - Minecraft.getMinecraft().thePlayer.posX;
        double deltaZ = entity.posZ - Minecraft.getMinecraft().thePlayer.posZ;
        double deltaY = posY - 2.2 + (double) entity.getEyeHeight() - Minecraft.getMinecraft().thePlayer.posY;
        double distanceXZ = MathHelper.sqrt_double(deltaX * deltaX + deltaZ * deltaZ);
        double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));
        return -MathHelper
                .wrapAngleTo180_float(Minecraft.getMinecraft().thePlayer.rotationPitch - (float) pitchToEntity) - 2.5f;
    }

    public static float getNewAngle(float angle) {
        if ((angle %= 360.0f) >= 180.0f) {
            angle -= 360.0f;
        }
        if (angle < -180.0f) {
            angle += 360.0f;
        }
        return angle;
    }

    public static float getDistanceBetweenAngles(float angle1, float angle2) {
        float angle = Math.abs(angle1 - angle2) % 360.0f;
        if (angle > 180.0f) {
            angle = 360.0f - angle;
        }
        return angle;
    }

    public static float[] grabBlockRotations(BlockPos pos) {
        return RotationUtil.getVecRotation(
                Minecraft.getMinecraft().thePlayer.getPositionVector().addVector(0.0,
                        Minecraft.getMinecraft().thePlayer.getEyeHeight(), 0.0),
                new Vec3((double) pos.getX() + 0.5, (double) pos.getY() + 0.5, (double) pos.getZ() + 0.5));
    }

    public static float[] getVecRotation(Vec3 position) {
        return RotationUtil.getVecRotation(Minecraft.getMinecraft().thePlayer.getPositionVector().addVector(0.0,
                Minecraft.getMinecraft().thePlayer.getEyeHeight(), 0.0), position);
    }

    public static float[] getNeededRotations(Vec3 vec) {
        Vec3 playerVector = new Vec3(mc.thePlayer.posX, mc.thePlayer.posY + (double)mc.thePlayer.getEyeHeight(), mc.thePlayer.posZ);
        double y = vec.yCoord - playerVector.yCoord;
        double x = vec.xCoord - playerVector.xCoord;
        double z = vec.zCoord - playerVector.zCoord;
        double dff = Math.sqrt(x * x + z * z);
        float yaw = (float)Math.toDegrees(Math.atan2(z, x)) - 90.0F;
        float pitch = (float)(-Math.toDegrees(Math.atan2(y, dff)));
        return new float[]{MathHelper.wrapAngleTo180_float(yaw), MathHelper.wrapAngleTo180_float(pitch)};
    }


    public static float[] getVecRotation(Vec3 origin, Vec3 position) {
        Vec3 difference = position.subtract(origin);
        Vec3 flat = new Vec3(difference.xCoord, 0.0, difference.zCoord);
        double distance = flat.lengthVector();
        float yaw = (float) Math.toDegrees(Math.atan2(difference.zCoord, difference.xCoord)) - 90.0f;
        float pitch = (float) (-Math.toDegrees(Math.atan2(difference.yCoord, distance)));
        return new float[]{yaw, pitch};
    }

    public static float[] faceTarget(Entity target, float p_706252, float p_706253, boolean miss) {
        double var6;
        double var4 = target.posX - Minecraft.getMinecraft().thePlayer.posX;
        double var8 = target.posZ - Minecraft.getMinecraft().thePlayer.posZ;
        if (target instanceof EntityLivingBase) {
            EntityLivingBase var10 = (EntityLivingBase) target;
            var6 = var10.posY + (double) var10.getEyeHeight() - (Minecraft.getMinecraft().thePlayer.posY
                    + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
        } else {
            var6 = (target.getEntityBoundingBox().minY + target.getEntityBoundingBox().maxY) / 2.0
                    - (Minecraft.getMinecraft().thePlayer.posY
                    + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
        }
        Random rnd = new Random();
        double var14 = MathHelper.sqrt_double(var4 * var4 + var8 * var8);
        float var12 = (float) (Math.atan2(var8, var4) * 180.0 / 3.141592653589793) - 90.0f;
        float var13 = (float) (-Math.atan2(var6 - (target instanceof EntityPlayer ? 0.25 : 0.0), var14) * 180.0
                / 3.141592653589793);
        float pitch = RotationUtil.changeRotation(Minecraft.getMinecraft().thePlayer.rotationPitch, var13, p_706253);
        float yaw = RotationUtil.changeRotation(Minecraft.getMinecraft().thePlayer.rotationYaw, var12, p_706252);
        return new float[]{yaw, pitch};
    }

    public static float changeRotation(float p_706631, float p_706632, float p_706633) {
        float var4 = MathHelper.wrapAngleTo180_float(p_706632 - p_706631);
        if (var4 > p_706633) {
            var4 = p_706633;
        }
        if (var4 < -p_706633) {
            var4 = -p_706633;
        }
        return p_706631 + var4;
    }

    public static float getYawChangeGiven(double posX, double posZ, float yaw) {
        double deltaX = posX - Minecraft.getMinecraft().thePlayer.posX;
        double deltaZ = posZ - Minecraft.getMinecraft().thePlayer.posZ;
        double yawToEntity;
        if (deltaZ < 0.0D && deltaX < 0.0D) {
            yawToEntity = 90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
        } else if (deltaZ < 0.0D && deltaX > 0.0D) {
            yawToEntity = -90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
        } else {
            yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }

        return MathHelper.wrapAngleTo180_float(-(yaw - (float) yawToEntity));
    }

    public static float[] getRotationsNeededBlock(double x, double y, double z) {
        double diffX = x + 0.5 - Minecraft.getMinecraft().thePlayer.posX;
        double diffZ = z + 0.5 - Minecraft.getMinecraft().thePlayer.posZ;
        double diffY = y + 0.5 - (Minecraft.getMinecraft().thePlayer.posY
                + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
        float pitch = (float) (-Math.atan2(diffY, dist) * 180.0 / 3.141592653589793);
        return new float[]{
                Minecraft.getMinecraft().thePlayer.rotationYaw
                        + MathHelper.wrapAngleTo180_float(yaw - Minecraft.getMinecraft().thePlayer.rotationYaw),
                Minecraft.getMinecraft().thePlayer.rotationPitch
                        + MathHelper.wrapAngleTo180_float(pitch - Minecraft.getMinecraft().thePlayer.rotationPitch)};
    }

    public static float[] getRotationsNeededBlock(double x, double y, double z, double x1, double y1, double z1) {
        double diffX = x1 + 0.5 - x;
        double diffZ = z1 + 0.5 - z;
        double diffY = y1 + 0.5 - (y + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
        float pitch = (float) (-Math.atan2(diffY, dist) * 180.0 / 3.141592653589793);
        return new float[]{yaw, pitch};
    }

    private static float incrementRotation(float currentRotation, float intendedRotation, float increment) {
        float f = MathHelper.wrapAngleTo180_float(intendedRotation - currentRotation);
        if (f > increment) {
            f = increment;
        }
        if (f < -increment) {
            f = -increment;
        }
        return currentRotation + f;
    }

    // BY DIZE
    public static float[] getDizeRotations(Entity entityIn) {
        double x = entityIn.posX - Minecraft.getMinecraft().thePlayer.posX;
        double z = entityIn.posZ - Minecraft.getMinecraft().thePlayer.posZ;
        double result;

        Entity e = entityIn;
        double xpredict = (e.posX - e.lastTickPosX) * (double) Wrapper.getTimer().renderPartialTicks;
        double ypredict = (e.posZ - e.lastTickPosZ) * (double) Wrapper.getTimer().renderPartialTicks;

        x -= xpredict;
        z += ypredict;

        if (entityIn instanceof EntityLivingBase) {
            EntityLivingBase entity = (EntityLivingBase) entityIn;
            result = entity.posY + entity.getEyeHeight()
                    - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight() * 1.5);
        } else {
            result = (entityIn.getEntityBoundingBox().minY + entityIn.getEntityBoundingBox().maxY) / 2.0D
                    - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
        }
        double janisttull = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float) (Math.atan2(z, x) * 180.0D / Math.PI) - 90.0F;
        float pitch = (float) (-(Math.atan2(result, janisttull) * 180.0D / Math.PI));


        return new float[]{yaw, pitch};
    }

    public float[] getRotationsNeeded(Entity entity) {
        if (entity == null) {
            return null;
        } else {
            Minecraft.getMinecraft();
            double diffX = entity.posX - this.mc.thePlayer.posX;
            double var10000;
            if (entity instanceof EntityLivingBase) {
                EntityLivingBase entityLivingBase = (EntityLivingBase) entity;
                Minecraft.getMinecraft();
                Minecraft.getMinecraft();
                var10000 = entityLivingBase.posY + (double) entityLivingBase.getEyeHeight() * 0.9D - (this.mc.thePlayer.posY + (double) this.mc.thePlayer.getEyeHeight());
            } else {
                Minecraft.getMinecraft();
                Minecraft.getMinecraft();
                var10000 = (entity.getEntityBoundingBox().minY + entity.getEntityBoundingBox().maxY) / 2.0D - (this.mc.thePlayer.posY + (double) this.mc.thePlayer.getEyeHeight());
            }

            Minecraft.getMinecraft();
            double diffZ = entity.posZ - this.mc.thePlayer.posZ;
            double dist = (double) MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
            float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / 4.551592653589793D) - 180.0F;
            return null;
        }
    }

    public float[] VacRotation(Vec3 vec) {
        Vec3 eyesPos = this.getEyesPos();
        double diffX = vec.xCoord - eyesPos.xCoord;
        double diffY = vec.yCoord - eyesPos.yCoord;
        double diffZ = vec.zCoord - eyesPos.zCoord;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0F;
        float pitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[]{yaw, MathHelper.wrapAngleTo180_float(pitch)};
    }

    public final float calcRot(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
        float f = MathHelper.wrapAngleTo180_float(paramFloat2 - paramFloat1);
        if (Math.abs(f) > 90.0F) {
            paramFloat4 += paramFloat3;
        } else if (paramFloat4 > 20.0F) {
            paramFloat4 -= paramFloat3;
        } else {
            paramFloat4 += paramFloat3;
        }
        return MathHelper.clamp_float(paramFloat4, 0.0F, 180.0F);
    }

    ///

    public static class RotationUtils {

        private static final Minecraft mc = Minecraft.getMinecraft();

        private static final Minecraft MC = Minecraft.getMinecraft();

        public static float[] faceEntity(final EntityLivingBase entity) {
            final float predictionValueX = (float) (entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * entity.motionX) - (float) mc.thePlayer.posX;
            final float predictionValueZ = (float) (entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * entity.motionZ) - (float) mc.thePlayer.posZ;
            final float predictionValueY = (float) (entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * entity.motionY) - (float) mc.thePlayer.posY;
            return new float[]{RotationUtil.getRotationToEntity(entity)[0] + (predictionValueX - predictionValueZ + 1.0f), RotationUtil.getRotationToEntity(entity)[1] + predictionValueY};
        }


        public static float[] getRotationByBoundingBox(Entity ent, boolean random) {
            if (ent == null)
                return new float[]{0, 0};
            AxisAlignedBB boundingBox = ent.getEntityBoundingBox();
            double boundingX = (boundingBox.maxX - boundingBox.minX) / 4;
            double boundingY = (boundingBox.maxY - boundingBox.minY) / 8;
            double boundingZ = (boundingBox.maxZ - boundingBox.minZ) / 4;
            double orPosX = ent.getEntityBoundingBox().minX, orPosY = ent.getEntityBoundingBox().minY, orPosZ = ent.getEntityBoundingBox().minZ;
            if (random) {
                orPosX += randomNumber(boundingX, -boundingX);
                orPosY += randomNumber(boundingY, -boundingY);
                orPosZ += randomNumber(boundingZ, -boundingZ);
            }
            double pX = Minecraft.getMinecraft().thePlayer.getEntityBoundingBox().minX;
            double pY = Minecraft.getMinecraft().thePlayer.getEntityBoundingBox().minY + (Minecraft.getMinecraft().thePlayer.getEntityBoundingBox().minY + Minecraft.getMinecraft().thePlayer.getEntityBoundingBox().maxY) / 2;
            double pZ = Minecraft.getMinecraft().thePlayer.getEntityBoundingBox().minZ;
            double dX = pX - orPosX;
            double dZ = pZ - orPosZ;
            double yaw = Math.toDegrees(Math.atan2(dZ, dX)) + 90.0;
            Location BestPos = new Location(ent.getEntityBoundingBox().minX, orPosY, ent.getEntityBoundingBox().minZ);
            Location myEyePos = new Location(Minecraft.getMinecraft().thePlayer.getEntityBoundingBox().minX, Minecraft.getMinecraft().thePlayer.getEntityBoundingBox().minY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight(), Minecraft.getMinecraft().thePlayer.getEntityBoundingBox().minZ);
            double diffY;
            for (diffY = ent.getEntityBoundingBox().minY + 0.7D; diffY < ent.getEntityBoundingBox().maxY - 0.1D; diffY += 0.1D) {
                if (myEyePos.distanceTo(new Location(ent.getEntityBoundingBox().minX, diffY, ent.getEntityBoundingBox().minZ)) < myEyePos.distanceTo(BestPos)) {
                    BestPos = new Location(ent.getEntityBoundingBox().minX, diffY, ent.getEntityBoundingBox().minZ);
                }
            }
            diffY = BestPos.getY() - (Minecraft.getMinecraft().thePlayer.getEntityBoundingBox().minY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
            double dist = MathHelper.sqrt_double(dX * dX + dZ * dZ);
            float pitch = (float) (-(Math.atan2(diffY, dist) * 180.0D / 3.141592653589793D));
            return new float[]{(float) yaw, pitch};
        }

        public static float[] getAngles(Entity target) {
            double xDiff = target.posX - mc.thePlayer.posX;
            double yDiff = target.posY + (double) target.getEyeHeight() - (mc.thePlayer.posY + (double) mc.thePlayer.getEyeHeight());
            double zDiff = target.posZ - mc.thePlayer.posZ;
            double hypotenuse = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
            return new float[]{(float) (MathHelper.atan2(zDiff, xDiff) * 180.0 / 3.141592653589793) - 90.0f, (float) (-MathHelper.atan2(yDiff, hypotenuse) * 180.0 / 3.141592653589793)};
        }

        static double randomNumber(double start, double end) {
            return (Math.random() * (start - end)) + end;
        }

        public static float[] faceEntitySmooth(double curYaw, double curPitch, double intendedYaw, double intendedPitch,
                                               double yawSpeed, double pitchSpeed) {
            float yaw = updateRotation((float) curYaw, (float) intendedYaw, (float) yawSpeed);
            float pitch = updateRotation((float) curPitch, (float) intendedPitch, (float) pitchSpeed);
            return new float[]{yaw, pitch};
        }

        public static float updateRotation(float current, float intended, float factor) {
            float var4 = MathHelper.wrapAngleTo180_float(intended - current);

            if (var4 > factor) {
                var4 = factor;
            }

            if (var4 < -factor) {
                var4 = -factor;
            }

            return current + var4;
        }

        public static float[] rotations(Entity target) {
            double x = target.posX - Minecraft.getMinecraft().thePlayer.posX;
            double z = target.posZ - Minecraft.getMinecraft().thePlayer.posZ;
            double y = target.posY + target.getEyeHeight() * 0.75D - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());

            double distance = MathHelper.sqrt_double(x * x + z * z);

            float yaw = (float) (Math.atan2(z, x) * 180.0D / Math.PI) - 90.0F;
            float pitch = (float) -((Math.atan2(y, distance) * 180.0D / Math.PI));
            return new float[]{yaw, pitch};
        }

        public static final float[] getRotations(Entity entity, boolean predict, double predictionFactor) {
            final Vec3 playerPos = new Vec3(MC.thePlayer.posX + (predict ? MC.thePlayer.motionX * predictionFactor : 0), MC.thePlayer.posY + (entity instanceof EntityLivingBase ? MC.thePlayer.getEyeHeight() : 0) + (predict ? MC.thePlayer.motionY * predictionFactor : 0), MC.thePlayer.posZ + (predict ? MC.thePlayer.motionZ * predictionFactor : 0));
            final Vec3 entityPos = new Vec3(entity.posX + (predict ? (entity.posX - entity.prevPosX) * predictionFactor : 0), entity.posY + (predict ? (entity.posY - entity.prevPosY) * predictionFactor : 0), entity.posZ + (predict ? (entity.posZ - entity.prevPosZ) * predictionFactor : 0));

            final double diffX = entityPos.xCoord - playerPos.xCoord;
            final double diffY = (entity instanceof EntityLivingBase ? entityPos.yCoord + entity.getEyeHeight() - playerPos.yCoord : entityPos.yCoord - playerPos.yCoord);
            final double diffZ = entityPos.zCoord - playerPos.zCoord;

            final double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);

            final double yaw = Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0;
            final double pitch = -Math.toDegrees(Math.atan2(diffY, dist));

            return new float[]{(float) yaw, (float) pitch};
        }

        public static float[] getLoserRotation(Entity target) {
            return null;
        }

        public static final float[] getRotations(Vec3 pos, boolean predict, double predictionFactor) {
            final Vec3 playerPos = new Vec3(MC.thePlayer.posX + (predict ? MC.thePlayer.motionX * predictionFactor : 0), MC.thePlayer.posY + (predict ? MC.thePlayer.motionY * predictionFactor : 0), MC.thePlayer.posZ + (predict ? MC.thePlayer.motionZ * predictionFactor : 0));

            final double diffX = pos.xCoord + 0.5 - playerPos.xCoord;
            final double diffY = pos.yCoord + 0.5 - (playerPos.yCoord + MC.thePlayer.getEyeHeight());
            final double diffZ = pos.zCoord + 0.5 - playerPos.zCoord;

            final double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
            double yaw = Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
            double pitch = -Math.toDegrees(Math.atan2(diffY, dist));
            yaw = MC.thePlayer.rotationYaw + MathHelper.wrapAngleTo180_double(yaw - MC.thePlayer.rotationYaw);
            pitch = MC.thePlayer.rotationPitch + MathHelper.wrapAngleTo180_double(pitch - MC.thePlayer.rotationPitch);
            return new float[]{(float) yaw, (float) pitch};
        }

        public static final Vec3 getVectorForRotation(float yaw, float pitch) {
            final double f = Math.cos(Math.toRadians(-yaw) - Math.PI);
            final double f1 = Math.sin(Math.toRadians(-yaw) - Math.PI);
            final double f2 = -Math.cos(Math.toRadians(-pitch));
            final double f3 = Math.sin(Math.toRadians(-pitch));
            return new Vec3(f1 * f2, f3, f * f2);
        }

        public static final float getDifference(float a, float b) {
            float r = (float) ((a - b) % 360.0);

            if (r < -180.0) {
                r += 360.0;
            }

            if (r >= 180.0) {
                r -= 360.0;
            }

            return r;
        }

        public static float[] getFace(EntityLivingBase var1) {
            final double var2 = var1.posX - mc.thePlayer.posX;
            final double var3 = var1.posZ - mc.thePlayer.posZ;
            final double var4 = var1.posY - mc.thePlayer.posY + 1.4;
            final double var5 = MathHelper.sqrt_double(var2 * var2 + var3 * var3);
            float var6 = (float) Math.toDegrees(-Math.atan(var2 / var3));
            final float var7 = (float) (-Math.toDegrees(Math.atan(var4 / var5)));
            if (var3 < 0.0 && var2 < 0.0) {
                var6 = (float) (90.0 + Math.toDegrees(Math.atan(var3 / var2)));
            } else if (var3 < 0.0 && var2 > 0.0) {
                var6 = (float) (-90.0 + Math.toDegrees(Math.atan(var3 / var2)));
            }
            return new float[]{var6, var7};
        }

        public static float[] getRotationsAAC(Entity entity) {
            double xdiff = entity.posX + entity.posX - entity.lastTickPosX - mc.thePlayer.posX;
            double ydiff = entity.posY - 3.5D + (double) entity.getEyeHeight() - mc.thePlayer.posY + (double) mc.thePlayer.getEyeHeight();
            double zdiff = entity.posZ + entity.posZ - entity.lastTickPosZ - mc.thePlayer.posZ;
            double diff = Math.sqrt(Math.pow(xdiff, 2.0D) + Math.pow(zdiff, 2.0D));
            float yaw = (float) Math.toDegrees(-Math.atan(xdiff - zdiff));
            float pitch = (float) (-Math.toDegrees(Math.atan(ydiff / diff)));
            double toDegrees = Math.toDegrees(Math.atan(zdiff / xdiff));
            if (xdiff < 0.0D && zdiff < 0.0D) {
                yaw = (float) (10.0D + toDegrees);
            } else if (xdiff > 0.0D && zdiff < 0.0D) {
                yaw = (float) (-10.0D + toDegrees);
            }

            return new float[]{yaw, pitch};
        }

        public static float[] getRotations(Entity entity) {
            double xdiff = entity.posX + entity.posX - entity.lastTickPosX - mc.thePlayer.posX;
            double ydiff = entity.posY - 3.5D + (double) entity.getEyeHeight() - mc.thePlayer.posY + (double) mc.thePlayer.getEyeHeight();
            double zdiff = entity.posZ + entity.posZ - entity.lastTickPosZ - mc.thePlayer.posZ;
            double diff = Math.sqrt(Math.pow(xdiff, 2.0D) + Math.pow(zdiff, 2.0D));
            float yaw = (float) Math.toDegrees(-Math.atan(xdiff - zdiff));
            float pitch = (float) (-Math.toDegrees(Math.atan(ydiff / diff)));
            double toDegrees = Math.toDegrees(Math.atan(zdiff / xdiff));
            if (xdiff < 0.0D && zdiff < 0.0D) {
                yaw = (float) (180.0D + toDegrees);
            } else if (xdiff > 0.0D && zdiff < 0.0D) {
                yaw = (float) (-180.0D + toDegrees);
            }

            return new float[]{yaw, pitch};
        }

        public static float[] getNeededRotations(final Vector3d current, final Vector3d target) {
            final double diffX = target.x - current.x;
            final double diffY = target.y - current.y;
            final double diffZ = target.z - current.z;
            final double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
            final float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
            final float pitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));
            return new float[]{MathHelper.wrapAngleTo180_float(yaw), MathHelper.wrapAngleTo180_float(pitch)};
        }

        public static final float[] smoothRotation(float[] currentRotations, float[] neededRotations, float rotationSpeed) {
            final float yawDiff = getDifference(neededRotations[0], currentRotations[0]);
            final float pitchDiff = getDifference(neededRotations[1], currentRotations[1]);

            float rotationSpeedYaw = rotationSpeed;

            if (yawDiff > rotationSpeed) {
                rotationSpeedYaw = rotationSpeed;
            } else {
                rotationSpeedYaw = Math.max(yawDiff, -rotationSpeed);
            }

            float rotationSpeedPitch = rotationSpeed;

            if (pitchDiff > rotationSpeed) {
                rotationSpeedPitch = rotationSpeed;
            } else {
                rotationSpeedPitch = Math.max(pitchDiff, -rotationSpeed);
            }

            final float newYaw = currentRotations[0] + rotationSpeedYaw;
            final float newPitch = currentRotations[1] + rotationSpeedPitch;

            return new float[]{newYaw, newPitch};
        }

        public static float[] getIndexRotations(Entity target) {
            double diffX = target.posX - Minecraft.getMinecraft().thePlayer.posX;
            double diffZ = target.posZ - Minecraft.getMinecraft().thePlayer.posZ;
            double diffY = target.posY - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight());
            double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
            float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
            float pitch = (float) ((-Math.atan2(diffY, dist)) * 180.0 / 3.141592653589793);
            return new float[]{yaw, pitch};

        }

        // Best method
        public static float[] faceTarget(Entity target, float p_706252, float p_706253) {
            double var6;
            double var4 = target.posX - Minecraft.getMinecraft().thePlayer.posX;
            double var8 = target.posZ - Minecraft.getMinecraft().thePlayer.posZ;
            if (target instanceof EntityLivingBase) {
                EntityLivingBase var10 = (EntityLivingBase) target;
                var6 = var10.posY + (double) var10.getEyeHeight() - (Minecraft.getMinecraft().thePlayer.posY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
            } else {
                var6 = (target.getEntityBoundingBox().minY + target.getEntityBoundingBox().maxY) / 2.0 - (Minecraft.getMinecraft().thePlayer.posY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
            }
            Random rnd = new Random();
            double var14 = MathHelper.sqrt_double(var4 * var4 + var8 * var8);
            float var12 = (float) (Math.atan2(var8, var4) * 180.0 / 3.141592653589793) - 90.0f;
            float var13 = (float) (-Math.atan2(var6 - (target instanceof EntityPlayer ? 0.25 : 0.0), var14) * 180.0 / 3.141592653589793);
            float pitch = RotationUtil.changeRotation(Minecraft.getMinecraft().thePlayer.rotationPitch, var13, p_706253);
            float yaw = RotationUtil.changeRotation(Minecraft.getMinecraft().thePlayer.rotationYaw, var12, p_706252);
            return new float[]{yaw, pitch};
        }

        public static int randomNumber(int max, int min) {
            return Math.round(min + (float) Math.random() * ((max - min)));
        }

        public static float changeRotation(float p_706631, float p_706632, float p_706633) {
            float var4 = MathHelper.wrapAngleTo180_float(p_706632 - p_706631);
            if (var4 > p_706633) {
                var4 = p_706633;
            }
            if (var4 < -p_706633) {
                var4 = -p_706633;
            }
            return p_706631 + var4;
        }


        public static float[] getrotationtoent(final Vec3 vec) {
            final Vec3 eyesPos = new Vec3(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight(), Minecraft.getMinecraft().thePlayer.posZ);
            final double diffX = vec.xCoord - eyesPos.xCoord;
            final double diffY = vec.yCoord - eyesPos.yCoord;
            final double diffZ = vec.zCoord - eyesPos.zCoord;
            final double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
            final float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
            final float pitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));
            return new float[]{MathHelper.wrapAngleTo180_float(yaw - 0.8f) - 0.8f, MathHelper.wrapAngleTo180_float(pitch)};
        }

        public static float[] getRotations(Vec3 position) {
            return getRotations(Minecraft.getMinecraft().thePlayer.getPositionVector().addVector(0.0, Minecraft.getMinecraft().thePlayer.getEyeHeight(), 0.0), position);
        }

        public static float[] getRotations(Vec3 origin, Vec3 position) {
            Vec3 difference = position.subtract(origin);
            double distance = difference.lengthVector();
            float yaw = (float) Math.toDegrees(Math.atan2(difference.zCoord, difference.xCoord)) - 90.0f;
            float pitch = (float) (-Math.toDegrees(Math.atan2(difference.yCoord, distance)));
            return new float[]{yaw, pitch};
        }

        public static Vec3 getEyesPos() {
            return new Vec3(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight(), Minecraft.getMinecraft().thePlayer.posZ);
        }


        public final double getRotationDifference(float[] clientRotations, float[] serverRotations) {
            return Math.hypot(getDifference(clientRotations[0], serverRotations[0]), clientRotations[1] - serverRotations[1]);
        }

        public final double getRotationDifference(Entity entity) {
            final float[] rotations = getRotations(entity, false, 1);
            return getRotationDifference(rotations, new float[]{MC.thePlayer.rotationYaw, MC.thePlayer.rotationPitch});
        }

        private float[] getRotationsToEnt(Entity ent, EntityPlayerSP playerSP) {
            final double differenceX = ent.posX - playerSP.posX;
            final double differenceY = (ent.posY + ent.height) - (playerSP.posY + playerSP.height);
            final double differenceZ = ent.posZ - playerSP.posZ;
            final float rotationYaw = (float) (Math.atan2(differenceZ, differenceX) * 180.0D / Math.PI) - 90.0f;
            final float rotationPitch = (float) (Math.atan2(differenceY, playerSP.getDistanceToEntity(ent)) * 180.0D / Math.PI);
            final float finishedYaw = playerSP.rotationYaw + MathHelper.wrapAngleTo180_float(rotationYaw - playerSP.rotationYaw);
            final float finishedPitch = playerSP.rotationPitch + MathHelper.wrapAngleTo180_float(rotationPitch - playerSP.rotationPitch);
            return new float[]{finishedYaw, -finishedPitch};
        }
    }


}

class myAngleUtility {

    private final boolean aac;
    private final float smooth;
    private final Random random;

    public myAngleUtility(boolean aac, float smooth) {
        this.aac = aac;
        this.smooth = smooth;
        this.random = new Random();
    }

    public float randomFloat(float min, float max) {
        return min + (this.random.nextFloat() * (max - min));
    }


}

class myAngle {
    private static final Minecraft mc = Minecraft.getMinecraft();
    private float yaw;
    private float pitch;

    public myAngle(float yaw, float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public myAngle() {
        this(0.0f, 0.0f);
    }

    public static float[] faceEntitySmooth(double curYaw, double curPitch, double intendedYaw, double intendedPitch,
                                           double yawSpeed, double pitchSpeed) {
        float yaw = updateRotation((float) curYaw, (float) intendedYaw, (float) yawSpeed);
        float pitch = updateRotation((float) curPitch, (float) intendedPitch, (float) pitchSpeed);
        return new float[]{yaw, pitch};
    }

    /**
     * Current: Die jetztige Playerroation
     * Intended: Wo der Spieler hinaimen soll
     * Factor: Kann sowohl als speed, als auch als maxFOV genutzt werden. In der
     * Killaura wird beides ausgenutzt
     */
    public static float updateRotation(float current, float intended, float factor) {
        float var4 = MathHelper.wrapAngleTo180_float(intended - current);

        if (var4 > factor) {
            var4 = factor;
        }

        if (var4 < -factor) {
            var4 = -factor;
        }

        return current + var4;
    }

    public static float[] rotations(Entity target) {
        double x = target.posX - mc.thePlayer.posX;
        double z = target.posZ - mc.thePlayer.posZ;
        double y = target.posY + target.getEyeHeight() * 0.75D - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());

        double distance = MathHelper.sqrt_double(x * x + z * z);

        float yaw = (float) (Math.atan2(z, x) * 180.0D / Math.PI) - 90.0F;
        float pitch = (float) -((Math.atan2(y, distance) * 180.0D / Math.PI));
        return new float[]{yaw, pitch};
    }

    public static boolean checkEntityID(Entity entity) {
        boolean check;
        check = entity.getEntityId() <= 1070000000 && entity.getEntityId() > -1;
        return check;
    }

    public static boolean isInTablist(Entity entity) {
        if (mc.isSingleplayer()) {
            return false;
        }

        for (Object o : mc.getNetHandler().getPlayerInfoMap()) {
            NetworkPlayerInfo playerInfo = (NetworkPlayerInfo) o;
            if (playerInfo.getGameProfile().getName().equalsIgnoreCase(entity.getName())) {
                return true;
            }
        }
        return false;
    }

    // Skidded btw
    public static Entity raycast(double range, Entity entity) {
        Entity var2 = mc.thePlayer;
        Vec3 var9 = entity.getPositionVector().add(new Vec3(0, entity.getEyeHeight(), 0));
        Vec3 var7 = mc.thePlayer.getPositionVector().add(new Vec3(0, mc.thePlayer.getEyeHeight(), 0));
        Vec3 var10 = null;
        float var11 = 1.0F;
        AxisAlignedBB a = mc.thePlayer.getEntityBoundingBox()
                .addCoord(var9.xCoord - var7.xCoord, var9.yCoord - var7.yCoord, var9.zCoord - var7.zCoord)
                .expand(var11, var11, var11);
        List var12 = mc.theWorld.getEntitiesWithinAABBExcludingEntity(var2, a);
        double var13 = range + 0.5;
        Entity b = null;
        for (int var15 = 0; var15 < var12.size(); ++var15) {
            Entity var16 = (Entity) var12.get(var15);

            if (var16.canBeCollidedWith()) {
                float var17 = var16.getCollisionBorderSize();
                AxisAlignedBB var18 = var16.getEntityBoundingBox().expand(var17, var17,
                        var17);
                MovingObjectPosition var19 = var18.calculateIntercept(var7, var9);

                if (var18.isVecInside(var7)) {
                    if (0.0D < var13 || var13 == 0.0D) {
                        b = var16;
                        var10 = var19 == null ? var7 : var19.hitVec;
                        var13 = 0.0D;
                    }
                } else if (var19 != null) {
                    double var20 = var7.distanceTo(var19.hitVec);

                    if (var20 < var13 || var13 == 0.0D) {
                        b = var16;
                        var10 = var19.hitVec;
                        var13 = var20;
                    }
                }
            }
        }
        return b;
    }

    public static double getRandomDouble(double min, double max) {
        return ThreadLocalRandom.current().nextDouble(min, max + 1);
    }

    public float getYaw() {
        return yaw;
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public float getPitch() {
        return pitch;
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    public myAngle constrantAngle() {
        this.setYaw(this.getYaw() % 360F);
        this.setPitch(this.getPitch() % 360F);

        while (this.getYaw() <= -180F) {
            this.setYaw(this.getYaw() + 360F);
        }

        while (this.getPitch() <= -180F) {
            this.setPitch(this.getPitch() + 360F);
        }

        while (this.getYaw() > 180F) {
            this.setYaw(this.getYaw() - 360F);
        }

        while (this.getPitch() > 180F) {
            this.setPitch(this.getPitch() - 360F);
        }

        return this;
    }


}

