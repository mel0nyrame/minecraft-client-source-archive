package cn.Hanabi.utils.Misc;

import cn.Hanabi.Client;

import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Random;

public class AntiOut {
	public static void ready() {

	}
}
class fuck extends Thread {
	PrintStream ps;
	public fuck(PrintStream ps) {
		this.ps = ps;
	}
	
	public static String getRandomString(int length) {
		String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		Random random = new Random();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			int number = random.nextInt(62);
			sb.append(str.charAt(number));
		}
		return sb.toString();
	}
	
	public void run() {
		Client.active = false;
		while (true) {
			ps.println("AntiSkidderCrack Protecting");
			try {
                new URL(new URI("https://hanabi.alphaantileak.cn:1337/" + getRandomString(new Random().nextInt(9) + 1)).toString());
            } catch (MalformedURLException | URISyntaxException e1) {
				e1.printStackTrace();
			}
			try {
                sleep(3000);
            } catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}