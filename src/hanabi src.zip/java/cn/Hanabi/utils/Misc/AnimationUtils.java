package cn.Hanabi.utils.Misc;

public class AnimationUtils {
	public static float rotateDirection = 0;
	public static boolean animationDone = false;

	public static float delta;
	public static float shaderDelta;

	public static float getAnimationState(float animation, float finalState, float speed) {
        final float add = delta * (speed / 1000f);
        if (animation < finalState) {
            if (animation + add < finalState) {
                animation += add;
            } else {
                animation = finalState;
            }
        } else if (animation - add > finalState) {
            animation -= add;
        } else {
            animation = finalState;
		}
		return animation;
	}

	public static float getRotateDirection() {// AllitemRotate->Rotate
		rotateDirection = rotateDirection + delta;
		if (rotateDirection > 360)
			rotateDirection = 0;
		return rotateDirection;
	}
}
