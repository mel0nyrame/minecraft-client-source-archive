package cn.Hanabi.injection.mixins;

import cn.Hanabi.events.BBSetEvent;
import cn.Hanabi.events.EventBlockRenderSide;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.render.Xray;
import cn.Hanabi.utils.Entity.Helper;
import com.darkmagician6.eventapi.EventManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSlab;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.List;

@Mixin(Block.class)
public abstract class MixinBlock {

    @Shadow
    @Final
    protected BlockState blockState;
    @Shadow
    protected double minX;
    @Shadow
    protected double minY;
    @Shadow
    protected double minZ;
    @Shadow
    protected double maxX;
    @Shadow
    protected double maxY;
    @Shadow
    protected double maxZ;
    @Final
    @Shadow
    protected Material blockMaterial;
    Minecraft mc = Minecraft.getMinecraft();
    int blockID = 0;
    private Block BLOCK;

    @Shadow
    public abstract void setBlockBounds(float minX, float minY, float minZ, float maxX, float maxY, float maxZ);

    @Shadow
    public abstract boolean isFullCube();

    @Shadow
    public abstract boolean isBlockNormalCube();

    /**
     * @author
     */
    @Overwrite
    public void addCollisionBoxesToList(World worldIn, BlockPos pos, IBlockState state, AxisAlignedBB mask,
                                        List<AxisAlignedBB> list, Entity collidingEntity) {
        AxisAlignedBB axisalignedbb = this.getCollisionBoundingBox(worldIn, pos, state);
        BBSetEvent blockBBEvent = new BBSetEvent(blockState.getBlock(), pos, axisalignedbb);
        EventManager.call(blockBBEvent);
        axisalignedbb = blockBBEvent.getBoundingBox();
        if (axisalignedbb != null && mask.intersectsWith(axisalignedbb))
            list.add(axisalignedbb);
    }





    @Overwrite
    public AxisAlignedBB getCollisionBoundingBox(World worldIn, BlockPos pos, IBlockState state) {
        return new AxisAlignedBB((double) pos.getX() + this.minX, (double) pos.getY() + this.minY,
                (double) pos.getZ() + this.minZ, (double) pos.getX() + this.maxX, (double) pos.getY() + this.maxY,
                (double) pos.getZ() + this.maxZ);
    }




}
