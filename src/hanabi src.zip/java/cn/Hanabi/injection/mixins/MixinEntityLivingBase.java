package cn.Hanabi.injection.mixins;

import cn.Hanabi.injection.interfaces.IEntityLivingBase;
import net.minecraft.entity.EntityLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(EntityLivingBase.class)
public abstract class MixinEntityLivingBase implements IEntityLivingBase {
	@Shadow protected abstract int getArmSwingAnimationEnd();

	@Shadow
	private int jumpTicks;

	@Override
	public int runGetArmSwingAnimationEnd() {
		return this.getArmSwingAnimationEnd();
	}

	@Override
	public int getJumpTicks(){
		return jumpTicks;
	}

	@Override
	public void setJumpTicks(int a){
		 jumpTicks = a;
	}
	
}
