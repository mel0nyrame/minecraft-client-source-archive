package cn.Hanabi.injection.mixins;

import net.minecraft.util.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import cn.Hanabi.injection.interfaces.IEntity;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.combat.Hitbox;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.world.World;

@Mixin(Entity.class)
public abstract class MixinEntity implements IEntity {

	@Shadow
	public double posX;
	@Shadow
	public double posY;
	@Shadow
	public double posZ;

	@Shadow
	public float rotationYaw;
	@Shadow
	public float rotationPitch;



	@Shadow
	public boolean onGround;

	@Shadow
	private int nextStepDistance;

	@Shadow
	private int fire;

	@Shadow
	private AxisAlignedBB boundingBox;

	@Shadow public World worldObj;

	@Override
	public int getNextStepDistance() {
		return nextStepDistance;
	}

	@Shadow
	public abstract Vec3 getVectorForRotation(float pitch, float yaw);

	@Override
	public void setNextStepDistance(int distance) {
		nextStepDistance = distance;
	}

	@Override
	public int getFire() {
		return fire;
	}

	@Override
	public void setFire(int i) {
		fire = i;
	}

	@Override
	public AxisAlignedBB getBoundingBox() {
		return boundingBox;
	}

	/**
	 * @author
	 */
	@Overwrite
	public float getCollisionBorderSize()
	{
		if(ModManager.getModule("Hitbox").isEnabled()) {
			return 0.1F + Hitbox.getSize();
		} else {
			return 0.1F;
		}
	}
}
