package cn.Hanabi.injection.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import cn.Hanabi.injection.interfaces.IItemTools;
import net.minecraft.item.ItemTool;

@Mixin(ItemTool.class)
public class MixinItemTools implements IItemTools {
	@Shadow protected float efficiencyOnProperMaterial = 4.0F;
	@Shadow  private float damageVsEntity;


	@Override
	public float getEfficiencyOnProperMaterial() {
		return efficiencyOnProperMaterial;
	}
	
	@Override
	public float getdamageVsEntity() {
		return damageVsEntity;
	}
}
