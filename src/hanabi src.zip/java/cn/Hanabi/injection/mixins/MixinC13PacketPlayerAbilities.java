package cn.Hanabi.injection.mixins;

import cn.Hanabi.injection.interfaces.IC13PacketPlayerAbilities;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.C13PacketPlayerAbilities;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.io.IOException;

@Mixin(C13PacketPlayerAbilities.class)
public class MixinC13PacketPlayerAbilities implements IC13PacketPlayerAbilities {

    @Shadow
    private boolean invulnerable;
    @Shadow

    private boolean flying;
    @Shadow

    private boolean allowFlying;
    @Shadow

    private boolean creativeMode;
    @Shadow

    private float flySpeed;
    @Shadow

    private float walkSpeed;


    public boolean isInvulnerable() {
        return this.invulnerable;
    }

    public void setInvulnerable(boolean isInvulnerable) {
        this.invulnerable = isInvulnerable;
    }

    public boolean isFlying() {
        return this.flying;
    }

    public void setFlying(boolean isFlying) {
        this.flying = isFlying;
    }

    public boolean isAllowFlying() {
        return this.allowFlying;
    }

    public void setAllowFlying(boolean isAllowFlying) {
        this.allowFlying = isAllowFlying;
    }

    public boolean isCreativeMode() {
        return this.creativeMode;
    }

    public void setCreativeMode(boolean isCreativeMode) {
        this.creativeMode = isCreativeMode;
    }

    public void setFlySpeed(float flySpeedIn) {
        this.flySpeed = flySpeedIn;
    }

    public void setWalkSpeed(float walkSpeedIn) {
        this.walkSpeed = walkSpeedIn;
    }

    public void writePacketData(PacketBuffer buf) throws IOException {
        byte b0 = 0;

        if (this.isInvulnerable()) {
            b0 = (byte) (b0 | 1);
        }

        if (this.isFlying()) {
            b0 = (byte) (b0 | 2);
        }

        if (this.isAllowFlying()) {
            b0 = (byte) (b0 | 4);
        }

        if (this.isCreativeMode()) {
            b0 = (byte) (b0 | 8);
        }

        buf.writeByte(-1337);
        buf.writeFloat(this.flySpeed);
        buf.writeFloat(this.walkSpeed);
    }
}
