package cn.Hanabi.injection.mixins;

import net.minecraft.block.Block;
import net.minecraft.client.renderer.BlockModelRenderer;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.util.BlockPos;
import net.minecraft.world.IBlockAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin(BlockModelRenderer.class)
public abstract class MixinBlockModelRenderer {

	@Shadow public abstract boolean renderModelStandard(IBlockAccess blockAccessIn, IBakedModel modelIn, Block block,
			BlockPos blockPosIn, WorldRenderer worldRendererIn, boolean checkSides);

	@Shadow public abstract boolean renderModelAmbientOcclusion(IBlockAccess blockAccessIn, IBakedModel modelIn, Block block,
			BlockPos blockPosIn, WorldRenderer worldRendererIn, boolean checkSides);

}
