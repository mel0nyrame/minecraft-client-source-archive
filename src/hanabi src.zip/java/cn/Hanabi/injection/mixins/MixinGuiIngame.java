/*
 * Copyright (c) 2018 superblaubeere27
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package cn.Hanabi.injection.mixins;

import cn.Hanabi.Hanabi;
import cn.Hanabi.events.EventRender2D;
import cn.Hanabi.gui.ScoreBoardMove;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.render.HUD;
import com.darkmagician6.eventapi.EventManager;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.EnumChatFormatting;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collection;
import java.util.List;

@SideOnly(Side.CLIENT)
@Mixin(GuiIngame.class)
public class MixinGuiIngame {

    @Inject(method = "renderTooltip", at = @At("HEAD"), cancellable = true)
    private void renderTooltip(ScaledResolution sr, float partialTicks, CallbackInfo ci) {
        EventManager.call(new EventRender2D(partialTicks));
        GlStateManager.color(1, 1, 1);
        if (ModManager.getModule("HUD").isEnabled() && ((HUD) ModManager.getModule("HUD")).hotbar.getValueState()) ci.cancel();
    }

    @Inject(method = "renderScoreboard", at = @At("HEAD"), cancellable = true)
    public void customBoard(ScoreObjective so, ScaledResolution sr, CallbackInfo info) {
    	if(Hanabi.INSTANCE.sbm == null) {
    		Scoreboard scoreboard = so.getScoreboard();
			Collection<Score> collection = scoreboard.getSortedScores(so);
			List<Score> list = Lists.newArrayList(Iterables.filter(collection, new Predicate<Score>() {
				public boolean apply(Score a) {
					return a.getPlayerName() != null && !a.getPlayerName().startsWith("#");
				}
			}));

			if (list.size() > 15) {
				collection = Lists.newArrayList(Iterables.skip(list, collection.size() - 15));
			} else {
				collection = list;
			}

			int maxLength = Minecraft.getMinecraft().fontRendererObj.getStringWidth(so.getDisplayName());

			for (Score score : collection) {
				ScorePlayerTeam scoreplayerteam = scoreboard.getPlayersTeam(score.getPlayerName());
				String s = ScorePlayerTeam.formatPlayerName(scoreplayerteam, score.getPlayerName()) + ": "
						+ EnumChatFormatting.RED + score.getScorePoints();
				maxLength = Math.max(maxLength, Minecraft.getMinecraft().fontRendererObj.getStringWidth(s));
			}
    		
			int i1 = collection.size() * Minecraft.getMinecraft().fontRendererObj.FONT_HEIGHT;
	        int startY = sr.getScaledHeight() / 2 + i1 / 3;
			
    		Hanabi.INSTANCE.sbm = new ScoreBoardMove(sr.getScaledWidth() - maxLength - 4, startY);
        }

        if(Hanabi.INSTANCE.sbm != null) {
        	Hanabi.INSTANCE.sbm.passValue();
        }
        
        info.cancel();
    }
}
