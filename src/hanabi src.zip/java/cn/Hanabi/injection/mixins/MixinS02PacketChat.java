package cn.Hanabi.injection.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import cn.Hanabi.injection.interfaces.IS02PacketChat;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.util.IChatComponent;

@Mixin(S02PacketChat.class)
public class MixinS02PacketChat implements IS02PacketChat {
    @Shadow
    private IChatComponent chatComponent;

    @Override
    public IChatComponent getChatComponent() {
        return chatComponent;
    }

    @Override
    public void setChatComponent(IChatComponent i) {
        this.chatComponent = i;
    }

}
