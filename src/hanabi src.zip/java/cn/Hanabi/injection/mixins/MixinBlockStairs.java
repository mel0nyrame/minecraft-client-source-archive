package cn.Hanabi.injection.mixins;

import cn.Hanabi.modules.ModManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockStairs;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(BlockStairs.class)
public class MixinBlockStairs {

    @Final
    @Shadow
    private Block modelBlock;




}
