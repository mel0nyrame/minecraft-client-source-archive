package cn.Hanabi.injection.mixins;

import cn.Hanabi.Client;
import cn.Hanabi.Hanabi;
import cn.Hanabi.events.EventClickMouse;
import cn.Hanabi.events.EventKey;
import cn.Hanabi.events.EventTick;
import cn.Hanabi.events.EventLoop;
import cn.Hanabi.injection.interfaces.IMinecraft;
import cn.Hanabi.utils.ChatUtils;
import cn.Hanabi.utils.Misc.RenderUtil;

import com.darkmagician6.eventapi.EventManager;

import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.main.GameConfiguration;
import net.minecraft.client.resources.LanguageManager;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Session;
import net.minecraft.util.Timer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

@Mixin(Minecraft.class)
@SideOnly(Side.CLIENT)
public abstract class MixinMinecraft implements IMinecraft {
    @Shadow
    public int rightClickDelayTimer;

    long lastFrame;

    @Shadow
    public GuiScreen currentScreen;

    @Shadow
    @Mutable
    @Final
    private Session session;

    @Shadow
    private LanguageManager mcLanguageManager;

    @Shadow
    private Timer timer;
    @Shadow
    private int leftClickCounter;

    @Shadow
    protected abstract void clickMouse();

    ServerSocket serverSocket = null;
    Socket s = null;
    BufferedReader br = null;
    InputStream is = null;
    int VL;

    public void runCrinkMouse() {
        this.clickMouse();
    }

    public void setClickCounter(int a) {
        this.leftClickCounter = a;
    }




    @Inject(method = "<init>", at = @At("RETURN"))
    private void minecraftConstructor(GameConfiguration gameConfig, CallbackInfo ci) {
        if (Integer.parseInt(System.getProperty("java.version").split("_")[1]) < 180) {
            ChatUtils.showMessageBox("鍚姩澶辫触銆傝鏇存柊Java銆�");
            return;
        }

    }
    @Shadow
    public int displayWidth;

    @Shadow
    public int displayHeight;

    @Inject(method = "run", at = @At("HEAD"))
    private void init(CallbackInfo callbackInfo) {
        if (displayWidth < 1100)
            displayWidth = 1100;

        if (displayHeight < 630)
            displayHeight = 630;
    }

    @Inject(method = "startGame", at = @At(value = "FIELD", target = "Lnet/minecraft/client/Minecraft;ingameGUI:Lnet/minecraft/client/gui/GuiIngame;", shift = At.Shift.AFTER))
    private void startGame(CallbackInfo ci) {
        new Hanabi();
        Hanabi.INSTANCE.startClient();
    }

    @Inject(method = "createDisplay", at = @At(value = "INVOKE", target = "Lorg/lwjgl/opengl/Display;setTitle(Ljava/lang/String;)V", shift = At.Shift.AFTER))
    private void createDisplay(CallbackInfo callbackInfo) {
        Display.setTitle(Hanabi.CLIENT_NAME + " " + Hanabi.CLIENT_VERSION);
    }

    @Inject(method = "runGameLoop", at = @At("HEAD"))
    private void runGameLoop(CallbackInfo ci) throws IOException {
        long i = System.nanoTime();
        long thisFrame = System.currentTimeMillis();
        RenderUtil.delta = (float) (thisFrame - this.lastFrame) / 1000.0f;
        this.lastFrame = thisFrame;
        Client.onGameLoop();
    }


    @Inject(method = "clickMouse", at = @At("HEAD"))
    private void clickMouse(CallbackInfo ci) {
        EventManager.call(new EventClickMouse());
    }

    @Inject(method = "runGameLoop", at = @At("HEAD"))
    private void onLoop(CallbackInfo ci) {
        EventManager.call(new EventLoop());
    }

    @Inject(method = "runTick", at = @At("HEAD"))
    private void tick(CallbackInfo ci) {
        // EventTick event = new EventTick();
        EventManager.call(new EventTick());

    }

    @Inject(method = "runTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Minecraft;dispatchKeypresses()V", shift = At.Shift.AFTER))
    private void onKey(CallbackInfo ci) {
        if (Keyboard.getEventKeyState() && currentScreen == null)
            EventManager.call(new EventKey(
                    Keyboard.getEventKey() == 0 ? Keyboard.getEventCharacter() + 256 : Keyboard.getEventKey()));
    }

    @Inject(method = "shutdown", at = @At("HEAD"))
    private void onShutdown(CallbackInfo ci) {

        Hanabi.INSTANCE.stopClient();
    }

    /**
     * @author
     */
    @Overwrite
    private void sendClickBlockToController(boolean leftClick) {
        if (!leftClick) {
            this.leftClickCounter = 0;
        }

        if (this.leftClickCounter <= 0) {
            if (leftClick && Minecraft.getMinecraft().objectMouseOver != null && Minecraft
                    .getMinecraft().objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
                BlockPos blockpos = Minecraft.getMinecraft().objectMouseOver.getBlockPos();

                if (Minecraft.getMinecraft().theWorld.getBlockState(blockpos).getBlock().getMaterial() != Material.air
                        && Minecraft.getMinecraft().playerController.onPlayerDamageBlock(blockpos,
                        Minecraft.getMinecraft().objectMouseOver.sideHit)) {
                    Minecraft.getMinecraft().effectRenderer.addBlockHitEffects(blockpos,
                            Minecraft.getMinecraft().objectMouseOver.sideHit);
                    Minecraft.getMinecraft().thePlayer.swingItem();
                }
            } else {
                Minecraft.getMinecraft().playerController.resetBlockRemoving();
            }
        }
    }

    @Override
    public Session getSession() {
        return session;
    }

    @Override
    public void setSession(Session session) {
        this.session = session;
    }

    public Timer getTimer() {
        return timer;
    }

    @Override
    public LanguageManager getLanguageManager() {
        return mcLanguageManager;
    }

    @Override
    public void setRightClickDelayTimer(int i) {
        rightClickDelayTimer = i;
    }
}