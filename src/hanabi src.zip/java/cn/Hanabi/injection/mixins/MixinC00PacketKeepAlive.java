package cn.Hanabi.injection.mixins;

import cn.Hanabi.injection.interfaces.IC00PacketKeepAlive;
import cn.Hanabi.injection.interfaces.IC0FPacketConfirmTransaction;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(C00PacketKeepAlive.class)
public class MixinC00PacketKeepAlive implements IC00PacketKeepAlive {
    @Shadow
    private int key;


    @Override
    public void setKey(int b) {
        key = b;
    }

    @Override
    public int getKey() {
        return key;
    }


}
