package cn.Hanabi.injection.mixins;


import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.player.Freecam;
import io.netty.channel.Channel;
import io.netty.channel.socket.SocketChannel;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "net.minecraft.network.NetworkManager$5")
public abstract class MixinNetworkManagerChInit {

}
