package cn.Hanabi.injection.mixins;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import cn.Hanabi.injection.interfaces.IItemSword;
import net.minecraft.item.ItemSword;

@Mixin(ItemSword.class)
public class MixinItemSword implements IItemSword {

	@Shadow private float attackDamage;
	
	@Override
	public float getAttackDamage() {
		return attackDamage;
	}

}
