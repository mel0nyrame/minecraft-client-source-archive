package cn.Hanabi.injection.mixins;

import cn.Hanabi.injection.interfaces.IEntityPlayer;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(EntityPlayer.class)
public class MixinEntityPlayer implements IEntityPlayer {
    @Shadow
    public int itemInUseCount;
    @Shadow
    protected float speedInAir;

    @Override
    public void setSpeedInAir(float i) {
        speedInAir = i;
    }


    @Override
    public void setItemInUseCount(int i) {
        itemInUseCount = i;
    }
}
