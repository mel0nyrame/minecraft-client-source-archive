package cn.Hanabi.injection.mixins;

import cn.Hanabi.modules.ModManager;
import net.minecraft.client.renderer.chunk.SetVisibility;
import net.minecraft.client.renderer.chunk.VisGraph;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.BitSet;
import java.util.Set;

@Mixin(VisGraph.class)
public abstract class MixinVisGraph {
    @Final
    @Shadow
    private static int[] field_178613_e;
    @Final
    @Shadow
    private BitSet field_178612_d;
    @Shadow
    private int field_178611_f;

    private static int getIndex(BlockPos pos) {
        return getIndex(pos.getX() & 15, pos.getY() & 15, pos.getZ() & 15);
    }

    private static int getIndex(int x, int y, int z) {
        return x << 0 | y << 8 | z << 4;
    }

    @Shadow
    public abstract Set<EnumFacing> func_178604_a(int i);



}
