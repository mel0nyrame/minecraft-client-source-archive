package cn.Hanabi.injection.mixins;

import cn.Hanabi.events.DamageBlockEvent;
import cn.Hanabi.events.EventAttack;
import cn.Hanabi.injection.interfaces.IPlayerControllerMP;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.combat.Reach;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.WorldSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerControllerMP.class)
public class MixinPlayerControllerMP implements IPlayerControllerMP {
	@Shadow private WorldSettings.GameType currentGameType;
	
	@Shadow private float curBlockDamageMP;

	@Shadow private int blockHitDelay;
	
	@Inject(method = "attackEntity", at = { @At("HEAD") })
	public void attack(EntityPlayer playerIn, Entity targetEntity, CallbackInfo info) {
		EventManager.call(new EventAttack(targetEntity));
	}
	
	/**
	 * @author
	 */
	@Overwrite
	public float getBlockReachDistance() {
    	if(ModManager.getModule("Reach").isEnabled() && !ModManager.getModule("TPHit").isEnabled()) {
    		return (float) Reach.getReach() + 1.5f;
    	} else {
    		return this.currentGameType.isCreative() ? 5.0F : 4.5F;
    	}
	}

	@Inject(method = "onPlayerDamageBlock", at = @At("HEAD"), cancellable = true)
	private void onPlayerDamageBlock(BlockPos posBlock, EnumFacing directionFacing, CallbackInfoReturnable<Boolean> cir) {
		DamageBlockEvent event = new DamageBlockEvent(posBlock, directionFacing);
		EventManager.call(event);
	}



	@Override
	public float getCurBlockDamageMP() {
		// TODO Auto-generated method stub
		return curBlockDamageMP;
	}


	@Override
	public int getBlockDELAY() {
		return blockHitDelay;

	}

	@Override
	public void setCurBlockDamageMP(float f) {
		curBlockDamageMP = f;
		
	}

	@Override
	public void setBlockHitDelay(int i) {
		blockHitDelay = i;

	}
}
