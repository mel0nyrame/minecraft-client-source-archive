package cn.Hanabi.injection.interfaces;

public interface IC10PacketCreativeInventoryAction {
}
