package cn.Hanabi.injection.interfaces;

import net.minecraft.util.ResourceLocation;

public interface IEntityRenderer {
    void runSetupCameraTransform(float partialTicks, int pass);

    void loadShader2(ResourceLocation resourceLocationIn);
}
