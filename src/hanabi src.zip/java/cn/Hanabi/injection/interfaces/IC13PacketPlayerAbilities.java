package cn.Hanabi.injection.interfaces;

public interface IC13PacketPlayerAbilities {
}
