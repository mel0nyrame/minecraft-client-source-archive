package cn.Hanabi.injection.interfaces;

public interface IC01PacketChatMessage {
    String getMessage();

    void setMessage(String s);
}
