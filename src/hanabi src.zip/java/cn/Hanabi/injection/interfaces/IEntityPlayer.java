package cn.Hanabi.injection.interfaces;

public interface IEntityPlayer {
    void setItemInUseCount(int i);

    void setSpeedInAir(float i);

}
