package cn.Hanabi.injection.interfaces;

public interface IItemTools {
    float getEfficiencyOnProperMaterial();

    float getdamageVsEntity();

}
