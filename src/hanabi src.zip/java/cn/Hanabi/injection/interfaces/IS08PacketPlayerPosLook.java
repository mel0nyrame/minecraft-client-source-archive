package cn.Hanabi.injection.interfaces;

public interface IS08PacketPlayerPosLook {
	void setYaw(float y);
	
	void setPitch(float p);
}
