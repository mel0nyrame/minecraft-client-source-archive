package cn.Hanabi.injection.interfaces;

public interface IItemSword {
    float getAttackDamage();
}
