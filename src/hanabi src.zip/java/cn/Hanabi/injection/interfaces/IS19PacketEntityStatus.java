package cn.Hanabi.injection.interfaces;

public interface IS19PacketEntityStatus {
    void getEntityId(int b);
     int getEntityId();
     void getLogicOpcode(byte b);
    byte getLogicOpcode();
}
