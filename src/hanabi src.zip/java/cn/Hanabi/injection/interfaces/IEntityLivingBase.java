package cn.Hanabi.injection.interfaces;

public interface IEntityLivingBase {
    int runGetArmSwingAnimationEnd();
    int getJumpTicks();
    void setJumpTicks(int a);
}
