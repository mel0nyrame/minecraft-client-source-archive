package cn.Hanabi.injection.interfaces;

public interface IC00PacketKeepAlive {
    void setKey(int b);

    int getKey();
}
