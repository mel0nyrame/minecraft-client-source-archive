package cn.Hanabi.injection.interfaces;

public interface IS32PacketConfirmTransaction {

    void setwindowId(int b);

    int getwindowID();

    void setAccepted(boolean b);

    void setUid(short b);

    short getUid();

    boolean getAccepted();

}