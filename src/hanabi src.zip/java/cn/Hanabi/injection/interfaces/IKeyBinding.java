package cn.Hanabi.injection.interfaces;

public interface IKeyBinding {
    boolean getPress();

    void setPress(Boolean b);
}
