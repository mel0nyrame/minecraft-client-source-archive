package cn.Hanabi.modules;

public class ModAddon {
    private final Mod mod;

    public ModAddon(Mod mod) {
        this.mod = mod;
    }
}
