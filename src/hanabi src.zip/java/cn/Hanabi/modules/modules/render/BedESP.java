package cn.Hanabi.modules.modules.render;

import cn.Hanabi.events.EventRender;
import cn.Hanabi.injection.interfaces.IRenderManager;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Misc.NukerUtil;
import cn.Hanabi.utils.Misc.RenderUtil;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.util.BlockPos;

public class BedESP extends Mod {
	public BedESP() {
		super("BedESP", Category.RENDER);
		// TODO Auto-generated constructor stub
	}
	@EventTarget
	public void onRender(EventRender e) {
		for (BlockPos pos : NukerUtil.list) {
			RenderUtil.drawSolidBlockESP(pos.getX() - ((IRenderManager) mc.getRenderManager()).getRenderPosX(),
					pos.getY() - ((IRenderManager) mc.getRenderManager()).getRenderPosY(),
					pos.getZ() - ((IRenderManager) mc.getRenderManager()).getRenderPosZ(), 1f, 1f, 1f, 0.2f);
		}
	}
}
