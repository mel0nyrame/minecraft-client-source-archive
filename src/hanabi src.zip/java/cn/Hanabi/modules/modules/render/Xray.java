package cn.Hanabi.modules.modules.render;

import cn.Hanabi.events.EventRenderBlock;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Entity.Helper;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import com.google.common.collect.Lists;
import net.minecraft.util.BlockPos;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class Xray extends Mod {
    public static ArrayList<BlockPos> glow;
    public static ArrayList<Integer> blocks;
    public static Value<Double> Opacity = new Value<Double>("Xray_Opacity", 160d, 0.0d, 255d, 5d);
    private static final HashSet<Integer> blockIDs = new HashSet<>();

    static {
        Xray.glow = new ArrayList<BlockPos>();
        Xray.blocks = new ArrayList<Integer>();
    }

    public CopyOnWriteArrayList list = new CopyOnWriteArrayList();
    public boolean loaded;
    public Value<Boolean> Bypass = new Value<Boolean>("Xray_Bypass", true);
    public Value<String> espmode = new Value<String>("Xray", "ESPMode", 0);
    Thread updater;
    List<Integer> KEY_IDS = Lists.newArrayList(10, 11, 8, 9, 14, 15, 16, 21, 41, 42, 46, 48, 52, 56, 57, 61, 62,
            73, 74, 84, 89, 103, 116, 117, 118, 120, 129, 133, 137, 145, 152, 153, 154);

    public Xray() {
        super("Xray", Category.RENDER);
        espmode.addValue("Box");
        espmode.addValue("None");

        // TODO Auto-generated constructor stub
    }
    @Override
    public void onEnable() {
        super.onEnable();
        Helper.dimblock.clear();
        blockIDs.clear();
        Helper.glow.clear();

        try {

            for (Object key_id : this.KEY_IDS) {
                Integer o = (Integer) key_id;
                blockIDs.add(o);
                Xray.blocks.add(o);
            }
        } catch (Exception var3) {
            var3.printStackTrace();
        }
        Helper.bypass = Bypass.getValue();
        Helper.opacity =  Opacity.getValue().intValue();
        Helper.blockIDs = blockIDs;
        Helper.xray = true;
        mc.renderGlobal.loadRenderers();
        final int var0 = (int) mc.thePlayer.posX;
        final int var = (int) mc.thePlayer.posY;
        final int var2 = (int) mc.thePlayer.posZ;
        mc.renderGlobal.markBlockRangeForRenderUpdate(var0 - 900, var - 900, var2 - 900, var0 + 900, var + 900,
                var2 + 900);

        loaded = true;

    }

    @Override
    public void onDisable() {
        super.onDisable();
        Helper.xray = false;
        mc.renderGlobal.loadRenderers();
        Helper.dimblock.clear();
        loaded = false;
        try {
            this.updater.interrupt();
            this.updater = null;
        } catch (Exception ex) {
        }
    }


    @EventTarget
    public void onRender(EventRenderBlock render) {
        if (espmode.isCurrentMode("None")) {
        } else {

        }
    }
}