package cn.Hanabi.modules.modules.render;

import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class ViewClip extends Mod {

	public ViewClip() {
		super("ViewClip", Category.RENDER);

	}

}