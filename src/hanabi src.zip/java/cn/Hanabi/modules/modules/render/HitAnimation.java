package cn.Hanabi.modules.modules.render;

import com.darkmagician6.eventapi.EventTarget;

import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.value.Value;

public class HitAnimation extends Mod {
	public static Value<String> mode = new Value<String>("HitAnimation", "Mode", 0);

	public HitAnimation() {
        super("HitAnimation", Category.RENDER);
        mode.addValue("Vanilla");
        mode.addValue("1.7");
        mode.addValue("Swang");
        mode.addValue("Swank");
        mode.addValue("Swong");
        mode.addValue("Sigma");
        mode.addValue("Jello");
        mode.addValue("Slide");
        mode.addValue("Ohare");
        mode.addValue("Wizzard");
        mode.addValue("Lennox");
        mode.addValue("Push");
        mode.addValue("Chill");
        mode.addValue("Butter");
    }

	@EventTarget
	public void onUpdate(EventUpdate e) {
		this.setDisplayName(mode.getValueState());
	}
}
