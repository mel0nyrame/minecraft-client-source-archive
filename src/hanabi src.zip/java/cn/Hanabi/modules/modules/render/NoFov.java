package cn.Hanabi.modules.modules.render;

import cn.Hanabi.Wrapper;
import cn.Hanabi.events.EventRender;
import cn.Hanabi.injection.interfaces.IRenderManager;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;


public class NoFov extends Mod {
    public static Value<Double> fovspoof = new Value("NoFov_Fov", 1.0d, 0.1d, 1.5d, 0.01d);

    public NoFov() {
        super("NoFov", Category.RENDER);
    }

}