package cn.Hanabi.modules.modules.render;

import cn.Hanabi.Hanabi;
import cn.Hanabi.Wrapper;
import cn.Hanabi.events.EventRender;
import cn.Hanabi.events.EventRender2D;
import cn.Hanabi.injection.interfaces.IEntityRenderer;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.modules.world.AntiBot;
import cn.Hanabi.modules.modules.world.Teams;
import cn.Hanabi.utils.Misc.Colors;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.utils.Rotation.RotationUtil;
import cn.Hanabi.utils.fontmanager.UnicodeFontRenderer;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

import java.awt.*;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Nametags extends Mod {
	public static Map<EntityLivingBase, double[]> entityPositions = new HashMap();

	public Value<Boolean> invis = new Value<Boolean>("Nametags_Invisible", false);
	public Value<Boolean> armor = new Value<Boolean>("Nametags_Armor", false);
	public Nametags() {
		super("Nametags", Category.RENDER);
	}

	@EventTarget
	public void update(EventRender event) {
		try {
			updatePositions();
		} catch (Exception e) {}
	}

	@EventTarget
	public void onRender2D(EventRender2D event) {
		GlStateManager.pushMatrix();
		ScaledResolution scaledRes = new ScaledResolution(mc);
		boolean exhiMode = true;
		for (Entity ent : entityPositions.keySet()) {
			if (ent != mc.thePlayer && (this.invis.getValueState() || !ent.isInvisible())) {

				GlStateManager.pushMatrix();
				if ((ent instanceof EntityPlayer)) {

					double[] renderPositions = entityPositions.get(ent);
					if ((renderPositions[3] < 0.0D) || (renderPositions[3] >= 1.0D)) {
						GlStateManager.popMatrix();
						continue;
					}

					UnicodeFontRenderer font = Hanabi.INSTANCE.fontManager.wqy18;
					if (exhiMode) {
						font = Hanabi.INSTANCE.fontManager.comfortaa12;
					}
					GlStateManager.translate(renderPositions[0] / scaledRes.getScaleFactor(), renderPositions[1] / scaledRes.getScaleFactor(), 0.0D);
					scale();
					GlStateManager.translate(0.0D, -2.5D, 0.0D);

					String health = "Health: " + Math.round(((EntityLivingBase) ent).getHealth() * 10) / 10;
					String str = (AntiBot.isBot(ent) ? "\2479[BOT]" : "") + (Teams.isOnSameTeam(ent) ? "\247b[TEAM]" : "") + "\247r" + ent.getDisplayName().getUnformattedText();
					String suff = "";




					str = str + suff;

					float strWidth = font.getStringWidth(str.replaceAll("\247.", ""));
					float strWidth2 = Hanabi.INSTANCE.fontManager.comfortaa12.getStringWidth(health);
					float allWidth = (strWidth > strWidth2 ? strWidth : strWidth2) + 8;
					RenderUtil.drawRect(-allWidth / 2, exhiMode ? -12 : -25.0f, allWidth / 2, 0, Colors.getColor(0, 130));
					int x3 = ((int) (renderPositions[0] + -allWidth / 2 - 3) / 2) - 26;
					int x4 = ((int) (renderPositions[0] + allWidth / 2 + 3) / 2) + 20;
					int y1 = ((int) (renderPositions[1] + -30) / 2);
					int y2 = ((int) (renderPositions[1] + 11) / 2);
					int mouseY = (scaledRes.getScaledHeight() / 2);
					int mouseX = (scaledRes.getScaledWidth() / 2);
					if (!exhiMode)
					font.drawStringWithColor(str, -allWidth / 2 + 4, -22.0F, Colors.WHITE.c);
					
					Hanabi.INSTANCE.fontManager.comfortaa12.drawStringWithColor(exhiMode ? str : health, -allWidth / 2 + 4, -10.0F, Colors.WHITE.c);

					EntityLivingBase entity = (EntityLivingBase) ent;
					float nowhealth = (float) Math.ceil(entity.getHealth() + entity.getAbsorptionAmount());
					float maxHealth = entity.getMaxHealth() + entity.getAbsorptionAmount();
					float healthP = nowhealth / maxHealth;
					RenderUtil.drawRect(-allWidth / 2, -1, allWidth / 2, 0, Colors.getColor(100,0,0, 255));
					RenderUtil.drawRect(-allWidth / 2, -1, allWidth / 2 - ((allWidth / 2) * (1 - healthP)) * 2, 0, Colors.RED.c);

					if(armor.getValueState()) {
						List<ItemStack> itemsToRender = new ArrayList<>();
						for (int i = 0; i < 5; i++) {
							ItemStack stack = ((EntityPlayer) ent).getEquipmentInSlot(i);
							if (stack != null) {
								itemsToRender.add(stack);
							}
						}
						int x = -(itemsToRender.size() * 9);
						for (ItemStack stack : itemsToRender) {
							RenderHelper.enableGUIStandardItemLighting();
							mc.getRenderItem().renderItemIntoGUI(stack, x + 6, -42);
							mc.getRenderItem().renderItemOverlays(mc.fontRendererObj, stack, x, -42);
							x += 3;
							RenderHelper.disableStandardItemLighting();
							if (stack != null) {
								int y = 21;
								int sLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId,
										stack);
								int fLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.fireAspect.effectId,
										stack);
								int kLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.knockback.effectId,
										stack);
								if (sLevel > 0) {
									drawEnchantTag("Sh" + getColor(sLevel) + sLevel, x, y);
									y += 6;
								}
								if (fLevel > 0) {
									drawEnchantTag("Fir" + getColor(fLevel) + fLevel, x, y);
									y += 6;
								}
								if (kLevel > 0) {
									drawEnchantTag("Kb" + getColor(kLevel) + kLevel, x, y);
								} else if ((stack.getItem() instanceof ItemArmor)) {
									int pLevel = EnchantmentHelper
											.getEnchantmentLevel(Enchantment.protection.effectId, stack);
									int tLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.thorns.effectId,
											stack);
									int uLevel = EnchantmentHelper
											.getEnchantmentLevel(Enchantment.unbreaking.effectId, stack);
									if (pLevel > 0) {
										drawEnchantTag("P" + getColor(pLevel) + pLevel, x, y);
										y += 6;
									}
									if (tLevel > 0) {
										drawEnchantTag("Th" + getColor(tLevel) + tLevel, x, y);
										y += 6;
									}
									if (uLevel > 0) {
										drawEnchantTag("Unb" + getColor(uLevel) + uLevel, x, y);
									}
								} else if ((stack.getItem() instanceof ItemBow)) {
									int powLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.power.effectId,
											stack);
									int punLevel = EnchantmentHelper.getEnchantmentLevel(Enchantment.punch.effectId,
											stack);
									int fireLevel = EnchantmentHelper
											.getEnchantmentLevel(Enchantment.flame.effectId, stack);
									if (powLevel > 0) {
										drawEnchantTag("Pow" + getColor(powLevel) + powLevel, x, y);
										y += 6;
									}
									if (punLevel > 0) {
										drawEnchantTag("Pun" + getColor(punLevel) + punLevel, x, y);
										y += 6;
									}
									if (fireLevel > 0) {
										drawEnchantTag("Fir" + getColor(fireLevel) + fireLevel, x, y);
									}
								} else if (stack.getRarity() == EnumRarity.EPIC) {
									drawEnchantTag("\2476\247lGod", x - 2, y);
								}
								int var7 = (int) Math.round(255.0D - (double) stack.getItemDamage() * 255.0D / (double) stack.getMaxDamage());
								int var10 = 255 - var7 << 16 | var7 << 8;
								Color customColor = new Color(var10).brighter();

								float x2 = (float) (x * 1.05D) - 2;
								if ((stack.getMaxDamage() - stack.getItemDamage()) > 0) {
									GlStateManager.pushMatrix();
									GlStateManager.disableDepth();
									//Hanabi.INSTANCE.fontManager.comfortaa12.drawString("" + (stack.getMaxDamage() - stack.getItemDamage()), x2 + 6, -32, customColor.getRGB());
									GlStateManager.enableDepth();
									GlStateManager.popMatrix();
								}

								x += 12;
							}
						}
					}
				}
				GlStateManager.popMatrix();
			}
		}
		GlStateManager.popMatrix();
	}

	private void drawEnchantTag(String text, int x, int y) {
		GlStateManager.pushMatrix();
		GlStateManager.disableDepth();
		x = (int) (x * 1.05D);
		y -= 6;
		Hanabi.INSTANCE.fontManager.comfortaa10.drawStringWithColor(text, x + 9, -30 - y, Colors.getColor(255));
		GlStateManager.enableDepth();
		GlStateManager.popMatrix();
	}

	private String getColor(int level) {
		if (level == 1) {

		} else if (level == 2) {
			return "\247a";
		} else if (level == 3) {
			return "\2473";
		} else if (level == 4) {
			return "\2474";
		} else if (level >= 5) {
			return "\2476";
		}
		return "\247f";
	}

	private void scale() {
		float scale = 1;
		scale *= mc.gameSettings.smoothCamera ? 2 : 1;
		GlStateManager.scale(scale, scale, scale);
	}

	private void updatePositions() {
		entityPositions.clear();
		float pTicks = Wrapper.getTimer().renderPartialTicks;
		for (Object o : mc.theWorld.loadedEntityList) {
			Entity ent = (Entity) o;
			if ((ent != mc.thePlayer) && ((ent instanceof EntityPlayer))
					&& ((!ent.isInvisible()) || (!this.invis.getValueState()))) {
				double x = ent.lastTickPosX + (ent.posX - ent.lastTickPosX) * pTicks - mc.getRenderManager().viewerPosX;
				double y = ent.lastTickPosY + (ent.posY - ent.lastTickPosY) * pTicks - mc.getRenderManager().viewerPosY;
				double z = ent.lastTickPosZ + (ent.posZ - ent.lastTickPosZ) * pTicks - mc.getRenderManager().viewerPosZ;
				y += ent.height + 0.2D;
				if ((convertTo2D(x, y, z)[2] >= 0.0D) && (convertTo2D(x, y, z)[2] < 1.0D)) {
					entityPositions.put((EntityPlayer) ent,
							new double[]{convertTo2D(x, y, z)[0], convertTo2D(x, y, z)[1],
									Math.abs(convertTo2D(x, y + 1.0D, z, ent)[1] - convertTo2D(x, y, z, ent)[1]),
									convertTo2D(x, y, z)[2]});
				}
			}
		}
	}

	private double[] convertTo2D(double x, double y, double z, Entity ent) {
		float pTicks = Wrapper.getTimer().renderPartialTicks;
		float prevYaw = mc.thePlayer.rotationYaw;
		float prevPrevYaw = mc.thePlayer.prevRotationYaw;
		float[] rotations = RotationUtil.getRotationFromPosition(
				ent.lastTickPosX + (ent.posX - ent.lastTickPosX) * pTicks,
				ent.lastTickPosZ + (ent.posZ - ent.lastTickPosZ) * pTicks,
				ent.lastTickPosY + (ent.posY - ent.lastTickPosY) * pTicks - 1.6D);
		mc.getRenderViewEntity().rotationYaw = (mc.getRenderViewEntity().prevRotationYaw = rotations[0]);
		((IEntityRenderer) Minecraft.getMinecraft().entityRenderer).runSetupCameraTransform(pTicks, 0);
		double[] convertedPoints = convertTo2D(x, y, z);
		mc.getRenderViewEntity().rotationYaw = prevYaw;
		mc.getRenderViewEntity().prevRotationYaw = prevPrevYaw;
		((IEntityRenderer) Minecraft.getMinecraft().entityRenderer).runSetupCameraTransform(pTicks, 0);
		return convertedPoints;
	}

	private double[] convertTo2D(double x, double y, double z) {
		FloatBuffer screenCoords = BufferUtils.createFloatBuffer(3);
		IntBuffer viewport = BufferUtils.createIntBuffer(16);
		FloatBuffer modelView = BufferUtils.createFloatBuffer(16);
		FloatBuffer projection = BufferUtils.createFloatBuffer(16);
		GL11.glGetFloat(2982, modelView);
		GL11.glGetFloat(2983, projection);
		GL11.glGetInteger(2978, viewport);
		boolean result = GLU.gluProject((float) x, (float) y, (float) z, modelView, projection, viewport, screenCoords);
		if (result) {
			return new double[]{screenCoords.get(0), Display.getHeight() - screenCoords.get(1), screenCoords.get(2)};
		}
		return null;
	}
}
