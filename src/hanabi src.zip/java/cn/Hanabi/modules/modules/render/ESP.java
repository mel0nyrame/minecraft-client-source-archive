package cn.Hanabi.modules.modules.render;

import cn.Hanabi.Wrapper;
import cn.Hanabi.events.EventRender;
import cn.Hanabi.injection.interfaces.IRenderManager;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.utils.Misc.ClientUtil;
import cn.Hanabi.utils.Misc.Colors;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class ESP extends Mod {
	public static Value<String> mode = new Value("ESP", "Mode", 0);
	private final Value<Boolean> invisible = new Value<Boolean>("ESP_Invisible", false);

	public ESP() {
		super("ESP", Category.RENDER);
		mode.addValue("Box");
		mode.addValue("2D");
		//this.mode.addValue("HotRender");

	}

	public static void drawBorderedRect(float x, float y, float x2, float y2, float l1, int col1, int col2) {
		drawRect(x, y, x2, y2, col2);
		float f = (float) (col1 >> 24 & 255) / 255.0F;
		float f1 = (float) (col1 >> 16 & 255) / 255.0F;
		float f2 = (float) (col1 >> 8 & 255) / 255.0F;
		float f3 = (float) (col1 & 255) / 255.0F;
		GL11.glEnable(3042);
		GL11.glDisable(3553);
		GL11.glBlendFunc(770, 771);
		GL11.glEnable(2848);
		GL11.glPushMatrix();
		GL11.glColor4f(f1, f2, f3, f);
		GL11.glLineWidth(l1);
		GL11.glBegin(1);
		GL11.glVertex2d(x, y);
		GL11.glVertex2d(x, y2);
		GL11.glVertex2d(x2, y2);
		GL11.glVertex2d(x2, y);
		GL11.glVertex2d(x, y);
		GL11.glVertex2d(x2, y);
		GL11.glVertex2d(x, y2);
		GL11.glVertex2d(x2, y2);
		GL11.glEnd();
		GL11.glPopMatrix();
		GL11.glEnable(3553);
		GL11.glDisable(3042);
		GL11.glDisable(2848);
	}

	public static void drawRect(float g, float h, float i, float j, int col1) {
		float f = (float) (col1 >> 24 & 255) / 255.0F;
		float f1 = (float) (col1 >> 16 & 255) / 255.0F;
		float f2 = (float) (col1 >> 8 & 255) / 255.0F;
		float f3 = (float) (col1 & 255) / 255.0F;
		GL11.glEnable(3042);
		GL11.glDisable(3553);
		GL11.glBlendFunc(770, 771);
		GL11.glEnable(2848);
		GL11.glPushMatrix();
		GL11.glColor4f(f1, f2, f3, f);
		GL11.glBegin(7);
		GL11.glVertex2d(i, h);
		GL11.glVertex2d(g, h);
		GL11.glVertex2d(g, j);
		GL11.glVertex2d(i, j);
		GL11.glEnd();
		GL11.glPopMatrix();
		GL11.glEnable(3553);
		GL11.glDisable(3042);
		GL11.glDisable(2848);
	}

	public void renderBox(Entity entity, double r, double g, double b) {
		if ((entity.isInvisible() && !invisible.getValueState().booleanValue())) {
			return;
		}

		mc.getRenderManager();
		double x = entity.lastTickPosX
				+ (entity.posX - entity.lastTickPosX) * Wrapper.getTimer().renderPartialTicks
				- ((IRenderManager) mc.getRenderManager()).getRenderPosX();
		mc.getRenderManager();
		double y = entity.lastTickPosY
				+ (entity.posY - entity.lastTickPosY) * Wrapper.getTimer().renderPartialTicks
				- ((IRenderManager) mc.getRenderManager()).getRenderPosY();
		mc.getRenderManager();
		double z = entity.lastTickPosZ
				+ (entity.posZ - entity.lastTickPosZ) * Wrapper.getTimer().renderPartialTicks
				- ((IRenderManager) mc.getRenderManager()).getRenderPosZ();
		double width = entity.getEntityBoundingBox().maxX - entity.getEntityBoundingBox().minX - 0.1;
		double height = entity.getEntityBoundingBox().maxY - entity.getEntityBoundingBox().minY
				+ 0.25;
		RenderUtil.drawEntityESP(x, y, z, width, height, 1f,
				1f, 1f, 0.2f, 1f,
				1f, 1f, 0f, 1f);
	}
	
	public static void func_181561_a(AxisAlignedBB p_181561_0_) {
		Tessellator tessellator = Tessellator.getInstance();
		WorldRenderer worldrenderer = tessellator.getWorldRenderer();
		worldrenderer.begin(3, DefaultVertexFormats.POSITION);
		worldrenderer.pos(p_181561_0_.minX, p_181561_0_.minY, p_181561_0_.minZ).endVertex();
		worldrenderer.pos(p_181561_0_.maxX, p_181561_0_.minY, p_181561_0_.minZ).endVertex();
		worldrenderer.pos(p_181561_0_.maxX, p_181561_0_.minY, p_181561_0_.maxZ).endVertex();
		worldrenderer.pos(p_181561_0_.minX, p_181561_0_.minY, p_181561_0_.maxZ).endVertex();
		worldrenderer.pos(p_181561_0_.minX, p_181561_0_.minY, p_181561_0_.minZ).endVertex();
		tessellator.draw();
		worldrenderer.begin(3, DefaultVertexFormats.POSITION);
		worldrenderer.pos(p_181561_0_.minX, p_181561_0_.maxY, p_181561_0_.minZ).endVertex();
		worldrenderer.pos(p_181561_0_.maxX, p_181561_0_.maxY, p_181561_0_.minZ).endVertex();
		worldrenderer.pos(p_181561_0_.maxX, p_181561_0_.maxY, p_181561_0_.maxZ).endVertex();
		worldrenderer.pos(p_181561_0_.minX, p_181561_0_.maxY, p_181561_0_.maxZ).endVertex();
		worldrenderer.pos(p_181561_0_.minX, p_181561_0_.maxY, p_181561_0_.minZ).endVertex();
		tessellator.draw();
		worldrenderer.begin(1, DefaultVertexFormats.POSITION);
		worldrenderer.pos(p_181561_0_.minX, p_181561_0_.minY, p_181561_0_.minZ).endVertex();
		worldrenderer.pos(p_181561_0_.minX, p_181561_0_.maxY, p_181561_0_.minZ).endVertex();
		worldrenderer.pos(p_181561_0_.maxX, p_181561_0_.minY, p_181561_0_.minZ).endVertex();
		worldrenderer.pos(p_181561_0_.maxX, p_181561_0_.maxY, p_181561_0_.minZ).endVertex();
		worldrenderer.pos(p_181561_0_.maxX, p_181561_0_.minY, p_181561_0_.maxZ).endVertex();
		worldrenderer.pos(p_181561_0_.maxX, p_181561_0_.maxY, p_181561_0_.maxZ).endVertex();
		worldrenderer.pos(p_181561_0_.minX, p_181561_0_.minY, p_181561_0_.maxZ).endVertex();
		worldrenderer.pos(p_181561_0_.minX, p_181561_0_.maxY, p_181561_0_.maxZ).endVertex();
		tessellator.draw();
	}

	@EventTarget
	public void onRender(EventRender event) {
		if (mode.isCurrentMode("Box")) {
			this.setDisplayName("Box");
			for (Object o : mc.theWorld.loadedEntityList) {
				if (o instanceof EntityPlayer) {
					EntityPlayer ent = (EntityPlayer) o;
					if (ent != mc.thePlayer && !ent.isDead) {
						renderBox(ent, 0, 1, 0);
					}
				}
			}
		}
		if (mode.isCurrentMode("2D")) {
			this.setDisplayName("2D");
			this.doOther2DESP();
		}
	}

	private boolean isValid(EntityLivingBase entity) {
		return entity != mc.thePlayer && (!(entity.getHealth() <= 0.0F) && (entity instanceof EntityPlayer));
	}

	private void doOther2DESP() {
		for (final EntityPlayer entity : mc.theWorld.playerEntities) {
			if (entity.isInvisible() && !invisible.getValueState().booleanValue()) {
				return;
			}

			if (isValid(entity)) {
				GL11.glPushMatrix();
				GL11.glEnable(3042);
				GL11.glDisable(2929);
				GL11.glNormal3f(0.0f, 1.0f, 0.0f);
				GlStateManager.enableBlend();
                GL11.glBlendFunc(770, 771);
                GL11.glDisable(3553);
                final float partialTicks = Wrapper.getTimer().renderPartialTicks;
				mc.getRenderManager();
                final double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - ((IRenderManager)mc.getRenderManager()).getRenderPosX();
				mc.getRenderManager();
                final double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - ((IRenderManager)mc.getRenderManager()).getRenderPosY();
				mc.getRenderManager();
				final double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - ((IRenderManager) mc.getRenderManager()).getRenderPosZ();
				final float DISTANCE = mc.thePlayer.getDistanceToEntity(entity);
				final float DISTANCE_SCALE = Math.min(DISTANCE * 0.15f, 0.15f);
                float SCALE = 0.035f;
                SCALE /= 2.0f;
                final float xMid = (float)x;
                final float yMid = (float)y + entity.height + 0.5f - (entity.isChild() ? (entity.height / 2.0f) : 0.0f);
                final float zMid = (float)z;
                GlStateManager.translate((float)x, (float)y + entity.height + 0.5f - (entity.isChild() ? (entity.height / 2.0f) : 0.0f), (float)z);
				GL11.glNormal3f(0.0f, 1.0f, 0.0f);
				GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0f, 1.0f, 0.0f);
				GL11.glScalef(-SCALE, -SCALE, -SCALE);
                final Tessellator tesselator = Tessellator.getInstance();
                final WorldRenderer worldRenderer = tesselator.getWorldRenderer();
                final float HEALTH = entity.getHealth();
                int COLOR = -1;
                if (HEALTH > 20.0) {
                    COLOR = -65292;
                }
                else if (HEALTH >= 10.0) {
                    COLOR = -16711936;
                }
                else if (HEALTH >= 3.0) {
                    COLOR = -23296;
                }
                else {
                    COLOR = -65536;
                }
                final Color gray = new Color(0, 0, 0);
                final double thickness = 1.5f + DISTANCE * 0.01f;
                final double xLeft = -30.0;
                final double xRight = 30.0;
                final double yUp = 15.0;
                final double yDown = 140.0;
                final double size = 10.0;
            //    RenderUtil.drawRect((float)xLeft, (float)yUp, (float)xRight, (float)yDown, ClientUtil.reAlpha(new Color(255, 255, 255).getRGB(), 0.2f));
                drawBorderedRect((float)xLeft, (float)yUp, (float)xRight, (float)yDown, (float)thickness, -1, 0);
                drawBorderedRect((float)xLeft - 3.0f - DISTANCE * 0.2f, (float)yDown - (float)(yDown - yUp), (float)xLeft - 2.0f, (float)yDown, 0.15f, Colors.BLACK.c, new Color(100, 100, 100).getRGB());
                drawBorderedRect((float)xLeft - 3.0f - DISTANCE * 0.2f, (float)yDown - (float)(yDown - yUp) * Math.min(1.0f, entity.getHealth() / 20.0f), (float)xLeft - 2.0f, (float)yDown, 0.15f, Colors.BLACK.c, COLOR);
                drawBorderedRect((float)xLeft, (float)yDown + 2.0f, (float)xRight, (float)yDown + 3.0f + DISTANCE * 0.2f, 0.15f, Colors.BLACK.c, new Color(100, 100, 100).getRGB());
                drawBorderedRect((float)xLeft, (float)yDown + 2.0f, (float)xLeft + (float)(xRight - xLeft) * Math.min(1.0f, entity.getFoodStats().getFoodLevel() / 20.0f), (float)yDown + 3.0f + DISTANCE * 0.2f, 0.15f, Colors.BLACK.c, new Color(0, 150, 255).getRGB());
                GL11.glEnable(3553);
                GL11.glEnable(2929);
                GlStateManager.disableBlend();
                GL11.glDisable(3042);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                GL11.glNormal3f(1.0f, 1.0f, 1.0f);
                GL11.glPopMatrix();
            }
        }
    }

}
