package cn.Hanabi.modules.modules.render;

import java.awt.Color;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.*;

import cn.Hanabi.gui.notifications.Notification;
import cn.Hanabi.modules.modules.world.Scaffold.Scaffold;
import cn.Hanabi.utils.CompassUtil;
import cn.Hanabi.utils.Misc.ClientUtil;
import cn.Hanabi.utils.Misc.Colors;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.utils.PaletteUtil;
import net.minecraft.block.material.Material;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import com.darkmagician6.eventapi.EventTarget;

import cn.Hanabi.Hanabi;
import cn.Hanabi.events.EventRender2D;
import cn.Hanabi.events.EventWorldChange;
import cn.Hanabi.gui.tabgui.SubTab;
import cn.Hanabi.gui.tabgui.Tab;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.player.ModChecker;
import cn.Hanabi.utils.fontmanager.HanabiFonts;
import cn.Hanabi.utils.fontmanager.UnicodeFontRenderer;
import cn.Hanabi.value.Value;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.boss.BossStatus;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ResourceLocation;

public class HUD extends Mod {
    private static final DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm:ss");

    public Value<Boolean> arraylist = new Value<Boolean>("HUD_ArrayList", true);
    public Value<Boolean> arraylistfade = new Value<Boolean>("HUD_Fade", false);
    public Value<Boolean> arraylistoutline = new Value<Boolean>("HUD_Outline", false);
    public Value<Boolean> logo = new Value<Boolean>("HUD_Logo", true);
    public Value<Boolean> hotbar = new Value<Boolean>("HUD_Hotbar", true);
    public Value<Boolean> music = new Value<Boolean>("HUD_MusicPlayer", true);
    public Value<Boolean> potion = new Value<Boolean>("HUD_Potion", true);
    public Value<Boolean> armor = new Value<Boolean>("HUD_Armor", true);
    public Value<Boolean> compass = new Value<Boolean>("HUD_Compass", true);
    public Value<Boolean> noti = new Value<Boolean>("HUD_Notification", true);
    public Value<Boolean> posDisplay = new Value<Boolean>("HUD_Postion", true);
    public static Value<Double> bgalpha = new Value<Double>("HUD_BackGroundAlpha", 45d, 0d, 255d, 5d);
    public static Value<Double> musicPosX = new Value<Double>("HUD_MusicPlayerX",
            70d, 0d, 400d, 1d);
    public static Value<Double> musicPosY = new
            Value<Double>("HUD_MusicPlayerY", 5d, 0d, 200d, 1d);
    public static
    Value<Double> musicPosYlyr = new Value<Double>("HUD_MusicPlayerLyricY", 120d,
            0d, 200d, 1d);

    public CompassUtil compasslol = new CompassUtil(325, 325, 1, 2, true);

    public HUD() {
        super("HUD", Category.RENDER, false, true, Keyboard.KEY_NONE);
        setState(true);

        HashMap<Category, java.util.List<Mod>> moduleCategoryMap = new HashMap<>();

        for (Mod module : Hanabi.INSTANCE.moduleManager.getModules()) {
            if (!moduleCategoryMap.containsKey(module.getCategory())) {
                moduleCategoryMap.put(module.getCategory(), new ArrayList<>());
            }

            moduleCategoryMap.get(module.getCategory()).add(module);
        }

        moduleCategoryMap.entrySet().stream().sorted(Comparator.comparingInt(cat -> cat.getKey().toString().hashCode()))
                .forEach(cat -> {
                    Tab<Mod> tab = new Tab<>(cat.getKey().toString());

                    for (Mod module : cat.getValue()) {
                        tab.addSubTab(new SubTab<>(module.getName(),
                                subTab -> subTab.getObject().setState(!subTab.getObject().getState()), module));
                    }
                });

    }

    @EventTarget
    public void onReload(EventWorldChange e) {
        HUD hud = (HUD) ModManager.getModule("HUD");

        new Thread() {
            public void run() {
                hud.set(false);
                try {
                    sleep(500);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                hud.set(true);
            }
        }.start();
    }

    public static int rainbow(int delay) {
        double rainbowState = Math.ceil((System.currentTimeMillis() + delay) / 20.0);
        rainbowState %= 360;
        return Color.getHSBColor((float) (rainbowState / 360.0f), 0.8f, 0.7f).getRGB();
    }

    public void drawRoundedRect(float x, float y, float x1, float y1, int borderC, int insideC) {
        enableGL2D();
        GL11.glScalef((float) 0.5f, (float) 0.5f, (float) 0.5f);
        drawVLine(x *= 2.0f, (y *= 2.0f) + 1.0f, (y1 *= 2.0f) - 2.0f, borderC);
        drawVLine((x1 *= 2.0f) - 1.0f, y + 1.0f, y1 - 2.0f, borderC);
        drawHLine(x + 2.0f, x1 - 3.0f, y, borderC);
        drawHLine(x + 2.0f, x1 - 3.0f, y1 - 1.0f, borderC);
        drawHLine(x + 1.0f, x + 1.0f, y + 1.0f, borderC);
        drawHLine(x1 - 2.0f, x1 - 2.0f, y + 1.0f, borderC);
        drawHLine(x1 - 2.0f, x1 - 2.0f, y1 - 2.0f, borderC);
        drawHLine(x + 1.0f, x + 1.0f, y1 - 2.0f, borderC);
        RenderUtil.drawRect(x + 1.0f, y + 1.0f, x1 - 1.0f, y1 - 1.0f, insideC);
        GL11.glScalef((float) 2.0f, (float) 2.0f, (float) 2.0f);
        disableGL2D();
    }

    public void color(int color) {
        float f = (float) (color >> 24 & 255) / 255.0f;
        float f1 = (float) (color >> 16 & 255) / 255.0f;
        float f2 = (float) (color >> 8 & 255) / 255.0f;
        float f3 = (float) (color & 255) / 255.0f;
        GL11.glColor4f((float) f1, (float) f2, (float) f3, (float) f);
    }

    public static void enableGL2D() {
        GL11.glDisable(GL11.GL_DEPTH_TEST);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        GL11.glDepthMask(true);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
        GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT, GL11.GL_NICEST);
    }

    public static void disableGL2D() {
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_DEPTH_TEST);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_DONT_CARE);
        GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT, GL11.GL_DONT_CARE);
    }

    SimpleDateFormat f = new SimpleDateFormat("HH:mm");
    SimpleDateFormat f2 = new SimpleDateFormat("YYYY/MM/dd");
    private float animationY2;

    @EventTarget
    private void render2D(EventRender2D event) {
        ScaledResolution sr = new ScaledResolution(mc);
        float width = sr.getScaledWidth();
        float height = sr.getScaledHeight();

        if (potion.getValueState()) {
            this.renderPotionStatus((int) width, (int) height);
        }

        if (compass.getValueState()) {
            renderCompass(sr);
        }

        if(armor.getValueState()){
            for (int slot = 3, xOffset = 0; slot >= 0; slot--) {
                ItemStack stack = mc.thePlayer.inventory.armorItemInSlot(slot);

                GuiIngame gi = new GuiIngame(mc);
                if (stack != null) {
                    mc.getRenderItem().renderItemIntoGUI(stack, RenderUtil.width() / 2 + 15 - xOffset,
                            RenderUtil.height() - 55
                                    - (((mc.thePlayer.isInsideOfMaterial(Material.water) && mc.thePlayer.getAir() > 0)
                                    || mc.thePlayer.isRidingHorse()) ? 10 : 0));
                    GL11.glDisable(GL11.GL_DEPTH_TEST);
                    GL11.glScalef(0.5F, 0.5F, 0.5F);
                    GL11.glScalef(2F, 2F, 2F);
                    GL11.glEnable(GL11.GL_DEPTH_TEST);
                    xOffset -= 18;
                }
            }
        }

        if (arraylist.getValueState()) {
            renderArray(sr);
        }

        if (noti.getValueState()) {
            if (mc.thePlayer.ticksExisted <= 10) {
                ClientUtil.clear();
            }
            ClientUtil.INSTANCE.drawNotifications();
        }

        if (logo.getValueState() && (!ModManager.getModule("TabGUI").getState() || ((TabGUI) ModManager.getModule("TabGUI")).screen == -1)) {
            Hanabi.INSTANCE.fontManager.icon100.drawString(HanabiFonts.ICON_HANABI_LOGO, 3F, 3F,
                    new Color(50, 50, 50, 200).getRGB());
        	Hanabi.INSTANCE.fontManager.icon100.drawString(HanabiFonts.ICON_HANABI_LOGO, 2, 2,
                    new Color(200, 200, 200, 20).getRGB());
        }

        if (posDisplay.getValueState()) {
            String pos = "";

            if (mc.thePlayer != null) {
                BlockPos blockPos = mc.thePlayer.getPosition();
                pos = "X:" + blockPos.getX() + "    Y:" + blockPos.getY() + "    Z:" + blockPos.getZ();

                Hanabi.INSTANCE.fontManager.wqy18.drawCenteredString(pos, sr.getScaledWidth() / 2, 50, new Color(255,255,255,180).getRGB());
            }
        }

        if (hotbar.getValueState() && this.mc.getRenderViewEntity() instanceof EntityPlayer
                && !mc.gameSettings.hideGUI) {
            UnicodeFontRenderer font = Hanabi.INSTANCE.fontManager.wqy18;

            RenderUtil.drawRect(0, height - 22, width, height, ClientUtil.reAlpha(Colors.BLACK.c, 0.5f));

            long ping = (mc.getCurrentServerData() != null) ? mc.getCurrentServerData().pingToServer : -1;

            int f1 = (ping <= 100 ? new Color(0x2f74fd).getRGB()
                    : ping <= 250 ? new Color(Colors.ORANGE.c).darker().getRGB() : new Color(Colors.RED.c).getRGB());

            RenderUtil.drawFilledCircle(10, height - 10.5f, 3, f1);

            font.drawString("PING:" + ((ping <= 0) ? "N/A" : ping) + "ms     FPS:" + Minecraft.getDebugFPS(), 16f,
                    height - 16f, -1);

            Date d = new Date();

            String date = f2.format(d);
            String time = f.format(d);

            String ez = "Hanabi Build " + Hanabi.CLIENT_VERSION + " - " + username;
            Hanabi.INSTANCE.fontManager.wqy18.drawString(ez, sr.getScaledWidth() - font.getStringWidth(ez) - 5,
                    sr.getScaledHeight() - 16, -1);

            if (mc.thePlayer.inventory.currentItem == 0) {
                RenderUtil.drawRect(width / 2 - 91, height - 2, (width / 2 + 90) - 20 * 8, height,
                        new Color(47, 116, 253,255).getRGB());
                RenderUtil.drawGradientSideways(width / 2 - 91, height - 20, (width / 2 + 90) - 20 * 8, height, new Color(47, 116, 253,180).getRGB(), new Color(47, 116, 253,0).getRGB());

            } else {
                RenderUtil.drawRect((width / 2) - 91 + mc.thePlayer.inventory.currentItem * 20, height - 2,
                        (width / 2) + 90 - 20 * (8 - mc.thePlayer.inventory.currentItem), height,
                        new Color(47, 116, 253,255).getRGB());
                RenderUtil.drawGradientSideways((width / 2) - 91 + mc.thePlayer.inventory.currentItem * 20, height - 20,
                        (width / 2) + 90 - 20 * (8 - mc.thePlayer.inventory.currentItem), height, new Color(47, 116, 253,180).getRGB(), new Color(47, 116, 253,0).getRGB());
            }

            RenderHelper.enableGUIStandardItemLighting();
            for (int j = 0; j < 9; ++j) {
                int k = (int) (width / 2 - 90 + j * 20 + 2);
                int l = (int) (height - 16 - 4);
                this.customRenderHotbarItem(j, k, l, event.partialTicks, mc.thePlayer);
            }

            GlStateManager.disableBlend();
            GlStateManager.color(1, 1, 1);

            RenderHelper.disableStandardItemLighting();

            GL11.glColor4f(1, 1, 1, 1);
            if (ModManager.getModule("StaffAnalyzer").isEnabled() && ModChecker.ui != null)
                ModChecker.ui.draw();
        }

    }

    public void renderCompass(ScaledResolution sr) {
        compasslol.draw(sr);
    }

    public static void drawRoundedRect2(float var0, float var1, float var2, float var3, int var4, int var5) {
        enableGL2D();
        GL11.glScalef(0.5F, 0.5F, 0.5F);
        drawVLine(var0 *= 2.0F, (var1 *= 2.0F) + 1.0F, (var3 *= 2.0F) - 2.0F, var4);
        drawVLine((var2 *= 2.0F) - 1.0F, var1 + 1.0F, var3 - 2.0F, var4);
        drawHLine(var0 + 2.0F, var2 - 3.0F, var1, var4);
        drawHLine(var0 + 2.0F, var2 - 3.0F, var3 - 1.0F, var4);
        drawHLine(var0 + 1.0F, var0 + 1.0F, var1 + 1.0F, var4);
        drawHLine(var2 - 2.0F, var2 - 2.0F, var1 + 1.0F, var4);
        drawHLine(var2 - 2.0F, var2 - 2.0F, var3 - 2.0F, var4);
        drawHLine(var0 + 1.0F, var0 + 1.0F, var3 - 2.0F, var4);
        RenderUtil.drawRect(var0 + 1.0F, var1 + 1.0F, var2 - 1.0F, var3 - 1.0F, var5);
        GL11.glScalef(2.0F, 2.0F, 2.0F);
        disableGL2D();
    }

    public static void drawHLine(float x, float y, float x1, int y1) {
        if (y < x) {
            float var5 = x;
            x = y;
            y = var5;
        }
        RenderUtil.drawRect(x, x1, y + 1.0F, x1 + 1.0F, y1);
    }

    public static void drawVLine(float x, float y, float x1, int y1) {
        if (x1 < y) {
            float var5 = y;
            y = x1;
            x1 = var5;
        }
        RenderUtil.drawRect(x, y + 1.0F, x + 1.0F, x1, y1);
    }

    public void customRenderHotbarItem(int index, int xPos, int yPos, float partialTicks, EntityPlayer p_175184_5_) {

        GlStateManager.disableBlend();

        ItemStack itemstack = p_175184_5_.inventory.mainInventory[index];

        if (itemstack != null) {
            float f = (float) itemstack.animationsToGo - partialTicks;

            if (f > 0.0F) {
                GlStateManager.pushMatrix();
                float f1 = 1.0F + f / 5.0F;
                GlStateManager.translate((float) (xPos + 8), (float) (yPos + 12), 0.0F);
                GlStateManager.scale(1.0F / f1, (f1 + 1.0F) / 2.0F, 1.0F);
                GlStateManager.translate((float) (-(xPos + 8)), (float) (-(yPos + 12)), 0.0F);
            }

            mc.getRenderItem().renderItemAndEffectIntoGUI(itemstack, xPos, yPos);

            if (f > 0.0F) {
                GlStateManager.popMatrix();
            }

            mc.getRenderItem().renderItemOverlays(mc.fontRendererObj, itemstack, xPos - 1, yPos);
        }
    }

    private void renderArray(ScaledResolution sr) {
        ArrayList<Mod> sorted = new ArrayList<Mod>();
        UnicodeFontRenderer font = Hanabi.INSTANCE.fontManager.comfortaa17;
        int y = 1;
        String name;
        for (Mod m : ModManager.getModules()) {
            if ((!m.isEnabled() && m.wasArrayRemoved() && m.getAnimx() == 0) || m.isHidden() || m.getCategory() == Category.RENDER)
                continue;
            sorted.add(m);
        }
        sorted.sort((o1,
                     o2) -> font
                .getStringWidth(o2.getDisplayName() == null ? o2.getName()
                        : String.format("%s %s", o2.getName(), o2.getDisplayName()))
                - font.getStringWidth(o1.getDisplayName() == null ? o1.getName()
                : String.format("%s %s", o1.getName(), o1.getDisplayName())));
        for (Mod m : sorted) {
            int nextIndex = sorted.indexOf(m) + 1;
            name = m.getDisplayName() == null ? m.getName() : String.format("%s %s", m.getName(), m.getDisplayName());
            Mod nextModule = null;
            if (sorted.size() > nextIndex) {
                nextModule = this.getNextEnabledModule(sorted, nextIndex);
            }

            if (m.isEnabled()) {
                m.setArrayRemoved(false);
                if (mc.thePlayer.ticksExisted >= 30) {
                    m.setAnimx(Math.min(m.getAnimx() + font.getStringWidth(name) / 12, font.getStringWidth(name)));
                } else {
                    m.setAnimx(font.getStringWidth(name));
                }
            } else {
                if (m.getAnimx() <= 0) {
                    m.setArrayRemoved(true);
                } else {
                    if (mc.thePlayer.ticksExisted >= 30) {
                        m.setAnimx(Math.max(m.getAnimx() - font.getStringWidth(name) / 12, 0));
                    } else {
                        m.setAnimx(0);
                    }
                }
            }

            int color;
            if (arraylistfade.getValueState()) {
                color = PaletteUtil
                        .fade(new Color(200, 200, 200, 200),
                                100, sorted.indexOf(nextModule) * 2 + 50)
                        .getRGB();
            } else {
                color = new Color(200, 200, 200).getRGB();
            }


            float x = RenderUtil.width() - m.getAnimx();
            RenderUtil.drawRect(x - 7, y - 1, x - 6, y + 10, color);
            if(arraylistoutline.getValueState()){
                if (nextModule != null) {
                    if (this.getNextEnabledModule(sorted, nextIndex).getDisplayName() != null) {
                        RenderUtil.drawRect(x - 7, y + 10, RenderUtil.width()
                                - font.getStringWidth(this.getNextEnabledModule(sorted, nextIndex).getName()
                                + " " + this.getNextEnabledModule(sorted, nextIndex).getDisplayName())
                                - 6, y + 11, color);
                    } else {
                        RenderUtil.drawRect(x - 7, y + 10,
                                RenderUtil.width() - font.getStringWidth(
                                        this.getNextEnabledModule(sorted, nextIndex).getName()) - 6,
                                y + 11, color);
                    }
                } else {
                    RenderUtil.drawRect(x - 7, y + 10, RenderUtil.width(), y + 11, color);
                }
            }
            RenderUtil.drawRect(x - 6, y - 1, RenderUtil.width(), y + 10, new Color(0, 0, 0, bgalpha.getValue().intValue()).getRGB());
            font.drawStringWithShadow(m.getName(), x - 3.0f, y - .5F,color);
            if(m.getDisplayName() != null)
                font.drawStringWithShadow(m.getDisplayName(), (float) (x - 3.0 + font.getStringWidth(m.getName() + " ")), y + 1, new Color(159, 159, 159).getRGB());

            y += 11;
        }


//        for (Mod module : mods) {
//            module.onRenderArray();
//            if (!module.isEnabled() && module.posX == 0)
//                continue;
////            if (module.getName().contains("TargetStrafe")) //涓嶆覆鏌撴覆鏌撶被
////                continue;
//            if (module.getCategory() == Category.RENDER)
//                continue;
//            // Module 淇℃伅
//            String modName = module.getName();
//            String displayName = module.getDisplayName();
//            float modwidth = module.posX;
//
//            module.lastY = module.posY;
//            module.posY = nextY;
//
//            // 鐢昏儗鏅�
//            RenderUtil.drawRect(sr.getScaledWidth() - modwidth - 7f, nextY + module.posYRend - 3.5f,
//                    sr.getScaledWidth(), nextY + module.posYRend + 10.5f, ClientUtil.reAlpha(Colors.BLACK.c, 0.55f));
//
//            RenderUtil.drawRect((float) (sr.getScaledWidth() - modwidth) - 7, nextY + module.posYRend - 3.5f,
//                    (float) (sr.getScaledWidth() - modwidth) - 6, nextY + module.posYRend + 10.5f,
//                    new Color(47, 116, 253).getRGB());
//            // 鐢诲瓧浣�
//            font.drawString(modName, sr.getScaledWidth() - modwidth - 2, nextY + module.posYRend - 1.5f,
//                    new Color(47, 116, 253).getRGB());
//            if (displayName != null)
//                font.drawString(displayName, sr.getScaledWidth() - modwidth + font.getStringWidth(modName),
//                        nextY + module.posYRend - 1.5f, new Color(159, 159, 159).getRGB());
//
//            nextY += 14;
//        }

    }

    private Mod getNextEnabledModule(List<Mod> modules, int startingIndex) {
        int modulesSize = modules.size();
        for (int i = startingIndex; i < modulesSize; ++i) {
            Mod module = modules.get(i);
            if (!module.isEnabled())
                continue;
            return module;
        }
        return null;
    }

    Map<Potion, Double> timerMap = new HashMap<Potion, Double>();

    private int x;

    public void renderPotionStatus(int width, int height) {
        x = 0;

        for (PotionEffect effect : (Collection<PotionEffect>) this.mc.thePlayer.getActivePotionEffects()) {
            Potion potion = Potion.potionTypes[effect.getPotionID()];
            String PType = I18n.format(potion.getName());
            int minutes = -1;
            int seconds = -2;

            try {
                minutes = Integer.parseInt(potion.getDurationString(effect).split(":")[0]);
                seconds = Integer.parseInt(potion.getDurationString(effect).split(":")[1]);
            } catch (Exception ex) {
                minutes = 0;
                seconds = 0;
            }

            double total = (minutes * 60) + seconds;

            if (!timerMap.containsKey(potion)) {
                timerMap.put(potion, total);
            }

            if (timerMap.get(potion) == 0 || total > timerMap.get(potion)) {
                timerMap.replace(potion, total);
            }

            switch (effect.getAmplifier()) {
                case 1:
                    PType = PType + " II";
                    break;
                case 2:
                    PType = PType + " III";
                    break;
                case 3:
                    PType = PType + " IV";
                    break;
                default:
                    break;
            }

            int color = Colors.WHITE.c;

            if (effect.getDuration() < 600 && effect.getDuration() > 300) {
                color = Colors.YELLOW.c;
            } else if (effect.getDuration() < 300) {
                color = Colors.RED.c;
            } else if (effect.getDuration() > 600) {
                color = Colors.WHITE.c;
            }

            int x1 = (int) ((width - 6) * 1.33f);
            int y1 = (int) ((height - 52 - this.mc.fontRendererObj.FONT_HEIGHT + x + 5) * 1.33F);

            RenderUtil.drawRect(width - 120, height - 60 + x, width - 10, height - 30 + x,
                    ClientUtil.INSTANCE.reAlpha(Colors.BLACK.c, 0.41f));

            if (potion.hasStatusIcon()) {
                GlStateManager.pushMatrix();

                GL11.glDisable(GL11.GL_DEPTH_TEST);
                GL11.glEnable(GL11.GL_BLEND);
                GL11.glDepthMask(false);
                OpenGlHelper.glBlendFunc(770, 771, 1, 0);
                GL11.glColor4f(1, 1, 1, 1);
                int index = potion.getStatusIconIndex();
                ResourceLocation location = new ResourceLocation("textures/gui/container/inventory.png");
                mc.getTextureManager().bindTexture(location);
                GlStateManager.scale(0.75, 0.75, 0.75);
                mc.ingameGUI.drawTexturedModalRect(x1 - 138, y1 + 8, 0 + index % 8 * 18, 198 + index / 8 * 18, 18, 18);

                GL11.glDepthMask(true);
                GL11.glDisable(GL11.GL_BLEND);
                GL11.glEnable(GL11.GL_DEPTH_TEST);
                GlStateManager.popMatrix();
            }

            int y = (height - this.mc.fontRendererObj.FONT_HEIGHT + x) - 38;
            UnicodeFontRenderer font = Hanabi.INSTANCE.fontManager.wqy18;
            font.drawString(PType.replaceAll("\247.", ""), (float) width - 91f,
                    y - this.mc.fontRendererObj.FONT_HEIGHT + 1, new Color(47, 116, 253).getRGB());

            Hanabi.INSTANCE.fontManager.comfortaa16.drawString(Potion.getDurationString(effect).replaceAll("\247.", ""),
                    width - 91f, y + 4, ClientUtil.reAlpha(-1, 0.8f));

            x -= 35;

        }
    }
}
