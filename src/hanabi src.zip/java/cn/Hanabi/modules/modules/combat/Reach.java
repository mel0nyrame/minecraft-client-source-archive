package cn.Hanabi.modules.modules.combat;

import java.util.Random;

import com.darkmagician6.eventapi.EventTarget;

import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;

public class Reach extends Mod {
	public long lastAttack = 0L;
	public TimeHelper timer = new TimeHelper();
	public static Value<Double> reach = new Value<Double>("Reach_Reach", 3.0d, 3.0d, 6.0d, 0.1d);
	public Value<Boolean> combo = new Value<Boolean>("Reach_ComboMode", false);
	public Random rand = new Random();
	public double currentRange = 3.0D;

	public Reach() {
		super("Reach", Category.COMBAT);
	}

	@EventTarget
	public void onUpdate(EventUpdate e) {
		this.setDisplayName("Range:" + reach.getValueState());
	}

	public static double getReach() {
		return ModManager.getModule("Reach").getState() ? reach.getValueState().floatValue() : 3.0f;

	}
}
