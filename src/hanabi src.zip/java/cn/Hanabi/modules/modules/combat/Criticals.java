package cn.Hanabi.modules.modules.combat;

import cn.Hanabi.events.*;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.movement.Speed.Speed;
import cn.Hanabi.utils.Entity.MoveUtils;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.MathUtils;
import cn.Hanabi.utils.Misc.BlockUtils;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import com.darkmagician6.eventapi.types.EventType;
import io.netty.util.internal.ThreadLocalRandom;
import me.tojatta.api.utilities.angle.AngleUtility;
import net.minecraft.block.BlockAir;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.item.EnumAction;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;

import java.util.Random;

public class Criticals extends Mod {
    private static final double[] offsetArray = {};
    public static boolean isReadyToCritical = false;
    public static Value<String> modes = new Value<String>("Criticals", "Mode", 0);
    public static Value<Double> hurttime = new Value<Double>("Criticals_HurtTime", 15d, 1d, 20d, 1d);
    public static Value<Double> delay = new Value<Double>("Criticals_Delay", 100d, 50d, 500d, 10d);

    public static Random random = new Random();
    public static Value<Boolean> rand = new Value<Boolean>("Criticals_Random", false);
    public static Value<Boolean> speed = new Value<Boolean>("Criticals_Speed", true);

    static double skidsense;
    int onGroundState;
    static TimeHelper stepTimer = new TimeHelper();
    static TimeHelper timer = new TimeHelper();
    private float FallStack;

    public Criticals() {
        super("Criticals", Category.COMBAT);
        modes.addValue("Packet");
        modes.addValue("Ground");
        modes.addValue("HEdit");
        modes.addValue("TelePort");

    }

    public static double getRandomInRange(double min, double max) {
        Random random = new Random();
        double range = max - min;
        double scaled = random.nextDouble() * range;
        if (scaled > max) {
            scaled = max;
        }
        double shifted = scaled + min;

        if (shifted > max) {
            shifted = max;
        }
        return shifted;
    }


    public static boolean isEating() {
        return mc.thePlayer.isUsingItem() && mc.thePlayer.getItemInUse().getItem()
                .getItemUseAction(mc.thePlayer.getItemInUse()) == EnumAction.EAT;
    }


    public static void doCrit() {
        if (ModManager.getModule(Criticals.class).isEnabled()) {
            if (stepTimer.isDelayComplete(50)) {
                isReadyToCritical = !isReadyToCritical && (KillAura.target.hurtResistantTime <= Criticals.hurttime.getValue()) && BlockUtils.isReallyOnGround() && (speed.getValueState() || !ModManager.getModule(Speed.class).isEnabled()) && !ModManager.getModule("Fly").isEnabled() && !ModManager.getModule("Scaffold").isEnabled();
            } else {
                isReadyToCritical = false;
            }
        }
        double[] offsets = Offset();
        if (isReadyToCritical) {
            EntityPlayerSP p = mc.thePlayer;

            for (double offset : offsets) {
                (mc.thePlayer.sendQueue.getNetworkManager()).sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(p.posX, p.posY + (offset * (rand.getValueState() ? 1 + KillAura.getRandomDoubleInRange(-10E-3, 10E-3) : 1)), p.posZ, false));
            }
            double random = MathUtils.getRandom() / 1000000;
            double val = 0.06 + random;

            if (modes.isCurrentMode("TelePort")) {
                if (mc.thePlayer.onGround) {
                    mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + val, mc.thePlayer.posZ);
                    mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.012511D, mc.thePlayer.posZ);
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + val, mc.thePlayer.posZ, false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.012511D, mc.thePlayer.posZ, false));
                    mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.002511D, mc.thePlayer.posZ);
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + val, mc.thePlayer.posZ, false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.002511D, mc.thePlayer.posZ, false));

                }
            }
            PlayerUtil.tellPlayer("Crit: " + randomNumber(-9999, 9999));
        }

    }


    private static int randomNumber(int max, int min) {
        return (int) (Math.random() * (double) (max - min)) + min;
    }


    public static double[] Offset() {
        double[] offsets = null;

        double random = MathUtils.getRandom() / 1000000;
        double val = 0.06 + random;
        double val2 = 0.0125D + random;

        if (modes.isCurrentMode("Packet")) {
            offsets = new double[]{val, 0.0125, val2, 0.0125, val2, 0.0015, 0.00012575};
        } else if (modes.isCurrentMode("HEdit")) {
            offsets = new double[]{val, 0.011511D, -0.0016, val, -0.016, random};
        } else if (modes.isCurrentMode("Ground")) {
            offsets = new double[]{val, -0.0016, val2, -0.0016, val2, -random, random};
        }

        return offsets;

    }


    @EventTarget
    public void onStep(EventStep e) {
        isReadyToCritical = false;
        if (e.getEventType() == EventType.POST) {
            stepTimer.reset();
        }
    }

    @EventTarget
    public void onChangeWorld(EventWorldChange e) {
        this.stepTimer.reset();
        skidsense = KillAura.getRandomDoubleInRange(0, 10E-8);
        PlayerUtil.debug("Random Reset : " + skidsense);
    }


    @EventTarget
    public void onPre(EventPreMotion e) {
        EntityPlayerSP player = mc.thePlayer;
    }


    @Override
    public void onEnable() {
    }

    private boolean isBlockUnder() {
        for (int i = (int) (mc.thePlayer.posY - 1.0); i > 0; --i) {
            BlockPos pos = new BlockPos(mc.thePlayer.posX, i, mc.thePlayer.posZ);
            if (mc.theWorld.getBlockState(pos).getBlock() instanceof BlockAir) continue;
            return true;
        }
        return false;
    }

    private static boolean canSetPositionUp(double offset) {
        return mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.getEntityBoundingBox().offset(0.0D, offset, 0.0D)).size() <= 0;
    }

    @EventTarget
    public void onUpdate(EventUpdate e) {
        this.setDisplayName(modes.getModeAt(modes.getCurrentMode()));
        if (MoveUtils.isOnGround(0.001)) {
            onGroundState++;
        } else if (!mc.thePlayer.onGround) {
            onGroundState = 0;
        }
    }


}
