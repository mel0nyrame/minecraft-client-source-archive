package cn.Hanabi.modules.modules.combat;

import cn.Hanabi.events.EventPacket;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.events.EventJump;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S27PacketExplosion;

public class Velocity extends Mod {
    public static Value<String> modes = new Value<String>("Velocity", "Mode", 0);
    private boolean jump;

    public Velocity() {
        super("Velocity", Category.COMBAT);
        modes.addValue("Cancel");
        modes.addValue("AAC");
        modes.addValue("AACZero");
        modes.addValue("AAC4.4.0");

        // TODO 自动生成的构造函数存根
    }

    @EventTarget
    private void onPacket(EventPacket e) {
        if (modes.isCurrentMode("Cancel")) {
            this.setDisplayName("Cancel");
            if (e.getPacket() instanceof S12PacketEntityVelocity || e.getPacket() instanceof S27PacketExplosion) {
                e.setCancelled(true);
            }
        }

    }

    @EventTarget
    public void onPre(EventPreMotion e) {
        if (modes.isCurrentMode("AACZero")) {
            this.setDisplayName("AACZero");
            if (mc.thePlayer.onGround || mc.thePlayer.fallDistance > 2F) {
                return;
            }
            mc.thePlayer.addVelocity(0.0, -1.0, 0.0);
            mc.thePlayer.onGround = true;
        }

        if (modes.isCurrentMode("AAC4.4.0")) {
            this.setDisplayName("AAC4.4.0");
            if (!mc.thePlayer.onGround) {
                if (mc.thePlayer.hurtResistantTime > 0) {
                    mc.thePlayer.motionX *= 0.6;
                    mc.thePlayer.motionZ *= 0.6;
                }
            }
        }

        if (modes.isCurrentMode("AAC")) {
            this.setDisplayName("AAC");
            if (jump) {
                if (mc.thePlayer.onGround)
                    jump = false;
            } else {
                if (mc.thePlayer.hurtTime > 0 && mc.thePlayer.motionX != 0.0 && mc.thePlayer.motionZ != 0.0)
                    mc.thePlayer.onGround = true;

                if (mc.thePlayer.hurtResistantTime > 0)
                    mc.thePlayer.motionY -= 0.0145;
            }

            if (mc.thePlayer.hurtResistantTime >= 19) {
                mc.thePlayer.motionX /= 2;
                mc.thePlayer.motionZ /= 2;
            }
        }

    }

    @EventTarget
    public void onJump(EventJump event) {
        jump = true;
    }

}
