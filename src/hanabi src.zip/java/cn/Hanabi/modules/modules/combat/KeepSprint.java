package cn.Hanabi.modules.modules.combat;

import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;

public class KeepSprint extends Mod {

	public KeepSprint() {
		super("KeepSprint", Category.COMBAT);
		// TODO 自动生成的构造函数存根
	}
}
