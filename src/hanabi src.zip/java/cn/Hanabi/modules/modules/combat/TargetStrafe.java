package cn.Hanabi.modules.modules.combat;

import cn.Hanabi.events.EventMove;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.events.EventRender;
import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.movement.Fly.Fly;
import cn.Hanabi.utils.Entity.MoveUtils;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.Rotation.RotationUtil;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.BlockAir;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

public class TargetStrafe extends Mod {

    // SkidSense
    public static boolean dire = true;
    public static Value<Double> range = new Value<Double>("TargetStrafe_StrafeRange", 2.0, 0.5, 4.5, 0.1);
    public static Value<Boolean> targetkey = new Value<Boolean>("TargetStrafe_KeyToggled", false);
    public static EntityLivingBase target;
    public static ArrayList<EntityLivingBase> targets = new ArrayList<EntityLivingBase>();
    private static int direction = -1;
    public static int strafe = -1;
    public TimeHelper timer = new TimeHelper();

    // AutoRound
    public final double Pi = 6.283185307179586;


    @Override
    public void onEnable() {
        super.onEnable();
        timer.reset();
        targets.clear();
        target = null;
        strafe = -1;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        targets.clear();
        target = null;
    }


    public TargetStrafe() {
        super("TargetStrafe", Category.COMBAT);
    }


    public static final void doStrafeAtSpeed(EventMove event, final double moveSpeed) {
        EntityLivingBase targ = KillAura.target;
        float[] rotations = RotationUtil.getRotation(targ);
        if (mc.thePlayer.getDistanceToEntity(KillAura.target) <= range.getValue()) {
            MoveUtils.setSpeed(event, moveSpeed, rotations[0], direction, 0);
        } else {
            MoveUtils.setSpeed(event, moveSpeed, rotations[0], direction, 1);
        }
    }

    public static final void doStrafeAtSpeed(EventPreMotion event, final double moveSpeed) {
        EntityLivingBase targ = KillAura.target;
        float[] rotations = RotationUtil.getRotation(targ);
        if (mc.thePlayer.getDistanceToEntity(KillAura.target) <= range.getValue()) {
            MoveUtils.setSpeed(event, moveSpeed, rotations[0], direction, 0);
        } else {
            MoveUtils.setSpeed(event, moveSpeed, rotations[0], direction, 1);
        }
    }

    private static boolean isBlockUnder() {
        for (int i = (int) (Minecraft.getMinecraft().thePlayer.posY - 1.0); i > 0; --i) {
            BlockPos pos = new BlockPos(Minecraft.getMinecraft().thePlayer.posX, i,
                    Minecraft.getMinecraft().thePlayer.posZ);
            if (Minecraft.getMinecraft().theWorld.getBlockState(pos).getBlock() instanceof BlockAir)
                continue;
            return true;
        }
        return false;
    }


    public static void setSpeed(EventMove moveEvent, double moveSpeed) {
        setSpeed(moveEvent, moveSpeed, mc.thePlayer.rotationYaw,
                mc.thePlayer.movementInput.moveStrafe, mc.thePlayer.movementInput.moveForward);
    }


    public static void setSpeed(EventMove moveEvent, double moveSpeed, float pseudoYaw, double pseudoStrafe,
                                double pseudoForward) {
        double forward = pseudoForward;
        double strafe = pseudoStrafe;
        float yaw = pseudoYaw;
        if (forward != 0.0) {
            if (strafe > 0.0) {
                yaw += (float) (forward > 0.0 ? -45 : 45);
            } else if (strafe < 0.0) {
                yaw += (float) (forward > 0.0 ? 45 : -45);
            }
            strafe = 0.0;
            if (forward > 0.0) {
                forward = 1.0;
            } else if (forward < 0.0) {
                forward = -1.0;
            }
        }
        if (strafe > 0.0) {
            strafe = 1.0;
        } else if (strafe < 0.0) {
            strafe = -1.0;
        }
        double mx = Math.cos(Math.toRadians(yaw + 90.0f));
        double mz = Math.sin(Math.toRadians(yaw + 90.0f));
        moveEvent.x = forward * moveSpeed * mx + strafe * moveSpeed * mz;
        moveEvent.z = forward * moveSpeed * mz - strafe * moveSpeed * mx;
    }

    public static float[] getRotations(double posX, double posY, double posZ) {
        EntityPlayerSP player = mc.thePlayer;
        double x = posX - player.posX;
        double y = posY - (player.posY + (double) player.getEyeHeight());
        double z = posZ - player.posZ;
        double dist = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float) (Math.atan2(z, x) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) (-(Math.atan2(y, dist) * 180.0 / Math.PI));
        return new float[]{yaw, pitch};
    }


    public static boolean canStrafe() {
        boolean press = !targetkey.getValue() || mc.gameSettings.keyBindJump.isKeyDown();

        return (KillAura.target != null) && press && (ModManager.getModule("KillAura").isEnabled() && (ModManager.getModule("Speed").isEnabled() || ModManager.getModule("Fly").isEnabled()));
    }

    @EventTarget
    private void onRender3D(final EventRender event) {
        if (canStrafe()) {
            EntityLivingBase target = KillAura.target;
            esp(target, event.getPartialTicks(), range.getValue());
        }
    }


    private void drawCircle(Entity entity, float partialTicks, double rad) {
        float points = 90F;
        GlStateManager.enableDepth();
        for (double il = 0; il < 4.9E-324; il += 4.9E-324) {
            GL11.glPushMatrix();
            GL11.glDisable(3553);
            GL11.glEnable(2848);
            GL11.glEnable(2881);
            GL11.glEnable(2832);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glHint(3154, 4354);
            GL11.glHint(3155, 4354);
            GL11.glHint(3153, 4354);
            GL11.glDisable(2929);
            GL11.glLineWidth(3.5f);
            GL11.glBegin(3);
            final double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - mc.getRenderManager().viewerPosX;
            final double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - mc.getRenderManager().viewerPosY;
            final double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - mc.getRenderManager().viewerPosZ;
            final double pix2 = 6.283185307179586;
            float speed = 5000f;
            float baseHue = System.currentTimeMillis() % (int) speed;
            while (baseHue > speed) {
                baseHue -= speed;
            }
            baseHue /= speed;
            for (int i = 0; i <= 90; ++i) {
                float max = ((float) i + (float) (il * 8)) / points;
                float hue = max + baseHue;
                while (hue > 1) {
                    hue -= 1;
                }
                final float r = 0.003921569f * new Color(Color.HSBtoRGB(hue, 0.75F, 1F)).getRed();
                final float g = 0.003921569f * new Color(Color.HSBtoRGB(hue, 0.75F, 1F)).getGreen();
                final float b = 0.003921569f * new Color(Color.HSBtoRGB(hue, 0.75F, 1F)).getBlue();
                GL11.glColor3f(r, g, b);

                if (range.getValue() < 0.8 && range.getValue() > 0) {
                    GL11.glVertex3d(x + rad * Math.cos(i * pix2 / 3), y + il, z + rad * Math.sin(i * pix2 / 3));
                }
                if (range.getValue() < 1.5 && range.getValue() > 0.7) {
                    GL11.glVertex3d(x + rad * Math.cos(i * pix2 / 4), y + il, z + rad * Math.sin(i * pix2 / 4));
                }
                if (range.getValue() < 2 && range.getValue() > 1.4) {
                    GL11.glVertex3d(x + rad * Math.cos(i * pix2 / 5), y + il, z + rad * Math.sin(i * pix2 / 5));
                }
                if (range.getValue() < 2.4 && range.getValue() > 1.9) {
                    GL11.glVertex3d(x + rad * Math.cos(i * pix2 / 6), y + il, z + rad * Math.sin(i * pix2 / 6));
                }
                if (range.getValue() < 2.7 && range.getValue() > 2.3) {
                    GL11.glVertex3d(x + rad * Math.cos(i * pix2 / 7), y + il, z + rad * Math.sin(i * pix2 / 7));
                }
                if (range.getValue() < 6.0 && range.getValue() > 2.6) {
                    GL11.glVertex3d(x + rad * Math.cos(i * pix2 / 8), y + il, z + rad * Math.sin(i * pix2 / 8));
                }
                if (range.getValue() < 7 && range.getValue() > 5.9) {
                    GL11.glVertex3d(x + rad * Math.cos(i * pix2 / 9), y + il, z + rad * Math.sin(i * pix2 / 9));
                }
                if (range.getValue() < 11 && range.getValue() > 6.9) {
                    GL11.glVertex3d(x + rad * Math.cos(i * pix2 / 10), y + il, z + rad * Math.sin(i * pix2 / 10));
                }
            }
            GL11.glEnd();
            GL11.glDepthMask(true);
            GL11.glEnable(2929);
            GL11.glDisable(2848);
            GL11.glDisable(2881);
            GL11.glEnable(2832);
            GL11.glEnable(3553);
            GL11.glPopMatrix();
            GlStateManager.color(255, 255, 255);
        }
    }

    public void esp(Entity entity, float partialTicks, double rad) {
        float points = 90F;
        GlStateManager.enableDepth();
        for (double il = 0; il < 4.9E-324; il += 4.9E-324) {
            GL11.glPushMatrix();
            GL11.glDisable(3553);
            GL11.glEnable(2848);
            GL11.glEnable(2881);
            GL11.glEnable(2832);
            GL11.glEnable(3042);
            GL11.glBlendFunc(770, 771);
            GL11.glHint(3154, 4354);
            GL11.glHint(3155, 4354);
            GL11.glHint(3153, 4354);
            GL11.glDisable(2929);
            GL11.glLineWidth(3.5f);
            GL11.glBegin(3);
            final double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - mc.getRenderManager().viewerPosX;
            final double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - mc.getRenderManager().viewerPosY;
            final double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - mc.getRenderManager().viewerPosZ;
            final double pix2 = 6.283185307179586;
            float speed = 5000f;
            float baseHue = System.currentTimeMillis() % (int) speed;
            while (baseHue > speed) {
                baseHue -= speed;
            }
            baseHue /= speed;
            for (int i = 0; i <= 90; ++i) {
                float max = ((float) i + (float) (il * 8)) / points;
                float hue = max + baseHue;
                while (hue > 1) {
                    hue -= 1;
                }
                final float r = 0.003921569f * new Color(Color.HSBtoRGB(hue, 0.75F, 1F)).getRed();
                final float g = 0.003921569f * new Color(Color.HSBtoRGB(hue, 0.75F, 1F)).getGreen();
                final float b = 0.003921569f * new Color(Color.HSBtoRGB(hue, 0.75F, 1F)).getBlue();
                int color = Color.WHITE.getRGB();
                GL11.glColor3f(r, g, b);
                GL11.glVertex3d(x + rad * Math.cos(i * pix2 / points), y + il, z + rad * Math.sin(i * pix2 / points));
            }
            GL11.glEnd();
            GL11.glDepthMask(true);
            GL11.glEnable(2929);
            GL11.glDisable(2848);
            GL11.glDisable(2881);
            GL11.glEnable(2832);
            GL11.glEnable(3553);
            GL11.glPopMatrix();
            GlStateManager.color(255, 255, 255);
        }


    }

    private void switchDirection() {
        if (direction == 1) {
            direction = -1;
        } else {
            direction = 1;
        }

    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.thePlayer.isCollidedHorizontally) {
            this.switchDirection();
        }

        if (mc.gameSettings.keyBindLeft.isPressed()) {
            direction = 1;
        }

        if (mc.gameSettings.keyBindRight.isPressed()) {
            direction = -1;
        }

        if (!isBlockUnder() && !ModManager.getModule("Fly").isEnabled()) {
            dire = !dire;
        }
        if (mc.thePlayer.isCollidedHorizontally) {
            dire = !dire;
        }
    }

    public static float radians(double x, double z) {
        final double diffX = x - Minecraft.getMinecraft().thePlayer.posX;
        final double diffZ = z - Minecraft.getMinecraft().thePlayer.posZ;
        return (float) (Math.atan2(diffZ, diffX) * 180.0 / Math.PI) - 90.0f;
    }


    public static void move(EventMove event, double speed, Entity entity) {
        double forward;
        double strafe = dire ? 1 : -1;
        if (Minecraft.getMinecraft().thePlayer.getDistanceToEntity(entity) > range.getValueState() + 0.5) {
            strafe = 0;
        }
        if (Minecraft.getMinecraft().thePlayer.getDistanceToEntity(entity) <= range.getValueState()) {
            forward = 0;
        } else {
            forward = 1;
            if (!isBlockUnder() && !ModManager.getModule(Fly.class).isEnabled())
                forward = -1;
        }

        float yaw = radians(entity.posX, entity.posZ);
        if (forward == 0 && strafe == 0 || !PlayerUtil.isMoving()) {
            if (event == null) {
                mc.thePlayer.motionZ = mc.thePlayer.motionX = 0;
            } else {
                event.setX(0.0D);
                event.setZ(0.0D);
            }
        } else {
            if (forward != 0) {
                if (strafe > 0) {
                    yaw += (forward > 0.0D ? -45 : 45);
                } else if (strafe < 0.0D) {
                    yaw += (forward > 0.0D ? 45 : -45);
                }
                strafe = 0.0D;
                if (forward > 0.0D) {
                    forward = 1;
                } else if (forward < 0.0D) {
                    forward = -1;
                }
            }
            final double cos = Math.cos(Math.toRadians(yaw + 90.0F));
            final double sin = Math.sin(Math.toRadians(yaw + 90.0F));

            double motionX = forward * speed * cos + strafe * speed * sin;
            if (event == null) {
                mc.thePlayer.motionX = motionX;
                mc.thePlayer.motionZ = forward * speed * sin - strafe * speed * cos;
            } else {
                event.setX(motionX);
                event.setZ(forward * speed * sin - strafe * speed * cos);
            }
        }
    }


}
