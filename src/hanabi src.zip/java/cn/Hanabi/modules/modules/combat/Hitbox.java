package cn.Hanabi.modules.modules.combat;

import com.darkmagician6.eventapi.EventTarget;

import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.value.Value;

public class Hitbox extends Mod {
	
	public static Value<Double> size = new Value<Double>("Hitbox_Size", 0.25D, 0.1D, 1.0D, 0.05D);

	public Hitbox() {
		super("Hitbox", Category.COMBAT);
	}
	
	@EventTarget
	public void onUpdate(EventUpdate e) {
		this.setDisplayName("Size:" + size.getValueState());
	}

	public static float getSize() {
		return (float) (ModManager.getModule("Hitbox").isEnabled() ? size.getValueState() : 0.1f);
	}
}
