package cn.Hanabi.modules.modules.combat;

import cn.Hanabi.Client;
import cn.Hanabi.Hanabi;
import cn.Hanabi.Wrapper;
import cn.Hanabi.events.*;
import cn.Hanabi.injection.interfaces.IEntityPlayer;
import cn.Hanabi.injection.interfaces.INetworkManager;
import cn.Hanabi.injection.interfaces.IRenderManager;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.render.ClickGUIModule;
import cn.Hanabi.modules.modules.world.AntiBot;
import cn.Hanabi.modules.modules.world.AutoL;
import cn.Hanabi.modules.modules.world.Teams;

import cn.Hanabi.utils.Location;
import cn.Hanabi.utils.MathUtils;
import cn.Hanabi.utils.Misc.*;
import cn.Hanabi.utils.Rotation.Angles;
import cn.Hanabi.utils.Rotation.AnglesUtils;
import cn.Hanabi.utils.Rotation.RotationUtil;
import cn.Hanabi.utils.TimeLocation.TimeHelper;

import cn.Hanabi.utils.Vec3d;
import cn.Hanabi.utils.fontmanager.UnicodeFontRenderer;
import cn.Hanabi.utils.vector.impl.Vector3;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import me.tojatta.api.utilities.angle.Angle;
import me.tojatta.api.utilities.angle.AngleUtility;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.monster.EntitySnowman;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityPig;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.INetHandler;
import net.minecraft.network.play.client.*;
import net.minecraft.util.*;
import org.apache.commons.lang3.RandomUtils;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;

import java.awt.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import static org.lwjgl.opengl.GL11.*;

public class KillAura extends Mod {
    // 瀹㈡埛绔缃�
    public static Value<Boolean> autoBlock = new Value<Boolean>("KillAura_AutoBlock", true);
    public static Value<Double> reach = new Value<Double>("KillAura_Range", 4.2, 3.0, 6.0, 0.1);
    public static Value<Double> switchsize = new Value<Double>("KillAura_MaxTargets", 1.0, 1.0, 5.0, 1.0);
    // Utils
    public static ArrayList<EntityLivingBase> targets = new ArrayList<EntityLivingBase>();
    public static ArrayList<EntityLivingBase> attacked = new ArrayList<EntityLivingBase>();
    // 瀹炰綋鍙橀噺
    public static EntityLivingBase target = null;

    public static Value<Double> cps = new Value<Double>("KillAura_CPS", 10.0, 1.0, 20.0, 1.0);
    public static Value<Double> blockReach = new Value<Double>("KillAura_BlockRange", 0.5, 0.0, 6.0, 0.1);
    public static Value<Boolean> attackPlayers = new Value<Boolean>("KillAura_Players", true);
    public static Value<Boolean> attackAnimals = new Value<Boolean>("KillAura_Animals", false);
    public static Value<Boolean> attackMobs = new Value<Boolean>("KillAura_Mobs", false);
    public static Value<Boolean> throughblock = new Value<Boolean>("KillAura_ThroughBlock", true);
    public static Value<Boolean> invisible = new Value<Boolean>("KillAura_Invisibles", false);
    public Value<Double> switchDelay = new Value<Double>("KillAura_SwitchDelay", 50d, 0d, 2000d, 10d);


    public static Value<Double> rotation2Value = new Value<Double>("KillAura_YawOffset", 200d, 0d, 400d, 10d);
    public static Value<Double> rotationValue = new Value<Double>("KillAura_PitchOffset", 200d, 0d, 400d, 10d);
    public static Value<Boolean> randoms2 = new Value<Boolean>("KillAura_PitchRandom", true);


    public Value<Boolean> autodisable = new Value<Boolean>("KillAura_AutoDisable", true);
    public Value<Boolean> targetHUD = new Value<Boolean>("KillAura_ShowTarget", true);
    public Value<Boolean> forcerise = new Value<Boolean>("KillAura_Slient", true);
    public Value<Boolean> esp = new Value<Boolean>("KillAura_ESP", true);
    public Value<Boolean> morekb = new Value<Boolean>("KillAura_MoreKB", false);

    public Value<Double> turn = new Value<Double>("KillAura_TurnHeadSpeed", 15.0, 5.0, 180.0, 1.0);

    public Value<String> rotation = new Value<String>("KillAura", "Rotations", 1);
    public Value<String> priority = new Value<String>("KillAura", "Priority", 1);
    public Value<String> EspMode = new Value<String>("KillAura", "EspMode", 0);
    public Value<String> hudMode = new Value<String>("KillAura", "HudMode", 0);
    public Value<String> FixMode = new Value<String>("KillAura", "FixMode", 0);

    public static Random random = new Random();
    // 寮�鍏�
    public static boolean isBlocking = false;
    public int index;
    // TimeHelper
    public TimeHelper attacktimer = new TimeHelper();
    private TimeHelper switchTimer = new TimeHelper();
    private TimeHelper critTimer = new TimeHelper();


    static double healthBarTarget = 0, healthBar = 0;
    float lastHealth = 0;
    double delay = 0;
    boolean step = false;
    // 杞ご
    private boolean AIMed;
    float[] lastRotations;
    float upAndDownPitch = 0;
    public static float[] rot;
    float rotationYawHead;
    public static Angles serverAngles = new Angles(0f, 0f);
    public static AnglesUtils aimUtil = new AnglesUtils(15, 30, 15, 30);

    public static void setAngles(EntityLivingBase targ) {
        if (targ != null) {
            Vector3D<Double> enemy = new Vector3D<>(targ.posX, targ.posY, targ.posZ);
            Vector3D<Double> me = new Vector3D<>(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
            Angles dstAngle = aimUtil.calculateAngle(enemy, me);
            Angles srcAngle = new Angles(serverAngles.getYaw(), serverAngles.getPitch());
            serverAngles = aimUtil.smoothAngle(srcAngle, dstAngle);
        }
    }


    public KillAura() {
        super("KillAura", Category.COMBAT);
        priority.addValue("Angle");
        priority.addValue("Range");
        priority.addValue("Armor");
        priority.addValue("Health");
        priority.addValue("Fov");

        hudMode.addValue("Simple");
        hudMode.addValue("Debug");
        hudMode.addValue("Fancy");
        hudMode.addValue("Skid");
        hudMode.addValue("Latest");


        rotation.addValue("Null");
        rotation.addValue("Null2");
        rotation.addValue("Legit");
        rotation.addValue("Smooth");
        rotation.addValue("Custom");
        rotation.addValue("Instant");
        rotation.addValue("New");


        EspMode.addValue("Box");
        EspMode.addValue("Circle");
        EspMode.addValue("New");


        FixMode.addValue("None");
        FixMode.addValue("Old");
        FixMode.addValue("New");


        attacked = new ArrayList<EntityLivingBase>();
    }

    public static double getRandomDoubleInRange(double minDouble, double maxDouble) {
        return minDouble >= maxDouble ? minDouble : new Random().nextDouble() * (maxDouble - minDouble) + minDouble;
    }


    public static float getDistanceBetweenAngles(float angle1, float angle2) {
        float angle = Math.abs(angle1 - angle2) % 360.0f;
        if (angle > 180.0f) {
            angle = 360.0f - angle;
        }
        return angle;
    }

    public static long randomClickDelay(final double minCPS, final double maxCPS) {
        return (long) ((Math.random() * (1000 / minCPS - 1000 / maxCPS + 1)) + 1000 / maxCPS);
    }


    private static boolean isValidEntity(Entity entity) {
        if (entity instanceof EntityLivingBase) {
            if (entity.isDead || ((EntityLivingBase) entity).getHealth() <= 0f) {
                if (ModManager.getModule("AutoL").isEnabled() && attacked.contains(entity)) {
                    attacked.remove(entity);
                    if (AutoL.wdr.getValueState() && !AutoL.wdred.contains(target.getName())) {
                        AutoL.wdred.add(target.getName());
                        mc.thePlayer.sendChatMessage("/wdr " + target.getName() + " ka fly reach nokb jesus ac");
                    }
                    mc.thePlayer.sendChatMessage(entity.getName() + " " + AbuseUtil.getAbuseGlobal());

                }

                return false;
            }

            if (mc.thePlayer.getDistanceToEntity(entity) < (reach.getValueState() + blockReach.getValueState())) {
                if (entity != mc.thePlayer && !mc.thePlayer.isDead
                        && !(entity instanceof EntityArmorStand || entity instanceof EntitySnowman)) {

                    if (entity instanceof EntityPlayer && attackPlayers.getValueState()) {

                        if (!mc.thePlayer.canEntityBeSeen(entity) && !throughblock.getValueState())
                            return false;

                        if (entity.isInvisible() && !invisible.getValueState())
                            return false;

                        return !AntiBot.isBot(entity) && !Teams.isOnSameTeam(entity);
                    }

                    if (entity instanceof EntityMob && attackMobs.getValueState()) {
                        return !AntiBot.isBot(entity);
                    }

                    if ((entity instanceof EntityAnimal || entity instanceof EntityVillager)
                            && attackAnimals.getValueState()) {
                        return !AntiBot.isBot(entity);
                    }
                }
            }
        }
        return false;
    }


    @EventTarget
    public void onReload(EventWorldChange e) {
        if (autodisable.getValueState()) {
            this.set(false);
        }
    }

    public DecimalFormat format = new DecimalFormat("0.0");
    public EntityLivingBase lastEnt;
    public float damageDelt = 0;
    public float lastPlayerHealth = -1;
    public float damageDeltToPlayer = 0;

    public static int getHealthColor(final EntityLivingBase player) {
        final float f = player.getHealth();
        final float f2 = player.getMaxHealth();
        final float f3 = Math.max(0.0f, Math.min(f, f2) / f2);
        return Color.HSBtoRGB(f3 / 3.0f, 1.0f, 0.75f) | 0xFF000000;
    }

    @EventTarget
    public void targetHud(EventRender2D event) {
        if (targetHUD.getValueState()) {
            ScaledResolution sr = new ScaledResolution(mc);
            if (Client.onDebug) {
                FontRenderer fr = Hanabi.INSTANCE.fontManager.comfortaa18;
                float scaledWidth = sr.getScaledWidth();
                float scaledHeight = sr.getScaledHeight();
                fr.drawString("Yaw: " + target.rotationYaw + "Pitch: " + target.rotationPitch, (int) scaledWidth / 2 - 196, (int) scaledHeight / 2 - +2, Color.lightGray.getRGB());
                fr.drawString("BlockType: " + (mc.thePlayer.ticksExisted % 12 == 0 ? "Pre" : "Post"), (int) scaledWidth / 2 - 196, (int) scaledHeight / 2 - 12, Color.lightGray.getRGB());
                fr.drawString("BlockMode: " + (isBlocking ? "Blocked" : "UnBlock"), (int) scaledWidth / 2 - 196, (int) scaledHeight / 2 - 20, Color.lightGray.getRGB());
            }
            if (this.hudMode.isCurrentMode("Simple")) {
                if (target != null) {
                    GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                    UnicodeFontRenderer font = Hanabi.INSTANCE.fontManager.wqy18;
                    font.drawStringWithShadow(target.getName(),
                            sr.getScaledWidth() / 2f - font.getStringWidth(target.getName()) / 2f,
                            sr.getScaledHeight() / 2f - 33, 16777215);
                    RenderHelper.enableGUIStandardItemLighting();
                    mc.getTextureManager().bindTexture(new ResourceLocation("textures/gui/icons.png"));

                    GL11.glDisable(GL11.GL_DEPTH_TEST);
                    GL11.glEnable(GL11.GL_BLEND);
                    GL11.glDepthMask(false);
                    OpenGlHelper.glBlendFunc(770, 771, 1, 0);

                    int i = 0;
                    while (i < target.getMaxHealth() / 2.0f) {
                        mc.ingameGUI.drawTexturedModalRect(
                                (sr.getScaledWidth() / 2) - target.getMaxHealth() / 2.0f * 10.0f / 2.0f + (i * 10),
                                (sr.getScaledHeight() / 2 - 20), 16, 0, 9, 9);
                        ++i;
                    }
                    i = 0;
                    while (i < target.getHealth() / 2.0f) {
                        mc.ingameGUI.drawTexturedModalRect(
                                (sr.getScaledWidth() / 2) - target.getMaxHealth() / 2.0f * 10.0f / 2.0f + (i * 10),
                                (sr.getScaledHeight() / 2 - 20), 52, 0, 9, 9);
                        ++i;
                    }

                    GL11.glDepthMask(true);
                    GL11.glDisable(GL11.GL_BLEND);
                    GL11.glEnable(GL11.GL_DEPTH_TEST);

                    GlStateManager.disableBlend();
                    GlStateManager.color(1, 1, 1);
                    RenderHelper.disableStandardItemLighting();
                }
            }
            if (hudMode.isCurrentMode("Debug")) {

                UnicodeFontRenderer font = Hanabi.INSTANCE.fontManager.wqy18;
                UnicodeFontRenderer font1 = Hanabi.INSTANCE.fontManager.wqy16;

                if (target != null) {
                    int width = (sr.getScaledWidth() / 2) + 100;
                    int height = sr.getScaledHeight() / 2;

                    EntityLivingBase player = target;
                    if (ClickGUIModule.theme.isCurrentMode("Light")) {
                        Gui.drawRect(width - 70, height + 30, width + 80, height + 105, new Color(255, 255, 255, 100).getRGB());

                    } else {
                        Gui.drawRect(width - 70, height + 30, width + 80, height + 105, new Color(0, 0, 0, 140).getRGB());
                    }
                    font.drawString(player.getName() + "             " + (Criticals.isReadyToCritical ? "Critical " : " "), width - 65, height + 35, 0xFFFFFF);
                    font1.drawString(player.onGround ? "鍦ㄥ湴闈�" : "涓嶅湪鍦伴潰", width - 65, height + 50, 0xFFFFFF);
                    font1.drawString("鐢熷懡鍊�: " + player.getHealth(), width - 65 + font1.getStringWidth("off Ground") + 13, height + 50, 0xFFFFFF);
                    font1.drawString("璺濈: " + mc.thePlayer.getDistanceToEntity(player), width - 65, height + 60, -1);
                    font1.drawString("鎽旇惤璺濈: " + player.fallDistance, width - 65, height + 70, -1);
                    font1.drawString("纭洿鏃堕棿: " + player.hurtTime, width - 15, height + 70, -1);

                    font.drawString(player.getHealth() > mc.thePlayer.getHealth() ? "浣犲彲鑳戒細杈撳摝" : "浣犲彲鑳借兘璧㈠惂", width - 65, height + 80, player.getHealth() > mc.thePlayer.getHealth() ? Color.RED.getRGB() : Color.GREEN.brighter().getRGB());
                    GL11.glPushMatrix();
                    GL11.glColor4f(1, 1, 1, 1);
                    GlStateManager.scale(1.0f, 1.0f, 1.0f);
                    mc.getRenderItem().renderItemAndEffectIntoGUI(player.getHeldItem(), width + 50, height + 80);
                    GL11.glPopMatrix();

                    float health = player.getHealth();
                    float healthPercentage = (health / player.getMaxHealth());
                    float targetHealthPercentage = 0;
                    if (healthPercentage != lastHealth) {
                        float diff = healthPercentage - this.lastHealth;
                        targetHealthPercentage = this.lastHealth;
                        this.lastHealth += diff / 8;
                    }
                    Color healthcolor = Color.WHITE;
                    if (healthPercentage * 100 > 75) {
                        healthcolor = Color.GREEN;
                    } else if (healthPercentage * 100 > 50 && healthPercentage * 100 < 75) {
                        healthcolor = Color.YELLOW;
                    } else if (healthPercentage * 100 < 50 && healthPercentage * 100 > 25) {
                        healthcolor = Color.ORANGE;
                    } else if (healthPercentage * 100 < 25) {
                        healthcolor = Color.RED;
                    }
                    Gui.drawRect(width - 70, height + 104, (int) (width - 70 + (149 * targetHealthPercentage)), height + 106, healthcolor.getRGB());
                    Gui.drawRect(width - 70, height + 104, (int) (width - 70 + (149 * healthPercentage)), height + 106, Color.GREEN.getRGB());
                    GL11.glColor4f(1, 1, 1, 1);
                    GuiInventory.drawEntityOnScreen(width + 60, height + 75, 20, Mouse.getX(), Mouse.getY(), player);
                }
            }

            if (hudMode.isCurrentMode("Ice")) {
                if (target != null) {
                    FontRenderer fr = mc.fontRendererObj;
                    DecimalFormat dec = new DecimalFormat("#");

                    healthBarTarget = sr.getScaledWidth() / 2 - 41 + (((140) / (target.getMaxHealth())) * (target.getHealth()));

                    // Lower is faster, higher is slower
                    double HealthBarSpeed = 5;

                    if (healthBar > healthBarTarget) {
                        healthBar = ((healthBar) - ((healthBar - healthBarTarget) / HealthBarSpeed));
                    } else if (healthBar < healthBarTarget) {
                        //healthBar = healthBarTarget;
                        healthBar = ((healthBar) + ((healthBarTarget - healthBar) / HealthBarSpeed));
                    }
                    //Command.sendPrivateChatMessage(healthBarTarget + " : " + healthBar);

                    int color = (target.getHealth() / target.getMaxHealth() > 0.66f) ? 0xff00ff00 : (target.getHealth() / target.getMaxHealth() > 0.33f) ? 0xffff9900 : 0xffff0000;

                    color = 0xff00ff00;
                    float[] hsb = Color.RGBtoHSB(((int) 255), ((int) 255), ((int) 255), null);
                    float hue = hsb[0];
                    float saturation = hsb[1];
                    color = Color.HSBtoRGB(hue, saturation, 1);

                    float hue1 = System.currentTimeMillis() % (int) ((100.5f - 50) * 1000) / (float) ((100.5f - 50) * 1000);
                    color = Color.HSBtoRGB(hue1, 0.65f, 1);

                    Gui.drawRect(sr.getScaledWidth() / 2 - 110, sr.getScaledHeight() / 2 + 100, sr.getScaledWidth() / 2 + 110, sr.getScaledHeight() / 2 + 170, 0xff36393f);
                    Gui.drawRect(sr.getScaledWidth() / 2 - 41, sr.getScaledHeight() / 2 + 100 + 54, sr.getScaledWidth() / 2 + 100, sr.getScaledHeight() / 2 + 96 + 45, 0xff202225);
                    Gui.drawRect(sr.getScaledWidth() / 2 - 41, sr.getScaledHeight() / 2 + 100 + 54, (int) healthBar, sr.getScaledHeight() / 2 + 96 + 45, color);
                    //Gui.drawRect(sr.getScaledWidth() / 2 - 41, sr.getScaledHeight() / 2 + 100 + 54, healthBarTarget, sr.getScaledHeight() / 2 + 96 + 45, color);

                    GlStateManager.color(1, 1, 1);
                    GuiInventory.drawEntityOnScreen(sr.getScaledWidth() / 2 - 75, sr.getScaledHeight() / 2 + 165, 25, 1f, 1f, target);
                    fr.drawString(target.getName(), sr.getScaledWidth() / 2 - 40, sr.getScaledHeight() / 2 + 110, -1);
                    fr.drawString("HP: ", sr.getScaledWidth() / 2 - 40, sr.getScaledHeight() / 2 + 125, -1);
                    fr.drawString("搂c鉂�: 搂f" + dec.format(target.getHealth()), sr.getScaledWidth() / 2 - 40 + fr.getStringWidth("HP: "), sr.getScaledHeight() / 2 + 125, color);
                }
            }
            if (hudMode.isCurrentMode("Fancy")) {
                FontRenderer fr = mc.fontRendererObj;
                DecimalFormat dec = new DecimalFormat("#");
                if (target != null) {

                    int color = (target.getHealth() / target.getMaxHealth() > 0.66f) ? 0xff00ff00 : (target.getHealth() / target.getMaxHealth() > 0.33f) ? 0xffff9900 : 0xffff0000;

                    Gui.drawRect(sr.getScaledWidth() / 2 - 110, sr.getScaledHeight() / 2 + 100, sr.getScaledWidth() / 2 + 110, sr.getScaledHeight() / 2 + 170, 0x50000000);
                    Gui.drawRect(sr.getScaledWidth() / 2 - 110, sr.getScaledHeight() / 2 + 100, (int) (sr.getScaledWidth() / 2 - 110 + (((220) / (target.getMaxHealth())) * (target.getHealth()))), sr.getScaledHeight() / 2 + 96, color);
                    GlStateManager.color(1, 1, 1);
                    GuiInventory.drawEntityOnScreen(sr.getScaledWidth() / 2 - 75, sr.getScaledHeight() / 2 + 165, 25, 1f, 1f, target);
                    fr.drawString(target.getName(), sr.getScaledWidth() / 2 - 40, sr.getScaledHeight() / 2 + 110, -1);
                    fr.drawString("HP: ", sr.getScaledWidth() / 2 - 40, sr.getScaledHeight() / 2 + 125, -1);
                    fr.drawString(dec.format(target.getHealth()) + " 搂f/ " + dec.format(target.getMaxHealth()), sr.getScaledWidth() / 2 - 40 + fr.getStringWidth("HP: "), sr.getScaledHeight() / 2 + 125, color);
                    fr.drawString(dec.format(target.getMaxHealth()) + "", sr.getScaledWidth() / 2 - 40 + fr.getStringWidth("HP: ") + fr.getStringWidth(dec.format(target.getHealth()) + " / "), sr.getScaledHeight() / 2 + 125, color);
                    RenderHelper.enableGUIStandardItemLighting();
                    mc.getRenderItem().renderItemAndEffectIntoGUI(target.getHeldItem(), sr.getScaledWidth() / 2 - 40, sr.getScaledHeight() / 2 + 143);
                    mc.getRenderItem().renderItemAndEffectIntoGUI(target.getCurrentArmor(3), sr.getScaledWidth() / 2 - 10, sr.getScaledHeight() / 2 + 143);
                    mc.getRenderItem().renderItemAndEffectIntoGUI(target.getCurrentArmor(2), sr.getScaledWidth() / 2 + 20, sr.getScaledHeight() / 2 + 143);
                    mc.getRenderItem().renderItemAndEffectIntoGUI(target.getCurrentArmor(1), sr.getScaledWidth() / 2 + 50, sr.getScaledHeight() / 2 + 143);
                    mc.getRenderItem().renderItemAndEffectIntoGUI(target.getCurrentArmor(0), sr.getScaledWidth() / 2 + 80, sr.getScaledHeight() / 2 + 143);

                }
            }


            if (hudMode.isCurrentMode("Skid")) {
                if (target != null) {
                    FontRenderer fr = mc.fontRendererObj;
                    DecimalFormat dec = new DecimalFormat("#");

                    healthBarTarget = sr.getScaledWidth() / 2 - 41 + (((140) / (target.getMaxHealth())) * (target.getHealth()));

                    // Lower is faster, higher is slower
                    double HealthBarSpeed = 5;

                    if (healthBar > healthBarTarget) {
                        healthBar = ((healthBar) - ((healthBar - healthBarTarget) / HealthBarSpeed));
                    } else if (healthBar < healthBarTarget) {
                        //healthBar = healthBarTarget;
                        healthBar = ((healthBar) + ((healthBarTarget - healthBar) / HealthBarSpeed));
                    }
                    //Command.sendPrivateChatMessage(healthBarTarget + " : " + healthBar);

                    int color = (target.getHealth() / target.getMaxHealth() > 0.66f) ? 0xff00ff00 : (target.getHealth() / target.getMaxHealth() > 0.33f) ? 0xffff9900 : 0xffff0000;

                    color = 0xff00ff00;
                    float[] hsb = Color.RGBtoHSB(((int) 255), ((int) 255), ((int) 255), null);
                    float hue = hsb[0];
                    float saturation = hsb[1];
                    color = Color.HSBtoRGB(hue, saturation, 1);

                    float hue1 = System.currentTimeMillis() % (int) ((100.5f - 50) * 1000) / (float) ((100.5f - 50) * 1000);
                    color = Color.HSBtoRGB(hue1, 0.65f, 1);

                    Gui.drawRect(sr.getScaledWidth() / 2 - 110, sr.getScaledHeight() / 2 + 100, sr.getScaledWidth() / 2 + 110, sr.getScaledHeight() / 2 + 170, 0xff36393f);
                    Gui.drawRect(sr.getScaledWidth() / 2 - 41, sr.getScaledHeight() / 2 + 100 + 54, sr.getScaledWidth() / 2 + 100, sr.getScaledHeight() / 2 + 96 + 45, 0xff202225);
                    Gui.drawRect(sr.getScaledWidth() / 2 - 41, sr.getScaledHeight() / 2 + 100 + 54, (int) healthBar, sr.getScaledHeight() / 2 + 96 + 45, color);
                    //Gui.drawRect(sr.getScaledWidth() / 2 - 41, sr.getScaledHeight() / 2 + 100 + 54, healthBarTarget, sr.getScaledHeight() / 2 + 96 + 45, color);

                    GlStateManager.color(1, 1, 1);
                    GuiInventory.drawEntityOnScreen(sr.getScaledWidth() / 2 - 75, sr.getScaledHeight() / 2 + 165, 25, 1f, 1f, target);
                    fr.drawString(target.getName(), sr.getScaledWidth() / 2 - 40, sr.getScaledHeight() / 2 + 110, -1);
                    fr.drawString("HP: ", sr.getScaledWidth() / 2 - 40, sr.getScaledHeight() / 2 + 125, -1);
                    fr.drawString("搂c鉂�: 搂f" + dec.format(target.getHealth()), sr.getScaledWidth() / 2 - 40 + fr.getStringWidth("HP: "), sr.getScaledHeight() / 2 + 125, color);
                }
            }
            if (hudMode.isCurrentMode("Latest")) {
                String name = StringUtils.stripControlCodes(target.getName());
                float startX = 20;
                float renderX = (sr.getScaledWidth() / 2) + startX;
                float renderY = (sr.getScaledHeight() / 2) + 10;
                int maxX2 = 30;
                float healthPercentage = target.getHealth() / target.getMaxHealth();
                if (target.getCurrentArmor(3) != null) {
                    maxX2 += 15;
                }
                if (target.getCurrentArmor(2) != null) {
                    maxX2 += 15;
                }
                if (target.getCurrentArmor(1) != null) {
                    maxX2 += 15;
                }
                if (target.getCurrentArmor(0) != null) {
                    maxX2 += 15;
                }
                if (target.getHeldItem() != null) {
                    maxX2 += 15;
                }

                float maxX = Math.max(maxX2, mc.fontRendererObj.getStringWidth(name) + 30);
                Gui.drawRect((int) renderX, (int) renderY, (int) (renderX + maxX), (int) renderY + 40, new Color(0, 0, 0, 0.6f).getRGB());
                Gui.drawRect((int) renderX, (int) renderY + 38, (int) (renderX + (maxX * healthPercentage)), (int) renderY + 40, getHealthColor(target));
                mc.fontRendererObj.drawStringWithShadow(name, renderX + 25, renderY + 7, -1);
                int xAdd = 0;
                double multiplier = 0.85;
                GlStateManager.pushMatrix();
                GlStateManager.scale(multiplier, multiplier, multiplier);
                if (target.getCurrentArmor(3) != null) {
                    mc.getRenderItem().renderItemAndEffectIntoGUI(target.getCurrentArmor(3), (int) ((((sr.getScaledWidth() / 2) + startX + 23) + xAdd) / multiplier), (int) (((sr.getScaledHeight() / 2) + 28) / multiplier));
                    xAdd += 15;
                }
                if (target.getCurrentArmor(2) != null) {
                    mc.getRenderItem().renderItemAndEffectIntoGUI(target.getCurrentArmor(2), (int) ((((sr.getScaledWidth() / 2) + startX + 23) + xAdd) / multiplier), (int) (((sr.getScaledHeight() / 2) + 28) / multiplier));
                    xAdd += 15;
                }
                if (target.getCurrentArmor(1) != null) {
                    mc.getRenderItem().renderItemAndEffectIntoGUI(target.getCurrentArmor(1), (int) ((((sr.getScaledWidth() / 2) + startX + 23) + xAdd) / multiplier), (int) (((sr.getScaledHeight() / 2) + 28) / multiplier));
                    xAdd += 15;
                }
                if (target.getCurrentArmor(0) != null) {
                    mc.getRenderItem().renderItemAndEffectIntoGUI(target.getCurrentArmor(0), (int) ((((sr.getScaledWidth() / 2) + startX + 23) + xAdd) / multiplier), (int) (((sr.getScaledHeight() / 2) + 28) / multiplier));
                    xAdd += 15;
                }
                if (target.getHeldItem() != null) {
                    mc.getRenderItem().renderItemAndEffectIntoGUI(target.getHeldItem(), (int) ((((sr.getScaledWidth() / 2) + startX + 23) + xAdd) / multiplier), (int) (((sr.getScaledHeight() / 2) + 28) / multiplier));
                }
                GlStateManager.popMatrix();
                GuiInventory.drawEntityOnScreen((int) renderX + 12, (int) renderY + 33, 15, target.rotationYaw, target.rotationPitch, target);
            }


        }

    }


    public static void drawESP(EntityLivingBase entity, int color, EventRender e) {
        double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double) e.getPartialTicks()
                - ((IRenderManager) mc.getRenderManager()).getRenderPosX();
        double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double) e.getPartialTicks()
                - ((IRenderManager) mc.getRenderManager()).getRenderPosY();
        double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double) e.getPartialTicks()
                - ((IRenderManager) mc.getRenderManager()).getRenderPosZ();
        float radius = 0.2f;
        int side = 6;
        GL11.glPushMatrix();
        GL11.glTranslated((double) x, (double) y + 2, (double) z);
        GL11.glRotatef((float) (-entity.width), (float) 0.0f, (float) 1.0f, (float) 0.0f);
        glColor(new Color(Math.max(new Color(color).getRed() - 75, 0), Math.max(new Color(color).getGreen() - 75, 0),
                Math.max(new Color(color).getBlue() - 75, 0), new Color(color).getAlpha()).getRGB());
        enableSmoothLine(1.0f);
        Cylinder c = new Cylinder();
        GL11.glRotatef((float) -90.0f, (float) 1.0f, (float) 0.0f, (float) 0.0f);

        c.setDrawStyle(100012);
        c.draw(0, radius, 0.3f, side, 1);
        glColor(color);
        c.setDrawStyle(100012);
        GL11.glTranslated(0, 0, 0.3);
        c.draw(radius, 0, 0.3f, side, 1);

        GL11.glRotatef((float) 90.0f, (float) 0.0f, (float) 0.0f, (float) 1.0f);

        disableSmoothLine();
        GL11.glPopMatrix();
    }


    public static void glColor(int hex) {
        float alpha = (float) (hex >> 24 & 255) / 255.0f;
        float red = (float) (hex >> 16 & 255) / 255.0f;
        float green = (float) (hex >> 8 & 255) / 255.0f;
        float blue = (float) (hex & 255) / 255.0f;
        GL11.glColor4f((float) red, (float) green, (float) blue, (float) (alpha == 0.0f ? 1.0f : alpha));
    }

    public static void enableSmoothLine(float width) {
        GL11.glDisable((int) 3008);
        GL11.glEnable((int) 3042);
        GL11.glBlendFunc((int) 770, (int) 771);
        GL11.glDisable((int) 3553);
        GL11.glDisable((int) 2929);
        GL11.glDepthMask((boolean) false);
        GL11.glEnable((int) 2884);
        GL11.glEnable((int) 2848);
        GL11.glHint((int) 3154, (int) 4354);
        GL11.glHint((int) 3155, (int) 4354);
        GL11.glLineWidth((float) width);
    }

    public static void disableSmoothLine() {
        GL11.glEnable((int) 3553);
        GL11.glEnable((int) 2929);
        GL11.glDisable((int) 3042);
        GL11.glEnable((int) 3008);
        GL11.glDepthMask((boolean) true);
        GL11.glCullFace((int) 1029);
        GL11.glDisable((int) 2848);
        GL11.glHint((int) 3154, (int) 4352);
        GL11.glHint((int) 3155, (int) 4352);
    }

    @EventTarget
    public void onStep(EventStep event) {
    }

    @EventTarget
    public void onRender(EventRender render) { // Copy
        if (target == null || !esp.getValueState()) {
            return;
        }

        if (EspMode.isCurrentMode("Box")) {
            for (EntityLivingBase entity : targets) {
                double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * Wrapper.getTimer().renderPartialTicks
                        - ((IRenderManager) mc.getRenderManager()).getRenderPosX();
                double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * Wrapper.getTimer().renderPartialTicks
                        - ((IRenderManager) mc.getRenderManager()).getRenderPosY();
                double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * Wrapper.getTimer().renderPartialTicks
                        - ((IRenderManager) mc.getRenderManager()).getRenderPosZ();
                double width = entity.getEntityBoundingBox().maxX - entity.getEntityBoundingBox().minX;
                double height = entity.getEntityBoundingBox().maxY - entity.getEntityBoundingBox().minY + 0.25;
                RenderUtil.drawEntityESP(x, y, z, width, height, (entity.hurtTime > 1) ? 1f : 0.0f,
                        (entity.hurtTime > 1) ? 0.0f : 1f, 0f, 0.2f, (entity.hurtTime > 1) ? 1f : 0f,
                        (entity.hurtTime > 1) ? 0f : 1f, 0.0f, 1f, 2f);
            }
        }

        if (EspMode.isCurrentMode("Circle")) {
            for (int i = 0; i < 5; i++) {
                drawCircle(target, render.getPartialTicks(), 0.8, delay / 100);
            }
        }


        if (EspMode.isCurrentMode("New")) {
            EntityLivingBase entity = target;
            mc.getRenderManager();
            double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double) Wrapper.getTimer().renderPartialTicks
                    - ((IRenderManager) mc.getRenderManager()).getRenderPosX();
            mc.getRenderManager();
            double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double) Wrapper.getTimer().renderPartialTicks
                    - ((IRenderManager) mc.getRenderManager()).getRenderPosY();
            mc.getRenderManager();
            double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double) Wrapper.getTimer().renderPartialTicks
                    - ((IRenderManager) mc.getRenderManager()).getRenderPosZ();
            drawESP(entity, entity.hurtTime >= 1 ? (new Color(255, 0, 0, 160).getRGB()) : (new Color(47, 116, 253, 255).getRGB()), render);

        }
        if (delay > 200) {
            step = false;
        }
        if (delay < 0) {
            step = true;
        }
        if (step) {
            delay += 3;
        } else {
            delay -= 3;
        }
    }

    private void drawCircle(Entity entity, float partialTicks, double rad, double height) {
        glPushMatrix();
        glDisable(GL_TEXTURE_2D);
        glDisable(GL_DEPTH_TEST);
        glDepthMask(false);
        glLineWidth(2.0f);
        glBegin(GL_LINE_STRIP);

        final double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - mc.getRenderManager().viewerPosX;
        final double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - mc.getRenderManager().viewerPosY;
        final double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - mc.getRenderManager().viewerPosZ;

        final float r = ((float) 1 / 255) * Color.WHITE.getRed();
        final float g = ((float) 1 / 255) * Color.WHITE.getGreen();
        final float b = ((float) 1 / 255) * Color.WHITE.getBlue();

        final double pix2 = Math.PI * 2.0D;

        for (int i = 0; i <= 90; ++i) {
            glVertex3d(x + rad * Math.cos(i * pix2 / 45), y + height, z + rad * Math.sin(i * pix2 / 45));
        }

        glEnd();
        glDepthMask(true);
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_TEXTURE_2D);
        glPopMatrix();
    }


    public float randomFloat(float min, float max) {
        return min + (this.random.nextFloat() * (max - min));
    }


    public float[] NormalRes(float[] rot) {
        float f = mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
        float f1 = f * f * f * 1.2F;
        return new float[]{rot[0] - (rot[0] % f1), rot[1] - (rot[1] % f1)};
    }


    public float[] PrefetFakeNormalRes(float[] rot) {
        float yaw = rot[0];
        float pitch = rot[1];
        float f = mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
        float pos = f * f * f * 8.0F;
        yaw += pos * 0.15F;
        pitch -= pos * 0.15F;
        return new float[]{yaw, pitch};
    }

    public float[] getRotations(Entity theEntity) {
        double xDistance = theEntity.posX - this.mc.thePlayer.posX;
        double zDistance = theEntity.posZ - this.mc.thePlayer.posZ;
        double yDistance = theEntity.posY + ((double) theEntity.getEyeHeight() - 0.1D) / 1.4D - this.mc.thePlayer.posY - (double) this.mc.thePlayer.getEyeHeight() / 1.4D;
        double angleHelper = (double) MathHelper.sqrt_double(xDistance * xDistance + zDistance * zDistance);
        float newYaw = (float) Math.toDegrees(-Math.atan(xDistance / zDistance));
        float newPitch = (float) (-Math.toDegrees(Math.atan(yDistance / angleHelper)));
        if (zDistance < 0.0D && xDistance < 0.0D) {
            newYaw = (float) (90.0D + Math.toDegrees(Math.atan(zDistance / xDistance)));
        } else if (zDistance < 0.0D && xDistance > 0.0D) {
            newYaw = (float) (-90.0D + Math.toDegrees(Math.atan(zDistance / xDistance)));
        }

        return new float[]{newYaw, newPitch};
    }


    public static float getAngleDifference(float a, float b) {
        float dist = (a - b + 360.0F) % 360.0F;
        if (dist > 180.0F) {
            dist = 360.0F - dist;
        }

        return Math.abs(dist);
    }

    public static float[] getAngles(Entity e) {
        return new float[]{RotationUtil.getYawChangeToEntity(e) + mc.thePlayer.rotationYaw, RotationUtil.getPitchChangeToEntity(e) + mc.thePlayer.rotationPitch};
    }


    /////Killaura Main Point
    @EventTarget
    public void onPre(EventPreMotion event) {
        rotationYawHead = mc.thePlayer.rotationYawHead;

        // 鍒濆鍖栧彉閲�
        if (!targets.isEmpty() && index >= targets.size())
            index = 0; // 瓒呰繃Switch闄愬埗

        for (EntityLivingBase ent : targets) { // 娣诲姞瀹炰綋
            if (isValidEntity(ent))
                continue;
            targets.remove(ent);
        }
        // Switch缁撴潫

        getTarget(event); // 鎷垮疄浣�

        if (targets.size() == 0) { // 瀹炰綋鏁伴噺涓�0鍋滄鏀诲嚮
            target = null;
        } else {
            target = targets.get(index);// 璁剧疆鏀诲嚮鐨凾arget
            if (mc.thePlayer.getDistanceToEntity(target) > reach.getValueState()) {
                target = targets.get(0);
            }
        }


        // Switch寮�濮�
        if (target != null) {
            setAngles(target);
            // Switch寮�濮�
            if (target.hurtTime == 10 && switchTimer.isDelayComplete(switchDelay.getValueState() * 1000)
                    && targets.size() > 1) {
                switchTimer.reset();
                ++index;
            }
            if (rotation.isCurrentMode("Null")) {
                lastRotations = AimUtil.getRotations(targets.get(index));
            } else if (rotation.isCurrentMode("Null2")) {
                lastRotations = new float[]{serverAngles.getYaw(), serverAngles.getPitch() + (mc.thePlayer.getDistanceToEntity(target)) * -0.15F};
            } else if (rotation.isCurrentMode("Smooth")) {
                float[] smoothRotations = AimUtil.faceEntitySmooth(lastRotations[0], lastRotations[1], getRotations(target)[0], getRotations(target)[1], 120, 60);
                lastRotations[0] = AimUtil.updateRotation(event.getYaw(), smoothRotations[0], 180);
                lastRotations[1] = smoothRotations[1];
            } else if (rotation.isCurrentMode("New")) {
                Vec3 playerVec = new Vec3(event.getX(), event.getY() + (double) mc.thePlayer.getEyeHeight(), event.getZ());
                Vec3 targetVec = target.getPositionVector();
                targetVec = targetVec.yCoord - 0.7 > event.getY() ? targetVec.addVector(0.0, (double) (target.getEyeHeight() / 2.0f), 0.0) : (targetVec.yCoord > event.getY() ? targetVec.addVector(0.0, (double) (target.getEyeHeight() / 1.5f), 0.0) : targetVec.addVector(0.0, (double) target.getEyeHeight(), 0.0));
                targetVec = targetVec.addVector(target.posX - target.lastTickPosX, 0.0, target.posZ - target.lastTickPosZ);
                lastRotations = RotationUtil.getNeededFacing((Vec3) targetVec, (Vec3) playerVec);
            } else if (rotation.isCurrentMode("Custom")) {
                lastRotations = RotationUtil.getNeededRotations(AimUtil.getCenter(targets.get(index).getEntityBoundingBox()));
            } else if (rotation.isCurrentMode("Legit")) {
                lastRotations = AimUtil.faceTarget(target, Math.max(10, this.getFoVDistance(event.getYaw(), target) * 0.8f), 20, false);
            } else if (rotation.isCurrentMode("Instant")) {
                lastRotations = AimUtil.faceEntity(targets.get(index));
            }

            float sens = getSensitivityMultiplier();
            float yaw = (float) (lastRotations[0] + KillAura.getRandomDoubleInRange(-0.55F, 0.55F));
            float pitch = (float) (lastRotations[1] + KillAura.getRandomDoubleInRange(-2.0F, 2.0F));
            float yawGCD = (Math.round(yaw / sens) * sens);
            float pitchGCD = (Math.round(pitch / sens) * sens);
            if (Math.abs(pitchGCD) > 90) {
                pitchGCD = 90;
            }
            if (Math.abs(pitchGCD) == Math.round(Math.abs(pitchGCD))) {
                pitchGCD += (Math.round(Math.random() * 2 / sens) * sens);
            }
            if (lastRotations[1] > 90) {
                lastRotations[1] = 90;
            } else if (lastRotations[1] < -90) {
                lastRotations[1] = -90;
            }
            float rotationSpeed = turn.getValue().floatValue();
            float rotationYaw = MathHelper.clamp_float((RotationUtil.getYawChangeGiven(targets.get(index).posX, targets.get(index).posZ, lastRotations[0])), -180.0f, 180.0f);
            rotationYaw = rotationYaw > rotationSpeed ? rotationSpeed : Math.max(rotationYaw, -rotationSpeed);

            if (lastRotations[1] < -90) {
                lastRotations[1] = -90;
            }


            if (FixMode.isCurrentMode("Old")) {
                lastRotations = NormalRes(new float[]{(float) ((lastRotations[0] += rotationYaw / 1.2f) + KillAura.getRandomDoubleInRange(-3, 3)), (float) (lastRotations[1] / 1.2f + KillAura.getRandomDoubleInRange(-5, 5))});
            } else if (FixMode.isCurrentMode("New")) {
                lastRotations = new float[]{yawGCD, pitchGCD};
            }

            if (!forcerise.getValueState()) {
                mc.thePlayer.rotationYaw = lastRotations[0];
                mc.thePlayer.rotationPitch = lastRotations[1];
            } else {
                event.setYaw(lastRotations[0]);
                event.setPitch(lastRotations[1]);
            }

            if (mc.gameSettings.thirdPersonView == 1) {
                mc.thePlayer.rotationYawHead = event.getYaw();
                mc.thePlayer.renderYawOffset = event.getYaw();
            }

            if (mc.thePlayer.isBlocking() || mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword && autoBlock.getValueState() && isBlocking) { // 鏍兼尅
                unBlock(!mc.thePlayer.isBlocking() && !autoBlock.getValueState() && mc.thePlayer.getItemInUseCount() > 0);
            }
        } else {
            targets.clear();
            lastRotations = new float[]{mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch};
            if (mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword
                    && autoBlock.getValueState() && isBlocking) {
                unBlock(true);
            }
        }
    }

    private float random(float min, float max) {
        return (float) ((double) min + (double) (max - min) * Math.random());
    }


    public float[] mouseFix(float yaw, float pitch) {
        float k = mc.gameSettings.mouseSensitivity * 0.6F + 0.2F;
        float k1 = k * k * k * 8.0F;
        yaw -= yaw % k1;
        pitch -= pitch % k1;
        return new float[]{yaw, pitch};
    }


    private float getFoVDistance(final float yaw, final Entity e) {
        return ((Math.abs(RotationUtil.getRotations((EntityLivingBase) e)[0] - yaw) % 360.0f > 180.0f) ? (360.0f - Math.abs(RotationUtil.getRotations((EntityLivingBase) e)[0] - yaw) % 360.0f) : (Math.abs(RotationUtil.getRotations((EntityLivingBase) e)[0] - yaw) % 360.0f));
    }

    private float[] getRotations(EntityLivingBase ent) {
        final double x = ent.posX - mc.thePlayer.posX;
        double y = ent.posY - mc.thePlayer.posY;
        final double z = ent.posZ - mc.thePlayer.posZ;
        y /= mc.thePlayer.getDistanceToEntity(ent);
        final float yaw = (float) (-(Math.atan2(x, z) * 57.29577951308232));
        final float pitch = (float) (-(Math.asin(y) * 57.29577951308232));
        return new float[]{yaw, pitch};
    }

    public static float getSensitivityMultiplier() {
        float f = Minecraft.getMinecraft().gameSettings.mouseSensitivity * 0.6F + 0.2F;
        return (f * f * f * 8.0F) * 0.15F;
    }

    private float[] smoothAngle(float[] dst, float[] src) {
        float[] smoothedAngle = new float[2];
        smoothedAngle[0] = (src[0] - dst[0]);
        smoothedAngle[1] = (src[1] - dst[1]);
        smoothedAngle = MathUtils.constrainAngle(smoothedAngle);
        smoothedAngle[0] = (src[0] - smoothedAngle[0] / 100 * randomFloat(8, 20));
        smoothedAngle[1] = (src[1] - smoothedAngle[1] / 100 * randomFloat(0, 8));
        return smoothedAngle;
    }


    public boolean canBlock() {
        return autoBlock.getValueState() && mc.thePlayer.inventory.getCurrentItem() != null
                && mc.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemSword;
    }


    private int randomNumber(int max, int min) {
        return (int) (Math.random() * (double) (max - min)) + min;
    }

    public boolean ShouldAttack() {
        int aps = cps.getValueState().intValue();
        return attacktimer.isDelayComplete(randomClickDelay(aps - 1, aps + 1));
    }


    @EventTarget
    public void onPost(EventPostMotion event) {

        if (target != null)
            doAttack(); // 鏀诲嚮
        // 寮�鏍兼尅
        if (target != null
                && (mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword
                && autoBlock.getValueState() || mc.thePlayer.isBlocking() && !isBlocking)) { // 鏍兼尅
            doBlock(true);
        }
    }


    private void doAttack() {
        // 绠桟PS - Delay
        if (ShouldAttack()) { // 鏀诲嚮Timer
            boolean isInRange = mc.thePlayer.getDistanceToEntity(target) <= reach.getValueState();

            if (isInRange) {
                attack(); // 鏀诲嚮浼犲弬miss
                attacktimer.reset();
            }
        }
    }

    private void attack() {
        EventManager.call(new EventAttack(target));
        if (mc.thePlayer.getFoodStats().getFoodLevel() > 6 && morekb.getValue()) {
            mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
        }

        //Critical
        if (critTimer.isDelayComplete(Criticals.delay.getValueState())) {
            Criticals.doCrit();
            critTimer.reset();
        }
        mc.thePlayer.swingItem();
        mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(target, C02PacketUseEntity.Action.ATTACK)); // 鏀诲嚮

        if (mc.thePlayer.getFoodStats().getFoodLevel() > 6 && morekb.getValue()) {
            mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING));
        }
        AutoSword.publicItemTimer.reset();
        if (!attacked.contains(target) && target instanceof EntityPlayer) {
            attacked.add(target);
        }

    }


    private void doBlock(boolean setItemUseInCount) {
        if (setItemUseInCount)
            ((IEntityPlayer) mc.thePlayer).setItemInUseCount(mc.thePlayer.getHeldItem().getMaxItemUseDuration());
        ((INetworkManager) mc.thePlayer.sendQueue.getNetworkManager()).sendPacketNoEvent(new C08PacketPlayerBlockPlacement(mc.thePlayer.getHeldItem()));
        // needUnBlock = true;
        isBlocking = true;
    }

    private void unBlock(boolean setItemUseInCount) {
        if (setItemUseInCount)
            ((IEntityPlayer) mc.thePlayer).setItemInUseCount(0);
        mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(-0.8, -1, -0.8), EnumFacing.DOWN));
        // needUnBlock = false;
        isBlocking = false;
    }

    @Override
    public void onEnable() {
        attacked = new ArrayList<EntityLivingBase>();
        healthBar = new ScaledResolution(mc).getScaledWidth() / 2 - 41;
        if (mc.thePlayer != null) {
            lastRotations = new float[]{mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch};
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        healthBar = new ScaledResolution(mc).getScaledWidth() / 2 - 41;
        if (isBlocking) { // 鏍兼尅
            unBlock(true);
        }
        targets.clear();
        target = null; // 娓呯┖鐩爣 (AutoBlock鍔ㄧ敾淇)
        super.onDisable();
    }


    private void getTarget(EventPreMotion event) {
        int maxSize = switchsize.getValueState().intValue(); // 鏈�澶у疄浣撴暟閲�

        if (maxSize > 1) {
            setDisplayName("Switch");
        } else {
            setDisplayName("Single");
        }

        for (Entity o3 : mc.theWorld.loadedEntityList) { // 閬嶅巻瀹炰綋
            EntityLivingBase curEnt;

            if (o3 instanceof EntityLivingBase && isValidEntity(curEnt = (EntityLivingBase) o3)
                    && !targets.contains(curEnt))
                targets.add(curEnt);

            if (targets.size() >= maxSize)
                break; // 瓒呰繃浜嗛檺鍒惰烦鍑�
        }

        // 鎺掑簭鐩爣瀹炰綋
        if (priority.isCurrentMode("Armor")) {
            targets.sort(Comparator.comparingInt((o) -> {
                return o instanceof EntityPlayer ? ((EntityPlayer) o).inventory.getTotalArmorValue()
                        : (int) o.getHealth();
            }));
        }

        if (priority.isCurrentMode("Range")) {
            targets.sort((o1, o2) -> (int) (o1.getDistanceToEntity(mc.thePlayer) - o2.getDistanceToEntity(mc.thePlayer)));
        }
        if (priority.isCurrentMode("Fov")) {
            targets.sort(Comparator.comparingDouble(o -> RotationUtil.getDistanceBetweenAngles(mc.thePlayer.rotationPitch,
                    RotationUtil.getRotationToEntity(o)[0])));
        }
        if (priority.isCurrentMode("Angle")) {
            targets.sort((o1, o2) -> {
                float[] rot1 = RotationUtil.getRotationToEntity(o1);
                float[] rot2 = RotationUtil.getRotationToEntity(o2);
                return (int) (mc.thePlayer.rotationYaw - rot1[0] - (mc.thePlayer.rotationYaw - rot2[0]));
            });
        }
        if (priority.isCurrentMode("Health")) {
            targets.sort((o1, o2) -> (int) (o1.getHealth() - o2.getHealth()));
        }

    }


    /////Killaura Utils (Rotation)

    double normalise(double value, double start, double end) {
        double width = end - start;   //
        double offsetValue = value - start;   // value relative to 0

        return (offsetValue - (Math.floor(offsetValue / width) * width)) + start;
    }

    private void drawFace(int x, int y, float u, float v, int uWidth, int vHeight, int width, int height,
                          float tileWidth, float tileHeight, AbstractClientPlayer target) {
        try {
            ResourceLocation skin = target.getLocationSkin();
            mc.getTextureManager().bindTexture(skin);
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glColor4f(1, 1, 1, 1);
            Gui.drawScaledCustomSizeModalRect(x, y, u, v, uWidth, vHeight, width, height, tileWidth, tileHeight);
            GL11.glDisable(GL11.GL_BLEND);
        } catch (Exception ignored) {
        }
    }


///rotaiton Class


    public static class AimUtil {

        public static float[] getRotate(Entity entity, float speed1, float speed2, float Cyaw, float Cpitch) {
            double x = entity.posX;
            double z = entity.posZ;
            double y;
            if (entity instanceof EntityLivingBase) {
                EntityLivingBase entitylivingbase = (EntityLivingBase) entity;
                y = entitylivingbase.posY + (double) entitylivingbase.getEyeHeight() - (mc.thePlayer.posY + (double) mc.thePlayer.getEyeHeight());
            } else {
                y = (entity.getEntityBoundingBox().minY + entity.getEntityBoundingBox().maxY) / 2.0D - (mc.thePlayer.posY + (double) mc.thePlayer.getEyeHeight());
            }

            double dist = Math.sqrt(x * x + z * z);
            float f0 = (float) (Math.atan2(z, x) * 180.0D / 3.141592653589793D) - 90.0F;
            float f1 = (float) (-(Math.atan2(y, dist) * 180.0D / 3.141592653589793D));
            float yaw = set(Cpitch, f1, speed2);
            float pitch = set(Cyaw, f0, speed1);
            return new float[]{yaw, pitch};
        }

        public static float set(float f1, float f2, float f3) {
            float f = MathHelper.wrapAngleTo180_float(f2 - f1);
            if (f > f3) {
                f = f3;
            }
            if (f < -f3) {
                f = -f3;
            }
            return f1 + f;
        }


        private static float[] getRotations(EntityLivingBase ent) {
            final double x = ent.posX - mc.thePlayer.posX;
            double y = ent.posY - mc.thePlayer.posY;
            final double z = ent.posZ - mc.thePlayer.posZ;
            y /= mc.thePlayer.getDistanceToEntity(ent);
            final float yaw = (float) (-(Math.atan2(x, z) * 57.29577951308232));
            final float pitch = (float) (-(Math.asin(y) * 57.29577951308232));
            return new float[]{yaw, pitch};
        }

        public static Vec3 getCenter(AxisAlignedBB bb) {
            double value = Math.random();
            return new Vec3(bb.minX + (bb.maxX - bb.minX) * ((rotation2Value.getValue() / 400)),
                    bb.minY + (bb.maxY - bb.minY) * (randoms2.getValue() ? value : (rotationValue.getValue() / 400)), bb.minZ + (bb.maxZ - bb.minZ) * ((rotation2Value.getValue() / 400)));
        }

        public static float[] faceEntitySmooth(double curYaw, double curPitch, double intendedYaw, double intendedPitch,
                                               double yawSpeed, double pitchSpeed) {
            float yaw = (float) updateRotation((float) curYaw, (float) intendedYaw, (float) yawSpeed);
            float pitch = (float) updateRotation((float) curPitch, (float) intendedPitch, (float) pitchSpeed);
            return new float[]{yaw, pitch};
        }

        public static float[] faceEntity(EntityLivingBase var0) {
            return getRotationsNeeded(var0);
        }

        public static float[] getRotationsNeeded(Entity var0) {
            if (var0 == null) {
                return null;
            } else {
                double var1 = var0.posX - Minecraft.getMinecraft().thePlayer.posX;
                double var3 = var0.posZ - Minecraft.getMinecraft().thePlayer.posZ;
                double var5;
                if (var0 instanceof EntityLivingBase) {
                    EntityLivingBase var7 = (EntityLivingBase) var0;
                    var5 = var7.posY + (double) var7.getEyeHeight() - (Minecraft.getMinecraft().thePlayer.posY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
                } else {
                    var5 = (var0.getEntityBoundingBox().minY + var0.getEntityBoundingBox().maxY) / 2.0D - (Minecraft.getMinecraft().thePlayer.posY + (double) Minecraft.getMinecraft().thePlayer.getEyeHeight());
                }

                double var11 = (double) MathHelper.sqrt_double(var1 * var1 + var3 * var3);
                float var9 = (float) (Math.atan2(var3, var1) * 180.0D / 3.141592653589793D) - 90.0F;
                float var10 = (float) (-(Math.atan2(var5, var11) * 180.0D / 3.141592653589793D));
                return new float[]{Minecraft.getMinecraft().thePlayer.rotationYaw + MathHelper.wrapAngleTo180_float(var9 - Minecraft.getMinecraft().thePlayer.rotationYaw), Minecraft.getMinecraft().thePlayer.rotationPitch + MathHelper.wrapAngleTo180_float(var10 - Minecraft.getMinecraft().thePlayer.rotationPitch)};
            }
        }

        private static Minecraft mc = Minecraft.getMinecraft();
        private static float virtualYaw;
        private static float virtualPitch;


        private static float[] faceTarget(final Entity target, final float yawSpeed, final float pitchSpeed, final boolean miss) {
            virtualPitch = mc.thePlayer.rotationPitch;
            virtualYaw = mc.thePlayer.rotationYaw;
            final double var4 = target.posX - mc.thePlayer.posX;
            final double var5 = target.posZ - mc.thePlayer.posZ;
            double var7;
            if (target instanceof EntityLivingBase) {
                final EntityLivingBase var6 = (EntityLivingBase) target;
                var7 = var6.posY + var6.getEyeHeight() - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
            } else {
                var7 = (target.getEntityBoundingBox().minY + target.getEntityBoundingBox().maxY) / 2.0 - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
            }

            Random rnd = new Random();
            final float offset = miss ? (rnd.nextInt(15) * 0.25f + 5.0f) : 0.0f;
            final double var8 = MathHelper.sqrt_double(var4 * var4 + var5 * var5);
            final float var9 = (float) (Math.atan2(var5 + offset, var4) * 180.0 / Math.PI) - 90.0f;
            final float var10 = (float) (-(Math.atan2(var7 - ((target instanceof EntityPlayer) ? 0.5f : 0.0f) + offset, var8) * 180.0 / Math.PI));
            final float pitch = changeRotation(virtualPitch, var10, pitchSpeed);
            final float yaw = changeRotation(virtualYaw, var9, yawSpeed);
            return new float[]{yaw, pitch};
        }

        private static float changeRotation(final float var1, final float var2, final float var3) {
            float var4 = MathHelper.wrapAngleTo180_float(var2 - var1);
            if (var4 > var3) {
                var4 = var3;
            }
            if (var4 < -var3) {
                var4 = -var3;
            }
            return var1 + var4;
        }

        public static void getRotationDifference(float[] rotations) {
        }


        public static float[] getNeededRotations(final EntityLivingBase entityIn) {
            final double d0 = entityIn.posX - mc.thePlayer.posX;
            final double d2 = entityIn.posZ - mc.thePlayer.posZ;
            final double d3 = entityIn.posY + entityIn.getEyeHeight() - (mc.thePlayer.getEntityBoundingBox().minY + (mc.thePlayer.getEntityBoundingBox().maxY - mc.thePlayer.getEntityBoundingBox().minY));
            final double d4 = MathHelper.sqrt_double(d0 * d0 + d2 * d2);
            final float f = (float) (MathHelper.atan2(d2, d0) * 180.0 / 3.141592653589793) - 90.0f;
            final float f2 = (float) (-(MathHelper.atan2(d3, d4) * 180.0 / 3.141592653589793));
            return new float[]{f, f2};
        }

        public static int randomrotation;

        public static float[] getRotations(Entity entity) {
            double diffX = entity.posX - mc.thePlayer.posX;
            double diffZ = entity.posZ - mc.thePlayer.posZ;
            double diffY;
            randomrotation = (int) KillAura.getRandomDoubleInRange(3.321592653589793, 3.442613764691814);
            randomrotation = (int) KillAura.getRandomDoubleInRange(3.321592653589793, 3.442613764691814);
            if ((entity instanceof EntityLivingBase) && mc.thePlayer.posY + 0.2 >= entity.posY) {
                EntityLivingBase elb = (EntityLivingBase) entity;
                diffY = elb.posY + (elb.getEyeHeight() - 0.4)
                        - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
            } else {
                diffY = (entity.getEntityBoundingBox().minY + entity.getEntityBoundingBox().maxY) / 2.0D
                        - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight() - 0.8);
            }
            double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
            float yaw = (float) (Math.atan2(diffZ, diffX) * 180 / randomrotation) - 64.0F;
            float pitch = (float) -(Math.atan2(diffY, dist) * 180 / randomrotation);

            return new float[]{yaw, pitch};
        }

        public static float[] getRotationsw(final Entity target) {
            final double var4 = target.posX - mc.thePlayer.posX;
            final double var5 = target.posZ - mc.thePlayer.posZ;
            double var7;
            if (target instanceof EntityLivingBase) {
                final EntityLivingBase var6 = (EntityLivingBase) target;
                var7 = var6.posY + var6.getEyeHeight() - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
            } else {
                var7 = (target.getEntityBoundingBox().minY + target.getEntityBoundingBox().maxY) / 2.0 - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
            }
            final double var8 = MathHelper.sqrt_double(var4 * var4 + var5 * var5);
            final float var9 = (float) (Math.atan2(var5, var4) * 180.0 / 3.141592653589793) - 90.0f;
            final float var10 = (float) (-(Math.atan2(var7 - ((target instanceof EntityPlayer) ? 0.25 : 0.0), var8) * 180.0 / 3.141592653589793));
            float pitch = changeRotation(mc.thePlayer.rotationPitch, var10);
            float yaw = changeRotation(mc.thePlayer.rotationYaw, var9);
            return new float[]{yaw, pitch};
        }

        public static float changeRotation(final float p_706631, final float p_706632) {
            float var4 = MathHelper.wrapAngleTo180_float(p_706632 - p_706631);
            if (var4 > 1000F) {
                var4 = 1000F;
            }
            if (var4 < -1000F) {
                var4 = -1000F;
            }
            return p_706631 + var4;
        }

        public static float[] getRotations(Location location) {
            double xDistance = location.getX() - mc.thePlayer.posX;
            double zDistance = location.getZ() - mc.thePlayer.posZ;
            double yDistance = location.getY() + (location.getY() - 0.1D) / 1.4D - mc.thePlayer.posY
                    - mc.thePlayer.getEyeHeight() / 1.4D;
            double angleHelper = MathHelper.sqrt_double(xDistance * xDistance + zDistance * zDistance);

            float newYaw = (float) Math.toDegrees(-Math.atan(xDistance / zDistance));
            float newPitch = (float) -Math.toDegrees(Math.atan(yDistance / angleHelper));
            if ((zDistance < 0.0D) && (xDistance < 0.0D)) {
                newYaw = (float) (90.0D + Math.toDegrees(Math.atan(zDistance / xDistance)));
            } else if ((zDistance < 0.0D) && (xDistance > 0.0D)) {
                newYaw = (float) (-90.0D + Math.toDegrees(Math.atan(zDistance / xDistance)));
            }
            return new float[]{newYaw, newPitch};
        }

        public static float getYawChangeToEntity(Entity entity) {
            double deltaX = entity.posX - mc.thePlayer.posX;
            double deltaZ = entity.posZ - mc.thePlayer.posZ;
            double yawToEntity;
            if ((deltaZ < 0.0D) && (deltaX < 0.0D)) {
                yawToEntity = 90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
            } else {
                if ((deltaZ < 0.0D) && (deltaX > 0.0D)) {
                    yawToEntity = -90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
                } else {
                    yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
                }
            }
            return MathHelper.wrapAngleTo180_float(-(mc.thePlayer.rotationYaw - (float) yawToEntity));
        }

        public static float getPitchChangeToEntity(Entity entity) {
            double deltaX = entity.posX - mc.thePlayer.posX;
            double deltaZ = entity.posZ - mc.thePlayer.posZ;
            double deltaY = entity.posY - 1.6D + entity.getEyeHeight() - 0.4D - mc.thePlayer.posY;
            double distanceXZ = MathHelper.sqrt_double(deltaX * deltaX + deltaZ * deltaZ);

            double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));

            return -MathHelper.wrapAngleTo180_float(mc.thePlayer.rotationPitch - (float) pitchToEntity);
        }

        public static float[] getAngles(Entity e) {
            return new float[]{getYawChangeToEntity(e) + mc.thePlayer.rotationYaw,
                    getPitchChangeToEntity(e) + mc.thePlayer.rotationPitch};
        }


        private static float updateRotation(float currentRotation, float intendedRotation, float increment) {
            float f = MathHelper.wrapAngleTo180_float(intendedRotation - currentRotation);

            if (f > increment)
                f = increment;

            if (f < -increment)
                f = -increment;

            return currentRotation + f;
        }


    }


}




