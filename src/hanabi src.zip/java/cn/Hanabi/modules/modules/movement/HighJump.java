package cn.Hanabi.modules.modules.movement;

import cn.Hanabi.events.EventPacket;
import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.BlockAir;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

public class HighJump extends Mod {

    private Value mode = new Value("HighJump", "Mode", 0);
    int counter = 0;
    int counter2 = 0;
    private Value<Double> boost = new Value("HighJump_Boost", 0.5D, 0.1D, 5.0D, 0.05D);
    TimeHelper wait = new TimeHelper();

    public HighJump() {
        super("HighJump", Category.MOVEMENT);
        mode.addValue("Vanilla");
        mode.addValue("Hypixel");
    }
    @Override
    public void onEnable() {
        counter = 0;
        counter2 = 0;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }



    @EventTarget
    public void onPacket(EventPacket e) {
        if ((mc.thePlayer.onGround) && (this.mc.gameSettings.keyBindForward.isPressed())
                && (this.wait.isDelayComplete(500L) && mode.isCurrentMode("Vanilla"))) {
            this.mc.thePlayer.motionY = ((Double) this.boost.getValueState()).doubleValue();
            this.wait.reset();
        }

        boolean blockUnderneath = false;
        int i = 0;
        while (i < this.mc.thePlayer.posY + 2.0) {
            BlockPos pos = new BlockPos(this.mc.thePlayer.posX, i, this.mc.thePlayer.posZ);
            if (!(this.mc.theWorld.getBlockState(pos).getBlock() instanceof BlockAir)) {
                blockUnderneath = true;
            }
            ++i;
        }
        if (mode.isCurrentMode("Hypixel")) {
            if (!blockUnderneath) {
                if (e.getPacket() instanceof C03PacketPlayer) {
                    if (mc.thePlayer.fallDistance > 8.0F) {
                        this.mc.thePlayer.motionY = ((Double) this.boost.getValueState()).doubleValue();
                    }
                }
            }
        }
    }
}