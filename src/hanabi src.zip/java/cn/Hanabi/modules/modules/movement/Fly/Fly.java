package cn.Hanabi.modules.modules.movement.Fly;

import cn.Hanabi.events.*;
import cn.Hanabi.gui.notifications.Notification;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Misc.ClientUtil;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

import java.util.Random;

public class Fly extends Mod {
    public static TimeHelper lagbacktimer = new TimeHelper();

    public static TimeHelper disablertimer = new TimeHelper();
    Value<String> mode = new Value<String>("Fly", "Mode", 0);
    Value<Boolean> lagback = new Value<Boolean>("Fly_LagBackChecks", true);
    public static Value<Double> dmgValue = new Value("Fly_Damage", 1.0, 0.0, 4.0, 1.0);
    public static Value<Double> timer = new Value<Double>("Fly_MotionSpeed", 1d, 1d, 10d, 1d);

    Fly_Motion MotionFly = new Fly_Motion();
    Fly_HypixelM HypixelM = new Fly_HypixelM();
    Fly_HypixelG HypixelG = new Fly_HypixelG();


    public Fly() {
        super("Fly", Category.MOVEMENT);

        mode.addValue("Motion");
        mode.addValue("HypixelG");
        mode.addValue("HypixelM");


    }

    @EventTarget
    public void onPacket(EventPacket e) {
        Packet packet = e.getPacket();

    }

    @EventTarget
    public void onPre(EventPreMotion event) {
        this.setDisplayName(mode.getModeAt(mode.getCurrentMode()));
        if (mode.isCurrentMode("HypixelM")) {
            HypixelM.onPre(event);
            return;
        }
        if (mode.isCurrentMode("HypixelG")) {
            HypixelG.onPre(event);
            return;
        }
        if (mode.isCurrentMode("Disabler")) {
            //disabler.onMove(event);
            return;
        }

        if (mode.isCurrentMode("Motion")) {
            this.setDisplayName("Motion");
            MotionFly.onPre();
            return;

        }


    }

    @EventTarget
    public void onPost(EventPostMotion event) {
        if (mode.isCurrentMode("Hypixel")) {
            return;
        }

    }

    @EventTarget
    public void onBB(BBSetEvent event) {
        if (mode.isCurrentMode("Hypixel")) {
            // GlobalHypixel.onBB(event);
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
    }


    @EventTarget
    public void onPullback(EventPullback e) {
        if (lagback.getValueState() && !mode.isCurrentMode("Disabler")) {
            lagbacktimer.reset();
            ClientUtil.sendClientMessage("(LagBackCheck) Fly Disabled", Notification.Type.WARNING);
            this.set(false);
        }
    }

    @EventTarget
    public void onMove(EventMove event) {
        if (mode.isCurrentMode("HypixelG")) {
            HypixelG.onMove(event);
            return;
        }
        if (mode.isCurrentMode("HypixelM")) {
            HypixelM.onMove(event);
            return;
        }
    }

    @Override
    public void onEnable() {
        if (mode.isCurrentMode("HypixelM")) {
            HypixelM.onEnabled();
            return;
        }
        if (mode.isCurrentMode("HypixelG")) {
            HypixelG.onEnabled();
            return;
        }
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (mode.isCurrentMode("HypixelM")) {
            HypixelM.onDisable();
            return;
        }
        if (mode.isCurrentMode("HypixelG")) {
            HypixelG.onDisable();
            return;
        }
        super.onDisable();
    }

    @EventTarget
    public void onStep(EventStep e) {
        if (mode.isCurrentMode("Hypixel")) {
            return;
        }
    }


    public static double getRandomInRange(double minDouble, double maxDouble) {
        return minDouble >= maxDouble ? minDouble : new Random().nextDouble() * (maxDouble - minDouble) + minDouble;
    }

    public static void damagePlayer(int damage) {
        Minecraft mc = Minecraft.getMinecraft();
        double i1 = getRandomInRange(0.059, 0.0615);
        double i2 = getRandomInRange(0.049, 0.0625);
        double i3 = getRandomInRange(0.000000500, 0.000000700);
        final PotionEffect potioneffect = mc.thePlayer.getActivePotionEffect(Potion.jump);
        final int f = (potioneffect != null) ? (potioneffect.getAmplifier() + 1) : 0;

        //c13 exploit

        if (mc.thePlayer.onGround && damage > 0) {
            for (int i = 0; i < (float) (mc.thePlayer.getMaxFallHeight() - 1 + Fly.dmgValue.getValueState() + f)
                    / 0.05510000046342611 + 1.0; ++i) {
                (mc.getNetHandler().getNetworkManager()).sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(
                        mc.thePlayer.posX, mc.thePlayer.posY + 0.05099991337, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false));
                (mc.getNetHandler().getNetworkManager()).sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(
                        mc.thePlayer.posX, mc.thePlayer.posY + 0.06199991337, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false));
                (mc.getNetHandler().getNetworkManager()).sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(
                        mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false));
            }
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false));
        }

    }

}
