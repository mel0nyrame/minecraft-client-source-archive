package cn.Hanabi.modules.modules.movement.Fly;

import cn.Hanabi.Wrapper;
import cn.Hanabi.events.EventMove;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.modules.modules.combat.TargetStrafe;
import cn.Hanabi.utils.Entity.MoveUtils;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.Misc.BlockUtils;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

import java.util.Random;

public class Fly_HypixelM {
    private int stage;
    private double distance;
    private double moveSpeed;
    private boolean shouldSlow;
    private boolean falling;
    private int counter;
    private double bypass;
    private static TimeHelper boost = new TimeHelper();

    private final Minecraft mc = Minecraft.getMinecraft();

    public void onEnabled() {
        this.shouldSlow = this.mc.thePlayer.isCollidedHorizontally;
        this.falling = this.mc.thePlayer.fallDistance > 0.0f;
        counter = 0;
        bypass = 0.0;
        this.stage = 0;
        this.distance = 0.0;
        this.moveSpeed = 0.0;
        boost.reset();
        if (!(!this.mc.thePlayer.onGround || BlockUtils.isOnLiquid() || BlockUtils.isInLiquid() || this.mc.thePlayer.isOnLadder() || this.falling)) {
            damagePlayer(Fly.dmgValue.getValueState().intValue() + MoveUtils.getJumpEffect());
            this.mc.thePlayer.jump();
            this.mc.thePlayer.posY += 0.49999999999989154856845164 + new Random().nextDouble() * 1E-10;
        }
        if (this.falling) {
            this.moveSpeed = 4;
        }
        if (!this.mc.thePlayer.isCollidedVertically && !this.falling) {
            this.shouldSlow = true;
        }
    }


    public void onPre(EventPreMotion e) {
        this.distance = PlayerUtil.getLastDist();
        if (this.mc.thePlayer.isCollidedHorizontally) {
            this.shouldSlow = true;
        }
        this.mc.thePlayer.motionY = 0.0;
        if (!this.falling) {
            Wrapper.getTimer().timerSpeed = boost.isDelayComplete(800) || this.shouldSlow  ? 1.0f : 2.1999f;

            if (++counter == 1) {
                bypass = 3.25E-4 + getRandomInRange(1.0999E-5, (new Random().nextFloat() * 1E-6));
            } else if (counter == 2) {
                bypass *= -1;
                counter = 0;
            }
            e.setY(mc.thePlayer.getEntityBoundingBox().minY + bypass);
        }
    }


    public void onMove(EventMove e) {
        if (!this.falling) {
            double potion = 1.0 + (this.mc.thePlayer.isPotionActive(Potion.moveSpeed) ? 0.2 * (double) (this.mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1) : 0.0);
            double bypass = 0.29 * potion;
            switch (++this.stage) {
                case 1: {
                    this.moveSpeed = (this.mc.thePlayer.isPotionActive(Potion.moveSpeed) ? 1.56 : 2.0) * bypass;
                    break;
                }
                case 2: {
                    this.moveSpeed *= this.mc.thePlayer.isPotionActive(Potion.moveSpeed) ? 2.34 : 2.39;
                    break;
                }
                case 3: {
                    this.moveSpeed = this.distance - (this.mc.thePlayer.ticksExisted % 3 == 0 ? 0.01 : 0.015) * (this.distance - bypass);
                    break;
                }
                default: {
                    this.moveSpeed = this.distance - this.distance / 159.8;
                    if (this.stage < 15) break;
                    this.stage = 15;
                }
            }
            double d = this.moveSpeed = this.shouldSlow ? PlayerUtil.getBaseMoveSpeed() : Math.max(this.moveSpeed, PlayerUtil.getBaseMoveSpeed());
        }
        if (TargetStrafe.canStrafe()) {
            TargetStrafe.move(e, moveSpeed , TargetStrafe.target);
        } else {
            e.setSpeed(moveSpeed);
        }
    }


    public static double getRandomInRange(double minDouble, double maxDouble) {
        return minDouble >= maxDouble ? minDouble : new Random().nextDouble() * (maxDouble - minDouble) + minDouble;
    }

    public static void damagePlayer(int damage) {
        Minecraft mc = Minecraft.getMinecraft();
        double i1 = getRandomInRange(0.059, 0.0615);
        double i2 = getRandomInRange(0.049, 0.0625);
        double i3 = getRandomInRange(0.000000500, 0.000000700);
        final PotionEffect potioneffect = mc.thePlayer.getActivePotionEffect(Potion.jump);
        final int f = (potioneffect != null) ? (potioneffect.getAmplifier() + 1) : 0;

        if (mc.thePlayer.onGround && damage > 0) {
            for (int i = 0; i < (float) (mc.thePlayer.getMaxFallHeight() + f)
                    / 0.05510000046342611 + 1.0; ++i) {
                (mc.getNetHandler().getNetworkManager()).sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(
                        mc.thePlayer.posX, mc.thePlayer.posY + 0.05099991337, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false));
                (mc.getNetHandler().getNetworkManager()).sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(
                        mc.thePlayer.posX, mc.thePlayer.posY + 0.06199991337, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false));
                (mc.getNetHandler().getNetworkManager()).sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(
                        mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false));
            }
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(mc.thePlayer.posX, mc.thePlayer.posY + 0.0000001, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, true));
        }

    }

    public void onDisable() {
        Wrapper.getTimer().timerSpeed = 1.0f;
    }
}
