package cn.Hanabi.modules.modules.movement;

import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Entity.PlayerUtil;
import com.darkmagician6.eventapi.EventTarget;

public class Sprint extends Mod {
	public static boolean isSprinting;
	
	public Sprint() {
		super("Sprint", Category.MOVEMENT);
		setState(true);
	}
	@EventTarget
	public void onUpdate(EventUpdate event) {
		boolean canSprint = mc.thePlayer.getFoodStats().getFoodLevel() > 6.0F || mc.thePlayer.capabilities.allowFlying;
		if(PlayerUtil.MovementInput() && canSprint) {
			isSprinting = true;
			mc.thePlayer.setSprinting(true);
		} else {
			isSprinting = false;
		}
	}
	
	@Override
	public void onDisable() {
		isSprinting = false;
		mc.thePlayer.setSprinting(false);
		super.onDisable();
	}

}
