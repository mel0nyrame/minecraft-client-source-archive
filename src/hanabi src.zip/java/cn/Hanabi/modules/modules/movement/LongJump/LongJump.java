package cn.Hanabi.modules.modules.movement.LongJump;

import cn.Hanabi.Wrapper;
import cn.Hanabi.events.*;
import cn.Hanabi.gui.notifications.Notification;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.modules.movement.Speed.Speed;
import cn.Hanabi.utils.Misc.ClientUtil;
import cn.Hanabi.utils.Entity.MoveUtils;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;

public class LongJump extends Mod {
    private final Value<Boolean> lagback = new Value("LongJump_LagBackChecks", false);


    private double speed;
    private int stage, downTicks;
    private double lastDist;
    TimeHelper delayTimer = new TimeHelper();


    public LongJump() {
        super("LongJump", Category.MOVEMENT);


    }

    @Override
    public void onEnable() {
        super.onEnable();

        Wrapper.getTimer().timerSpeed = 0.6F;
        delayTimer.reset();
        speed = PlayerUtil.getBaseMoveSpeed();
        stage = 0;
        downTicks = 0;
    }


    @Override
    public void onDisable() {
        super.onDisable();
        Wrapper.getTimer().timerSpeed = 1.0F;
    }

    @EventTarget
    public void onLagBack(EventPullback e) {
        if (lagback.getValueState()) {
            ClientUtil.sendClientMessage("(LagBackCheck) LongJump Disabled", Notification.Type.WARNING);
            set(false);
        }
    }

    @EventTarget
    public void onPre(EventPreMotion e) {
        if ((mc.thePlayer.isCollidedVertically || mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.getCollisionBoundingBox().offset(0.0, mc.thePlayer.motionY, 0.0)).size() > 0)) {
            if (stage == 0) {
                e.setY(mc.thePlayer.posY + 1.0E-10D);
                stage = 1;
                downTicks = 0;
            } else if (stage == 4) {
                this.set(false);
            }
        }

    }

    @EventTarget
    public void onPost(EventPostMotion e) {
        final double xDist = mc.thePlayer.posX - mc.thePlayer.prevPosX;
        final double zDist = mc.thePlayer.posZ - mc.thePlayer.prevPosZ;
        lastDist = Math.sqrt(xDist * xDist + zDist * zDist);

    }

    @EventTarget
    public void onMove(EventMove event) {
        if (stage == 1 && PlayerUtil.isMoving()) {
            stage = 2;
            speed = (1.38 * PlayerUtil.getBaseMoveSpeed() - 0.01) / 1.6;
        } else if (stage == 2 && mc.thePlayer.onGround && mc.thePlayer.isCollidedVertically) {
            stage = 3;
            event.x = event.z = 0;
            event.setY(mc.thePlayer.motionY = (0.423 + MoveUtils.getJumpEffect() * 0.09));
            speed *= 2.149;
        } else if (stage == 3) {
            stage = 4;
            final double difference = 0.64 * (lastDist - PlayerUtil.getBaseMoveSpeed());
            speed = (lastDist - difference) * 1.92;
        } else {
            if (mc.thePlayer.motionY < 0 && mc.thePlayer.fallDistance <= 1.2) {
                mc.thePlayer.motionY = getDownMotion(downTicks);
                downTicks++;
            }
            speed = lastDist - lastDist / 159.0;
        }
        speed = Math.max(speed, PlayerUtil.getBaseMoveSpeed());
        if (speed > 0.7) {
            speed = 0.7 - Math.random() / 50;
        }
        Speed.setMoveSpeed(event, speed);

    }

    public double getDownMotion(int stage) {
        //water motionY = glide ???
        double[] motion = {-0.012255154820464102
                , -0.022255154820464102
                , -0.029804124002464114
                , -0.04384329955726414
                , -0.05507464016846417
                , -0.0640597127913122
                , -0.07124777099670104
                , -0.07699821764670045
                , -0.08159857503525064
                , -0.08527886100093134
                , -0.08822308981734832
                , -0.09057847290557984
                , -0.09246277940424341
                , -0.09397022462563696
                , -0.09517618082072195
                , -0.09614094579116605
                , -0.09691275777902224
                , -0.0975302073785079
                , -0.098024167065457};

        if (stage <= motion.length) {
            return motion[stage];
        } else {
            return mc.thePlayer.motionY;
        }
    }

}

