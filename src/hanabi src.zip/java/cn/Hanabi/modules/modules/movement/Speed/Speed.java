package cn.Hanabi.modules.modules.movement.Speed;

import cn.Hanabi.events.*;
import cn.Hanabi.gui.notifications.Notification;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Misc.ClientUtil;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;

public class Speed extends Mod {

    public static Value mode = new Value("Speed", "Mode", 1);
    public Value<Boolean> lagback = new Value("Speed_LagBackChecks", true);
    public Value<Boolean> autodisable = new Value<Boolean>("Speed_AutoDisable", true);
    Speed_Hypixel GlobalHypixel = new Speed_Hypixel();
    Speed_GudHop GudHop = new Speed_GudHop();
    Speed_AAC AAC = new Speed_AAC();

    public Speed() {
        super("Speed", Category.MOVEMENT);
        mode.addValue("GudHop");
        mode.addValue("Hypixel");

    }

    public static void setMoveSpeed(final EventMove event, final double speed) {
        double forward = mc.thePlayer.moveForward;
        double strafe = mc.thePlayer.moveStrafing;
        float yaw = mc.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            event.setX(0.0);
            event.setZ(0.0);
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += ((forward > 0.0) ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += ((forward > 0.0) ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            event.setX(forward * speed * Math.cos(Math.toRadians(yaw + 90.0f))
                    + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f)));
            event.setZ(forward * speed * Math.sin(Math.toRadians(yaw + 90.0f))
                    - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f)));
        }
    }

    @EventTarget
    public void onReload(EventWorldChange e) {
        if (autodisable.getValueState()) {
            this.set(false);
        }
    }


    @EventTarget
    public void onPacket(EventPacket e) {
        if (mode.isCurrentMode("Hypixel")) {
            return;
        }
    }

    @EventTarget
    public void onStep(EventStep e) {

        if (mode.isCurrentMode("Hypixel")) {
            GlobalHypixel.onStep(e);
            return;
        }
    }

    @EventTarget
    public void onUpdate(EventPreMotion e) {
        if (mode.isCurrentMode("GudHop")) {
            setDisplayName("GudHop");
            GudHop.onPre(e);
            return;
        }
        if (mode.isCurrentMode("Hypixel")) {
            GlobalHypixel.onUpdate(e);
            return;
        }
        if (mode.isCurrentMode("Test")) {
            return;
        }
        if (mode.isCurrentMode("AAC")) {
            AAC.onPre(e);
            return;
        }
        /*
         * if (mode.isCurrentMode("Hypixel")) { Hypixel.onPre(e); return; }
         */
    }

    @EventTarget
    public void onPost(EventPostMotion e) {
        if (mode.isCurrentMode("Test")) {
            return;
        }
    }

    @EventTarget
    public void onPullback(EventPullback e) {
        if (lagback.getValueState()) {
            ClientUtil.sendClientMessage("(LagBackCheck) Speed Disabled", Notification.Type.WARNING);
            set(false);
        }
        /*
         * if (mode.isCurrentMode("HypixelGlobal")) { GlobalHypixel.onPullback(e);
         * return; }
         */
        if (mode.isCurrentMode("Hypixel")) {
            GlobalHypixel.onPullback(e);
            return;
        }
    }

    @EventTarget
    public void onMove(EventMove em) {
        /*
         * if (mode.isCurrentMode("HypixelGlobal")) { setDisplayName("HypixelGlobal");
         * GlobalHypixel.onMove(em); return; }
         */

        if (mode.isCurrentMode("Hypixel")) {
            setDisplayName("Hypixel");
            GlobalHypixel.onMove(em);
            return;
        }
        if (mode.isCurrentMode("Test")) {
            return;
        }
        /*
         * if (mode.isCurrentMode("Hypixel")) { setDisplayName("Hypixel");
         * Hypixel.onMove(em); return; }
         */


    }

    @Override
    public void onDisable() {
        /*
         * try { if
         * (!Hanabi.AES_UTILS.decrypt(Hanabi.HWID_VERIFY).contains(Wrapper.getHWID())) {
         * FMLCommonHandler.instance().exitJava(0, true); Client.sleep = true; } } catch
         * (Exception e) { FMLCommonHandler.instance().exitJava(0, true); Client.sleep =
         * true; }
         *
         */

        /*
         * if (mode.isCurrentMode("HypixelGlobal")) { GlobalHypixel.onDisable(); return;
         * }
         */
        if (mode.isCurrentMode("Test")) {
            return;
        }
        if (mode.isCurrentMode("Hypixel")) {
            GlobalHypixel.onDisable();
            return;
        }
        if (mode.isCurrentMode("AAC")) {
            AAC.onDisable();
            return;
        }
    }

    @Override
    public void onEnable() {
        /*
         * if (mode.isCurrentMode("HypixelGlobal")) { GlobalHypixel.onEnable(); return;
         * }
         */

        if (mode.isCurrentMode("Hypixel")) {
            GlobalHypixel.onEnable();
            return;
        }
        if (mode.isCurrentMode("Test")) {
            return;
        }
        if (mode.isCurrentMode("AAC")) {
            AAC.onEnable();
            return;
        }
        /*
         * if (mode.isCurrentMode("Hypixel")) { Hypixel.onEnable(); return; }
         */
    }


}
