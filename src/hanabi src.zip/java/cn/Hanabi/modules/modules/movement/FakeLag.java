package cn.Hanabi.modules.modules.movement;

import cn.Hanabi.events.EventPacket;
import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.MathUtils;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.network.Packet;
import net.minecraft.network.login.client.C00PacketLoginStart;
import net.minecraft.network.login.client.C01PacketEncryptionResponse;
import net.minecraft.network.play.client.*;
import net.minecraft.network.status.client.C00PacketServerQuery;
import net.minecraft.network.status.client.C01PacketPing;

import java.util.concurrent.CopyOnWriteArrayList;

public class FakeLag extends Mod {
    Value<Double> lagValue = new Value<Double>("FakeLag_Delay", 3000d, 300d, 5000d);
    CopyOnWriteArrayList<Packet> packetList = new CopyOnWriteArrayList<Packet>();
    TimeHelper lagHelper = new TimeHelper();
    Packet lastPacket;


    public FakeLag() {
        super("FakeLag", Category.MOVEMENT);
    }

    @EventTarget
    public void onPacket(EventPacket e) {
        Packet packet = e.getPacket();

        if ((packet instanceof C00PacketKeepAlive || packet instanceof C0CPacketInput || packet instanceof C16PacketClientStatus) && !(mc.thePlayer.isDead || mc.thePlayer.getHealth() <= 0)) {
            if (packetList.contains(packet)) { // 再次发包处理
                packetList.remove(packet);
            } else {
                packetList.add(packet);
                e.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate e) {
        if (lagHelper.isDelayComplete(lagValue.getValueState())) {
            if (mc.theWorld.getEntityByID(-1) != null) mc.theWorld.removeEntityFromWorld(-1);
            for (Packet packet : packetList) {
                mc.thePlayer.sendQueue.addToSendQueue(packet);
                lastPacket = packet;
            }
            PlayerUtil.debug("FakeLagged");
            lagHelper.reset();
        }
    }
}
