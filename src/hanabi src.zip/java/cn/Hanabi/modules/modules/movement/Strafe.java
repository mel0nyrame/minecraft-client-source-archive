package cn.Hanabi.modules.modules.movement;

import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.injection.interfaces.IKeyBinding;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Entity.PlayerUtil;
import com.darkmagician6.eventapi.EventTarget;

public class Strafe extends Mod {

	public boolean air = true;

	public Strafe() {
		super("Strafe", Category.MOVEMENT);
	}

	@EventTarget
	public void onPreMotion(EventPreMotion event) {
		if (!mc.thePlayer.onGround) {
			if (((IKeyBinding) mc.gameSettings.keyBindJump).getPress()) {
				PlayerUtil.setSpeed(PlayerUtil.getSpeed());
			}
		}

	}
}
