package cn.Hanabi.modules.modules.movement.Speed;

import cn.Hanabi.Wrapper;
import cn.Hanabi.events.EventMove;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.events.EventPullback;
import cn.Hanabi.events.EventStep;
import cn.Hanabi.modules.modules.combat.KillAura;
import cn.Hanabi.modules.modules.combat.TargetStrafe;
import cn.Hanabi.utils.Entity.MoveUtils;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.MathUtils;
import cn.Hanabi.utils.Misc.BlockUtils;
import cn.Hanabi.utils.TimeLocation.DelayTimer;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.utils.Translate;
import cn.Hanabi.value.Value;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.potion.Potion;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Keyboard;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Random;

public class Speed_Hypixel {
    static Value<String> mode = new Value<String>("Speed", "HypixelMode", 0);

    private double speed = 0.07999999821186066D;
    public int state;
    public double moveSpeed;
    Minecraft mc = Minecraft.getMinecraft();
    boolean collided;
    double less, stair;
    float yaw;
    boolean lessSlow;
    private double lastDist;
    private int stage;

    private boolean shouldslow;

    public Speed_Hypixel() {
        mode.addValue("Hop");
        mode.addValue("LowHop");

    }

    public static double defaultSpeed() {
        double baseSpeed = 0.2887D;
        if (Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.moveSpeed)) {
            int amplifier = Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= (1.0D + 0.2D * (amplifier + 1));
        }
        return baseSpeed;
    }

    public void onStep(EventStep event) {
        double height = mc.thePlayer.getEntityBoundingBox().minY - mc.thePlayer.posY;
        if (height > 0.7) {
            less = 0;
        }
        if (height == 0.5)
            stair = 0.75;
    }
    DelayTimer lastCheck = new DelayTimer();




    public void onUpdate(EventPreMotion event) {
        yaw = event.getYaw();
        lastDist = Math.sqrt(((mc.thePlayer.posX - mc.thePlayer.prevPosX) * (mc.thePlayer.posX - mc.thePlayer.prevPosX))
                + ((mc.thePlayer.posZ - mc.thePlayer.prevPosZ) * (mc.thePlayer.posZ - mc.thePlayer.prevPosZ)));

    }


    public void onMove(EventMove event) {
        if (mode.isCurrentMode("Hop")) {
            if (mc.thePlayer.isCollidedHorizontally) {
                collided = true;
            }
            if (collided) {
                Wrapper.getTimer().timerSpeed = 1;
                stage = -1;
            }
            if (stair > 0)
                stair -= 0.25;
            less -= less > 1 ? 0.12 : 0.11;
            if (less < 0)
                less = 0;
            if (MoveUtils.isOnGround(0.01) && (PlayerUtil.isMoving2())) {
                collided = mc.thePlayer.isCollidedHorizontally;
                if (stage >= 0 || collided) {
                    stage = 0;

                    double motY = 0.4086666D + MoveUtils.getJumpEffect() * 0.1;
                    if (stair == 0) {
                        mc.thePlayer.jump();
                        event.setY(mc.thePlayer.motionY = motY);
                    } else {

                    }

                    less++;
                    if (less > 1 && !lessSlow)
                        lessSlow = true;
                    else
                        lessSlow = false;
                    if (less > 1.12)
                        less = 1.12;
                }
            }

            speed = getHypixelSpeed(stage) + 0.032;// 国服还能更快
            speed *= 0.91;

            if (stair > 0) {
                speed *= 0.67 - MoveUtils.getSpeedEffect() * 0.1;
            }

            if (stage < 0)
                speed = MoveUtils.defaultSpeed();

            if (lessSlow) {
                speed *= 0.91;
            }

            if (mc.thePlayer.isInWater() || mc.thePlayer.isInLava()) {
                speed = 0.12;
            }
            if ((mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f)) {
                ++stage;
            }
        }

        if (mode.isCurrentMode("LowHop")) {
            if (this.stage == 1)
                stage++;
            double Y = 0.4089;
            double lowY = 0.1114514D;
            if (mc.thePlayer.isPotionActive(Potion.jump)) {
                Y += ((float) (mc.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1) * 0.1f);
            }
            if (this.canZoom() && this.stage == 2
                    && (mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f)) {
                if (mc.thePlayer.fallDistance == 0) {
                    this.mc.thePlayer.motionY -= 0.04;
                }
                event.setY(mc.thePlayer.motionY);
                event.setY(Y);
                if (this.mc.thePlayer.isInWater()) {
                    this.speed *= 1.06D;
                } else if (this.mc.thePlayer.isInLava()) {
                    this.speed *= 0.33D;
                } else
                    this.speed *= mc.theWorld
                            .getBlockState(new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ))
                            .getBlock() instanceof BlockStairs ? 0.7D : 1.72D;
            } else if (this.stage == 3) {
                double diff = (0.66 + speed * 0.07) * (this.lastDist - (double) getBaseMoveSpeed());
                this.speed = this.lastDist - diff;
            } else {
                if (mc.theWorld.getCollidingBoundingBoxes((Entity) mc.thePlayer,
                        mc.thePlayer.getEntityBoundingBox().offset(0.0D, lowY, 0.0D)).size() > 0
                        || (mc.thePlayer.isCollidedVertically && mc.thePlayer.onGround)) {
                    this.stage = isMoving2() ? 1 : 0;
                    Wrapper.getTimer().timerSpeed = 1.0F;
                }
                this.speed = this.lastDist - this.lastDist / 160.12;
            }
            this.speed = Math.max(this.speed, (double) getBaseMoveSpeed());
        }


        if (mc.thePlayer.movementInput.moveForward != 0.0F || mc.thePlayer.movementInput.moveStrafe != 0.0F) {
            if (TargetStrafe.canStrafe()) {
                if (KillAura.target != null) {
                    cn.Hanabi.modules.modules.combat.TargetStrafe.doStrafeAtSpeed(event, speed);
                }
            } else {
                event.setSpeed(speed);
            }

            ++stage;
        }
    }

    private boolean canZoom() {
        if (isMoving2() && this.mc.thePlayer.onGround) {
            return true;
        }
        return false;
    }

    private void setMotion(EventMove em, double speed) {
        double xDist = em.x;
        double zDist = em.z;
        float lastDist = (float) Math.sqrt(xDist * xDist + zDist * zDist);
        double forward = mc.thePlayer.movementInput.moveForward;
        double strafe = mc.thePlayer.movementInput.moveStrafe;
        float yaw = mc.thePlayer.rotationYaw;
        if ((forward == 0.0D) && (strafe == 0.0D)) {
            em.setX(0.0D);
            em.setZ(0.0D);
        } else {
            if (forward != 0.0D) {
                if (strafe > 0.0D) {
                    yaw += (forward > 0.0D ? -45 : 45);
                } else if (strafe < 0.0D) {
                    yaw += (forward > 0.0D ? 45 : -45);
                }
                strafe = 0.0D;
                if (forward > 0.0D) {
                    forward = 1;
                } else if (forward < 0.0D) {
                    forward = -1;
                }
            }
            em.setX(mc.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90F))
                    + strafe * speed * Math.sin(Math.toRadians(yaw + 90F)));
            em.setZ(mc.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90F))
                    - strafe * speed * Math.cos(Math.toRadians(yaw + 90F)));

        }
    }

    public boolean isMoving2() {
        return ((mc.thePlayer.moveForward != 0.0F || mc.thePlayer.moveStrafing != 0.0F));
    }

    public boolean isOnGround(double height) {
        return !mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer,
                mc.thePlayer.getEntityBoundingBox().offset(0.0D, -height, 0.0D)).isEmpty();
    }

    public void onPullback(EventPullback event) {
        stage = -4;
    }

    public int getJumpEffect() {
        if (mc.thePlayer.isPotionActive(Potion.jump))
            return mc.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1;
        else
            return 0;
    }

    public int getSpeedEffect() {
        if (mc.thePlayer.isPotionActive(Potion.moveSpeed))
            return mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1;
        else
            return 0;
    }

    public boolean isInLiquid() {
        if (mc.thePlayer.isInWater()) {
            return true;
        }
        boolean inLiquid = false;
        final int y = (int) mc.thePlayer.getEntityBoundingBox().minY;
        for (int x = MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().minX); x < MathHelper
                .floor_double(mc.thePlayer.getEntityBoundingBox().maxX) + 1; x++) {
            for (int z = MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().minZ); z < MathHelper
                    .floor_double(mc.thePlayer.getEntityBoundingBox().maxZ) + 1; z++) {
                final Block block = mc.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                if (block != null && block.getMaterial() != Material.air) {
                    if (!(block instanceof BlockLiquid))
                        return false;
                    inLiquid = true;
                }
            }
        }
        return inLiquid;
    }


    public void onEnable() {
        moveSpeed = MoveUtils.defaultSpeed();
        less = 0;
        lastDist = 0.0;
        stage = 2;
        Wrapper.getTimer().timerSpeed = 1;
        lessSlow = mc.thePlayer.inventory.inventoryChanged;
        Wrapper.getTimer().timerSpeed = 1.0f;

    }

    private double random(double min, double max) {
        return Math.random() * (min - max) + max;
    }

    public void onDisable() {
        Wrapper.getTimer().timerSpeed = 1;
    }


    private double getHypixelSpeed(int stage) {
        double value = MoveUtils.defaultSpeed() + (0.028 * MoveUtils.getSpeedEffect())
                + (double) MoveUtils.getSpeedEffect() / 15;
        double firstvalue = 0.4125 + (double) MoveUtils.getSpeedEffect() / 12.5;
        double thirdvalue = 0.4015 + (double) MoveUtils.getSpeedEffect() / 12.5;
        double decr = (((double) stage / 500) * 2.975);

        if (stage == 0) {
            if (!lastCheck.isDelayComplete(400)) {
                if (!shouldslow)
                    shouldslow = true;
            } else {
                if (shouldslow)
                    shouldslow = false;
            }
            value = 0.64 + (MoveUtils.getSpeedEffect() + (0.028 * MoveUtils.getSpeedEffect())) * 0.1322;
        } else if (stage == 1) {
            value = firstvalue;
        } else if (stage == 2) {
            value = thirdvalue;
        } else if (stage >= 3) {
            value = thirdvalue - decr;
        }
        if (shouldslow || !lastCheck.isDelayComplete(500) || collided) {
            value = 0.2;
            if (stage == 0)
                value = 0;
        }

        return Math.max(value, shouldslow ? value : MoveUtils.defaultSpeed() + (0.028 * MoveUtils.getSpeedEffect()));
    }

    public final double getYaw(boolean strafing) {
        float rotationYaw = mc.thePlayer.rotationYaw;
        float forward = 1F;

        final double moveForward = mc.thePlayer.movementInput.moveForward;
        final double moveStrafing = mc.thePlayer.movementInput.moveStrafe;
        final float yaw = mc.thePlayer.rotationYaw;

        if (moveForward < 0) {
            rotationYaw += 180F;
        }

        if (moveForward < 0) {
            forward = -0.5F;
        } else if (moveForward > 0) {
            forward = 0.5F;
        }

        if (moveStrafing > 0) {
            rotationYaw -= 90F * forward;
        } else if (moveStrafing < 0) {
            rotationYaw += 90F * forward;
        }

        return Math.toRadians(rotationYaw);
    }

    public final double getSpeed() {
        return Math.sqrt(mc.thePlayer.motionX * mc.thePlayer.motionX + mc.thePlayer.motionZ * mc.thePlayer.motionZ);
    }


    public double getBaseMoveSpeed() {
        double boostSpeed = 0.2873D;
        if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
            int amplifier = mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            boostSpeed *= (1.0D + 0.2D * (amplifier + 1));
        }
        return boostSpeed;
    }

    public double round(double value, int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        }
        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }


}
