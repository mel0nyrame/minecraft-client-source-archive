package cn.Hanabi.modules.modules.movement.Fly;

import cn.Hanabi.Wrapper;
import cn.Hanabi.events.EventMove;
import cn.Hanabi.events.EventPostMotion;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.modules.modules.combat.KillAura;
import cn.Hanabi.modules.modules.combat.TargetStrafe;
import cn.Hanabi.utils.Entity.MoveUtils;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.Misc.BlockUtils;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import com.darkmagician6.eventapi.EventTarget;
import com.darkmagician6.eventapi.events.Event;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

import java.util.Random;

public class Fly_HypixelO {
    TimeHelper delayTimer = new TimeHelper();
    boolean hurtted;
    double currentSpeed;
    int ticks, stage;
    double y;
    private int counter;
    private double bypass;

    private final Minecraft mc = Minecraft.getMinecraft();

    public void onEnable() {
        Wrapper.getTimer().timerSpeed = 0.5f;
        y = 0;
        stage = 0;
        ticks = 0;
        hurtted = false;
        delayTimer.reset(); }

    public void onDisable() {
        Wrapper.getTimer().timerSpeed = 1;
        MoveUtils.setMotion(0.2);
    }

    public void onPre(EventPreMotion e) {
        mc.thePlayer.setSprinting(true);
        float baseSpeed = 0.29f + MoveUtils.getSpeedEffect() * 0.06f;
        // Zoom的延迟
        if (delayTimer.isDelayComplete(50)) {
            // 处理受伤
            if (!hurtted) {
                hurtted = true;
                Fly.damagePlayer(Fly.dmgValue.getValueState().intValue() + MoveUtils.getJumpEffect());
                currentSpeed = 100;
                mc.thePlayer.jump();
                return;
            }

            // 随时间Timer减速
            if (stage >= 4) {
                Wrapper.getTimer().timerSpeed = Math.max(1, (float) (1f + currentSpeed / ((float) 400)));
            }

            // 撞墙\松手的减速
            if ((mc.thePlayer.moveForward == 0 && mc.thePlayer.moveStrafing == 0) || mc.thePlayer.isCollidedHorizontally) {
                currentSpeed = 0;
            }

            // 玩家杂项
            mc.thePlayer.motionY = 0;
            mc.thePlayer.jumpMovementFactor = 0; // 时间长回弹

            // 设置速度
            boolean lagged = !Fly.lagbacktimer.isDelayComplete(5000);
            double speed = Math.max(baseSpeed, (baseSpeed + currentSpeed / 145f) * (currentSpeed < 70 || lagged ? 1f : 1.35f));

            if (TargetStrafe.canStrafe()) {
                TargetStrafe.move(null, speed, KillAura.target);
            } else {
                MoveUtils.setMotion(speed);
            }
            Random rdm = new Random();

            //可能不支持速度药水  国际暂未测试
            if(MoveUtils.getSpeedEffect() == 0 && !lagged) {
                if(currentSpeed < 5) {
                    currentSpeed = Math.max(currentSpeed - 0.185, 0);
                }else if(currentSpeed < 30) {
                    currentSpeed = Math.max(currentSpeed - 0.53592, 0);
                }else if(currentSpeed < 50){
                    currentSpeed = Math.max(currentSpeed - 0.5766, 0);
                }else if(currentSpeed < 60) {
                    currentSpeed = Math.max(currentSpeed - 0.652, 0);
                }else if(currentSpeed < 70) {
                    currentSpeed = Math.max(currentSpeed - 0.7199992, 0);
                }else if(currentSpeed < 95) {
                    currentSpeed = Math.max(currentSpeed - 0.93 + ((float)rdm.nextInt(5) / 100), 0);
                }else if(currentSpeed <= 100) {
                    currentSpeed = Math.max(currentSpeed - 0.9528, 0);
                }
            }else if(!lagged){
                currentSpeed = Math.max(currentSpeed - 0.9978888, 0);
            }else {
                currentSpeed = Math.max((int)currentSpeed - 1, 0);
            }
            // 上升坐标

            if (++counter == 1) {
                bypass = 3.25E-4 + getRandomInRange(1.0999E-5, (new Random().nextFloat() * 1E-6));
            } else if (counter == 2) {
                bypass *= -1;
                counter = 0;
            }
            e.setY(mc.thePlayer.getEntityBoundingBox().minY + bypass);
            stage++; }
    }

    @EventTarget
    public void onPost(EventPostMotion e) {
    }

    @EventTarget
    public void onMove(EventMove e) {
        // 延迟未到的原地不动
        if (!delayTimer.isDelayComplete(50)) {
            e.setX(0);
            // Y继续下降就好咯
            // e.setY(0);
            e.setZ(0);
        }

        if (e.getY() == 0 && stage >= 3) {
            Wrapper.getTimer().timerSpeed = 1f;
        }
    }

    public static double getRandomInRange(double minDouble, double maxDouble) {
        return minDouble >= maxDouble ? minDouble : new Random().nextDouble() * (maxDouble - minDouble) + minDouble;
    }


}
