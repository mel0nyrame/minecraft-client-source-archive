package cn.Hanabi.modules.modules.movement.Speed;

import cn.Hanabi.Wrapper;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.modules.modules.combat.TargetStrafe;
import cn.Hanabi.utils.Entity.PlayerUtil;
import net.minecraft.client.Minecraft;

public class Speed_GudHop {
	Minecraft mc = Minecraft.getMinecraft();
	
	public void onPre(EventPreMotion e) {
		if (mc.thePlayer.onGround && PlayerUtil.MovementInput() && !mc.thePlayer.isInWater()) {
			Wrapper.getTimer().timerSpeed = 1.0F;
			mc.thePlayer.jump();
		} else if (PlayerUtil.MovementInput() && !mc.thePlayer.isInWater()) {
			if (TargetStrafe.canStrafe()){
				TargetStrafe.doStrafeAtSpeed(e , 0.8D);
			} else {
				PlayerUtil.setSpeed(0.8D);

			}
		}

		if (!PlayerUtil.MovementInput()) {
			mc.thePlayer.motionX = mc.thePlayer.motionZ = 0.0D;
		}
	}
}
