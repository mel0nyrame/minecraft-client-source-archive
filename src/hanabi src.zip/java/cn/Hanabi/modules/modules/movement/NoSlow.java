package cn.Hanabi.modules.modules.movement;

import cn.Hanabi.Wrapper;
import cn.Hanabi.events.EventPostMotion;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.modules.combat.KillAura;
import cn.Hanabi.utils.Entity.MoveUtils;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;

import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class NoSlow extends Mod {
	public Value<String> mode = new Value<String>("NoSlow", "Mode", 0);
	public static Value<Double> percent = new Value("NoSlow_Percent", 0.0D, 0.0D, 100.0D, 5D);

	public NoSlow() {
		super("NoSlow", Category.MOVEMENT);
		// TODO 自动生成的构造函数存根
		mode.addValue("Vanilla");
		mode.addValue("NCP");
		mode.addValue("AAC");
		mode.addValue("Custom");

	}
	
	@EventTarget
	public void onPre(EventPreMotion e) {
		if(mc.thePlayer.isUsingItem() && PlayerUtil.isMoving() && MoveUtils.isOnGround(0.42) && KillAura.target == null && (mode.isCurrentMode("AAC") || mode.isCurrentMode("NCP"))){
			if (mode.isCurrentMode("AAC")) Wrapper.getTimer().timerSpeed = 0.7f;
			double x = mc.thePlayer.posX; double y = mc.thePlayer.posY; double z = mc.thePlayer.posZ;
			mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
		}
		
		if (!mc.thePlayer.isUsingItem() && mode.isCurrentMode("AAC")) {
			Wrapper.getTimer().timerSpeed = 1f;
		}
		
	    if (mode.isCurrentMode("Custom")) {
			this.setDisplayName("Custom");		

		if(mc.thePlayer.getItemInUse().getItem() instanceof ItemSword) {
			mc.thePlayer.motionX *= 0.5f;
			mc.thePlayer.motionZ *= 0.5f;
		}
		if (mc.thePlayer.isUsingItem()) {
			mc.thePlayer.motionX *= percent.getValueState().floatValue() / 100;
			mc.thePlayer.motionZ *= percent.getValueState().floatValue() / 100;
		}
	    }
	}
	
	@EventTarget
	public void onPost(EventPostMotion e) {
		if(mc.thePlayer.isUsingItem() && PlayerUtil.isMoving() && MoveUtils.isOnGround(0.42) && KillAura.target == null && (mode.isCurrentMode("AAC") || mode.isCurrentMode("NCP"))){
			double x = mc.thePlayer.posX; double y = mc.thePlayer.posY; double z = mc.thePlayer.posZ;
		
			mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));
		}
	}
}
