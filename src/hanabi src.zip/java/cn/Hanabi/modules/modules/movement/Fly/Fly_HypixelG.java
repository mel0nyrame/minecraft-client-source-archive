package cn.Hanabi.modules.modules.movement.Fly;

import cn.Hanabi.Wrapper;
import cn.Hanabi.events.EventMove;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.modules.modules.combat.KillAura;
import cn.Hanabi.modules.modules.combat.TargetStrafe;
import cn.Hanabi.utils.Entity.MoveUtils;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.MathUtils;
import cn.Hanabi.utils.Misc.BlockUtils;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

import java.util.Random;

public class Fly_HypixelG {
    private int stage;
    private double distance;
    private double moveSpeed;
    private boolean canFly;
    private boolean shouldSlow;
    private boolean falling;
    private int counter;
    private double bypass;
    private static TimeHelper boost = new TimeHelper();

    private final Minecraft mc = Minecraft.getMinecraft();

    public void onEnabled() {
        this.shouldSlow = this.mc.thePlayer.isCollidedHorizontally;
        this.falling = this.mc.thePlayer.fallDistance > 0.0f;

        this.stage = 0;
        this.counter = 0;
        this.bypass = 0.0;
        this.distance = 0.0;
        this.moveSpeed = 0.0;
        this.canFly = this.falling || this.shouldSlow;
        if (!(!this.mc.thePlayer.onGround || BlockUtils.isOnLiquid() || BlockUtils.isInLiquid() || this.mc.thePlayer.isOnLadder() || this.falling)) {
            if (this.canFly) {
                damagePlayer(Fly.dmgValue.getValueState().intValue() + MoveUtils.getJumpEffect());
                this.mc.thePlayer.jump();
                this.mc.thePlayer.posY += 0.42 + new Random().nextDouble() / 4799.0;
            } else {
                damagePlayer(Fly.dmgValue.getValueState().intValue() + MoveUtils.getJumpEffect());
            }
        }
        if (this.falling) {
            this.moveSpeed = PlayerUtil.getBaseMoveSpeed() * 12;
        }
        if (!this.mc.thePlayer.isCollidedVertically && !this.falling) {
            this.shouldSlow = true;
        }
    }


    public void onPre(EventPreMotion e) {
        this.distance = PlayerUtil.getLastDist();
        if (this.mc.thePlayer.isCollidedHorizontally) {
            this.shouldSlow = true;
        }
        this.mc.thePlayer.motionY = 0.0;
        if (!this.falling) {
            if (!this.canFly) {
                if (this.mc.thePlayer.hurtResistantTime == 19) {
                    this.mc.thePlayer.jump();
                    this.mc.thePlayer.posY += 0.42 + new Random().nextDouble() / 4799.0;
                    this.canFly = true;
                }
                boost.reset();
                return;
            }

            Wrapper.getTimer().timerSpeed = boost.isDelayComplete(750) || this.shouldSlow ? 1.0f : 2.0f;

            if (++this.counter == 1) {
                this.bypass = 3.25E-4 + MathUtils.randomDouble(1.0999E-5, (double) new Random().nextFloat() * 1.0E-6);
            } else if (this.counter == 2) {
                this.bypass = -this.bypass;
                this.counter = 0;
            }
            e.setY(this.mc.thePlayer.posY + this.bypass);
        }
    }


    public void onMove(EventMove e) {
        if (!this.falling) {
            if (!this.canFly) {
                ((EventMove) e).setSpeed(0.0);
                return;
            }
            double potion = 1.0 + (this.mc.thePlayer.isPotionActive(Potion.moveSpeed) ? 0.2 * (double) (this.mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1) : 0.0);
            double bypass = 0.29 * potion;
            switch (++this.stage) {
                case 1: {
                    this.moveSpeed = (this.mc.thePlayer.isPotionActive(Potion.moveSpeed) ? 1.56 : 2.0) * bypass;
                    break;
                }
                case 2: {
                    this.moveSpeed *= this.mc.thePlayer.isPotionActive(Potion.moveSpeed) ? 2.34 : 2.39;
                    break;
                }
                case 3: {
                    this.moveSpeed = this.distance - (this.mc.thePlayer.ticksExisted % 3 == 0 ? 0.01 : 0.015) * (this.distance - bypass);
                    break;
                }
                default: {
                    this.moveSpeed = this.distance - this.distance / 159.8;
                    if (this.stage < 15) break;
                    this.stage = 15;
                }
            }
            double d = this.moveSpeed = this.shouldSlow ? PlayerUtil.getBaseMoveSpeed() : Math.max(this.moveSpeed, PlayerUtil.getBaseMoveSpeed());
        }
        if (TargetStrafe.canStrafe()) {
            if (KillAura.target != null) {
                cn.Hanabi.modules.modules.combat.TargetStrafe.move(e, moveSpeed , KillAura.target);
            }
        } else {
            e.setSpeed(moveSpeed);
        }
    }


    public static double getRandomInRange(double minDouble, double maxDouble) {
        return minDouble >= maxDouble ? minDouble : new Random().nextDouble() * (maxDouble - minDouble) + minDouble;
    }

    public static void damagePlayer(int damage) {
        Minecraft mc = Minecraft.getMinecraft();
        double i1 = getRandomInRange(0.059, 0.0615);
        double i2 = getRandomInRange(0.049, 0.0625);
        double i3 = getRandomInRange(0.000000500, 0.000000700);
        final PotionEffect potioneffect = mc.thePlayer.getActivePotionEffect(Potion.jump);
        final int f = (potioneffect != null) ? (potioneffect.getAmplifier() + 1) : 0;

        if (mc.thePlayer.onGround && damage > 0) {
            for (int i = 0; i < (float) (mc.thePlayer.getMaxFallHeight() - 1 + Fly.dmgValue.getValueState() + f)
                    / 0.05510000046342611 + 1.0; ++i) {
                (mc.getNetHandler().getNetworkManager()).sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(
                        mc.thePlayer.posX, mc.thePlayer.posY + 0.06011F, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false));
                (mc.getNetHandler().getNetworkManager()).sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(
                        mc.thePlayer.posX, mc.thePlayer.posY + 0.000495765F, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false));
                (mc.getNetHandler().getNetworkManager()).sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(
                        mc.thePlayer.posX, mc.thePlayer.posY + 0.0049575F, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false));
            }
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(mc.thePlayer.posX, mc.thePlayer.posY + 0.0000001, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, true));
        }

    }

    public void onDisable() {
        Wrapper.getTimer().timerSpeed = 1.0f;
    }


}
