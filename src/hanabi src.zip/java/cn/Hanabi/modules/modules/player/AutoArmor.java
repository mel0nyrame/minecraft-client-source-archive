package cn.Hanabi.modules.modules.player;

import cn.Hanabi.events.EventTick;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.TimeLocation.DelayTimer;
import cn.Hanabi.utils.Entity.InvUtils;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

public class AutoArmor extends Mod {
	private final DelayTimer timer = new DelayTimer();
	private final DelayTimer glitchFixer = new DelayTimer();
	private final Value<Boolean> openInv = new Value("AutoArmor_SortInInv", Boolean.valueOf(true));
	private final Value<Double> delay = new Value("AutoArmor_Delay", Double.valueOf(150.0D), Double.valueOf(0.0D),
			Double.valueOf(1000.0D), 10.0D);
	public static boolean isDone = false;

	public AutoArmor() {
		super("AutoArmor", Category.PLAYER);

	}

	@EventTarget
	public void onTick(EventTick event) {
		if (openInv.getValueState()) {
			if (mc.currentScreen == null || !(mc.currentScreen instanceof GuiInventory))
				return;
		} else {
			// Glitch Fix
			if (mc.currentScreen != null)
				this.glitchFixer.reset();

			if (!this.glitchFixer.hasPassed(300))
				return;
		}

		if (!timer.hasPassed(delay.getValue()))
			return;

		if (mc.thePlayer.capabilities.isCreativeMode
				|| (mc.currentScreen != null && !openInv.getValueState())) {
			timer.reset();
			return;
		}

		int slot;

		for (ArmorType armorType : ArmorType.values()) {
			if ((slot = this.findArmor(armorType,
					InvUtils.getArmorScore(mc.thePlayer.inventory.armorItemInSlot(armorType.ordinal())))) != -1) {
				// set
				isDone = false;
				if (mc.thePlayer.inventory.armorItemInSlot(armorType.ordinal()) != null) {
					dropArmor(armorType.ordinal());
					timer.reset();
					return;
				}
				warmArmor(slot);
				timer.reset();
				return;
			} else {
				isDone = true;
			}
		}
	}

	private int findArmor(ArmorType armorType, float minimum) {
		float best = 0;
		int result = -1;

		for (int i = 0; i < mc.thePlayer.inventory.mainInventory.length; i++) {
			ItemStack itemStack = mc.thePlayer.inventory.mainInventory[i];
			if (InvUtils.getArmorScore(itemStack) < 0 || InvUtils.getArmorScore(itemStack) <= minimum
					|| InvUtils.getArmorScore(itemStack) < best || !isValid(armorType, itemStack))
				continue;

			best = InvUtils.getArmorScore(itemStack);
			result = i;
		}

		return result;
	}

	private boolean isValid(ArmorType type, ItemStack itemStack) {
		if (!(itemStack.getItem() instanceof ItemArmor))
			return false;

		ItemArmor armor = (ItemArmor) itemStack.getItem();

		if (type == ArmorType.HELMET && armor.armorType == 0)
			return true;

		if (type == ArmorType.CHEST_PLATE && armor.armorType == 1)
			return true;

		if (type == ArmorType.LEGGINGS && armor.armorType == 2)
			return true;

		return type == ArmorType.BOOTS && armor.armorType == 3;
	}

	private void warmArmor(int slot_In) {
		if (slot_In >= 0 && slot_In <= 8) { // 0-8 is hotbar
			clickSlot(slot_In + 36, 0, true);
		} else {
			clickSlot(slot_In, 0, true);
		}
	}

	private void clickSlot(int slot, int mouseButton, boolean shiftClick) {
		mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot, mouseButton,
				shiftClick ? 1 : 0, mc.thePlayer);
	}

	private void dropArmor(int armorSlot) {
		int slot = InvUtils.armorSlotToNormalSlot(armorSlot);
		if (!InvUtils.isFull()) {

			this.clickSlot(slot, 0, true);
		} else {
			mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot, 1, 4,
					mc.thePlayer);
		}
	}
}

enum ArmorType {
	BOOTS, LEGGINGS, CHEST_PLATE, HELMET
}