package cn.Hanabi.modules.modules.player;

import cn.Hanabi.events.*;
import cn.Hanabi.injection.interfaces.IMinecraft;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;

import java.util.UUID;

public class Freecam extends Mod {
    public Value<Boolean> damage = new Value<Boolean>("Freecam_NoDamage", false);
    public static EntityOtherPlayerMP freecamEntity;


    public Freecam() {
        super("Freecam", Category.PLAYER);
        // TODO Auto-generated constructor stub
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed = 0.2873;
        if (Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.moveSpeed)) {
            int amplifier = Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return baseSpeed;
    }

    @Override
    public void onDisable() {
        mc.thePlayer.setPositionAndRotation(freecamEntity.posX, freecamEntity.posY, freecamEntity.posZ, freecamEntity.rotationYaw, freecamEntity.rotationPitch);
        mc.theWorld.removeEntityFromWorld(freecamEntity.getEntityId());
        mc.renderGlobal.loadRenderers();
        mc.thePlayer.noClip = false;
        super.onDisable();
    }

    @Override
    public void onEnable() {
        if (Freecam.mc.thePlayer == null) {
            return;
        }
        freecamEntity = new EntityOtherPlayerMP(Freecam.mc.theWorld, new GameProfile(new UUID(69, 96), mc.thePlayer.getName()));
        freecamEntity.inventory =mc.thePlayer.inventory;
        freecamEntity.inventoryContainer =mc.thePlayer.inventoryContainer;
        freecamEntity.setPositionAndRotation(Freecam.mc.thePlayer.posX,mc.thePlayer.posY,mc.thePlayer.posZ,mc.thePlayer.rotationYaw,mc.thePlayer.rotationPitch);
        freecamEntity.rotationYawHead =mc.thePlayer.rotationYawHead;
        mc.theWorld.addEntityToWorld(freecamEntity.getEntityId(), freecamEntity);
        mc.renderGlobal.loadRenderers();
        super.onEnable();
    }

    @EventTarget
    public void onMotion(EventPreMotion e){
        mc.thePlayer.noClip = true;
    }
    @EventTarget
    public void onPushBlock(EventPushBlock e){
        e.setCancelled(true);
    }

    @EventTarget
    public void onBB(BBSetEvent e){
        e.setCancelled(true);
    }

    @EventTarget
    public void onPacket(EventPacket e){
        if(damage.getValueState()) {
            if (e.isOutgoing() && e.getPacket() instanceof C03PacketPlayer) {
                e.setCancelled(true);
            }
        }
    }


    @EventTarget
    public void onMove(EventMove e){
        float speed = 5;

        if (Freecam.mc.thePlayer.movementInput.jump) {
            Freecam.mc.thePlayer.motionY = speed;
            e.setY(Freecam.mc.thePlayer.motionY);
        } else if (Freecam.mc.thePlayer.movementInput.sneak) {
            Freecam.mc.thePlayer.motionY = - speed;
            e.setY(Freecam.mc.thePlayer.motionY);
        } else {
            Freecam.mc.thePlayer.motionY = 0.0;
            e.setY(0.0);
        }
        speed = (float)Math.max((double)speed, Freecam.getBaseMoveSpeed());
        double forward = Freecam.mc.thePlayer.movementInput.moveForward;
        double strafe = Freecam.mc.thePlayer.movementInput.moveStrafe;
        float yaw = Freecam.mc.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            e.setX(0.0);
            e.setZ(0.0);
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            double sin = Math.sin(Math.toRadians(yaw + 90.0f));
            double cos = Math.cos(Math.toRadians(yaw + 90.0f));
            e.setX(forward * (double)speed * cos + strafe * (double)speed * sin);
            e.setZ(forward * (double)speed * sin - strafe * (double)speed * cos);
        }
    }


}
