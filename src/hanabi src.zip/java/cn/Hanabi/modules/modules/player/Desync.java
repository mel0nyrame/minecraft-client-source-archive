package cn.Hanabi.modules.modules.player;

import cn.Hanabi.events.EventPacket;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.injection.interfaces.IMinecraft;
import cn.Hanabi.injection.interfaces.IS08PacketPlayerPosLook;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;

public class Desync extends Mod {

    public Desync() {
        super("Desync", Category.PLAYER);
        // TODO Auto-generated constructor stub
    }

    private int lastSlot = -1;

    @EventTarget
    public void onPre(EventPreMotion e) {

    }

    @EventTarget
    public void onUpdate(EventPacket event) {
        if (event.getPacket() instanceof S08PacketPlayerPosLook) {
            IS08PacketPlayerPosLook packet = (IS08PacketPlayerPosLook) event.getPacket();
            packet.setYaw(mc.thePlayer.rotationYaw);
            packet.setPitch(mc.thePlayer.rotationPitch);
        }
    }
}
