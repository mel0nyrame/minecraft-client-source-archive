package cn.Hanabi.modules.modules.player;

import cn.Hanabi.events.EventChat;
import cn.Hanabi.events.EventPacket;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.events.EventRender2D;
import cn.Hanabi.gui.ModCheckUI;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.ProfileUtil;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import com.darkmagician6.eventapi.types.EventType;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.network.play.server.S38PacketPlayerListItem;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ModChecker extends Mod {

    public static String[] modlist = new String[]{"alex_markey", "vislo", "Teddzy", "Timppali", "Unadvised", "fouffy", "teddy3684",
            "KierenBoal", "AcceptedAppeal", "UglyKidSteve", "Swaggle", "Bouncehouses", "AyeItsBeck", "socialisinq", "Kane",
            "Chilo_", "Mu3l", "TrippedUp", "xBenz", "Eunbin", "kvng_steph", "seekingattention", "AZXG", "Cxrtr", "MicroSquid",
            "PorkChopH3X", "W5vil", "Hypnoticxd", "yourbbg", "Vervain", "Abar", "fajoszz", "Incarnati0n_", "JakeOnPc", "iSloth",
            "Bequty_", "Mauricioh", "Minninq", "sinderr", "PistolPet", "mxbel", "Pinkapie", "CoolElla", "DrBrando", "Nikki_",
            "Elecctricc", "kuieren", "6hb", "Swinger", "Rev3rse", "89p", "nonRacist", "Tennente_", "Dionnysus", "Simplistiq",
            "YoureKindaSus", "Darenn", "creeper7777777", "ltself", "Alex_Tila", "TeddyOreo", "kryfex", "Melodieee", "TheKingOfTurtlez",
            "reallylazy", "tjester300", "InsaneIsMyName", "BOGA32", "minifreddusch", "Sir_Cow", "Tringo", "_PolynaLove_", "Aerh", "Pencil",
            "skyerzz", "tjbruce17594", "tom396", "Taytale", "Cera", "arstan", "Extermalizable", "Magicboys", "boomer9", "Kualdir", "mcvisuals",
            "tjommie", "HiitSayZ", "Withur"};
    private String modname;
    public List<String> offlinemod = new ArrayList();
    public List<String> onlinemod = new ArrayList();
    private final Value<Boolean> showOffline = new Value("StaffAnalyzer_ShowOffline", true);
    private final Value<Boolean> showOnline = new Value("StaffAnalyzer_ShowOnline", true);
    private int counter;
    private boolean isFinished = false;
    public static ModCheckUI ui;

    public ModChecker() {
        super("StaffAnalyzer", Category.PLAYER);
        ui = new ModCheckUI(mc, new ScaledResolution(mc));
    }

    @EventTarget
    public void onRender(EventRender2D e) {

    }

    @EventTarget
    public void onChat(EventChat e) {
        if (e.getMessage().contains("for the next"))
            mc.thePlayer.sendChatMessage("/chat a");
        if (e.getMessage().contains("这名玩家不在线！") || e.getMessage().contains("That player is not online!")) {
            e.setCancelled(true);
            if (onlinemod.contains(modname)) {
                PlayerUtil.tellPlayer("\247b\247c" + modname + "\247a已下线！");
                onlinemod.remove(modname);
                offlinemod.add(modname);
                return;
            }
            if (!offlinemod.contains(modname)) {
                PlayerUtil.tellPlayer("\247b\247c" + modname + "\247a不在线！");
                offlinemod.add(modname);
            }
        }

        if (e.getMessage().contains("You cannot message this player.") || e.getMessage().contains("for the next")) {
            e.setCancelled(true);
            if (offlinemod.contains(modname)) {
                PlayerUtil.tellPlayer("\247b\247c" + modname + "\247a已上线！");
                offlinemod.remove(modname);
                onlinemod.add(modname);
                return;
            }
            if (!onlinemod.contains(modname)) {
                PlayerUtil.tellPlayer("\247b\247c" + modname + "\247a在线！");
                onlinemod.add(modname);
            }
        }

        if (e.getMessage().contains("找不到名为 \"" + modname + "\" 的玩家")) {
            System.out.println(modname + "不存在！");
            e.setCancelled(true);
        }
    }

    @EventTarget
    public void onPacket(EventPacket e) {
        if (e.getEventType() == EventType.RECIEVE || !(e.getPacket() instanceof S38PacketPlayerListItem)) {
            return;
        }
        S38PacketPlayerListItem packet = (S38PacketPlayerListItem) e.getPacket();
        packet.getEntries().forEach(object -> {
            if (object == null) {
                return;
            }
            S38PacketPlayerListItem.AddPlayerData data = object;
            boolean match = mc.getNetHandler().getPlayerInfoMap().stream().anyMatch(networkPlayerInfo -> networkPlayerInfo.getGameProfile().getId().equals(data.getProfile().getId()));
            if (!match && packet.getAction() == S38PacketPlayerListItem.Action.UPDATE_LATENCY) {
                new VanishDetectionThread(data.getProfile().getId()).start();
            }
        });
    }

    @EventTarget
    public void onUpdate(EventPreMotion e) {
        if (mc.thePlayer.ticksExisted % 120 == 0) {
            if (counter >= modlist.length) {
                counter = -1;
                if (!isFinished) {
                    isFinished = true;
                }

            }
            counter++;
            modname = modlist[counter];
            mc.thePlayer.sendChatMessage("/msg " + modname);
        }
    }

    class VanishDetectionThread
            extends Thread {
        private final UUID uuid;

        public VanishDetectionThread(UUID uuid) {
            this.uuid = uuid;
        }

        @Override
        public void run() {
            String name = ProfileUtil.INSTANCE.getName(this.uuid);
            if (name == "") {
                return;
            }
            PlayerUtil.tellPlayer("Player " + name + " may be a Staff.");
        }
    }

}
