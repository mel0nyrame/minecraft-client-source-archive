package cn.Hanabi.modules.modules.player;

import cn.Hanabi.events.EventPacket;
import cn.Hanabi.injection.interfaces.IKeyBinding;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import com.darkmagician6.eventapi.types.EventType;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;

import javax.vecmath.Vector3f;
import java.util.ArrayList;

public class Blink extends Mod {
	TimeHelper time = new TimeHelper();
	ArrayList<Packet> packets = new ArrayList<Packet>();

	public Blink() {
		super("Blink", Category.PLAYER);
		setState(false);
		// TODO Auto-generated constructor stub
	}
	@EventTarget
	public void onPacket(EventPacket event) {
		if (event.getEventType() == EventType.SEND) {
			if (event.getPacket() instanceof C03PacketPlayer) {
				packets.add(event.getPacket());
				event.setCancelled(true);
			} else if (event.getPacket() instanceof C08PacketPlayerBlockPlacement
					|| event.getPacket() instanceof C07PacketPlayerDigging
					|| event.getPacket() instanceof C09PacketHeldItemChange
					|| event.getPacket() instanceof C02PacketUseEntity) {
				packets.add(event.getPacket());
				event.setCancelled(true);
			}

		}

		if (event.getEventType() == EventType.RECIEVE) {
			if (event.getPacket() instanceof S08PacketPlayerPosLook) {
				event.setCancelled(true);
			}

		}
	}

	private void addPosition() {
		double x = mc.thePlayer.posX;
		double y = mc.thePlayer.posY;
		double z = mc.thePlayer.posZ;
		Vector3f vec = new Vector3f((float) x, (float) y, (float) z);
		if (mc.thePlayer.movementInput.moveForward != 0.0F || ((IKeyBinding) mc.gameSettings.keyBindJump).getPress()
				|| mc.thePlayer.movementInput.moveStrafe != 0.0F) {
		}

	}

	public void onEnable() {
		EventManager.register(this);
		if (mc.thePlayer != null && mc.theWorld != null) {
			double x = mc.thePlayer.posX;
			double y = mc.thePlayer.posY;
			double z = mc.thePlayer.posZ;
			float yaw = mc.thePlayer.rotationYaw;
			float pitch = mc.thePlayer.rotationPitch;
			EntityOtherPlayerMP ent = new EntityOtherPlayerMP(mc.theWorld, mc.thePlayer.getGameProfile());
			ent.inventory = mc.thePlayer.inventory;
			ent.inventoryContainer = mc.thePlayer.inventoryContainer;
			ent.setPositionAndRotation(x, y, z, yaw, pitch);
			ent.rotationYawHead = mc.thePlayer.rotationYawHead;
			mc.theWorld.addEntityToWorld(-1, ent);
		}

		packets.clear();
	}

	public void onDisable() {
		EventManager.unregister(this);
		mc.theWorld.removeEntityFromWorld(-1);

		for (Packet packet : packets) {
			mc.thePlayer.sendQueue.addToSendQueue(packet);
			time.reset();
		}

		packets.clear();
	}

}
