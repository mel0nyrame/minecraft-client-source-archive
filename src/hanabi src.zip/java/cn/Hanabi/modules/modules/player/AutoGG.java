package cn.Hanabi.modules.modules.player;

import com.darkmagician6.eventapi.EventTarget;

import cn.Hanabi.events.EventPacket;
import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.gui.notifications.Notification;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.utils.Misc.ClientUtil;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import net.minecraft.item.Item;
import net.minecraft.network.play.client.C01PacketChatMessage;
import net.minecraft.network.play.client.C0EPacketClickWindow;
import net.minecraft.network.play.server.S45PacketTitle;

public class AutoGG extends Mod {
	public Value<Boolean> ad = new Value<Boolean>("AutoGG_AD", true);
	public Value<Double> autoPlayDelay = new Value<Double>("AutoPlay_Delay", 3000d, 500d, 10000d, 100d);
	public Value<Double> delay = new Value<Double>("AutoGG_SpeakDelay", 100d, 100d, 3000d, 100d);

	public boolean needSpeak = false;
	public boolean speaked = false;
	public boolean notiSent = false;

	public TimeHelper timer = new TimeHelper();
	public Notification noti = new Notification("", Notification.Type.INFO);

	public String playCommand = "";
	public String lastTitle = "";

	public AutoGG() {
		super("AutoGG", Category.PLAYER);
		// TODO 自动生成的构造函数存根
	}

	@EventTarget
	public void onUpdate(EventUpdate e) {
		if (mc.thePlayer != null) {
			if (needSpeak) {
				if (!speaked && timer.isDelayComplete(delay.getValueState())) {
					speaked = true;
					mc.thePlayer.sendChatMessage("/ac GG" + (ad.getValueState() ? " Buy Hanabi -> Mcheika.com" : ""));
					if (ModManager.getModule("AutoPlay").getState()) ClientUtil.notifications.add(noti);
				}

				if (speaked) {
					if (timer.isDelayComplete(autoPlayDelay.getValueState() + delay.getValueState())) {
						speaked = false;
						needSpeak = false;
						if (ModManager.getModule("AutoPlay").getState()) mc.thePlayer.sendChatMessage(playCommand);
					} else {
						noti.timer.reset();
						noti.message = "Next game will start in " + (autoPlayDelay.getValueState()
								+ delay.getValueState() + timer.getLastMs() - System.currentTimeMillis()) + " ms";
					}
				}
			}
		}
	}

	@EventTarget
	public void onPacket(EventPacket e) {
		if (playCommand.startsWith("/play ")) {
			String display = playCommand.replace("/play ", "").replace("_", " ");
			boolean nextUp = true;
			String result = "";
			for (char c : display.toCharArray()) {
				if (c == ' ') {
					nextUp = true;
					result += " ";
					continue;
				}
				if (nextUp) {
					nextUp = false;
					result += Character.toUpperCase(c);
				} else {
					result += c;
				}
			}
			ModManager.getModule("AutoPlay").setDisplayName(result);
		} else {
			ModManager.getModule("AutoPlay").setDisplayName("Empty");
		}
		
		if (e.getPacket() instanceof S45PacketTitle) {
			S45PacketTitle packet = (S45PacketTitle) e.getPacket();
			String title = packet.getMessage().getFormattedText();
			if (title.startsWith("\247r\2476\247l") && title.endsWith("\247r")) {
				timer.reset();
				needSpeak = true;
			}
			lastTitle = title;
		} else if (e.getPacket() instanceof C0EPacketClickWindow) {
			C0EPacketClickWindow packet = (C0EPacketClickWindow) e.getPacket();
			String itemname = packet.getClickedItem().getDisplayName();
			if (packet.getClickedItem().getDisplayName().startsWith("\247a")) {
				int itemID = Item.getIdFromItem(packet.getClickedItem().getItem());
				if (itemID == 381 || itemID == 368) {
					if (itemname.contains("空岛战争") || itemname.contains("SkyWars")) {
						if (itemname.contains("双人") || itemname.contains("Doubles")) {
							if (itemname.contains("普通") || itemname.contains("Normal")) {
								playCommand = "/play teams_normal";
							} else if (itemname.contains("疯狂") || itemname.contains("Insane")) {
								playCommand = "/play teams_insane";
							}
						} else if (itemname.contains("单挑") || itemname.contains("Solo")) {
							if (itemname.contains("普通") || itemname.contains("Normal")) {
								playCommand = "/play solo_normal";
							} else if (itemname.contains("疯狂") || itemname.contains("Insane")) {
								playCommand = "/play solo_insane";
							}
						}
					}
				} else if (itemID == 355) {
					if (itemname.contains("起床战争") || itemname.contains("Bed Wars")) {
						if (itemname.contains("4v4")) {
							playCommand = "/play bedwars_four_four";
						} else if (itemname.contains("3v3")) {
							playCommand = "/play bedwars_four_three";
						} else if (itemname.contains("双人模式") || itemname.contains("Doubles")) {
							playCommand = "/play bedwars_eight_two";
						} else if (itemname.contains("单挑") || itemname.contains("Solo")) {
							playCommand = "/play bedwars_eight_one";
						}
					}
				} else if (itemID == 346) {
					if (itemname.contains("Duel") || itemname.contains("单挑")) {
						playCommand = "/play duels_classic_duel";
					}
				} else if (itemID == 322){
					if (itemname.contains("Duel") || itemname.contains("单挑")) {
						playCommand = "/play duels_uhc_duel";
					}
				}
			}
		} else if (e.getPacket() instanceof C01PacketChatMessage) {
			C01PacketChatMessage packet = (C01PacketChatMessage) e.getPacket();
			if (packet.getMessage().startsWith("/play")) {
				playCommand = packet.getMessage();
			}
		}
	}

}
