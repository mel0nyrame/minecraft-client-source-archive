package cn.Hanabi.modules.modules.player;

import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.injection.interfaces.IMinecraft;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.item.ItemBlock;

public class FastPlace extends Mod {

	public FastPlace() {
		super("FastPlace", Category.PLAYER);
		// TODO Auto-generated constructor stub
	}

	@EventTarget
	public void onUpdate(EventUpdate e) {

	}
}
