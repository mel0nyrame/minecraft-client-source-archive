package cn.Hanabi.modules.modules.player;

import cn.Hanabi.events.EventPacket;
import cn.Hanabi.events.EventPostMotion;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.injection.interfaces.IC03PacketPlayer;
import cn.Hanabi.injection.interfaces.INetworkManager;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.movement.Fly.Fly;
import cn.Hanabi.utils.Entity.MoveUtils;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.Misc.BlockUtils;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;

public class NoFall extends Mod {
    private final float b = 1.0F;
    private final boolean c = true;
    private final Value mode = new Value("NoFall", "Mode", 0);
    public double fallDist = 0;
    public TimeHelper timer = new TimeHelper();
    double lastFall;
    int times;
    boolean showed;
    private int hypixel1;
    private int d;
    private int state;
    private double actualFallDistance;
    private boolean damage;
    private BlockPos startPos;

    public NoFall() {
        super("NoFall", Category.PLAYER);
        mode.addValue("Hypixel");
        mode.addValue("Mineplex");
        mode.addValue("Spoof");
        mode.addValue("AAC");

    }

    public static boolean isBlockUnder() {
        if (mc.thePlayer.posY < 0.0D) {
            return false;
        } else {
            int off = 0;

            while (true) {
                if (off >= (int) mc.thePlayer.posY + 2) {
                    return false;
                }

                AxisAlignedBB bb = mc.thePlayer.getEntityBoundingBox().offset(0.0D, -off, 0.0D);
                if (!mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, bb).isEmpty()) {
                    return true;
                }

                off += 2;
            }
        }
    }

    public static int getJumpEffect() {
        return mc.thePlayer.isPotionActive(Potion.jump)
                ? mc.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1
                : 0;
    }

    double fall;


    private BlockPos getGroundPos(BlockPos startPos) {
        for (int i = 0; i < startPos.getY(); i++) {
            final BlockPos newPos = startPos.down(i);
            if (BlockUtils.getBlock(newPos) != Blocks.air) {
                return newPos;
            }
        }
        return null;
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mode.isCurrentMode("Hypixel")) {
            setDisplayName("Hypixel");
            if (!BlockUtils.isReallyOnGround()) {
                if (mc.thePlayer.motionY < -0.08) {
                    fall -= mc.thePlayer.motionY;
                }
                if (fall > 2) {
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(false));
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
                    fall = 0;
                }
            } else fall = 0;
//            float falldis = 1.625f + (float) MoveUtils.getJumpEffect();
//            if (mc.thePlayer.fallDistance - this.lastFall >= falldis) {
//                this.lastFall = mc.thePlayer.fallDistance;
//                PlayerUtil.debug("Packet");
//                ((INetworkManager) mc.getNetHandler().getNetworkManager()).sendPacketNoEvent(new C03PacketPlayer(true));
//            } else if (mc.thePlayer.isCollidedVertically) {
//                this.lastFall = 0f;
//            }


        }
        if (mode.isCurrentMode("Mineplex")) {
            setDisplayName("Mineplex");
            if (mc.thePlayer.fallDistance > 2.5F) {
                (mc.getNetHandler().getNetworkManager()).sendPacket(new C03PacketPlayer(true));
                mc.thePlayer.fallDistance = 0.5F;
            }
        }

        if (mode.isCurrentMode("AAC")) {
            if (mc.thePlayer.fallDistance > (3 + MoveUtils.getJumpEffect())) {

                if (!mc.thePlayer.onGround) {
                    mc.thePlayer.motionY = -200;
                }
            }
        }
    }

    @Override
    public void onEnable() {
        fallDist = mc.thePlayer.fallDistance;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    double fallDist1;


    @EventTarget
    public void onPacket(EventPacket e) {
        IC03PacketPlayer packet = (IC03PacketPlayer) e.getPacket();
        if (mode.isCurrentMode("Spoof")) {
            if (e.getPacket() instanceof C03PacketPlayer) {
                if (mc.thePlayer.fallDistance > 3.0F) {
                    ((IC03PacketPlayer) e.packet).setOnGround(true);
                }
            }
        }
    }
}
