package cn.Hanabi.modules.modules.player;

import cn.Hanabi.command.commands.PrefixCommand;
import cn.Hanabi.command.commands.SpammerCommand;
import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;

import java.io.IOException;
import java.util.Random;

public class Spammer extends Mod {
	public static String text = "Hanabi Hacked Client Code by Margele.";
	public static String prefix = "[Hanabi]";
	TimeHelper delay = new TimeHelper();
	Random random = new Random();
	double state = 0.0D;
	private final Value<Double> spammerdelay = new Value("Spammer_Delay", 2000.0D, 500.0D, 10000.0D, 100D);
	private final Value<Boolean> randomstring = new Value<Boolean>("Spammer_RandomString", true);
	private int num;

	public Spammer() {
		super("Spammer", Category.PLAYER);
	}

	@EventTarget
	public void onUpdate(EventUpdate event) {
		this.setDisplayName("Delay:" + spammerdelay.getValueState() + " Times:" + num);
		try {
			SpammerCommand.loadText();
			PrefixCommand.loadText();
		} catch (IOException e) {
			e.printStackTrace();
		}

		if (this.delay.isDelayComplete(spammerdelay.getValueState().longValue())) {
			++this.state;
			num++;
			String message = prefix + text;
			if (randomstring.getValueState()) {
				message = message + " >" + new StringRandom().getStringRandom(6) + "<";
			}
			mc.thePlayer.sendChatMessage(message);
			this.delay.reset();
		}
	}

	public void onDisable() {
		this.state = 0.0D;
		num = 0;
		super.onDisable();
	}

	public class StringRandom {
		public String getStringRandom(int length) {

			String val = "";
			Random random = new Random();

			for (int i = 0; i < length; i++) {

				String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
				if ("char".equalsIgnoreCase(charOrNum)) {
					int temp = random.nextInt(2) % 2 == 0 ? 65 : 97;
					val += (char) (random.nextInt(26) + temp);
				} else if ("num".equalsIgnoreCase(charOrNum)) {
					val += String.valueOf(random.nextInt(10));
				}
			}
			return val;
		}
	}
}
