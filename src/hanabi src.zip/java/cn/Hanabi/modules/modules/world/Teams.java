package cn.Hanabi.modules.modules.world;

import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;

public class Teams extends Mod {
	public static Value<Boolean> clientfriend = new Value("Teams_ClientFriends", true);
	TimeHelper timer = new TimeHelper();

	static boolean clientfriendOld;

	public Teams() {
		super("Teams", Category.PLAYER);
	}

	public void onDisable() {

	}

	public static boolean isOnSameTeam(Entity entity) {
		if (ModManager.getModule("Teams").isEnabled()) {
			if (Minecraft.getMinecraft().thePlayer.getDisplayName().getUnformattedText().startsWith("\247")) {
                if (Minecraft.getMinecraft().thePlayer.getDisplayName().getUnformattedText().length() <= 2
                        || entity.getDisplayName().getUnformattedText().length() <= 2) {
                    return false;
                }
                return Minecraft.getMinecraft().thePlayer.getDisplayName().getUnformattedText().substring(0, 2)
                        .equals(entity.getDisplayName().getUnformattedText().substring(0, 2));
            }
		}
		return false;
	}

}
