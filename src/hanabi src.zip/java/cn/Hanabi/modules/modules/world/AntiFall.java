package cn.Hanabi.modules.modules.world;

import cn.Hanabi.events.EventKey;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.BlockAir;
import net.minecraft.util.BlockPos;
import org.lwjgl.input.Keyboard;

public class AntiFall extends Mod {

	BlockPos lastGroundPos;
	TimeHelper timer = new TimeHelper();
	TimeHelper timer2 = new TimeHelper();
	TimeHelper spacetimer = new TimeHelper();
	public static Value<Double> falldistance = new Value("AntiFall_FallDistance", 10d, 5d, 30d, 0.1d);
	public Value<Boolean> onlyvoid = new Value("AntiFall_OnlyVoid", true);

	public AntiFall() {
		super("AntiFall", Category.WORLD);
		// TODO 自动生成的构造函数存根
	}

	@EventTarget
	public void onKey(EventKey e) {
		if (e.getKey() == Keyboard.KEY_SPACE) {
			spacetimer.reset();
		}
	}

	private boolean isBlockUnder() {
		for (int i = (int) (mc.thePlayer.posY - 1.0); i > 0; --i) {
			BlockPos pos = new BlockPos(mc.thePlayer.posX, i, mc.thePlayer.posZ);
			if (mc.theWorld.getBlockState(pos).getBlock() instanceof BlockAir)
				continue;
			return true;
		}
		return false;
	}

	@EventTarget
	public void onUpdate(EventPreMotion e) {
		boolean blockUnderneath = true;
		if (mc.thePlayer.fallDistance > falldistance.getValueState() && !(onlyvoid.getValueState() && isBlockUnder()))
			blockUnderneath = false;

		if (mc.thePlayer.onGround && timer.isDelayComplete(1000)) {
			lastGroundPos = mc.thePlayer.getPosition();
			timer.reset();
		}

		if (!blockUnderneath && spacetimer.isDelayComplete(800) && !ModManager.getModule("Fly").isEnabled()) {
			e.x = lastGroundPos.getX();
			e.y = lastGroundPos.getY();
			e.z = lastGroundPos.getZ();
		}
	}

}
