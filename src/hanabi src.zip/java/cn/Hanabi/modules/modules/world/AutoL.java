package cn.Hanabi.modules.modules.world;

import cn.Hanabi.Hanabi;
import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Misc.AbuseUtil;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import net.minecraft.entity.player.EntityPlayer;

import java.util.ArrayList;
import java.util.List;

import com.darkmagician6.eventapi.EventTarget;

public class AutoL extends Mod {

	public static TimeHelper LTimer = new TimeHelper();
	public static Value<Boolean> ad = new Value("AutoL_AD", true);
	public static Value<Boolean> wdr = new Value("AutoL_AutoReport", true);
	public static Value<Boolean> clientname = new Value("AutoL_ClientName", true);

	public static Value<Boolean> abuse = new Value("AutoL_Abuse", false);
	public static List<String> wdred = new ArrayList();

	public static List<EntityPlayer> power = new ArrayList<EntityPlayer>();

	public AutoL() {
		super("AutoL", Category.WORLD);

	}

	@EventTarget
	public void onUpdate(EventUpdate e) {

		this.setDisplayName("English");

	}

	public static String getAutoLMessage(String PlayerName) {
		String abuse = "";
		abuse = AbuseUtil.getAbuseGlobal();

		return "/ac " + (AutoL.clientname.getValueState() ? "[" + Hanabi.CLIENT_NAME + "] " : "") + PlayerName + " L"
				+ (AutoL.abuse.getValueState() ? " " + abuse : "");
	}
}





