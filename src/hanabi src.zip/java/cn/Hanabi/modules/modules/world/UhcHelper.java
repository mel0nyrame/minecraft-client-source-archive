package cn.Hanabi.modules.modules.world;

import cn.Hanabi.events.EventPacket;
import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockHopper;
import net.minecraft.item.ItemShears;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity;
import net.minecraft.util.*;
import net.minecraft.world.WorldSettings;
import org.lwjgl.input.Keyboard;

public class UhcHelper extends Mod {

    public Value<Boolean> sandbreak = new Value<Boolean>("UHCHelper_SandBreaker", false);
    public Value<Boolean> LightningCheck = new Value<Boolean>("UHCHelper_LightningCheck", false);
    public Value<Boolean> autoSneak = new Value<Boolean>("UHCHelper_AutoSneak", false);
    public static int movement;
    public Value<Boolean> noSandDamage = new Value<Boolean>("UHCHelper_noSandDamage", false);
    public Value<Boolean> noWaterDamage = new Value<Boolean>("UHCHelper_noWaterDamage", false);
    public Value<Boolean> lessPacket = new Value<Boolean>("UHCHelper_lessPacket", false);
    boolean sneak = false;
    public static int x;
    public static int y;
    public static int z;
    TimeHelper sneakTimer = new TimeHelper();
    int clock;
    int delay;
    public UhcHelper() {
        super("UHCHelper", Category.WORLD);
    }

    /* AntiObf By Kody Edit By VanillaMirror */
    @EventTarget
    public void OnUpdate(EventUpdate e) {
        BlockPos sand = new BlockPos(new Vec3(mc.thePlayer.posX, mc.thePlayer.posY + 3, mc.thePlayer.posZ));
        Block sandblock = mc.theWorld.getBlockState(sand).getBlock();
        BlockPos forge = new BlockPos(new Vec3(mc.thePlayer.posX, mc.thePlayer.posY + 2, mc.thePlayer.posZ));
        Block forgeblock = mc.theWorld.getBlockState(forge).getBlock();
        BlockPos obsidianpos = new BlockPos(new Vec3(mc.thePlayer.posX, mc.thePlayer.posY + 1, mc.thePlayer.posZ));
        Block obsidianblock = mc.theWorld.getBlockState(obsidianpos).getBlock();

        if (obsidianblock == Block.getBlockById(49)) {
            bestTool(mc.objectMouseOver.getBlockPos().getX(), mc.objectMouseOver.getBlockPos().getY(),
                    mc.objectMouseOver.getBlockPos().getZ());
            BlockPos downpos = new BlockPos(new Vec3(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ));
            mc.playerController.onPlayerDamageBlock(downpos, EnumFacing.UP);
        }
        if (forgeblock == Block.getBlockById(61)) {
            bestTool(mc.objectMouseOver.getBlockPos().getX(), mc.objectMouseOver.getBlockPos().getY(),
                    mc.objectMouseOver.getBlockPos().getZ());
            BlockPos downpos = new BlockPos(new Vec3(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ));
            mc.playerController.onPlayerDamageBlock(downpos, EnumFacing.UP);
        }

        if (sandbreak.getValueState()) {
            if (sandblock == Block.getBlockById(12) || sandblock == Block.getBlockById(13)) {
                bestTool(mc.objectMouseOver.getBlockPos().getX(), mc.objectMouseOver.getBlockPos().getY(),
                        mc.objectMouseOver.getBlockPos().getZ());
                BlockPos downpos = new BlockPos(new Vec3(mc.thePlayer.posX, mc.thePlayer.posY + 3, mc.thePlayer.posZ));
                PlayerUtil.tellPlayer("Sand On your Head. Care for it :D");
                mc.playerController.onPlayerDamageBlock(downpos, EnumFacing.UP);
            }
        }
        if (autoSneak.getValueState()) {
            if (!sneak && sneakTimer.isDelayComplete(2000)) {
                sneak = true;
            }
        }

        if (sneak){

        }

        if (lessPacket.getValueState()) {
            mc.thePlayer.setGameType(WorldSettings.GameType.SURVIVAL);
            mc.thePlayer.setGameType(WorldSettings.GameType.CREATIVE);
            if (mc.thePlayer.onGround) {
                mc.thePlayer.motionX *= 1.005F;
                mc.thePlayer.motionZ *= 1.005F;
            }
        }


    }

    @EventTarget
    public void onPacketReceive(EventPacket packetEvent) {
        if (noSandDamage.getValueState()) {
            if (packetEvent.packet instanceof C03PacketPlayer) {
                if (this.isInsideBlock()) {
                    packetEvent.setCancelled(true);
                }
            }
        }
        if (noWaterDamage.getValueState()) {
            if (packetEvent.packet instanceof C03PacketPlayer) {
                if ((PlayerUtil.isInWater() && Keyboard.isKeyDown(Keyboard.KEY_LSHIFT))) {
                    packetEvent.setCancelled(true);
                }
            }
        }

        if (LightningCheck.getValueState()) {
            if (packetEvent.packet instanceof S2CPacketSpawnGlobalEntity) {
                S2CPacketSpawnGlobalEntity packetIn = (S2CPacketSpawnGlobalEntity) packetEvent.packet;
                if (packetIn.func_149053_g() == 1) {
                    x = (int) ((double) packetIn.func_149051_d() / 32.0D);
                    y = (int) ((double) packetIn.func_149050_e() / 32.0D);
                    z = (int) ((double) packetIn.func_149049_f() / 32.0D);
                    PlayerUtil.tellPlayer("Found Lightning X:" + x + "-Y:" + y + "-Z:" + z);
                }
            }
        }
    }

    @Override
    public void onEnable() {
        if (noWaterDamage.getValueState()) {
            PlayerUtil.tellPlayer("Lshift In Water To Enable Water GodMode");
        }
        sneakTimer.reset();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        if (lessPacket.getValueState()) {
            if(mc.thePlayer.capabilities.isCreativeMode){
                mc.thePlayer.setGameType(WorldSettings.GameType.CREATIVE);
            }else {
                mc.thePlayer.setGameType(WorldSettings.GameType.SURVIVAL);
            }
        }
        sneakTimer.reset();
        super.onDisable();
    }

    private boolean isInsideBlock() {
        for (int x = MathHelper.floor_double(Phase.mc.thePlayer.getEntityBoundingBox().minX); x < MathHelper
                .floor_double(Phase.mc.thePlayer.getEntityBoundingBox().maxX) + 1; ++x) {
            for (int y = MathHelper.floor_double(Phase.mc.thePlayer.getEntityBoundingBox().minY); y < MathHelper
                    .floor_double(Phase.mc.thePlayer.getEntityBoundingBox().maxY) + 1; ++y) {
                for (int z = MathHelper.floor_double(Phase.mc.thePlayer.getEntityBoundingBox().minZ); z < MathHelper
                        .floor_double(Phase.mc.thePlayer.getEntityBoundingBox().maxZ) + 1; ++z) {
                    final Block block = Phase.mc.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                    if (block != null && !(block instanceof BlockAir) && (block.isFullBlock())) {
                        AxisAlignedBB boundingBox = block.getCollisionBoundingBox(Phase.mc.theWorld,
                                new BlockPos(x, y, z), Phase.mc.theWorld.getBlockState(new BlockPos(x, y, z)));
                        if (block instanceof BlockHopper) {
                            boundingBox = new AxisAlignedBB(x, y, z, x + 1, y + 1, z + 1);
                        }
                        if (boundingBox != null && Phase.mc.thePlayer.getEntityBoundingBox().intersectsWith(boundingBox)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public void bestTool(int x, int y, int z) {
        int blockId = Block.getIdFromBlock(mc.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock());
        int bestSlot = 0;
        float f = -1F;
        for (int i1 = 36; i1 < 45; i1++)
            try {
                ItemStack curSlot = mc.thePlayer.inventoryContainer.getSlot(i1).getStack();
                if (((curSlot.getItem() instanceof ItemTool) || (curSlot.getItem() instanceof ItemSword)
                        || (curSlot.getItem() instanceof ItemShears))
                        && curSlot.getStrVsBlock(Block.getBlockById(blockId)) > f) {
                    bestSlot = i1 - 36;
                    f = curSlot.getStrVsBlock(Block.getBlockById(blockId));
                }
            } catch (Exception exception) {
            }

        if (f != -1F) {
            mc.thePlayer.inventory.currentItem = bestSlot;
            mc.playerController.updateController();
        }
    }
}
