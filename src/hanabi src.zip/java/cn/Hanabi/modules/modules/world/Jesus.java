package cn.Hanabi.modules.modules.world;

import com.darkmagician6.eventapi.EventTarget;

import cn.Hanabi.events.BBSetEvent;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.events.EventJump;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Misc.BlockUtils;
import cn.Hanabi.utils.TimeLocation.DelayTimer;
import cn.Hanabi.value.Value;
import net.minecraft.block.BlockLiquid;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

public class Jesus extends Mod {
    private static final Value mode = new Value("Jesus", "Mode", 0);

    public Jesus() {
        super("Jesus", Category.WORLD);
        mode.addValue("Solid");
        mode.addValue("Motion");
        //mode.addValue("BHop");

    }

    private final DelayTimer timer = new DelayTimer();

    @EventTarget
    public void onBounding(BBSetEvent event) {
        if (mode.isCurrentMode("Solid")) {
            if (event.getBlock() instanceof BlockLiquid && !mc.thePlayer.isInWater()
                    && !mc.thePlayer.isInLava() && this.isPossible(event.pos)) {
                event.setBoundingBox(new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 1.0, 1.0).contract(0.0, 2.0E-12, 0.0)
                        .offset(event.getPos().getX(), event.getPos().getY(), event.getPos().getZ()));

            }
        }
	}

	@EventTarget
	public void onPacket(EventPreMotion event) {
		if (mode.isCurrentMode("Solid")) {
            if (mc.thePlayer.onGround && !mc.thePlayer.isInWater() && BlockUtils.isOnLiquid()
                    && !mc.thePlayer.isSneaking()) {
                event.y += mc.thePlayer.ticksExisted % 2 == 0 ? 2.0E-12 : 0.0;
            }
        }
	}

	@EventTarget
	public void onJump(EventJump event) {
		if (mode.isCurrentMode("Solid")) {
            if (mc.thePlayer.onGround && !mc.thePlayer.isInWater() && BlockUtils.isOnLiquid()
                    && !mc.thePlayer.isSneaking())
                event.setCancelled(true);
        }
	}

	@EventTarget
	public void onUpdatePre(EventPreMotion event) {
        if (BlockUtils.isInLiquid() && mc.thePlayer.movementInput.jump) {
            mc.thePlayer.movementInput.jump = false;
            mc.thePlayer.setJumping(false);
        }

        if (mode.isCurrentMode("Motion")) {
            if (BlockUtils.isInLiquid()) {
                mc.thePlayer.motionY = 0.1;
            }
            return;
        }

        if (mode.isCurrentMode("BHop")) {
            if (BlockUtils.isInLiquid() && timer.hasPassed(200) && !mc.gameSettings.keyBindSneak.isKeyDown()
                    && !mc.thePlayer.isInWater()) {
                float forward = mc.thePlayer.movementInput.moveForward;
                float strafe = mc.thePlayer.movementInput.moveStrafe;

                if ((forward != 0.0F || strafe != 0.0F)) {
                    mc.thePlayer.motionX = 0;
                    mc.thePlayer.motionZ = 0;

                    // jump
                    mc.thePlayer.motionY = 0.4D;
                    mc.thePlayer.isAirBorne = true;

                    // move
                    float var4 = strafe * strafe + forward * forward;
                    var4 = MathHelper.sqrt_float(var4);

                    if (var4 < 1.0F) {
                        var4 = 1.0F;
                    }

                    var4 = 0.26f / var4;
                    strafe *= var4;
                    forward *= var4;
                    float var5 = MathHelper.sin(mc.thePlayer.rotationYaw * (float) Math.PI / 180.0F);
                    float var6 = MathHelper.cos(mc.thePlayer.rotationYaw * (float) Math.PI / 180.0F);
                    mc.thePlayer.motionX += strafe * var6 - forward * var5;
                    mc.thePlayer.motionZ += forward * var6 + strafe * var5;

                    timer.reset();
                } else {
                    mc.thePlayer.motionX = 0;
                    mc.thePlayer.motionZ = 0;

                    mc.thePlayer.motionY = 0.085D;
                }
            } else if (mc.thePlayer.isInWater() && mc.thePlayer.movementInput.jump) {
                mc.thePlayer.motionY = 0.08;
            }
			return;
		}
	}

	private boolean isPossible(BlockPos pos) {
        final int i = mc.theWorld.getBlockState(pos).getBlock()
                .getMetaFromState(mc.theWorld.getBlockState(pos));
        return i < 5 && mc.thePlayer.fallDistance <= 3.0f && !mc.thePlayer.isSneaking();
    }

	private boolean isAboveLiquid() {
		return mc.theWorld.getBlockState(
				new BlockPos(mc.thePlayer.posX, mc.thePlayer.getEntityBoundingBox().maxY - 0.75, mc.thePlayer.posZ))
				.getBlock() instanceof BlockLiquid;
	}

}