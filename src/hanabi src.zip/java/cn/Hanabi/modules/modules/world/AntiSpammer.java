package cn.Hanabi.modules.modules.world;

import java.util.ArrayList;

import com.darkmagician6.eventapi.EventTarget;

import cn.Hanabi.events.EventPacket;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Levenshtein;
import cn.Hanabi.value.Value;
import net.minecraft.network.play.server.S02PacketChat;

public class AntiSpammer extends Mod {
	public Value<Double> history = new Value<Double>("AntiSpammer_HistoryMessage", 10d, 3d, 30d, 1d);
	public Value<Double> ratio = new Value<Double>("AntiSpammer_Ratio", 0.6d, 0.1d, 1d, 0.01d);
	
	public ArrayList<String> historyChat = new ArrayList<String>();
	
	public static final Levenshtein lt = new Levenshtein();
	
	public AntiSpammer() {
		super("AntiSpammer", Category.WORLD);
	}
	
	@EventTarget
	public void onFuckingPacket(EventPacket motherfucker) {
		if (mc.thePlayer != null && mc.theWorld != null && motherfucker.getPacket() instanceof S02PacketChat) {
			S02PacketChat packet = (S02PacketChat) motherfucker.getPacket();
			String message = packet.getChatComponent().getFormattedText().replaceAll("\247.", "").replaceAll("[.*?]", "").replaceAll("<.*?>", "");
			String result = "";
			int isSpace = 0;
			
			for (char c : message.toCharArray()) {
				if (c == ' ') {
					isSpace++;
				}
				if (isSpace >= 2) result += c;
			}
			
			result = result.replace(" ", "");
			
			for (String history : historyChat) {
				double similar = lt.getSimilarityRatio(result, history);
				if (similar > ratio.getValueState()) {
					if (this.getDisplayName() != null) {
						this.setDisplayName((Integer.valueOf(this.getDisplayName()) + 1) + "");
					} else {
						this.setDisplayName(1 + "");
					}
					
					motherfucker.setCancelled(true);
					break;
				}
			}
			
			historyChat.add(result);
			if (historyChat.size() > history.getValueState().intValue()) historyChat.remove(0);
		}
	}
}
