package cn.Hanabi.modules.modules.world;

import cn.Hanabi.events.DamageBlockEvent;
import cn.Hanabi.events.EventPacket;
import cn.Hanabi.events.EventPostMotion;
import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.injection.interfaces.IPlayerControllerMP;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class SpeedMine extends Mod {
    private boolean bzs = false;
    private float bzx = 0.0f;
    public BlockPos blockPos;
    public EnumFacing facing;
    public C07PacketPlayerDigging curPacket;
    public Value<Boolean> C03 = new Value<Boolean>("SpeedMine_Boost", false);
    public Value<Boolean> pot = new Value<Boolean>("SpeedMine_PotBoost", false);
    public Value<Boolean> ultraBoost = new Value<Boolean>("SpeedMine_UltraBoost", false);

    public SpeedMine() {
        super("SpeedMine", Category.WORLD);
    }

    @EventTarget
    public void onDamageBlock(EventPacket event) {
        if (event.packet instanceof C07PacketPlayerDigging && event.getPacket() != curPacket && !mc.playerController.extendedReach() && mc.playerController != null) {
            C07PacketPlayerDigging c07PacketPlayerDigging = (C07PacketPlayerDigging) event.packet;
            if (c07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                this.bzs = true;
                this.blockPos = c07PacketPlayerDigging.getPosition();
                this.facing = c07PacketPlayerDigging.getFacing();
                this.bzx = 0.0f;
            } else if (c07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK || c07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
                this.bzs = false;
                this.blockPos = null;
                this.facing = null;
            }
        }
    }
    private boolean canBreak(BlockPos pos) {
        final IBlockState blockState = mc.theWorld.getBlockState(pos);
        final Block block = blockState.getBlock();
        return block.getBlockHardness(mc.theWorld, pos) != -1;
    }

    public boolean packet = true;
    public boolean damage = true;

    @EventTarget
    public void onBreak(DamageBlockEvent event) {
        if (canBreak(event.getPos())) {
            if (ultraBoost.getValueState()) {
                mc.thePlayer.swingItem();
                mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK ,event.getPos(), event.getFace()));
                mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.getPos(), event.getFace()));
            }
            if (ultraBoost.getValueState()) {
                IPlayerControllerMP controller = (IPlayerControllerMP) mc.playerController;
                controller.setBlockHitDelay(0);
                if (controller.getCurBlockDamageMP() >= 0.7F) {
                    controller.setCurBlockDamageMP(1.0F);
                }
            }
        }
    }



    @EventTarget
    public void onUpdate(EventUpdate event) {
        IPlayerControllerMP controller = (IPlayerControllerMP) mc.playerController;

        if (pot.getValueState()) {
            mc.thePlayer.addPotionEffect(new PotionEffect(Potion.digSpeed.getId(), 100, 1));

        }

        if (mc.playerController.extendedReach()) {
            controller.setBlockHitDelay(0);
            if (controller.getCurBlockDamageMP() >= 0.6F) {
                controller.setCurBlockDamageMP(1.0F);
            }

        } else if (this.bzs) {
            Block block = mc.theWorld.getBlockState(this.blockPos).getBlock();
            this.bzx += block.getPlayerRelativeBlockHardness(mc.thePlayer, mc.theWorld, this.blockPos) * 1.4;
            if (this.bzx >= 1.0f) {
                mc.theWorld.setBlockState(this.blockPos, Blocks.air.getDefaultState(), 11);
                C07PacketPlayerDigging packet = new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.blockPos, this.facing);
                curPacket = packet;
                if (C03.getValueState()) {
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, true));
                }
                mc.thePlayer.sendQueue.getNetworkManager().sendPacket(packet);

                this.bzx = 0.0f;
                this.bzs = false;
            }
        }
    }
}
