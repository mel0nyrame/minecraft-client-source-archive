package cn.Hanabi.gui;

import cn.Hanabi.Hanabi;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.player.ModChecker;
import cn.Hanabi.utils.Misc.ClientUtil;
import cn.Hanabi.utils.Misc.Colors;
import cn.Hanabi.utils.MouseInputHandler;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.utils.fontmanager.HanabiFonts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;

public class ModCheckUI {
	
	public boolean isDragging = false;
	
	public float x = 0;
	public float y = 0;
	
	public int x2;
    public int y2;
    
    public boolean isExtended = false;
    public float rectYSize;
    public float animationY;
    
    private final MouseInputHandler handler = new MouseInputHandler(0);
    
    public Minecraft mc;
    public ScaledResolution sr;

	private final String fileDir;

    public ModCheckUI(Minecraft mc, ScaledResolution sr) {
    	this.fileDir = mc.mcDataDir.getAbsolutePath() + "/" + Hanabi.CLIENT_NAME;
    	this.mc = mc;
    	this.sr = sr;
    	this.loadFile();
    	
		/*
		 * try { if
		 * (!Hanabi.AES_UTILS.decrypt(Hanabi.HWID_VERIFY).contains(Wrapper.getHWID())) {
		 * FMLCommonHandler.instance().exitJava(0, true); Client.sleep = true; } } catch
		 * (Exception e) { FMLCommonHandler.instance().exitJava(0, true); Client.sleep =
		 * true; }
		 * 
		 */
    }
   
    public void draw() {
		this.sr = new ScaledResolution(mc);
		ModChecker modChecker = ModManager.getModule(ModChecker.class);
		if (!modChecker.onlinemod.isEmpty()) {
			if (this.isExtended) {
				float startY = 13;
				for (String s : modChecker.onlinemod) {
					startY += Hanabi.INSTANCE.fontManager.wqy16.getStringHeight(s);
				}
				this.rectYSize = startY + 2;
			} else {
				this.rectYSize = 10;
			}
    	} else {
    		if(this.isExtended) {
    			this.rectYSize = 25;
    		} else {
    			this.rectYSize = 10;
    		}
    	}
    	
    	//动画
    	this.animationY = (float) RenderUtil.getAnimationState(this.animationY, this.rectYSize, Math.max(10, (Math.abs(this.animationY - this.rectYSize)) * 30) * 0.3);
    	this.drawRoundedRect(x, y + 10, x + 80, y + this.animationY, ClientUtil.reAlpha(Colors.WHITE.c, 0.5f), ClientUtil.reAlpha(Colors.WHITE.c, 0.5f));
    	
    	//渲染在线Mod名称
    	if(!modChecker.onlinemod.isEmpty()) {
    		if(this.isExtended) {
    			float startY = y + 13;
        		for(String s : modChecker.onlinemod) {
        			
        			if(y + this.animationY > startY) {
            	    	Hanabi.INSTANCE.fontManager.wqy16.drawString(s, x + 2, startY, Colors.GREY.c);
        			}
        			
        	    	startY += Hanabi.INSTANCE.fontManager.wqy16.getStringHeight(s);
        		}
    		} else if(!this.isExtended && this.animationY > 10) {
    			float startY = y + 13;
        		for(String s : modChecker.onlinemod) {
        			
        			if(y + this.animationY > startY) {
            	    	Hanabi.INSTANCE.fontManager.wqy16.drawString(s, x + 2, startY, Colors.GREY.c);
        			}
        			
        	    	startY += Hanabi.INSTANCE.fontManager.wqy16.getStringHeight(s);
        		}
    		}
    	} else {
    		if(this.isExtended) {
    			if(this.animationY + y > y + 22) {
					Hanabi.INSTANCE.fontManager.wqy16.drawString("All Helper r offline", x + 2, y + 14, Colors.GREY.c);
				}
			}
		}


		//窗口标题渲染
		int col1 = new Color(0xff1d6fdf).brighter().getRGB();
		this.drawRoundedRect(x, y, x + 80, y + 13, col1, col1);

		Hanabi.INSTANCE.fontManager.wqy16.drawString("Helpder List (" + modChecker.onlinemod.size() + "/" + ModChecker.modlist.length + ")", x + 2, y + 2, Colors.WHITE.c);
		Hanabi.INSTANCE.fontManager.icon16.drawString(this.isExtended ? HanabiFonts.ICON_CLICKGUI_ARROW_DOWN : HanabiFonts.ICON_CLICKGUI_ARROW_UP, x + 70, y + 2, Colors.WHITE.c);

	}
    
    public void mouseListener(int mouseX, int mouseY) {
    	this.moveWindow(mouseX, mouseY);
    	
    	if(this.isHovering(mouseX, mouseY, x + 70, y + 2, x + 78, y + 12) && this.handler.canExcecute()) {
    		this.isExtended = !this.isExtended;
    	}
    }
    
    public void moveWindow(int mouseX, int mouseY) {
		
    	if(this.isHovering(mouseX, mouseY, x + 70, y + 2, x + 78, y + 12)) return;
    	
    	if (this.isHoveringWindow(mouseX, mouseY) && this.handler.canExcecute()) {
			this.isDragging = true;
            this.x2 = (int) (mouseX - this.x);
            this.y2 = (int) (mouseY - this.y);
        }
		
		if (this.isDragging) {
            this.x = mouseX - this.x2;
            this.y = mouseY - this.y2;
        }
		
		if(!Mouse.isButtonDown(0) && this.isDragging) {
			this.isDragging = false;
			this.saveFile();
		}
	}
    
    public void loadFile() {
		
		File coordFile = new File(this.fileDir + "/modCheckerCoord.txt");
				
		try {
			if (!coordFile.exists()) {
				coordFile.createNewFile();
			}
			
			String line;
			BufferedReader br = new BufferedReader(new FileReader(coordFile));
			
			while ((line = br.readLine()) != null) {
				String[] split = line.split(":");
				this.x = Float.valueOf(split[0]);
				this.y = Float.valueOf(split[1]);
			}
			
			br.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		
	}
	
	public void saveFile() {
		File coord = new File(this.fileDir + "/modCheckerCoord.txt");
		try {
			if (!coord.exists()) {
				coord.createNewFile();
			}

			PrintWriter coordWriter = new PrintWriter(coord);

			coordWriter.write(x + ":" + y);

			coordWriter.close();

			System.out.println("Saved ModChecker Coords File!");

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void drawRoundedRect(float x, float y, float x1, float y1, int borderC, int insideC) {
		enableGL2D();
		GL11.glScalef(0.5f, 0.5f, 0.5f);
		drawVLine(x *= 2.0f, (y *= 2.0f) + 1.0f, (y1 *= 2.0f) - 2.0f, borderC);
		drawVLine((x1 *= 2.0f) - 1.0f, y + 1.0f, y1 - 2.0f, borderC);
		drawHLine(x + 2.0f, x1 - 3.0f, y, borderC);
		drawHLine(x + 2.0f, x1 - 3.0f, y1 - 1.0f, borderC);
		drawHLine(x + 1.0f, x + 1.0f, y + 1.0f, borderC);
		drawHLine(x1 - 2.0f, x1 - 2.0f, y + 1.0f, borderC);
		drawHLine(x1 - 2.0f, x1 - 2.0f, y1 - 2.0f, borderC);
		drawHLine(x + 1.0f, x + 1.0f, y1 - 2.0f, borderC);
		RenderUtil.drawRect(x + 1.0f, y + 1.0f, x1 - 1.0f, y1 - 1.0f, insideC);
		GL11.glScalef(2.0f, 2.0f, 2.0f);
		disableGL2D();
	}

	public void drawHLine(float x, float y, float x1, int y1) {
		if (y < x) {
			float var5 = x;
			x = y;
			y = var5;
		}
		RenderUtil.drawRect(x, x1, y + 1, x1 + 1, y1);
	}

	public void drawVLine(float x, float y, float x1, int y1) {
		if (x1 < y) {
			float var5 = y;
			y = x1;
			x1 = var5;
		}
		RenderUtil.drawRect(x, y + 1, x + 1, x1, y1);
	}

	public void color(int color) {
		float f = (float) (color >> 24 & 255) / 255.0f;
		float f1 = (float) (color >> 16 & 255) / 255.0f;
		float f2 = (float) (color >> 8 & 255) / 255.0f;
		float f3 = (float) (color & 255) / 255.0f;
		GL11.glColor4f(f1, f2, f3, f);
	}
	
	public void enableGL2D() {
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glDepthMask(true);
		GL11.glEnable(GL11.GL_LINE_SMOOTH);
		GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
		GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT, GL11.GL_NICEST);
	}

	public void disableGL2D() {
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		GL11.glDisable(GL11.GL_BLEND);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDisable(GL11.GL_LINE_SMOOTH);
		GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_DONT_CARE);
		GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT, GL11.GL_DONT_CARE);
	}
    
    private boolean isHovering(int mouseX, int mouseY, float xLeft, float yUp, float xRight, float yBottom) {
        return mouseX > xLeft && mouseX < xRight && mouseY > yUp && mouseY < yBottom;
    }
	
	private boolean isHoveringWindow(int mouseX, int mouseY) {
        return mouseX >= this.x && mouseX <= this.x + 80 && mouseY >= this.y && mouseY <= this.y + 10;
    }
}
