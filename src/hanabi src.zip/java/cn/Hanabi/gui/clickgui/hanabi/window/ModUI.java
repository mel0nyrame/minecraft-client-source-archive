package cn.Hanabi.gui.clickgui.hanabi.window;

import cn.Hanabi.Hanabi;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.modules.render.ClickGUIModule;
import cn.Hanabi.utils.Misc.Colors;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.utils.fontmanager.UnicodeFontRenderer;

import java.awt.*;

public class ModUI {
	public static Mod selectedMod;
	Mod mod;
	boolean selected = false;
	float x, y;
	Button button;
	
	public ModUI(Mod mod) {
		this.mod = mod;
	}
	
	public void draw(int x, int y) {
		this.x = x;
		this.y = y;
		if (selected) {
			selectedMod = mod;
			RenderUtil.drawRoundedRect(x, y, x + 100, y + 25, 6f, ClickGUIModule.theme.isCurrentMode("Light") ? 0xffeeeeee : 0xff1b1b1b);
		}
		
		UnicodeFontRenderer font = Hanabi.INSTANCE.fontManager.usans16;
		
		font.drawString(mod.getName(), x + 5, y + 12.5f - font.FONT_HEIGHT / 2, ClickGUIModule.theme.isCurrentMode("Light") ? Colors.BLACK.c : new Color(167, 167, 167).getRGB());
		if (button == null) {
			button = new Button(mod.getName(), mod.isEnabled()) {
				@Override
				public void onPress() {
					mod.set(!mod.isEnabled());
					mod.modButton.toggle();
					super.onPress();
				}
			};
		}
		
		button.draw(x + 85, y + 12.5f);
		button.state = mod.isEnabled();
	}
	
	public boolean isPressed(int mouseX, int mouseY) {
		if (button != null) button.isPressed(mouseX, mouseY);
		return isHovering(mouseX, mouseY, x, y - 5, x + 100, y + 30) && !selected;
	}
	
	private boolean isHovering(int mouseX, int mouseY, double xLeft, double yUp, double xRight, double yBottom) {
		return mouseX > xLeft && mouseX < xRight && mouseY > yUp && mouseY < yBottom;
	}
}
