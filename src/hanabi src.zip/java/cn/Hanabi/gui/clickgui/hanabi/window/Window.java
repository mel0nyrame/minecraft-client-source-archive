package cn.Hanabi.gui.clickgui.hanabi.window;

import cn.Hanabi.Hanabi;
import cn.Hanabi.gui.clickgui.hanabi.ClickGUI;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.render.ClickGUIModule;
import cn.Hanabi.utils.Misc.Colors;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.value.Value;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Window {
	public static int x, y, windowWidth, windowHeight, wheelStateMod, wheelStateValue;
	public int tX, tY, dragX, dragY;
	public static double wheelSmoothMod, wheelSmoothValue;
	public static boolean isDraging = false;
	public boolean clickNotDraging = false;
	public Category category;
	public List<ModUI> mods = new ArrayList<ModUI>();
	public static Map<Value, Button> booleanValueMap = new HashMap<Value, Button>();
	public static Map<Value, SliderBar> doubleValueMap = new HashMap<Value, SliderBar>();
	public static Map<Value, ModeSelector> modeValueMap = new HashMap<Value, ModeSelector>();
	
	public Window(Category category) {
		this.category = category;
		x = -1;
		y = -1;
	}
	
	public void createModUI() {
		mods.clear();
		for (Mod mod : ModManager.getModList()) {
			if (mod.getCategory() == category) mods.add(new ModUI(mod));
		}
	}
	
	public void draw(int mouseX, int mouseY) {
		ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
		windowWidth = (int) (sr.getScaledWidth() * 0.5);
		windowHeight = (int) (sr.getScaledHeight() * 0.6);
		if (windowWidth < 370) windowWidth = 370;
		if (windowHeight < 240) windowHeight = 240;
		
		if (x == -1 || y == -1) {
			x = sr.getScaledWidth() / 2 - windowWidth / 2;
			y = sr.getScaledHeight() / 2 - windowHeight / 2;
		}
		
		processDrag(mouseX, mouseY);
		processWheel(mouseX, mouseY);
		
		drawBackground();
		//if (ClickGUI.animpos == 0) {
			drawModList();
		//}
		drawValueList(mouseX, mouseY);
	}
	
	private void drawValueList(int mouseX, int mouseY) {
		if (ModUI.selectedMod != null) {
			Mod selectedMod = ModUI.selectedMod;
			// Mod标题
			Hanabi.INSTANCE.fontManager.usans18.drawString(selectedMod.getName(), x + 120, y + 30,ClickGUIModule.theme.isCurrentMode("Light") ? Colors.BLACK.c : new Color(167, 167, 167).getRGB());
			
			// 最上方的Mod开关
			if (selectedMod.modButton == null) {
				selectedMod.modButton = new Button(selectedMod.getName(), selectedMod.isEnabled()) {
					@Override
					public void onPress() {
						selectedMod.set(!selectedMod.isEnabled());
						for (ModUI mod : mods) {
							if (mod.mod == selectedMod) {
								mod.button.toggle();
								break;
							}
						}
						super.onPress();
					}
				};
			}
			
			selectedMod.modButton.draw(x + windowWidth - 35, y + 36);
			selectedMod.modButton.state = selectedMod.isEnabled();
			
			// 分割线
			RenderUtil.drawRect(x + 115, y + 45, x + windowWidth - 15, y + 45.3f, new Color(40, 40, 40).getRGB());
			
			// Value处理
			List<Value> modBooleanValue = new ArrayList<Value>();
			List<Value> modModeValue = new ArrayList<Value>();
			List<Value> modDoubleValue = new ArrayList<Value>();
			
			modBooleanValue.clear();
			modModeValue.clear();
			modDoubleValue.clear();
			
			selectedMod.valueSize = 0;
			for (Value value : Value.list) {
				String valueMod = value.getValueName().split("_")[0];
				if (valueMod.equals(selectedMod.getName())) {
					selectedMod.valueSize += 1;
					if (value.isValueDouble) modDoubleValue.add(value);
					if (value.isValueMode) modModeValue.add(value);
					if (value.isValueBoolean) modBooleanValue.add(value);
				}
			}
			
			GL11.glPushMatrix();
			GL11.glEnable(GL11.GL_SCISSOR_TEST);
			
			// 画Value
			RenderUtil.doGlScissor(x + 110, y + 45 + (int)ClickGUI.animpos, windowWidth, windowHeight - 55);
			wheelSmoothValue = RenderUtil.getAnimationState(wheelSmoothValue, wheelStateValue * 30, 400);
			int tempY = (int) (y + wheelSmoothValue);
			int drawY = tempY + 60;
			
			for (Value value : modBooleanValue) {
				String modName = value.getValueName().split("_")[0];
				String valueName = value.getValueName().split("_")[1];
				Hanabi.INSTANCE.fontManager.usans16.drawString(valueName, x + 120, drawY, ClickGUIModule.theme.isCurrentMode("Light") ? Colors.BLACK.c : new Color(167, 167, 167).getRGB());
				Button button = null;
				if (booleanValueMap.containsKey(value)) {
					button = booleanValueMap.get(value);
				} else {
					button = new Button(modName, (boolean)value.getValueState()) {
						@Override
						public void onPress() {
							
							if(!parent.equals(ModUI.selectedMod.getName())) return;
							
							value.setValueState(!(boolean) value.getValueState());
							super.onPress();
						}
					};
					booleanValueMap.put(value, button);
				}
				button.draw(x + windowWidth - 35, drawY + 5.5f);
				drawY += 30;
			}
			
			for (Value value : modDoubleValue) {
				String valueName = value.getValueName().split("_")[1];
				Hanabi.INSTANCE.fontManager.usans16.drawString(valueName, x + 120, drawY, ClickGUIModule.theme.isCurrentMode("Light") ? Colors.BLACK.c : new Color(167, 167, 167).getRGB());
				SliderBar bar = null;
				if (doubleValueMap.containsKey(value)) {
					bar = doubleValueMap.get(value);
				} else {
					bar = new SliderBar(value);
					doubleValueMap.put(value, bar);
				}
				bar.draw(x + windowWidth, drawY);
				bar.onPress(mouseX, mouseY);
				drawY += 30;
			}
			
			for (Value value : modModeValue) {
				String valueName = value.getDisplayTitle();
				Hanabi.INSTANCE.fontManager.usans16.drawString(valueName, x + 120, drawY, ClickGUIModule.theme.isCurrentMode("Light") ? Colors.BLACK.c : new Color(167, 167, 167).getRGB());
				ModeSelector selector = null;
				if (modeValueMap.containsKey(value)) {
					selector = modeValueMap.get(value);
				} else {
					selector = new ModeSelector(value);
					modeValueMap.put(value, selector);
				}
				selector.draw(x + windowWidth, drawY, mouseX, mouseY);
				drawY += 30;
			}
			
			if (selectedMod.valueSize == 0) {
				Hanabi.INSTANCE.fontManager.usans16.drawString("No setting here.", x + 120, y + 60,ClickGUIModule.theme.isCurrentMode("Light") ? new Color(Colors.BLACK.c).brighter().brighter().getRGB() : new Color(167, 167, 167).getRGB());
			}

			GL11.glDisable(GL11.GL_SCISSOR_TEST);
			GL11.glPopMatrix();
		}
	}

	private void drawModList() {
		GL11.glPushMatrix();
		GL11.glEnable(GL11.GL_SCISSOR_TEST);
		RenderUtil.doGlScissor(x + 10, y + 25 + (int)ClickGUI.animpos, 100, windowHeight - 35);
		wheelSmoothMod = RenderUtil.getAnimationState(wheelSmoothMod, wheelStateMod * 30, 400);
		int tempY = (int) (y + wheelSmoothMod);
		int drawY = tempY + 25;
		for (ModUI modui : mods) {
			modui.draw(x + 10, drawY);
			drawY += 35;
		}
		GL11.glDisable(GL11.GL_SCISSOR_TEST);
		GL11.glPopMatrix();
	}

	private void drawBackground() {
		int backGroundCol = ClickGUIModule.theme.isCurrentMode("Light") ? 0xFFF1EFF1 : new Color(27, 27, 27).getRGB();
		int buttCol = ClickGUIModule.theme.isCurrentMode("Light") ? Colors.RED.c : new Color(47, 116, 253).getRGB();
		
		if(!ClickGUIModule.theme.isCurrentMode("Light")) {
			RenderUtil.drawRoundedRect(x - 0.5f, y - 0.5f, x + windowWidth + 0.5f, y + windowHeight + 0.5f, 6f, new Color(16, 76, 182).getRGB());
		} else {
			RenderUtil.drawRoundedRect(x - 1f, y - 1f, x + windowWidth + 1f, y + windowHeight + 1f, 6f, backGroundCol);
		}
		
		RenderUtil.drawRoundedRect(x, y, x + windowWidth, y + windowHeight, 6f, backGroundCol);
		
		RenderUtil.drawRoundedRect(x + 2, y + 14, x + windowWidth - 2, y + windowHeight - 2, 6f, ClickGUIModule.theme.isCurrentMode("Light") ? new Color(Colors.GREY.c).brighter().brighter().getRGB() : new Color(13, 13, 13).getRGB());
		
		RenderUtil.circle(x + windowWidth - 10, y + 8, 2.5f, buttCol);
		
		Hanabi.INSTANCE.fontManager.raleway16.drawString(category.toString(), x + 8, y + 3, ClickGUIModule.theme.isCurrentMode("Light") ? Colors.BLACK.c : new Color(167, 167, 167).getRGB());
	}

	private void processWheel(int mouseX, int mouseY) {
		int wheel = Mouse.getDWheel();
		if (isHover(x + 10, y + 25, 100, windowHeight - 35, mouseX, mouseY)) { // 鼠标在ModList
			if (wheel > 0) {
				if (wheelStateMod < 0) wheelStateMod++;
			} else if (wheel < 0) {
				if (wheelStateMod * 30 > mods.size() * -30) wheelStateMod--;
			}
		} else if (isHover(x + 110, y + 25, windowWidth, windowHeight - 35, mouseX, mouseY)) {
			if (wheel > 0) {
				if (wheelStateValue < 0) wheelStateValue++;
			} else if (wheel < 0) {
				if (ModUI.selectedMod != null && wheelStateValue * 50 > ModUI.selectedMod.valueSize * -40) wheelStateValue--;
			}
		}
	}
	
	private void processDrag(int mouseX, int mouseY) {
		ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
		if (Mouse.isButtonDown(0)) {
			if (isHover(x + windowWidth - 17, y, 10, 10, mouseX, mouseY)) {
				Minecraft.getMinecraft().displayGuiScreen(null);
				return;
			}
			if (isHover(x, y, windowWidth, 15, mouseX, mouseY) || isDraging) {
				isDraging = true;
			} else {
				clickNotDraging = true;
			}
			if (isDraging && !clickNotDraging) {
				dragX = mouseX - tX;
				dragY = mouseY - tY;
				if (x < sr.getScaledWidth() * 0.155) {
					x = (int) (sr.getScaledWidth() * 0.155) + 1;
				} else if (x > sr.getScaledWidth() - windowWidth) {
					x = sr.getScaledWidth() - windowWidth - 1;
				} else {
					x += dragX;
				}

				if (y < 0) {
					y = 1;
				} else if (y > sr.getScaledHeight() - windowHeight) {
					y = sr.getScaledHeight() - windowHeight - 1;
				} else {
					y += dragY;
				}
			}
		} else {
			isDraging = false;
			clickNotDraging = false;
		}
		tX = mouseX;
		tY = mouseY;
	}
	
    public boolean isHover(final int x, final int y, final int widht, final int height, final int mouseX, final int mouseY) {
        return mouseX >= x && mouseX <= x + widht && mouseY >= y && mouseY <= y + height;
    }	

	public void onMouseClick(int mouseX, int mouseY) {
		// 左边Mod列表处理
		for (ModUI mod : mods) {
			if (isHover(x + 10, y + 25, 100, windowHeight - 35, mouseX, mouseY) && mod.isPressed(mouseX, mouseY)) {
				for (ModUI mod2 : mods) mod2.selected = false;
				mod.selected = true;
				wheelStateValue = 0;
				break;
			}
		}
		
		// 右边开关处理
		for (Button button : booleanValueMap.values()) {
			button.isPressed(mouseX, mouseY);
		}
		
		// 右上开关处理
		if (ModUI.selectedMod != null && ModUI.selectedMod.modButton != null) ModUI.selectedMod.modButton.isPressed(mouseX, mouseY);
	}
}
