package cn.Hanabi.gui.clickgui.hanabi.bar;

import cn.Hanabi.Hanabi;
import cn.Hanabi.gui.clickgui.hanabi.window.Window;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.modules.render.ClickGUIModule;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.utils.fontmanager.HanabiFonts;
import cn.Hanabi.utils.fontmanager.UnicodeFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class SideBar {
	Minecraft mc = Minecraft.getMinecraft();
	ScaledResolution sr;
	int length;

	public float animationY;

	public List<Button> button = new ArrayList<Button>();
	UnicodeFontRenderer icon;

	public SideBar() {
		sr = new ScaledResolution(mc);
		
		length = (int) (sr.getScaledWidth() * 0.155); // start = 200
		
		for (int i = 0; i < Category.values().length; i++) {
			Button active = new Button(length / 2,
					sr.getScaledHeight() * 0.342f + (i + 1) * sr.getScaledHeight() * 0.078f, length / 2,
					Category.values()[i].toString(), sr, this) {
				@Override
				public void onPress() {
					super.onPress();
				}
			};
			active.active = false;
			button.add(active);
		}

		button.get(0).active = true;

	}

	public void draw() {
		sr = new ScaledResolution(mc);
		GlStateManager.translate(0,0,0);
		RenderUtil.drawRect(0, -sr.getScaledHeight(), length, sr.getScaledHeight(),
				ClickGUIModule.theme.isCurrentMode("Light") ? 0xffeeeeee : new Color(22, 22, 22).getRGB());
		RenderUtil.drawRect(length, -sr.getScaledHeight(), length + 2, sr.getScaledHeight(),
				ClickGUIModule.theme.isCurrentMode("Light") ? new Color(0xff1d6fdf).brighter().getRGB()
						: new Color(47, 116, 253).getRGB());


		Button activeButton = null;
		length = (int) (sr.getScaledWidth() * 0.155);
		int i = 0;
		
		for (Button but : button) {
			but.x = length / 2;
			but.y = sr.getScaledHeight() * 0.342f + (i + 1) * sr.getScaledHeight() * 0.078f - 40;
			but.radius = length / 2;
			i++;
			if (but.active) {
				activeButton = but;
			}
		}

		this.animationY = (float) RenderUtil.getAnimationState(this.animationY, activeButton.y,
				Math.max(10, (Math.abs(this.animationY - activeButton.y) * 50) * 0.3));
		
		float s2 = sr.getScaledHeight() / 480f;

		RenderUtil.drawRoundedRect((int) activeButton.x - 50 * s2, (int) animationY - 15 * s2, (int) activeButton.x + 50 * s2,
				(int) animationY + 18 * s2, 15.6f * s2,
				ClickGUIModule.theme.isCurrentMode("Light") ? new Color(0xff1d6fdf).brighter().getRGB()
						: new Color(47, 116, 253).getRGB());

		for (Button but : button) {
			but.drawOther();
		}

		float size = (sr.getScaledHeight() / 60f) * 15f;

		icon = Hanabi.INSTANCE.fontManager.getFontWithCustomGlyph("icon", size, 59648, 59673);

		icon.drawCenteredString(HanabiFonts.ICON_HANABI_LOGO, (int) (length / 2.1), (int) (sr.getScaledHeight() * 0.11),
				ClickGUIModule.theme.isCurrentMode("Light") ? new Color(0xff1d6fdf).brighter().getRGB()
						: new Color(47, 116, 253).getRGB());
	}

	public void onMouseClick(int mouseX, int mouseY) {
		for (Button but : button) {
			if (but.isPressed(mouseX, mouseY)) {
				but.onPress();
				Window.wheelStateMod = 0;
			}
		}
	}
}
