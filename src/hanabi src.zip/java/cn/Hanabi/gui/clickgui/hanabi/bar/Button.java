package cn.Hanabi.gui.clickgui.hanabi.bar;

import cn.Hanabi.Hanabi;
import cn.Hanabi.modules.modules.render.ClickGUIModule;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.utils.fontmanager.HanabiFonts;
import cn.Hanabi.utils.fontmanager.UnicodeFontRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

import java.awt.*;

public class Button {
	float x, y, radius;
	String logo;
	public String title;
	ScaledResolution sr;
	public Boolean active = false;
	double state = 0;
	SideBar sb;
	
	public Button(float x, float y, float radius, String title, ScaledResolution sr, SideBar sb) {
		this.x = x;
		this.y = y;
		this.radius = radius;
		this.title = title;
		this.sr = sr;
		this.sb = sb;
		if (title.equals("Combat")) {
			logo = HanabiFonts.ICON_CLICKGUI_COMBAT;
		} else if (title.equals("Movement")) {
			logo = HanabiFonts.ICON_CLICKGUI_MOVEMENT;
		} else if (title.equals("Render")) {
			logo = HanabiFonts.ICON_CLICKGUI_RENDER;
		} else if (title.equals("Player")) {
			logo = HanabiFonts.ICON_CLICKGUI_PLAYER;
		} else if (title.equals("World")) {
			logo = HanabiFonts.ICON_CLICKGUI_WORLD;
		} else {
			logo = HanabiFonts.ICON_CLICKGUI_GHOST;
		}
	}
	
	public void drawButton() {
		sr = new ScaledResolution(Minecraft.getMinecraft());
		if (active) {
			state = getAnimationState(state, 5, 35);
			RenderUtil.drawRoundedRect((int)x - 45, (int)y - 16,(int)x + 45, (int)y + 17, 15f, ClickGUIModule.theme.isCurrentMode("Light") ? new Color(0xff1d6fdf).brighter().getRGB() : new Color(47, 116, 253).getRGB());
		}
	}
	
	public void drawOther() {

		UnicodeFontRenderer icon;
		UnicodeFontRenderer font;
		
		float size = (sr.getScaledHeight() / 60f) * 4f;
		icon = Hanabi.INSTANCE.fontManager.getFontWithCustomGlyph("icon", size, 59648, 59673);
		font = Hanabi.INSTANCE.fontManager.getFont("raleway", size / 3 * 2);

		if(ClickGUIModule.theme.isCurrentMode("Light")) {
			icon.drawString(logo, x - radius / 2, y - icon.getStringHeight(logo) / 2, active ? new Color(255, 255, 255).getRGB() : new Color(0xff1d6fdf).brighter().getRGB());
			font.drawString(title, x - icon.getStringWidth(logo) / 2, y - font.getStringHeight(title) / 2, active ? new Color(255, 255, 255).getRGB() : new Color(0xff1d6fdf).brighter().getRGB());
		} else {
			icon.drawString(logo, x - radius / 2, y - icon.getStringHeight(logo) / 2, active ? new Color(255, 255, 255).getRGB() : new Color(47, 116, 253).getRGB());
			font.drawString(title, x - icon.getStringWidth(logo) / 2, y - font.getStringHeight(title) / 2, active ? new Color(255, 255, 255).getRGB() : new Color(47, 116, 253).getRGB());
		}
		
		
		
	}

	public void onPress() {
		for (Button but : sb.button) but.active = false;
		active = true;
		state = 0;
	}
	
	public boolean isPressed(int mouseX, int mouseY) {
		return isHovering(mouseX, mouseY, x - radius / 1.5, y - radius / 3.5, x + radius / 1.5, y + radius / 3.5) && !active;
	}
	
	private boolean isHovering(int mouseX, int mouseY, double xLeft, double yUp, double xRight, double yBottom) {
		return mouseX > xLeft && mouseX < xRight && mouseY > yUp && mouseY < yBottom;
	}
	
	public double getAnimationState(double animation, double finalState, double speed) {
		float add = (float) (RenderUtil.delta * speed);
		if (animation < finalState) {
			if (animation + add < finalState)
				animation += add;
			else
				animation = finalState;
		} else {
			if (animation - add > finalState)
				animation -= add;
			else
				animation = finalState;
		}
		return animation;
	}
}
