package cn.Hanabi.gui.clickgui.hanabi.window;

import cn.Hanabi.Hanabi;
import cn.Hanabi.modules.modules.render.ClickGUIModule;
import cn.Hanabi.utils.Misc.Colors;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.utils.fontmanager.UnicodeFontRenderer;
import cn.Hanabi.value.Value;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;

import java.awt.*;

public class SliderBar {
	Value<Double> value;
	public float x, y;
	private boolean isDraging, clickNotDraging;
	public int tX, tY, dragX, dragY;
	double ani;
	
	public SliderBar(Value value) {
		this.value = value;
	}
	
	public void draw(float x, float y) {
		this.x = x;
		this.y = y;
		UnicodeFontRenderer font = Hanabi.INSTANCE.fontManager.comfortaa16;
		double pos = (value.getValueState() - value.getValueMin()) / (value.getValueMax() - value.getValueMin()); 
		font.drawString(value.getValueName().split("_")[1], x + 120, y, new Color(212, 212, 212).getRGB());
		font.drawString(value.getValueState() + "", x - 165 - font.getStringWidth(value.getValueState() + ""), y, ClickGUIModule.theme.isCurrentMode("Light") ? Colors.GREY.c : new Color(212, 212, 212).getRGB());
		if (ani == 0 || Window.isDraging) ani = (float) (x - 15 - (140 - 140 * pos));
		ani = RenderUtil.getAnimationState(ani, (float) (x - 15 - (140 - 140 * pos)), 600);
		RenderUtil.drawRoundedRect(x - 155, y + 3, x - 15, y + 6, 1f, ClickGUIModule.theme.isCurrentMode("Light") ? Colors.GREY.c : new Color(27, 27, 27).getRGB());
		RenderUtil.drawRoundedRect(x - 155, y + 3, (float) ani, y + 6, 1f, ClickGUIModule.theme.isCurrentMode("Light") ? new Color(0xff1d6fdf).brighter().getRGB() : new Color(16, 72, 182).getRGB());
		RenderUtil.circle((float) ani, y + 4.5f, 3f, ClickGUIModule.theme.isCurrentMode("Light") ? new Color(0xff1d6fdf).brighter().getRGB() : new Color(29, 111, 223).getRGB());
	}
	
	public void onPress(int mouseX, int mouseY) {
		ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
		if (Mouse.isButtonDown(0)) {
			if (isHovering(mouseX, mouseY, x - 155, y - 3, x - 15, y + 10) || isDraging) {
				isDraging = true;
			} else {
				clickNotDraging = true;
			}
			if (isDraging && !clickNotDraging) {
				double pos = (mouseX - x + 155) / 140;
				if (pos < 0) pos = 0;
				if (pos > 1) pos = 1;
				double valueState = (value.getValueMax() - value.getValueMin()) * pos + value.getValueMin();
				valueState = Math.round(valueState * (1.0 / value.getSteps())) / (1.0 / value.getSteps());
				value.setValueState(valueState);
			}
		} else {
			isDraging = false;
			clickNotDraging = false;
		}
		tX = mouseX;
		tY = mouseY;
	}
	
	private boolean isHovering(int mouseX, int mouseY, double xLeft, double yUp, double xRight, double yBottom) {
		return mouseX > xLeft && mouseX < xRight && mouseY > yUp && mouseY < yBottom;
	}
}
