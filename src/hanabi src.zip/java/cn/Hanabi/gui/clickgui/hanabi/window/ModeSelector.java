package cn.Hanabi.gui.clickgui.hanabi.window;

import cn.Hanabi.Hanabi;
import cn.Hanabi.modules.modules.render.ClickGUIModule;
import cn.Hanabi.utils.Misc.Colors;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.utils.fontmanager.HanabiFonts;
import cn.Hanabi.value.Value;
import org.lwjgl.input.Mouse;

import java.awt.*;

public class ModeSelector {
	Value<String> value;
	int x, y;
	private boolean readySelect, isSelectingMode;
	double ani;
	
	public static Value<String> renderingValue;

	public ModeSelector(Value value) {
		this.value = value;
	}

	public void draw(int x, int y, int mouseX, int mouseY) {
		if (this.isSelectingMode) {
			renderingValue = value;
		}
		
		if (renderingValue != null && renderingValue != value) {
			return;
		}
		boolean isLightMode = ClickGUIModule.theme.isCurrentMode("Light");

		float modeOffset = y - 5;
		float fontOffset = modeOffset + 7;
		ani = RenderUtil.getAnimationState(ani, (isSelectingMode ? 20 * value.mode.size() : 20), 400);
		RenderUtil.drawRoundedRect(x - 80, modeOffset, x - 20, (float) (modeOffset + ani), 2f,
				isLightMode ? new Color(Colors.GREY.c).brighter().getRGB() : new Color(15, 15, 15).getRGB());
		RenderUtil.drawRoundedRect(x - 80, modeOffset, x - 20, modeOffset + 20, 2f, isLightMode ? new Color(Colors.GREY.c).brighter().getRGB() : new Color(21, 21, 21).getRGB());
		Hanabi.INSTANCE.fontManager.usans15.drawString(value.mode.get(value.getCurrentMode()), x - 75, fontOffset, -1);

		if (!isSelectingMode) {

			Hanabi.INSTANCE.fontManager.icon15.drawString(HanabiFonts.ICON_CLICKGUI_ARROW_UP, x - 32, y + 1,
					-1);

			if (Mouse.isButtonDown(0) && isHovering(mouseX, mouseY, x - 80, modeOffset, x - 20, modeOffset + 20)
					&& !readySelect)
				readySelect = true;
			if (!Mouse.isButtonDown(0) && readySelect)
				isSelectingMode = true;
		} else {

			Hanabi.INSTANCE.fontManager.icon15.drawString(HanabiFonts.ICON_CLICKGUI_ARROW_DOWN, x - 32, y + 1, -1);

			for (String str : value.mode) {
				if (str.equals(value.mode.get(value.getCurrentMode())))
					continue;
				fontOffset += 20;
				modeOffset += 20;
				if (ani > modeOffset - y - 30) {
					if (Mouse.isButtonDown(0)) {
						if (isHovering(mouseX, mouseY, x - 80, modeOffset, x - 20, modeOffset + 20)) {
							isSelectingMode = false;
							readySelect = false;
							
							new Thread() {
								public void run() {
									try {
										sleep(50L);
									} catch (InterruptedException e) {
										e.printStackTrace();
									}
									renderingValue = null;
								}
							}.start();
							
							value.setCurrentMode(value.mode.indexOf(str));
						} else {
							for (ModeSelector selector : Window.modeValueMap.values()) {
								
								new Thread() {
									public void run() {
										try {
											sleep(50L);
										} catch (InterruptedException e) {
											e.printStackTrace();
										}
										selector.isSelectingMode = false;
										selector.readySelect = false;
										renderingValue = null;
									}
								}.start();
							}
						}

					}
					Hanabi.INSTANCE.fontManager.usans15.drawString(str, x - 75, fontOffset, -1);
				}
			}
		}
	}

	private boolean isHovering(int mouseX, int mouseY, double xLeft, double yUp, double xRight, double yBottom) {
		return mouseX > xLeft && mouseX < xRight && mouseY > yUp && mouseY < yBottom;
	}
}
