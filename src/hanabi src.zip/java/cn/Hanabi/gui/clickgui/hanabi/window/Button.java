package cn.Hanabi.gui.clickgui.hanabi.window;

import cn.Hanabi.modules.modules.render.ClickGUIModule;
import cn.Hanabi.utils.Misc.Colors;
import cn.Hanabi.utils.Misc.RenderUtil;

import java.awt.*;

public class Button {

	public String parent;

	public float x, y;
	public boolean state;

	double aniState;

	public Button(String parent, boolean b) {
		this.parent = parent;
		this.state = b;
		aniState = 8;
	}

	public void draw(float x, float y) {
		this.x = x;
		this.y = y;
		aniState = RenderUtil.getAnimationState(aniState, state? 8:0, 100);
		RenderUtil.drawRoundedRect(x - 8, y - 3f, x + 8, y + 3f, 2f, ClickGUIModule.theme.isCurrentMode("Light") ? new Color(Colors.GREY.c).brighter().getRGB() : new Color(40, 40, 40).getRGB());

		if(ClickGUIModule.theme.isCurrentMode("Light")) {
			RenderUtil.circle(state ? (float) (x - 4 + aniState) : (float) (x - 4 + aniState), y, 4f, state ? new Color(0xff1d6fdf).brighter().getRGB() : new Color(Colors.WHITE.c).darker().getRGB());
		} else {
			RenderUtil.circle(state ? (float) (x - 4 + aniState) : (float) (x - 4 + aniState), y, 4f, state ? 0xff1d6fdf : 0xff434343);
		}

	}

	public void toggle() {
		state = !state;
		//aniState = 0;
	}

	public void isPressed(int mouseX, int mouseY) {
		if (isHovering(mouseX, mouseY, x - 12, y - 5f, x + 12, y + 5f)) onPress();
	}

	private boolean isHovering(int mouseX, int mouseY, double xLeft, double yUp, double xRight, double yBottom) {
		return mouseX > xLeft && mouseX < xRight && mouseY > yUp && mouseY < yBottom;
	}

	public void onPress() {
		toggle();
	}
}
	