/*
 * Copyright (c) 2018 superblaubeere27
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package cn.Hanabi.gui.clickgui.components;

import cn.Hanabi.gui.clickgui.ClickGUI;
import cn.Hanabi.utils.GLUtil;
import cn.Hanabi.utils.Utils;
import cn.Hanabi.value.Value;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.*;

import static org.lwjgl.opengl.GL11.*;

public class SliderUI extends AbstractComponentUI<Value> {
    private boolean isValueChanging = false;

    public SliderUI(Value value) {
        super(0, 0, 0, 0, value);
    }

    @Override
    public void draw() {
        GL11.glPushMatrix();
        glTranslatef(x, y, 0);
        glEnable(GL_BLEND);
        glDisable(GL_CULL_FACE);

        final Rectangle area = new Rectangle(x, y, getWidth(), getHeight());

//        GLUtil.drawRect(GL11.GL_LINE_LOOP, 1, 1, area.width, area.height, GLUtil.toRGBA(ClickGUI.PANEL_MAIN_COLOR));

        glTranslatef(2, 2, 0);

        final int fontSize = fontRenderer.FONT_HEIGHT;
        GLUtil.setColor(Color.white);
        fontRenderer.drawString(getValue().getValueName().split("_")[1], 0, 0, GLUtil.toRGBA(Color.white));
        String content = null;

        if (getValue().getValueState() instanceof Integer || getValue().getValueState() instanceof Long) {
            content = getValue().getValueState().toString();
        } else if (getValue().getValueState() instanceof Float || getValue().getValueState() instanceof Double) {
            content = String.format("%.2f", getValue().getValueState());
        }

        if (content != null) {
            GLUtil.setColor(Color.white);
            fontRenderer.drawString(content, getWidth() - fontRenderer.getStringWidth(content) - 3, 0,
                    GLUtil.toRGBA(Color.white));
        }

        GLUtil.setColor(ClickGUI.PANEL_MAIN_COLOR);
        glLineWidth(0.9f);


        final double sliderPercentage = (((Number) getValue().getValueState()).doubleValue() - ((Number) getValue().getValueMin()).doubleValue())
                / (((Number) getValue().getValueMax()).doubleValue() - ((Number) getValue().getValueMin()).doubleValue());

        GLUtil.setColor(ClickGUI.PANEL_SECONDARY_COLOR);

        Gui.drawRect(0, fontSize + 2, (int) (area.width * sliderPercentage) - 2, area.height - 4, ClickGUI.PANEL_SECONDARY_COLOR.getRGB());
        GLUtil.drawRect(GL11.GL_LINE_LOOP, 0, fontSize + 2, (int) (area.width * sliderPercentage) - 2, area.height - 4, ClickGUI.PANEL_MAIN_COLOR.getRGB());


        GL11.glPopMatrix();
    }

    @Override
    public boolean onMouseClick(int x, int y, int mouseButton) {
        if (new Rectangle(getX(), fontRenderer.FONT_HEIGHT + 2 + getY(), getWidth(),
                getHeight() - fontRenderer.FONT_HEIGHT).contains(x, y) && mouseButton == 0) {
            if (Mouse.isButtonDown(0) && !isValueChanging) {
                isValueChanging = true;
            } else if (!Mouse.isButtonDown(0) && isValueChanging) {
                isValueChanging = false;
            }
            return true;
        }
        return false;
    }

    @Override
    public void update() {
        if (isValueChanging) {
            final Point mouse = Utils.calculateMouseLocation();
            if (!Mouse.isButtonDown(0) || !new Rectangle(getX(), 0, getWidth(),
                    Integer.MAX_VALUE).contains(mouse)) {
                isValueChanging = false;
                return;
            }
            mouse.translate(-getX(), -getY());
            final double percent = (double) mouse.x / (double) getWidth();
            double value = ((Number) getValue().getValueMin()).doubleValue()
                    - percent * (((Number) getValue().getValueMin()).doubleValue() - ((Number) getValue().getValueMax()).doubleValue());

            value = Math.round(value * (1.0 / getValue().getSteps())) / (1.0 / getValue().getSteps());
            if (getValue().getValueState() instanceof Integer) {
                getValue().setValueState((int) Math.round(value));
            }
            if (getValue().getValueState() instanceof Float) {
                getValue().setValueState((float) value);
            }
            if (getValue().getValueState() instanceof Double) {
                getValue().setValueState(value);
            }
            if (getValue().getValueState() instanceof Long) {
                getValue().setValueState((long) value);
            }
        }
        width = Math.max(100, fontRenderer.getStringWidth(value.getValueName().split("_")[1]) + 25);
        height = 12 + fontRenderer.FONT_HEIGHT;
    }
}
