package cn.Hanabi.gui;

import cn.Hanabi.Hanabi;
import cn.Hanabi.gui.clickgui.hanabi.ClickGUI;
import cn.Hanabi.utils.Misc.ClientUtil;
import cn.Hanabi.utils.Misc.Colors;
import cn.Hanabi.utils.MouseInputHandler;
import cn.Hanabi.utils.Misc.RenderUtil;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class ScoreBoardMove {
	public float x;
	public float y;

	public int x2;
	public int y2;

	public float xSize = 65;

	public boolean isDragging = false;

	public boolean isExtended = true;

	public boolean showNumber = true;

	private final MouseInputHandler handler = new MouseInputHandler(0);

	public Minecraft mc = Minecraft.getMinecraft();

	public ScoreBoardMove(float startX, float startY) {
		this.x = startX;
		this.y = startY;
		this.isExtended = true;
	}

	public void passValue() {
		Scoreboard scoreboard = this.mc.theWorld.getScoreboard();
		ScoreObjective scoreobjective = null;
		ScorePlayerTeam scoreplayerteam = scoreboard.getPlayersTeam(this.mc.thePlayer.getName());

		if (scoreplayerteam != null) {
			int j1 = scoreplayerteam.getChatFormat().getColorIndex();

			if (j1 >= 0) {
				scoreobjective = scoreboard.getObjectiveInDisplaySlot(3 + j1);
			}
		}

		ScoreObjective scoreobjective1 = scoreobjective != null ? scoreobjective
				: scoreboard.getObjectiveInDisplaySlot(1);

		if (scoreobjective1 != null) {
			this.draw(scoreobjective1);
		}
	}

	public void draw(ScoreObjective so) {
		if (this.isExtended) {
			Scoreboard scoreboard = so.getScoreboard();
			Collection<Score> collection = scoreboard.getSortedScores(so);
			List<Score> list = Lists.newArrayList(Iterables.filter(collection, new Predicate<Score>() {
				public boolean apply(Score a) {
					return a.getPlayerName() != null && !a.getPlayerName().startsWith("#");
				}
			}));
			
			Collections.reverse(list);
			
			if (list.size() > 15) {
				collection = Lists.newArrayList(Iterables.skip(list, collection.size() - 15));
			} else {
				collection = list;
			}

			int maxLength = mc.fontRendererObj.getStringWidth(so.getDisplayName());

			for (Score score : collection) {
				ScorePlayerTeam scoreplayerteam = scoreboard.getPlayersTeam(score.getPlayerName());
				String s = ScorePlayerTeam.formatPlayerName(scoreplayerteam, score.getPlayerName()) + ": "
						+ EnumChatFormatting.RED + score.getScorePoints();
				maxLength = Math.max(maxLength, mc.fontRendererObj.getStringWidth(s));
			}

			int a = 3;

			this.xSize = maxLength + a;

			int size = 0;
			
			
			
			for (Score sc : collection) {
				size++;
			}

			drawRect(x - 2, y - 2, x + xSize + 5,
					y + mc.fontRendererObj.FONT_HEIGHT,
					ClientUtil.reAlpha(Colors.BLACK.c, 0.65f));

			drawRect(x - 2, y + mc.fontRendererObj.FONT_HEIGHT, x + xSize + 5,
					y + (mc.fontRendererObj.FONT_HEIGHT * (size + 1)) + 2,
					ClientUtil.reAlpha(Colors.BLACK.c, 0.45f));
			

			float sY = 0;

			for (Score sc2 : collection) {
				ScorePlayerTeam scoreplayerteam1 = scoreboard.getPlayersTeam(sc2.getPlayerName());
				String s1 = ScorePlayerTeam.formatPlayerName(scoreplayerteam1, sc2.getPlayerName());
				String s2 = EnumChatFormatting.RED + "" + sc2.getScorePoints();
				
				if(this.showNumber) {
					mc.fontRendererObj.drawString(s2, x + xSize - mc.fontRendererObj.getStringWidth(s2) + 4, y + 10 + sY, Colors.WHITE.c, false);
				}
				
				mc.fontRendererObj.drawString(s1, x, y + 10 + sY, Colors.WHITE.c, false);

				if (size == collection.size()) {
					drawCenteredString(so.getDisplayName(), x + (xSize / 2), y + ((mc.currentScreen instanceof GuiChat || mc.currentScreen instanceof ClickGUI) ? 0.5f : -0.5f), Colors.WHITE.c);
				}

				sY += mc.fontRendererObj.FONT_HEIGHT;
			}
		}

		if(mc.currentScreen instanceof GuiChat || mc.currentScreen instanceof ClickGUI) {
			int col1 = new Color(0xff1d6fdf).brighter().getRGB();
			this.drawRoundedRect(x - 2, y - 12, x + xSize + 5, y, col1, col1);

			Hanabi.INSTANCE.fontManager.wqy18.drawString("计分板", x, y - 11, Colors.WHITE.c);

			RenderUtil.drawArc(x + xSize - 2, y - 6, 3, Colors.WHITE.c, 0, 360, 1);
			
			RenderUtil.drawArc(x + xSize - 12, y - 6, 3, Colors.WHITE.c, 0, 360, 1);
			
			if(this.showNumber) {
				RenderUtil.circle(x + xSize - 12, y - 6, 1, Colors.WHITE.c);
			}
			
			if (this.isExtended) {
				RenderUtil.circle(x + xSize - 2, y - 6, 1, Colors.WHITE.c);
			}
		}
		
		GL11.glColor4f(1, 1, 1, 1);
	}
	
	public void drawCenteredString(String text, float x, float y, int color) {
        Minecraft.getMinecraft().fontRendererObj.drawString(text, x - (float)(Minecraft.getMinecraft().fontRendererObj.getStringWidth(text) / 2), y, color, false);
    }

	public void moveWindow(int mouseX, int mouseY) {

		if (this.isHovering(mouseX, mouseY, x + xSize - 6, y - 10, x + xSize + 2, y - 2)) {

			if (this.handler.canExcecute()) {
				this.isExtended = !this.isExtended;
			}

			return;
		}
		
		if(this.isHovering(mouseX, mouseY, x + xSize - 16, y - 10, x + xSize - 8, y - 2)) {
			
			if(this.handler.canExcecute()) {
				this.showNumber = !this.showNumber;
			}
			
			return;
		}

		if (this.isHoveringWindow(mouseX, mouseY) && this.handler.canExcecute()) {
			this.isDragging = true;
			this.x2 = (int) (mouseX - this.x);
			this.y2 = (int) (mouseY - this.y);
		}

		if (this.isDragging) {
			this.x = mouseX - this.x2;
			this.y = mouseY - this.y2;
		}

		if (!Mouse.isButtonDown(0) && this.isDragging) {
			this.isDragging = false;
		}
	}

	public void drawRoundedRect(float x, float y, float x1, float y1, int borderC, int insideC) {
		enableGL2D();
		GL11.glScalef(0.5f, 0.5f, 0.5f);
		drawVLine(x *= 2.0f, (y *= 2.0f) + 1.0f, (y1 *= 2.0f) - 2.0f, borderC);
		drawVLine((x1 *= 2.0f) - 1.0f, y + 1.0f, y1 - 2.0f, borderC);
		drawHLine(x + 2.0f, x1 - 3.0f, y, borderC);
		drawHLine(x + 2.0f, x1 - 3.0f, y1 - 1.0f, borderC);
		drawHLine(x + 1.0f, x + 1.0f, y + 1.0f, borderC);
		drawHLine(x1 - 2.0f, x1 - 2.0f, y + 1.0f, borderC);
		drawHLine(x1 - 2.0f, x1 - 2.0f, y1 - 2.0f, borderC);
		drawHLine(x + 1.0f, x + 1.0f, y1 - 2.0f, borderC);
		drawRect(x + 1.0f, y + 1.0f, x1 - 1.0f, y1 - 1.0f, insideC);
		GL11.glScalef(2.0f, 2.0f, 2.0f);
		disableGL2D();
	}

	public static void drawRect(float left, float top, float right, float bottom, int color) {

		float var5;
	    
	    if (left < right) {
	    	var5 = left;
	        left = right;
	        right = var5;
	    }

	    if (top < bottom) {
	    	var5 = top;
	    	top = bottom;
	    	bottom = var5;
	    }

	    float var11 = (float)(color >> 24 & 255) / 255.0F;
	    float var6 = (float)(color >> 16 & 255) / 255.0F;
	    float var7 = (float)(color >> 8 & 255) / 255.0F;
	    float var8 = (float)(color & 255) / 255.0F;
	    WorldRenderer worldRenderer = Tessellator.getInstance().getWorldRenderer();
	    GlStateManager.enableBlend();
	    GlStateManager.disableTexture2D();
	    GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
	    GlStateManager.color(var6, var7, var8, var11);
	    worldRenderer.begin(7, DefaultVertexFormats.POSITION);
	    worldRenderer.pos(left, bottom, 0.0D).endVertex();
	    worldRenderer.pos(right, bottom, 0.0D).endVertex();
	    worldRenderer.pos(right, top, 0.0D).endVertex();
	    worldRenderer.pos(left, top, 0.0D).endVertex();
	    Tessellator.getInstance().draw();
	    GlStateManager.enableTexture2D();
	    GlStateManager.disableBlend();
	    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    }
	
	public void drawHLine(float x, float y, float x1, int y1) {
		if (y < x) {
			float var5 = x;
			x = y;
			y = var5;
		}
		drawRect(x, x1, y + 1, x1 + 1, y1);
	}

	public void drawVLine(float x, float y, float x1, int y1) {
		if (x1 < y) {
			float var5 = y;
			y = x1;
			x1 = var5;
		}
		drawRect(x, y + 1, x + 1, x1, y1);
	}

	public void color(int color) {
		float f = (float) (color >> 24 & 255) / 255.0f;
		float f1 = (float) (color >> 16 & 255) / 255.0f;
		float f2 = (float) (color >> 8 & 255) / 255.0f;
		float f3 = (float) (color & 255) / 255.0f;
		GL11.glColor4f(f1, f2, f3, f);
	}

	public void enableGL2D() {
		GL11.glDisable(GL11.GL_DEPTH_TEST);
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glDisable(GL11.GL_TEXTURE_2D);
		GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
		GL11.glDepthMask(true);
		GL11.glEnable(GL11.GL_LINE_SMOOTH);
		GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
		GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT, GL11.GL_NICEST);
	}

	public void disableGL2D() {
		GL11.glEnable(GL11.GL_TEXTURE_2D);
		GL11.glDisable(GL11.GL_BLEND);
		GL11.glEnable(GL11.GL_DEPTH_TEST);
		GL11.glDisable(GL11.GL_LINE_SMOOTH);
		GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_DONT_CARE);
		GL11.glHint(GL11.GL_POLYGON_SMOOTH_HINT, GL11.GL_DONT_CARE);
	}

	private boolean isHovering(int mouseX, int mouseY, float xLeft, float yUp, float xRight, float yBottom) {
		return mouseX > xLeft && mouseX < xRight && mouseY > yUp && mouseY < yBottom;
	}

	private boolean isHoveringWindow(int mouseX, int mouseY) {
		return mouseX >= x - 2 && mouseX <= x + xSize + 5 && mouseY >= y - 10 && mouseY <= y;
	}
}
