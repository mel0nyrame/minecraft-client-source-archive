package cn.Hanabi.command.commands;

import cn.Hanabi.command.Command;
import cn.Hanabi.gui.notifications.Notification;
import cn.Hanabi.modules.modules.player.Spammer;
import cn.Hanabi.utils.Misc.ClientUtil;
import net.minecraft.client.Minecraft;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class SpammerCommand extends Command {
    private static final String fileDir = Minecraft.getMinecraft().mcDataDir.getAbsolutePath() + "/" + "Hanabi";

    public SpammerCommand() {
        super("spammer");
    }

    public static void saveText() {
        File f = new File(fileDir + "/spammer.txt");

        try {
            if (!f.exists()) {
				f.createNewFile();
			}

			PrintWriter pw = new PrintWriter(f);
			pw.print(Spammer.text);
			pw.close();
		} catch (Exception var2) {
			var2.printStackTrace();
		}

	}

	@SuppressWarnings("resource")
	public static void loadText() throws IOException {
		File f = new File(fileDir + "/spammer.txt");
		if (!f.exists()) {
			f.createNewFile();
		} else {
			BufferedReader br = new BufferedReader(new FileReader(f));

			String line;
			while ((line = br.readLine()) != null) {
				try {
                    String text = line;
                    Spammer.text = text;
                } catch (Exception var4) {
                }
			}
		}

	}

	@Override
	public void run(String alias, String[] args) {
		if (args.length == 0) {
			ClientUtil.sendClientMessage("Failed", Notification.Type.WARNING);
		} else {
			String msg = "";
			int i = 0;
			while (i < args.length) {
				msg = msg + args[i] + " ";
				++i;
			}
			Spammer.text = msg;
			saveText();
			ClientUtil.sendClientMessage("Changed to " + msg, Notification.Type.SUCCESS);

		}
	}

	@Override
	public List<String> autocomplete(int arg, String[] args) {
		return new ArrayList<>();
	}
}
