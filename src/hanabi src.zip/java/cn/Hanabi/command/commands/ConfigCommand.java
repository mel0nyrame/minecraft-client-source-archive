package cn.Hanabi.command.commands;

import cn.Hanabi.Hanabi;
import cn.Hanabi.command.Command;
import cn.Hanabi.gui.notifications.Notification;
import cn.Hanabi.utils.Misc.ClientUtil;
import net.minecraft.client.Minecraft;
import org.jetbrains.annotations.NotNull;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ConfigCommand extends Command {
    public ConfigCommand() {
        super("config");
    }

    @Override
    public void run(String alias, @NotNull String[] args) {
    	if(args.length == 1) {
            if (!get("https://hanabi-client.oss-cn-hangzhou.aliyuncs.com/config/" + args[0].toLowerCase() + "/values.txt").equals("")) {
                writeValue(get("https://hanabi-client.oss-cn-hangzhou.aliyuncs.com/config/" + args[0].toLowerCase() + "/values.txt"));
                writeMods(get("https://hanabi-client.oss-cn-hangzhou.aliyuncs.com/config/" + args[0].toLowerCase() + "/mods.txt"));
                Hanabi.INSTANCE.fileManager.load();
            } else {
                ClientUtil.sendClientMessage("We do not have this config!", Notification.Type.INFO);
            }
        }else {
    		ClientUtil.sendClientMessage(".config [server]", Notification.Type.INFO);
    	}
    }
    
    public static void writeValue(String value) {
        String fileDir = Minecraft.getMinecraft().mcDataDir.getAbsolutePath() + "/" + "Hanabi";
        File f = new File(fileDir + "/values.txt");

        try {
           if(!f.exists()) {
              f.createNewFile();
           }

           PrintWriter pw = new PrintWriter(f);
           pw.print(value);
           pw.close();
        } catch (Exception var2) {
           var2.printStackTrace();
        }
     }
    
    public static void writeMods(String mods) {
        String fileDir = Minecraft.getMinecraft().mcDataDir.getAbsolutePath() + "/" + "Hanabi";
        File f = new File(fileDir + "/mods.txt");

        try {
           if(!f.exists()) {
              f.createNewFile();
           }

           PrintWriter pw = new PrintWriter(f);
           pw.print(mods);
           pw.close();
        } catch (Exception var2) {
           var2.printStackTrace();
        }
     }
    
    public static String get(String url) {
        String result = "";
        BufferedReader in = null;
        try {
            String urlNameString = url;
            URL realUrl = new URL(urlNameString);
            URLConnection connection = realUrl.openConnection();
            connection.setDoOutput(true);
            connection.setReadTimeout(99781);
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent",
                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.connect();
            Map<String, List<String>> map = connection.getHeaderFields();
            for (String key : map.keySet()) { }
            in = new BufferedReader(new InputStreamReader(
                    connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line + "\n";
            }
        } catch (Exception e) {
        }
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e2) {
            }
        }
  	return result;
    }

    @Override
    public List<String> autocomplete(int arg, String[] args) {
    	return new ArrayList<>();
    }
}
