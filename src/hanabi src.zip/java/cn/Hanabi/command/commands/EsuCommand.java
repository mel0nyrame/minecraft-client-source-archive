package cn.Hanabi.command.commands;

import cn.Hanabi.command.Command;
import cn.Hanabi.command.CommandException;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.utils.Entity.PlayerUtil;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.input.Keyboard;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class EsuCommand extends Command {

    public EsuCommand() {
        super("esu");
    }


    @Override
    public void run(String alias, @NotNull String[] args) {
        try {
            if (args.length == 0) {
                throw new CommandException("Usage: ." + alias + "esu");
            }
            String jsonData = sendGet("http://vipcs.yzcmh.cn/qb-api.php?mod=cha&qq=" + args[0], null);
            jsonData = deleteCharInString(jsonData, '\n');
            jsonData = deleteCharInString(jsonData, '\r');
            jsonData = deleteCharInString(jsonData, ' ');
            try {
                String parsedData = getJsonData(jsonData, "data");
                String qq = getJsonData(parsedData, "qq");
                String mobile = getJsonData(parsedData, "mobile");
                PlayerUtil.tellPlayer("QQ:" + qq + ",mobile:" + mobile);
            } catch (Exception e) {
                PlayerUtil.tellPlayer("未查询到记录!");
            }
        } catch (Exception e) {
            // TODO: handle exception
        }

    }


    public static String getJsonData(String jsonString, String targetString) {
        JsonParser parser = new JsonParser();
        JsonElement jsonNode = parser.parse(jsonString);
        if (jsonNode.isJsonObject()) {
            JsonObject jsonObject = jsonNode.getAsJsonObject();
            JsonElement jsonElementId = jsonObject.get(targetString);
            return jsonElementId.toString();
        }
        return null;
    }

    public static String deleteCharInString(String str, char delChar) {
        StringBuilder delStr = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) != delChar) {
                delStr.append(str.charAt(i));
            }
        }
        return delStr.toString();
    }

    @Override
    public List<String> autocomplete(int arg, String[] args) {
        return new ArrayList<>();
    }

    public static String sendGet(String url, String param) {
        String result = "";
        BufferedReader in = null;

        try {
            URL realUrl = new URL(url);
            URLConnection connection = realUrl.openConnection();
            connection.setDoOutput(true);
            connection.setReadTimeout(99781);
            connection.setRequestProperty("accept", "*/*");
            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            connection.connect();
            Map<String, List<String>> map = connection.getHeaderFields();
            for (String str : map.keySet()) ;
            in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result = String.valueOf(result) + line;
            }
        } catch (Exception exception) {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception ignored) {
            }
        } finally {
            try {
                if (in != null) in.close();
            } catch (Exception ignored) {
            }
        }
        return result;
    }

}
