package cn.Hanabi.command.commands;

import cn.Hanabi.command.Command;
import cn.Hanabi.command.CommandException;
import cn.Hanabi.events.EventMove;
import cn.Hanabi.events.EventPacket;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.injection.interfaces.IS08PacketPlayerPosLook;
import cn.Hanabi.modules.modules.world.UhcHelper;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.PathFinder.AStarCustomPathFinder;
import cn.Hanabi.utils.PathFinder.Vec3;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C13PacketPlayerAbilities;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.BlockPos;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class TeleportCommand extends Command {
    protected static final Minecraft mc = Minecraft.getMinecraft();
    public static BlockPos target;
    public Entity targetEntity;
    public TimeHelper timer = new TimeHelper();
    public TimeHelper tpreset = new TimeHelper();
    public boolean tp;
    int PlayerY;
    private ArrayList<Vec3> path = new ArrayList<>();
    private boolean tryCancelPacket;

    public TeleportCommand() {
        super("tp");
    }

    @Override
    public void run(String alias, @NotNull String[] args) {
        if (args.length == 0) {
            throw new CommandException("Usage: ." + alias + " <x,y,z>  , <player> + (PosY)");
        }
        try {
            timer.reset();
            tp = false;
            targetEntity = null;
            target = null;
            if (args.length == 3) {
                target = new BlockPos(Integer.parseInt(args[0]), Integer.parseInt(args[1]), Integer.parseInt(args[2]));
            } else if (args.length == 2) {
                if (!args[0].contains("LN")) {
                    for (Entity entity : Minecraft.getMinecraft().theWorld.loadedEntityList) {
                        if (entity instanceof EntityPlayer && Minecraft.getMinecraft().thePlayer != entity) {
                            if (entity.getName().equalsIgnoreCase(args[0])) {
                                targetEntity = entity;
                                PlayerY = Integer.parseInt(args[1]);
                                break;
                            }
                        }
                    }

                    if (targetEntity == null) {
                        PlayerUtil.tellPlayer("Can not locate " + args[0]);
                        return;
                    } else {
                        PlayerUtil.tellPlayer("Located Player " + targetEntity.getName() + "And Pos Y Added " + PlayerY + " !");
                    }
                }
            } else if (args.length == 1) {

                if (args[0].contains("FN")) {
                    target = new BlockPos(UhcHelper.x, UhcHelper.y, UhcHelper.z);
                    PlayerUtil.debug("Located Lighting " + "!");
                }
                if (!args[0].contains("LN") && !args[0].contains("TCK")) {
                    for (Entity entity : Minecraft.getMinecraft().theWorld.loadedEntityList) {
                        if (entity instanceof EntityPlayer && Minecraft.getMinecraft().thePlayer != entity) {
                            if (entity.getName().equalsIgnoreCase(args[0])) {
                                targetEntity = entity;
                                PlayerY = 0;
                                break;
                            }
                        }
                    }

                    if (targetEntity == null) {
                        PlayerUtil.tellPlayer("Can not locate " + args[0]);
                        return;
                    } else {
                        PlayerUtil.tellPlayer("Located Player " + targetEntity.getName() + "And Pos Y Added " + PlayerY + " !");
                    }
                }


            }

            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(mc.thePlayer.posX, mc.thePlayer.posY + 0.41999998688697815, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false));
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(mc.thePlayer.posX, mc.thePlayer.posY + 0.675319998688697815, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch, false));

            tryCancelPacket = true;

            PlayerUtil.debug("姝ｅ湪灏濊瘯閫氳繃鏈嶅姟鍣ㄥ欢杩熻幏鍙栧皝鍖呬俊鎭�");
            EventManager.register(this);


        } catch (Exception e) {
            // TODO: handle exception
        }
    }

    @EventTarget
    public void onMove(EventMove e) {
        if (tryCancelPacket) {
            e.x = 0.0;
            e.z = 0.0;
            e.y = 0.0;
        }
    }

    @EventTarget
    public void onPacket(EventPacket e) {
        if (e.getPacket() instanceof S08PacketPlayerPosLook) {
            IS08PacketPlayerPosLook packet = (IS08PacketPlayerPosLook) e.getPacket();
            packet.setPitch(mc.thePlayer.rotationPitch);
            packet.setYaw(mc.thePlayer.rotationYaw);
            tryCancelPacket = false;

            if (e.getPacket() instanceof S08PacketPlayerPosLook) {

                if (!tp) {
                    PlayerUtil.tellPlayer("鏆傛椂缁曡繃鍙嶄綔寮�!");
                    tp = true;
                    e.setCancelled(true);
                }
            }
            //   PlayerUtil.debug("鏆傛椂缁曡繃鍙嶄綔寮�");
        }
    }

    @EventTarget
    public void onSend(EventPacket e) {
        if (tryCancelPacket && (e.getPacket() instanceof C03PacketPlayer.C04PacketPlayerPosition || e.getPacket() instanceof C03PacketPlayer.C06PacketPlayerPosLook || e.getPacket() instanceof C03PacketPlayer.C05PacketPlayerLook)) {
            e.setCancelled(true);
        }
    }


    @EventTarget
    private void onUpdate(EventPreMotion event) {
        if (timer.isDelayComplete(8500)) {
            PlayerUtil.debug("Failed to teleport.");

            EventManager.unregister(this);
        }
        if (tp) {
            tp = false;
            Vec3 topFrom = new Vec3(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
            if (target == null) target = new BlockPos(targetEntity.posX, targetEntity.posY + 1, targetEntity.posZ);
            Vec3 to = new Vec3(target.getX(), target.getY(), target.getZ());
            path = computePath(topFrom, to);
            EventManager.unregister(this);
            tpreset.reset();
            PlayerUtil.tellPlayer("Teleporting to X:" + target.getX() + " Y:" + target.getY() + " Z:" + target.getZ());
            new Thread(() -> {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException interruptedException) {
                    interruptedException.printStackTrace();
                }

                PlayerCapabilities playerCapabilities = new PlayerCapabilities();
                playerCapabilities.isFlying = true;
                playerCapabilities.allowFlying = true;

                mc.thePlayer.sendQueue.addToSendQueue(new C13PacketPlayerAbilities(playerCapabilities));

                for (Vec3 pathElm : path) {
                    mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(pathElm.getX(), pathElm.getY(), pathElm.getZ(), true));
                }
                mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(target.getX(), target.getY(), target.getZ(), true));
                mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C03PacketPlayer(true));
                mc.thePlayer.setPosition(target.getX(), target.getY(), target.getZ());

                PlayerUtil.tellPlayer("Teleported!");
            }).start();
        }

    }


    private ArrayList<Vec3> computePath(Vec3 topFrom, Vec3 to) {
        if (!canPassThrow(new BlockPos(topFrom.mc()))) {
            topFrom = topFrom.addVector(0, 1, 0);
        }
        AStarCustomPathFinder pathfinder = new AStarCustomPathFinder(topFrom, to);
        pathfinder.compute();

        int i = 0;
        Vec3 lastLoc = null;
        Vec3 lastDashLoc = null;
        ArrayList<Vec3> path = new ArrayList<Vec3>();
        ArrayList<Vec3> pathFinderPath = pathfinder.getPath();
        for (Vec3 pathElm : pathFinderPath) {
            if (i == 0 || i == pathFinderPath.size() - 1) {
                if (lastLoc != null) {
                    path.add(lastLoc.addVector(0.5, 0, 0.5));
                }
                path.add(pathElm.addVector(0.5, 0, 0.5));
                lastDashLoc = pathElm;
            } else {
                boolean canContinue = true;
                if (pathElm.squareDistanceTo(lastDashLoc) > 5 * 5) {
                    canContinue = false;
                } else {
                    double smallX = Math.min(lastDashLoc.getX(), pathElm.getX());
                    double smallY = Math.min(lastDashLoc.getY(), pathElm.getY());
                    double smallZ = Math.min(lastDashLoc.getZ(), pathElm.getZ());
                    double bigX = Math.max(lastDashLoc.getX(), pathElm.getX());
                    double bigY = Math.max(lastDashLoc.getY(), pathElm.getY());
                    double bigZ = Math.max(lastDashLoc.getZ(), pathElm.getZ());
                    cordsLoop:
                    for (int x = (int) smallX; x <= bigX; x++) {
                        for (int y = (int) smallY; y <= bigY; y++) {
                            for (int z = (int) smallZ; z <= bigZ; z++) {
                                if (!AStarCustomPathFinder.checkPositionValidity(x, y, z, false)) {
                                    canContinue = false;
                                    break cordsLoop;
                                }
                            }
                        }
                    }
                }
                if (!canContinue) {
                    path.add(lastLoc.addVector(0.5, 0, 0.5));
                    lastDashLoc = lastLoc;
                }
            }
            lastLoc = pathElm;
            i++;
        }
        return path;
    }

    private boolean canPassThrow(BlockPos pos) {
        Block block = Minecraft.getMinecraft().theWorld.getBlockState(new net.minecraft.util.BlockPos(pos.getX(), pos.getY(), pos.getZ())).getBlock();
        return block.getMaterial() == Material.air || block.getMaterial() == Material.plants || block.getMaterial() == Material.vine || block == Blocks.ladder || block == Blocks.water || block == Blocks.flowing_water || block == Blocks.wall_sign || block == Blocks.standing_sign;
    }

    @Override
    public List<String> autocomplete(int arg, String[] args) {
        return new ArrayList<>();
    }
}
