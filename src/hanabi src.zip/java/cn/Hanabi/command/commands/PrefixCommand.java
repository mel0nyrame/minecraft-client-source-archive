package cn.Hanabi.command.commands;

import cn.Hanabi.command.Command;
import cn.Hanabi.gui.notifications.Notification;
import cn.Hanabi.modules.modules.player.Spammer;
import cn.Hanabi.utils.Misc.ClientUtil;
import net.minecraft.client.Minecraft;
import org.jetbrains.annotations.NotNull;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PrefixCommand extends Command {
    private static final String fileDir = Minecraft.getMinecraft().mcDataDir.getAbsolutePath() + "/" + "Hanabi";

    public PrefixCommand() {
        super("prefix");
    }

    @Override
    public void run(String alias, @NotNull String[] args) {
        if (args.length != 1) {
            ClientUtil.sendClientMessage("Failed", Notification.Type.WARNING);
        } else {
            Spammer.prefix = args[0];
            saveText();
            ClientUtil.sendClientMessage("Changed to " + args[0], Notification.Type.SUCCESS);
         }
    }

    @NotNull
    @Override
    public List<String> autocomplete(int arg, String[] args) {
        return new ArrayList<>();
    }
    
    public static void saveText() {
        File f = new File(fileDir + "/prefix.txt");

        try {
           if(!f.exists()) {
              f.createNewFile();
           }

           PrintWriter pw = new PrintWriter(f);
           pw.print(Spammer.prefix);
           pw.close();
        } catch (Exception var2) {
           var2.printStackTrace();
        }

     }

     @SuppressWarnings("resource")
  public static void loadText() throws IOException {
        File f = new File(fileDir + "/prefix.txt");
        if(!f.exists()) {
           f.createNewFile();
        } else {
           BufferedReader br = new BufferedReader(new FileReader(f));

           String line;
           while((line = br.readLine()) != null) {
              try {
                  String text = line;
                 Spammer.prefix = text;
              } catch (Exception var4) {
              }
           }
        }

     }
}
