/*
 * AimWhere Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package cn.fu917.ui

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.features.module.modules.render.ClickGUI
import net.ccbluex.liquidbounce.ui.client.hud.designer.GuiHudDesigner
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.client.hud.element.Side
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.*
import net.ccbluex.liquidbounce.utils.Player.MovementUtils
import net.ccbluex.liquidbounce.utils.render.BlurUtils
import net.ccbluex.liquidbounce.utils.render.ColorManager
import net.ccbluex.liquidbounce.utils.render.Palette
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.shader.shaders.RainbowFontShader
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.*
import net.minecraft.client.Minecraft
import net.minecraft.util.ChatAllowedCharacters
import org.lwjgl.input.Keyboard
import org.lwjgl.opengl.GL11
import java.awt.Color
import java.text.DecimalFormat
import java.text.SimpleDateFormat


/**
 * CustomHUD text element
 *
 * Allows to draw custom text
 */
@ElementInfo(name = "Text")
class Text(x: Double = 10.0, y: Double = 10.0, scale: Float = 1F,
           side: Side = Side.default()) : Element(x, y, scale, side) {

    companion object {

        val DATE_FORMAT = SimpleDateFormat("yyyy-MM-dd")
        val HOUR_FORMAT = SimpleDateFormat("HH:mm")

        val DECIMAL_FORMAT = DecimalFormat("0.00")

        /**
         * Create default element
         */
        fun defaultClient(): Text {
            val text = Text(x = 5.0, y = 5.0, scale = 1F)

            text.displayString.set("Destiny")
            text.shadow.set(true)
            text.fontValue.set(Fonts.minecraftFont)
            text.setColor(Color(255, 255, 255))

            return text
        }

    }

    private val displayString = TextValue("DisplayText", "")
    //line
    private val lineValue = BoolValue("Line", true)
    private val gradientAmountValue = IntegerValue("Gradient-Amount", 25, 1, 50)
    //blur
    private val blurValue = BoolValue("Blur", true)
    private val blurStrength = FloatValue("BlurStrength", 1F, 0F, 30F)
    //Background
    private val skeetRectValue = BoolValue("SkeetRect", false)
    private val backgroundValue = BoolValue("Background", true)
    private val bgredValue = IntegerValue("Background-Red", 0, 0, 255)
    private val bggreenValue = IntegerValue("Background-Green", 0, 0, 255)
    private val bgblueValue = IntegerValue("Background-Blue", 0, 0, 255)
    private val bgalphaValue = IntegerValue("Background-Alpha", 120, 0, 255)
    //animation
    private val animation = BoolValue("Animation", false)
    private val animationDelay = FloatValue("AnimationDelay", 1F, 0.01F, 5F)
    //rainwbow
    private val rainbow = ListValue("Rainbow", arrayOf("Normal","Fade","Astolfo","Other","None"), "Fade")
    private val redValue = IntegerValue("Red", 255, 0, 255)
    private val greenValue = IntegerValue("Green", 255, 0, 255)
    private val blueValue = IntegerValue("Blue", 255, 0, 255)
    private val rainbowSpeed = IntegerValue("RainbowSpeed",10,1,10)
    private val rainbowSaturation = FloatValue("RainbowSaturation", 0.5F,0.01F,1F)
    private val fadeDistanceValue = IntegerValue("FadeDistance", 50, 1, 100)
    private val rainbowX = FloatValue("Rainbow-X", -1000F, -2000F, 2000F)
    private val rainbowY = FloatValue("Rainbow-Y", -1000F, -2000F, 2000F)
    private val shadow = BoolValue("Shadow", true)
    private var fontValue = FontValue("Font", Fonts.font35)

    private var editMode = false
    private var editTicks = 0
    private var prevClick = 0L

    private var displayText = display

    private val display: String
        get() {
            val textContent = if (displayString.get().isEmpty() && !editMode)
                "Text Element"
            else
                displayString.get()


            return multiReplace(textContent)
        }

    private fun getReplacement(str: String): String? {
        if (mc.thePlayer != null) {
            when (str) {
                "x" -> return DECIMAL_FORMAT.format(mc.thePlayer.posX)
                "y" -> return DECIMAL_FORMAT.format(mc.thePlayer.posY)
                "z" -> return DECIMAL_FORMAT.format(mc.thePlayer.posZ)
                "xdp" -> return mc.thePlayer.posX.toString()
                "ydp" -> return mc.thePlayer.posY.toString()
                "zdp" -> return mc.thePlayer.posZ.toString()
                "ping" -> return EntityUtils.getPing(mc.thePlayer).toString()
                "Speed" -> return DECIMAL_FORMAT.format(MovementUtils.getBlockSpeed(mc.thePlayer))
                "timer" -> return DECIMAL_FORMAT.format(mc.timer.timerSpeed)
                "0" -> return "§0"
                "1" -> return "§1"
                "2" -> return "§2"
                "3" -> return "§3"
                "4" -> return "§4"
                "5" -> return "§5"
                "6" -> return "§6"
                "7" -> return "§7"
                "8" -> return "§8"
                "9" -> return "§9"
                "a" -> return "§a"
                "b" -> return "§b"
                "c" -> return "§c"
                "d" -> return "§d"
                "e" -> return "§e"
                "f" -> return "§f"
                "n" -> return "§n"
                "m" -> return "§m"
                "l" -> return "§l"
                "k" -> return "§k"
                "o" -> return "§o"
                "r" -> return "§r"
            }
        }

        return when (str) {
            "username" -> mc.session.username
            "clientName" -> LiquidBounce.CLIENT_NAME
            "clientVersion" -> "b${LiquidBounce.CLIENT_VERSION}"
            "clientCreator" -> LiquidBounce.CLIENT_CREATOR
            "fps" -> Minecraft.getDebugFPS().toString()
            "date" -> DATE_FORMAT.format(System.currentTimeMillis())
            "time" -> HOUR_FORMAT.format(System.currentTimeMillis())
            "serverIp" -> ServerUtils.getRemoteIp()
            "cps", "lcps" -> return CPSCounter.getCPS(CPSCounter.MouseButton.LEFT).toString()
            "mcps" -> return CPSCounter.getCPS(CPSCounter.MouseButton.MIDDLE).toString()
            "rcps" -> return CPSCounter.getCPS(CPSCounter.MouseButton.RIGHT).toString()
            else -> null // Null = don't replace
        }
    }


    private fun multiReplace(str: String): String {
        var lastPercent = -1
        val result = StringBuilder()
        for (i in str.indices) {
            if (str[i] == '%') {
                if (lastPercent != -1) {
                    if (lastPercent + 1 != i) {
                        val replacement = getReplacement(str.substring(lastPercent + 1, i))

                        if (replacement != null) {
                            result.append(replacement)
                            lastPercent = -1
                            continue
                        }
                    }
                    result.append(str, lastPercent, i)
                }
                lastPercent = i
            } else if (lastPercent == -1) {
                result.append(str[i])
            }
        }

        if (lastPercent != -1) {
            result.append(str, lastPercent, str.length)
        }

        return result.toString()
    }
    private fun drawExhiRect(x: Float, y: Float, x2: Float, y2: Float) {
        RenderUtils.drawRect(x - 1.5F, y - 1.5F, x2 + 1.5F, y2 + 1.5F, Color(8, 8, 8).rgb)
        RenderUtils.drawRect(x - 1, y - 1, x2 + 1, y2 + 1, Color(49, 49, 49).rgb)
        RenderUtils.drawBorderedRect(x + 2F, y + 2F, x2 - 2F, y2 - 2F, 0.5F, Color(18, 18, 18).rgb, Color(28, 28, 28).rgb)
    }
    /**
     * Draw element
     */
    override fun drawElement(): Border {
        val counter = intArrayOf(0)
        val color = Color(redValue.get(), greenValue.get(), blueValue.get()).rgb
        val fontRenderer = fontValue.get()
        val addColor = color + Color(0, 0, 0, 50).rgb
        val rainbow = rainbow.get()
        var length = 0

        val floatX = renderX.toFloat()
        val floatY = renderY.toFloat()

        if (blurValue.get()) {
            GL11.glTranslated(-renderX, -renderY, 0.0)
            GL11.glScalef(1F, 1F, 1F)
            GL11.glPushMatrix()
            BlurUtils.blurArea(floatX * scale - 2F * scale, floatY * scale - 2F * scale, (floatX + fontRenderer.getStringWidth(displayText) + 2F) * scale, (floatY + fontRenderer.FONT_HEIGHT) * scale, blurStrength.get())
            GL11.glPopMatrix()
            GL11.glScalef(scale, scale, scale)
            GL11.glTranslated(renderX, renderY, 0.0)
        }

        if (backgroundValue.get()) {
            RenderUtils.drawRect(-2F, -2F, fontRenderer.getStringWidth(displayText) + 2F, fontRenderer.FONT_HEIGHT + 3F, Color(bgredValue.get(), bggreenValue.get(), bgblueValue.get(), bgalphaValue.get()))
        }
        if (lineValue.get()) {
            val barLength = (fontRenderer.getStringWidth(displayText) + 4F).toDouble()

            for (i in 0..(gradientAmountValue.get()-1)) {
                val barStart = i.toDouble() / gradientAmountValue.get().toDouble() * barLength
                val barEnd = (i + 1).toDouble() / gradientAmountValue.get().toDouble() * barLength
                RenderUtils.drawGradientSideways(-2.0 + barStart, -3.0, -2.0 + barEnd, -2.0,Color(ClickGUI.colorRedValue.get(), ClickGUI.colorGreenValue.get(), ClickGUI.colorBlueValue.get()).rgb,Color(
                    ClickGUI.colorRedValue.get(), ClickGUI.colorGreenValue.get(), ClickGUI.colorBlueValue.get()).rgb)
            }
        }
        if (skeetRectValue.get()) {
            drawExhiRect(-4F, if (lineValue.get()) -5F else -4F, fontRenderer.getStringWidth(displayText) + 4F, fontRenderer.FONT_HEIGHT + 2F)
        }
        RainbowFontShader.begin(rainbow == "Normal", if (rainbowX.get() == 0.0F) 0.0F else 1.0F / rainbowX.get(), if (rainbowY.get() == 0.0F) 0.0F else 1.0F / rainbowY.get(), System.currentTimeMillis() % 10000 / 10000F).use {
            if(rainbow == "Fade")
                for(i in displayText.toCharArray()) {
                    fontRenderer.drawString(i.toString(), 0F + length, 0F,
                        Palette.fade(Color(redValue.get(), greenValue.get(), blueValue.get()), counter[0] * fadeDistanceValue.get(),displayText.length * 130).rgb, shadow.get())
                    length += fontRenderer.getCharWidth(i)
                    counter[0] += 1
                    counter[0] = counter[0].coerceIn(0, displayText.length)
                }
            else if(rainbow == "Other")
                for (i in displayText.toCharArray()){
                    fontRenderer.drawString(i.toString(), 0F + length, 0F,
                        ColorManager.fluxRainbow(-100, counter[0] * -50 * rainbowSpeed.get().toLong(),rainbowSaturation.get()), shadow.get())
                    length += fontRenderer.getCharWidth(i)
                    counter[0] += 1
                    counter[0] = counter[0].coerceIn(0, displayText.length)
                }
            else if(rainbow == "Astolfo")
                for (i in displayText.toCharArray()){
                    fontRenderer.drawString(i.toString(), 0F + length, 0F,
                        ColorManager.Astolfo(counter[0] * 100), shadow.get())
                    length += fontRenderer.getCharWidth(i)
                    counter[0] += 1
                    counter[0] = counter[0].coerceIn(0, displayText.length)
                }
            else
                fontRenderer.drawString(displayText, 0F, 0F, if(rainbow != "None") 0 else color, shadow.get())
        }

        if (editMode && mc.currentScreen !is GuiHudDesigner) {
            editMode = false
            updateElement()
        }

        return Border(
            -2F,
            -2F,
            fontRenderer.getStringWidth(displayText) + 2F,
            fontRenderer.FONT_HEIGHT.toFloat()
        )
    }
    private var count = 0
    private var reverse = false;

    private var timer = MSTimer()
    override fun updateElement() {
        editTicks += 5
        if (editTicks > 80) editTicks = 0

        if (count < 0 || count > display.length) {
            count = 0;
            reverse = false
        }

        if (!editMode && animation.get() && timer.hasTimePassed((animationDelay.get() * 1000).toLong())) {
            if (reverse) count -= 1 else count += 1
            if (count == display.length || count == 0) reverse = !reverse
            timer.reset()
        }

        val tempDisplayText = if (animation.get()) display.substring(0, count) else display

        displayText = if (editMode) displayString.get() else tempDisplayText

    }

    override fun handleMouseClick(x: Double, y: Double, mouseButton: Int) {
        if (isInBorder(x, y) && mouseButton == 0) {
            if (System.currentTimeMillis() - prevClick <= 250L)
                editMode = true

            prevClick = System.currentTimeMillis()
        } else {
            editMode = false
        }
    }

    override fun handleKey(c: Char, keyCode: Int) {
        if (editMode && mc.currentScreen is GuiHudDesigner) {
            if (keyCode == Keyboard.KEY_BACK) {
                if (displayString.get().isNotEmpty())
                    displayString.set(displayString.get().substring(0, displayString.get().length - 1))

                updateElement()
                return
            }

            if (ChatAllowedCharacters.isAllowedCharacter(c) || c == '§')
                displayString.set(displayString.get() + c)

            updateElement()
        }
    }

    fun setColor(c: Color): Text {
        redValue.set(c.red)
        greenValue.set(c.green)
        blueValue.set(c.blue)
        return this
    }

}