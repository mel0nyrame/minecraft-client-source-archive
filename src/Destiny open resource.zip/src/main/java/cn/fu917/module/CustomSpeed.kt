/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package cn.fu917.module

import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.event.EventPreUpdate
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.JumpEvent
import net.ccbluex.liquidbounce.utils.MovementUtils.*
import net.ccbluex.liquidbounce.event.MoveEvent

class CustomSpeed : SpeedMode("Custom") {
    override fun onPreUpdate(event: EventPreUpdate) {}
    override fun onMotion() {
        if (isMoving()) {
            val speed = LiquidBounce.moduleManager.getModule(Speed::class.java) as Speed? ?: return
            mc.timer.timerSpeed = speed.customTimerValue.get()
            if (mc.thePlayer.onGround) {
                strafe(speed.customSpeedValue.get() + 0.1f * getSpeedEffect())
                mc.thePlayer.motionY = speed.customYValue.get().toDouble()
            } else if (speed.customStrafeValue.get()) strafe(speed.customSpeedValue.get()) else strafe()
        } else {
            mc.thePlayer.motionZ *= 1.0
            mc.thePlayer.motionX *= 1.0
        }
    }

    override fun onEnable() {
        val speed = LiquidBounce.moduleManager.getModule(Speed::class.java) as Speed? ?: return
        if (speed.resetXZValue.get()) {
            mc.thePlayer.motionZ = 0.0
            mc.thePlayer.motionX = 0.0
        }
        if (speed.resetYValue.get()) mc.thePlayer.motionY = 0.0
        super.onEnable()
    }

    override fun onDisable() {
        mc.timer.timerSpeed = 1f
        super.onDisable()
    }
    override fun onJump(event: JumpEvent) {
        if (mc.thePlayer != null)
            event.cancelEvent()
    }
    override fun onUpdate() {}
    override fun onMove(event: MoveEvent) {}
}