package cn.fu917.module;

import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.*;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.value.BoolValue;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;

import java.util.ArrayList;
import java.util.List;

import static net.ccbluex.liquidbounce.utils.MovementUtils.*;

@ModuleInfo(name = "HytSpeed", description = ":/", category = ModuleCategory.MOVEMENT)
public class HytSpeed extends Module {
    private final FloatValue speed = new FloatValue("Speed", 0.5f, 0.15f, 8f);
    private final FloatValue motionY = new FloatValue("MotionY", 0.42f, 0.1f, 2f);
    private final BoolValue HytPit= new BoolValue("HytPit",false);

    private final List<Packet<?>> packets = new ArrayList<>();
    boolean doAsFly = false;
    double stage = 0;
    double timer = 0;

    public void move() {
        if(isMoving()){
            strafe(speed.get());
            mc.thePlayer.motionY = motionY.get();
        }
    }

    @Override
    public void onEnable() {
        timer = 0;
    }

    @Override
    public void onDisable() {
        doAsFly = false;
        if (packets.size() > 0) {
            for (Packet<?> packet : packets) {
                mc.thePlayer.sendQueue.addToSendQueue(packet);
                packets.clear();
            }
        }
    }

    @EventTarget
    public void onJump(JumpEvent event){
        if (mc.thePlayer!=null)
            event.cancelEvent();
    }
    @EventTarget
    public void onMotion(MotionEvent event){
        final TargetStrafe targetStrafe =(TargetStrafe) LiquidBounce.moduleManager.getModule(TargetStrafe.class);
        if (targetStrafe.getCanStrafe()&&isMoving()&&HytPit.get()) {
            if (mc.thePlayer.onGround) {
                strafe(0.35f);
                mc.thePlayer.motionY = 0.15;
            } else {
                strafe(getSpeed());
            }
        }
    }
    @EventTarget
    public void onUpdate(UpdateEvent event) {
        final TargetStrafe targetStrafe =(TargetStrafe) LiquidBounce.moduleManager.getModule(TargetStrafe.class);

        if(!isMoving()){
            timer=0;
        } else {
            timer++;
        }
        if (mc.thePlayer.onGround && timer>1) {
            doAsFly = true;
            stage = 0;
            if ((!targetStrafe.getCanStrafe()&&HytPit.get())|| !HytPit.get()) {
                move();
            }
        }
        if (stage >= 1) {
            doAsFly = false;
            if (packets.size() > 0) {
                for (Packet<?> packet : packets) {
                    mc.thePlayer.sendQueue.addToSendQueue(packet);
                    packets.clear();
                }
            }
        }
    }

    @EventTarget
    public void onPacket(PacketEvent event) {
        if (!doAsFly) return;
        final Packet<?> packet = event.getPacket();
        if (packet instanceof C03PacketPlayer) {
            event.cancelEvent();
            packets.add(packet);
            stage++;
        }
    }
}
