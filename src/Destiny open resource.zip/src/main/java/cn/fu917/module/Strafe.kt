package cn.fu917.module

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import kotlin.math.*

@ModuleInfo(name = "Strafe", description = "Allows you to freely move in mid air.", category = ModuleCategory.MOVEMENT)
class Strafe : Module() {

    private val mode = ListValue("Mode", arrayOf("Smart","Simple"),"Simple")
    private var strengthValue= FloatValue("Strength", 0.5F, -1F, 2F).displayable { mode.get().equals("Smart") }
    private var noMoveStopValue = BoolValue("NoMoveStop", false).displayable { mode.get().equals("Smart") }
    private var onGroundStrafeValue = BoolValue("OnGround", false).displayable { mode.get().equals("Smart") }
    private var allDirectionsJumpValue = BoolValue("Omni", false).displayable { mode.get().equals("Smart") }
    private var HypixelMod = BoolValue("Hypixel",false).displayable { mode.get().equals("Smart") }

    private var wasDown: Boolean = false
    private var jump: Boolean = false
    @EventTarget
    fun onMotion(event: MotionEvent) {
        if (mode.get().equals("Simple",ignoreCase = true)) {
            if (event.eventState == EventState.POST)
                return
            MovementUtils.strafe()
        }
    }
    @EventTarget
    fun onJump(event: JumpEvent) {
        if (mode.get().equals("Smart",ignoreCase = true)) {
            if (jump) {
                event.cancelEvent()
            }
        }
    }

    override fun onEnable() {
        wasDown = false
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        val speed = (LiquidBounce.moduleManager.getModule(Speed::class.java) as Speed?)!!
        if (mode.get().equals("Smart",ignoreCase = true)) {
            if ((HypixelMod.get() && MovementUtils.getSpeedEffect() == 2 && speed.state )|| !HypixelMod.get()) {
                if (mc.thePlayer!!.onGround && mc.gameSettings.keyBindJump.isKeyDown && allDirectionsJumpValue.get() && (mc.thePlayer!!.movementInput.moveForward != 0F || mc.thePlayer!!.movementInput.moveStrafe != 0F) && !(mc.thePlayer!!.isInWater || mc.thePlayer!!.isInLava || mc.thePlayer!!.isOnLadder || mc.thePlayer!!.isInWeb)) {
                    if (mc.gameSettings.keyBindJump.isKeyDown) {
                        mc.gameSettings.keyBindJump.pressed = false
                        wasDown = true
                    }
                    val yaw = mc.thePlayer!!.rotationYaw
                    mc.thePlayer!!.rotationYaw = getMoveYaw()
                    mc.thePlayer!!.jump()
                    mc.thePlayer!!.rotationYaw = yaw
                    jump = true
                    if (wasDown) {
                        mc.gameSettings.keyBindJump.pressed = true
                        wasDown = false
                    }
                } else {
                    jump = false
                }
            }
        }
    }

    @EventTarget
    fun onStrafe(event: StrafeEvent) {
        val speedmoduel = (LiquidBounce.moduleManager.getModule(Speed::class.java) as Speed?)!!
        val shotSpeed = sqrt((mc.thePlayer!!.motionX * mc.thePlayer!!.motionX) + (mc.thePlayer!!.motionZ * mc.thePlayer!!.motionZ))
        val speed = (shotSpeed * strengthValue.get())
        val motionX = (mc.thePlayer!!.motionX * (1 - strengthValue.get()))
        val motionZ = (mc.thePlayer!!.motionZ * (1 - strengthValue.get()))
        if (mode.get().equals("Smart",ignoreCase = true)) {
            if ((HypixelMod.get() && MovementUtils.getSpeedEffect() == 2 && speedmoduel.state )|| !HypixelMod.get()) {
                if (!(mc.thePlayer!!.movementInput.moveForward != 0F || mc.thePlayer!!.movementInput.moveStrafe != 0F)) {
                    if (noMoveStopValue.get()) {
                        mc.thePlayer!!.motionX = 0.0
                        mc.thePlayer!!.motionZ = 0.0
                    }
                    return
                }
                if (!mc.thePlayer!!.onGround || onGroundStrafeValue.get()) {
                    val yaw = getMoveYaw()
                    mc.thePlayer!!.motionX = (((-sin(Math.toRadians(yaw.toDouble())) * speed) + motionX))
                    mc.thePlayer!!.motionZ = (((cos(Math.toRadians(yaw.toDouble())) * speed) + motionZ))
                }
            }
        }
    }


    private fun getMoveYaw(): Float {
        var moveYaw = mc.thePlayer!!.rotationYaw
        if (mc.thePlayer!!.moveForward != 0F && mc.thePlayer!!.moveStrafing == 0F) {
            moveYaw += if(mc.thePlayer!!.moveForward > 0) 0 else 180
        } else if (mc.thePlayer!!.moveForward != 0F && mc.thePlayer!!.moveStrafing != 0F) {
            if (mc.thePlayer!!.moveForward > 0) {
                moveYaw += if (mc.thePlayer!!.moveStrafing > 0) -45 else 45
            } else {
                moveYaw -= if (mc.thePlayer!!.moveStrafing > 0) -45 else 45
            }
            moveYaw += if(mc.thePlayer!!.moveForward > 0) 0 else 180
        } else if (mc.thePlayer!!.moveStrafing != 0F && mc.thePlayer!!.moveForward == 0F) {
            moveYaw += if(mc.thePlayer!!.moveStrafing > 0) -90 else 90
        }
        return moveYaw
    }
}
