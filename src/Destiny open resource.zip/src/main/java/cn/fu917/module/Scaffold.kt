package cn.fu917.module

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.*
import net.ccbluex.liquidbounce.utils.Utils.Player.MovementUtils
import net.ccbluex.liquidbounce.utils.Utils.Timer.TimeUtils
import net.ccbluex.liquidbounce.utils.block.BlockUtils.canBeClicked
import net.ccbluex.liquidbounce.utils.block.BlockUtils.isReplaceable
import net.ccbluex.liquidbounce.utils.block.PlaceInfo
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.client.renderer.GlStateManager
import net.minecraft.client.settings.GameSettings
import net.minecraft.init.Blocks
import net.minecraft.item.ItemBlock
import net.minecraft.network.play.client.C09PacketHeldItemChange
import net.minecraft.network.play.client.C0APacketAnimation
import net.minecraft.network.play.client.C0BPacketEntityAction
import net.minecraft.util.*
import org.lwjgl.input.Keyboard
import org.lwjgl.opengl.GL11
import java.awt.Color


@ModuleInfo(
    name = "Scaffold",
    description = "Automatically places blocks beneath your feet.",
    category = ModuleCategory.WORLD,
    keyBind = Keyboard.KEY_G
)
class Scaffold : Module() {
    /**
     * OPTIONS
     */
    // Mode
    val modeValue = ListValue("Mode", arrayOf("Normal", "Rewinside", "Expand", "AAC", "Hypixel"), "Normal")

    // Delay
    private val maxDelayValue: IntegerValue = object : IntegerValue("MaxDelay", 0, 0, 1000) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val i = minDelayValue.get()
            if (i > newValue) set(i)
        }
    }
    private val minDelayValue: IntegerValue = object : IntegerValue("MinDelay", 0, 0, 1000) {
        override fun onChanged(oldValue: Int, newValue: Int) {
            val i = maxDelayValue.get()
            if (i < newValue) set(i)
        }
    }
    private val Yaw = IntegerValue("HypixelYaw", 180, -360, 360)
    private val PitchValue = IntegerValue("HypixelPitch", 79, 60, 100)
    private val aacPitchValue = IntegerValue("AACPitch", 79, 60, 100)
    private val placeableDelay = BoolValue("PlaceableDelay", false)
    private val Bypass = ListValue("Bypass", arrayOf("Normal","Fast","None"),"Normal")
    // AutoBlock
    private val autoBlockValue = ListValue("AutoBlock", arrayOf("Switch", "Spoof"), "Spoof")

    // Basic stuff
    @JvmField
    val sprintValue = BoolValue("Sprint", true)
    private val swingValue = BoolValue("Swing", true)
    private val searchValue = BoolValue("Search", true)
    private val downValue = BoolValue("Down", true)
    private val silentRotationValue = BoolValue("SilentRotation", true)
    private val HypixelSlow = BoolValue("HypixelSlowDown", true)
    private val hypixelslowset = FloatValue("MotionValue",0.475f,0f,1f)
    private val Test = BoolValue("OnlyGround",false)
    private val placeModeValue = ListValue("PlaceTiming", arrayOf("Pre", "Post"), "Post")

    // Eagle
    private val eagleValue = BoolValue("Eagle", false)
    private val eagleSilentValue = BoolValue("EagleSilent", false)
    private val blocksToEagleValue = IntegerValue("BlocksToEagle", 0, 0, 10)

    // Expand
    //private final IntegerValue expandLengthValue = new IntegerValue("ExpandLength", 5, 1, 6);
    private val expandLengthValue = FloatValue("ExpandLength", 5f, 1f, 6f)

    // Rotations
    private val rotationsValue = BoolValue("Rotations", true)
    private val rotationStrafeValue =
        ListValue("RotationStrafe", arrayOf("Off", "Strict", "Silent", "NoStrafe", "Test"), "Off")
    private val keepLengthValue = IntegerValue("KeepRotationLength", 0, 0, 20)
    private val keepRotationValue = BoolValue("KeepRotation", false)

    // Zitter
    private val zitterValue = BoolValue("Zitter", false)
    private val zitterModeValue = ListValue("ZitterMode", arrayOf("Teleport", "Smooth"), "Teleport")
    private val zitterSpeed = FloatValue("ZitterSpeed", 0.13f, 0.1f, 0.3f)
    private val zitterStrength = FloatValue("ZitterStrength", 0.072f, 0.05f, 0.2f)

    // Game
    private val timerValue = FloatValue("Timer", 1f, 0.1f, 10f)
    private val speedModifierValue = FloatValue("SpeedModifier", 1f, 0f, 2f)

    // Safety
    private val sameYValue = ListValue("SameY", arrayOf("Simple", "AutoJump", "OnlySpeed", "OFF"), "OnlySpeed")
    private val safeWalkValue = BoolValue("SafeWalk", true)
    private val airSafeValue = BoolValue("AirSafe", false)

    // Visuals
    private val debugValue = BoolValue("Debug", false)

    /**
     * MODULE
     */
    // Target block
    private var targetPlace: PlaceInfo? = null

    // Launch position
    private var launchY = 0

    //Rotation
    private var rotation = false

    // Rotation lock
    private var lockRotation: Rotation? = null

    // Auto block slot
    private var slot = 0

    // Zitter Smooth
    private var zitterDirection = false

    // Delay
    private val delayTimer = MSTimer()
    private val zitterTimer = MSTimer()
    private var delay: Long = 0
    private val rotationTimer = MSTimer()
    private var rotYaw = 0

    // Eagle
    private var placedBlocksWithoutEagle = 0
    private var eagleSneaking = false

    // Down
    private var shouldGoDown = false
    private var canSameY = false

    /**
     * Enable module
     */
    override fun onEnable() {
        if (mc.thePlayer == null) return
        launchY = mc.thePlayer.posY.toInt()
    }

    @EventTarget
    fun onStrafe(event: StrafeEvent) {
        if (rotationStrafeValue.get().equals("Off", ignoreCase = true)) {
            return
        }
        if (rotationStrafeValue.get().equals("Strict", ignoreCase = true)) {
            if (RotationUtils.serverRotation == null) {
                return
            }
            val yaw = RotationUtils.serverRotation.yaw
            var strafe = event.strafe
            var forward = event.forward
            val friction = event.friction
            var f = strafe * strafe + forward * forward
            if (f >= 1.0E-4f) {
                f = MathHelper.sqrt_float(f)
                if (f < 1.0f) f = 1.0f
                f = friction / f
                strafe *= f
                forward *= f
                val yawSin = MathHelper.sin((yaw * Math.PI / 180f).toFloat())
                val yawCos = MathHelper.cos((yaw * Math.PI / 180f).toFloat())
                mc.thePlayer.motionX += (strafe * yawCos - forward * yawSin).toDouble()
                mc.thePlayer.motionZ += (forward * yawCos + strafe * yawSin).toDouble()
            }
            event.cancelEvent()
        }
        if (rotationStrafeValue.get().equals("NoStrafe", ignoreCase = true)) {
            event.cancelEvent()
        }
        if (rotationStrafeValue.get().equals("Silent", ignoreCase = true)) {
            RotationUtils.serverRotation.applyStrafeToPlayer(event)
            event.cancelEvent()
        }
        if (rotationStrafeValue.get().equals("Test", ignoreCase = true)) {
            MovementUtils.setMoveSpeed(0.1)
            event.cancelEvent()
        }
    }

    /**
     * Update event
     *
     * @param event
     */
    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        mc.timer.timerSpeed = if (LiquidBounce.moduleManager[Speed::class.java]!!.state) 1f else timerValue.get()
        shouldGoDown = downValue.get() && GameSettings.isKeyDown(mc.gameSettings.keyBindSneak) && blocksAmount > 1
        if (shouldGoDown) mc.gameSettings.keyBindSneak.pressed = false
        when(sameYValue.get().toLowerCase()){
            "simple" -> {
                canSameY = true
            }
            "autojump" -> {
                canSameY = true
                if (MovementUtils.isMoving() && mc.thePlayer.onGround)
                    mc.thePlayer.jump()
            }
            "onlyspeed" -> {
                canSameY= (LiquidBounce.moduleManager.getModule(Speed::class.java) as Speed).state
            }
            else -> {
                canSameY = false
            }
        }
        if (mc.thePlayer.onGround) {
            val mode = modeValue.get()
            launchY = mc.thePlayer.posY.toInt()
            // Rewinside scaffold mode
            if (mode.equals("Rewinside", ignoreCase = true)) {
                MovementUtils.strafe(0.2f)
                mc.thePlayer.motionY = 0.0
            }

            // Smooth Zitter
            if (zitterValue.get() && zitterModeValue.get().equals("smooth", ignoreCase = true)) {
                if (!GameSettings.isKeyDown(mc.gameSettings.keyBindRight)) mc.gameSettings.keyBindRight.pressed = false
                if (!GameSettings.isKeyDown(mc.gameSettings.keyBindLeft)) mc.gameSettings.keyBindLeft.pressed = false
                if (zitterTimer.hasTimePassed(100)) {
                    zitterDirection = !zitterDirection
                    zitterTimer.reset()
                }
                if (zitterDirection) {
                    mc.gameSettings.keyBindRight.pressed = true
                    mc.gameSettings.keyBindLeft.pressed = false
                } else {
                    mc.gameSettings.keyBindRight.pressed = false
                    mc.gameSettings.keyBindLeft.pressed = true
                }
            }

            // Eagle
            if (eagleValue.get() && !shouldGoDown) {
                if (placedBlocksWithoutEagle >= blocksToEagleValue.get()) {
                    val shouldEagle = mc.theWorld.getBlockState(
                        BlockPos(
                            mc.thePlayer.posX,
                            mc.thePlayer.posY - 1.0, mc.thePlayer.posZ
                        )
                    ).block === Blocks.air
                    if (eagleSilentValue.get()) {
                        if (eagleSneaking != shouldEagle) {
                            mc.netHandler.addToSendQueue(
                                C0BPacketEntityAction(
                                    mc.thePlayer,
                                    if (shouldEagle) C0BPacketEntityAction.Action.START_SNEAKING else C0BPacketEntityAction.Action.STOP_SNEAKING
                                )
                            )
                        }
                        eagleSneaking = shouldEagle
                    } else mc.gameSettings.keyBindSneak.pressed = shouldEagle
                    placedBlocksWithoutEagle = 0
                } else placedBlocksWithoutEagle++
            }

            // Zitter
            if (zitterValue.get() && zitterModeValue.get().equals("teleport", ignoreCase = true)) {
                MovementUtils.strafe(zitterSpeed.get())
                val yaw = Math.toRadians(mc.thePlayer.rotationYaw + if (zitterDirection) 90.0 else -90.0)
                mc.thePlayer.motionX -= Math.sin(yaw) * zitterStrength.get()
                mc.thePlayer.motionZ += Math.cos(yaw) * zitterStrength.get()
                zitterDirection = !zitterDirection
            }
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (mc.thePlayer == null) return
        val packet = event.packet

        // AutoBlock
        if (packet is C09PacketHeldItemChange) {
            slot = packet.slotId
        }
    }

    var width = 0
    @EventTarget
    fun onMotion(event: MotionEvent) {
        val eventState = event.eventState
        if ((modeValue.get() == "AAC" || modeValue.get()
                .equals("RedeSky", ignoreCase = true)) && keepRotationValue.get()
        ) {
            mc.thePlayer.isSprinting = false
            if (mc.gameSettings.keyBindForward.isKeyDown) {
                rotYaw = 180
            }
            if (mc.gameSettings.keyBindLeft.isKeyDown) {
                rotYaw = 90
            }
            if (mc.gameSettings.keyBindRight.isKeyDown) {
                rotYaw = 270
            }
            if (mc.gameSettings.keyBindBack.isKeyDown) {
                rotYaw = 0
            }
            rotation =
                !mc.gameSettings.keyBindForward.isKeyDown && !mc.gameSettings.keyBindLeft.isKeyDown && !mc.gameSettings.keyBindRight.isKeyDown && !mc.gameSettings.keyBindBack.isKeyDown
            val AACRotation = Rotation(
                mc.thePlayer.rotationYaw + rotYaw, aacPitchValue.get()
                    .toFloat()
            )
            if (silentRotationValue.get()) {
                RotationUtils.setTargetRotation(AACRotation)
            } else {
                AACRotation.toPlayer(mc.thePlayer)
            }
        }
        if (modeValue.get() == "Hypixel" && keepRotationValue.get()) {
            rotation =
                !mc.gameSettings.keyBindForward.isKeyDown && !mc.gameSettings.keyBindLeft.isKeyDown && !mc.gameSettings.keyBindRight.isKeyDown && !mc.gameSettings.keyBindBack.isKeyDown
            val AACRotation = Rotation(
                mc.thePlayer.rotationYaw + Yaw.get(), PitchValue.get()
                    .toFloat()
            )
            if (silentRotationValue.get()) {
                RotationUtils.setTargetRotation(AACRotation)
            } else {
                AACRotation.toPlayer(mc.thePlayer)
            }
        } else {
//            if (sprintValue.get() && mc.thePlayer.moveForward != 0f) {
//                mc.thePlayer.isSprinting = true
//            }
            if (!mc.thePlayer.movementInput.jump && sprintValue.get() && Bypass.get() !== "None") {
                when (Bypass.get()) {
                    "Normal" -> if (mc.thePlayer.ticksExisted % 5 == 0 && !mc.thePlayer.isSprinting) {
                        if (eventState == EventState.PRE) {
                            PacketUtils.sendPacketNoEvent(
                                C0BPacketEntityAction(
                                    mc.thePlayer,
                                    C0BPacketEntityAction.Action.START_SPRINTING
                                )
                            )
                        }
                    } else if (mc.thePlayer.ticksExisted % 2 == 0 && mc.thePlayer.isSprinting && eventState == EventState.POST) {
                        PacketUtils.sendPacketNoEvent(
                            C0BPacketEntityAction(
                                mc.thePlayer,
                                C0BPacketEntityAction.Action.STOP_SPRINTING
                            )
                        )
                    }
                }
            }else {
                if (sprintValue.get() && mc.thePlayer.moveForward != 0f) {
                    mc.thePlayer.isSprinting = true
                }
            }
        }
        if (rotationTimer.hasTimePassed(3000L) && debugValue.get()) {
            ClientUtils.displayChatMessage("§8[§9§lDebug§8] RotationYaw:" + mc.thePlayer.rotationYaw + " | Pitch:" + mc.thePlayer.rotationPitch)
            rotationTimer.reset()
        }
        // Lock Rotation
        if (rotationsValue.get() && keepRotationValue.get() && lockRotation != null && (modeValue.get() != "AAC" && modeValue.get()
                .equals("Hypixel", ignoreCase = true) || rotation) && modeValue.get() != "RedeSky"
        ) RotationUtils.setTargetRotation(lockRotation)

        // Place block
        if (placeModeValue.get().equals(eventState.stateName, ignoreCase = true)) place()

        // Update and search for new block
        if (eventState === EventState.PRE) update()

        // Reset placeable delay
        if (targetPlace == null && placeableDelay.get()) delayTimer.reset()
    }

    private fun update() {
        val isHeldItemBlock = mc.thePlayer.heldItem != null && mc.thePlayer.heldItem.item is ItemBlock
        if (if (!autoBlockValue.get()
                    .equals("Off", ignoreCase = true)
            ) InventoryUtils.findAutoBlockBlock() == -1 && !isHeldItemBlock else !isHeldItemBlock
        ) return
        findBlock(modeValue.get().equals("expand", ignoreCase = true))
    }

    /**
     * Search for new target block
     */
    private fun findBlock(expand: Boolean) {
        val blockPosition = if (shouldGoDown) if (mc.thePlayer.posY == mc.thePlayer.posY.toInt() + 0.5) BlockPos(
            mc.thePlayer.posX,
            mc.thePlayer.posY - 0.6,
            mc.thePlayer.posZ
        ) else BlockPos(
            mc.thePlayer.posX, mc.thePlayer.posY - 0.6, mc.thePlayer.posZ
        ).down() else if (mc.thePlayer.posY == mc.thePlayer.posY.toInt() + 0.5 && !canSameY) BlockPos(
            mc.thePlayer
        ) else if(canSameY && launchY<=mc.thePlayer.posY) BlockPos(
            mc.thePlayer.posX, launchY-1.0, mc.thePlayer.posZ) else BlockPos(
            mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ
        ).down()
        //        if(sameYValue.get()){
//            if (MovementUtils.isMoving() && !mc.thePlayer.onGround){
//                launchY = mc.thePlayer.posY;
//            }
//            if (mc.thePlayer.onGround && mc.thePlayer.fallDistance <  0.1 || mc.thePlayer.fallDistance > 0.8)
//                launchY = mc.thePlayer.posY;
//        }
        if (!expand && (!isReplaceable(blockPosition) || search(blockPosition, !shouldGoDown))) return
        if (expand) {
            for (i in 0 until expandLengthValue.get().toInt()) {
                if (search(
                        blockPosition.add(
                            if (mc.thePlayer.horizontalFacing == EnumFacing.WEST) -i else if (mc.thePlayer.horizontalFacing == EnumFacing.EAST) i else 0,
                            0,
                            if (mc.thePlayer.horizontalFacing == EnumFacing.NORTH) -i else if (mc.thePlayer.horizontalFacing == EnumFacing.SOUTH) i else 0
                        ), false
                    )
                ) return
            }
        } else if (searchValue.get()) {
            for (x in -1..1) for (z in -1..1) if (search(blockPosition.add(x, 0, z), !shouldGoDown)) return
        }
    }

    /**
     * Place target block
     */
    private fun place() {
        if (targetPlace == null) {
            if (placeableDelay.get()) delayTimer.reset()
            return
        }
        if (!delayTimer.hasTimePassed(delay) || canSameY && launchY - 1 != targetPlace!!.vec3.yCoord.toInt())
            return

        var blockSlot = -1
        var itemStack = mc.thePlayer.heldItem
        if (mc.thePlayer.heldItem == null || mc.thePlayer.heldItem.item !is ItemBlock || mc.thePlayer.heldItem.stackSize <= 0) {
            if (autoBlockValue.get().equals("Off", ignoreCase = true)) return
            blockSlot = InventoryUtils.findAutoBlockBlock()
            if (blockSlot == -1) return
            if (autoBlockValue.get().equals("Spoof", ignoreCase = true)) {
                if (blockSlot - 36 != slot) mc.netHandler.addToSendQueue(C09PacketHeldItemChange(blockSlot - 36))
            } else {
                mc.thePlayer.inventory.changeCurrentItem(blockSlot - 36)
                mc.playerController.updateController()
            }
            itemStack = mc.thePlayer.inventoryContainer.getSlot(blockSlot).stack
        }
        if (mc.playerController.onPlayerRightClick(
                mc.thePlayer,
                mc.theWorld,
                itemStack,
                targetPlace!!.blockPos,
                targetPlace!!.enumFacing,
                targetPlace!!.vec3
            )
        ) {
            delayTimer.reset()
            delay = TimeUtils.randomDelay(minDelayValue.get(), maxDelayValue.get())
            if (mc.thePlayer.onGround) {
                val modifier = speedModifierValue.get()
                mc.thePlayer.motionX *= modifier.toDouble()
                mc.thePlayer.motionZ *= modifier.toDouble()
            }
            if (swingValue.get()) mc.thePlayer.swingItem() else mc.netHandler.addToSendQueue(C0APacketAnimation())
        }

//        if (!stayAutoBlock.get() && blockSlot >= 0)
//            mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));

        // Reset
        targetPlace = null
    }

    /**
     * Disable scaffold module
     */
    override fun onDisable() {
        rotYaw = 0
        if (mc.thePlayer == null) return
        if (!GameSettings.isKeyDown(mc.gameSettings.keyBindSneak)) {
            mc.gameSettings.keyBindSneak.pressed = false
            if (eagleSneaking) mc.netHandler.addToSendQueue(
                C0BPacketEntityAction(
                    mc.thePlayer,
                    C0BPacketEntityAction.Action.STOP_SNEAKING
                )
            )
        }
        if (!GameSettings.isKeyDown(mc.gameSettings.keyBindRight)) mc.gameSettings.keyBindRight.pressed = false
        if (!GameSettings.isKeyDown(mc.gameSettings.keyBindLeft)) mc.gameSettings.keyBindLeft.pressed = false
        lockRotation = null
        mc.timer.timerSpeed = 1f
        shouldGoDown = false
        if (slot != mc.thePlayer.inventory.currentItem) mc.netHandler.addToSendQueue(C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem))
    }

    /**
     * Entity movement event
     *
     * @param event
     */
    @EventTarget
    fun onMove(event: MoveEvent) {
        if (HypixelSlow.get()) {
            if (MovementUtils.isMoving() && (mc.thePlayer.onGround && Test.get() || !Test.get())) {
                MovementUtils.setMotion(event,  hypixelslowset.get().toDouble())
            }
        }
        if (!safeWalkValue.get() || shouldGoDown) return
        if (airSafeValue.get() || mc.thePlayer.onGround) event.isSafeWalk = true
    }

    /**
     * Scaffold visuals
     *
     * @param event
     */
    @EventTarget
    fun onRender2D(event: Render2DEvent?) {
        if (blocksAmount in 100..999) {
            width = 7
        }
        if (blocksAmount in 10..99) {
            width = 5
        }
        if (blocksAmount in 0..9) {
            width = 3
        }
        val blockSlot = InventoryUtils.findAutoBlockBlock()
        if (blockSlot == -1) return
        val itemStack = mc.thePlayer.inventoryContainer.getSlot(blockSlot).stack
        val res = ScaledResolution(mc)
        GL11.glPushMatrix()
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f)
        if (mc.theWorld != null) {
            GLUtils.enableGUIStandardItemLighting()
        }
        GlStateManager.pushMatrix()
        GlStateManager.disableAlpha()
        GlStateManager.clear(256)
        //this.mc.getRenderItem().zLevel = -150.0f;
        mc.renderItem.renderItemIntoGUI(itemStack, res.scaledWidth / 2 - 20, res.scaledHeight / 2 + 2)
        Fonts.minecraftFont.drawStringWithShadow(
            "$blocksAmount  Blocks",
            (res.scaledWidth / 2).toFloat(),
            (res.scaledHeight / 2 + 7).toFloat(),
            Color.WHITE.rgb
        )
        mc.renderItem.zLevel = 0.0f
        GlStateManager.disableBlend()
        GlStateManager.scale(0.5, 0.5, 0.5)
        GlStateManager.disableDepth()
        GlStateManager.disableLighting()
        GlStateManager.enableDepth()
        GlStateManager.scale(2.0f, 2.0f, 2.0f)
        GlStateManager.enableAlpha()
        GlStateManager.popMatrix()
        GL11.glPopMatrix()
    }
//
//    /**
//     * Scaffold visuals
//     *
//     * @param event
//     */
//    @EventTarget
//    fun onRender3D(event: Render3DEvent?) {
//        if (!markValue.get()) return
//        var i = 0
//        while (i < if (modeValue.get().equals("Expand", ignoreCase = true)) expandLengthValue.get() + 1 else 2) {
//            val blockPos = BlockPos(
//                mc.thePlayer.posX + if (mc.thePlayer.horizontalFacing == EnumFacing.WEST) -i else if (mc.thePlayer.horizontalFacing == EnumFacing.EAST) i else 0,
//                mc.thePlayer.posY - (if (mc.thePlayer.posY == mc.thePlayer.posY.toInt() + 0.5) 0.0 else 1.0) - if (shouldGoDown) 1.0 else 0,
//                mc.thePlayer.posZ + if (mc.thePlayer.horizontalFacing == EnumFacing.NORTH) -i else if (mc.thePlayer.horizontalFacing == EnumFacing.SOUTH) i else 0
//            )
//            val placeInfo = get(blockPos)
//            if (isReplaceable(blockPos) && placeInfo != null) {
//                RenderUtils.drawBlockBox(blockPos, Color(68, 117, 255, 100), false)
//                break
//            }
//            i++
//        }
//    }

    /**
     * Search for placeable block
     *
     * @param blockPosition pos
     * @param checks        visible
     * @return
     */
    private fun search(blockPosition: BlockPos, checks: Boolean): Boolean {
        if (!isReplaceable(blockPosition)) return false
        val eyesPos = Vec3(
            mc.thePlayer.posX,
            mc.thePlayer.entityBoundingBox.minY + mc.thePlayer.getEyeHeight(),
            mc.thePlayer.posZ
        )
        var placeRotation: PlaceRotation? = null
        for (side in EnumFacing.values()) {
            val neighbor = blockPosition.offset(side)
            if (!canBeClicked(neighbor)) continue
            val dirVec = Vec3(side.directionVec)
            var xSearch = 0.1
            while (xSearch < 0.9) {
                var ySearch = 0.1
                while (ySearch < 0.9) {
                    var zSearch = 0.1
                    while (zSearch < 0.9) {
                        val posVec = Vec3(blockPosition).addVector(xSearch, ySearch, zSearch)
                        val distanceSqPosVec = eyesPos.squareDistanceTo(posVec)
                        val hitVec = posVec.add(Vec3(dirVec.xCoord * 0.5, dirVec.yCoord * 0.5, dirVec.zCoord * 0.5))
                        if (checks && (eyesPos.squareDistanceTo(hitVec) > 18.0 || distanceSqPosVec > eyesPos.squareDistanceTo(
                                posVec.add(dirVec)
                            ) || mc.theWorld.rayTraceBlocks(eyesPos, hitVec, false, true, false) != null)
                        ) {
                            zSearch += 0.1
                            continue
                        }

                        // face block
                        val diffX = hitVec.xCoord - eyesPos.xCoord
                        val diffY = hitVec.yCoord - eyesPos.yCoord
                        val diffZ = hitVec.zCoord - eyesPos.zCoord
                        val diffXZ = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ).toDouble()
                        val rotation = Rotation(
                            MathHelper.wrapAngleTo180_float(Math.toDegrees(Math.atan2(diffZ, diffX)).toFloat() - 90f),
                            MathHelper.wrapAngleTo180_float((-Math.toDegrees(Math.atan2(diffY, diffXZ))).toFloat())
                        )
                        val rotationVector = RotationUtils.getVectorForRotation(rotation)
                        val vector = eyesPos.addVector(
                            rotationVector.xCoord * 4,
                            rotationVector.yCoord * 4,
                            rotationVector.zCoord * 4
                        )
                        val obj = mc.theWorld.rayTraceBlocks(eyesPos, vector, false, false, true)
                        if (!(obj.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK && obj.blockPos == neighbor)) {
                            zSearch += 0.1
                            continue
                        }
                        if (placeRotation == null || RotationUtils.getRotationDifference(rotation) < RotationUtils.getRotationDifference(
                                placeRotation.rotation
                            )
                        ) placeRotation = PlaceRotation(PlaceInfo(neighbor, side.opposite, hitVec), rotation)
                        zSearch += 0.1
                    }
                    ySearch += 0.1
                }
                xSearch += 0.1
            }
        }
        if (placeRotation == null) return false
        if ((modeValue.get() == "AAC" || modeValue.get()
                .equals("RedeSky", ignoreCase = true)) && !keepRotationValue.get()
        ) {
            mc.thePlayer.isSprinting = false
            if (mc.gameSettings.keyBindForward.isKeyDown) {
                rotYaw = 180
            }
            if (mc.gameSettings.keyBindLeft.isKeyDown) {
                rotYaw = 90
            }
            if (mc.gameSettings.keyBindRight.isKeyDown) {
                rotYaw = 270
            }
            if (mc.gameSettings.keyBindBack.isKeyDown) {
                rotYaw = 0
            }
            rotation =
                !mc.gameSettings.keyBindForward.isKeyDown && !mc.gameSettings.keyBindLeft.isKeyDown && !mc.gameSettings.keyBindRight.isKeyDown && !mc.gameSettings.keyBindBack.isKeyDown
            val AACRotation = Rotation(
                mc.thePlayer.rotationYaw + rotYaw, aacPitchValue.get()
                    .toFloat()
            )
            if (silentRotationValue.get()) {
                RotationUtils.setTargetRotation(AACRotation)
            } else {
                AACRotation.toPlayer(mc.thePlayer)
            }
        }
        if (modeValue.get() == "Hypixel" && !keepRotationValue.get()) {
            rotation =
                !mc.gameSettings.keyBindForward.isKeyDown && !mc.gameSettings.keyBindLeft.isKeyDown && !mc.gameSettings.keyBindRight.isKeyDown && !mc.gameSettings.keyBindBack.isKeyDown
            val AACRotation = Rotation(
                mc.thePlayer.rotationYaw + Yaw.get(), PitchValue.get()
                    .toFloat()
            )
            if (silentRotationValue.get()) {
                RotationUtils.setTargetRotation(AACRotation)
            } else {
                AACRotation.toPlayer(mc.thePlayer)
            }
        }
        if (rotationsValue.get() && (modeValue.get() != "AAC" && !modeValue.get()
                .equals("Hypixel", ignoreCase = true) || rotation) && modeValue.get() != "RedeSky"
        ) {
            RotationUtils.setTargetRotation(placeRotation.rotation, keepLengthValue.get())
            lockRotation = placeRotation.rotation
        }
        targetPlace = placeRotation.placeInfo
        return true
    }

    /**
     * @return hotbar blocks amount
     */
    private val blocksAmount: Int
        private get() {
            var amount = 0
            for (i in 36..44) {
                val itemStack = mc.thePlayer.inventoryContainer.getSlot(i).stack
                if (itemStack != null && itemStack.item is ItemBlock) {
                    val block = (itemStack.item as ItemBlock).getBlock()
                    if (mc.thePlayer.heldItem == itemStack || !InventoryUtils.BLOCK_BLACKLIST.contains(block)) amount += itemStack.stackSize
                }
            }
            return amount
        }
    override val tag: String
        get() = placeModeValue.get()
}