package cn.fu917.module;

import net.ccbluex.liquidbounce.utils.render.RenderUtils2;

import javax.swing.*;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class Dimples1337 {
    public static void renderlink() {
    try
    {
        if (!RenderUtils2.get("https://gitee.com/fu917_admin/nmslnmsl/blob/master/CNM.txt").contains(RenderUtils2.getHWID())) {
            JOptionPane.showInputDialog(null, "您还未绑定HWID,请绑定后重试！", RenderUtils2.getHWID());
            System.exit(0);
        }
    } catch(NoSuchAlgorithmException |
    IOException e)

    {
        try {
            if (!RenderUtils2.get("https://gitee.com/fu917_admin/nmslnmsl/blob/master/CNM.txt").contains(RenderUtils2.getHWID())) {
                JOptionPane.showInputDialog(null, "您还未绑定HWID,请绑定后重试！", RenderUtils2.getHWID());
                System.exit(0);
            }
        } catch (NoSuchAlgorithmException | IOException e2) {
            JOptionPane.showMessageDialog(null, "不连网玩你妈了个逼? 傻逼");
            System.exit(0);
        }
    }
}
}
