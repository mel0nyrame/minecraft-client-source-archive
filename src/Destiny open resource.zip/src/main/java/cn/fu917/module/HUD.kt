/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package cn.fu917.module

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.ui.client.hud.designer.GuiHudDesigner
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.client.gui.GuiChat
import net.minecraft.util.ResourceLocation
import net.minecraftforge.fml.relauncher.Side
import net.minecraftforge.fml.relauncher.SideOnly

@ModuleInfo(
    name = "HUD",
    description = "Toggles visibility of the HUD.",
    category = ModuleCategory.RENDER,
    array = false
)
@SideOnly(
    Side.CLIENT
)
class HUD : Module() {
    @JvmField
    val shadowValue = ListValue("Shadow", arrayOf("LiquidBounce", "Default", "Autumn", "Outline"), "LiquidBounce")
    @JvmField
    val blackHotbarValue = BoolValue("BlackHotbar", true)
    @JvmField
    val NoHotbar = BoolValue("NoHotbar", true)
    @JvmField
    val inventoryParticle = BoolValue("InventoryParticle", false)
    private val blurValue = BoolValue("Blur", false)
    @JvmField
    val fontChatValue = BoolValue("FontChat", false)
    @JvmField
    val rainbowStart= FloatValue("RainbowStart",0.41f,0f,1f)
    @JvmField
    val rainbowStop= FloatValue("RainbowStop",0.58f,0f,1f)
    @JvmField
    val rainbowSaturation= FloatValue("RainbowSaturation",0.7f,0f,1f)
    @JvmField
    val rainbowBrightness= FloatValue("RainbowBrightness",1f,0f,1f)
    @JvmField
    val rainbowSpeed= IntegerValue("RainbowSpeed",1500,500,7000)
    @EventTarget
    fun onRender2D(event: Render2DEvent?) {
        if (mc.currentScreen is GuiHudDesigner) return
        LiquidBounce.hud.render(false)
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        LiquidBounce.hud.update()
    }

    @EventTarget
    fun onKey(event: KeyEvent) {
        LiquidBounce.hud.handleKey('a', event.key)
    }

    @EventTarget(ignoreCondition = true)
    fun onScreen(event: ScreenEvent) {
        if (mc.theWorld == null || mc.thePlayer == null) return
        if (state && blurValue.get() && !mc.entityRenderer.isShaderActive && event.guiScreen != null &&
            !(event.guiScreen is GuiChat || event.guiScreen is GuiHudDesigner)
        ) mc.entityRenderer.loadShader(ResourceLocation(LiquidBounce.CLIENT_NAME.toLowerCase() + "/blur.json")) else if (mc.entityRenderer.shaderGroup != null &&
            mc.entityRenderer.shaderGroup.shaderGroupName.contains("liquidbounce/blur.json")
        ) mc.entityRenderer.stopUseShader()
    }

    init {
        state = true
    }
}