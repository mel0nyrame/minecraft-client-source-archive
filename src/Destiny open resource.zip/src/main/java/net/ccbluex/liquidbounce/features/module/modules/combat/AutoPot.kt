/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.combat

import cn.fu917.module.Scaffold
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.InventoryUtils
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.utils.timer.TimerUtil
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.client.gui.inventory.GuiInventory
import net.minecraft.init.Items
import net.minecraft.item.ItemPotion
import net.minecraft.item.ItemStack
import net.minecraft.network.play.client.*
import net.minecraft.network.play.client.C03PacketPlayer.C05PacketPlayerLook
import net.minecraft.potion.PotionEffect
import net.minecraft.util.BlockPos
import net.minecraft.util.EnumFacing

@ModuleInfo(name = "AutoPot", description = ":/", category = ModuleCategory.COMBAT)
class AutoPot : Module() {
    private val potion = BoolValue("PotionGet",false)
    private val REGEN = BoolValue("RegenPot", true)
    private val SPEED = BoolValue("SpeedPot", true)
    private val PREDICT = BoolValue("PredictPot", false)
    private val health = IntegerValue("Health", 20, 0, 40)
    private val showHaveTarget = BoolValue("ShouldHaveTarget", true)
    private val soup = BoolValue("SoupGet",false)
    private val healthValue = FloatValue("Health", 15f, 0f, 20f)
    private val delayValue = IntegerValue("Delay", 150, 0, 500)
    private val openInventoryValue = BoolValue("OpenInv", false)
    private val simulateInventoryValue = BoolValue("SimulateInventory", true)
    private val bowlValue = ListValue("Bowl", arrayOf("Drop", "Move", "Stay"), "Drop")

    private val delay = MSTimer()
    private val timer = TimerUtil()
    private val scaffold = LiquidBounce.moduleManager.getModule(Scaffold::class.java) as Scaffold
    @EventTarget
    fun onUpdate(e: UpdateEvent) {
        if(!scaffold.state) {
            if (potion.get()) {
                if (openInventoryValue.get() && mc.currentScreen !is GuiInventory)
                    return
                if (!mc.thePlayer.onGround) return
                val speed = SPEED.get()
                val regen = REGEN.get()
                if (timer.delay(200f)) {
                    if (potting) potting = false
                }
                val spoofSlot = bestSpoofSlot
                val pots = intArrayOf(6, -1, -1)
                if (regen) pots[1] = 10
                if (speed) pots[2] = 1
                for (pot in pots) {
                    if (pot == -1) continue
                    if (pot == 6 || pot == 10) {
                        if (timer.delay(900f) && !mc.thePlayer.isPotionActive(pot)) {
                            if (mc.thePlayer.health < health.get() * 2) {
                                getBestPot(spoofSlot, pot)
                            }
                        }
                    } else if (timer.delay(1000f) && !mc.thePlayer.isPotionActive(pot)) {
                        getBestPot(spoofSlot, pot)
                    }
                }
            }
        }
        if (soup.get()){
            if (!delay.hasTimePassed(delayValue.get().toLong()))
                return

            val soupInHotbar = InventoryUtils.findItem(36, 45, Items.mushroom_stew)
            if (mc.thePlayer.health <= healthValue.get() && soupInHotbar != -1) {
                mc.netHandler.addToSendQueue(C09PacketHeldItemChange(soupInHotbar - 36))
                mc.netHandler.addToSendQueue(C08PacketPlayerBlockPlacement(mc.thePlayer.inventoryContainer
                    .getSlot(soupInHotbar).stack))
                if (bowlValue.get().equals("Drop", true))
                    mc.netHandler.addToSendQueue(
                        C07PacketPlayerDigging(
                            C07PacketPlayerDigging.Action.DROP_ITEM,
                            BlockPos.ORIGIN, EnumFacing.DOWN)
                    )
                mc.netHandler.addToSendQueue(C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem))
                timer.reset()
                return
            }

            val bowlInHotbar = InventoryUtils.findItem(36, 45, Items.bowl)
            if (bowlValue.get().equals("Move", true) && bowlInHotbar != -1) {
                if (openInventoryValue.get() && mc.currentScreen !is GuiInventory)
                    return

                var bowlMovable = false

                for (i in 9..36) {
                    val itemStack = mc.thePlayer.inventoryContainer.getSlot(i).stack

                    if (itemStack == null) {
                        bowlMovable = true
                        break
                    } else if (itemStack.item == Items.bowl && itemStack.stackSize < 64) {
                        bowlMovable = true
                        break
                    }
                }

                if (bowlMovable) {
                    val openInventory = mc.currentScreen !is GuiInventory && simulateInventoryValue.get()

                    if (openInventory)
                        mc.netHandler.addToSendQueue(C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT))
                    mc.playerController.windowClick(0, bowlInHotbar, 0, 1, mc.thePlayer)
                }
            }

            val soupInInventory = InventoryUtils.findItem(9, 36, Items.mushroom_stew)
            if (soupInInventory != -1 && InventoryUtils.hasSpaceHotbar()) {
                if (openInventoryValue.get() && mc.currentScreen !is GuiInventory)
                    return

                val openInventory = mc.currentScreen !is GuiInventory && simulateInventoryValue.get()
                if (openInventory)
                    mc.netHandler.addToSendQueue(C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT))

                mc.playerController.windowClick(0, soupInInventory, 0, 1, mc.thePlayer)

                if (openInventory)
                    mc.netHandler.addToSendQueue(C0DPacketCloseWindow())

                timer.reset()
            }
        }
    }

    @EventTarget
    fun swap(slot1: Int, hotbarSlot: Int) {
        if (potion.get()) {
            if (openInventoryValue.get() && mc.currentScreen !is GuiInventory)
                return
            mc.playerController.windowClick(
                mc.thePlayer.inventoryContainer.windowId,
                slot1,
                hotbarSlot,
                2,
                mc.thePlayer
            )
        }
    }

    private val rotations: FloatArray
        get() {
            val movedPosX = mc.thePlayer.posX + mc.thePlayer.motionX * 26.0
            val movedPosY = mc.thePlayer.entityBoundingBox.minY - 3.6
            val movedPosZ = mc.thePlayer.posZ + mc.thePlayer.motionZ * 26.0
            return if (PREDICT.get() && MovementUtils.isMoving()) RotationUtils.getRotationFromPotion(
                movedPosX,
                movedPosY,
                movedPosZ
            ) else floatArrayOf(mc.thePlayer.rotationYaw, 70f)
        }
    val bestSpoofSlot: Int
        get() {
            var spoofSlot = 5
            for (i in 36..44) {
                if (!mc.thePlayer.inventoryContainer.getSlot(i).hasStack) {
                    spoofSlot = i - 36
                    break
                } else if (mc.thePlayer.inventoryContainer.getSlot(i).stack.item is ItemPotion) {
                    spoofSlot = i - 36
                    break
                }
            }
            return spoofSlot
        }

    private fun getBestPot(hotbarSlot: Int, potID: Int) {
        val aura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura?
        if (showHaveTarget.get()) {
            assert(aura != null)
            if (aura!!.target == null) {
                return
            }
        }
        for (i in 9..44) {
            if (mc.thePlayer.inventoryContainer.getSlot(i).hasStack && (mc.currentScreen == null || mc.currentScreen is GuiInventory)) {
                val `is` = mc.thePlayer.inventoryContainer.getSlot(i).stack
                if (`is`.item is ItemPotion) {
                    val pot = `is`.item as ItemPotion
                    if (pot.getEffects(`is`).isEmpty()) return
                    val effect = pot.getEffects(`is`)[0]
                    val potionID = effect.potionID
                    if (potionID == potID) if (ItemPotion.isSplash(`is`.itemDamage) && isBestPot(pot, `is`)) {
                        if (36 + hotbarSlot != i)
                            swap(i, hotbarSlot)
                        timer.reset()
                        val oldSlot = mc.thePlayer.inventory.currentItem
                        mc.thePlayer.sendQueue.addToSendQueue(C09PacketHeldItemChange(hotbarSlot))
                        if (!PREDICT.get()) {
                            mc.gameSettings.keyBindForward.pressed = true
                        }
                        mc.thePlayer.sendQueue.addToSendQueue(
                            C05PacketPlayerLook(
                                rotations[0],
                                rotations[1],
                                mc.thePlayer.onGround
                            )
                        )
                        if (!PREDICT.get()) {
                            mc.gameSettings.keyBindForward.pressed = false
                        }
                        mc.thePlayer.sendQueue.addToSendQueue(C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()))
                        mc.thePlayer.sendQueue.addToSendQueue(C09PacketHeldItemChange(oldSlot))
                        potting = true
                        break
                    }
                }
            }
        }
    }

    fun isBestPot(potion: ItemPotion, stack: ItemStack?): Boolean {
        if (potion.getEffects(stack) == null || potion.getEffects(stack).size != 1) return false
        val effect = potion.getEffects(stack)[0]
        val potionID = effect.potionID
        val amplifier = effect.amplifier
        val duration = effect.duration
        for (i in 9..44) {
            if (mc.thePlayer.inventoryContainer.getSlot(i).hasStack) {
                val `is` = mc.thePlayer.inventoryContainer.getSlot(i).stack
                if (`is`.item is ItemPotion) {
                    val pot = `is`.item as ItemPotion
                    if (pot.getEffects(`is`) != null) {
                        for (o in pot.getEffects(`is`)) {
                            val effects = o as PotionEffect
                            val id = effects.potionID
                            val ampl = effects.amplifier
                            val dur = effects.duration
                            if (id == potionID && ItemPotion.isSplash(`is`.itemDamage)) {
                                if (ampl > amplifier) {
                                    return false
                                } else if (ampl == amplifier && dur > duration) {
                                    return false
                                }
                            }
                        }
                    }
                }
            }
        }
        return true
    }

    companion object {
        var potting = false
    }
}