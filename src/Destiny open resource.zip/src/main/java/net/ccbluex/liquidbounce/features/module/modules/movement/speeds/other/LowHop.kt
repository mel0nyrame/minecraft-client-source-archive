/*
 * LiquidBounce+ Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/WYSI-Foundation/LiquidBouncePlus/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.verus

import net.ccbluex.liquidbounce.event.EventPreUpdate
import net.ccbluex.liquidbounce.event.JumpEvent
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils

class LowHop : SpeedMode("LowHop") {
    override fun onJump(event: JumpEvent){}
    override fun onMotion() {}
    override fun onUpdate() {}
    override fun onPreUpdate(event: EventPreUpdate) {
//        val speed = LiquidBounce.moduleManager[Speed::class.java] as Speed
//        if (MovementUtils.isMoving() &&speed.groundspoof.get() &&mc.thePlayer.isCollidedVertically && mc.thePlayer.onGround && mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer as Entity, mc.thePlayer.entityBoundingBox.offset(0.0, 0.5, 0.0)).isEmpty()) {
//            event.y = event.y + ThreadLocalRandom.current().nextFloat().toDouble() / 1000.0
//            event.isOnground = true
//        }
    }
    override fun onMove(event: MoveEvent) {
        if (!mc.thePlayer.isInWeb && !mc.thePlayer.isInLava && !mc.thePlayer.isInWater && !mc.thePlayer.isOnLadder && mc.thePlayer.ridingEntity == null) {
            if (MovementUtils.isMoving()) {
                mc.gameSettings.keyBindJump.pressed = false
                if (mc.thePlayer.onGround) {
                    mc.thePlayer.jump()
                    mc.thePlayer.motionY = 0.0
                    MovementUtils.strafe(0.61f + MovementUtils.getSpeedEffect() * 0.1f)
                    event.y = 0.41999998688698
                }
                MovementUtils.strafe()
            }
        }
    }
}