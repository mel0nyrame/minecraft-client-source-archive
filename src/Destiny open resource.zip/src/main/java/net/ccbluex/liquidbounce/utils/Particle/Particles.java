package net.ccbluex.liquidbounce.utils.Particle;


import net.ccbluex.liquidbounce.utils.Player.RotationHelper;

public class Particles {
    public int ticks;

    public RotationHelper rotationhelper;

    public String text;

    public Particles(RotationHelper rotationhelper, String text) {
        this.rotationhelper = rotationhelper;
        this.text = text;
        this.ticks = 0;
    }
}
//rotationhelper