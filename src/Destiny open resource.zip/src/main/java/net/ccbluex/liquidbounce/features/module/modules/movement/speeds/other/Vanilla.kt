package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import cn.fu917.module.Scaffold
import io.netty.util.internal.ThreadLocalRandom
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.minecraft.util.MathHelper
import net.minecraft.util.BlockPos
import net.minecraft.block.BlockAir
import net.minecraft.block.BlockLiquid
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.minecraft.entity.Entity
import net.minecraft.potion.Potion

class Vanilla : SpeedMode("Vanilla") {
    var shouldslow = false
    private val timer = MSTimer()
    var collided: Boolean
    var lessSlow: Boolean
    var lastCheck = MSTimer()
    var less: Double
    var stair = 0.0
    private var motY = 0.0
    private fun defaultSpeed(): Double {
        var baseSpeed = 0.2873
        if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
            val amplifier = mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).amplifier
            baseSpeed *= 1.0 + 0.2 * (amplifier + 1).toDouble()
        }
        return baseSpeed
    }

    private val isInLiquid: Boolean
        get() {
            if (mc.thePlayer == null) {
                return false
            }
            var x2 = MathHelper.floor_double(mc.thePlayer.entityBoundingBox.minX)
            while (x2 < MathHelper.floor_double(mc.thePlayer.entityBoundingBox.maxX) + 1) {
                var z2 = MathHelper.floor_double(mc.thePlayer.entityBoundingBox.minZ)
                while (z2 < MathHelper.floor_double(mc.thePlayer.entityBoundingBox.maxZ) + 1) {
                    val pos = BlockPos(x2, mc.thePlayer.entityBoundingBox.minY.toInt(), z2)
                    val block = mc.theWorld.getBlockState(pos).block
                    if (block != null && block !is BlockAir) {
                        return block is BlockLiquid
                    }
                    ++z2
                }
                ++x2
            }
            return false
        }
    var isstep = false
    @EventTarget
    fun onStep(e: StepEvent?) {
        isstep = false
    }
    override fun onJump(event: JumpEvent){}
    override fun onMotion() {}
    override fun onUpdate() {}
    override fun onPreUpdate(event: EventPreUpdate) {
        val speed = LiquidBounce.moduleManager[Speed::class.java] as Speed
        if (MovementUtils.isMoving() &&speed.groundspoof.get() &&mc.thePlayer.isCollidedVertically && mc.thePlayer.onGround && mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer as Entity, mc.thePlayer.entityBoundingBox.offset(0.0, 0.5, 0.0)).isEmpty()) {
            event.y = event.y + ThreadLocalRandom.current().nextFloat().toDouble() / 1000.0
            event.isOnground = true
        }
    }
    override fun onMove(e2: MoveEvent) {
        if (LiquidBounce.moduleManager[Scaffold::class.java]!!.state)
            return
        val speed = LiquidBounce.moduleManager[Speed::class.java] as Speed
        val setY = 0.4040404
            mc.timer.timerSpeed = 1.03f
        if (isstep) {
            isstep = false
            return
        }
        if (mc.thePlayer.isCollidedHorizontally) {
            collided = true
        }
        if (collided) {
            mc.timer.timerSpeed = 1.0f
            stage = -1
        }
        if (stair > 0.0) {
            stair -= 0.25
        }
        less -= if (less > 1.0) 0.12 else 0.11
        if (less < 0.0) {
            less = 0.0
        }
        if (!isInLiquid && MovementUtils.isOnGround(0.01) && MovementUtils.isMoving()) {
            collided = mc.thePlayer.isCollidedHorizontally
            if (stage >= 0 || collided) {
                stage = 0
                    motY = setY + MovementUtils.getJumpEffect().toDouble() * 0.1
                //0.399994
                //0.40866666
//                double motY = 0.399994 + (double) MovementUtils.getJumpEffect() * 0.1;
                if (stair == 0.0) {
                    mc.thePlayer.motionY = motY
                    e2.y = mc.thePlayer.motionY
                }
                less += 1.0
                lessSlow = less > 1.0 && !lessSlow
                if (less > 1.12) {
                    less = 1.12
                }
            }
        }
        var movementSpeed = getHypixelSpeed(stage)
        movementSpeed *= speed.vanillaspeed.get().toDouble()
        if (stair > 0.0) {
            movementSpeed *= 0.73 - MovementUtils.getSpeedEffect().toDouble() * 0.1
        }
        if (stage < 0) {
            movementSpeed = defaultSpeed()
        }
        if (lessSlow) {
            movementSpeed *= 1.0
        }
        if (lessSlow) {
            movementSpeed *= 1.0
        }
        if (isInLiquid) {
            movementSpeed = 0.11
        }
        if (mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f) {
            setMotion(e2, movementSpeed)
            ++stage
        }
    }

    private fun setMotion(em2: MoveEvent, speed: Double) {
        var forward = mc.thePlayer.movementInput.moveForward.toDouble()
        var strafe = mc.thePlayer.movementInput.moveStrafe.toDouble()
        var yaw = mc.thePlayer.rotationYaw
        if (forward == 0.0 && strafe == 0.0) {
            em2.x = 0.0
            em2.z = 0.0
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (if (forward > 0.0) -45 else 45).toFloat()
                } else if (strafe < 0.0) {
                    yaw += (if (forward > 0.0) 45 else -45).toFloat()
                }
                strafe = 0.0
                if (forward > 0.0) {
                    forward = 1.0
                } else if (forward < 0.0) {
                    forward = -1.0
                }
            }
            val sin = Math.sin(Math.toRadians((yaw + 90.0f).toDouble()))
            val cos = Math.cos(Math.toRadians((yaw + 90.0f).toDouble()))
            em2.x = forward * speed * cos + strafe * speed * sin
            em2.z = forward * speed * sin - strafe * speed * cos
        }
    }

    private fun getHypixelSpeed(stage: Int): Double {
        var value = defaultSpeed() + 0.028 * MovementUtils.getSpeedEffect()
            .toDouble() + MovementUtils.getSpeedEffect().toDouble() / 15.0
        val firstvalue = 0.4145 + MovementUtils.getSpeedEffect().toDouble() / 12.5
        val decr = stage.toDouble() / 500.0 * 2.0
        if (stage == 0) {
            if (timer.delay(500.0)) {
                timer.reset()
            }
            if (!lastCheck.delay(500.0)) {
                if (!shouldslow) {
                    shouldslow = true
                }
            } else if (shouldslow) {
                shouldslow = false
            }
            value = 0.64 + (MovementUtils.getSpeedEffect().toDouble() + 0.028 * MovementUtils.getSpeedEffect()
                .toDouble()) * 0.134
        } else if (stage == 1) {
            value = firstvalue
        } else if (stage >= 2) {
            value = firstvalue - decr
        }
        if (shouldslow || !lastCheck.delay(500.0) || collided) {
            value = 0.2
            if (stage == 0) {
                value = 0.0
            }
        }
        return Math.max(
            value, if (shouldslow) value else defaultSpeed() + 0.028 * MovementUtils.getSpeedEffect()
                .toDouble()
        )
    }

    companion object {
        var stage: Int = 0
    }

    init {
        val player = mc.thePlayer == null
        collided = !player && mc.thePlayer.isCollidedHorizontally
        lessSlow = false
        less = 0.0
        stage = 2
        mc.timer.timerSpeed = 1.0f
    }
}