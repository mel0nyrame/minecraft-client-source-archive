/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import io.netty.util.internal.ThreadLocalRandom
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.JumpEvent
import net.ccbluex.liquidbounce.event.EventPreUpdate
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils.*
import net.minecraft.entity.Entity

class SlowHop : SpeedMode("SlowHop") {
    override fun onJump(event: JumpEvent) {}
    override fun onMotion() {
    }

    override fun onPreUpdate(event: EventPreUpdate) {
        val speed = LiquidBounce.moduleManager[Speed::class.java] as Speed
        if (isMoving() &&speed.groundspoof.get() &&mc.thePlayer.isCollidedVertically && mc.thePlayer.onGround && mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer as Entity, mc.thePlayer.entityBoundingBox.offset(0.0, 0.5, 0.0)).isEmpty()) {
            event.y = event.y + ThreadLocalRandom.current().nextFloat().toDouble() / 1000.0
            event.isOnground = true
        }
    }
    override fun onUpdate() {}
    override fun onMove(event: MoveEvent) {
        if (mc.thePlayer.isInWater) return
        if (isMoving()) {
            if (mc.thePlayer.onGround) {
                setMotion(event,0.475 + 0.1 * getSpeedEffect())
                mc.thePlayer.motionY = getJumpBoostModifier(0.4040404)
                event.y=mc.thePlayer.motionY
            }
            else
                strafe()
        } else {
            mc.thePlayer.motionX *= 1.0
            mc.thePlayer.motionZ *= 1.0
        }

    }
}