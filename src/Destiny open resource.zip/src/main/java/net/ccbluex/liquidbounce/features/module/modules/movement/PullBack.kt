package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.PacketUtils
import net.ccbluex.liquidbounce.utils.PacketUtils.sendPacketNoEvent
import net.ccbluex.liquidbounce.utils.Utils.Timer.TimeHelper
import net.ccbluex.liquidbounce.utils.Utils.Timer.TimerUtil
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.network.play.client.C03PacketPlayer
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition
import net.minecraft.network.play.server.S08PacketPlayerPosLook
import java.util.ArrayList

@ModuleInfo(name = "PullBack", description = "PullBack", category = ModuleCategory.PLAYER)
class PullBack : Module() {
    var lastGroundPos = DoubleArray(3)
    private val pullTimer = TimerUtil()
    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (!packets.isEmpty() && mc.thePlayer.ticksExisted < 100) packets.clear()
        if (event.packet is C03PacketPlayer) {
            if (isInVoid) {
                event.cancelEvent()
                packets.add(event.packet)
                if (timer.isDelayComplete(pullbackTime.get().toDouble())) {
                    //ChatUtils.debug("Send Packets");
                    sendPacketNoEvent(
                        C04PacketPlayerPosition(
                            lastGroundPos[0], lastGroundPos[1] - 1,
                            lastGroundPos[2], true
                        )
                    )
                }
            } else {
                lastGroundPos[0] = mc.thePlayer.posX
                lastGroundPos[1] = mc.thePlayer.posY
                lastGroundPos[2] = mc.thePlayer.posZ
                if (!packets.isEmpty()) {
                    //ChatUtils.debug("Release Packets - " + packets.size());
                    for (p in packets) sendPacketNoEvent(p)
                    packets.clear()
                }
                timer.reset()
            }
        }
    }

    @EventTarget
    fun onRevPacket(e: PacketEvent) {
        if (e.packet is S08PacketPlayerPosLook && packets.size > 1) {
            packets.clear()
        }
    }

    companion object {
        var pullbackTime = FloatValue("PullbackTime", 1500f, 1000f, 2000f)
        var timer = TimeHelper()
        var packets = ArrayList<C03PacketPlayer>()
        val isInVoid: Boolean
            get() {
                for (i in 0..128) {
                    if (MovementUtils.isOnGround(i.toDouble())) {
                        return false
                    }
                }
                return true
            }
        val antifall = LiquidBounce.moduleManager.getModule(PullBack::class.java) as PullBack?
        val isPullbacking: Boolean
            get() = antifall!!.state && !packets.isEmpty()
    }
}