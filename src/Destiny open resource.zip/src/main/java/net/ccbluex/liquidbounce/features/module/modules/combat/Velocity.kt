
package net.ccbluex.liquidbounce.features.module.modules.combat

import io.netty.util.internal.ThreadLocalRandom
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.JumpEvent
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.Fly
import net.ccbluex.liquidbounce.features.module.modules.movement.LongJump
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed
import net.ccbluex.liquidbounce.utils.ClientUtils
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.utils.timer.MSTimer
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.server.S12PacketEntityVelocity
import net.minecraft.network.play.server.S27PacketExplosion
import net.minecraft.util.MathHelper
import kotlin.math.cos
import kotlin.math.sin
import net.minecraft.entity.projectile.EntityArrow




@ModuleInfo(name = "Velocity", description = "Allows you to modify the amount of knockback you take.", category = ModuleCategory.COMBAT)
class Velocity : Module() {

    /**
     * OPTIONS
     */
    private val horizontalValue = FloatValue("Horizontal", 0F, 0F, 1F)
    private val verticalValue = FloatValue("Vertical", 0F, 0F, 1F)
    private val aac4MotionXValue = FloatValue("AAC4MotionX", 0.6F, 0F, 1F)
    private val aac4MotionZValue = FloatValue("AAC4MotionZ", 0.6F, 0F, 1F)
    private val modeValue = ListValue("Mode", arrayOf("Simple", "OldAAC", "AAC5", "Reverse", "SmoothReverse", "AAC","Vanilla"), "Simple")
    // Reverse
    private val reverseStrengthValue = FloatValue("ReverseStrength", 1F, 0.1F, 1F)
    private val reverse2StrengthValue = FloatValue("SmoothReverseStrength", 0.05F, 0.02F, 0.1F)

    // AAC Push
    private val aacPushXZReducerValue = FloatValue("AACPushXZReducer", 2F, 1F, 3F)
    private val aacPushYReducerValue = BoolValue("AACPushYReducer", true)
    private val killaura = BoolValue("OnlyKillaura",false)
    private val ismoving = BoolValue("OnlyMove",false)
    //AAC
    private val AACY = BoolValue("AACLowY",false)
    private val MoveOnly = BoolValue("AACMove",false)
    private val GroundOnly = BoolValue("GroundOnly",false)


    /**
     * VALUES
     */
    private var velocityTimer = MSTimer()
    private var velocityInput = false

    // SmoothReverse
    private var reverseHurt = false

    // AACPush
    private var jump = false

    private var timer = MSTimer()

    override val tag: String
        get() =
            if(modeValue.get() == "Simple" && horizontalValue.get() == 0F && verticalValue.get() == 0F) {
                "Cancel"
            } else {
                modeValue.get()
            }

    override fun onDisable() {
        mc.thePlayer?.speedInAir = 0.02F
    }

    private fun canSetGameSettings(): Boolean {
        val yaw = MovementUtils.getDirection()
        val x = -sin(yaw) * 0.4
        val z = cos(yaw) * 0.4

        return mc.theWorld.getCollisionBoxes(mc.thePlayer.entityBoundingBox.offset(x, 1.001335979112147, z))
            .isEmpty()
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (isArrowNearby()){
            timer.reset()
        }
        if (!ismoving.get() || (ismoving.get() && MovementUtils.isMoving()))
        if (mc.thePlayer.isInWater || mc.thePlayer.isInLava || mc.thePlayer.isInWeb)
            return
        when (modeValue.get().toLowerCase()) {
            "jump" -> if (mc.thePlayer.hurtTime > 0 && mc.thePlayer.onGround) {
                mc.thePlayer.motionY = 0.42

                val yaw = mc.thePlayer.rotationYaw * 0.017453292F
                mc.thePlayer.motionX -= MathHelper.sin(yaw) * 0.2
                mc.thePlayer.motionZ += MathHelper.cos(yaw) * 0.2
            }

            "glitch" -> {
                mc.thePlayer.noClip = velocityInput
                if (mc.thePlayer.hurtTime == 7)
                    mc.thePlayer.motionY = 0.4

                velocityInput = false
            }

            "reverse" -> {
                if (!velocityInput)
                    return

                if (!mc.thePlayer.onGround) {
                    MovementUtils.strafe(MovementUtils.getSpeed() * reverseStrengthValue.get())
                } else if (velocityTimer.hasTimePassed(80L))
                    velocityInput = false
            }

            "smoothreverse" -> {
                if (!velocityInput) {
                    mc.thePlayer.speedInAir = 0.02F
                    return
                }

                if (mc.thePlayer.hurtTime > 0)
                    reverseHurt = true

                if (!mc.thePlayer.onGround) {
                    if (reverseHurt)
                        mc.thePlayer.speedInAir = reverse2StrengthValue.get()
                } else if (velocityTimer.hasTimePassed(80L)) {
                    velocityInput = false
                    reverseHurt = false
                }
            }

            "oldaac" -> if (velocityInput && velocityTimer.hasTimePassed(80L)) {
                mc.thePlayer.motionX *= horizontalValue.get()
                mc.thePlayer.motionZ *= horizontalValue.get()
                //mc.thePlayer.motionY *= verticalValue.get() ?
                velocityInput = false
                velocityTimer.reset()
            }

            "aac" -> {
                if (!LiquidBounce.moduleManager[Fly::class.java]!!.state || !LiquidBounce.moduleManager[LongJump::class.java]!!.state) {
                    if (mc.thePlayer.hurtTime != 0) {
                        if (!mc.thePlayer.isBurning) {
                            mc.timer.timerSpeed = 1f
                            mc.thePlayer.speedInAir = 0.02f
                            if ((GroundOnly.get() && mc.thePlayer.onGround) || !GroundOnly.get()) {
                                if (!mc.thePlayer.onGround) {
                                    if ((MovementUtils.isMoving() && MoveOnly.get()) || (!MoveOnly.get())) {
                                        mc.thePlayer.motionX = (mc.thePlayer.motionX * aac4MotionXValue.get())
                                        mc.thePlayer.motionZ = (mc.thePlayer.motionZ * aac4MotionZValue.get())
                                    }
                                } else {
                                    if (velocityTimer.hasTimePassed(80L) && AACY.get()) {
                                        if (mc.thePlayer.ticksExisted % 3 == 0) {
                                            mc.thePlayer.motionY =
                                                (mc.thePlayer.motionY - 0.0169 * mc.thePlayer.fallDistance)
                                        }
                                        velocityTimer.reset()
                                    }
                                    if ((MovementUtils.isMoving() && MoveOnly.get()) || (!MoveOnly.get())) {
                                        mc.thePlayer.motionX = (mc.thePlayer.motionX * aac4MotionXValue.get())
                                        mc.thePlayer.motionZ = (mc.thePlayer.motionZ * aac4MotionZValue.get())
                                    }
                                }
                            }
                        }
                    }
                }
            }
            "aac5" -> {
                if (jump) {
                    if (mc.thePlayer.onGround)
                        jump = false
                } else {
                    // Strafe
                    if (mc.thePlayer.hurtTime > 0 && mc.thePlayer.motionX != 0.0 && mc.thePlayer.motionZ != 0.0)
                        mc.thePlayer.onGround = true

                    // Reduce Y
                    if (mc.thePlayer.hurtResistantTime > 0 && aacPushYReducerValue.get()
                        && !LiquidBounce.moduleManager[Speed::class.java]!!.state)
                        mc.thePlayer.motionY -= 0.014999993
                }

                // Reduce XZ
                if (mc.thePlayer.hurtResistantTime >= 19) {
                    val reduce = aacPushXZReducerValue.get()

                    mc.thePlayer.motionX /= reduce
                    mc.thePlayer.motionZ /= reduce
                }
            }

            "aaczero" -> if (mc.thePlayer.hurtTime > 0) {
                if (!velocityInput || mc.thePlayer.onGround || mc.thePlayer.fallDistance > 2F)
                    return

                mc.thePlayer.addVelocity(0.0, -1.0, 0.0)
                mc.thePlayer.onGround = true
            } else
                velocityInput = false
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        val packet = event.packet

        if (packet is S12PacketEntityVelocity) {
            if (mc.thePlayer == null || (mc.theWorld?.getEntityByID(packet.entityID) ?: return) != mc.thePlayer)
                return

            velocityTimer.reset()

            when (modeValue.get().toLowerCase()) {
                "simple" -> {
                    val killAura = LiquidBounce.moduleManager[KillAura::class.java]!! as KillAura
                    val horizontal = horizontalValue.get()
                    val vertical = verticalValue.get()
                        if (horizontal == 0F && vertical == 0F && (!killaura.get() || (killaura.get() && killAura.state)))
                            event.cancelEvent()
//                        if (alerts.get()) {
//                            DebugUtil.log(
//                                "Velocity",
//                                ThreadLocalRandom.current().nextInt(1000, 10000).toString()
//                            )
//                        }
                        packet.motionX = (packet.getMotionX() * horizontal).toInt()
                        packet.motionY = (packet.getMotionY() * vertical).toInt()
                        packet.motionZ = (packet.getMotionZ() * horizontal).toInt()
                    ClientUtils.displayChatMessage("§dVelocity §f>> " + ThreadLocalRandom.current().nextInt(1000, 10000).toString())

                }
                "vanilla"->{
                    ClientUtils.displayChatMessage("§dVelocity §f>> " + ThreadLocalRandom.current().nextInt(1000, 10000).toString())
                        if (!timer.hasTimePassed(1500L) || mc.thePlayer.isBlocking ||(LiquidBounce.moduleManager[KillAura::class.java] as KillAura).target !=null) {
                            event.cancelEvent()
                        }

//                        if(mc.thePlayer.hurtTime >0 || (LiquidBounce.moduleManager[KillAura::class.java] as KillAura).target !=null || isArrowNearby()) {
//                            event.cancelEvent()
//                            chat("§dtick: " + ThreadLocalRandom.current().nextInt(1000, 10000).toString())
//                        }
                }
                "aac4" -> {
                    packet.motionX = packet.getMotionX() * 0.6.toInt()
                    packet.motionY = packet.getMotionY() * 1
                    packet.motionZ = packet.getMotionZ() * 0.6.toInt()
                }

                "aac", "reverse", "smoothreverse", "aaczero" -> velocityInput = true

                "glitch" -> {
                    if (!mc.thePlayer.onGround)
                        return

                    velocityInput = true
                    event.cancelEvent()
                }

            }
        }
        if (packet is S27PacketExplosion) {
            event.cancelEvent()
        }
    }


    private fun isArrowNearby(): Boolean {
        for (entity in mc.theWorld.getLoadedEntityList()) {
            if (entity is EntityArrow) {
                if (entity.shootingEntity !== mc.thePlayer) {
                    return entity.getDistanceToEntity(mc.thePlayer) < 12
                }
            }
        }
        return false
    }

    @EventTarget
    fun onJump(event: JumpEvent) {
        if (mc.thePlayer == null || mc.thePlayer.isInWater || mc.thePlayer.isInLava || mc.thePlayer.isInWeb)
            return

        when (modeValue.get().toLowerCase()) {
            "aac5" -> {
                jump = true

                if (!mc.thePlayer.isCollidedVertically)
                    event.cancelEvent()
            }
            "aaczero" -> if (mc.thePlayer.hurtTime > 0)
                event.cancelEvent()
        }
    }
}
