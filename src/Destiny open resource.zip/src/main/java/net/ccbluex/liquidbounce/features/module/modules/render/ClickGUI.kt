/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.PacketEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.ui.client.clickgui.ClickGui
import net.ccbluex.liquidbounce.ui.client.clickgui.style.styles.LiquidBounceStyle
import net.ccbluex.liquidbounce.ui.client.clickgui.style.styles.NullStyle
import net.ccbluex.liquidbounce.ui.client.clickgui.style.styles.SlowlyStyle
import net.ccbluex.liquidbounce.utils.render.ColorUtils.rainbow
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.network.play.server.S2EPacketCloseWindow
import org.lwjgl.input.Keyboard
import java.awt.Color

@ModuleInfo(
    name = "ClickGUI",
    description = "Opens the ClickGUI.",
    category = ModuleCategory.RENDER,
    keyBind = Keyboard.KEY_RSHIFT,
    canEnable = false
)
class ClickGUI : Module() {
    private val styleValue: ListValue =
        object : ListValue("Style", arrayOf("LiquidBounce", "Null", "Slowly"), "Slowly") {
            override fun onChanged(oldValue: String, newValue: String) {
                updateStyle()
            }
        }
    @JvmField
    val scaleValue = FloatValue("Scale", 1f, 0.7f, 2f)
    @JvmField
    val maxElementsValue = IntegerValue("MaxElements", 15, 1, 20)
    override fun onEnable() {
        updateStyle()
        mc.displayGuiScreen(LiquidBounce.clickGui)
    }

    private fun updateStyle() {
        when (styleValue.get().toLowerCase()) {
            "liquidbounce" -> LiquidBounce.clickGui.style = LiquidBounceStyle()
            "null" -> LiquidBounce.clickGui.style = NullStyle()
            "slowly" -> LiquidBounce.clickGui.style = SlowlyStyle()
        }
    }

    @EventTarget(ignoreCondition = true)
    fun onPacket(event: PacketEvent) {
        val packet = event.packet
        if (packet is S2EPacketCloseWindow && mc.currentScreen is ClickGui) {
            event.cancelEvent()
        }
    }

    companion object {
        val colorRedValue = IntegerValue("R", 0, 0, 255)
        val colorGreenValue = IntegerValue("G", 160, 0, 255)
        val colorBlueValue = IntegerValue("B", 255, 0, 255)
        val colorRainbow = BoolValue("Rainbow", false)
        @JvmStatic
        fun generateColor(): Color {
            return if (colorRainbow.get()) rainbow() else Color(
                colorRedValue.get(),
                colorGreenValue.get(),
                colorBlueValue.get()
            )
        }
    }
}