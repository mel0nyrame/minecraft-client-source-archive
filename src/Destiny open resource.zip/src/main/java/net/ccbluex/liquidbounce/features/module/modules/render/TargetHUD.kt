package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render2DEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.utils.render.AnimationUtil
import net.ccbluex.liquidbounce.utils.render.Colors
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.utils.render.UiUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.client.entity.AbstractClientPlayer
import net.minecraft.client.gui.ScaledResolution
import net.minecraft.client.network.NetworkPlayerInfo
import net.minecraft.client.renderer.GlStateManager
import net.minecraft.client.renderer.RenderHelper
import net.minecraft.entity.EntityLivingBase
import net.minecraft.entity.player.EntityPlayer
import net.minecraft.item.ItemArmor
import net.minecraft.item.ItemStack
import net.minecraft.item.ItemTool
import java.awt.Color
import java.text.DecimalFormat
import java.util.*

@ModuleInfo(name = "TargetInfo", description = "Show the target.", category = ModuleCategory.RENDER)
class TargetHUD : Module() {
    private val modeValue =
        ListValue("Mode", arrayOf("Astolfo", "AquaBounce"), "AquaBounce")
    private val ColorBreathing = BoolValue("ColorBreathing", true)
    private val ComplementaryColor = ListValue("ComplementaryColor", arrayOf("Red", "Green", "Blue", "Aftery", "Purple", "White"), "Green")
    var animAlpha = 0
    var anim = 75.0f
    var format: DecimalFormat? = null
    var astolfoHelathAnim = 0f
    var startAnim = false
    var stopAnim = false
    var lastEnt: EntityLivingBase? = null
    var onGround: String? = null
    var color = 0
    private var TargetDistance = 0
    private var Distance = ""
    var targetHurtTime = 0
    private var ColourAddition = 0
    private var ColourBreathingOffset = 0
    private var RightLeft = true
    var mcHeight = 100
    var mcWidth = 100
    var currenthealth = 0
    var maxhealth = 1f
    var playerInfo: NetworkPlayerInfo? = null
    var targetPing: String? = null
    private var Purple = Color(84, 30, 97).rgb
    private var Blue = Color(32, 45, 99).rgb
    private var Green = Color(45, 214, 45).rgb
    private var Red = Color(190, 0, 0).rgb
    private var White = Color(255, 255, 255).rgb
    private var Aftery = Color(255, 160, 255).rgb
    @EventTarget
    private fun onUpdate(event: UpdateEvent) {
        val aura = (LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura?)!!
        val target = aura.target
        val scale = ScaledResolution(mc)
        if (target != null) {
            onGround = if (target.onGround) "OnGround" else "NoGround"
        }
        if (ColorBreathing.get() && ComplementaryColor.get() != "White") {
            if (RightLeft) {
                ColourAddition++
            } else {
                ColourAddition--
            }
            if (ColourAddition >= 30) {
                RightLeft = false
            }
            if (ColourAddition <= 0) {
                RightLeft = true
            }
        }
        if (!ColorBreathing.get()) {
            ColourAddition = 0
        }
        ColourBreathingOffset = if (ComplementaryColor.get() == "Aftery") {
            -ColourAddition
        } else {
            ColourAddition
        }
        if (target != null) {
            if (mc.thePlayer.ticksExisted % 40 == 0) {
                mcHeight = scale.scaledHeight
                mcWidth = scale.scaledWidth
                maxhealth = target.maxHealth
                playerInfo = mc.netHandler.getPlayerInfo(target.uniqueID)
                targetPing = if (playerInfo == null) "0 ms" else playerInfo!!.responseTime.toString() + " ms"
            }
            if (mc.thePlayer.ticksExisted % 5 == 0) {
                currenthealth = target.health.toInt()
            }
            if (mc.thePlayer.ticksExisted % 2 == 0) {
                TargetDistance = target.getDistanceToEntity(mc.thePlayer).toInt()
                Distance = "Distance $TargetDistance"
                if (TargetDistance > 10) {
                    Distance = "Distance 10+"
                }
            }
            targetHurtTime = target.hurtTime
        }
        when (ComplementaryColor.get()) {
            "White" -> {
                color = White
                ColourAddition = 0
            }
            "Red" -> color = Red
            "Green" -> color = Green
            "Blue" -> color = Blue
            "Aftery" -> color = Aftery
            "Purple" -> color = Purple
            else -> {
            }
        }
    }
    private fun renderItemStack(stack: ItemStack, x: Int) {
        mc.renderItem.zLevel = -150.0f
        mc.renderItem.renderItemAndEffectIntoGUI(stack, x, 20)
        mc.renderItem.renderItemOverlays(mc.fontRendererObj, stack, x, 20)
    }
    private fun renderArmor(player: EntityPlayer) {
        var armourStack: ItemStack
        var xOffset = 36
        if (player.heldItem != null) {
            val stock = player.heldItem.copy()
            if (stock.hasEffect() && (stock.item is ItemTool || stock.item is ItemArmor)) {
                stock.stackSize = 1
            }
            renderItemStack(stock, xOffset)
            xOffset += 16
        }
        val renderStack: Array<ItemStack> = player.inventory.armorInventory
        for (index in 3 downTo 0) {
            armourStack = renderStack[index]
            renderItemStack(armourStack, xOffset)
            xOffset += 16
        }
    }
    @EventTarget
    fun onRender2D(event: Render2DEvent?) {
        val Killaura = LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura?
        val res = ScaledResolution(mc)
        assert(Killaura != null)
        val target1 = Killaura!!.target
        val x = res.scaledWidth / 2 + 30
        val y = res.scaledHeight / 2 + 30
        if (target1 !== lastEnt && target1 != null) {
            lastEnt = target1
        }
        if (startAnim) {
            stopAnim = false
        }
        if (animAlpha == 255 && Killaura.target == null) {
            stopAnim = true
        }
        startAnim = Killaura.target != null
        if (startAnim) {
            anim = AnimationUtil.mvoeUD(anim, 0.0f, 0.09f)
            if (animAlpha < 255) {
                animAlpha += 15
            }
        }
        if (stopAnim) {
            anim = AnimationUtil.mvoeUD(anim, 75f, 0.09f)
            if (animAlpha > 0) {
                animAlpha -= 15
            }
        }
        if (target1 == null && animAlpha < 255) {
            startAnim = false
            stopAnim = true
        }
        val player: EntityLivingBase? = target1
        when (modeValue.get()) {
            "Astolfo" -> if (player != null) {
                RenderUtils.pre()
                GlStateManager.pushMatrix()

                // BaseRect(black)
                RenderUtils.drawRect(x + 0.7f, y.toFloat(), x + 149.7f, (y + 60).toFloat(), Color(0, 0, 0, 110).rgb)

                // health color math
                val health = player.health
                var health2: Float
                val fractions = floatArrayOf(0.0f, 0.2f, 0.7f)
                val colors = arrayOf(Color.RED, Color.YELLOW, Color.GREEN)
                val progress = health / player.maxHealth
                var customColor = if (health >= 0.0f) blendColors(fractions, colors, progress)!!
                    .brighter() else Color.RED
                customColor = customColor.darker()

                // Player name
                Fonts.font35.drawStringWithShadow(player.name, (x + 37).toFloat(), (y + 8).toFloat(), -1)
                Fonts.font35.drawStringWithShadow("Dist: " + mc.thePlayer.getDistanceToEntity(player),
                    (x + 37).toFloat(), (y + 35).toFloat(), -1);


                // Player Health
                GlStateManager.scale(1.5f, 1.5f, 1.5f)
                Fonts.font35.drawString(
                    Math.round(player.health).toString() + "❤", (x + 37) / 1.5f,
                    (y + 20) / 1.5f, customColor.rgb
                )
                // health rect animation
                val wdnmd = 150.0
                if (astolfoHelathAnim < wdnmd
                    * (player.health / player.maxHealth.also { health2 = it })
                ) {
                    if (wdnmd * health2 - astolfoHelathAnim < 1.0) {
                        astolfoHelathAnim = (wdnmd * health2).toFloat()
                    }
                    astolfoHelathAnim = (astolfoHelathAnim + 4.0).toFloat()
                }
                if (wdnmd * health2 - astolfoHelathAnim > 1.0) {
                    astolfoHelathAnim = (wdnmd * health2).toFloat()
                }
                astolfoHelathAnim = (astolfoHelathAnim - 4.0).toFloat()
                if (astolfoHelathAnim < 0) {
                    astolfoHelathAnim = 0f
                }

                // health rect base
                RenderUtils.drawRect(
                    (x + 2.985f) / 1.5f, (y + 55) / 1.5f, (x + 148) / 1.5f, (y + 58) / 1.5f,
                    Color(customColor.red, customColor.green, customColor.blue, 100).rgb
                )

                // health rect main
                RenderUtils.drawRect(
                    (x + 2.985f) / 1.5f, (y + 55) / 1.5f, (x + 2 + astolfoHelathAnim) / 1.5f,
                    (y + 58) / 1.5f, customColor.rgb
                )
                GlStateManager.popMatrix()
                RenderUtils.post()

                // Player Model
                GlStateManager.color(1.0f, 1.0f, 1.0f)
                RenderUtils.drawEntityOnScreen(
                    x + 18,
                    (y + (if (player.isSneaking) 38 else if (player is EntityPlayer) if (player.inventory.armorInventory.isEmpty()) 44 else 46 else 46)
                            + player.eyeHeight / 0.3f).toInt(), 24f, player.rotationYaw, player.rotationPitch, player
                )
                if (player is EntityPlayer) {
                    GlStateManager.pushMatrix()
                    // Player Armor
                    val stuff = ArrayList<ItemStack>()
                    val split = x + 132
                    var y2 = y - 16
                    var index = 3
                    while (index >= 0) {
                        val armer = player.inventory.armorInventory[index]
                        if (armer != null) {
                            stuff.add(armer)
                        }
                        --index
                    }
                    for (errything in stuff) {
                        if (mc.theWorld != null) {
                            RenderHelper.enableGUIStandardItemLighting()
                            y2 += 14
                        }
                        GlStateManager.disableAlpha()
                        GlStateManager.clear(256)
                        mc.renderItem.zLevel = -150.0f
                        mc.renderItem.renderItemAndEffectIntoGUI(errything, split, y2)
                        mc.renderItem.renderItemOverlays(mc.fontRendererObj, errything, split, y2)
                        mc.renderItem.zLevel = 0.0f
                        GlStateManager.disableBlend()
                        GlStateManager.scale(0.5, 0.5, 0.5)
                        GlStateManager.disableDepth()
                        GlStateManager.disableLighting()
                        GlStateManager.enableDepth()
                        GlStateManager.scale(2.0f, 2.0f, 2.0f)
                        GlStateManager.enableAlpha()
                    }
                    GlStateManager.popMatrix()
                }
            }
            "AquaBounce" -> {
                val killaura = (LiquidBounce.moduleManager.getModule(KillAura::class.java) as KillAura?)!!
                val entity = killaura.target
                if (entity != null && !entity.isDead && entity is EntityPlayer && mc.thePlayer.getDistanceToEntity(
                        entity
                    ) < 8.0f
                ) {
                    var hpPercentage = (entity.getHealth() / entity.getMaxHealth()).toDouble()
                    val scaledRes = ScaledResolution(mc)
                    val scaledWidth = scaledRes.scaledWidth.toFloat()
                    val scaledHeight = scaledRes.scaledHeight.toFloat()
                    if (hpPercentage > 1.0) {
                        hpPercentage = 1.0
                    } else if (hpPercentage < 0.0) {
                        hpPercentage = 0.0
                    }
                    UiUtils.rectangleBordered(
                        (scaledWidth / 2.0f - 200.0f).toDouble(),
                        (scaledHeight / 2.0f - 42.0f).toDouble(),
                        (scaledWidth / 2.0f - 200.0f + 40.0f).toDouble(),
                        (scaledHeight / 2.0f - 2.0f).toDouble(),
                        1.0,
                        Colors.getColor(0, 0),
                        Colors.getColor(0, 0)
                    )
                    RenderUtils.drawRect(
                        scaledWidth / 2.0f - 200.0f,
                        scaledHeight / 2.0f - 42.0f,
                        scaledWidth / 2.0f - 200.0f + 40.0f + (if (mc.fontRendererObj.getStringWidth(entity.getName()) > 105) mc.fontRendererObj.getStringWidth(
                            entity.getName()
                        ) - 10 else 105).toFloat(),
                        scaledHeight / 2.0f - 2.0f,
                        Color(34, 34, 34, 150).rgb
                    )
                    RenderUtils.drawFace(
                        scaledWidth.toInt() / 2 - 196,
                        (scaledHeight / 2.0f - 38.0f).toInt(),
                        8.0f,
                        8.0f,
                        8,
                        8,
                        32,
                        32,
                        64.0f,
                        64.0f,
                        entity as AbstractClientPlayer?
                    )
                    mc.fontRendererObj.drawStringWithShadow(
                        entity.getName(),
                        scaledWidth / 2.0f - 196.0f + 40.0f,
                        scaledHeight / 2.0f - 36.0f,
                        -1
                    )
                    RenderUtils.drawRect(
                        scaledWidth / 2.0f - 196.0f + 40.0f,
                        scaledHeight / 2.0f - 26.0f,
                        ((scaledWidth / 2.0f - 196.0f + 40.0f).toDouble() + 87.5).toFloat(),
                        scaledHeight / 2.0f - 14.0f,
                        Color(55, 55, 55).rgb
                    )
                    RenderUtils.drawRect(
                        scaledWidth / 2.0f - 196.0f + 40.0f,
                        scaledHeight / 2.0f - 26.0f,
                        ((scaledWidth / 2.0f - 196.0f + 40.0f).toDouble() + hpPercentage * 1.25 * 70.0).toFloat(),
                        scaledHeight / 2.0f - 14.0f,
                        Colors.getHealthColor(entity).rgb
                    )
                    mc.fontRendererObj.drawStringWithShadow(
                        String.format("%.1f", entity.getHealth()),
                        scaledWidth / 2.0f - 196.0f + 40.0f + 36.0f,
                        scaledHeight / 2.0f - 23.0f,
                        Colors.getHealthColor(entity).rgb
                    )
                    mc.fontRendererObj.drawStringWithShadow(
                        "Distance: \u00a77" + mc.thePlayer.getDistanceToEntity(entity)
                            .toInt() + "m", scaledWidth / 2.0f - 196.0f + 40.0f, scaledHeight / 2.0f - 12.0f, -1
                    )
                }
            }
        }
    }

    override fun onEnable() {
        animAlpha = 0
        startAnim = false
        stopAnim = false
        astolfoHelathAnim = 0f
    }

    private fun getIncremental(`val`: Double): Double {
        val one = 1.0 / 10.0
        return Math.round(`val` * one) / one
    }

    companion object {
        fun getFractionIndicies(fractions: FloatArray): IntArray {
            val range = IntArray(2)
            var startPoint = 0
            if (startPoint >= fractions.size) {
                startPoint = fractions.size - 1
            }
            range[0] = startPoint - 1
            range[1] = startPoint
            return range
        }

        fun blendColors(fractions: FloatArray, colors: Array<Color>, progress: Float): Color? {
            val color: Color?
            if (fractions.size == colors.size) {
                val indicies = getFractionIndicies(fractions)
                val range = floatArrayOf(fractions[indicies[0]], fractions[indicies[1]])
                val colorRange = arrayOf(colors[indicies[0]], colors[indicies[1]])
                val max = range[1] - range[0]
                val value = progress - range[0]
                val weight = value / max
                color = blend(colorRange[0], colorRange[1], (1.0f - weight).toDouble())
                return color
            }
            return Color(255, 255, 255)
        }

        fun blend(color1: Color, color2: Color, ratio: Double): Color? {
            val r = ratio.toFloat()
            val ir = 1.0f - r
            val rgb1 = FloatArray(3)
            val rgb2 = FloatArray(3)
            color1.getColorComponents(rgb1)
            color2.getColorComponents(rgb2)
            var red = rgb1[0] * r + rgb2[0] * ir
            var green = rgb1[1] * r + rgb2[1] * ir
            var blue = rgb1[2] * r + rgb2[2] * ir
            if (red < 0.0f) {
                red = 0.0f
            } else if (red > 255.0f) {
                red = 255.0f
            }
            if (green < 0.0f) {
                green = 0.0f
            } else if (green > 255.0f) {
                green = 255.0f
            }
            if (blue < 0.0f) {
                blue = 0.0f
            } else if (blue > 255.0f) {
                blue = 255.0f
            }
            var color3: Color? = null
            try {
                color3 = Color(red, green, blue)
            } catch (exp: IllegalArgumentException) {
                exp.printStackTrace()
            }
            return color3
        }
    }

}