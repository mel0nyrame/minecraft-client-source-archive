package net.ccbluex.liquidbounce.features.module.modules.misc

import io.netty.buffer.Unpooled
import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.timer.TimerUtil
import net.minecraft.network.PacketBuffer
import net.minecraft.network.play.client.C17PacketCustomPayload

@ModuleInfo(
    name = "HytBypass",
    description = ":/",
    category = ModuleCategory.MISC
)
class HytBypass : Module(){
    private val timer = TimerUtil()
    @EventTarget
    fun onUpdate(event: UpdateEvent) {
        if (timer.isDelayComplete(2000L)) {
            if (mc.netHandler != null) {
                mc.netHandler.networkManager.sendPacket(
                    C17PacketCustomPayload(
                        "AntiCheat", PacketBuffer(Unpooled.buffer()).writeString(
                            "{\"base64\":\"ecbeb575677ab9a37410748a5f429f9f\",\"cltitle\":\"\u6211\u7684\u4e16\u754c 1.8.9\",\"isLiquidbounce\":false,\"path\":\"mixins.mcwrapper.json\",\"player\":\"" +
                                    mc.thePlayer.name + "\"}"
                        )
                    )
                )
            }
            timer.reset()
        }
    }
}
