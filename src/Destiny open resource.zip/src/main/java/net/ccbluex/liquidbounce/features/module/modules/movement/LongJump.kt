/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.JumpEvent
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.event.UpdateEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import net.minecraft.util.EnumFacing

@ModuleInfo(name = "LongJump", description = "Allows you to jump further.", category = ModuleCategory.MOVEMENT)
class LongJump : Module() {
    private val modeValue =
        ListValue("Mode", arrayOf("NCP", "AACv1", "AACv2", "AACv3", "AAC5","Mineplex", "Mineplex2", "Mineplex3","Hyt"), "NCP")
    private val ncpBoostValue = FloatValue("NCPBoost", 4.25f, 1f, 10f)
    private val autoJumpValue = BoolValue("AutoJump", false)
    private var jumped = false
    private var canBoost = false
    private var teleported = false
    private var canMineplexBoost = false
    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        if (jumped) {
            val mode = modeValue.get()
            if (mc.thePlayer.onGround || mc.thePlayer.capabilities.isFlying) {
                jumped = false
                canMineplexBoost = false
                if (mode.equals("NCP", ignoreCase = true)) {
                    mc.thePlayer.motionX = 0.0
                    mc.thePlayer.motionZ = 0.0
                }
                return
            }
            when (mode.toLowerCase()) {
                "ncp" -> {
                    MovementUtils.strafe(MovementUtils.getSpeed() * if (canBoost) ncpBoostValue.get() else 1f)
                    canBoost = false
                }
                "aacv1" -> {
                    mc.thePlayer.motionY += 0.05999
                    MovementUtils.strafe(MovementUtils.getSpeed() * 1.08f)
                }
                "aac5" ->{
                    mc.thePlayer.jumpMovementFactor = 0.05549f
                }
                "hyt" -> {
                    mc.thePlayer.motionY += 0.031470000997
                    MovementUtils.strafe(MovementUtils.getSpeed() * 1.0114514f)
                    mc.timer.timerSpeed = 1.0114514f
                }
                "aacv2", "mineplex3" -> {
                    mc.thePlayer.jumpMovementFactor = 0.09f
                    mc.thePlayer.motionY += 0.0132099999999999999999999999999
                    mc.thePlayer.jumpMovementFactor = 0.08f
                    MovementUtils.strafe()
                }
                "aacv3" -> {
                    val player = mc.thePlayer
                    if (player.fallDistance > 0.5f && !teleported) {
                        val value = 3.0
                        val horizontalFacing = player.horizontalFacing
                        var x = 0.0
                        var z = 0.0
                        when (horizontalFacing) {
                            EnumFacing.NORTH -> z = -value
                            EnumFacing.EAST -> x = +value
                            EnumFacing.SOUTH -> z = +value
                            EnumFacing.WEST -> x = -value
                        }
                        player.setPosition(player.posX + x, player.posY, player.posZ + z)
                        teleported = true
                    }
                }
                "mineplex" -> {
                    mc.thePlayer.motionY += 0.0132099999999999999999999999999
                    mc.thePlayer.jumpMovementFactor = 0.08f
                    MovementUtils.strafe()
                }
                "mineplex2" -> {
                    if (!canMineplexBoost)
                        return

                    mc.thePlayer.jumpMovementFactor = 0.1f
                    if (mc.thePlayer.fallDistance > 1.5f) {
                        mc.thePlayer.jumpMovementFactor = 0f
                        mc.thePlayer.motionY = -10.0
                    }
                    MovementUtils.strafe()
                }
            }
        }
        if (autoJumpValue.get() && mc.thePlayer.onGround && MovementUtils.isMoving()) {
            jumped = true
            mc.thePlayer.jump()
        }
    }

    @EventTarget
    fun onMove(event: MoveEvent) {
        val mode = modeValue.get()
        if (mode.equals("mineplex3", ignoreCase = true)) {
            if (mc.thePlayer.fallDistance != 0f) mc.thePlayer.motionY += 0.037
        } else if (mode.equals("ncp", ignoreCase = true) && !MovementUtils.isMoving() && jumped) {
            mc.thePlayer.motionX = 0.0
            mc.thePlayer.motionZ = 0.0
            event.zeroXZ()
        }
    }

    @EventTarget(ignoreCondition = true)
    fun onJump(event: JumpEvent) {
        jumped = true
        canBoost = true
        teleported = false
        if (state) {
            when (modeValue.get().toLowerCase()) {
                "mineplex" -> event.motion = event.motion * 4.08f
                "mineplex2" -> if (mc.thePlayer.isCollidedHorizontally) {
                    event.motion = 2.31f
                    canMineplexBoost = true
                    mc.thePlayer.onGround = false
                }
            }
        }
    }

    override val tag: String
        get() = modeValue.get()
}