package net.ccbluex.liquidbounce.features.module.modules.Legit

import net.ccbluex.liquidbounce.event.EventTarget
import net.ccbluex.liquidbounce.event.Render3DEvent
import net.ccbluex.liquidbounce.event.StrafeEvent
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.EntityUtils
import net.ccbluex.liquidbounce.utils.Rotation
import net.ccbluex.liquidbounce.utils.RotationUtils
import net.ccbluex.liquidbounce.utils.extensions.getDistanceToEntityBox
import net.ccbluex.liquidbounce.utils.render.RenderUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.entity.Entity
import java.awt.Color

@ModuleInfo(name = "GunAimbot", description = "",category = ModuleCategory.COMBAT)
class GunAimbot : Module() {

    private val rangeValue = FloatValue("Range", 40F, 1F, 100F)
    private val turnSpeedValue = FloatValue("TurnSpeed", 30F, 1F, 180F)
    private val fovValue = FloatValue("FOV", 180F, 1F, 180F)
    private val recoilSize = FloatValue("RecoilSize", 1f, 0f, 5f)
    private val centerValue = BoolValue("Center", true)
    private val lockValue = BoolValue("Lock", true)
    private val silent = BoolValue("Silent", true)


    private var rotation: Rotation? = null
    private var entity: Entity? = null

    override fun onEnable() {
        rotation = null
        entity=null
    }

    @EventTarget
    fun onStrafe(event: StrafeEvent) {

        val range = rangeValue.get()
        entity = mc.theWorld.loadedEntityList
            .filter {
                EntityUtils.isSelected(it, true) && mc.thePlayer.canEntityBeSeen(it) &&
                        mc.thePlayer.getDistanceToEntityBox(it) <= range && RotationUtils.getRotationDifference(it) <= fovValue.get()
            }
            .minBy { RotationUtils.getRotationDifference(it) } ?: return

        if (!lockValue.get() && RotationUtils.isFaced(entity, range.toDouble()))
            return

        val boundingBox = entity!!.entityBoundingBox

        rotation = RotationUtils.limitAngleChange(
            RotationUtils.serverRotation,
            if (centerValue.get())
                RotationUtils.toRotation(RotationUtils.getCenter(boundingBox), true)
            else
                RotationUtils.searchCenter(
                    boundingBox, false, false, true,
                    false
                ).rotation,
            (turnSpeedValue.get() + Math.random()).toFloat()
        )

        if (recoilSize.get()!=0f) {
            rotation!!.pitch += (recoilSize.get()*Math.random()).toFloat()
        }

        if (RotationUtils.targetRotation != null) {
            return
        }

        if (silent.get()) {
            mc.thePlayer.isSprinting=false
            RotationUtils.setTargetRotation(rotation)
            RotationUtils.targetRotation.applyStrafeToPlayer(event)
            event.cancelEvent()
        } else {
            rotation!!.toPlayer(mc.thePlayer)
        }
    }


    @EventTarget
    fun onRender3D(event: Render3DEvent){
        if (entity!=null) {
            mc.fontRendererObj.drawStringWithShadow("[   ]", mc.displayWidth/2f, mc.displayHeight/2f,0x6464E1)
            RenderUtils.drawEntityBox(entity!!,Color(100,100,225,255),false,true,0f)
        }
    }
}