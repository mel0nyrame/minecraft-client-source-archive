package net.ccbluex.liquidbounce.utils

object PlaySound : MinecraftInstance(){
    var mode = 0
}