/*
 * Decompiled with CFR 0_132.
 */
package net.ccbluex.liquidbounce.event;


public class EventPreUpdate
        extends Event {
    public static float yaw;
    public static float pitch;
    public double y;
    private boolean ground;

    public EventPreUpdate(float yaw, float pitch, double y, boolean ground) {
        EventPreUpdate.yaw = yaw;
        EventPreUpdate.pitch = pitch;
        this.y = y;
        this.ground = ground;
    }

    public float getYaw() {
        return yaw;
    }

    public void setYaw(float yaw) {
        EventPreUpdate.yaw = yaw;
    }

    public float getPitch() {
        return pitch;
    }

    public void setPitch(float pitch) {
        EventPreUpdate.pitch = pitch;
    }

    public double getY() {
        return this.y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public boolean isOnground() {
        return this.ground;
    }

    public void setOnground(boolean ground) {
        this.ground = ground;
    }
}

