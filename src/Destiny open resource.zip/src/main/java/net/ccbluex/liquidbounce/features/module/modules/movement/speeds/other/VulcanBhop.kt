package net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other

import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura
import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.EventPreUpdate
import net.ccbluex.liquidbounce.event.JumpEvent
import net.ccbluex.liquidbounce.event.MoveEvent
import net.ccbluex.liquidbounce.features.module.modules.movement.Speed
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.utils.MovementUtils.*

class VulcanBhop : SpeedMode("VulcanBoost") {
    override fun onJump(event: JumpEvent) {
        if(mc.thePlayer !=null)
            event.cancelEvent()
    }

    override fun onMotion() {
        val speed = LiquidBounce.moduleManager[Speed::class.java] as Speed
        val killaura = LiquidBounce.moduleManager[KillAura::class.java] as KillAura
        if (isMoving()){
            when{
                mc.thePlayer.onGround->{
                    if(
                        (speed.vulcandamageboost.get().equals("DamageOnly")&&mc.thePlayer.hurtTime>0) ||
                        (speed.vulcandamageboost.get().equals("AttackOnly")&&killaura.target !=null) ||
                        (speed.vulcandamageboost.get().equals("Both")&& mc.thePlayer.hurtTime>0&&killaura.target !=null)
                    )
                        setMotion(speed.vulcandamageboostValue.get().toDouble())
                    else
                        setMotion(0.475)

                    mc.thePlayer.motionY = getJumpBoostModifier(0.42)
                }
                (speed.vulcandamageboost.get().equals("DamageOnly")&&mc.thePlayer.hurtTime>0) ||
                        (speed.vulcandamageboost.get().equals("AttackOnly")&&killaura.target !=null) ||
                        (speed.vulcandamageboost.get().equals("Both")&& mc.thePlayer.hurtTime>0&&killaura.target !=null) && !mc.thePlayer.onGround->{
                    setMotion(speed.vulcandamageboostValue.get().toDouble())
                }
            }
        }else {
            mc.thePlayer.motionX *=1.0
            mc.thePlayer.motionZ *=1.0
        }
    }

    override fun onPreUpdate(event: EventPreUpdate) {
    }

    override fun onUpdate() {
    }

    override fun onMove(event: MoveEvent) {
    }

    override fun onEnable() {
    }

    override fun onDisable() {
    }
}