package net.ccbluex.liquidbounce.features.module.modules.movement;

import net.ccbluex.liquidbounce.event.BlockBBEvent;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.MoveEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.RotationUtils;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.minecraft.block.BlockAir;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;

@ModuleInfo(name = "CollideFly", description = "Collide fly.", category = ModuleCategory.MOVEMENT)
public class CollideFly extends Module {
    private final IntegerValue speedValue = new IntegerValue("Speed", 14, 10, 200);

    @Override
    public void onEnable() {
        mc.thePlayer.addVelocity(0, 0.2, 0);
    }

    @Override
    public void onDisable() {
        mc.thePlayer.motionY=0;
    }

    @EventTarget
    public void onMove(MoveEvent event) {
        RotationUtils.reset();
        if(mc.gameSettings.keyBindForward.isKeyDown()) {
            float speed = speedValue.get() / 100F;
            float f = mc.thePlayer.rotationYaw * 0.017453292F;
            mc.thePlayer.motionX -= MathHelper.sin(f) * speed;
            mc.thePlayer.motionZ += MathHelper.cos(f) * speed;
            event.setX(mc.thePlayer.motionX);
            event.setZ(mc.thePlayer.motionZ);
        }
    }

    @EventTarget
    public void onBB(BlockBBEvent event) {
        if (mc.thePlayer == null) return;
        if(event.getBlock() instanceof BlockAir&&event.getY() < mc.thePlayer.posY){
            event.setBoundingBox(AxisAlignedBB.fromBounds(event.getX(), mc.thePlayer.posY, event.getZ(), event.getX() + 1, mc.thePlayer.posY, event.getZ() + 1));
        }
    }
}
