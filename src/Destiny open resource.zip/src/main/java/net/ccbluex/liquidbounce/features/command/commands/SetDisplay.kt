package net.ccbluex.liquidbounce.features.command.commands

import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.utils.render.ColorUtils
import org.lwjgl.opengl.Display

class SetDisplay : Command("title", emptyArray()) {
    override fun execute(args: Array<String>) {
        val string: String
        var i = 1
        var title = ""
        while(i < args.size) {
            title += args[i] + " "
            i++
        }
        string =  when(args[1]){
            "1" -> "Achievement provides the only real pleasure in life"
            "2" -> "Keep on going never give up"
            "3" -> "Action speak louder than words"
            "4" ->  "Never put off what you can do today until tomorrow"
            "5" -> "Judge not from appearances"
            "6" -> "Victory won''t come to me unless I go to it"
            "7" -> "While there is life there is hope"
            "8" -> "Nothing is impossible"
            "9" -> "Do what you say,say what you do"
            else -> title
        }

        Display.setTitle(string)
        chat(Display.getTitle() + " was changed to " + title)
        if (args.isEmpty()) {
            chatSyntax("title <title>")
        }
    }
}