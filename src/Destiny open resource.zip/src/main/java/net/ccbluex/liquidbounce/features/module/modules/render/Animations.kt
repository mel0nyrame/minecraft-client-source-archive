package net.ccbluex.liquidbounce.features.module.modules.render

import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.IntegerValue
import net.ccbluex.liquidbounce.value.ListValue

@ModuleInfo(name = "Animations", description = "Animation for blocking.", category = ModuleCategory.RENDER)
class Animations : Module() {
    override val tag: String
        get() = presetValue.get()

    val presetValue = ListValue(
        "Preset", arrayOf(
            "Akrien", "Avatar", "ETB", "Exhibition", "Push", "Reverse",
            "Shield", "SigmaNew", "SigmaOld", "Slide", "SlideDown", "HSlide", "Swong", "VisionFX",
            "Swank", "Jello", "None","Rotate"
        ),
        "SlideDown"
    )

    var translateX = FloatValue("TranslateX", 0.0f, 0.0f, 1.5f)
    var translateY = FloatValue("TranslateY", 0.0f, 0.0f, 0.5f)
    var translateZ = FloatValue("TranslateZ", 0.0f, 0.0f, -2.0f)
    val itemPosX = FloatValue("ItemPosX", 0.56F, -1.0F, 1.0F)
    val itemPosY = FloatValue("ItemPosY", -0.52F, -1.0F, 1.0F)
    val itemPosZ = FloatValue("ItemPosZ", -0.71999997F, -1.0F, 1.0F)
    var itemScale = FloatValue("ItemScale", 0.4f, 0.0f, 2.0f)
    var swingAnim = BoolValue("SwingAnim",false)

    companion object {
        @JvmField
        val Scale = FloatValue("Scale", 1f, 0f, 2f)
        @JvmField
        val swingSpeed = IntegerValue("ArmSlow", 0, 0, 100)
        @JvmField
        val swingmode = ListValue("SwingMode", arrayOf("1.7", "1.8", "Custom"), "1.8")

        @JvmField
        val heldItemRight = IntegerValue("HeldItemRight", 3, -5, 10)

        @JvmField
        val rotateAngleY = FloatValue("AngleY", 0f, -1f, 3f)
    }
}