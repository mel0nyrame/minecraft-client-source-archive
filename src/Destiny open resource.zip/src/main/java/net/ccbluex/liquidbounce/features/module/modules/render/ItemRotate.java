package net.ccbluex.liquidbounce.features.module.modules.render;

import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.timer.MSTimer;
import net.ccbluex.liquidbounce.value.FloatValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.client.renderer.GlStateManager;

@ModuleInfo(name = "ItemRotate", description = "AquaVit.", category = ModuleCategory.RENDER)
public class ItemRotate extends Module {
    float delay = 0.0F;
    public static final ListValue Mode = new ListValue("Mode", new String[] {"Straight","Forward","Nano","Uh"}, "Straight");
    public static FloatValue RotateSpeed = new FloatValue("RotateSpeed", 1, 0, 5);
    public String getTag() {
        return Mode.get();
    }
    public void ItemRenderRotate() {
        MSTimer rotateTimer = new MSTimer();
            if (ItemRotate.Mode.get().equalsIgnoreCase("Straight")) {
                GlStateManager.rotate(delay, 0.0F, 1.0F, 0.0F);
            }
            if (ItemRotate.Mode.get().equalsIgnoreCase("Forward")) {
                GlStateManager.rotate(delay, 1.0F, 1.0F, 0.0F);
            }
            if (ItemRotate.Mode.get().equalsIgnoreCase("Nano")) {
                GlStateManager.rotate(delay, 0.0F, 0.0F, 0.0F);
            }

            if (ItemRotate.Mode.get().equalsIgnoreCase("Uh")) {
                GlStateManager.rotate(delay, 1.0F, 0.0F, 1.0F);
            }
        if(rotateTimer.hasTimePassed(1L)) {
            ++delay;
            delay += ItemRotate.RotateSpeed.get();
            rotateTimer.reset();
        }
        if(delay > 360.0F) {
            delay = 0;
        }

    }
}
