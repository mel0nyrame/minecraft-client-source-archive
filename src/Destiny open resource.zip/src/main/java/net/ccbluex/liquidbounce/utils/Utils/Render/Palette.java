package net.ccbluex.liquidbounce.utils.Utils.Render;

import java.awt.*;
import java.util.function.Supplier;

public enum Palette {
    GREEN(() -> new Color(0, 255, 138)),
    WHITE(() -> Color.WHITE),
    PURPLE(() -> new Color(198, 139, 255)),
    DARK_PURPLE(() -> new Color(133, 46, 215)),
    BLUE(() -> new Color(116, 202, 255));

    private final Supplier<Color> colorSupplier;

    Palette(Supplier<Color> colorSupplier) {
        this.colorSupplier = colorSupplier;
    }

    public static Color fade(Color color) {
        return Palette.fade(color, 2, 100);
    }

    public static Color fade(Color color, int index, int count) {
        float[] hsb = new float[3];
        Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), hsb);
        float brightness = Math.abs(((float)(System.currentTimeMillis() % 2000L) / 1000.0f + (float)index / (float)count * 2.0f) % 2.0f - 1.0f);
        brightness = 0.5f + 0.5f * brightness;
        hsb[2] = brightness % 2.0f;
        return new Color(Color.HSBtoRGB(hsb[0], hsb[1], hsb[2]));
    }
    public static Color getAstolfoRainbow(int v1) {
        double delay = Math.ceil((double) (System.currentTimeMillis() +  (v1 * 70L)) / 5.0);
        float rainbow = (double) ((float) ((delay %= 420.0) / 420.0)) < 0.5 ? -((float) (delay / 420.0)) : (float) (delay / 420.0);
        return Color.getHSBColor(rainbow, 0.8f, 1.0f);
    }

    public static Color fade2(Color color,int index,int count) {
        float[] hsb = new float[3];
        Color.RGBtoHSB(color.getRed(),color.getGreen(), color.getBlue(),hsb);
        float bright = (float)Math.abs(((System.currentTimeMillis() % 1500L)/ 1000F + Math.sin(index / count * 2f)) % 2f - 1);
        bright = 2 * bright;
        hsb[2] = bright % 1f;
        return new Color(Color.HSBtoRGB(hsb[0], hsb[1], hsb[2]));
    }

    public Color getColor() {
        return this.colorSupplier.get();
    }
}

