package net.ccbluex.liquidbounce.features.module.modules.render;


import net.ccbluex.liquidbounce.LiquidBounce;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render2DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.features.module.modules.combat.KillAura;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.Utils.Player.PlayerUtil;
import net.ccbluex.liquidbounce.utils.render.ColorUtils;
import net.ccbluex.liquidbounce.utils.render.Colors;
import net.ccbluex.liquidbounce.utils.render.LnkRenderUtils;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

import static net.ccbluex.liquidbounce.utils.render.Colors.blendColors;

@ModuleInfo(name = "TargetHUD", description = "undefiend.", category = ModuleCategory.RENDER)
public class TargetHUD extends Module {
    //lnk的iq有多低
    private final ListValue modeValue = new ListValue("Mode", new String[]{"Simplicity","LiquidSense", "Astolfo", "Novoline"}, "LiquidSense");
    private final IntegerValue customX = new IntegerValue("X", -150, -500, 500);
    private final IntegerValue customY = new IntegerValue("Y", 80, -500, 500);
    private final IntegerValue redValue = new IntegerValue("R", 125, 0, 255);
    private final IntegerValue greenValue = new IntegerValue("G", 125, 0, 255);
    private final IntegerValue blueValue = new IntegerValue("B", 225, 0, 255);

    double animation = 0;
    float width = 0;

    final KillAura ka = (KillAura) LiquidBounce.moduleManager.getModule(KillAura.class);

    public EntityLivingBase getTarget () {
        if (ka.getTarget() != null) {
            return ka.getTarget();
        } else {
            return null;
        }
    }

    @EventTarget
    public void onRender2D(Render2DEvent event) {
        EntityLivingBase entity = mc.currentScreen instanceof GuiChat ? mc.thePlayer : ka.getTarget() != null ? ka.getTarget() : ka.getTarget() != null ? ka.getTarget() : null;
        ScaledResolution res = new ScaledResolution(mc);
        int x = res.getScaledWidth() / 2;
        int y = res.getScaledHeight() / 2;

        final KillAura ka = (KillAura) LiquidBounce.moduleManager.getModule(KillAura.class);
        EntityPlayer ent = (EntityPlayer) getTarget();
        if (entity != null) {
            // Simlicity
            if (modeValue.get().equalsIgnoreCase("Simplicity")) {
                GlStateManager.pushMatrix();
                double width = 100f;
                width = PlayerUtil.getIncremental(width, -50);

                Fonts.fontSF40.drawStringWithShadow("\247l" + entity.getName(), customX.get() + x + 38, customY.get() + y + 2.0f, -1);

                final float health = entity.getHealth();
                final float progress = health / entity.getMaxHealth();

                if (width < 80.0) {
                    width = 80.0;
                }

                if (width > 80.0) {
                    width = 80.0;
                }

                final double healthLocation = width * progress;

                if (animation < healthLocation + 5) {
                    animation++;
                }

                if (animation > healthLocation + 2) {
                    animation--;
                }

                RenderUtils.drawGradientSideways(customX.get() + x + 37.5, customY.get() + y + 11, customX.get() + x + 37.5 + animation, customY.get() + y + 19, ColorUtils.rainbow(5000000000L).getRGB(), ColorUtils.rainbow(500L).getRGB());
                RenderUtils.rectangleBordered(customX.get() + x + 37.0, customY.get() + y + 10.5, customX.get() + x + 38.0 + animation, customY.get() + y + 19.5, 0.5, Colors.getColor(0, 0), Colors.getColor(0));

                GlStateManager.resetColor();
                GlStateManager.popMatrix();
            }

            // LiquidSense
            if (modeValue.get().equalsIgnoreCase("LiquidSense")) {
                GlStateManager.pushMatrix();
                double width = mc.fontRendererObj.getStringWidth(ent.getName());
                width = PlayerUtil.getIncremental(width, -50);

                RenderUtils.drawtargethudRect(customX.get() + x, customY.get() + y - 0.5, customX.get() + x + 80 + width, customY.get() + y + 37.0, Colors.getColor(0, 0, 0, 120), Colors.getColor(200, 255, 255));
                mc.fontRendererObj.drawStringWithShadow("\247l" + ent.getName(), customX.get() + x + 38, customY.get() + y + 3.0f, -1);

                BigDecimal DT = BigDecimal.valueOf(mc.thePlayer.getDistanceToEntity(ent));
                DT = DT.setScale(1, RoundingMode .HALF_UP);
                double Dis = DT.doubleValue();
                double Food = ent.getFoodStats().getFoodLevel();
                double Armor = entity.getTotalArmorValue();

                final float health = entity.getHealth();
                final float[] fractions = {0.0f, 0.5f, 1.0f};
                final Color[] colors = {Color.RED, Color.YELLOW, Color.GREEN};
                final float progress = health / entity.getMaxHealth();
                final Color customColor = (health >= 0.0f) ? blendColors(fractions, colors, progress).brighter() : Color.RED;

                if (width < 80.0) {
                    width = 80.0;
                }

                if (width > 80.0) {
                    width = 80.0;
                }

                final double healthLocation = width * progress;

                if (animation < healthLocation + 5) {
                    animation++;
                }

                if (animation > healthLocation + 2) {
                    animation--;
                }

                RenderUtils.drawGradientSideways(customX.get() + x + 37.5, customY.get() + y + 13.5, customX.get() + x + 37.5 + animation, customY.get() + y + 16.5, new Color(225, 50, 50).getRGB(), customColor.getRGB());
                RenderUtils.rectangleBordered(customX.get() + x + 37.0, customY.get() + y + 13.5, customX.get() + x + 40.0 + width, customY.get() + y + 15.5 + 1, 0.5, Colors.getColor(0, 0), Colors.getColor(0));
                RenderUtils.drawFace(customX.get() + x + 3, customY.get() + y + 2, 32, (AbstractClientPlayer) entity);

                GlStateManager.scale(0.5, 0.5, 0.5);
                final String str = "Dist>> " + Dis + "   Food>> " + Food;
                mc.fontRendererObj.drawStringWithShadow(str, (customX.get() + x) * 2 + 76.0f, (customY.get() + y) * 2 + 40.0f, -1);
                final String str2 = String.format("Yaw>> %s", (int) entity.rotationYaw + "   Armor>> " + Armor);
                mc.fontRendererObj.drawStringWithShadow(str2, (customX.get() + x) * 2 + 76.0f, (customY.get() + y) * 2 + 55.0f, -1);
                GlStateManager.scale(2.0f, 2.0f, 2.0f);
                GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
                GlStateManager.enableAlpha();
                GlStateManager.enableBlend();
                GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
                GlStateManager.popMatrix();
            }

            // Astolfo
            if (modeValue.get().equalsIgnoreCase("Astolfo")) {
                int colors  = new Color(redValue.get(), greenValue.get(), blueValue.get(), 255).getRGB();
                int colors1 = new Color(redValue.get(), greenValue.get(), blueValue.get(), 150).getRGB();
                int colors2 = new Color(redValue.get(), greenValue.get(), blueValue.get(), 50).getRGB();

                final float health = getHealthes(entity);
                final float n18 = 125.0f * (health / entity.getMaxHealth());
                animation = RenderUtils.getAnimationState(animation, n18, 135.0f);
                GlStateManager.pushMatrix();
                GlStateManager.translate((float) (res.getScaledWidth() / 2 + customX.get() + 15), (float) (res.getScaledHeight() - customY.get() - 55), 0.0F);
                GlStateManager.color(1, 1, 1);
                if (ka.getTarget() instanceof EntityPlayer) {
                    GuiInventory.drawEntityOnScreen(-18, 47, 30, -180, 0, entity);
                } else {
                    GuiInventory.drawEntityOnScreen(-20, 50, 30, -180, 0, entity);
                }
                LnkRenderUtils.MdrawRect(-38.0, -14.0, 133, 52.0, Colors.getColor(0, 0, 0, 180));
                mc.fontRendererObj.drawStringWithShadow(entity.getName(), 0.0F, -8.0F, new Color(255, 255, 255).getRGB());
                LnkRenderUtils.MdrawRect(0.0f, 8.0f + Math.round(40.0f), 130f, 40f, colors2);
                if ((entity.getHealth() / 2.0f + entity.getAbsorptionAmount() / 2.0f) > 1.0) {
                    LnkRenderUtils.MdrawRect(0.0f, 8.0f + Math.round(40.0f), animation + 5f, 40f, colors1);
                }
                LnkRenderUtils.MdrawRect(0.0f, 8.0f + Math.round(40.0f), animation, 40f, colors);
                GlStateManager.scale(3f, 3f, 3f);
                mc.fontRendererObj.drawStringWithShadow(getHealthes(entity) + " \u2764", 0.0F, 2.5F, colors);
                GlStateManager.popMatrix();
            }

            // Novoline
            if (modeValue.get().equalsIgnoreCase("Novoline")) {
                int colors233 = new Color(redValue.get(), greenValue.get(), blueValue.get(), 255).getRGB();
                final String healthStr = String.valueOf((int) entity.getHealth() / 2.0f);

                double healthwidth;
                double healthamout;

                //player health
                GL11.glPushMatrix();
                double width = Fonts.minecraftFont.getStringWidth(entity.getName()) > 40 ? 20 + mc.fontRendererObj.getStringWidth(entity.getName()) : 50;
                healthwidth = width + 18;
                healthamout = healthwidth * entity.getHealth() / entity.getMaxHealth();
                healthamout = RenderUtils.getAnimationState(healthamout, healthwidth * entity.getHealth() / entity.getMaxHealth(), 200);
                RenderUtils.rectangleBordered(customX.get() + x - 9, customY.get() + y, customX.get() + x + 52 + width, customY.get() + y + 37, 1f, new Color(40, 40, 40).getRGB(), new Color(40, 40, 40).getRGB());
                //RenderUtil.rectangleBordered(x + 30, y + 11, x + 30 + healthwidth, y + 15, 0.5f, new Color(0, 0, 0, 0).getRGB(), new Color(0, 0, 0).getRGB());
                RenderUtils.rectangle(customX.get() + x + 30, customY.get() + y + 15, customX.get() + x + 30 + healthwidth, customY.get() + y + 24.5, new Color(90, 90, 90).getRGB());
                RenderUtils.rectangleBordered(customX.get() + x + 30, customY.get() + y + 15, customX.get() + x + 30 + healthamout, customY.get() + y + 24.5, 0f, colors233, new Color(0, 0, 0, 0).getRGB());
                RenderUtils.drawFace(customX.get() + x - 7, customY.get() + y + 2, 33, (AbstractClientPlayer) entity);
                Fonts.minecraftFont.drawStringWithShadow(healthStr + "❤", customX.get() + x + 30f, customY.get() + y + 58f - mc.fontRendererObj.FONT_HEIGHT - 22.2F, colors233);
                Fonts.minecraftFont.drawStringWithShadow(entity.getName(), customX.get() + x + 30, customY.get() + y + 4, new Color(255, 255, 255).getRGB());
                GL11.glPopMatrix();
            }
        }
    }

    private float getHealthes(final EntityLivingBase entityLivingBase) {
        return (float)(int)((int)Math.ceil(entityLivingBase.getHealth()) + 0.5f);
    }
}

