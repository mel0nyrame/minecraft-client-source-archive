package cn.fu917.module

import net.ccbluex.liquidbounce.LiquidBounce
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.utils.MinecraftInstance
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.minecraft.network.Packet
import net.minecraft.network.play.client.C03PacketPlayer
import java.util.ArrayList

@ModuleInfo(name = "PacketFix", description = ":/", category = ModuleCategory.MOVEMENT)
class Debug : Module() {
    private val packets: MutableList<Packet<*>> = ArrayList()
    var doAsFly = false
    var stage = 0.0
    var timer = 0.0
    fun move() {
    }

    override fun onEnable() {
        timer = 0.0
    }

    override fun onDisable() {
        doAsFly = false
        if (packets.size > 0) {
            for (packet in packets) {
                mc.thePlayer.sendQueue.addToSendQueue(packet)
                packets.clear()
            }
        }
    }


    @EventTarget
    fun onMotion(event: MotionEvent?) {
    }

    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        if (!MovementUtils.isMoving()) {
            timer = 0.0
        } else {
            timer++
        }
        if (mc.thePlayer.onGround && timer > 1) {
            doAsFly = true
            stage = 0.0
        }
        if (stage >= 1) {
            doAsFly = false
            if (packets.size > 0) {
                for (packet in packets) {
                    mc.thePlayer.sendQueue.addToSendQueue(packet)
                    packets.clear()
                }
            }
        }
    }

    @EventTarget
    fun onPacket(event: PacketEvent) {
        if (!doAsFly) return
        val packet = event.packet
        if (packet is C03PacketPlayer) {
            event.cancelEvent()
            packets.add(packet)
            stage++
        }
    }
}