/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.features.module.modules.movement

import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other.CustomSpeed
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.ncp.NCPBHop
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other.SlowHop
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other.Vanilla
import net.ccbluex.liquidbounce.event.*
import net.ccbluex.liquidbounce.features.module.Module
import net.ccbluex.liquidbounce.features.module.ModuleCategory
import net.ccbluex.liquidbounce.features.module.ModuleInfo
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.SpeedMode
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.ncp.NCPHop
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.other.VulcanBhop
import net.ccbluex.liquidbounce.features.module.modules.movement.speeds.verus.LowHop
import net.ccbluex.liquidbounce.utils.MovementUtils
import net.ccbluex.liquidbounce.value.BoolValue
import net.ccbluex.liquidbounce.value.FloatValue
import net.ccbluex.liquidbounce.value.ListValue
import java.util.*

@ModuleInfo(name = "Speed", description = "Allows you to move faster.", category = ModuleCategory.MOVEMENT)
class Speed : Module() {
    private val speedModes = arrayOf( // NCP
        NCPBHop(),
        NCPHop(),
        SlowHop(),
        CustomSpeed(),
        Vanilla(),
        LowHop(),
        VulcanBhop()
    )
    
    val modeValue: ListValue = object : ListValue("Mode", modes, "NCPBHop") {
        override fun onChange(oldValue: String, newValue: String) {
            if (state) onDisable()
        }

        override fun onChanged(oldValue: String, newValue: String) {
            if (state) onEnable()
        }
    }

    val vanillaspeed = FloatValue("VanillaSpeed",0.86f,0.0f,4f).displayable { modeValue.get() == "Vanilla" } as FloatValue
    val customSpeedValue = FloatValue("CustomSpeed", 1.6f, 0.2f, 2f)
    val customYValue = FloatValue("CustomY", 0f, 0f, 4f)
    val customTimerValue = FloatValue("CustomTimer", 1f, 0.1f, 2f)
    val vulcandamageboost = ListValue("VulcanMode", arrayOf("DamageOnly","AttackOnly","Both"),"AttackOnly")
    val vulcandamageboostValue = FloatValue("vulcanDamageBoost", 0.51f,0.475f,0.8f)
    val customStrafeValue = BoolValue("Strafe", true)
    val resetXZValue = BoolValue("ResetXZ", false)
    val resetYValue = BoolValue("ResetY", false)
    val groundspoof = BoolValue("GroundSpoof",true)
    @EventTarget
    fun onUpdate(event: UpdateEvent?) {
        if (mc.thePlayer.isSneaking) return
        if (MovementUtils.isMoving()) mc.thePlayer.isSprinting = true
        val speedMode = mode
        speedMode?.onUpdate()
    }


    @EventTarget
    fun onMotion(event: MotionEvent) {
        if (mc.thePlayer.isSneaking || event.eventState !== EventState.PRE) return
        if (MovementUtils.isMoving()) mc.thePlayer.isSprinting = true
        val speedMode = mode
        speedMode?.onMotion()
    }
    var stoptick = 0
    @EventTarget
    fun onJump(event: JumpEvent?) {
        if (mc.thePlayer == null || stoptick > 0) return
        val speedMode = mode
        speedMode?.onJump(event)
    }

    @EventTarget
    fun onMove(event: MoveEvent?) {
        if (mc.thePlayer.isSneaking) return
        val speedMode = mode
        speedMode?.onMove(event)
    }

    @EventTarget
    fun onTick(event: TickEvent?) {
        if (mc.thePlayer.isSneaking) return
        val speedMode = mode
        speedMode?.onTick()
    }
    @EventTarget
    fun onPreUpdate(event: EventPreUpdate) {
        if (mc.thePlayer.isSneaking)
            return
        val speedMode = mode
        speedMode?.onPreUpdate(event)
    }
    override fun onEnable() {
        if (mc.thePlayer == null) return
        mc.timer.timerSpeed = 1f
        val speedMode = mode
        speedMode?.onEnable()
    }

    override fun onDisable() {
        if (mc.thePlayer == null) return
        mc.timer.timerSpeed = 1f
        val speedMode = mode
        speedMode?.onDisable()
    }

    override val tag: String
        get() = modeValue.get()
    private val mode: SpeedMode?
        private get() {
            val mode = modeValue.get()
            for (speedMode in speedModes) if (speedMode.modeName.equals(mode, ignoreCase = true)) return speedMode
            return null
        }
    private val modes: Array<String>
        private get() {
            val list: MutableList<String> = ArrayList()
            for (speedMode in speedModes) list.add(speedMode.modeName)
            return list.toTypedArray()
        }
}