
package net.ccbluex.liquidbounce.utils.timer;

import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.misc.RandomUtils;

import java.util.Timer;
import java.util.TimerTask;

public final class MSTimer extends MinecraftInstance {

    private long time = -1L;
    private long lastMs = 0L;
    private long prevMS;
    public MSTimer(){
        this.prevMS = getTime();
    }
    public static long randomDelay(final int minDelay, final int maxDelay) {
        return RandomUtils.nextInt(minDelay, maxDelay);
    }

    public static long randomClickDelay(final int minCPS, final int maxCPS) {
        return (long) ((Math.random() * (1000 / minCPS - 1000 / maxCPS + 1)) + 1000 / maxCPS);
    }
    public boolean hasTimePassed(final long MS) {
        return System.currentTimeMillis() >= time + MS;
    }

    public long hasTimeLeft(final long MS) {
        return (MS + time) - System.currentTimeMillis();
    }

    public void reset() {

        time = System.currentTimeMillis();
        lastMs = 0L;
    }


    public boolean isDelayComplete(long delay) {

        return System.currentTimeMillis() - this.lastMs > delay;
    }

    public long getCurrentMS() {

        return System.nanoTime() / 1000000L;
    }

    public long getLastMs() {
        return this.lastMs;
    }

    public void setLastMs(int i) {

        this.lastMs = System.currentTimeMillis() + (long)i;
    }

    public boolean hasReached(long milliseconds) {

        return this.getCurrentMS() - this.lastMs >= milliseconds;
    }

    public boolean hasReached(float timeLeft) {

        return (float)(this.getCurrentMS() - this.lastMs) >= timeLeft;
    }

    public boolean delay(double nextDelay) {

        return (double)(System.currentTimeMillis() - this.lastMs) >= nextDelay;
    }
    public long getTime() {

        return System.nanoTime() / 1000000L;
    }

    public long getDifference() {

        return getTime() - this.prevMS;
    }

    public void setDifference(long difference) {
        this.prevMS = (getTime() - difference);
    }
}
