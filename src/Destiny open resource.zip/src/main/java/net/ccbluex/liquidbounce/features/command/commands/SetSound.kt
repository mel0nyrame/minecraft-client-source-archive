package net.ccbluex.liquidbounce.features.command.commands

import net.ccbluex.liquidbounce.features.command.Command
import net.ccbluex.liquidbounce.utils.PlaySound

class SetSound : Command("Sound", emptyArray()) {
    override fun execute(args: Array<String>) {
        var mode = 0
        if (args.size > 1) {
            try {
                if(args[1].isNotEmpty()) {
                    mode =  when(args[1]){
                        "1" -> 1
                        "2" -> 2
                        "3" -> 3
                        "4" -> 4
                        "5" -> 5
                        "6" -> 6
                        "7" -> 7
                        "8" -> 8
                        "9" -> 9
                        else -> 0
                    }
                    PlaySound.mode = mode
//                    if (args[1] != "reset") {
//                        Display.setTitle("LiquidBounce | Achievement provides the only real pleasure in life.")
//                    } else
//                        Display.setTitle("LiquidBounce | " + ColorUtils.translateAlternateColorCodes(args[1]))
//                    Display.setTitle("LiquidBounce | " + ColorUtils.translateAlternateColorCodes(string))
                }
                chat("Sound has changed $mode")
            } catch (exception: NumberFormatException) {
                chatSyntaxError()
            }
            return
        }

        chatSyntax("sound <value>")
    }
}