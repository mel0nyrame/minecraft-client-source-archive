/*
 * LiquidBounce Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge.
 * https://github.com/CCBlueX/LiquidBounce/
 */
package net.ccbluex.liquidbounce.ui.client.hud.element.elements

import com.google.common.collect.Iterables
import com.google.common.collect.Lists
import net.ccbluex.liquidbounce.ui.client.hud.element.Border
import net.ccbluex.liquidbounce.ui.client.hud.element.Element
import net.ccbluex.liquidbounce.ui.client.hud.element.ElementInfo
import net.ccbluex.liquidbounce.ui.client.hud.element.Side
import net.ccbluex.liquidbounce.ui.font.Fonts
import net.ccbluex.liquidbounce.value.*
import net.minecraft.client.gui.Gui
import net.minecraft.client.renderer.GlStateManager
import net.minecraft.scoreboard.ScoreObjective
import net.minecraft.scoreboard.ScorePlayerTeam
import net.minecraft.scoreboard.Scoreboard
import net.minecraft.util.EnumChatFormatting
import java.awt.Color

/**
 * CustomHUD scoreboard
 *
 * Allows to move and customize minecraft scoreboard
 */
@ElementInfo(name = "Scoreboard", force = true)
class ScoreboardElement(x: Double = 5.0, y: Double = 55.0, scale: Float = 1F, side: Side = Side(Side.Horizontal.RIGHT, Side.Vertical.MIDDLE)) : Element(x, y, scale, side) {

    private val textRedValue = IntegerValue("Text-R", 255, 0, 255)
    private val textGreenValue = IntegerValue("Text-G", 255, 0, 255)
    private val textBlueValue = IntegerValue("Text-B", 255, 0, 255)
    private val backgroundColorRedValue = IntegerValue("Background-R", 0, 0, 255)
    private val backgroundColorGreenValue = IntegerValue("Background-G", 0, 0, 255)
    private val backgroundColorBlueValue = IntegerValue("Background-B", 0, 0, 255)
    private val backgroundColorAlphaValue = IntegerValue("Background-Alpha", 100, 0, 255)

    //rainbow
    private val rectColorModeValue = ListValue("Rainbow", arrayOf("Fade", "Other","Astolfo"), "Fade")
    private val rectColorRedValue = IntegerValue("R", 0, 0, 255)
    private val rectColorGreenValue = IntegerValue("G", 111, 0, 255)
    private val rectColorBlueValue = IntegerValue("B", 255, 0, 255)
    private val fadeDistanceValue = IntegerValue("Fade-Distance", 50, 1, 100)
    private val noPointValue = BoolValue("NoNumber",true)
    private val shadowValue = BoolValue("Shadow", false)
    private val fontValue = FontValue("Font", Fonts.minecraftFont)
    /**
     * Draw element
     */
    override fun drawElement(): Border? {
        val counter = intArrayOf(1)
        val fontRenderer = fontValue.get()
        val textColor = textColor().rgb
        val backColor = backgroundColor().rgb
        val worldScoreboard: Scoreboard = mc.theWorld.scoreboard
        var currObjective: ScoreObjective? = null
        val playerTeam = worldScoreboard.getPlayersTeam(mc.thePlayer.name)

        if (playerTeam != null) {
            val colorIndex = playerTeam.chatFormat.colorIndex

            if (colorIndex >= 0)
                currObjective = worldScoreboard.getObjectiveInDisplaySlot(3 + colorIndex)
        }

        val objective = currObjective ?: worldScoreboard.getObjectiveInDisplaySlot(1) ?: return null

        val scoreboard: Scoreboard = objective.scoreboard
        var scoreCollection = scoreboard.getSortedScores(objective)
        val scores = Lists.newArrayList(Iterables.filter(scoreCollection) { input ->
            input?.playerName != null && !input.playerName.startsWith("#")
        })

        scoreCollection = if (scores.size > 15)
            Lists.newArrayList(Iterables.skip(scores, scoreCollection.size - 15))
        else
            scores

        var maxWidth = fontRenderer.getStringWidth(objective.displayName)

        for (score in scoreCollection) {
            val scorePlayerTeam = scoreboard.getPlayersTeam(score.playerName)
            val width = "${ScorePlayerTeam.formatPlayerName(scorePlayerTeam, score.playerName)}: ${EnumChatFormatting.RED}${score.scorePoints}"
            maxWidth = maxWidth.coerceAtLeast(fontRenderer.getStringWidth(width))
        }

        val maxHeight = scoreCollection.size * fontRenderer.FONT_HEIGHT
        val l1 = -maxWidth - 3

        Gui.drawRect(l1 - 2, -2, 5, maxHeight + fontRenderer.FONT_HEIGHT, backColor)


        scoreCollection.forEachIndexed { index, score ->
            val team = scoreboard.getPlayersTeam(score.playerName)
            val width = 5
            val height = maxHeight - index * fontRenderer.FONT_HEIGHT
            val name = ScorePlayerTeam.formatPlayerName(team, score.playerName)

            val scorePoints = "${EnumChatFormatting.RED}${score.scorePoints}"


            GlStateManager.resetColor()
            if (!name.toLowerCase().contains("cc") && !name.toLowerCase().contains(".top") && !name.contains(".com") && !name.contains(".net") && !name.contains(".cn") && !name.toLowerCase().contains("pixel") && !name.toLowerCase().contains("mc986") && !name.toLowerCase().contains("loyisa.cn")
            ) {
                fontRenderer.drawString(name, l1.toFloat(), height.toFloat(), 553648127, shadowValue.get())
            } else {
                val charArray = "Destiny"
                var length = 0
//                val rainbow = when(rectColorModeValue.get().toLowerCase()){
//                    "fade" -> Palette.fade(Color(rectColorRedValue.get(), rectColorGreenValue.get(), rectColorBlueValue.get()), counter[0] * 100,"gameSense.pub".length * 130).rgb
//                    "astolfo" -> ColorManager.Astolfo(counter[0] * 100)
//                    "other" -> ColorManager.fluxRainbow(-100, counter[0] * -50 * rainbowSpeed.get().toLong(),rainbowSaturation.get())
//                    else -> Color(rectColorRedValue.get(), rectColorGreenValue.get(), rectColorBlueValue.get()).rgb
//                }
//                for (charIndex in charArray) {
//                    fontRenderer.drawString(
//                        charIndex.toString(),
//                        l1 + length.toFloat(),
//                        height.toFloat(),
//                        rainbow,shadowValue.get())
//                    length += fontRenderer.getCharWidth(charIndex)
//                    counter[0] += 1
//                }
                for (charIndex in charArray) {
                    fontRenderer.drawString(
                        charIndex.toString(),
                        l1 + length.toFloat(),
                        height.toFloat(),
                        net.ccbluex.liquidbounce.utils.render.Palette.fade(Color(rectColorRedValue.get(), rectColorGreenValue.get(), rectColorBlueValue.get(), 0), index * fadeDistanceValue.get(), 100).rgb,shadowValue.get()
                    )
                    length += fontRenderer.getCharWidth(charIndex)
                    counter[0] = counter[0] + 1
                }
            }
            if(!noPointValue.get()) {
                fontRenderer.drawString(
                    scorePoints,
                    (width - fontRenderer.getStringWidth(scorePoints)).toFloat(),
                    height.toFloat(),
                    textColor,
                    shadowValue.get()
                )
            }
            //fontRenderer.drawString(scorePoints, (width - fontRenderer.getStringWidth(scorePoints)).toFloat(), height.toFloat(), textColor, shadowValue.get())
            if (index == scoreCollection.size - 1) {
                val displayName = objective.displayName

                GlStateManager.resetColor()

                fontRenderer.drawString(displayName, (l1 + maxWidth / 2 - fontRenderer.getStringWidth(displayName) / 2).toFloat(), (height -
                        fontRenderer.FONT_HEIGHT).toFloat(), textColor, shadowValue.get())
            }

        }

        return Border(-maxWidth.toFloat() - 5, -2F, 5F, maxHeight.toFloat() + fontRenderer.FONT_HEIGHT)
    }

    private fun backgroundColor() = Color(backgroundColorRedValue.get(), backgroundColorGreenValue.get(), backgroundColorBlueValue.get(), backgroundColorAlphaValue.get())

    private fun textColor() = Color(textRedValue.get(), textGreenValue.get(), textBlueValue.get())
}