var script = registerScript({
    name: "RedeLongJump",
    version: "1.1",
    authors: ["Rede"]
});

var S08PacketPlayerPosLook = Java.type('net.minecraft.network.play.server.S08PacketPlayerPosLook');

var air;

script.registerModule({
    name: "RedeLongJump",
    description: "lollololololololololol",
    category: "Combat",
    settings: {
        dis: Setting.boolean({
            name: "lagbackground",
            default: true
        })
    }
}, function(module) {
    module.on("enable", function() {
        air = 0;
    });

    module.on("disable", function() {

    });

    module.on("packet", function(event) {
        var packet = event.getPacket();
        if (packet instanceof S08PacketPlayerPosLook) {
            moduleManager.getModule("RedeLongJump").setState(false);
        }
    });

    module.on("move", function(event) {

    });

    module.on("update", function() {
        if (!mc.thePlayer.onGround) {
            air++;
        } else if (air > 3 && module.settings.dis.get()) {
            moduleManager.getModule("RedeLongJump").setState(false);
        }
        if (mc.thePlayer.onGround && (!module.settings.dis.get() || air == 0)) {
            mc.thePlayer.jump();
        }
        mc.thePlayer.jumpMovementFactor = 0.053;
        mc.thePlayer.motionY += 0.011;
    });
});