# Season 1.7.10 (Chentg) (Agent)

* 我们源码拥有的功能 : <img width="160" src="xswl.png" alt="xswl"></br>

* 现在这个版本已经开源公开


## 绕过反作弊
* [CatAntiCheat](https://github.com/Luohuayu/CatAntiCheat-Public) (all_version)
* HX:AntiCheat (private_anticheat)
* NaBanMod (HardwareID Ban)
* [Decimation](https://github.com/boehmod/DecimationRelease) (AntiScreenshot)

## 关于本注入使用:

配置:
* `gradlew setDevWorkSpace idea`

启动需要添加的jvm参数:
* `-Dfml.coreMods.load=net.minecraft.injection.ClientLoader`

释放版本(可使用版本):
* [点我下载](https://pan.baidu.com/s/1RLJYwhlp0IfJSaTmEQNm5Q)
* 提取码: `m3ts`

鸣谢:
* lss233 提供的forge下载镜像 `http://lss233.littleservice.cn/repositories/minecraft`
