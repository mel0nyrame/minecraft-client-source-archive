package Client.Dev.module.modules.render;

import Client.Dev.module.*;
import Client.Dev.api.value.*;

public class Animations extends Module
{
    public static Mode<Enum> mode;
    public static Option<Boolean> NoFire;
    public static Option<Boolean> EveryThingBlock;
    public static Numbers<Double> x;
    public static Numbers<Double> y;
    public static Numbers<Double> z;
    public static Numbers<Double> Speed;
    
    static {
        Animations.mode = new Mode<Enum>("Mode", "mode", renderMode.values(), renderMode.Swang);
        Animations.NoFire = new Option<Boolean>("NoFire", "NoFire", false);
        Animations.EveryThingBlock = new Option<Boolean>("EveryThingBlock", "EveryThingBlock", false);
        Animations.x = new Numbers<Double>("x", "x", 0.0, -1.0, 1.0, 0.1);
        Animations.y = new Numbers<Double>("y", "y", 0.0, -1.0, 1.0, 0.1);
        Animations.z = new Numbers<Double>("z", "z", 0.0, -1.0, 1.0, 0.1);
        Animations.Speed = new Numbers<Double>("Speed", "Speed", 10.0, 1.0, 50.0, 1.0);
    }
    
    public Animations() {
        super("Animations", new String[] { "BlockHitanimations" }, ModuleType.Render);
        this.addValues(Animations.mode, Animations.NoFire, Animations.x, Animations.y, Animations.z, Animations.Speed, Animations.EveryThingBlock);
        this.setEnabled(true);
    }
    
    public enum renderMode
    {
        Swang("Swang", 0), 
        Swank("Swank", 1), 
        Swing("Swing", 2), 
        Swong("Swong", 3), 
        SwAing("SwAing", 4), 
        Remix("Remix", 5), 
        Custom("Custom", 6), 
        None("None", 7), 
        Old("Old", 8), 
        Gay("Gay", 9), 
        Punch("Punch", 10), 
        rotate("rotate", 11), 
        Winter("Winter", 12), 
        circle("circle", 13);
        
        private renderMode(final String s, final int n) {
        }
    }
}
