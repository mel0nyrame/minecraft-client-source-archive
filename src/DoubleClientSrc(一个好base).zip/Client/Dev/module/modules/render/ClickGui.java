
package Client.Dev.module.modules.render;

import java.awt.Color;

import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventTick;
import Client.Dev.api.value.Numbers;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import Client.Dev.ui.clickgui.ClickUI;
import Client.Dev.utils.Wrapper;

import net.minecraft.client.Minecraft;

public class ClickGui
extends Module {
	public static boolean rainbow;
	public static int rainbowcolor;
    public ClickGui() {
        super("ClickGui", new String[]{"clickui"}, ModuleType.Render);
    }

    @Override
    public void onEnable() {
        Wrapper.mc.displayGuiScreen(new ClickUI());
//        mc.thePlayer.playSound("random.orb", 1.0f, 1.0f);
        this.setEnabled(false);
    }
    
    @EventHandler
    public void onTick(EventTick e) {
    	int rainbowTick = 0;
        Color rainbow = new Color(Color.HSBtoRGB((float)((double)Minecraft.getMinecraft().thePlayer.ticksExisted / 50.0 + Math.sin((double)rainbowTick / 50.0 * 1.6)) % 1.0f, 0.5f, 1.0f));
//        rainbowcolor = rainbow.getRGB();
        rainbowcolor = new Color(HUD.R.getValue().intValue(),( HUD.G).getValue().intValue(),HUD.B.getValue().intValue()).getRGB();
    }
}

