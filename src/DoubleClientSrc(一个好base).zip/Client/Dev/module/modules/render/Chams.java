/*
 * Decompiled with CFR 0_132.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package Client.Dev.module.modules.render;

import Client.Dev.api.EventHandler;
import Client.Dev.api.events.rendering.EventPostRenderPlayer;
import Client.Dev.api.events.rendering.EventPreRenderPlayer;
import Client.Dev.api.value.Mode;
import Client.Dev.api.value.Value;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import java.awt.Color;
import org.lwjgl.opengl.GL11;

public class Chams
extends Module {
    public Mode<Enum> mode = new Mode("Mode", "mode", (Enum[])ChamsMode.values(), (Enum)ChamsMode.Textured);

    public Chams() {
        super("Chams", new String[]{"seethru", "cham"}, ModuleType.Render);
        this.addValues(this.mode);
        this.setColor(new Color(159, 190, 192).getRGB());
    }

    @EventHandler
    private void preRenderPlayer(EventPreRenderPlayer e) {
        GL11.glEnable((int)32823);
        GL11.glPolygonOffset((float)1.0f, (float)-1100000.0f);
    }

    @EventHandler
    private void postRenderPlayer(EventPostRenderPlayer e) {
        GL11.glDisable((int)32823);
        GL11.glPolygonOffset((float)1.0f, (float)1100000.0f);
    }

    public static enum ChamsMode {
        Textured,
        Normal;
    }

}

