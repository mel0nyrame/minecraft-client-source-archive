/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.module.modules.render;

import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;

public class NoHurtCam
extends Module {
    public NoHurtCam() {
        super("No Hurt Cam", new String[]{"nohurtcam"}, ModuleType.Render);
    }
}

