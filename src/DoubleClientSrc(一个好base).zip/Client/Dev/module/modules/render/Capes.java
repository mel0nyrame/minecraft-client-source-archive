/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.module.modules.render;

import Client.Dev.Client;
import Client.Dev.api.EventHandler;
import Client.Dev.api.events.rendering.EventRenderCape;
import Client.Dev.management.FriendManager;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

public class Capes
extends Module {
    public Capes() {
        super("Capes", new String[]{"kape"}, ModuleType.Render);
        this.setColor(new Color(159, 190, 192).getRGB());
        this.setEnabled(true);
        this.setRemoved(true);
    }

    @EventHandler
    public void onRender(EventRenderCape event) {
        if (this.mc.theWorld != null && FriendManager.isFriend(event.getPlayer().getName())) {
            event.setLocation(Client.CLIENT_CAPE);
            event.setCancelled(true);
        }
    }
}

