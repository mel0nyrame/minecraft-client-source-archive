package Client.Dev.module.modules.render;

import net.minecraft.client.*;
import net.minecraft.potion.*;
import Client.Dev.module.*;
import java.awt.*;
import Client.Dev.api.events.rendering.*;
import net.minecraft.block.material.*;
import net.minecraft.block.*;
import Client.Dev.api.*;
import net.minecraft.util.*;
import Client.Dev.api.events.world.*;
import org.lwjgl.input.*;
import Client.Dev.utils.*;
import Client.Dev.module.modules.movement.*;
import Client.Dev.management.*;

public class ClickTp extends Module
{
    boolean canTP;
    boolean down;
    int TeleX;
    int TeleY;
    int TeleZ;
    
    public int Height() {
        final Minecraft mc = ClickTp.mc;
        if (Minecraft.thePlayer.isPotionActive(Potion.jump)) {
            final Minecraft mc2 = ClickTp.mc;
            return Minecraft.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1;
        }
        return 0;
    }
    
    public ClickTp() {
        super("LookTP", new String[0], ModuleType.Movement);
        this.setColor(new Color(158, 114, 243).getRGB());
    }
    
    public static Block getBlock(final int x, final int y, final int z) {
        final Minecraft mc = ClickTp.mc;
        return Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
    }
    
    public static Block getBlock(final BlockPos pos) {
        final Minecraft mc = ClickTp.mc;
        return Minecraft.theWorld.getBlockState(pos).getBlock();
    }
    
    @EventHandler
    public void EventRender3D(final EventRender3D er) {
        try {
            final int x = this.getTeleBlock().getBlockPos().getX();
            final int y = this.getTeleBlock().getBlockPos().getY();
            final int z = this.getTeleBlock().getBlockPos().getZ();
            final Block block1 = getBlock(x, y, z);
            final Block block2 = getBlock(x, y + 1, z);
            final Block block3 = getBlock(x, y + 2, z);
            final boolean blockBelow = !(block1 instanceof BlockSign) && block1.getMaterial().isSolid();
            final boolean blockLevel = !(block2 instanceof BlockSign) && block1.getMaterial().isSolid();
            final boolean blockAbove = !(block3 instanceof BlockSign) && block1.getMaterial().isSolid();
            if (getBlock(this.getTeleBlock().getBlockPos()).getMaterial() != Material.air && blockBelow && blockLevel && blockAbove && !(getBlock(this.getTeleBlock().getBlockPos()) instanceof BlockChest)) {
                this.canTP = true;
            }
            else {
                this.canTP = false;
            }
        }
        catch (Exception ex) {}
    }
    
    public Vec3 func_174824_e(final float partial) {
        if (partial == 1.0f) {
            final Minecraft mc = ClickTp.mc;
            final double posX = Minecraft.thePlayer.posX;
            final Minecraft mc2 = ClickTp.mc;
            final double posY = Minecraft.thePlayer.posY;
            final Minecraft mc3 = ClickTp.mc;
            final double y = posY + Minecraft.thePlayer.getEyeHeight();
            final Minecraft mc4 = ClickTp.mc;
            return new Vec3(posX, y, Minecraft.thePlayer.posZ);
        }
        final Minecraft mc5 = ClickTp.mc;
        final double prevPosX = Minecraft.thePlayer.prevPosX;
        final Minecraft mc6 = ClickTp.mc;
        final double posX2 = Minecraft.thePlayer.posX;
        final Minecraft mc7 = ClickTp.mc;
        final double var2 = prevPosX + (posX2 - Minecraft.thePlayer.prevPosX) * partial;
        final Minecraft mc8 = ClickTp.mc;
        final double prevPosY = Minecraft.thePlayer.prevPosY;
        final Minecraft mc9 = ClickTp.mc;
        final double posY2 = Minecraft.thePlayer.posY;
        final Minecraft mc10 = ClickTp.mc;
        final double n = prevPosY + (posY2 - Minecraft.thePlayer.prevPosY) * partial;
        final Minecraft mc11 = ClickTp.mc;
        final double var3 = n + Minecraft.thePlayer.getEyeHeight();
        final Minecraft mc12 = ClickTp.mc;
        final double prevPosZ = Minecraft.thePlayer.prevPosZ;
        final Minecraft mc13 = ClickTp.mc;
        final double posZ = Minecraft.thePlayer.posZ;
        final Minecraft mc14 = ClickTp.mc;
        final double var4 = prevPosZ + (posZ - Minecraft.thePlayer.prevPosZ) * partial;
        return new Vec3(var2, var3, var4);
    }
    
    public MovingObjectPosition getTeleBlock() {
        final Vec3 var4 = this.func_174824_e(EventRender3D.ticks);
        final Minecraft mc = ClickTp.mc;
        final Vec3 var5 = Minecraft.thePlayer.getLook(EventRender3D.ticks);
        final Vec3 var6 = var4.addVector(var5.xCoord * 70.0, var5.yCoord * 70.0, var5.zCoord * 70.0);
        final Minecraft mc2 = ClickTp.mc;
        return Minecraft.thePlayer.worldObj.rayTraceBlocks(var4, var6, false, false, true);
    }
    
    @EventHandler
    private void onUpdate(final EventPreUpdate e) {
        if (Mouse.isButtonDown(2) && !this.down) {
            this.TeleX = this.getTeleBlock().getBlockPos().getX();
            this.TeleY = this.getTeleBlock().getBlockPos().getY() + 1;
            this.TeleZ = this.getTeleBlock().getBlockPos().getZ();
            Helper.sendMessage("Teleport to X:" + this.TeleX + " Y:" + this.TeleY + " Z:" + this.TeleZ);
            TeleportMod.x = (float)this.TeleX;
            TeleportMod.y = (float)this.TeleY;
            TeleportMod.z = (float)this.TeleZ;
            ModuleManager.getModuleByClass(TeleportMod.class).setEnabled(true);
            this.down = true;
        }
        if (!Mouse.isButtonDown(2)) {
            this.down = false;
        }
    }
}
