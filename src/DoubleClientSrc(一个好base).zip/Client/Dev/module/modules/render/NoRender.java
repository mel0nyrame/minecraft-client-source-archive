/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.module.modules.render;

import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import java.awt.Color;

public class NoRender
extends Module {
    public NoRender() {
        super("NoRender", new String[]{"noitems"}, ModuleType.Render);
        this.setColor(new Color(166, 185, 123).getRGB());
    }
}

