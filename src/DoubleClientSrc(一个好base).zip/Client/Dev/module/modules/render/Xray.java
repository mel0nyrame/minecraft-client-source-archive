/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.module.modules.render;

import Client.Dev.api.EventHandler;
import Client.Dev.api.events.rendering.EventBlockRenderSide;
import Client.Dev.api.events.rendering.EventRender2D;
import Client.Dev.api.events.rendering.EventRender3D;
import Client.Dev.api.events.rendering.EventRenderBlock;
import Client.Dev.api.value.Numbers;
import Client.Dev.api.value.Option;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import Client.Dev.utils.XrayBlock;
import Client.Dev.utils.math.RotationUtil;
import Client.Dev.utils.math.Vec4f;
import Client.Dev.utils.render.GLUProjection;
import Client.Dev.utils.render.RenderUtil;
import com.google.common.collect.Lists;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockOre;
import net.minecraft.block.BlockRedstoneOre;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import optifine.Config;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.vecmath.Vector3d;

import org.lwjgl.opengl.GL11;

public class Xray
        extends Module {
	public Xray() {
		super("Xray",new String[] {}, ModuleType.Render);
		blocks.add(14);
		blocks.add(15);
		blocks.add(16);
		blocks.add(21);
		blocks.add(56);
		blocks.add(73);
		blocks.add(129);
		blocks.add(133);
		blocks.add(57);
		blocks.add(41);
		blocks.add(42);
		blocks.add(173);
		blocks.add(152);
		// TODO Auto-generated constructor stub
	}

	public static final HashSet<Integer> blockIDs = new HashSet();
	public List<Integer> blocks = new ArrayList<Integer>();
	private int opacity = 160;
	public java.util.List<Integer> KEY_IDS = com.google.common.collect.Lists.newArrayList(new Integer[] {
			Integer.valueOf(10), Integer.valueOf(11), Integer.valueOf(8), Integer.valueOf(9), Integer.valueOf(14),
			Integer.valueOf(15), Integer.valueOf(16), Integer.valueOf(21), Integer.valueOf(41), Integer.valueOf(42),
			Integer.valueOf(46), Integer.valueOf(48), Integer.valueOf(52), Integer.valueOf(56), Integer.valueOf(57),
			Integer.valueOf(61), Integer.valueOf(62), Integer.valueOf(73), Integer.valueOf(74), Integer.valueOf(84),
			Integer.valueOf(89), Integer.valueOf(103), Integer.valueOf(116), Integer.valueOf(117), Integer.valueOf(118),
			Integer.valueOf(120), Integer.valueOf(129), Integer.valueOf(133), Integer.valueOf(137),
			Integer.valueOf(145), Integer.valueOf(152), Integer.valueOf(153), Integer.valueOf(154) });


	public List<Integer> getBlocks() {
		return this.blocks;
	}

	public CopyOnWriteArrayList list = new CopyOnWriteArrayList<>();

	@Override
	public void onEnable() {
		blockIDs.clear();
		System.out.println(Block.getBlockById(10).toString());
		super.onEnable();
		this.opacity = 200;
		try {
			for (Integer o : this.KEY_IDS) {
				blockIDs.add(o);
			}
			Minecraft.getMinecraft().renderGlobal.loadRenderers();
		} catch (Exception e) {
			e.printStackTrace();
		}
		mc.renderGlobal.loadRenderers();
	}

	@Override
	public void onDisable() {
		super.onDisable();
		mc.renderGlobal.loadRenderers();
		this.list.clear();

	}

	@EventHandler
	public void onEvent(EventRender3D event) {
		Iterator x = list.iterator();

		while (x.hasNext()) {
			XrayBlock x1 = (XrayBlock) x.next();
			if (x1.type.contains("Diamond"))
				RenderUtil.drawblock(x1.x - mc.getRenderManager().viewerPosX, x1.y - mc.getRenderManager().viewerPosY,
						x1.z - mc.getRenderManager().viewerPosZ, getColor(55, 155, 255),
						new Color(55, 155, 255).getRGB(), 0.1f);
			else if (x1.type.contains("Iron"))
				RenderUtil.drawblock(x1.x - mc.getRenderManager().viewerPosX, x1.y - mc.getRenderManager().viewerPosY,
						x1.z - mc.getRenderManager().viewerPosZ, getColor(180, 180, 180),
						new Color(180, 180, 180).getRGB(), 0.1f);
			else if (x1.type.contains("Gold"))
				RenderUtil.drawblock(x1.x - mc.getRenderManager().viewerPosX, x1.y - mc.getRenderManager().viewerPosY,
						x1.z - mc.getRenderManager().viewerPosZ, getColor(255, 255, 120), new Color(255, 255, 120).getRGB(),
						0.1f);
			else if (x1.type.contains("Red")) {
				RenderUtil.drawblock(x1.x - mc.getRenderManager().viewerPosX, x1.y - mc.getRenderManager().viewerPosY,
						x1.z - mc.getRenderManager().viewerPosZ, getColor(255, 50, 50), new Color(255, 50, 50).getRGB(),
						0.1f);
			} else {
				RenderUtil.drawblock(x1.x - mc.getRenderManager().viewerPosX, x1.y - mc.getRenderManager().viewerPosY,
						x1.z - mc.getRenderManager().viewerPosZ, getColor(50, 50, 50), new Color(50,50,50).getRGB(), 0.1f);
			}

		}
	}

	@EventHandler
	public void onEvent(EventBlockRenderSide e) {
		if ((e.getSide() == EnumFacing.DOWN && e.minY > 0.0D ? true
				: (e.getSide() == EnumFacing.UP && e.maxY < 1.0D ? true
						: (e.getSide() == EnumFacing.NORTH && e.minZ > 0.0D ? true
								: (e.getSide() == EnumFacing.SOUTH && e.maxZ < 1.0D ? true
										: (e.getSide() == EnumFacing.WEST && e.minX > 0.0D ? true
												: (e.getSide() == EnumFacing.EAST && e.maxX < 1.0D ? true
														: !e.getWorld().getBlockState(e.pos).getBlock()
																.isOpaqueCube()))))))) {
			if (mc.theWorld.getBlockState(e.getPos().offset(e.getSide(), -1)).getBlock() instanceof BlockOre
					|| mc.theWorld.getBlockState(e.getPos().offset(e.getSide(), -1))
							.getBlock() instanceof BlockRedstoneOre) {

				final float xDiff = (float) (mc.thePlayer.posX - e.pos.getX());
				final float yDiff = 0;
				final float zDiff = (float) (mc.thePlayer.posZ - e.pos.getZ());
				float dis = MathHelper.sqrt_float(xDiff * xDiff + yDiff * yDiff + zDiff * zDiff);
				if (dis > 50)
					return;
				XrayBlock x = new XrayBlock(Math.round(e.pos.offset(e.getSide(), -1).getZ()),
						Math.round(e.pos.offset(e.getSide(), -1).getY()),
						Math.round(e.pos.offset(e.getSide(), -1).getX()),
						mc.theWorld.getBlockState(e.pos.offset(e.getSide(), -1)).getBlock().getUnlocalizedName());
				if (!list.contains(x))
					list.add(x);
			}
		}
	}

	public static int getColor(int red, int green, int blue) {
		return getColor(red, green, blue, 255);
	}

	public static int getColor(int red, int green, int blue, int alpha) {
		int color = 0;
		color |= alpha << 24;
		color |= red << 16;
		color |= green << 8;
		color |= blue;
		return color;
	}

	private static float getSize(double x, double y, double z) {
		return (float) (mc.thePlayer.getDistance(x, y, z)) / 4.0f <= 2.0f ? 2.0f
				: (float) (mc.thePlayer.getDistance(x, y, z)) / 4.0f;
	}

	private static void startDrawing(double x, double y, double z, double StringX, double StringY, double StringZ) {
		float var10001 = mc.gameSettings.thirdPersonView == 2 ? -1.0f : 1.0f;
		double size = Config.zoomMode ? (double) (getSize(StringX, StringY, StringZ) / 10.0f) * 1.6
				: (double) (getSize(StringX, StringY, StringZ) / 10.0f) * 4.8;
		GL11.glPushMatrix();
//		RenderUtil.startDrawing();
		GL11.glTranslatef((float) x, (float) y, (float) z);
		GL11.glNormal3f((float) 0.0f, (float) 1.0f, (float) 0.0f);
		GL11.glRotatef((float) (-mc.getRenderManager().playerViewY), (float) 0.0f, (float) 1.0f, (float) 0.0f);
		GL11.glRotatef((float) mc.getRenderManager().playerViewX, (float) var10001, (float) 0.0f, (float) 0.0f);
		GL11.glScaled((double) (-0.01666666753590107 * size), (double) (-0.01666666753590107 * size),
				(double) (0.01666666753590107 * size));
	}

	private static void drawNames(String Str, int Color) {
		float xP = 2.2f;
		float width = (float) getWidth(Str) / 2.0f + xP;
		float w = width = (float) ((double) width + 2.5);
		float nw = -width - xP;
		float offset = getWidth(Str) + 4;
		RenderUtil.drawBorderedRect(nw + 6.0f, -1.0f, width, 10.0f, 1.0f, new Color(20, 20, 20, 0).getRGB(),
				new Color(10, 10, 10, 200).getRGB());
		GlStateManager.disableDepth();
		drawString(Str, w - offset + 2, 0.0f, Color);
		GlStateManager.enableDepth();
	}

	private static void drawString(String text, float x, float y, int color) {
		mc.fontRendererObj.drawStringWithShadow(text, x, y, color);
	}

	private static int getWidth(String text) {
		return mc.fontRendererObj.getStringWidth(text);
	}

	private static void stopDrawing() {
//		RenderUtil.stopDrawing();
		GlStateManager.color(1.0f, 1.0f, 1.0f);
		GlStateManager.popMatrix();
	}

	public static void rendertag(String Str, double x, double y, double z, double StringX, double StringY,
			double StringZ, int color) {
		y = (float) ((double) y + 1.55);
		startDrawing(x, y, z, StringX, StringY, StringZ);
		drawNames(Str, color);
		GL11.glColor4d((double) 1.0, (double) 1.0, (double) 1.0, (double) 1.0);
		stopDrawing();
	}
}