package Client.Dev.module.modules.world;

import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventPacketRecieve;
import Client.Dev.api.events.world.EventPacketSend;
import Client.Dev.api.value.Option;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import Client.Dev.utils.Helper;

public class DevModule extends Module {

    public Option<Boolean> packetSend = new Option<Boolean>("packetSend","packetSend", false);
    public Option<Boolean> packetRecieve = new Option<Boolean>("packetRecieve","packetRecieve", false);

    public DevModule() {
		super("DevModule", new String[] { "Dev" }, ModuleType.World);
        addValues(packetSend,packetRecieve);
    }

    @EventHandler
    public void onPacketSend(EventPacketSend event){
        if(!packetSend.getValue())
            return;

        Helper.sendMessage("��6[DEV] PacketSend: " + event.getPacket());
    }

    @EventHandler
    public void onPacketSend(EventPacketRecieve event){
        if(!packetRecieve.getValue())
            return;

        Helper.sendMessage("��6[DEV] PacketRecieve " + event.getPacket());
    }
}
