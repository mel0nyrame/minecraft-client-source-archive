package Client.Dev.module.modules.world;

import Client.Dev.module.*;
import Client.Dev.api.value.*;
import Client.Dev.api.events.misc.*;
import net.minecraft.client.*;
import java.util.*;
import Client.Dev.api.*;
import java.io.*;
import Client.Dev.api.events.rendering.*;
import net.minecraft.client.gui.*;
import java.awt.*;
import Client.Dev.utils.*;
import Client.Dev.ui.font.*;
import Client.Dev.api.events.world.*;

public class AutoGG extends Module
{
    public boolean play;
    private Timer timer;
    private Mode<Enum> AutoJoinMode;
    private Mode<Enum> MusicKitMode;
    private Mode<Enum> mode;
    public static Option<Boolean> AutoJoin;
    private Numbers<Double> delay;
    public static Option<Boolean> ReJoin;
    public static Option<Boolean> Message;
    public static Option<Boolean> Prefix;
    public static Option<Boolean> AD;
    public static Option<Boolean> All;
    int a;
    
    static {
        AutoGG.AutoJoin = new Option<Boolean>("AutoPlay", "AutoPlay", true);
        AutoGG.ReJoin = new Option<Boolean>("AutoReJoin", "AutoReJoin", true);
        AutoGG.Message = new Option<Boolean>("Message", "Message", true);
        AutoGG.Prefix = new Option<Boolean>("Prefix", "Prefix", true);
        AutoGG.AD = new Option<Boolean>("AD", "AD", true);
        AutoGG.All = new Option<Boolean>("All", "All", false);
    }
    
    public AutoGG() {
        super("Auto GG", new String[] { "AutoGG", "AutoPlay", "AutoGG&AutoPlay" }, ModuleType.Player);
        this.play = false;
        this.timer = new Timer();
        this.AutoJoinMode = new Mode<Enum>("AutoJoinMode", "AutoJoinMode", AutoPlayMode.values(), AutoPlayMode.BedWars_1v1);
        this.MusicKitMode = new Mode<Enum>("MusicKitMode", "MusicKitMode", MusicKit.values(), MusicKit.FrameOfMind);
        this.mode = new Mode<Enum>("Mode", "Mode", Server.values(), Server.Public);
        this.delay = new Numbers<Double>("AutoPlayDelay", "AutoPlayDelay", 3.0, 0.0, 10.0, 1.0);
        this.a = 0;
        this.addValues(this.AutoJoinMode, this.MusicKitMode, this.mode, AutoGG.AutoJoin, this.delay, AutoGG.ReJoin, AutoGG.Message, AutoGG.Prefix, AutoGG.AD, AutoGG.All);
    }
    
    @EventHandler
    public void onChat(final EventChat e) {
        if (this.mode.getValue() == Server.Hypixel && e.getMessage().contains("\u4f60\u7684\u7f51\u7edc\u8fde\u63a5\u51fa\u73b0\u5c0f\u95ee\u9898") && AutoGG.ReJoin.getValue()) {
            final Minecraft mc = AutoGG.mc;
            Minecraft.thePlayer.sendChatMessage("/rejoin");
        }
        if ((this.mode.getValue() == Server.Hypixel && e.getMessage().contains("\u80dc\u5229\u8005")) || e.getMessage().contains("\u041f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044c") || e.getMessage().contains("\u512a\u52dd\u8005") || e.getMessage().toLowerCase().contains("winner") || e.getMessage().contains("\u80dc\u8005") || e.getMessage().contains("\u041f\u041e\u0411\u0415\u0414\u0418\u0422\u0415\u041b\u042c")) {
            if (AutoGG.Message.getValue()) {
                Minecraft.thePlayer.sendChatMessage(String.valueOf(AutoGG.Prefix.getValue() ? new StringBuilder("[").append("Double").append("]").toString() : "") + " GG " + (AutoGG.AD.getValue() ? " Double Client is best copy client" : ""));
            }
            if (AutoGG.AutoJoin.getValue()) {
                this.play = true;
                this.timer.schedule(new TimerTask() {
                    @Override
                    public void run() {
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.BedWars_1v1) {
                            Minecraft.thePlayer.sendChatMessage("/play bedwars_eight_one");
                        }
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.BedWars_2v2) {
                            Minecraft.thePlayer.sendChatMessage("/play bedwars_eight_two");
                        }
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.BedWars_3v3) {
                            Minecraft.thePlayer.sendChatMessage("/play bedwars_four_three");
                        }
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.BedWars_4v4) {
                            Minecraft.thePlayer.sendChatMessage("/play bedwars_four_four");
                        }
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SkyWars_Solo) {
                            Minecraft.thePlayer.sendChatMessage("/play solo_normal");
                        }
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SkyWars_Solo_Insane) {
                            Minecraft.thePlayer.sendChatMessage("/play solo_insane");
                        }
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SkyWars_Solo_LuckyBlock) {
                            Minecraft.thePlayer.sendChatMessage("/play solo_insane_lucky");
                        }
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SkyWars_Team) {
                            Minecraft.thePlayer.sendChatMessage("/play teams_normal");
                        }
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SkyWars_Team_Insane) {
                            Minecraft.thePlayer.sendChatMessage("/play teams_insane");
                        }
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SkyWars_Team_LuckyBlock) {
                            Minecraft.thePlayer.sendChatMessage("/play teams_insane_lucky");
                        }
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SurivialGames_Solo) {
                            Minecraft.thePlayer.sendChatMessage("/play blitz_solo_normal");
                        }
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SurivialGames_Solo) {
                            Minecraft.thePlayer.sendChatMessage("/play blitz_teams_normal");
                        }
                        if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.MiniWalls) {
                            Minecraft.thePlayer.sendChatMessage("/play arcade_mini_walls");
                        }
                        AutoGG.this.play = false;
                    }
                }, this.delay.getValue().longValue() * 10L * 100L);
            }
        }
        if (this.mode.getValue() == Server.HuaYuTing && e.getMessage().contains("\u83b7\u5f97\u80dc\u5229!") && AutoGG.Message.getValue()) {
            Minecraft.thePlayer.sendChatMessage(String.valueOf(AutoGG.Prefix.getValue() ? new StringBuilder("[").append("Double").append("]").toString() : "") + " GG " + (AutoGG.AD.getValue() ? " 购买Double客户端加 君羊 ：1077028467" : ""));
        }
        Label_0842: {
            if (this.mode.getValue() == Server.OtherPVP) {
                final String message = e.getMessage();
                final StringBuilder sb = new StringBuilder("\u80dc\u5229\u8005 ��e");
                final Minecraft mc2 = AutoGG.mc;
                if (!message.contains(sb.append(Minecraft.thePlayer.getName()).toString())) {
                    final String message2 = e.getMessage();
                    final StringBuilder sb2 = new StringBuilder("Win ��e");
                    final Minecraft mc3 = AutoGG.mc;
                    if (!message2.contains(sb2.append(Minecraft.thePlayer.getName()).toString())) {
                        final String message3 = e.getMessage();
                        final StringBuilder sb3 = new StringBuilder("\u80dc\u5229\u8005 ��4");
                        final Minecraft mc4 = AutoGG.mc;
                        if (!message3.contains(sb3.append(Minecraft.thePlayer.getName()).toString())) {
                            final String message4 = e.getMessage();
                            final StringBuilder sb4 = new StringBuilder("Win ��4");
                            final Minecraft mc5 = AutoGG.mc;
                            if (!message4.contains(sb4.append(Minecraft.thePlayer.getName()).toString())) {
                                final String message5 = e.getMessage();
                                final StringBuilder sb5 = new StringBuilder("\u80dc\u5229\u8005 ");
                                final Minecraft mc6 = AutoGG.mc;
                                if (!message5.contains(sb5.append(Minecraft.thePlayer.getName()).toString())) {
                                    final String message6 = e.getMessage();
                                    final StringBuilder sb6 = new StringBuilder("Win ");
                                    final Minecraft mc7 = AutoGG.mc;
                                    if (!message6.contains(sb6.append(Minecraft.thePlayer.getName()).toString())) {
                                        final String message7 = e.getMessage();
                                        final StringBuilder sb7 = new StringBuilder("\u80dc\u5229\u8005 ��a");
                                        final Minecraft mc8 = AutoGG.mc;
                                        if (!message7.contains(sb7.append(Minecraft.thePlayer.getName()).toString())) {
                                            final String message8 = e.getMessage();
                                            final StringBuilder sb8 = new StringBuilder("Win ��a");
                                            final Minecraft mc9 = AutoGG.mc;
                                            if (!message8.contains(sb8.append(Minecraft.thePlayer.getName()).toString())) {
                                                break Label_0842;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (AutoGG.Message.getValue()) {
                    Minecraft.thePlayer.sendChatMessage(String.valueOf(AutoGG.Prefix.getValue() ? new StringBuilder("[").append("Double").append("]").toString() : "") + " GG " + (AutoGG.AD.getValue() ? " Double Client is best copy client" : ""));
                }
            }
        }
        if ((this.mode.getValue() == Server.Hypixel && e.getMessage().contains("\u4f60\u6b7b\u4e86")) || e.getMessage().contains("\u6b7b\u3093\u3067\u3057\u307e\u3063\u305f") || e.getMessage().contains("\u0412\u044b \u0443\u043c\u0435\u0440\u043b\u0438") || (e.getMessage().contains("You died") && AutoGG.AutoJoin.getValue())) {
            this.play = true;
            this.timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.BedWars_1v1) {
                        Minecraft.thePlayer.sendChatMessage("/play bedwars_eight_one");
                    }
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.BedWars_2v2) {
                        Minecraft.thePlayer.sendChatMessage("/play bedwars_eight_two");
                    }
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.BedWars_3v3) {
                        Minecraft.thePlayer.sendChatMessage("/play bedwars_four_three");
                    }
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.BedWars_4v4) {
                        Minecraft.thePlayer.sendChatMessage("/play bedwars_four_four");
                    }
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SkyWars_Solo) {
                        Minecraft.thePlayer.sendChatMessage("/play solo_normal");
                    }
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SkyWars_Solo_Insane) {
                        Minecraft.thePlayer.sendChatMessage("/play solo_insane");
                    }
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SkyWars_Solo_LuckyBlock) {
                        Minecraft.thePlayer.sendChatMessage("/play solo_insane_lucky");
                    }
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SkyWars_Team) {
                        Minecraft.thePlayer.sendChatMessage("/play teams_normal");
                    }
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SkyWars_Team_Insane) {
                        Minecraft.thePlayer.sendChatMessage("/play teams_insane");
                    }
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SkyWars_Team_LuckyBlock) {
                        Minecraft.thePlayer.sendChatMessage("/play teams_insane_lucky");
                    }
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SurivialGames_Solo) {
                        Minecraft.thePlayer.sendChatMessage("/play blitz_solo_normal");
                    }
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.SurivialGames_Solo) {
                        Minecraft.thePlayer.sendChatMessage("/play blitz_teams_normal");
                    }
                    if (AutoGG.this.AutoJoinMode.getValue() == AutoPlayMode.MiniWalls) {
                        Minecraft.thePlayer.sendChatMessage("/play arcade_mini_walls");
                    }
                    AutoGG.this.play = false;
                }
            }, this.delay.getValue().longValue() * 10L * 100L);
        }
    }
    
    @EventHandler
    public void onChat3(final EventChat e) throws IOException {
        if ((e.getMessage().contains("\u80dc\u5229\u8005") || e.getMessage().contains("\u041f\u043e\u0431\u0435\u0434\u0438\u0442\u0435\u043b\u044c") || e.getMessage().contains("\u512a\u52dd\u8005") || e.getMessage().toLowerCase().contains("winner") || e.getMessage().contains("\u80dc\u8005") || e.getMessage().contains("\u041f\u041e\u0411\u0415\u0414\u0418\u0422\u0415\u041b\u042c")) && this.mode.getValue() == Server.Public && AutoGG.Message.getValue()) {
            Minecraft.thePlayer.sendChatMessage(String.valueOf(AutoGG.Prefix.getValue() ? new StringBuilder("[").append("Double").append("]").toString() : "") + " GG " + (AutoGG.AD.getValue() ? " Double Client is best copy Client" : ""));
        }
    }
    
    @EventHandler
    public void onRender2D(final EventRender2D event) {
        if (this.play) {
            final ScaledResolution sr = new ScaledResolution(AutoGG.mc);
            RenderUtils.drawRoundedRect((float)(ScaledResolution.getScaledWidth() / 2 - 80), -3.0f, (float)(ScaledResolution.getScaledWidth() / 2 + 80), (float)this.a, 2.0f, new Color(255, 255, 255, 255).getRGB());
            FontLoaders.kiona18.drawString("Close to join with " + this.delay.getValue().intValue() + "s", (float)(ScaledResolution.getScaledWidth() / 2 - FontLoaders.kiona18.getStringWidth("Close to join with " + this.delay.getValue().intValue() + "s") + 20), (float)(this.a - 14), new Color(150, 150, 150).getRGB());
            if (this.a < 20) {
                this.a += 2;
            }
        }
    }
    
    @EventHandler
    public void onUpdate(final EventPreUpdate e) {
        this.setSuffix(this.mode.getValue());
    }
    
    @Override
    public void onDisable() {
        this.play = false;
        this.a = 0;
    }
    
    enum AutoPlayMode
    {
        BedWars_1v1("BedWars_1v1", 0), 
        BedWars_2v2("BedWars_2v2", 1), 
        BedWars_3v3("BedWars_3v3", 2), 
        BedWars_4v4("BedWars_4v4", 3), 
        SkyWars_Solo("SkyWars_Solo", 4), 
        SkyWars_Solo_Insane("SkyWars_Solo_Insane", 5), 
        SkyWars_Solo_LuckyBlock("SkyWars_Solo_LuckyBlock", 6), 
        SkyWars_Team("SkyWars_Team", 7), 
        SkyWars_Team_Insane("SkyWars_Team_Insane", 8), 
        SkyWars_Team_LuckyBlock("SkyWars_Team_LuckyBlock", 9), 
        SurivialGames_Solo("SurivialGames_Solo", 10), 
        SurivialGames_Team("SurivialGames_Team", 11), 
        MiniWalls("MiniWalls", 12);
        
        private AutoPlayMode(final String s, final int n) {
        }
    }
    
    enum MusicKit
    {
        FrameOfMind("FrameOfMind", 0), 
        Bodacious("Bodacious", 1), 
        EyeDragon("EyeDragon", 2), 
        BlackHuman("BlackHuman", 3);
        
        private MusicKit(final String s, final int n) {
        }
    }
    
    enum Server
    {
        Hypixel("Hypixel", 0), 
        HuaYuTing("HuaYuTing", 1), 
        OtherPVP("OtherPVP", 2), 
        Public("Public", 3);
        
        private Server(final String s, final int n) {
        }
    }
}
