package Client.Dev.module.modules.world;

import Client.Dev.module.*;
import java.awt.*;
import Client.Dev.api.value.*;
import net.minecraft.client.*;
import net.minecraft.network.play.client.*;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.network.*;
import net.minecraft.client.entity.*;
import Client.Dev.Client;
import Client.Dev.api.*;
import Client.Dev.api.events.world.*;
import Client.Dev.utils.*;


public class AntiFall extends Module {
	private TimerUtil timer = new TimerUtil();
	private boolean saveMe;
	public static Numbers<Double> distance = new Numbers<Double>("Distance", "Distance", 5.0, 4.0, 10.0, 1.0);
	public static Option<Boolean> Void = new Option<Boolean>("Void", "Void", true);

	public AntiFall() {
		super("AntiFall", new String[] { "novoid", "antifall" }, ModuleType.Movement);
		this.addValues(this.distance, this.Void);
	}

	@EventHandler
	private void onUpdate(EventMove e) {
		if ((saveMe && timer.delay(150)) || mc.thePlayer.isCollidedVertically) {
			saveMe = false;
			timer.reset();
		}
		int dist = this.distance.getValue().intValue();
		if (mc.thePlayer.fallDistance > dist && !Client.getModuleManager().getModuleByName("Fly").isEnabled()) {
			if (!((Boolean) this.Void.getValue()) || !isBlockUnder()) {
				if (!saveMe) {
					saveMe = true;
					timer.reset();
				}
				mc.thePlayer.fallDistance = 0;
				//System.out.println("hello world");
				mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX,
						mc.thePlayer.posY + 12, mc.thePlayer.posZ, false));
			}
		}
	}

	private boolean isBlockUnder() {
		if (mc.thePlayer.posY < 0)
			return false;
		for (int off = 0; off < (int) mc.thePlayer.posY + 2; off += 2) {
			AxisAlignedBB bb = mc.thePlayer.boundingBox.offset(0, -off, 0);
			if (!mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, bb).isEmpty()) {
				return true;
			}
		}
		return false;
	}

}
