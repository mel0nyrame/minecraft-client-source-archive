package Client.Dev.module.modules.world;

import Client.Dev.Client;
import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventPacketSend;
import Client.Dev.api.events.world.EventPostUpdate;
import Client.Dev.api.events.world.EventPreUpdate;
import Client.Dev.api.value.Mode;
import Client.Dev.api.value.Numbers;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import Client.Dev.utils.BlockUtil;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;

import java.awt.*;

public class SpeedMine extends Module {
	private boolean bzs = false;
    private float bzx = 0.0f;
    public BlockPos blockPos;
    public EnumFacing facing;
	
	public SpeedMine() {
		super("SpeedMine", new String[] {"fastbreak","fastdig"}, ModuleType.World);
		
	}
	
	@EventHandler
	public void onPre(EventPreUpdate e) {
		if (mc.playerController.extendedReach()) {
            mc.playerController.blockHitDelay = 0;
        } else if (this.bzs) {
            Block block = this.mc.theWorld.getBlockState(this.blockPos).getBlock();
            this.bzx += (float)((double)block.getPlayerRelativeBlockHardness(mc.thePlayer, this.mc.theWorld, this.blockPos) * 1.4);
            if (this.bzx >= 1.0f) {
                this.mc.theWorld.setBlockState(this.blockPos, Blocks.air.getDefaultState(), 11);
                mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.blockPos, this.facing));
                this.bzx = 0.0f;
                this.bzs = false;
            }
        }
	}
	
//	@EventHandler
//	public void onUpdate(EventPostUpdate e) {
//		mc.playerController.blockHitDelay = 0;
//		BlockPos blockpos = this.mc.objectMouseOver.getBlockPos();
//			BlockPos tempPos;
//			
//			if(mc.gameSettings.keyBindAttack.pressed && mc.objectMouseOver.typeOfHit.equals(MovingObjectPosition.MovingObjectType.BLOCK)) {
//				mc.thePlayer.swingItem();
//				if (mc.playerController.curBlockDamageMP >= 0.3) {
//					mc.playerController.curBlockDamageMP = 1F;
//					this.mc.theWorld.setBlockState(blockPos, Blocks.air.getDefaultState(), 11);
//					mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C07PacketPlayerDigging(
//							C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, blockPos, this.facing));
//				}
//				
//			}
//		}
	
	@EventHandler
	public final void onSendPacket(EventPacketSend event) {
		if (event.getPacket() instanceof C07PacketPlayerDigging && !mc.playerController.extendedReach() && mc.playerController != null) {
            C07PacketPlayerDigging c07PacketPlayerDigging = (C07PacketPlayerDigging)event.getPacket();
            if (c07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                this.bzs = true;
                this.blockPos = c07PacketPlayerDigging.getPosition();
                this.facing = c07PacketPlayerDigging.getFacing();
                this.bzx = 0.0f;
            } else if (c07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK || c07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
                this.bzs = false;
                this.blockPos = null;
                this.facing = null;
            }
        }
	}
	
	public Block getBlock(double posX, double posY, double posZ) {
		BlockPos pos = new BlockPos((int) posX, (int) posY, (int) posZ);
		return mc.theWorld.getChunkFromBlockCoords(pos).getBlock(pos);
	}
	}

	
