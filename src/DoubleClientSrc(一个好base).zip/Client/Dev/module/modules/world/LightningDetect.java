/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.module.modules.world;

import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventMove;
import Client.Dev.api.events.world.EventPacketRecieve;
import Client.Dev.api.events.world.EventPreUpdate;
import Client.Dev.api.events.world.EventTick;
import Client.Dev.api.value.Mode;
import Client.Dev.api.value.Numbers;
import Client.Dev.api.value.Option;
import Client.Dev.management.ModuleManager;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import javax.vecmath.Vector3d;
import javax.vecmath.Vector4d;

import Client.Dev.module.modules.movement.Flight;
import Client.Dev.utils.Helper;
import Client.Dev.utils.TimerUtil;
import Client.Dev.utils.render.ColorUtils;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.server.S03PacketTimeUpdate;
import net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity;
import net.minecraft.util.AxisAlignedBB;

public class LightningDetect extends Module {
    public LightningDetect() {
        super("LightningCheck", new String[] { "lightning", "ld"}, ModuleType.World);
        setColor(new Color(223, 233, 233).getRGB());
    }
	
    @EventHandler
    public void onPacketReceive(EventPacketRecieve packetEvent) {
       if(packetEvent.getPacket() instanceof S2CPacketSpawnGlobalEntity) {
          S2CPacketSpawnGlobalEntity packetIn = (S2CPacketSpawnGlobalEntity)packetEvent.getPacket();
          if(packetIn.func_149053_g() == 1) {
             int x = (int)((double)packetIn.func_149051_d() / 32.0D);
             int y = (int)((double)packetIn.func_149050_e() / 32.0D);
             int z = (int)((double)packetIn.func_149049_f() / 32.0D);
             Helper.sendMessageWithoutPrefix("\u00a7bDetected Lightning ! \u00a7a X : \u00a77" + x + " \u00a7a, Y : \u00a77" + y + " \u00a7a, Z : \u00a77" + z);
          }
       }

    }
}