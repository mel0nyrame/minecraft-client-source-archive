package Client.Dev.module.modules.player;

import Client.Dev.module.*;
import java.awt.*;
import Client.Dev.api.events.world.*;
import net.minecraft.client.*;
import net.minecraft.block.*;
import net.minecraft.util.*;
import Client.Dev.api.*;
import net.minecraft.item.*;

public class AntiObby extends Module
{
    public AntiObby() {
        super("AntiObby", new String[] { "antiobby", "antiob" }, ModuleType.Player);
        this.setColor(new Color(AntiObby.random.nextInt(255), AntiObby.random.nextInt(255), AntiObby.random.nextInt(255)).getRGB());
    }
    
    @EventHandler
    public void onTick(final EventTick e) {
        final Minecraft mc = AntiObby.mc;
        final double posX = Minecraft.thePlayer.posX;
        final Minecraft mc2 = AntiObby.mc;
        final double y = Minecraft.thePlayer.posY + 3.0;
        final Minecraft mc3 = AntiObby.mc;
        final BlockPos sand = new BlockPos(new Vec3(posX, y, Minecraft.thePlayer.posZ));
        final Minecraft mc4 = AntiObby.mc;
        final Block sandblock = Minecraft.theWorld.getBlockState(sand).getBlock();
        final Minecraft mc5 = AntiObby.mc;
        final double posX2 = Minecraft.thePlayer.posX;
        final Minecraft mc6 = AntiObby.mc;
        final double y2 = Minecraft.thePlayer.posY + 2.0;
        final Minecraft mc7 = AntiObby.mc;
        final BlockPos forge = new BlockPos(new Vec3(posX2, y2, Minecraft.thePlayer.posZ));
        final Minecraft mc8 = AntiObby.mc;
        final Block forgeblock = Minecraft.theWorld.getBlockState(forge).getBlock();
        final Minecraft mc9 = AntiObby.mc;
        final double posX3 = Minecraft.thePlayer.posX;
        final Minecraft mc10 = AntiObby.mc;
        final double y3 = Minecraft.thePlayer.posY + 1.0;
        final Minecraft mc11 = AntiObby.mc;
        final BlockPos obsidianpos = new BlockPos(new Vec3(posX3, y3, Minecraft.thePlayer.posZ));
        final Minecraft mc12 = AntiObby.mc;
        final Block obsidianblock = Minecraft.theWorld.getBlockState(obsidianpos).getBlock();
        if (obsidianblock == Block.getBlockById(49)) {
            this.bestTool(AntiObby.mc.objectMouseOver.getBlockPos().getX(), AntiObby.mc.objectMouseOver.getBlockPos().getY(), AntiObby.mc.objectMouseOver.getBlockPos().getZ());
            final Minecraft mc13 = AntiObby.mc;
            final double posX4 = Minecraft.thePlayer.posX;
            final Minecraft mc14 = AntiObby.mc;
            final double y4 = Minecraft.thePlayer.posY - 1.0;
            final Minecraft mc15 = AntiObby.mc;
            final BlockPos downpos = new BlockPos(new Vec3(posX4, y4, Minecraft.thePlayer.posZ));
            final Minecraft mc16 = AntiObby.mc;
            Minecraft.playerController.onPlayerDamageBlock(downpos, EnumFacing.UP);
        }
        if (forgeblock == Block.getBlockById(61)) {
            this.bestTool(AntiObby.mc.objectMouseOver.getBlockPos().getX(), AntiObby.mc.objectMouseOver.getBlockPos().getY(), AntiObby.mc.objectMouseOver.getBlockPos().getZ());
            final Minecraft mc17 = AntiObby.mc;
            final double posX5 = Minecraft.thePlayer.posX;
            final Minecraft mc18 = AntiObby.mc;
            final double y5 = Minecraft.thePlayer.posY - 1.0;
            final Minecraft mc19 = AntiObby.mc;
            final BlockPos downpos = new BlockPos(new Vec3(posX5, y5, Minecraft.thePlayer.posZ));
            final Minecraft mc20 = AntiObby.mc;
            Minecraft.playerController.onPlayerDamageBlock(downpos, EnumFacing.UP);
        }
        if (sandblock == Block.getBlockById(12) || sandblock == Block.getBlockById(13)) {
            this.bestTool(AntiObby.mc.objectMouseOver.getBlockPos().getX(), AntiObby.mc.objectMouseOver.getBlockPos().getY(), AntiObby.mc.objectMouseOver.getBlockPos().getZ());
            final Minecraft mc21 = AntiObby.mc;
            final double posX6 = Minecraft.thePlayer.posX;
            final Minecraft mc22 = AntiObby.mc;
            final double y6 = Minecraft.thePlayer.posY + 3.0;
            final Minecraft mc23 = AntiObby.mc;
            final BlockPos downpos = new BlockPos(new Vec3(posX6, y6, Minecraft.thePlayer.posZ));
            final Minecraft mc24 = AntiObby.mc;
            Minecraft.playerController.onPlayerDamageBlock(downpos, EnumFacing.UP);
        }
    }
    
    public void bestTool(final int x, final int y, final int z) {
        final Minecraft mc = AntiObby.mc;
        final int blockId = Block.getIdFromBlock(Minecraft.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock());
        int bestSlot = 0;
        float f = -1.0f;
        for (int i1 = 36; i1 < 45; ++i1) {
            try {
                final Minecraft mc2 = AntiObby.mc;
                final ItemStack curSlot = Minecraft.thePlayer.inventoryContainer.getSlot(i1).getStack();
                if ((curSlot.getItem() instanceof ItemTool || curSlot.getItem() instanceof ItemSword || curSlot.getItem() instanceof ItemShears) && curSlot.getStrVsBlock(Block.getBlockById(blockId)) > f) {
                    bestSlot = i1 - 36;
                    f = curSlot.getStrVsBlock(Block.getBlockById(blockId));
                }
            }
            catch (Exception ex) {}
        }
        if (f != -1.0f) {
            final Minecraft mc3 = AntiObby.mc;
            Minecraft.thePlayer.inventory.currentItem = bestSlot;
            final Minecraft mc4 = AntiObby.mc;
            Minecraft.playerController.updateController();
        }
    }
}
