package Client.Dev.module.modules.player;

import Client.Dev.module.*;
import java.awt.*;
import Client.Dev.api.events.world.*;
import Client.Dev.api.value.Mode;
import net.minecraft.client.*;
import net.minecraft.network.play.client.*;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.network.*;
import Client.Dev.api.*;

public class NoFall
extends Module {
	double fall;
	private Mode mode = new Mode("Mode", "mode", (Enum[])NoFallMode.values(), (Enum)NoFallMode.GodLike);
	private float lastFall;
	public NoFall() {
        super("NoFall", new String[]{"Nofalldamage"}, ModuleType.Player);
        this.setColor(new Color(242, 137, 73).getRGB());
        this.addValues(mode);
    }
    public static boolean isBlockUnder() {
        int offset = 0;
        while ((double)offset < Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()) {
            AxisAlignedBB boundingBox = Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, -offset, 0.0);
            if (!Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, boundingBox).isEmpty()) {
                return true;
            }
            offset += 2;
        }
        return false;
    }
	
    @EventHandler
    private void onUpdate(EventPreUpdate e) {
    	this.setSuffix(mode.getValue());
    	if(mode.getValue() == NoFallMode.Spoof) {
            if(mc.thePlayer.fallDistance > 2) {
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY , mc.thePlayer.posZ, true));
            }
        }else if(mode.getValue() == NoFallMode.GodLike) {
            final double packets = Math.ceil(getMinFallDist() / 0.0625);
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY, Minecraft.getMinecraft().thePlayer.posZ, true));
            for (int i = 0; i < packets; ++i) {
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY + 0.06258781076883, Minecraft.getMinecraft().thePlayer.posZ, false));
                mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY + 0.00008781076883, Minecraft.getMinecraft().thePlayer.posZ, false));
            }

            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY, Minecraft.getMinecraft().thePlayer.posZ, false));
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY, Minecraft.getMinecraft().thePlayer.posZ, true));
        }
            }
    public static double getMinFallDist() {
        double baseFallDist = 3.0;
        if (Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.jump)) {
            baseFallDist += Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1.0f;
        }
        return baseFallDist;
    }
       
    
    

				
    	}
    
    
    enum NoFallMode {
    	Spoof,
    	GodLike,;
    }


