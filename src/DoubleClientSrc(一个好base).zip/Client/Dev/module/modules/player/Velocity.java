package Client.Dev.module.modules.player;

import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventPacketRecieve;
import Client.Dev.api.events.world.EventPreUpdate;
import Client.Dev.api.value.Numbers;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import java.awt.Color;

import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S27PacketExplosion;

public class Velocity
extends Module {
    private Numbers<Double> percentage = new Numbers<Double>("Percentage", "Percentage", 0.0, 0.0, 100.0, 5.0);

    public Velocity() {
        super("Velocity", new String[]{"velocity", "antiknockback", "antikb"}, ModuleType.Combat);
        this.addValues(this.percentage);
        this.setColor(new Color(191, 191, 191).getRGB());
    }

    @EventHandler
    private void onPacket(EventPacketRecieve e) {
    	Packet packet = e.getPacket();
    	if (packet instanceof S12PacketEntityVelocity) {
            if(((S12PacketEntityVelocity) e.getPacket()).getEntityID() == mc.thePlayer.getEntityId()) {
                    if (percentage.getValue() == 0.0) {
                        e.setCancelled(true);
                    } else {
                    	((S12PacketEntityVelocity) packet).motionX *= percentage.getValue() / 100;
                    	((S12PacketEntityVelocity) packet).motionY *= percentage.getValue() / 100;
                    	((S12PacketEntityVelocity) packet).motionZ *= percentage.getValue() / 100;
                    }
            }
        }
        if(packet instanceof S27PacketExplosion){
            e.setCancelled(true);
        }
    }
    
    @EventHandler
    private void onUpdate(EventPreUpdate event) {
    	
    }
}

