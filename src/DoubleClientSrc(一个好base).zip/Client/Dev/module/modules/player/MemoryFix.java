package Client.Dev.module.modules.player;

import java.awt.Color;

import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventTick;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import Client.Dev.utils.TimerUtil;

import net.minecraft.block.Block;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;

public class MemoryFix
extends Module {
	private TimerUtil mftimer = new TimerUtil();
	private double mflimit = 10.0;
	
    public MemoryFix() {
        super("MemoryFix", new String[]{"memory, fix"}, ModuleType.Player);
        this.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)).getRGB());
    }
    
    @Override
    public void onEnable() {
    	Runtime.getRuntime().gc();
    	mftimer.reset();
    }
    
    @EventHandler
	public void onTick(EventTick e) {
    	if(mftimer.hasReached(30000) && mflimit <= ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) * 100 / Runtime.getRuntime().maxMemory())) {
            Runtime.getRuntime().gc();
            mftimer.reset();
        }
	}
    
}
