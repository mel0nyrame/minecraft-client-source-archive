package Client.Dev.module.modules.player;

import Client.Dev.Client;
import Client.Dev.api.value.Option;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class Teams extends Module{
//	public static Option<Boolean> Armor = new Option("Armor", "Armor", true);

	public Teams() {
		super("Teams", new String[] {"Teams"}, ModuleType.Player);
//		this.addValues(Armor);
	}

	public static boolean isOnSameTeam(Entity entity) {
		if (!Client.getModuleManager().getModuleByClass(Teams.class).isEnabled()) {
			return false;
		}
		Minecraft.getMinecraft();
		if (Minecraft.thePlayer.getDisplayName().getUnformattedText().startsWith("\u00a7")) {
			Minecraft.getMinecraft();
			if (Minecraft.thePlayer.getDisplayName().getUnformattedText().length() <= 2
					|| entity.getDisplayName().getUnformattedText().length() <= 2) {
				return false;
			}
			Minecraft.getMinecraft();
			if (Minecraft.thePlayer.getDisplayName().getUnformattedText().substring(0, 2)
					.equals(entity.getDisplayName().getUnformattedText().substring(0, 2))) {
				return true;
			}

		}
		return false;
	}

	public static boolean isTeam(EntityPlayer e, EntityPlayer e2) {
		return e.getDisplayName().getFormattedText().contains("ยง" + isOnSameTeam(e))
				&& e2.getDisplayName().getFormattedText().contains("ยง" + isOnSameTeam(e));
	}


}