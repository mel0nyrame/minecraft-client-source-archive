package Client.Dev.module.modules.player;

import Client.Dev.Client;
import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventAttack;
import Client.Dev.api.events.world.EventPacket;
import Client.Dev.api.events.world.EventPacketSend;
import Client.Dev.api.events.world.EventPreUpdate;
import Client.Dev.api.value.Mode;
import Client.Dev.api.value.Numbers;
import Client.Dev.api.value.Option;
import Client.Dev.management.ModuleManager;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import Client.Dev.module.modules.combat.Criticals.CritMode;
import Client.Dev.module.modules.movement.Flight;
import Client.Dev.module.modules.movement.Longjump;
import Client.Dev.module.modules.movement.Scaffold;
import Client.Dev.module.modules.movement.Speed;
import Client.Dev.utils.Helper;
import Client.Dev.utils.MoveUtils;
import Client.Dev.utils.MovementUtils;
import Client.Dev.utils.PlayerUtil;
import Client.Dev.utils.PlayerUtils;
import Client.Dev.utils.Stopwatch;
import Client.Dev.utils.TimerUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import net.minecraft.block.BlockLiquid;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.server.S2APacketParticles;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

public class IQBooster extends Module {
	   private Numbers<Double> delay = new Numbers<Double>("Dealy","Delay",250.0,50.0,114514.0,1.0);
	    public static Mode mode = new Mode("Mode", "Mode", (Enum[])CritMode.values(), (Enum)CritMode.GodLike);
    public IQBooster() {
        super("IQBooster", new String[]{"IQBooster", "IQBooster"}, ModuleType.Combat);

        this.setColor(new Color(235, 194, 138).getRGB()); 
        this.addValues(this.delay,this.mode);
    }
    public void onEnable() {
    Helper.sendMessage("IQ Increased!");
    }
    public void onDisable() {
        Helper.sendMessage("IQ Reduction!");
    }
    @EventHandler
    private void onPacket(EventPreUpdate e10) {
    	this.setSuffix(""+this.mode.getValue() +" "+ delay.getValue().intValue());
		
    }

public static enum CritMode {
    GodLike,
    Best,
    High,
    Low
}


 }
 
