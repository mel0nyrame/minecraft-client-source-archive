package Client.Dev.module.modules.player;

import java.awt.Color;

import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventTick;
import Client.Dev.api.value.Numbers;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;

public class Timer
extends Module {
	public static float timerSpeed;
	private Numbers<Double> speed = new Numbers<Double>("Speed", "Speed", 1.0,0.1,2.0,0.001);
	
    public Timer() {
        super("Timer", new String[]{"timer"}, ModuleType.Player);
        this.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)).getRGB());
        this.addValues(speed);
    }
    
    @Override
	public void onEnable() {
		mc.timer.timerSpeed = speed.getValue().floatValue();
	}
	
	@Override
	public void onDisable() {
        mc.timer.timerSpeed = 1F;
	}

	@EventHandler
	public void onTick(EventTick e) {
		this.setSuffix(speed.getValue());
		mc.timer.timerSpeed = speed.getValue().floatValue();
	}
}
