package Client.Dev.module.modules.combat;


import Client.Dev.ui.font.CFontRenderer;
import Client.Dev.ui.font.FontLoaders;
import Client.Dev.Client;
import Client.Dev.api.EventHandler;
import Client.Dev.api.events.rendering.EventRender2D;
import Client.Dev.api.events.rendering.EventRender3D;
import Client.Dev.api.events.world.EventPacketSend;
import Client.Dev.api.events.world.EventPacket;
import Client.Dev.api.events.world.EventPostUpdate;
import Client.Dev.api.events.world.EventPreUpdate;
import Client.Dev.api.value.Mode;
import Client.Dev.api.value.Numbers;
import Client.Dev.api.value.Option;
import Client.Dev.management.FriendManager;
import Client.Dev.management.ModuleManager;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import Client.Dev.module.modules.player.Teams;
import Client.Dev.utils.TimerUtil;

import Client.Dev.utils.math.MathUtil;
import Client.Dev.utils.math.RotationUtil;
import Client.Dev.utils.render.ColorUtils;
import Client.Dev.utils.render.RenderUtil;
import Client.Dev.utils.render.gl.GLUtils;

import java.awt.Color;
import java.util.*;
import java.util.function.ToDoubleFunction;
import java.util.stream.Collectors;
import javax.vecmath.Vector3d;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.monster.*;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.player.EntityPlayer;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C07PacketPlayerDigging.Action;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Vec3;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;
import org.lwjgl.util.vector.Vector2f;

public class Killaura extends Module {
    public static EntityLivingBase blockTarget;
	public static EntityLivingBase curtarget;
	private List targets = new ArrayList(0);
	private int index;
	private Numbers<Double> Cps = new Numbers<Double>("CPS","CPS", 10.0, 1.0, 20.0, 0.5);
	public static Numbers<Double> Range = new Numbers<Double>("Range","Range", 4.5, 1.0, 6.0, 0.1);
    private Mode<Enum> ESP = new Mode("ESP","ESP", (Enum[])ESPMode.values(), (Enum)ESPMode.Jello);
    public static Numbers<Double> turnspeed = new Numbers<Double>("TurnSpeeed","TurnSpeeed", 120.0, 0.0, 180.0, 5.0);
	public static Numbers<Double> SwitchDelay = new Numbers<Double>("SwitchDelay","SwitchDelay", 500.0, 1.0, 5000.0, 1.0);
	private Option<Boolean> Autoblock = new Option<Boolean>("Autoblock","Autoblock", true);
	private Option<Boolean> multi = new Option<Boolean>("Multi","Multi", false);
	public static Numbers<Double> multiMaxTarget = new Numbers<Double>("MultiMaxTarget", "MultiMaxTarget", 255.0, 0.0, 255.0, 1.0);
	private static Option<Boolean> RCircle = new Option<Boolean>("DrawRangeCircle", "DrawRangeCircle", true);
	public static Numbers<Double> R = new Numbers<Double>("RangeCircleR", "RangeCircleR", 255.0, 0.0, 255.0, 1.0);
	public static Numbers<Double> G = new Numbers<Double>("RangeCircleG", "RangeCircleG", 0.0, 0.0, 255.0, 1.0);
	public static Numbers<Double> B = new Numbers<Double>("RangeCircleB", "RangeCircleB", 0.0, 0.0, 255.0, 1.0);
	private static Option<Boolean> Players = new Option<Boolean>("Players","Players", true);
	private static Option<Boolean> Animals = new Option<Boolean>("Animals","Animals", true);
	private static Option<Boolean> Mobs = new Option<Boolean>("Mobs","Mobs", false);
	private static Option<Boolean> Invis = new Option<Boolean>("Invisibles","Invisibles", false);
	private Option<Boolean> Radom = new Option<Boolean>("Radom","Radom", true);
	private Mode<Enum> Mode = new Mode<Enum>("Mode","Mode", AuraMode.values(), AuraMode.Single);
	private Mode<Enum> rotmode = new Mode<Enum>("RotationMode","RotationMode", AuraRotMode.values(), AuraRotMode.GodLike);
	private Mode<Enum> SwitchMod = new Mode<Enum>("SwitchMode","SwitchMode", SwitchMode.values(), SwitchMode.Delay);
	public Option<Boolean> autoaim = new Option<Boolean>("AutoAim", "AutoAim", false);
	private boolean isBlocking;
	private Comparator<Entity> angleComparator = Comparator.comparingDouble(e2 -> e2.getDistanceToEntity(mc.thePlayer));

	private TimerUtil AttackTimer = new TimerUtil();

	private TimerUtil SwitchTimer = new TimerUtil();
	private Object texture;
	float anim = 100;
	
	public static float[] facing;
	private float[] facing0;
	private float[] facing1;
	private float[] facing2;
	private float[] facing3;
	
	public float[] lastAngles;
	private Vector2f lastAnglesEz = new Vector2f(0.0F, 0.0F);

    static enum SwitchMode {
        Delay,
        HurtTime
    }
	public static EntityLivingBase getBlockTarget() {
        return blockTarget;
    }
	
	public static EntityLivingBase getTarget() {
	    return curtarget;
	}
	
	public Killaura() {
		super("Killaura", new String[] { "ka", "killaura"}, ModuleType.Combat);
		this.addValues(this.Mode,this.ESP,rotmode,this.Cps, this.Range, this.SwitchDelay,this.autoaim,this.Radom,this.turnspeed, this.Autoblock, this.multi, this.multiMaxTarget,  this.RCircle,this.R,this.G,this.B, this.Players, this.Animals, this.Mobs, this.Invis);
	}

	@Override
	public void onDisable() {
		this.curtarget = null;
		this.targets.clear();
		if (this.Autoblock.getValue().booleanValue() && this.hasSword() && this.mc.thePlayer.isBlocking()) {
			this.UnBlock();
		}
		if (mc.thePlayer != null) {
	          this.lastAnglesEz.x = mc.thePlayer.rotationYaw;
	       }
	}

	@Override
	public void onEnable() {
		this.curtarget = null;
		this.index = 0;
		if (mc.thePlayer != null) {
            this.lastAnglesEz.x = mc.thePlayer.rotationYaw;
         }
	}

	@EventHandler
	public void onRender(EventRender3D render) {
		if(this.RCircle.getValue() == true) {
			GL11.glPushMatrix();
		    GL11.glEnable(3042);
		    GL11.glBlendFunc(770, 771);
		    GL11.glEnable(2848);
		    GL11.glLineWidth(2.0F);
		    GL11.glDisable(3553);
		    GL11.glEnable(2884);
		    GL11.glDisable(2929);
		    double renderPosX = (this.mc.getRenderManager()).viewerPosX;
		    double renderPosY = (this.mc.getRenderManager()).viewerPosY;
		    double renderPosZ = (this.mc.getRenderManager()).viewerPosZ;
		    AxisAlignedBB Item = new AxisAlignedBB(-0.175D, 0.0D, -0.175D, 0.175D, 0.35D, 0.175D);
		    GL11.glPushMatrix();
		    GL11.glTranslated(RenderUtil.getEntityRenderX(this.mc.thePlayer), RenderUtil.getEntityRenderY(this.mc.thePlayer), RenderUtil.getEntityRenderZ(this.mc.thePlayer));
		    GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);
		    if(curtarget == null) {
		    	RenderUtil.drawCircle((int)Item.minX, (int)Item.minY, ((Double)this.Range.getValue()).floatValue(), 1.0F, false, (new Color(255, 255, 255)).getRGB());
		    }else {
			    RenderUtil.drawCircle((int)Item.minX, (int)Item.minY, ((Double)this.Range.getValue()).floatValue(), 1.0F, false, (new Color(R.getValue().intValue(), G.getValue().intValue(),B.getValue().intValue())).getRGB());
		    }
		    GL11.glPopMatrix();
		    GL11.glColor4f(0.0F, 0.0F, 1.0F, 1.0F);
		    GL11.glEnable(2929);
		    GL11.glEnable(3553);
		    GL11.glDisable(3042);
		    GL11.glDisable(2848);
		    GL11.glPopMatrix();
		    }
		}

	@EventHandler
	public void onRender2D(EventRender2D event) {

	}
	
	@EventHandler
    public void onRender3D(EventRender3D event) {
        double z1;
        double y1;
        double z;
        double y;
        double x;
        EntityLivingBase entity2;
        if (this.ESP.getValue() == ESPMode.Cylinder) {
            double posX = Killaura.curtarget.lastTickPosX + (Killaura.curtarget.posX - Killaura.curtarget.lastTickPosX) * (double)event.getPartialTicks() - RenderManager.renderPosX;
            double posY = Killaura.curtarget.lastTickPosY + (Killaura.curtarget.posY - Killaura.curtarget.lastTickPosY) * (double)event.getPartialTicks() - RenderManager.renderPosY;
            double posZ = Killaura.curtarget.lastTickPosZ + (Killaura.curtarget.posZ - Killaura.curtarget.lastTickPosZ) * (double)event.getPartialTicks() - RenderManager.renderPosZ;
            if (Killaura.curtarget.hurtTime > 0) {
                RenderUtil.drawWolframEntityESP(curtarget, new Color(255, 102, 113).getRGB(), posX, posY, posZ);
            } else {
                RenderUtil.drawWolframEntityESP(curtarget, new Color(186, 100, 200).getRGB(), posX, posY, posZ);
            }
        }
        if (this.ESP.getValue() == ESPMode.Rainbow) {
            float alpha;
            float blue;
            float green;
            float red;
            mc.getRenderManager();
            double x1 = Killaura.curtarget.lastTickPosX + (Killaura.curtarget.posX - Killaura.curtarget.lastTickPosX) * (double)Killaura.mc.timer.renderPartialTicks - RenderManager.renderPosX;
            mc.getRenderManager();
            y1 = Killaura.curtarget.lastTickPosY + (Killaura.curtarget.posY - Killaura.curtarget.lastTickPosY) * (double)Killaura.mc.timer.renderPartialTicks - RenderManager.renderPosY;
            mc.getRenderManager();
            z1 = Killaura.curtarget.lastTickPosZ + (Killaura.curtarget.posZ - Killaura.curtarget.lastTickPosZ) * (double)Killaura.mc.timer.renderPartialTicks - RenderManager.renderPosZ;
            double width = Killaura.curtarget.getEntityBoundingBox().maxX - Killaura.curtarget.getEntityBoundingBox().minX - 0.2;
            double height = Killaura.curtarget.getEntityBoundingBox().maxY - Killaura.curtarget.getEntityBoundingBox().minY + 0.05;
            if (Killaura.curtarget.hurtTime == 10) {
                red = (float)ColorUtils.getRainbow().getRed() / 255.0f;
                green = (float)ColorUtils.getRainbow().getGreen() / 255.0f;
                blue = (float)ColorUtils.getRainbow().getBlue() / 255.0f;
                alpha = (float)(80 + Killaura.curtarget.hurtTime * 10) / 255.0f;
            } else {
                red = (float)ColorUtils.getRainbow().getRed() / 255.0f;
                green = (float)ColorUtils.getRainbow().getGreen() / 255.0f;
                blue = (float)ColorUtils.getRainbow().getBlue() / 255.0f;
                alpha = (float)(80 + Killaura.curtarget.hurtTime * 10) / 255.0f;
            }
            RenderUtil.drawEntityESP(x1, y1, z1, width, height, red, green, blue, alpha, 0.1f, 0.1f, 0.1f, 0.1f, 0.1f);
        }
        if (this.ESP.getValue() == ESPMode.New) {
            float lineWdith1;
            float lineAlpha1;
            float lineBlue1;
            float lineGreen1;
            float lineRed1;
            float alpha1;
            float green1;
            mc.getRenderManager();
            double x1 = Killaura.curtarget.lastTickPosX + (Killaura.curtarget.posX - Killaura.curtarget.lastTickPosX) * (double)Killaura.mc.timer.renderPartialTicks - RenderManager.renderPosX;
            mc.getRenderManager();
            y1 = Killaura.curtarget.lastTickPosY + (Killaura.curtarget.posY - Killaura.curtarget.lastTickPosY) * (double)Killaura.mc.timer.renderPartialTicks - RenderManager.renderPosY;
            mc.getRenderManager();
            z1 = Killaura.curtarget.lastTickPosZ + (Killaura.curtarget.posZ - Killaura.curtarget.lastTickPosZ) * (double)Killaura.mc.timer.renderPartialTicks - RenderManager.renderPosZ;
            if (curtarget instanceof EntityPlayer) {
                double width1 = Killaura.curtarget.getEntityBoundingBox().maxX - Killaura.curtarget.getEntityBoundingBox().minX - 0.35;
                double height1 = Killaura.curtarget.getEntityBoundingBox().maxY - Killaura.curtarget.getEntityBoundingBox().minY;
                float red1 = Killaura.curtarget.hurtTime > 0 ? 1.0f : 0.0f;
                green1 = Killaura.curtarget.hurtTime > 0 ? 0.2f : 1.0f;
                float blue1 = Killaura.curtarget.hurtTime > 0 ? 0.0f : 0.2f;
                alpha1 = 0.2f;
                lineRed1 = Killaura.curtarget.hurtTime > 0 ? 1.0f : 0.0f;
                lineGreen1 = Killaura.curtarget.hurtTime > 0 ? 0.2f : 1.0f;
                lineBlue1 = Killaura.curtarget.hurtTime > 0 ? 0.0f : 0.2f;
                lineAlpha1 = 0.2f;
                lineWdith1 = 2.0f;
                RenderUtil.drawEntityESP(x1, y1, z1, width1, height1, red1, green1, blue1, 0.2f, lineRed1, lineGreen1, lineBlue1, 0.2f, 2.0f);
            } else {
                double width1 = Killaura.curtarget.getEntityBoundingBox().maxX - Killaura.curtarget.getEntityBoundingBox().minX - 0.35;
                double height1 = Killaura.curtarget.getEntityBoundingBox().maxY - Killaura.curtarget.getEntityBoundingBox().minY;
                float red1 = Killaura.curtarget.hurtTime > 0 ? 1.0f : 0.0f;
                green1 = Killaura.curtarget.hurtTime > 0 ? 0.2f : 1.0f;
                float blue1 = Killaura.curtarget.hurtTime > 0 ? 0.0f : 0.2f;
                alpha1 = 0.2f;
                lineRed1 = Killaura.curtarget.hurtTime > 0 ? 1.0f : 0.0f;
                lineGreen1 = Killaura.curtarget.hurtTime > 0 ? 0.2f : 1.0f;
                lineBlue1 = Killaura.curtarget.hurtTime > 0 ? 0.0f : 0.2f;
                lineAlpha1 = 0.2f;
                lineWdith1 = 2.0f;
                RenderUtil.drawEntityESP(x1, y1, z1, width1, height1, red1, green1, blue1, 0.2f, lineRed1, lineGreen1, lineBlue1, 0.2f, 2.0f);
            }
        }

        this.ESP.getValue();
        entity2 = curtarget;
        if (this.ESP.getValue() == ESPMode.Jello && entity2 != null && !Killaura.curtarget.isDead) {
            this.esp(curtarget, EventRender3D.ticks);
        }
        if (this.ESP.getValue() == ESPMode.LiquidBounce) {
        	mc.getRenderManager();
			double x2 = Killaura.curtarget.lastTickPosX + (Killaura.curtarget.posX - Killaura.curtarget.lastTickPosX)
					* (double) Killaura.mc.timer.renderPartialTicks - RenderManager.renderPosX;
			mc.getRenderManager();
			double y2 = Killaura.curtarget.lastTickPosY + (Killaura.curtarget.posY - Killaura.curtarget.lastTickPosY)
					* (double) Killaura.mc.timer.renderPartialTicks - RenderManager.renderPosY;
			mc.getRenderManager();
			double z2 = Killaura.curtarget.lastTickPosZ + (Killaura.curtarget.posZ - Killaura.curtarget.lastTickPosZ)
					* (double) Killaura.mc.timer.renderPartialTicks - RenderManager.renderPosZ;
			if (curtarget instanceof EntityPlayer) {
				double d = curtarget.isSneaking() ? 0.25 : 0.0;
				double mid = 0.5;
				GL11.glPushMatrix();
				GL11.glEnable((int) 3042);
				GL11.glBlendFunc((int) 770, (int) 771);
				double rotAdd = -0.25 * (double) (Math.abs((float) Killaura.curtarget.rotationPitch) / 90.0f);
				GL11.glTranslated((double) ((x2 -= 0.5) + 0.5),
						(double) ((y2 += (double) curtarget.getEyeHeight() + 0.35 - d) + 0.5),
						(double) ((z2 -= 0.5) + 0.5));
				GL11.glRotated((double) (-Killaura.curtarget.rotationYaw % 360.0f), (double) 0.0, (double) 1.0,
						(double) 0.0);
				GL11.glTranslated((double) (-(x2 + 0.5)), (double) (-(y2 + 0.5)), (double) (-(z2 + 0.5)));
				GL11.glDisable((int) 3553);
				GL11.glEnable((int) 2848);
				GL11.glDisable((int) 2929);
				GL11.glDepthMask((boolean) false);
				/*GL11.glColor4f((float) ((float) color.getRed() / 255.0f),
						(float) ((float) color.getGreen() / 255.0f), (float) ((float) color.getBlue() / 255.0f),
						(float) 0.5f);*/
				RenderUtil.drawBoundingBox((AxisAlignedBB) new AxisAlignedBB(x2, y2, z2, x2 + 1.0, y2 + 0.05, z2 + 1.0));
				GL11.glDisable((int) 2848);
				GL11.glEnable((int) 3553);
				GL11.glEnable((int) 2929);
				GL11.glDepthMask((boolean) true);
				GL11.glDisable((int) 3042);
				GL11.glPopMatrix();
			} else {
				double width = Killaura.curtarget.getEntityBoundingBox().maxX
						- Killaura.curtarget.getEntityBoundingBox().minX - 0.2;
				if ((int) Killaura.curtarget.hurtTime > 5) {
					float red = 1.0f;
					float green = 0.0f;
					float blue = 0.0f;
					RenderUtil.drawEntityESP(x2, y2 + curtarget.getEyeHeight() + 0.25, z2, width, 0.1, red, green,
							blue, 0.5f, red, green, blue, 1, 2);
				} else {
					float red = 0.0f;
					float green = 1.0f;
					float blue = 0.0f;
					RenderUtil.drawEntityESP(x2, y2 + curtarget.getEyeHeight() + 0.25, z2, width, 0.1, red, green,
							blue, 0.5f, red, green, blue, 1, 2);
				}
			}
        }


		}
    

    public void esp(Entity entity, float partialTicks) {
        this.onecircle(entity, partialTicks, 0.6f, 0.0f);
    }
    public void onecircle(Entity entity, float partialTicks, float alpha, float yoffset) {
        double shit = entity.getEntityBoundingBox().maxY - entity.posY - 0.9;
        double d = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)partialTicks;
        mc.getRenderManager();
        double x = d - RenderManager.viewerPosX;
        double d2 = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)partialTicks;
        mc.getRenderManager();
        double y = d2 - RenderManager.viewerPosY + Math.sin((double)System.currentTimeMillis() * 0.0045) * shit + shit + (double)yoffset;
        double d3 = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)partialTicks;
        mc.getRenderManager();
        double z = d3 - RenderManager.viewerPosZ;
        Cylinder c = new Cylinder();
        GL11.glPushMatrix();
        GL11.glDisable((int)2896);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)2848);
        GL11.glDepthMask((boolean)false);
        GlStateManager.translate(x, y, z);
        GlStateManager.color(1.0f, 1.0f, 1.0f, alpha);
        GlStateManager.rotate(180.0f, 90.0f, 0.0f, 2.0f);
        GlStateManager.rotate(180.0f, 0.0f, 90.0f, 90.0f);
        c.setDrawStyle(100011);
        c.draw(0.8f, 0.8f, 0.0f, 360, 0);
        GL11.glDisable((int)2848);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glDepthMask((boolean)true);
        GL11.glEnable((int)2896);
        GL11.glEnable((int)3553);
        GL11.glPopMatrix();
    }

	private boolean hasSword() {
		if (mc.thePlayer.inventory.getCurrentItem() != null) {
			if (mc.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemSword) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	private void Block() {
		if (mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) {
			KeyBinding.setKeyBindState(this.mc.gameSettings.keyBindUseItem.getKeyCode(), true);
			if (this.mc.playerController.sendUseItem(this.mc.thePlayer, this.mc.theWorld, this.mc.thePlayer.inventory.getCurrentItem())) {
				this.mc.getItemRenderer().resetEquippedProgress2();
			}
			this.isBlocking = true;
		}
	}

	private void UnBlock() {
		if (mc.thePlayer.getHeldItem().getItem() instanceof ItemSword && isBlocking) {
			KeyBinding.setKeyBindState(this.mc.gameSettings.keyBindUseItem.getKeyCode(), false);
			this.mc.playerController.onStoppedUsingItem(this.mc.thePlayer);
			this.isBlocking = false;
		}
	}

	private boolean shouldAttack() {
		return this.AttackTimer.hasReached(1000.0 / (this.Cps.getValue() + MathUtil.randomDouble(-1.0, 1.0)));
	}

	private void drawCircle(Entity entity, float partialTicks, double rad) {
		GL11.glPushMatrix();
		GL11.glDisable((int)3553);
		GLUtils.startSmooth();
		GL11.glDisable((int)2929);
		GL11.glDepthMask((boolean)false);
		GL11.glLineWidth((float)1.0f);
		GL11.glBegin((int)3);
		double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)partialTicks - mc.getRenderManager().viewerPosX;
		double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)partialTicks - mc.getRenderManager().viewerPosY;
		double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)partialTicks - mc.getRenderManager().viewerPosZ;
		double pix2 = Math.PI * 2;
		for (int i = 0; i <= 360; ++i) {
			GL11.glVertex3d((double)(x + rad * Math.cos((double)i * (Math.PI * 2) / 45)), (double)y + 0, (double)(z + rad * Math.sin((double)i * (Math.PI * 2) / 45.0)));
		}
		GL11.glEnd();
		GL11.glDepthMask((boolean)true);
		GL11.glEnable((int)2929);
		GLUtils.endSmooth();
		GL11.glEnable((int)3553);
		GL11.glPopMatrix();
	}

	public void esp(Entity player, double x, double y, double z, float alpha) {
		GL11.glPushMatrix();
		GL11.glDisable(2896);
		GL11.glDisable(3553);
		GL11.glEnable(3042);
		GL11.glBlendFunc(770, 771);
		GL11.glDisable(2929);
		GL11.glEnable(2848);
		GL11.glDepthMask(true);
		GlStateManager.translate(x, y, z);
		GlStateManager.color(1, 1, 1, 1.0f);
		GlStateManager.rotate(180, 90.0f, 0, 2.0f);
		GlStateManager.rotate(180, 0.0f, 90, 90.0f);
		Cylinder c = new Cylinder();
		c.setDrawStyle(100011);
		c.draw(0.7F, 0.7F, 0f, 120, 2);
		GL11.glDepthMask(true);
		GL11.glDisable(2848);
		GL11.glEnable(2929);
		GL11.glDisable(3042);
		GL11.glEnable(2896);
		GL11.glEnable(3553);
		GL11.glPopMatrix();
	}

	@EventHandler
	private void onUpdate(EventPreUpdate event) {
		this.setSuffix(this.Mode.getValue());
		if (curtarget == null && Autoblock.getValue()) {
			if (hasSword()) {
				UnBlock();
			}
		}
		if (hasSword() && this.curtarget != null && Autoblock.getValue() && !isBlocking) {
			this.Block();
		}
		this.targets = this.getTargets(Range.getValue());

		targets.sort(this.angleComparator);

		if (this.autoaim.getValue().booleanValue()) {
			if (this.curtarget != null) {
				float[] rotations = RotationUtil.getRotations(curtarget);
				mc.thePlayer.rotationYawHead = rotations[0];
				mc.thePlayer.rotationYaw = rotations[0];
			}
		}
		
		if (this.targets.size() > 1 && this.Mode.getValue() == AuraMode.Switch) {
			if (SwitchTimer.delay(SwitchDelay.getValue().longValue())) {
				++this.index;
				SwitchTimer.reset();
			}
		}

		if (this.mc.thePlayer.ticksExisted % SwitchDelay.getValue().intValue() == 0 && this.targets.size() > 1 && this.Mode.getValue() == AuraMode.Single) {

			if (curtarget.getDistanceToEntity(mc.thePlayer) > Range.getValue()) {
				++index;
			} else if (curtarget.isDead) {
				++index;
			}
		}

		if (curtarget != null) {
			curtarget = null;
		}

		if (!this.targets.isEmpty()) {
			if (this.index >= this.targets.size()) {
				this.index = 0;
			}
			curtarget = (EntityLivingBase) this.targets.get(this.index);
			switch (this.rotmode.getValue().toString()) {
				case "GodLike":{
					mc.thePlayer.rotationYawHead = getRotation(curtarget)[0];
					mc.thePlayer.rotationPitchHead = getRotation(curtarget)[1];
					mc.thePlayer.renderYawOffset = getRotation(curtarget)[0];

					event.setYaw(getRotation(curtarget)[0]);
					event.setPitch(getRotation(curtarget)[1]);
					break;
				}
				case "Exhibition":{
					float[] rotations = getRotationsEx(curtarget);
	                float targetYaw = MathHelper.clamp_float(getYawChangeGivenEx(curtarget.posX, curtarget.posZ, this.lastAnglesEz.x) + (float)this.randomNumber(-5, 5), -180.0F, 180.0F);
	                
	                Random rand = new Random();
	                facing0 = getRotationsEx(curtarget);
	                facing1 = getNeededRotationsEx(curtarget);
	                facing2 = getRotations5Ex(curtarget);
	                facing3 = getRotationsEx(curtarget);
	                switch (randomNumber(1,4)) {
	                     case 1:
	                         facing = facing0;
	                         break;
	                     case 2:
	                         facing = facing1;
	                         break;
	                     case 3:
	                         facing = facing2;
	                         break;
	                     case 4:
	                         facing = facing3;
	                         break;
	                  }
	              
	                 if(facing.length > 0) {
	                     event.setYaw((facing[0]) + (float)rand.nextInt(12) -2.0F);
	                     event.setPitch(facing[1] );
	                 }
	                mc.thePlayer.renderYawOffset = rotations[0];
	                mc.thePlayer.rotationYawHead = rotations[0];
				}
				}
			}
		}
	

	@EventHandler
	private void onUpdatePost(EventPostUpdate e) {
		if (curtarget != null) {
			double angle = Math.toRadians(this.curtarget.rotationYaw - 90.0f + 360.0f) % 360.0;
			if (this.shouldAttack()) {
				if (this.hasSword() && this.mc.thePlayer.isBlocking() && this.CanAttack(this.curtarget)) {
					UnBlock();
				}
				mc.thePlayer.swingItem();
				mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(this.curtarget, C02PacketUseEntity.Action.ATTACK));
				this.AttackTimer.reset();
			}
			if (!mc.thePlayer.isBlocking() && this.hasSword() && Autoblock.getValue().booleanValue()) {
				this.Block();
			}
			if (this.multi.getValue()) {
	 		    int targets = 0;
				Iterator<EntityLivingBase> iterator = this.targets.iterator();
				while (iterator.hasNext()) {
					if (targets >= multiMaxTarget.getValue().intValue()) {
		                break;
		            }
					Entity entity = iterator.next();
					if (this.getEntityValid((EntityLivingBase) entity)) {
					    mc.thePlayer.swingItem();
					    mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(entity, C02PacketUseEntity.Action.ATTACK));
					    ++targets;
					}
				}
		   } else {
	       mc.thePlayer.swingItem();
	       mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(curtarget, C02PacketUseEntity.Action.ATTACK));
		   }
		}
	}

	public static List<Entity> getTargets(Double value) {
		return mc.theWorld.loadedEntityList.stream().filter(e -> (double) mc.thePlayer.getDistanceToEntity((Entity) e) <= value && CanAttack((Entity) e)).collect(Collectors.toList());
	}

	private static boolean CanAttack(Entity e2) {
		if (mc.thePlayer.getDistanceToEntity(e2) > Range.getValue())
			return false;
		if (e2.isInvisible() && !Invis.getValue())
			return false;
		if (!e2.isEntityAlive())
			return false;
		if (e2 == mc.thePlayer||FriendManager.isFriend(e2.getName()) || e2.isDead || mc.thePlayer.getHealth() == 0F)
			return false;
		if ((e2 instanceof EntityMob || e2 instanceof EntityGhast || e2 instanceof EntityGolem
				|| e2 instanceof EntityDragon || e2 instanceof EntitySlime) && Mobs.getValue())
			return true;
		if ((e2 instanceof EntitySquid || e2 instanceof EntityBat || e2 instanceof EntityVillager)
				&& Animals.getValue())
			return true;
		if (e2 instanceof EntityAnimal && Animals.getValue())
			return true;

		AntiBot ab2 = (AntiBot) ModuleManager.getModuleByClass(AntiBot.class);
		if (ab2.isEntityBot(e2)) {
		    return false;
		}
		if (e2 instanceof EntityPlayer && Players.getValue().booleanValue() && !Teams.isOnSameTeam(e2)) {
		    return true;
		}
		if (e2 instanceof EntityPlayer && Players.getValue() && !Teams.isOnSameTeam(e2))
			return true;

		return false;
	}
	public static float[] getRotations(EntityLivingBase ent) {
		double x = ent.posX;
		double z = ent.posZ;
		double y = ent.posY + ent.getEyeHeight() / 2.0F;
		return getRotationFromPositionSlow(x, z, y);
	}


	public static float[] getRotationFromPositionSlow(double x, double z, double y) {
		double xDiff = x - Minecraft.getMinecraft().thePlayer.posX;
		double zDiff = z - Minecraft.getMinecraft().thePlayer.posZ;
		double yDiff = y - Minecraft.getMinecraft().thePlayer.posY - 1.2;

		double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
		float yaw = (float) (Math.atan2(zDiff, xDiff) * 180 / 3.141592653589793D) - 90.0F;
		float pitch = (float) -(Math.atan2(yDiff, dist) * 180 / 3.141592653589793D);
		return new float[]{yaw, pitch};
	}

	public static float[] getRotation(EntityLivingBase curTarget2) {
		Minecraft.getMinecraft();
		double xDiff = curtarget.posX - mc.thePlayer.posX;
		double yDiff = curtarget.posY - mc.thePlayer.posY - 0.2;
		double zDiff = curtarget.posZ - mc.thePlayer.posZ;
		Minecraft.getMinecraft();
		double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
		float yaw = (float)(Math.atan2(zDiff, xDiff) * 180 / 3.141592653589793) - 90.0f;
		float pitch = (float)((- Math.atan2(yDiff, dist)) * 180 / 3.141592653589793);
		float[] array = new float[2];
		int n = 0;
		Minecraft.getMinecraft();
		float rotationYaw = Minecraft.thePlayer.rotationYaw;
		float n2 = yaw;
		Minecraft.getMinecraft();
		array[n] = rotationYaw + MathHelper.wrapAngleTo180_float(n2 - Minecraft.thePlayer.rotationYaw);
		int n3 = 1;
		Minecraft.getMinecraft();
		float rotationPitch = Minecraft.thePlayer.rotationPitch;
		float n4 = pitch;
		Minecraft.getMinecraft();
		array[n3] = rotationPitch + MathHelper.wrapAngleTo180_float(n4 - Minecraft.thePlayer.rotationPitch);
		return array;
	}

	public static float[] getRotation2(EntityLivingBase entity) {
		EntityLivingBase entityLivingBase = entity;
		double diffX = entityLivingBase.posX - mc.thePlayer.posX;
		double diffZ = entityLivingBase.posZ - mc.thePlayer.posZ;
		double diffY = entityLivingBase.posY + (double) entity.getEyeHeight() - (mc.thePlayer.posY + (double) mc.thePlayer.getEyeHeight());
		double X = diffX;
		double Z = diffZ;
		double dist = MathHelper.sqrt_double((double) (X * X + Z * Z));
		float yaw = (float) (Math.atan2((double) diffZ, (double) diffX) * 180 / 3.141592653589) - 90.0f;
		float pitch = (float) (-(Math.atan2((double) diffY, (double) dist) * 180 / 3.141592653589));
		return new float[]{yaw, pitch};
	}
	
	 public static float getYawChangeGivenEx(double posX, double posZ, float yaw) {
	      double deltaX = posX - Minecraft.getMinecraft().thePlayer.posX;
	      double deltaZ = posZ - Minecraft.getMinecraft().thePlayer.posZ;
	      double yawToEntity;
	      if (deltaZ < 0.0D && deltaX < 0.0D) {
	         yawToEntity = 90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
	      } else if (deltaZ < 0.0D && deltaX > 0.0D) {
	         yawToEntity = -90.0D + Math.toDegrees(Math.atan(deltaZ / deltaX));
	      } else {
	         yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
	      }

	      return MathHelper.wrapAngleTo180_float(-(yaw - (float)yawToEntity));
	   }
	 
	public static  float[] getRotations5Ex( Entity curTarget) {
	   	 if(curTarget == null)
	            return null;
	   
	        double diffX = curTarget.posX - Minecraft.getMinecraft().thePlayer.posX;
	        double diffZ = curTarget.posZ - Minecraft.getMinecraft().thePlayer.posZ;
	        double diffY;
	        if(curTarget instanceof EntityLivingBase){
	            EntityLivingBase elb = (EntityLivingBase) curTarget;
	            diffY = elb.posY
	                    + (elb.getEyeHeight() - 0.6)
	                    - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer
	                    .getEyeHeight());
	        }else
	            diffY = (curTarget.boundingBox.minY + curTarget.boundingBox.maxY)
	                    / 2.0D
	                    - (Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer
	                    .getEyeHeight());
	        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
	        float yaw = (float) (Math.atan2(diffZ, diffX) * 180.0D / Math.PI) - 90.0f;
	        float pitch = (float) -(Math.atan2(diffY, dist) * 180.0D / Math.PI);

	        return new float[] { yaw, pitch };
	   }
  
  public static float[] getNeededRotationsEx(Entity target) {
      final Vec3 eyesPos = new Vec3(Minecraft.getMinecraft().thePlayer.posX, Minecraft.getMinecraft().thePlayer.posY + Minecraft.getMinecraft().thePlayer.getEyeHeight(), Minecraft.getMinecraft().thePlayer.posZ);
      final double diffX = target.posX - eyesPos.xCoord;
      final double diffY = target.posY - eyesPos.yCoord;
      final double diffZ = target.posZ - eyesPos.zCoord;
      final double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
      final float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
      final float pitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));
      return new float[]{MathHelper.wrapAngleTo180_float(yaw), MathHelper.wrapAngleTo180_float(pitch)};
  }
	public static float[] getRotationFromPositionEx(double x, double z, double y) {
	      double xDiff = x - Minecraft.getMinecraft().thePlayer.posX;
	      double zDiff = z - Minecraft.getMinecraft().thePlayer.posZ;
	      double yDiff = y - Minecraft.getMinecraft().thePlayer.posY - 1.2D;
	      double dist = (double)MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
	      float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0D / 3.141592653589793D) - 90.0F;
	      float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0D / 3.141592653589793D));
	      return new float[]{yaw, pitch};
	   }
	
	public static float[] getRotationsEx(EntityLivingBase ent) {
	      double x = ent.posX;
	      double z = ent.posZ;
	      double y = ent.posY + (double)(ent.getEyeHeight() / 2.0F);
	      return getRotationFromPositionEx(x, z, y);
	   }
	
	private static int randomNumber(double min, double max) {
		Random random = new Random();
		return (int) (min + (random.nextDouble() * (max - min)));
	}
	
	@EventHandler
	private void EventPacket(EventPacket packet) {
        C07PacketPlayerDigging packetPlayerDigging;
        C08PacketPlayerBlockPlacement blockPlacement;
        if (packet.getPacket() instanceof C07PacketPlayerDigging && (packetPlayerDigging = (C07PacketPlayerDigging) packet.getPacket()).getStatus().equals((Object) C07PacketPlayerDigging.Action.RELEASE_USE_ITEM)) {
            this.isBlocking = false;
        }
        if (packet.getPacket() instanceof C08PacketPlayerBlockPlacement && (blockPlacement = (C08PacketPlayerBlockPlacement) packet.getPacket()).getStack() != null && blockPlacement.getStack().getItem() instanceof ItemSword && blockPlacement.getPosition().equals(new BlockPos(-1, -1, -1))) {
            this.isBlocking = true;
        }
	}
	
	private boolean getEntityValid(EntityLivingBase entity) {
        AntiBot antibots = (AntiBot) Client.getModuleManager().getModuleByClass(AntiBot.class);
        if (!mc.thePlayer.isEntityAlive()
                || mc.thePlayer.isPlayerSleeping()
                || mc.thePlayer.isDead
                || mc.thePlayer.getHealth() <= 0
                || mc.thePlayer.getDistanceToEntity(entity) > Range.getValue().floatValue()
                || !entity.isEntityAlive()
                || entity.isDead
                || entity.getHealth() <= 0
                || entity instanceof EntityArmorStand
                || Teams.isOnSameTeam(entity)
                //|| AntiBot.isServerBot(entity)
                ||entity == mc.thePlayer) {
            return false;
        }
        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) entity;
            if (FriendManager.isFriend(player.getName())) return false;
            if (!Players.getValue()) return false;

            if (player.isPlayerSleeping()) return false;
            //boolean wallChecks = (!throughWallValue.getValue() || mc.thePlayer.getDistanceToEntity(player) > wallRangeValue.getValue().floatValue());
            if (!RotationUtil.canEntityBeSeen(player)) return false;
            if (player.isPotionActive(Potion.invisibility) && !Invis.getValue()) return false;
        }

        if (entity instanceof EntityAnimal) {
            return Animals.getValue();
        }

        if (entity instanceof EntityMob) {
            return Mobs.getValue();
        }
        return true;
      
    }

	public static void drawCircle(EntityLivingBase entity, int color, EventRender3D e) {
		double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)e.getPartialTicks() - RenderManager.renderPosX;
		double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)e.getPartialTicks() - RenderManager.renderPosY;
		double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)e.getPartialTicks() - RenderManager.renderPosZ;
		float radius = 0.2f;
		int side = 4;
		GL11.glPushMatrix();
		GL11.glTranslated((double)x, (double)y + 2, (double)z);
		GL11.glRotatef((float)(-entity.width), (float)0.0f, (float)1.0f, (float)0.0f);
		glColor(color);
		enableSmoothLine(1.0f);
		Cylinder c = new Cylinder();
		GL11.glRotatef((float)-90.0f, (float)1.0f, (float)0.0f, (float)0.0f);

		c.setDrawStyle(100012);
		c.draw(0, radius, 0.3f, side, 1);

		c.setDrawStyle(100012);
		GL11.glTranslated(0, 0, 0.3);
		c.draw(radius, 0, 0.3f, side, 1);

//        glColor(-1);

		GL11.glRotatef((float)90.0f, (float)0.0f, (float)0.0f, (float)1.0f);

		c.setDrawStyle(100011);
		GL11.glTranslated(0, 0, -0.3);
		c.draw(0, radius, 0.3f, side, 1);

		c.setDrawStyle(100011);
		GL11.glTranslated(0, 0, 0.3);
		c.draw(radius, 0, 0.3f, side, 1);

		disableSmoothLine();
		GL11.glPopMatrix();
	}

	public static void glColor(int hex) {
		float alpha = (float)(hex >> 24 & 255) / 255.0f;
		float red = (float)(hex >> 16 & 255) / 255.0f;
		float green = (float)(hex >> 8 & 255) / 255.0f;
		float blue = (float)(hex & 255) / 255.0f;
		GL11.glColor4f((float)red, (float)green, (float)blue, (float)(alpha == 0.0f ? 1.0f : alpha));
	}

	public static void enableSmoothLine(float width) {
		GL11.glDisable((int)3008);
		GL11.glEnable((int)3042);
		GL11.glBlendFunc((int)770, (int)771);
		GL11.glDisable((int)3553);
		GL11.glDisable((int)2929);
		GL11.glDepthMask((boolean)false);
		GL11.glEnable((int)2884);
		GL11.glEnable((int)2848);
		GL11.glHint((int)3154, (int)4354);
		GL11.glHint((int)3155, (int)4354);
		GL11.glLineWidth((float)width);
	}

	public static void disableSmoothLine() {
		GL11.glEnable((int)3553);
		GL11.glEnable((int)2929);
		GL11.glDisable((int)3042);
		GL11.glEnable((int)3008);
		GL11.glDepthMask((boolean)true);
		GL11.glCullFace((int)1029);
		GL11.glDisable((int)2848);
		GL11.glHint((int)3154, (int)4352);
		GL11.glHint((int)3155, (int)4352);
	}
	public static boolean isOnSameTeam(Entity entity) {
		if (!Client.instance.getModuleManager().getModuleByClass(Killaura.class).isEnabled())
			return false;
		if (Minecraft.getMinecraft().thePlayer.getDisplayName().getUnformattedText().startsWith("\247")) {
			if (Minecraft.getMinecraft().thePlayer.getDisplayName().getUnformattedText().length() <= 2
					|| entity.getDisplayName().getUnformattedText().length() <= 2) {
				return false;
			}
			if (Minecraft.getMinecraft().thePlayer.getDisplayName().getUnformattedText().substring(0, 2)
					.equals(entity.getDisplayName().getUnformattedText().substring(0, 2))) {
				return true;
			}
		}
		return false;
	}


	static enum AuraMode {
		Switch,
		Single,
		Multi,
	}

	static enum AuraRotMode {
		GodLike,
		Exhibition;
	}
    static enum ESPMode {
        None,
        Jello,
        LiquidBounce,
        Cylinder,
        New,
        Rainbow;

    }
}

