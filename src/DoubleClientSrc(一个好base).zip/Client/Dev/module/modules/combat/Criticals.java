package Client.Dev.module.modules.combat;

import Client.Dev.Client;
import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventAttack;
import Client.Dev.api.events.world.EventPacket;
import Client.Dev.api.events.world.EventPacketSend;
import Client.Dev.api.events.world.EventPreUpdate;
import Client.Dev.api.value.Mode;
import Client.Dev.api.value.Numbers;
import Client.Dev.api.value.Option;
import Client.Dev.management.ModuleManager;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import Client.Dev.module.modules.movement.Flight;
import Client.Dev.module.modules.movement.Longjump;
import Client.Dev.module.modules.movement.Scaffold;
import Client.Dev.module.modules.movement.Speed;
import Client.Dev.utils.Helper;
import Client.Dev.utils.MoveUtils;
import Client.Dev.utils.MovementUtils;
import Client.Dev.utils.PlayerUtil;
import Client.Dev.utils.PlayerUtils;
import Client.Dev.utils.Stopwatch;
import Client.Dev.utils.TimerUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import net.minecraft.block.BlockLiquid;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.server.S2APacketParticles;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;

import org.apache.commons.lang3.RandomUtils;

public class Criticals
extends Module {
    public static Mode mode = new Mode("Mode", "Mode", (Enum[])CritMode.values(), (Enum)CritMode.GodLike);
	   private Numbers<Double> delay = new Numbers<Double>("Dealy","Delay",250.0,50.0,500.0,1.0);
    private TimerUtil timer = new TimerUtil();
    TimerUtil timer2 = new TimerUtil();
    private static List<EntityPlayer> invalid = new ArrayList();
    private static List<EntityPlayer> removed = new ArrayList();
    public Criticals() {
        super("Criticals", new String[]{"crits", "crit"}, ModuleType.Combat);
        this.setColor(new Color(235, 194, 138).getRGB());       
        this.addValues(this.mode,this.delay);
    }

    public void onEnable() {
        invalid.clear();
    }

    public void onDisable() {
        invalid.clear();
    }

    @EventHandler
    private void onUpdate(EventPreUpdate e) {
        this.setSuffix(this.mode.getValue());
    }

    private boolean canCrit() {
        if (this.mc.thePlayer.onGround && !this.mc.thePlayer.isInWater() && !Client.instance.getModuleManager().getModuleByClass(Speed.class).isEnabled()) {
            return true;
        }
        return false;
    }

    void doPacket() {
            if (this.timer.hasTimeElapsed(50.0D, true) && mc.thePlayer.isSwingInProgress) {
                double offsets[] = { 0.04114514, 0.02114514, 0.0114514, 0.000114514 };
                Arrays.stream(offsets).forEach(offset -> mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + offset, mc.thePlayer.posZ, false)));
                this.timer.reset();
        }
    }

    @EventHandler
    private void onPacket(EventPacketSend e) {
        double x = mc.thePlayer.posX;
        double y = mc.thePlayer.posY;
        double z = mc.thePlayer.posZ;
        if ( this.canCrit() && this.mode.getValue() == CritMode.GodLike) {
            Minecraft.thePlayer.motionY = 0.4;
        
        }

        





}

    


    	
	   
	 void Crit2(Double[] value) {
		NetworkManager var1 = mc.thePlayer.sendQueue.getNetworkManager();
		Double curX = mc.thePlayer.posX;
		Double curY = mc.thePlayer.posY;
		Double curZ = mc.thePlayer.posZ;
		for (Double offset : value) {
				var1.sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(curX, curY+offset, curZ, false));	
				var1.sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(curX, curY, curZ, true));
		}
	 }
    public static enum CritMode {
        GodLike,    
    }


	 }
	 