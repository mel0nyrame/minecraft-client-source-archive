/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.module.modules.combat;

import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventPreUpdate;
import Client.Dev.management.ModuleManager;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import Client.Dev.utils.InventoryUtils;
import Client.Dev.utils.TimerUtil;

import java.awt.Color;
import java.util.Comparator;
import java.util.Objects;
import java.util.Optional;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

public class AutoSword
extends Module {
    private ItemStack bestSword;
    private ItemStack prevBestSword;
    private boolean shouldSwitch = false;
    public TimerUtil timer = new TimerUtil();
//    private static Aura aura;
    int slotHB;

    public AutoSword() {
        super("AutoSword", new String[]{"autoweapon"}, ModuleType.Combat);
        this.setColor(new Color(208, 30, 142).getRGB());
    }
    
    @Override
    public void onEnable() {
    	//Chocola.protect();
//        if (this.aura == null) {
//            this.aura = (Aura) ModuleManager.getModuleByClass(Aura.class);
//        }
    }

    @EventHandler
    private void onUpdate(EventPreUpdate event) {
        if (Killaura.curtarget != null && ModuleManager.getModuleByName("Aura").isEnabled()) {
        	float damage = 1.0f;
            int bestSwordSlot = -1;
            for (int i = 0; i < 9; ++i) {
                float damageLevel;
                ItemStack itemStack = mc.thePlayer.inventory.getStackInSlot(i);
                if (itemStack == null || !(itemStack.getItem() instanceof ItemSword) || !((damageLevel = (float) getSwordDamage(itemStack)) > damage)) continue;
                damage = damageLevel;
                bestSwordSlot = i;
            }
            if (bestSwordSlot != -1) {
                mc.thePlayer.inventory.currentItem = bestSwordSlot;
            }
        }
    }

    private ItemStack getBestItem(Class<? extends Item> itemType, Comparator comparator) {
        Optional<ItemStack> bestItem = this.mc.thePlayer.inventoryContainer.inventorySlots.stream().map(Slot::getStack).filter(Objects::nonNull).filter(itemStack -> itemStack.getItem().getClass().equals((Object)itemType)).max(comparator);
        return bestItem.orElse(null);
    }

    private double getSwordDamage(ItemStack itemStack) {
        double damage = 0.0;
        Optional attributeModifier = itemStack.getAttributeModifiers().values().stream().findFirst();
        if (attributeModifier.isPresent()) {
            damage = ((AttributeModifier)attributeModifier.get()).getAmount();
        }
        return damage += (double)EnchantmentHelper.func_152377_a(itemStack, EnumCreatureAttribute.UNDEFINED);
    }
}

