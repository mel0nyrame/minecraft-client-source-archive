package Client.Dev.module.modules.movement;

import java.util.concurrent.*;
import net.minecraft.network.*;
import java.util.*;
import Client.Dev.module.*;
import java.awt.*;
import Client.Dev.api.events.misc.*;
import net.minecraft.util.*;
import Client.Dev.api.*;
import net.minecraft.client.*;
import net.minecraft.network.play.server.*;
import Client.Dev.module.modules.combat.*;
import net.minecraft.network.play.client.*;
import Client.Dev.api.events.world.*;
import Client.Dev.utils.*;

public class FreeCamTP extends Module
{
    private boolean tp;
    private float x;
    private float y;
    private float z;
    private boolean startblink;
    private TimerUtil blinktimer;
    private final LinkedBlockingQueue<Packet> packets;
    private boolean disableLogger;
    private final LinkedList<double[]> positions;
    
    public FreeCamTP() {
        super("FreeCamTP", new String[] { "freecamtp" }, ModuleType.Movement);
        this.tp = false;
        this.startblink = false;
        this.blinktimer = new TimerUtil();
        this.packets = new LinkedBlockingQueue<Packet>();
        this.positions = new LinkedList<double[]>();
        this.setColor(new Color(158, 205, 125).getRGB());
    }
    
    @EventHandler
    private void onBB(final EventCollideWithBlock e) {
        e.setBoundingBox(null);
    }
    
    @Override
    public void onEnable() {
        this.tp = false;
        this.startblink = false;
        this.blinktimer.reset();
        synchronized (this.positions) {
            final LinkedList<double[]> positions = this.positions;
            final double[] array = new double[3];
            final int n = 0;
            final Minecraft mc = FreeCamTP.mc;
            array[n] = Minecraft.thePlayer.posX;
            final int n2 = 1;
            final Minecraft mc2 = FreeCamTP.mc;
            final double minY = Minecraft.thePlayer.getEntityBoundingBox().minY;
            final Minecraft mc3 = FreeCamTP.mc;
            array[n2] = minY + Minecraft.thePlayer.getEyeHeight() / 2.0f;
            final int n3 = 2;
            final Minecraft mc4 = FreeCamTP.mc;
            array[n3] = Minecraft.thePlayer.posZ;
            positions.add(array);
            final LinkedList<double[]> positions2 = this.positions;
            final double[] array2 = new double[3];
            final int n4 = 0;
            final Minecraft mc5 = FreeCamTP.mc;
            array2[n4] = Minecraft.thePlayer.posX;
            final int n5 = 1;
            final Minecraft mc6 = FreeCamTP.mc;
            array2[n5] = Minecraft.thePlayer.getEntityBoundingBox().minY;
            final int n6 = 2;
            final Minecraft mc7 = FreeCamTP.mc;
            array2[n6] = Minecraft.thePlayer.posZ;
            positions2.add(array2);
        }
        this.startblink = true;
    }
    
    @Override
    public void onDisable() {
        this.tp = false;
        this.startblink = false;
    }
    
    @EventHandler
    private void onSendPacket(final EventPacketSend e) {
        final Packet<?> packet = (Packet<?>)e.getPacket();
        if (packet instanceof C03PacketPlayer && this.startblink && !this.tp) {
            e.setCancelled(true);
            final Minecraft mc = FreeCamTP.mc;
            if (Minecraft.thePlayer.ticksExisted % 2 == 0) {
                this.packets.add(packet);
            }
        }
    }
    
    @EventHandler
    private void onRecievePacket(final EventPacketRecieve e) {
        if (e.getPacket() instanceof S08PacketPlayerPosLook && !this.tp) {
            this.tp = true;
            this.startblink = false;
        }
    }
    
    @EventHandler
    private void onUpdate(final EventPreUpdate event) {
        Killaura.curtarget = null;
        if (this.startblink && !this.tp) {
            final Minecraft mc = FreeCamTP.mc;
            this.x = (float)Minecraft.thePlayer.posX;
            final Minecraft mc2 = FreeCamTP.mc;
            this.y = (float)Minecraft.thePlayer.posY;
            final Minecraft mc3 = FreeCamTP.mc;
            this.z = (float)Minecraft.thePlayer.posZ;
        }
        synchronized (this.positions) {
            final LinkedList<double[]> positions = this.positions;
            final double[] array = new double[3];
            final int n = 0;
            final Minecraft mc4 = FreeCamTP.mc;
            array[n] = Minecraft.thePlayer.posX;
            final int n2 = 1;
            final Minecraft mc5 = FreeCamTP.mc;
            array[n2] = Minecraft.thePlayer.getEntityBoundingBox().minY;
            final int n3 = 2;
            final Minecraft mc6 = FreeCamTP.mc;
            array[n3] = Minecraft.thePlayer.posZ;
            positions.add(array);
        }
        if (this.tp) {
            final Minecraft mc7 = FreeCamTP.mc;
            Minecraft.getNetHandler().addToSendQueue(new C0CPacketInput(0.0f, 0.0f, true, true));
            this.blink();
            this.setEnabled(false);
        }
    }
    
    @EventHandler
    private void onMove(final EventMove e) {
        final Minecraft mc = FreeCamTP.mc;
        Minecraft.thePlayer.motionY = 0.0;
        EventMove.y = 0.0;
        if (FreeCamTP.mc.gameSettings.keyBindJump.isKeyDown()) {
            final Minecraft mc2 = FreeCamTP.mc;
            Minecraft.thePlayer.motionY = 0.75;
            EventMove.y = 0.75;
        }
        else if (FreeCamTP.mc.gameSettings.keyBindSneak.isKeyDown()) {
            final Minecraft mc3 = FreeCamTP.mc;
            Minecraft.thePlayer.motionY = -0.75;
            EventMove.y = -0.75;
        }
        MovementUtils.setSpeed(e, 1.5);
    }
    
    private void blink() {
        try {
            this.disableLogger = true;
            while (!this.packets.isEmpty()) {
                final Minecraft mc = FreeCamTP.mc;
                Minecraft.getNetHandler().getNetworkManager().sendPacket(this.packets.take());
            }
            this.disableLogger = false;
        }
        catch (Exception e) {
            e.printStackTrace();
            this.disableLogger = false;
        }
        synchronized (this.positions) {
            this.positions.clear();
        }
    }
}
