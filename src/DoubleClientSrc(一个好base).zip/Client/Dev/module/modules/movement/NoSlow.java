package Client.Dev.module.modules.movement;

import Client.Dev.Client;
import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventPostUpdate;
import Client.Dev.api.events.world.EventPreUpdate;
import Client.Dev.api.value.Mode;
import Client.Dev.api.value.Numbers;
import Client.Dev.api.value.Option;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;

//import Client.Dev.module.modules.combat.Killaura;
import Client.Dev.module.modules.combat.Killaura;

import java.awt.Color;

import Client.Dev.utils.Helper;
import Client.Dev.utils.PlayerUtil;
import Client.Dev.utils.TimerUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class NoSlow
extends Module {
	public Option<Boolean> Ground = new Option("Ground", "Ground", Boolean.valueOf(true));
	public TimerUtil timer = new TimerUtil();
	private Mode<Enum> mode = new Mode("Mode", "Mode", (Enum[])JMode.values(), (Enum)JMode.WatchDog);
	   
    public NoSlow() {
        super("No Slow", new String[]{"NoSlow", "No Slow","NoSlowDown","No Slow Down"}, ModuleType.Movement);
        this.setColor(new Color(216, 253, 100).getRGB());
        this.addValues(mode,Ground);
    }

    @EventHandler
    private void onUpdate(EventPreUpdate e) {
        if (((Boolean)this.Ground.getValue()).booleanValue()) {
        if (!Minecraft.thePlayer.onGround) {
          return;  
        }
    }
        if (this.mode.getValue() == JMode.WatchDog2) {
        if (!(!this.mc.thePlayer.isBlocking() || Helper.onServer("invaded") || Helper.onServer("hypixel") || Helper.onServer("faithful") || Helper.onServer("mineman"))) {
            this.mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        }
    }      
        if (this.mode.getValue() == JMode.WatchDog) {
    	if (Minecraft.thePlayer.isBlocking() && PlayerUtil.isMoving()) {
            Minecraft.thePlayer.sendQueue.addToSendQueue((Packet)new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN)); 
        }
    }
        if (this.mode.getValue() == JMode.AAC)	{
        	if(mc.thePlayer.onGround || isOnGround(0.5))
				mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        }
      }
    
    
    @EventHandler
    public void onPost(EventPostUpdate event) {
        if (((Boolean)this.Ground.getValue()).booleanValue()) {
        if (!Minecraft.thePlayer.onGround) {
          return;  
        }
    }
        if (this.mode.getValue() == JMode.WatchDog) {
            return; 
        }
        if (this.mode.getValue() == JMode.WatchDog2) {
            return; 
    }
        if (this.mode.getValue() == JMode.AAC)	{
        	return;
        }
 }
    public static boolean isOnGround(double height) {
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        if (!Minecraft.theWorld.getCollidingBoundingBoxes((Entity)Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().offset(0.0D, -height, 0.0D)).isEmpty())
          return true; 
        return false;
      }
    
    enum JMode {
  WatchDog,WatchDog2,AAC;
  	}
}

