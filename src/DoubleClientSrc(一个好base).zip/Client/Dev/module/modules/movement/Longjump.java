package Client.Dev.module.modules.movement;

import Client.Dev.Client;
import Client.Dev.api.EventHandler;
import Client.Dev.api.events.misc.BoundingBoxEvent;
import Client.Dev.api.events.misc.EventCollideWithBlock;
import Client.Dev.api.events.world.*;
import Client.Dev.api.value.Mode;
import Client.Dev.api.value.Numbers;
import Client.Dev.api.value.Option;
import Client.Dev.management.ModuleManager;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
//import Client.Dev.module.modules.combat.Aura;
import Client.Dev.module.modules.combat.Killaura;
import Client.Dev.module.modules.movement.Scaffold;
//import Client.Dev.ui.notification.NotificationPublisher;
//import Client.Dev.ui.notification.NotificationType;
import Client.Dev.utils.Helper;
import Client.Dev.utils.MovementUtils;
import Client.Dev.utils.TimerUtil;
import Client.Dev.utils.math.MathUtil;
import net.minecraft.block.BlockAir;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.*;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;

import java.awt.*;
import java.util.LinkedList;
import java.util.concurrent.LinkedBlockingQueue;

public class Longjump
		extends Module {

	private int stage;
	private float groundTicks;
	private double moveSpeed;
	private double lastDist;
	
	public Longjump() {
		super("LongJump", new String[]{"lj"}, ModuleType.Movement);
		this.setColor(new Color(158, 114, 243).getRGB());
	}

	@Override
	public void onEnable() {
        if(mc.thePlayer == null) return;
        
        this.groundTicks = 0;
		this.moveSpeed = MovementUtils.getBaseMoveSpeed();
		this.stage = 0;
	}

	@Override
	public void onDisable() {
		
	}
	
	@EventHandler
	private void onRecievePacket(EventPacketRecieve e) {
		if (e.getPacket() instanceof S08PacketPlayerPosLook) {
			this.setEnabled(false);
		}
	}

	@EventHandler
	private void onUpdate(EventPreUpdate e) {
		
	}
	
	@EventHandler
	private void onTick(EventTick e) {
		
		final double xDist = this.mc.thePlayer.posX - this.mc.thePlayer.prevPosX;
		final double zDist = this.mc.thePlayer.posZ - this.mc.thePlayer.prevPosZ;
		this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
		if ((mc.thePlayer.moveForward != 0 || mc.thePlayer.moveStrafing != 0) && mc.thePlayer.onGround) {
			if (groundTicks > 0) {
				groundTicks = 0;
				setEnabled(false);
				return;
			}
		}
	}

	@EventHandler
	private void onMove(EventMove e) {
		if (!this.mc.thePlayer.onGround) {
			this.moveSpeed = MovementUtils.getBaseMoveSpeed() / 2.0;
		}
		if (this.stage == 1 && (this.mc.thePlayer.moveForward != 0.0f || this.mc.thePlayer.moveStrafing != 0.0f)) {
			this.stage = 2;
			this.moveSpeed = (1.8D * MovementUtils.getBaseMoveSpeed() - 0.01D) / 1.6D;
		} else if (this.stage == 2) {
			groundTicks++;
			PlayerCapabilities playerCapabilities = new PlayerCapabilities();
			playerCapabilities.isFlying = true;
//			playerCapabilities.allowFlying = true;
//			playerCapabilities.setFlySpeed((float) MathUtils.randomNumber(0.1, 9.0));
			
			mc.getNetHandler().addToSendQueue(new C0FPacketConfirmTransaction(0, (short)(-1), false));
			mc.getNetHandler().addToSendQueue(new C13PacketPlayerAbilities(playerCapabilities));
			this.stage = 3;
			e.setX(0);
			e.setZ(0);
			this.mc.thePlayer.motionY = 0.43993956416514;
			e.y = 0.43993956416514;
			this.moveSpeed *= 2.16D;
		} else if (this.stage == 3) {
			this.stage = 4;
			final double difference = 0.6 * (this.lastDist - MovementUtils.getBaseMoveSpeed());
			this.moveSpeed = (this.lastDist - difference) * 2.2D;
		} else {
			if (this.mc.theWorld.getCollidingBoundingBoxes(this.mc.thePlayer,
					this.mc.thePlayer.boundingBox.offset(0.0, this.mc.thePlayer.motionY, 0.0)).size() > 0
					|| this.mc.thePlayer.isCollidedVertically) {
				this.stage = 1;
			}
			this.moveSpeed = this.lastDist - this.lastDist / (mc.thePlayer.motionY < -0.1D ? 25 : 159);
		}
		this.moveSpeed = Math.max(this.moveSpeed, MovementUtils.getBaseMoveSpeed());
		MovementUtils.setSpeed(e, moveSpeed);
	}
}
