package Client.Dev.module.modules.movement;

import Client.Dev.module.*;
import Client.Dev.pathfinding.CustomVec3;
import Client.Dev.pathfinding.PathfindingUtils;

import java.awt.*;
import net.minecraft.client.*;
import net.minecraft.entity.player.*;
import net.minecraft.network.*;
import net.minecraft.client.network.*;
import net.minecraft.network.play.client.*;
import java.util.*;
import Client.Dev.api.*;
import Client.Dev.api.events.misc.*;
import net.minecraft.util.*;
import net.minecraft.util.Timer;
import Client.Dev.utils.*;
import Client.Dev.api.events.world.*;
import net.minecraft.network.play.server.*;

public class TeleportMod extends Module
{
    public static float x;
    public static float y;
    public static float z;
    public static boolean isTPPlayer;
    public static String playername;
    private CustomVec3 target;
    boolean tp;
    
    public TeleportMod() {
        super("Teleport", new String[] { "teleport" }, ModuleType.Movement);
        this.setColor(new Color(TeleportMod.random.nextInt(255), TeleportMod.random.nextInt(255), TeleportMod.random.nextInt(255)).getRGB());
        this.setRemoved(true);
    }
    
    @Override
    public void onEnable() {
        Helper.sendMessage("Please wait...");
        final Minecraft mc = TeleportMod.mc;
        if (Minecraft.thePlayer == null) {
            return;
        }
        this.tp = false;
        final PlayerCapabilities playerCapabilities = new PlayerCapabilities();
        playerCapabilities.isFlying = true;
        final Minecraft mc2 = TeleportMod.mc;
        Minecraft.getNetHandler().addToSendQueue(new C0FPacketConfirmTransaction(0, (short)(-1), false));
        final Minecraft mc3 = TeleportMod.mc;
        Minecraft.getNetHandler().addToSendQueue(new C13PacketPlayerAbilities(playerCapabilities));
        final Minecraft mc4 = TeleportMod.mc;
        final NetHandlerPlayClient netHandler = Minecraft.getNetHandler();
        final Minecraft mc5 = TeleportMod.mc;
        final double posX = Minecraft.thePlayer.posX;
        final Minecraft mc6 = TeleportMod.mc;
        final double posY = Minecraft.thePlayer.posY + 0.17;
        final Minecraft mc7 = TeleportMod.mc;
        netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, posY, Minecraft.thePlayer.posZ, true));
        final Minecraft mc8 = TeleportMod.mc;
        final NetHandlerPlayClient netHandler2 = Minecraft.getNetHandler();
        final Minecraft mc9 = TeleportMod.mc;
        final double posX2 = Minecraft.thePlayer.posX;
        final Minecraft mc10 = TeleportMod.mc;
        final double posY2 = Minecraft.thePlayer.posY + 0.06;
        final Minecraft mc11 = TeleportMod.mc;
        netHandler2.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX2, posY2, Minecraft.thePlayer.posZ, true));
        final Minecraft mc12 = TeleportMod.mc;
        Minecraft.thePlayer.stepHeight = 0.0f;
        final Minecraft mc13 = TeleportMod.mc;
        Minecraft.thePlayer.motionX = 0.0;
        final Minecraft mc14 = TeleportMod.mc;
        Minecraft.thePlayer.motionZ = 0.0;
    }
    
    @Override
    public void onDisable() {
        final Timer timer = TeleportMod.mc.timer;
        Timer.timerSpeed = 1.0f;
        final Minecraft mc = TeleportMod.mc;
        Minecraft.thePlayer.stepHeight = 0.625f;
        final Minecraft mc2 = TeleportMod.mc;
        Minecraft.thePlayer.motionX = 0.0;
        final Minecraft mc3 = TeleportMod.mc;
        Minecraft.thePlayer.motionZ = 0.0;
        TeleportMod.isTPPlayer = false;
        TeleportMod.playername = null;
    }
    
    @EventHandler
    public void onTick(final EventTick event) {
        if (TeleportMod.isTPPlayer) {
            final Minecraft mc = TeleportMod.mc;
            if (Minecraft.theWorld.getPlayerEntityByName(TeleportMod.playername) == null) {
                this.setEnabled(false);
                return;
            }
            final Minecraft mc2 = TeleportMod.mc;
            TeleportMod.x = (float)Minecraft.theWorld.getPlayerEntityByName(TeleportMod.playername).posX;
            final Minecraft mc3 = TeleportMod.mc;
            TeleportMod.y = (float)Minecraft.theWorld.getPlayerEntityByName(TeleportMod.playername).posY + 3.0f;
            final Minecraft mc4 = TeleportMod.mc;
            TeleportMod.z = (float)Minecraft.theWorld.getPlayerEntityByName(TeleportMod.playername).posZ;
        }
        if (this.tp) {
            final Minecraft mc5 = TeleportMod.mc;
            Minecraft.getNetHandler().addToSendQueue(new C0CPacketInput(0.0f, 0.0f, true, true));
            final Minecraft mc6 = TeleportMod.mc;
            double lastY = Minecraft.thePlayer.posY;
            double downY = 0.0;
            final Minecraft mc7 = TeleportMod.mc;
            final double posX = Minecraft.thePlayer.posX;
            final Minecraft mc8 = TeleportMod.mc;
            final double posY = Minecraft.thePlayer.posY;
            final Minecraft mc9 = TeleportMod.mc;
            for (final CustomVec3 vec3 : PathfindingUtils.computePath(new CustomVec3(posX, posY, Minecraft.thePlayer.posZ), new CustomVec3(TeleportMod.x, TeleportMod.y, TeleportMod.z))) {
                if (vec3.getY() < lastY) {
                    downY += lastY - vec3.getY();
                }
                if (downY > 2.5) {
                    downY = 0.0;
                    final Minecraft mc10 = TeleportMod.mc;
                    Minecraft.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(vec3.getX(), vec3.getY(), vec3.getZ(), true));
                }
                else {
                    final Minecraft mc11 = TeleportMod.mc;
                    Minecraft.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(vec3.getX(), vec3.getY(), vec3.getZ(), false));
                }
                lastY = vec3.getY();
            }
            final Minecraft mc12 = TeleportMod.mc;
            Minecraft.thePlayer.setPosition(TeleportMod.x, TeleportMod.y, TeleportMod.z);
            this.setEnabled(false);
        }
    }
    
    @EventHandler
    private void onBB(final EventCollideWithBlock e) {
        e.setBoundingBox(null);
    }
    
    @EventHandler
    public final void onMove(final EventMove event) {
        MovementUtils.setSpeed(event, 0.0);
        final Minecraft mc = TeleportMod.mc;
        Minecraft.thePlayer.motionY = 0.0;
        EventMove.y = 0.0;
    }
    
    @EventHandler
    public final void onSendPacket(final EventPacketSend event) {
        if (!this.tp && event.getPacket() instanceof C03PacketPlayer) {
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public final void onReceivePacket(final EventPacketRecieve event) {
        if (event.getPacket() instanceof S08PacketPlayerPosLook && !this.tp) {
            Helper.sendMessage("Teleport!");
            this.tp = true;
        }
    }
}
