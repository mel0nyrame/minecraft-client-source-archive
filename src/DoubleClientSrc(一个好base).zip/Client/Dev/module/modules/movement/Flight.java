package Client.Dev.module.modules.movement;

import java.util.concurrent.*;
import net.minecraft.network.*;
import java.util.*;
import net.minecraft.entity.boss.*;
import Client.Dev.module.*;
import java.awt.*;
import Client.Dev.api.value.*;
import net.minecraft.client.*;
import net.minecraft.entity.player.*;
import net.minecraft.client.network.*;
import net.minecraft.client.entity.*;
import net.minecraft.potion.*;
import Client.Dev.api.*;
import net.minecraft.network.play.server.*;
import Client.Dev.module.modules.combat.*;
import Client.Dev.management.*;
import net.minecraft.network.play.client.*;
import Client.Dev.api.events.world.*;
import Client.Dev.utils.*;
import Client.Dev.api.events.misc.*;
import net.minecraft.block.*;
import net.minecraft.util.*;
import net.minecraft.util.Timer;
import net.minecraft.item.*;
import Client.Dev.module.modules.world.*;

public class Flight extends Module
{
    public Option<Boolean> combat;
    public Option<Boolean> damage;
    public Option<Boolean> timer;
    private static Numbers<Double> timerspeed;
    private static Numbers<Double> timerduration;
    public Option<Boolean> teleport;
    public Option<Boolean> blink;
    public Option<Boolean> bob;
    private TimerUtil blinktimer;
    private final LinkedBlockingQueue<Packet> packets;
    private boolean disableLogger;
    private final LinkedList<double[]> positions;
    private EntityDragon dragon;
    private int boostHypixelState;
    private double moveSpeed;
    private double lastDistance;
	public Mode mode = new Mode("Mode", "Mode", (Enum[])FMode.values(), (Enum)FMode.Hypixel);
    private boolean failedStart;
    private double y;
    private int posYStage;
    private int flyTick;
    private final int boostTick = 12;
    private boolean tp;
    private boolean damaged;
    private TimerUtil tptimer;
    private TimerUtil timertimer;
    private TimerUtil c13timer;
    int tick;
    private TimerUtil motiononground;
    
    public Flight() {
        super("Flight", new String[] { "fly", "flight", "glide" }, ModuleType.Movement);
        this.combat = new Option<Boolean>("CombatSpoof", "CombatSpoof", true);
        this.damage = new Option<Boolean>("Damage", "Damage", true);
        this.timer = new Option<Boolean>("Timer", "Timer", false);
        this.teleport = new Option<Boolean>("Teleport", "Teleport", false);
        this.blink = new Option<Boolean>("Blink", "Blink", false);
        this.bob = new Option<Boolean>("Bob", "Bob", false);
        this.blinktimer = new TimerUtil();
        this.packets = new LinkedBlockingQueue<Packet>();
        this.positions = new LinkedList<double[]>();
        this.tp = false;
        this.damaged = false;
        this.tptimer = new TimerUtil();
        this.timertimer = new TimerUtil();
        this.c13timer = new TimerUtil();
        this.motiononground = new TimerUtil();
        this.setColor(new Color(158, 114, 243).getRGB());
        this.addValues(this.mode, this.combat, this.damage, this.timer, Flight.timerspeed, Flight.timerduration, this.teleport, this.blink, this.bob);
    }
    
    @Override
    public void onEnable() {
        PlayerCapabilities playerCapabilities;
        final Minecraft mc = Flight.mc;
        if (Minecraft.thePlayer == null) {
            return;
        }
        this.c13timer.reset();
        if (this.mode.getValue() == FMode.Hypixel) {
            playerCapabilities = new PlayerCapabilities();
            playerCapabilities.isFlying = true;

            if (this.blink.getValue()) {
                synchronized (this.positions) {
                    final LinkedList<double[]> positions = this.positions;
                    final double[] array = new double[3];
                    final int n = 0;
                    final Minecraft mc13 = Flight.mc;
                    array[n] = Minecraft.thePlayer.posX;
                    final int n2 = 1;
                    final Minecraft mc14 = Flight.mc;
                    final double minY = Minecraft.thePlayer.getEntityBoundingBox().minY;
                    final Minecraft mc15 = Flight.mc;
                    array[n2] = minY + Minecraft.thePlayer.getEyeHeight() / 2.0f;
                    final int n3 = 2;
                    final Minecraft mc16 = Flight.mc;
                    array[n3] = Minecraft.thePlayer.posZ;
                    positions.add(array);
                    final LinkedList<double[]> positions2 = this.positions;
                    final double[] array2 = new double[3];
                    final int n4 = 0;
                    final Minecraft mc17 = Flight.mc;
                    array2[n4] = Minecraft.thePlayer.posX;
                    final int n5 = 1;
                    final Minecraft mc18 = Flight.mc;
                    array2[n5] = Minecraft.thePlayer.getEntityBoundingBox().minY;
                    final int n6 = 2;
                    final Minecraft mc19 = Flight.mc;
                    array2[n6] = Minecraft.thePlayer.posZ;
                    positions2.add(array2);
                }
            }
            this.blinktimer.reset();
            final Minecraft mc20 = Flight.mc;
            if (!Minecraft.thePlayer.onGround) {
                return;
            }

            playerCapabilities.isFlying = true;
            final Minecraft mc21 = Flight.mc;
            Minecraft.thePlayer.sendQueue.addToSendQueue(new C0FPacketConfirmTransaction(0, (short)(-1), false));
            final Minecraft mc22 = Flight.mc;
            Minecraft.thePlayer.sendQueue.addToSendQueue(new C13PacketPlayerAbilities(playerCapabilities));
            if (this.damage.getValue()) {
                final double offset = 0.060100000351667404;
                final NetHandlerPlayClient netHandler = Minecraft.getNetHandler();
                final EntityPlayerSP player = Minecraft.thePlayer;
                final double x1 = player.posX;
                final double y1 = player.posY;
                final double z2 = player.posZ;
                for (int i = 0; i < getMaxFallDist() / 0.05510000046342611 + 1.0; ++i) {
                    netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x1, y1 + 0.060100000351667404, z2, false));
                    netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x1, y1 + 5.000000237487257E-4, z2, false));
                    netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x1, y1 + 0.004999999888241291 + 6.01000003516674E-8, z2, false));
                }
                netHandler.addToSendQueue(new C03PacketPlayer(true));
            }
            Minecraft.thePlayer.jump();
            Minecraft.thePlayer.posY += 0.42 + new Random().nextDouble() / 4666.0;
            this.boostHypixelState = 1;
            this.moveSpeed = 0.1;
            this.lastDistance = 0.0;
            this.failedStart = false;
            this.posYStage = 0;
            this.y = 0.0;
            this.flyTick = 0;
        }
    }
    
    public static float getMaxFallDist() {
        final PotionEffect potioneffect = Minecraft.thePlayer.getActivePotionEffect(Potion.jump);
        final int f = (potioneffect != null) ? (potioneffect.getAmplifier() + 1) : 0;
        return (float)(Minecraft.thePlayer.getMaxFallHeight() + f);
    }
    
    @Override
    public void onDisable() {
        final Minecraft mc = Flight.mc;
        if (Minecraft.thePlayer == null) {
            return;
        }
        if (this.blink.getValue()) {
            this.blink();
        }
        this.damaged = false;
        final Minecraft mc2 = Flight.mc;
        Minecraft.thePlayer.motionX = 0.0;
        final Minecraft mc3 = Flight.mc;
        Minecraft.thePlayer.motionZ = 0.0;
        final Minecraft mc4 = Flight.mc;
        Minecraft.thePlayer.capabilities.isFlying = false;
        final Minecraft mc5 = Flight.mc;
        final EntityPlayerSP thePlayer = Minecraft.thePlayer;
        final Minecraft mc6 = Flight.mc;
        final double posX = Minecraft.thePlayer.posX;
        final Minecraft mc7 = Flight.mc;
        final double posY = Minecraft.thePlayer.posY;
        final Minecraft mc8 = Flight.mc;
        thePlayer.setPosition(posX, posY, Minecraft.thePlayer.posZ);
        final Timer timer = Flight.mc.timer;
        Timer.timerSpeed = 1.0f;
        final Minecraft mc9 = Flight.mc;
        Minecraft.thePlayer.stepHeight = 0.5f;
        final Minecraft mc10 = Flight.mc;
        Minecraft.thePlayer.speedInAir = 0.02f;
    }
    
    @EventHandler
    private void onSendPacket(final EventPacketSend e) {
        final Packet<?> packet = (Packet<?>)e.getPacket();
        if (packet instanceof C03PacketPlayer && this.mode.getValue() == FMode.Hypixel && this.damaged) {
            ((C03PacketPlayer)packet).onGround = false;
        }
        if (this.mode.getValue() == FMode.Hypixel && this.blink.getValue()) {
            final Minecraft mc = Flight.mc;
            if (Minecraft.thePlayer == null || this.disableLogger) {
                return;
            }
            if (packet instanceof C03PacketPlayer) {
                e.setCancelled(true);
            }
            if (packet instanceof C03PacketPlayer.C04PacketPlayerPosition || packet instanceof C03PacketPlayer.C06PacketPlayerPosLook || packet instanceof C08PacketPlayerBlockPlacement || packet instanceof C0APacketAnimation || packet instanceof C0BPacketEntityAction || packet instanceof C02PacketUseEntity) {
                e.setCancelled(true);
                this.packets.add(packet);
            }
        }
        }

    
    @EventHandler
    private void onRecievePacket(final EventPacketRecieve e) {
        if (this.mode.getValue() == FMode.Hypixel && e.getPacket() instanceof S08PacketPlayerPosLook) {
            this.failedStart = true;
            this.setEnabled(false);
        }

        }
    
   
    @EventHandler
    private void onUpdate(final EventPreUpdate e) {
        this.setSuffix(this.mode.getValue());
        if (this.combat.getValue()) {
            Killaura.curtarget = null;
        }
        if (ModuleManager.getModuleByName("Scaffold").isEnabled() && (this.getBlockCount() > 0 || this.getallBlockCount() > 0)) {
            this.setEnabled(false);
        }
        final Minecraft mc = Flight.mc;
        if (Minecraft.thePlayer.ticksExisted % 3 == 0) {
            final Minecraft mc2 = Flight.mc;
            final EntityPlayerSP thePlayer = Minecraft.thePlayer;
            final Minecraft mc3 = Flight.mc;
            final double posX = Minecraft.thePlayer.posX;
            final Minecraft mc4 = Flight.mc;
            final double posY = Minecraft.thePlayer.posY;
            final Minecraft mc5 = Flight.mc;
            thePlayer.setPosition(posX, posY, Minecraft.thePlayer.posZ);
            switch (++this.tick) {
                case 1: {
                    final Minecraft mc6 = Flight.mc;
                    final EntityPlayerSP thePlayer2 = Minecraft.thePlayer;
                    final Minecraft mc7 = Flight.mc;
                    final double posX2 = Minecraft.thePlayer.posX;
                    final Minecraft mc8 = Flight.mc;
                    final double y = Minecraft.thePlayer.posY + 1.0E-4;
                    final Minecraft mc9 = Flight.mc;
                    thePlayer2.setPosition(posX2, y, Minecraft.thePlayer.posZ);
                    break;
                }
                case 2: {
                    final Minecraft mc10 = Flight.mc;
                    final EntityPlayerSP thePlayer3 = Minecraft.thePlayer;
                    final Minecraft mc11 = Flight.mc;
                    final double posX3 = Minecraft.thePlayer.posX;
                    final Minecraft mc12 = Flight.mc;
                    final double y2 = Minecraft.thePlayer.posY + 1.0E-4;
                    final Minecraft mc13 = Flight.mc;
                    thePlayer3.setPosition(posX3, y2, Minecraft.thePlayer.posZ);
                    break;
                }
                case 3: {
                    final Minecraft mc14 = Flight.mc;
                    final EntityPlayerSP thePlayer4 = Minecraft.thePlayer;
                    final Minecraft mc15 = Flight.mc;
                    final double posX4 = Minecraft.thePlayer.posX;
                    final Minecraft mc16 = Flight.mc;
                    final double y3 = Minecraft.thePlayer.posY - 2.0E-4;
                    final Minecraft mc17 = Flight.mc;
                    thePlayer4.setPosition(posX4, y3, Minecraft.thePlayer.posZ);
                    break;
                }
                case 4: {
                    final Minecraft mc18 = Flight.mc;
                    final EntityPlayerSP thePlayer5 = Minecraft.thePlayer;
                    final Minecraft mc19 = Flight.mc;
                    final double posX5 = Minecraft.thePlayer.posX;
                    final Minecraft mc20 = Flight.mc;
                    final double y4 = Minecraft.thePlayer.posY + 1.0E-4;
                    final Minecraft mc21 = Flight.mc;
                    thePlayer5.setPosition(posX5, y4, Minecraft.thePlayer.posZ);
                    break;
                }
                case 5: {
                    final Minecraft mc22 = Flight.mc;
                    final EntityPlayerSP thePlayer6 = Minecraft.thePlayer;
                    final Minecraft mc23 = Flight.mc;
                    final double posX6 = Minecraft.thePlayer.posX;
                    final Minecraft mc24 = Flight.mc;
                    final double y5 = Minecraft.thePlayer.posY + 1.0E-4;
                    final Minecraft mc25 = Flight.mc;
                    thePlayer6.setPosition(posX6, y5, Minecraft.thePlayer.posZ);
                    break;
                }
                case 6: {
                    final Minecraft mc26 = Flight.mc;
                    final EntityPlayerSP thePlayer7 = Minecraft.thePlayer;
                    final Minecraft mc27 = Flight.mc;
                    final double posX7 = Minecraft.thePlayer.posX;
                    final Minecraft mc28 = Flight.mc;
                    final double y6 = Minecraft.thePlayer.posY + 1.0E-4;
                    final Minecraft mc29 = Flight.mc;
                    thePlayer7.setPosition(posX7, y6, Minecraft.thePlayer.posZ);
                    break;
                }
                case 7: {
                    final Minecraft mc30 = Flight.mc;
                    final EntityPlayerSP thePlayer8 = Minecraft.thePlayer;
                    final Minecraft mc31 = Flight.mc;
                    final double posX8 = Minecraft.thePlayer.posX;
                    final Minecraft mc32 = Flight.mc;
                    final double y7 = Minecraft.thePlayer.posY - 3.0E-4;
                    final Minecraft mc33 = Flight.mc;
                    thePlayer8.setPosition(posX8, y7, Minecraft.thePlayer.posZ);
                    break;
                }
                case 8: {
                    final Minecraft mc34 = Flight.mc;
                    final EntityPlayerSP thePlayer9 = Minecraft.thePlayer;
                    final Minecraft mc35 = Flight.mc;
                    final double posX9 = Minecraft.thePlayer.posX;
                    final Minecraft mc36 = Flight.mc;
                    final double y8 = Minecraft.thePlayer.posY + 1.0E-4;
                    final Minecraft mc37 = Flight.mc;
                    thePlayer9.setPosition(posX9, y8, Minecraft.thePlayer.posZ);
                    break;
                }
                case 9: {
                    final Minecraft mc38 = Flight.mc;
                    final EntityPlayerSP thePlayer10 = Minecraft.thePlayer;
                    final Minecraft mc39 = Flight.mc;
                    final double posX10 = Minecraft.thePlayer.posX;
                    final Minecraft mc40 = Flight.mc;
                    final double y9 = Minecraft.thePlayer.posY + 1.0E-4;
                    final Minecraft mc41 = Flight.mc;
                    thePlayer10.setPosition(posX10, y9, Minecraft.thePlayer.posZ);
                    break;
                }
                case 10: {
                    final Minecraft mc42 = Flight.mc;
                    final EntityPlayerSP thePlayer11 = Minecraft.thePlayer;
                    final Minecraft mc43 = Flight.mc;
                    final double posX11 = Minecraft.thePlayer.posX;
                    final Minecraft mc44 = Flight.mc;
                    final double y10 = Minecraft.thePlayer.posY - 2.0E-4;
                    final Minecraft mc45 = Flight.mc;
                    thePlayer11.setPosition(posX11, y10, Minecraft.thePlayer.posZ);
                    this.tick = 0;
                    break;
                }
            }
        }
        if (!this.failedStart) {
            final Minecraft mc46 = Flight.mc;
            Minecraft.thePlayer.motionY = 0.0;
        }
        if (this.blink.getValue()) {
            synchronized (this.positions) {
                final LinkedList<double[]> positions = this.positions;
                final double[] array = new double[3];
                final int n = 0;
                final Minecraft mc47 = Flight.mc;
                array[n] = Minecraft.thePlayer.posX;
                final int n2 = 1;
                final Minecraft mc48 = Flight.mc;
                array[n2] = Minecraft.thePlayer.getEntityBoundingBox().minY;
                final int n3 = 2;
                final Minecraft mc49 = Flight.mc;
                array[n3] = Minecraft.thePlayer.posZ;
                positions.add(array);
            }
            final TimerUtil blinktimer = this.blinktimer;
            final float n4 = 500.0f;
            final Timer timer = Flight.mc.timer;
            if (blinktimer.hasReached(n4 / Timer.timerSpeed)) {
                this.blink();
                this.blinktimer.reset();
            }
        }
    }
    
    @EventHandler
    private void onTick(final EventTick e) {
        if (this.mode.getValue() == FMode.Hypixel) {
            final Minecraft mc = Flight.mc;
            Minecraft.getNetHandler().addToSendQueue(new C0FPacketConfirmTransaction(Integer.MAX_VALUE, (short)(-1), false));
            final Minecraft mc2 = Flight.mc;
            Minecraft.getNetHandler().addToSendQueue(new C0CPacketInput());
            if (this.teleport.getValue() && !this.tptimer.hasReached(250.0) && this.damage.getValue() && this.damaged) {
                final Timer timer = Flight.mc.timer;
                Timer.timerSpeed = 6.0f;
                this.timertimer.reset();
            }
            else {
                final Timer timer2 = Flight.mc.timer;
                Timer.timerSpeed = 1.0f;
                if (this.timer.getValue() && this.damage.getValue() && this.damaged) {
                    final Timer timer3 = Flight.mc.timer;
                    Timer.timerSpeed = (this.timertimer.hasReached((double)Flight.timerduration.getValue().longValue()) ? 1.0f : Flight.timerspeed.getValue().floatValue());
                }
            }
        }
    }
    
    @EventHandler
    public void onPost(final EventPostUpdate e) {
        final Minecraft mc = Flight.mc;
        final double posX = Minecraft.thePlayer.posX;
        final Minecraft mc2 = Flight.mc;
        final double xDist = posX - Minecraft.thePlayer.prevPosX;
        final Minecraft mc3 = Flight.mc;
        final double posZ = Minecraft.thePlayer.posZ;
        final Minecraft mc4 = Flight.mc;
        final double zDist = posZ - Minecraft.thePlayer.prevPosZ;
        this.lastDistance = Math.sqrt(xDist * xDist + zDist * zDist);
    }
    
    @EventHandler
    private void onMove(final EventMove e) {
        if (this.mode.getValue() == FMode.Motion) {
            if (this.motiononground.hasReached(5000.0)) {
                final Minecraft mc = Flight.mc;
                final NetHandlerPlayClient netHandler = Minecraft.getNetHandler();
                final Minecraft mc2 = Flight.mc;
                final double posX = Minecraft.thePlayer.posX;
                final Minecraft mc3 = Flight.mc;
                final double posY = Minecraft.thePlayer.posY;
                final Minecraft mc4 = Flight.mc;
                netHandler.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, posY, Minecraft.thePlayer.posZ, true));
                this.motiononground.reset();
            }
            final Minecraft mc5 = Flight.mc;
            Minecraft.thePlayer.motionY = 0.0;
            EventMove.y = 0.0;
            if (Flight.mc.gameSettings.keyBindJump.isKeyDown()) {
                final Minecraft mc6 = Flight.mc;
                Minecraft.thePlayer.motionY = 2.0;
                EventMove.y = 2.0;
            }
            else if (Flight.mc.gameSettings.keyBindSneak.isKeyDown()) {
                final Minecraft mc7 = Flight.mc;
                Minecraft.thePlayer.motionY = -2.0;
                EventMove.y = -2.0;
            }
            MovementUtils.setSpeed(e, 2.5);
        }
        if (this.mode.getValue() == FMode.Hypixel) {
            final Minecraft mc8 = Flight.mc;
            if (!Minecraft.thePlayer.moving()) {
                MovementUtils.setSpeed(e, 0.0);
                return;
            }
            if (this.bob.getValue()) {
                final Minecraft mc9 = Flight.mc;
                Minecraft.thePlayer.cameraYaw = 0.095f;
            }
            if (this.failedStart) {
                return;
            }
            final Minecraft mc10 = Flight.mc;
            if (!Minecraft.thePlayer.moving()) {
                EventMove.x = 0.0;
                EventMove.z = 0.0;
                return;
            }
            final double n = 1.0;
            final Minecraft mc11 = Flight.mc;
            double n3;
            if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
                final double n2 = 0.2;
                final Minecraft mc12 = Flight.mc;
                n3 = n2 * (Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1);
            }
            else {
                n3 = 0.0;
            }
            final double amplifier = n + n3;
            final double baseSpeed = 0.291 * amplifier;
            switch (this.boostHypixelState) {
                case 1: {
                    final Minecraft mc13 = Flight.mc;
                    this.moveSpeed = (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed) ? 1.56 : 2.034) * baseSpeed;
                    this.boostHypixelState = 2;
                    break;
                }
                case 2: {
                    this.moveSpeed *= 2.16;
                    this.boostHypixelState = 3;
                    break;
                }
                case 3: {
                    final double lastDistance = this.lastDistance;
                    final Minecraft mc14 = Flight.mc;
                    this.moveSpeed = lastDistance - ((Minecraft.thePlayer.ticksExisted % 2 == 0) ? 0.0103 : 0.0123) * (this.lastDistance - baseSpeed);
                    this.boostHypixelState = 4;
                    break;
                }
                default: {
                    this.moveSpeed = this.lastDistance - this.lastDistance / 159.9;
                    break;
                }
            }
            this.moveSpeed = Math.max(this.moveSpeed, 0.3);
            if (TargetStrafe.canStrafe()) {
                TargetStrafe.strafe(e, this.moveSpeed);
            }
            else {
                MovementUtils.setSpeed(e, this.moveSpeed);
            }
        }
        }

    @EventHandler
    public void onBB(final EventCollideWithBlock event) {
        if (this.mode.getValue() == FMode.Hypixel) {
            final Minecraft mc = Flight.mc;
            if (Minecraft.thePlayer == null) {
                return;
            }
            if (event.getBlock() instanceof BlockAir) {
                final double n = event.getPos().getY();
                final Minecraft mc2 = Flight.mc;
                if (n < Minecraft.thePlayer.posY) {
                    final double x1 = event.getPos().getX();
                    final double y1 = event.getPos().getY();
                    final double z1 = event.getPos().getZ();
                    final double x2 = event.getPos().getX() + 1;
                    final Minecraft mc3 = Flight.mc;
                    event.setBoundingBox(AxisAlignedBB.fromBounds(x1, y1, z1, x2, Minecraft.thePlayer.posY, event.getPos().getZ() + 1));
                }
            }
        }
    }
    
    public int getBlockCount() {
        int n = 0;
        for (int i = 36; i < 45; ++i) {
            final Minecraft mc = Flight.mc;
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                final Minecraft mc2 = Flight.mc;
                final ItemStack stack = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                final Item item = stack.getItem();
                if (stack.getItem() instanceof ItemBlock && this.isValid(item)) {
                    n += stack.stackSize;
                }
            }
        }
        return n;
    }
    
    private boolean isValid(final Item item) {
        return item instanceof ItemBlock ;
    }
    
    public int getallBlockCount() {
        int n = 0;
        for (int i = 0; i < 36; ++i) {
            final Minecraft mc = Flight.mc;
            if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                final Minecraft mc2 = Flight.mc;
                final ItemStack stack = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
                final Item item = stack.getItem();
                if (stack.getItem() instanceof ItemBlock && this.isValid(item)) {
                    n += stack.stackSize;
                }
            }
        }
        return n;
    }
    
    double getBaseMoveSpeed() {
        double baseSpeed = 0.275;
        final Minecraft mc = Flight.mc;
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            final Minecraft mc2 = Flight.mc;
            final int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (amplifier + 1);
        }
        return baseSpeed;
    }
    
    private void blink() {
        if (!this.blink.getValue()) {
            return;
        }
        try {
            this.disableLogger = true;
            while (!this.packets.isEmpty()) {
                final Minecraft mc = Flight.mc;
                Minecraft.getNetHandler().getNetworkManager().sendPacket(this.packets.take());
            }
            this.disableLogger = false;
        }
        catch (Exception e) {
            e.printStackTrace();
            this.disableLogger = false;
        }
        synchronized (this.positions) {
            this.positions.clear();
        }
    }
    
    static {
        Flight.timerspeed = new Numbers<Double>("TimerSpeed", "TimerSpeed", 1.5, 1.0, 3.0, 0.1);
        Flight.timerduration = new Numbers<Double>("TimerDuration", "TimerDuration", 1000.0, 100.0, 2000.0, 100.0);
    }
    
    public enum FMode
    {
        Motion, 
        Hypixel;
    }
}
