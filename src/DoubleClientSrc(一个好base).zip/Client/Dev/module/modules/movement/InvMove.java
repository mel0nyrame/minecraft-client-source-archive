package Client.Dev.module.modules.movement;

import Client.Dev.api.Event;
import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventPacket;
import Client.Dev.api.events.world.EventPreUpdate;
import Client.Dev.api.value.Option;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;


import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

import org.lwjgl.input.Keyboard;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;

public class InvMove extends Module {


	boolean lastInvOpen = false;
	boolean invOpen = false;
	boolean inInventory = false;



	public InvMove() {
		super("InvMove", new String[] {"invmove", "invwalk", "inventorymove", "inventorywalk"}, ModuleType.Movement);
        this.setColor(new Color(235, 194, 138).getRGB());

	}

    

    

    
	@EventHandler
	public void onUpdate(EventPreUpdate event) {
		if (this.mc.currentScreen != null && !(this.mc.currentScreen instanceof GuiChat)) {
			KeyBinding[] key = { this.mc.gameSettings.keyBindForward, this.mc.gameSettings.keyBindBack,
					this.mc.gameSettings.keyBindLeft, this.mc.gameSettings.keyBindRight,
					this.mc.gameSettings.keyBindSprint, this.mc.gameSettings.keyBindJump };
			KeyBinding[] array;
			for (int length = (array = key).length, i = 0; i < length; ++i) {
				KeyBinding b = array[i];
				KeyBinding.setKeyBindState(b.getKeyCode(), Keyboard.isKeyDown(b.getKeyCode()));
			}
		}
	}
}
