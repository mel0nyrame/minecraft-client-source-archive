package Client.Dev.module.modules.movement;

import Client.Dev.Client;
import Client.Dev.api.Event;
import Client.Dev.api.EventHandler;
import Client.Dev.api.events.rendering.EventRender2D;
import Client.Dev.api.events.rendering.EventRender3D;
import Client.Dev.api.events.world.EventMove;
import Client.Dev.api.events.world.EventPacketRecieve;
import Client.Dev.api.events.world.EventPacketSend;
import Client.Dev.api.events.world.EventPostUpdate;
import Client.Dev.api.events.world.EventPreUpdate;
import Client.Dev.api.value.Mode;
import Client.Dev.api.value.Option;
import Client.Dev.management.ModuleManager;
import Client.Dev.module.Module;
import Client.Dev.module.ModuleType;
import Client.Dev.module.modules.combat.Killaura;
import Client.Dev.module.modules.movement.Speed;
import Client.Dev.module.modules.movement.ScaffoldModule.Rotation;
import Client.Dev.ui.font.CFontRenderer;
import Client.Dev.ui.font.FontLoaders;
import Client.Dev.utils.BlockUtil;
import Client.Dev.utils.Helper;
import Client.Dev.utils.InventoryUtils;
import Client.Dev.utils.MoveUtils;
import Client.Dev.utils.PlayerUtil;
import Client.Dev.utils.RenderUtils;
import Client.Dev.utils.RotationUtils;
import Client.Dev.utils.math.RotationUtil;
import Client.Dev.utils.render.Colors;
import Client.Dev.utils.render.RenderUtil;

import java.awt.Color;
import java.util.Arrays;
import java.util.List;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockCarpet;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.BlockSkull;
import net.minecraft.block.BlockSnow;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.server.S2FPacketSetSlot;
import net.minecraft.stats.StatList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class Scaffold extends Module {

	private Mode<Enum> mode = new Mode("Mode", "Mode", (Enum[]) ScMode.values(), (Enum) ScMode.Normal);
	private Mode<Enum> tower = new Mode("Tower", "Tower", (Enum[]) TWMod.values(), (Enum) TWMod.Normal);
	private Option silent = new Option("Silent", "Silent", false);
	private Option ShowBlocks = new Option("Render Remainder Blocks", "RRB", false);
	private static List invalid;
	public static BlockCache blockCache;
	private int currentItem;
	float yaw;
	public static float pitch;
	public static int fucku = 0;
	private int width = 120;

	public Scaffold() {
		super("Scaffold", new String[] { "autosword" }, ModuleType.Movement);
		this.addValues(this.tower, this.silent, this.mode);
		this.currentItem = 0;
		this.setColor((new Color(244, 119, 194)).getRGB());
	}

	public void onEnable() {
		this.currentItem = this.mc.thePlayer.inventory.currentItem;
	}

	public void onDisable() {
		this.mc.thePlayer.inventory.currentItem = this.currentItem;
		fucku = 0;
	}

	@EventHandler
	private void onUpdate(EventMove e) {
		if (mc.gameSettings.keyBindSprint.isKeyDown()) {
			this.mc.thePlayer.setMoveSpeed(e, 0.15);
			if(mc.thePlayer.isSprinting()) {
				mc.thePlayer.setSprinting(false);
			}
			if(!mc.thePlayer.onGround) {
				this.mc.thePlayer.setMoveSpeed(e, 0.0);
			}
		}
	}

	@EventHandler
	private void onUpdate(EventPreUpdate event) {
		this.setSuffix(this.mode.getValue());
		if (this.grabBlockSlot() == -1) {
			Helper.sendMessage((String) "No Blocks!");
			this.setEnabled(false);
		}
		if (this.grabBlockSlot() != -1 && fucku == 1) {
			Minecraft.thePlayer.renderYawOffset = yaw;
			Minecraft.thePlayer.rotationYawHead = yaw;
			event.setYaw(yaw);
			event.setPitch(pitch);
			//Minecraft.thePlayer.prevRenderArmPitch=pitch;
		}
		if (mc.gameSettings.keyBindSprint.isKeyDown()&&mc.thePlayer.onGround) {
				return;
			}
			if (this.grabBlockSlot() != -1) {
				this.blockCache = grab();
				if (this.blockCache != null) {
					fucku = 1;
					float[] rotations = RotationUtil.grabBlockRotations(BlockCache.access$0(this.blockCache));
					yaw = rotations[0];
					// pitch=90;
					pitch = RotationUtil.getVecRotation(this.grabPosition(BlockCache.access$0(this.blockCache),
							BlockCache.access$1(this.blockCache)))[1] - 3.0F;
					// System.out.println(pitch);
					mc.thePlayer.swingItem();
				}
			}
		}

	@EventHandler
	private void renderHud(EventRender2D event) {
		CFontRenderer fr = FontLoaders.kiona20;
		fr.drawString("Blocks:" + this.currentItem, this.width, (float)(new ScaledResolution(mc).getScaledHeight() / 2 + 5), -1);
	}

	@EventHandler
	private void onPostUpdate(EventPostUpdate event) {
		if (this.blockCache != null) {
			if ( this.tower.getValue() == TWMod.Normal) {
				BlockPos underPos = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ);
				Block underBlock = mc.theWorld.getBlockState(underPos).getBlock();
				if (this.mc.thePlayer.moving() && !this.mc.gameSettings.keyBindJump.pressed) {
					if (isOnGround(0.76) && !isOnGround(0.75) && mc.thePlayer.motionY > 0.23
							&& mc.thePlayer.motionY < 0.25) {
						mc.thePlayer.motionY = (Math.round(mc.thePlayer.posY) - mc.thePlayer.posY);
					}
					if (isOnGround(0.0001)) {
						mc.thePlayer.motionX *= 0.9;
						mc.thePlayer.motionZ *= 0.9;
					} else if (mc.thePlayer.posY >= Math.round(mc.thePlayer.posY) - 0.0001
							&& mc.thePlayer.posY <= Math.round(mc.thePlayer.posY) + 0.0001) {
						mc.thePlayer.motionY = 0;
					}
				} else if (!this.mc.thePlayer.moving() && this.mc.gameSettings.keyBindJump.pressed) {
					mc.thePlayer.motionX = 0;
					mc.thePlayer.motionZ = 0;
					mc.thePlayer.jumpMovementFactor = 0;
					if (isAirBlock(underBlock)) {
						mc.thePlayer.motionY = 0.4196;
						mc.thePlayer.motionX *= 0.75;
						mc.thePlayer.motionZ *= 0.75;
					}
				}
			}

			if(this.tower.getValue() == TWMod.AAC4){
				mc.timer.timerSpeed = 0.97f;
				if (mc.thePlayer.onGround) {
					fakeJump();
					mc.thePlayer.motionY = 0.387565;
					mc.timer.timerSpeed = 1.05f;
				}
			}

			int currentSlot = this.mc.thePlayer.inventory.currentItem;
			int slot = this.grabBlockSlot();
			this.mc.thePlayer.inventory.currentItem = slot;
			mc.playerController.updateController();

			if (this.placeBlock(BlockCache.access$2(this.blockCache), BlockCache.access$3(this.blockCache))) {
				if (((Boolean) this.silent.getValue()).booleanValue()) {
					this.mc.thePlayer.inventory.currentItem = currentSlot;
					mc.playerController.updateController();
					this.mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(currentSlot));
				}

				this.blockCache = null;
			}

		}
	}

	private void fakeJump() {
		mc.thePlayer.isAirBorne = true;
		mc.thePlayer.triggerAchievement(StatList.jumpStat);
	}

	private boolean isOnGround(double d) {
		return false;
	}

	public boolean isAirBlock(Block block) {
		if (block.getMaterial().isReplaceable()) {
			if (block instanceof BlockSnow && block.getBlockBoundsMaxY() > 0.125) {
				return false;
			}
			return true;
		}

		return false;
	}

	private boolean placeBlock(BlockPos pos, EnumFacing facing) {
		new Vec3(this.mc.thePlayer.posX, this.mc.thePlayer.posY + (double) this.mc.thePlayer.getEyeHeight(),
				this.mc.thePlayer.posZ);
		if (this.mc.playerController.onPlayerRightClick(this.mc.thePlayer, this.mc.theWorld,
				this.mc.thePlayer.getHeldItem(), pos, facing,
				(new Vec3(BlockCache.access$2(this.blockCache))).addVector(0.5D, 0.5D, 0.5D)
						.add((new Vec3(BlockCache.access$3(this.blockCache).getDirectionVec())).scale(0.5D)))) {
			this.mc.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
			return true;
		} else {
			return false;
		}
	}

	private Vec3 grabPosition(BlockPos position, EnumFacing facing) {
		Vec3 offset = new Vec3((double) facing.getDirectionVec().getX() / 2.0D,
				(double) facing.getDirectionVec().getY() / 2.0D, (double) facing.getDirectionVec().getZ() / 2.0D);
		Vec3 point = new Vec3((double) position.getX() + 0.5D, (double) position.getY() + 0.5D,
				(double) position.getZ() + 0.5D);
		return point.add(offset);
	}

	private BlockCache grab() {
		double x = mc.thePlayer.posX;
		double y = mc.thePlayer.posY - 0.8;
		double z = mc.thePlayer.posZ;
		double forward = this.mc.thePlayer.movementInput.moveForward;
		double strafe = this.mc.thePlayer.movementInput.moveStrafe;
		float yaw = this.mc.thePlayer.rotationYaw;
		x += (forward * 0.4 * Math.cos(Math.toRadians(yaw + 90.0f))
				+ strafe * 0.4 * Math.sin(Math.toRadians(yaw + 90.0f)));
		z += (forward * 0.4 * Math.sin(Math.toRadians(yaw + 90.0f))
				- strafe * 0.4 * Math.cos(Math.toRadians(yaw + 90.0f)));
		BlockPos blockBelow = new BlockPos(x, y, z);
		BlockPos blockBelow1 = new BlockPos(x, y, z);

		EnumFacing[] invert = new EnumFacing[] { EnumFacing.UP, EnumFacing.DOWN, EnumFacing.SOUTH, EnumFacing.NORTH,
				EnumFacing.EAST, EnumFacing.WEST };
		BlockPos position = new BlockPos(Minecraft.thePlayer.getPositionVector()).down();
		if (!(Minecraft.theWorld.getBlockState(position).getBlock() instanceof BlockAir)) {
			return null;
		}
		EnumFacing[] var6 = EnumFacing.values();
		int var5 = var6.length;
		int offset = 0;
		while (offset < var5) {
			EnumFacing offsets = var6[offset];
			BlockPos offset1 = position.offset(offsets);
			Minecraft.theWorld.getBlockState(offset1);
			if (!(Minecraft.theWorld.getBlockState(offset1).getBlock() instanceof BlockAir)) {
				return new BlockCache(this, offset1, invert[offsets.getIndex()], null);
			}
			++offset;
		}
		BlockPos[] var16;
		BlockPos[] var19 = var16 = new BlockPos[] { new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1),
				new BlockPos(0, 0, -1), new BlockPos(1, 0, 0) };
		int var18 = var16.length;
		var5 = 0;
		while (var5 < var18) {
			BlockPos var17 = var19[var5];
			BlockPos offsetPos = position.add(var17.getX(), 0, var17.getZ());
			Minecraft.theWorld.getBlockState(offsetPos);
			if (Minecraft.theWorld.getBlockState(offsetPos).getBlock() instanceof BlockAir) {
				EnumFacing[] var13 = EnumFacing.values();
				int var12 = var13.length;
				int var11 = 0;
				while (var11 < var12) {
					EnumFacing facing2 = var13[var11];
					BlockPos offset2 = offsetPos.offset(facing2);
					Minecraft.theWorld.getBlockState(offset2);
					if (!(Minecraft.theWorld.getBlockState(offset2).getBlock() instanceof BlockAir)) {
						return new BlockCache(null, offset2, invert[facing2.ordinal()], null);
					}
					++var11;
				}

			}
			++var5;
		}
		return null;
	}

	public static int grabBlockSlot() {
		for (int i = 0; i < 9; ++i) {
			ItemStack itemStack = mc.thePlayer.inventory.mainInventory[i];
			if (itemStack != null && itemStack.getItem() instanceof ItemBlock) {
				return i;
			}
		}
		return -1;
	}

	static class BlockCache {
		private BlockPos position;
		private EnumFacing facing;
		final Scaffold this$0;

		private BlockCache(Scaffold var1, BlockPos position, EnumFacing facing) {
			this.this$0 = var1;
			this.position = position;
			this.facing = facing;
		}

		private BlockPos getPosition() {
			return this.position;
		}

		private EnumFacing getFacing() {
			return this.facing;
		}

		static BlockPos access$0(BlockCache var0) {
			return var0.getPosition();
		}

		static EnumFacing access$1(BlockCache var0) {
			return var0.getFacing();
		}

		static BlockPos access$2(BlockCache var0) {
			return var0.position;
		}

		static EnumFacing access$3(BlockCache var0) {
			return var0.facing;
		}

		BlockCache(Scaffold var1, BlockPos var2, EnumFacing var3, BlockCache var4) {
			this(var1, var2, var3);
		}
	}

	public static int getBlockCount() {
		int blockCount = 0;
		for (int i = 0; i < 45; i++) {
			if (Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
				ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
				Item item = is.getItem();
				if (is.getItem() instanceof ItemBlock && isValid(item)) {
					blockCount += is.stackSize;
				}
			}
		}
		return blockCount;
	}

	private static boolean isValid(Item item) {
		if (!(item instanceof ItemBlock)) {
			return false;
		}
		ItemBlock iBlock = (ItemBlock) item;
		Block block = iBlock.getBlock();
		if (invalid.contains(block)) {
			return false;
		}

		return true;
	}

	static enum ScMode {
		Normal;
	}

	static enum TWMod{
		Normal, AAC4
	}
}
