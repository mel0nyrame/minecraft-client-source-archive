package Client.Dev.module.modules.movement;

import java.util.*;
import java.util.List;

import Client.Dev.utils.*;
import Client.Dev.module.*;
import java.awt.*;
import Client.Dev.api.value.*;
import net.minecraft.client.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import Client.Dev.Client;
import Client.Dev.api.*;
import net.minecraft.network.play.server.*;
import Client.Dev.api.events.world.*;
import net.minecraft.block.*;
import net.minecraft.potion.*;
import net.minecraft.entity.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.client.entity.*;
import java.math.*;
import net.minecraft.util.*;
import net.minecraft.util.Timer;

public class Speed
extends Module {
    private Mode<Enum> mode = new Mode("Mode", "mode", (Enum[])SpeedMode.values(), (Enum)SpeedMode.GodLike);
    double movementSpeed;
    private double distance;
    int level = 1;
    double down;
    public static int stage;
    private double lastDist;
    private int tick;
	private boolean canZoom;
    private List<AxisAlignedBB> collidingList;
    public boolean shouldslow = false;
    private double speed;
    public static int aacCount;
    boolean collided = false;
    boolean lessSlow;
    TimerUtil lastCheck = new TimerUtil();
    double less;
    double stair;
    boolean iscolod;
    boolean isJump;
    public static TimeHelper timer2 = new TimeHelper();
    int stoptick;
    private TimerUtil timer = new TimerUtil();

    public Speed() {
        super("Speed", new String[]{"zoom"}, ModuleType.Movement);
        this.setColor(new Color(99, 248, 91).getRGB());
        this.addValues(this.mode);
    }
	private boolean isNotInLiquid() {
		if (mc.thePlayer == null) {
			return true;
		}
		for (int x = MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().minX); x < MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().maxX) + 1; x++) {
			for (int z = MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().minZ); z < MathHelper.floor_double(mc.thePlayer.getEntityBoundingBox().maxZ) + 1; z++) {
				BlockPos pos = new BlockPos(x, (int) mc.thePlayer.getEntityBoundingBox().minY, z);
				Block block = mc.theWorld.getBlockState(pos).getBlock();
				if ((block != null) && (!(block instanceof BlockAir))) {
					return !(block instanceof BlockLiquid);
				}
			}
		}
		return true;
	}
    @Override
    public void onEnable() {
        boolean player = mc.thePlayer == null;
        this.collided = player ? false : mc.thePlayer.isCollidedHorizontally;
        this.lessSlow = false;
        if (mc.thePlayer != null) {
            this.speed = defaultSpeed();
        }
        this.less = 0.0;
        this.lastDist = 0.0;
        stage = 2;
        Timer.timerSpeed = 1.0f;
    }
    
    @Override
    public void onDisable() {
        speed = PlayerUtil.getBaseMoveSpeed();
        level = 0;
        Timer.timerSpeed = 1.0f;
        this.tick = 0;
        aacCount = 0;
    }
  @EventHandler
    public void onMotion() {
        double xDist = mc.thePlayer.posX - mc.thePlayer.prevPosX;
        double zDist = mc.thePlayer.posZ - mc.thePlayer.prevPosZ;
        lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
    }
    
  public void setSpeed(double speed) {
      mc.thePlayer.motionX = - Math.sin(this.getDirection()) * speed;
      mc.thePlayer.motionZ = Math.cos(this.getDirection()) * speed;
  }

  public float getDirection() {
      float yaw = mc.thePlayer.rotationYaw;
      if (mc.thePlayer.moveForward < 0.0f) {
          yaw += 180.0f;
      }
      float forward = 1.0f;
      if (mc.thePlayer.moveForward < 0.0f) {
          forward = -0.5f;
      } else if (mc.thePlayer.moveForward > 0.0f) {
          forward = 0.5f;
      }
      if (mc.thePlayer.moveStrafing > 0.0f) {
          yaw -= 90.0f * forward;
      }
      if (mc.thePlayer.moveStrafing < 0.0f) {
          yaw += 90.0f * forward;
      }
      return yaw *= 0.017453292f;
  }

  
    private boolean canZoom() {
        if (this.mc.thePlayer.moving() && this.mc.thePlayer.onGround) {
            return true;
        }
        return false;
    }
  
    boolean isstep = false;
    @EventHandler
    public void onStep(EventBus e){
        isstep = false;
    }
    
    @EventHandler
    private void onUpdate(EventPreUpdate e) {
        if (this.mode.getValue() == SpeedMode.SlowHop){
        	  ++level;
        	    if(level == 2 && mc.thePlayer.onGround && PlayerUtil.isMoving()) {
        	        if(checksoulsand()) {
        	            mc.thePlayer.jump();
        	        } else {
        	            isJump = true;
        	        }
        	    } else
        	        isJump = false;
        }
        if(mode.getValue()==SpeedMode.TimerHop){
            if(isMoving2()) {
                if(mc.thePlayer.onGround)
                    mc.thePlayer.jump();
                Timer.timerSpeed = 1.5f;
            }else{
                mc.thePlayer.motionX = 0D;
                mc.thePlayer.motionZ = 0D;
            }
        }

        if(mode.getValue()==SpeedMode.Bhop) {
            if(PlayerUtil.isMoving()) {

                if(mc.thePlayer.onGround) {
                    mc.thePlayer.jump();

                    double speed = PlayerUtil.getSpeed() < 0.56F ? PlayerUtil.getSpeed() * 1.045F : 0.56F;

                    if(mc.thePlayer.onGround && mc.thePlayer.isPotionActive(Potion.moveSpeed))
                        speed *= 1F + 0.13F * (1 + mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier());

                    MoveUtils.strafe(speed);
                    return;
                }else if(mc.thePlayer.motionY < 0.2D)
                    mc.thePlayer.motionY -= 0.02D;

                MoveUtils.strafe(PlayerUtil.getSpeed() * 1.01889F);
            }else{
                mc.thePlayer.motionX = mc.thePlayer.motionZ = 0D;
            }
        }
    
        this.setSuffix(this.mode.getValue());
        
    }
    private boolean checksoulsand() {
        if (issoulsand(0, 0)) {
            return true;
        }
        return false;
    }

    @SuppressWarnings("unlikely-arg-type")
	private boolean issoulsand(int X, int Z) {
        if (mc.thePlayer.posY < 0.0) {
        }
        for (int off = 0; off < (int) mc.thePlayer.posY + 2; off += 2) {
            Block block = mc.theWorld.getBlockState(new BlockPos(X,-off, Z)).getBlock();
            if(!block.blockRegistry.equals("soul_sand") || !block.blockRegistry.equals("soul_sand"))
            return false;
        }
        return true;
    }
    private double getHypixelBest(double speed, int T) {
        double base = PlayerUtil.getBaseMoveSpeed();
        boolean slow = false;

        if (T == 1) {
            speed = 0.025;
        } else if (mc.thePlayer.onGround && PlayerUtil.isMoving() && T == 2) {
            speed *= 2.149;
        } else if (T == 3) {
            double str = 0.7095;
            double fe = 1.0E-18;
            double strafe = str * (lastDist - base);
            speed = lastDist - (strafe + fe);
            iscolod = true;
        } else {
            if (T == 2 && mc.thePlayer.fallDistance > 0.0) {
                slow = true;
            }
            level = 1;
            speed = lastDist - lastDist / 159.0;
        }

        speed = Math.max(speed - (slow ? (lastDist * speed) * 0.0149336 : (0.0049336 * lastDist)), base);
        return speed;
    }
    
    @EventHandler
    private void onMove(EventMove e) {
    	 if (this.mode.getValue() == SpeedMode.SlowHop) {
    	      Speed Value = (Speed) Client.instance.modulemanager.getModuleByClass(Speed.class);
    	        double base = PlayerUtil.getBaseMoveSpeed();
    	        if (level > 0 && !mc.thePlayer.isInWater()) {
    	            if (level == 2 && mc.thePlayer.onGround && PlayerUtil.isMoving()) {
    	                if(!checksoulsand())
    	                    e.setY(mc.thePlayer.motionY = 0.4086347666785435 + (MoveUtils.getJumpEffect() * 0.1f));

    	            } else if (mc.thePlayer.fallDistance < 0.42f) {
    	                if (Value.stoptick > 0) {
    	                    level = 0;
    	                    speed = PlayerUtil.getBaseMoveSpeed();
    	                }
    	                if (level > 3) {
    	                    if (mc.thePlayer.isCollidedVertically) {
    	                        level = 0;
    	                        lastDist = 0.0f;
    	                    }
    	                }
    	            }
    	            speed = getHypixelBest(speed, level) - 0.0002133;
    	        } else {
    	            level = 0;
    	        }
    	        if (PlayerUtil.isMoving()) {
    	        	MoveUtils.setMotion(e, speed);
    	        } else {
    	            level = 0;
    	        }
    	 }
    	 else if (this.mode.getValue() == SpeedMode.GodLike) {
    		 if (mc.thePlayer.isCollidedHorizontally) {
                 this.stage = -1;
             }
             if (this.stair > 0.0D) {
                 this.stair -= 0.25D;
             }
                 this.less -= (this.less > 1.0D ? 0.12D : 0.11D);
                 this.less = Math.max(this.less, 0.0);
                 if (this.isNotInLiquid() && MoveUtils.isOnGround(0.01) && MoveUtils.isMoving()) {
                     if (this.stage >= 0 || mc.thePlayer.isCollidedHorizontally) {
                         this.stage = 0;
                         if (this.stair == 0.0) {
                             mc.thePlayer.jump();
                             e.setY(mc.thePlayer.motionY = 0.42F + MoveUtils.getJumpEffect() * 0.1f);
                         }
                         ++this.less;
                         this.lessSlow = this.less > 1.0 && !this.lessSlow;
                         if (this.less > 1.12) {
                             this.less = 1.12;
                         }
                         if (!this.canZoom) this.canZoom = true;
                     }
                 }
                 if (!this.canZoom) {
                     return;
                 }
                 if (stage == 0) {
                     if (!this.lastCheck.isDelayComplete(500.0)) {
                         if (!this.shouldslow) {
                             this.shouldslow = true;
                         }
                     } else if (this.shouldslow) {
                         this.shouldslow = false;
                     }
                     movementSpeed = 0.46f + MoveUtils.getSpeedEffect() * 0.5;
                 } else if (this.stage >= 1) {
                     movementSpeed = Math.hypot(mc.thePlayer.motionX, mc.thePlayer.motionZ);
                 }
                 if (this.shouldslow || !this.lastCheck.isDelayComplete(500.0) || mc.thePlayer.isCollidedHorizontally) {
                     movementSpeed = 0.2;
                     if (this.stage == 0) {
                         movementSpeed = 0.0;
                     }
                 }
                 this.movementSpeed = Math.max(movementSpeed, this.shouldslow ? movementSpeed : 0.2873D);
                 if (this.stair > 0.0) {
                     this.movementSpeed *= 0.7 - MoveUtils.getSpeedEffect() * 0.1;
                 }
                 if (this.stage < 0) {
                     this.movementSpeed = 0.2;
                 }
                 if (this.lessSlow) {
                     this.movementSpeed *= 0.95;
                 }
                 if (!this.isNotInLiquid() || mc.thePlayer.isInWater()) {
                     this.movementSpeed = 0.2865D;
                 }
                 if (MoveUtils.isMoving()) {
                     e.setMoveSpeed(this.movementSpeed);
                     ++this.stage;
                 } else {
                     this.canZoom = false;
                 }
             }
    	 }
             
    private boolean isInLiquid() {
        if (mc.thePlayer == null) {
            return false;
        }
        int x2 = MathHelper.floor_double(mc.thePlayer.boundingBox.minX);
        while (x2 < MathHelper.floor_double(mc.thePlayer.boundingBox.maxX) + 1) {
            int z2 = MathHelper.floor_double(mc.thePlayer.boundingBox.minZ);
            while (z2 < MathHelper.floor_double(mc.thePlayer.boundingBox.maxZ) + 1) {
                BlockPos pos = new BlockPos(x2, (int)mc.thePlayer.boundingBox.minY, z2);
                Block block = mc.theWorld.getBlockState(pos).getBlock();
                if (block != null && !(block instanceof BlockAir)) {
                    return block instanceof BlockLiquid;
                }
                ++z2;
            }
            ++x2;
        }
        return false;
    }
    public static int getJumpEffect() {
        if (Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.jump))
            return Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1;
        else
            return 0;
    }

    public boolean isMoving2() {
        Minecraft.getMinecraft();
        if (mc.thePlayer.moveForward == 0.0f) {
            if (mc.thePlayer.moveStrafing == 0.0f) {
                return false;
            }
        }
        return true;
    }
    
    public boolean isOnGround(double height) {
        if (!this.mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.getEntityBoundingBox().offset(0.0, - height, 0.0)).isEmpty()) {
            return true;
        }
        return false;
    }
    
    private double defaultSpeed() {
        double baseSpeed = 0.2873;
        if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
            int amplifier = mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return baseSpeed;
    }
    
    private void setMotion(EventMove em2, double speed) {
        double forward = MovementInput.moveForward;
        double strafe = MovementInput.moveStrafe;
        float yaw = mc.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            em2.setX(0.0);
            em2.setZ(0.0);
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            em2.setX(forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f)));
            em2.setZ(forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f)));
        }
    }
    public int getSpeedEffect() {
        if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
            return mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1;
        }
        return 0;

    }

    
    private double getHypixelSpeed(int stage) {
        double value = defaultSpeed() + 0.028 * (double)getSpeedEffect() + (double)getSpeedEffect() / 15.0;
        double firstvalue = 0.4145 + (double)getSpeedEffect() / 12.5;
        double decr = (double)stage / 500.0 * 2.0;
        if (stage == 0) {
            if (this.timer.delay(300.0f)) {
                this.timer.reset();
            }
            if (!this.lastCheck.delay(500.0f)) {
                if (!this.shouldslow) {
                    this.shouldslow = true;
                }
            } else if (this.shouldslow) {
                this.shouldslow = false;
            }
            value = 0.64 + ((double)getSpeedEffect() + 0.028 * (double)getSpeedEffect()) * 0.134;
        } else if (stage == 1) {
            value = firstvalue;
        } else if (stage >= 2) {
            value = firstvalue - decr;
        }
        if (this.shouldslow || !this.lastCheck.delay(500.0f) || this.collided) {
            value = 0.2;
            if (stage == 0) {
                value = 0.0;
            }
        }
        return Math.max(value, this.shouldslow ? value : defaultSpeed() + 0.028 * (double)getSpeedEffect());
    }
    
    static enum SpeedMode {
        GodLike,
        SlowHop,
    	TimerHop,
    	Bhop;
    }
}
