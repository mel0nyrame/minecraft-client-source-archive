package Client.Dev.module.modules.movement;

import Client.Dev.module.*;
import java.awt.*;
import Client.Dev.api.value.*;
import Client.Dev.api.events.world.*;
import net.minecraft.client.*;
import Client.Dev.api.*;

public class Sprint extends Module
{
    private Option<Boolean> omni;
    
    public Sprint() {
        super("Sprint", new String[] { "run" }, ModuleType.Movement);
        this.omni = new Option<Boolean>("Omni", "Omni", true);
        this.setColor(new Color(158, 205, 125).getRGB());
        this.addValues(this.omni);
    }
    
    @EventHandler
    private void onUpdate(final EventPreUpdate event) {
        final Minecraft mc = Sprint.mc;
        if (Minecraft.thePlayer.getFoodStats().getFoodLevel() > 6 && this.omni.getValue()) {
            final Minecraft mc2 = Sprint.mc;
            if (!Minecraft.thePlayer.moving()) {
                return;
            }
        }
        else {
            final Minecraft mc3 = Sprint.mc;
            if (Minecraft.thePlayer.moveForward <= 0.0f) {
                return;
            }
        }
        final Minecraft mc4 = Sprint.mc;
        Minecraft.thePlayer.setSprinting(true);
    }
}
