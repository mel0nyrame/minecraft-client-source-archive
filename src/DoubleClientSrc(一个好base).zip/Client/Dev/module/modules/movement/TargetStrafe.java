package Client.Dev.module.modules.movement;

import Client.Dev.module.*;
import java.awt.*;
import Client.Dev.api.value.*;
import Client.Dev.api.events.rendering.*;
import Client.Dev.module.modules.combat.*;
import Client.Dev.module.modules.render.*;
import Client.Dev.api.*;
import org.lwjgl.opengl.*;
import Client.Dev.utils.render.gl.*;
import net.minecraft.client.*;
import Client.Dev.api.events.world.*;
import Client.Dev.utils.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.init.*;
import net.minecraft.client.multiplayer.*;
import Client.Dev.management.*;
import net.minecraft.client.renderer.entity.*;
import org.lwjgl.util.glu.*;

public class TargetStrafe extends Module
{
    private static Numbers<Double> radius;
    private static Numbers<Double> lol;
    private static Option<Boolean> render;
    private static Option<Boolean> space;
    private static Option<Boolean> third;
    private static int direction;
    private static boolean strafing;
    static int preview;
    
    public TargetStrafe() {
        super("TargetStrafe", new String[] { "ts", "strafe" }, ModuleType.Movement);
        this.setColor(new Color(158, 205, 125).getRGB());
        this.addValues(TargetStrafe.radius, TargetStrafe.lol, TargetStrafe.render, TargetStrafe.space, TargetStrafe.third);
    }
    
    @EventHandler
    public void onRender3D(final EventRender3D e) {
        if (canStrafe() && TargetStrafe.render.getValue()) {
            drawCircle2(Killaura.curtarget, new Color(HUD.R.getValue().intValue(), HUD.G.getValue().intValue(), HUD.B.getValue().intValue()).getRGB(), e);
        }
    }
    
    private void drawCircle(final Entity entity, final float partialTicks, final double rad) {
        GL11.glPushMatrix();
        GL11.glDisable(3553);
        GLUtils.startSmooth();
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glLineWidth(1.0f);
        GL11.glBegin(3);
        final double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - TargetStrafe.mc.getRenderManager().viewerPosX;
        final double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - TargetStrafe.mc.getRenderManager().viewerPosY;
        final double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - TargetStrafe.mc.getRenderManager().viewerPosZ;
        final float r = (float)(HUD.R.getValue() / 255.0);
        final float g = (float)(HUD.G.getValue() / 255.0);
        final float b = (float)(HUD.B.getValue() / 255.0);
        final double pix2 = 6.283185307179586;
        for (int i = 0; i <= 360; ++i) {
            GL11.glColor3f(r, g, b);
            GL11.glVertex3d(x + rad * Math.cos(i * 6.283185307179586 / 45.0), y + 0.0, z + rad * Math.sin(i * 6.283185307179586 / 45.0));
        }
        GL11.glEnd();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        GLUtils.endSmooth();
        GL11.glEnable(3553);
        GL11.glPopMatrix();
    }
    
    @EventHandler
    private void onUpdate(final EventPreUpdate event) {
        if (!canStrafe() && TargetStrafe.strafing) {
            TargetStrafe.strafing = false;
            TargetStrafe.mc.gameSettings.thirdPersonView = TargetStrafe.preview;
        }
        final Minecraft mc = TargetStrafe.mc;
        if (Minecraft.thePlayer.isCollidedHorizontally || this.isAboveVoid()) {
            this.switchDirection();
        }
        if (TargetStrafe.mc.gameSettings.keyBindLeft.isPressed()) {
            TargetStrafe.direction = 1;
        }
        if (TargetStrafe.mc.gameSettings.keyBindRight.isPressed()) {
            TargetStrafe.direction = -1;
        }
        if (TargetStrafe.strafing && TargetStrafe.third.getValue()) {
            TargetStrafe.mc.gameSettings.thirdPersonView = 1;
        }
    }
    
    private void switchDirection() {
        TargetStrafe.direction = ((TargetStrafe.direction == 1) ? -1 : 1);
    }
    
    public static void strafe(final EventMove event, final double moveSpeed) {
        if (!TargetStrafe.strafing) {
            TargetStrafe.preview = TargetStrafe.mc.gameSettings.thirdPersonView;
        }
        TargetStrafe.strafing = true;
        final EntityLivingBase target = Killaura.curtarget;
        final float[] rotations = RotationUtils.getRotations(target);
        final Minecraft mc = TargetStrafe.mc;
        if (Minecraft.thePlayer.getDistanceToEntity(target) <= TargetStrafe.radius.getValue()) {
            MovementUtils.setSpeed(event, moveSpeed, rotations[0], TargetStrafe.direction, 0.0);
        }
        else {
            MovementUtils.setSpeed(event, moveSpeed, rotations[0], TargetStrafe.direction, 1.0);
        }
    }
    
    public boolean isAboveVoid() {
        final Minecraft mc = TargetStrafe.mc;
        for (int i = (int)Math.ceil(Minecraft.thePlayer.posY); i >= 0; --i) {
            final double var10004 = i;
            final Minecraft mc2 = TargetStrafe.mc;
            final WorldClient theWorld = Minecraft.theWorld;
            final Minecraft mc3 = TargetStrafe.mc;
            final double posX = Minecraft.thePlayer.posX;
            final double y = var10004;
            final Minecraft mc4 = TargetStrafe.mc;
            if (theWorld.getBlockState(new BlockPos(posX, y, Minecraft.thePlayer.posZ)).getBlock() != Blocks.air) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean canStrafe() {
        return ModuleManager.getModuleByName("Aura").isEnabled() && Killaura.curtarget != null && ModuleManager.getModuleByName("TargetStrafe").isEnabled() && (ModuleManager.getModuleByName("Speed").isEnabled() || ModuleManager.getModuleByName("Flight").isEnabled()) && (!TargetStrafe.space.getValue() || TargetStrafe.mc.gameSettings.keyBindJump.isKeyDown());
    }
    
    public static void drawCircle2(final EntityLivingBase entity, final int color, final EventRender3D e) {
        final double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * e.getPartialTicks() - RenderManager.renderPosX;
        final double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * e.getPartialTicks() - RenderManager.renderPosY;
        final double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * e.getPartialTicks() - RenderManager.renderPosZ;
        GL11.glPushMatrix();
        GL11.glTranslated(x, y, z);
        GL11.glRotatef(-entity.width, 0.0f, 1.0f, 0.0f);
        glColor(color);
        enableSmoothLine(1.0f);
        final Cylinder c = new Cylinder();
        GL11.glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
        c.setDrawStyle(100011);
        c.draw(TargetStrafe.radius.getValue().floatValue(), TargetStrafe.radius.getValue().floatValue() + 0.005f, 0.005f, TargetStrafe.lol.getValue().intValue(), 1);
        c.draw(TargetStrafe.radius.getValue().floatValue() + 0.005f, TargetStrafe.radius.getValue().floatValue() + 0.01f, 0.005f, TargetStrafe.lol.getValue().intValue(), 1);
        c.draw(TargetStrafe.radius.getValue().floatValue() + 0.01f, TargetStrafe.radius.getValue().floatValue() + 0.015f, 0.005f, TargetStrafe.lol.getValue().intValue(), 1);
        c.draw(TargetStrafe.radius.getValue().floatValue() + 0.015f, TargetStrafe.radius.getValue().floatValue() + 0.02f, 0.005f, TargetStrafe.lol.getValue().intValue(), 1);
        c.draw(TargetStrafe.radius.getValue().floatValue() + 0.02f, TargetStrafe.radius.getValue().floatValue() + 0.025f, 0.005f, TargetStrafe.lol.getValue().intValue(), 1);
        glColor(new Color(50, 50, 50).getRGB());
        c.draw(TargetStrafe.radius.getValue().floatValue(), TargetStrafe.radius.getValue().floatValue() + 0.0f, 0.005f, TargetStrafe.lol.getValue().intValue(), 1);
        c.draw(TargetStrafe.radius.getValue().floatValue() + 0.025f, TargetStrafe.radius.getValue().floatValue() + 0.025f, 0.005f, TargetStrafe.lol.getValue().intValue(), 1);
        disableSmoothLine();
        GL11.glPopMatrix();
    }
    
    public static void glColor(final int hex) {
        final float alpha = (hex >> 24 & 0xFF) / 255.0f;
        final float red = (hex >> 16 & 0xFF) / 255.0f;
        final float green = (hex >> 8 & 0xFF) / 255.0f;
        final float blue = (hex & 0xFF) / 255.0f;
        GL11.glColor4f(red, green, blue, (alpha == 0.0f) ? 1.0f : alpha);
    }
    
    public static void enableSmoothLine(final float width) {
        GL11.glDisable(3008);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glEnable(2884);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glHint(3155, 4354);
        GL11.glLineWidth(width);
    }
    
    public static void disableSmoothLine() {
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDisable(3042);
        GL11.glEnable(3008);
        GL11.glDepthMask(true);
        GL11.glCullFace(1029);
        GL11.glDisable(2848);
        GL11.glHint(3154, 4352);
        GL11.glHint(3155, 4352);
    }
    
    static {
        TargetStrafe.radius = new Numbers<Double>("Radius", "Radius", 2.0, 1.0, 3.0, 0.25);
        TargetStrafe.lol = new Numbers<Double>("Sides", "Sides", 9.0, 5.0, 25.0, 1.0);
        TargetStrafe.render = new Option<Boolean>("Render", "Render", true);
        TargetStrafe.space = new Option<Boolean>("Space", "Space", true);
        TargetStrafe.third = new Option<Boolean>("ThirdPersonView", "ThirdPersonView", false);
        TargetStrafe.direction = -1;
        TargetStrafe.strafing = false;
    }
}
