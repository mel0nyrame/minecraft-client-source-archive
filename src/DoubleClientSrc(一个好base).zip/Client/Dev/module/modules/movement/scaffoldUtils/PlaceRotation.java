package Client.Dev.module.modules.movement.scaffoldUtils;

public class PlaceRotation
{
    private PlaceInfo info;
    private Rotation rot;
    
    public PlaceRotation(final PlaceInfo info, final Rotation rot) {
        this.info = info;
        this.rot = rot;
    }
    
    public PlaceInfo getPlaceInfo() {
        return this.info;
    }
    
    public Rotation getRotation() {
        return this.rot;
    }
}
