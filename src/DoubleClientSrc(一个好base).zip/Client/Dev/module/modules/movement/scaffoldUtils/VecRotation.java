package Client.Dev.module.modules.movement.scaffoldUtils;

import net.minecraft.util.*;

public final class VecRotation
{
    private Vec3 vec;
    private Rotation rot;
    
    public VecRotation() {
    }
    
    public VecRotation(final Vec3 vec, final Rotation rot) {
        this.vec = vec;
        this.rot = rot;
    }
    
    public Rotation getRotation() {
        return this.rot;
    }
    
    public Vec3 getVec() {
        return this.vec;
    }
}
