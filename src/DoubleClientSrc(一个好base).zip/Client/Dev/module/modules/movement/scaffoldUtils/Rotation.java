package Client.Dev.module.modules.movement.scaffoldUtils;

import net.minecraft.client.entity.*;
import net.minecraft.client.*;

public final class Rotation
{
    private float yaw;
    private float pitch;
    
    public Rotation() {
        this(0.0f, 0.0f);
    }
    
    public Rotation(final float yaw, final float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }
    
    public float getYaw() {
        return this.yaw;
    }
    
    public float getPitch() {
        return this.pitch;
    }
    
    public void fixedSensitivity(final float sensitivity) {
        final float f = sensitivity * 0.6f + 0.2f;
        final float gcd = f * f * f * 1.2f;
        this.yaw -= this.yaw % gcd;
        this.pitch -= this.pitch % gcd;
    }
    
    public void toPlayer(final EntityPlayerSP player) {
        this.fixedSensitivity(Minecraft.getMinecraft().gameSettings.mouseSensitivity);
        player.rotationYaw = this.yaw;
        player.rotationPitch = this.pitch;
    }
}
