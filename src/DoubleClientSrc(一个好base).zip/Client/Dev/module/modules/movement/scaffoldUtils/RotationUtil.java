package Client.Dev.module.modules.movement.scaffoldUtils;

import net.minecraft.client.*;
import java.util.*;
import net.minecraft.entity.*;
import net.minecraft.client.entity.*;
import net.minecraft.util.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import Client.Dev.api.events.world.*;

public class RotationUtil
{
    private static final Minecraft mc;
    private static Random random;
    private static int keepLength;
    public static Rotation targetRotation;
    public static Rotation serverRotation;
    public static boolean keepCurrentRotation;
    private static double x;
    private static double y;
    private static double z;
    
    static {
        mc = Minecraft.getMinecraft();
        RotationUtil.random = new Random();
        RotationUtil.serverRotation = new Rotation(0.0f, 0.0f);
        RotationUtil.keepCurrentRotation = false;
        RotationUtil.x = RotationUtil.random.nextDouble();
        RotationUtil.y = RotationUtil.random.nextDouble();
        RotationUtil.z = RotationUtil.random.nextDouble();
    }
    
    public static VecRotation faceBlock(final BlockPos blockPos) {
        if (blockPos == null) {
            return null;
        }
        VecRotation vecRotation = null;
        for (double xSearch = 0.1; xSearch < 0.9; xSearch += 0.1) {
            for (double ySearch = 0.1; ySearch < 0.9; ySearch += 0.1) {
                for (double zSearch = 0.1; zSearch < 0.9; zSearch += 0.1) {
                    final Vec3 eyesPos = new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.getEntityBoundingBox().minY + Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
                    final Vec3 posVec = new Vec3(blockPos).addVector(xSearch, ySearch, zSearch);
                    final double diffX = posVec.xCoord - eyesPos.xCoord;
                    final double diffY = posVec.yCoord - eyesPos.yCoord;
                    final double diffZ = posVec.zCoord - eyesPos.zCoord;
                    final double diffXZ = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
                    final Rotation rotation = new Rotation(MathHelper.wrapAngleTo180_float((float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f), MathHelper.wrapAngleTo180_float((float)(-Math.toDegrees(Math.atan2(diffY, diffXZ)))));
                    final Vec3 rotationVector = getVectorForRotation(rotation);
                    final Vec3 vector = eyesPos.addVector(rotationVector.xCoord * 4.0, rotationVector.yCoord * 4.0, rotationVector.zCoord * 4.0);
                    final MovingObjectPosition obj = Minecraft.theWorld.rayTraceBlocks(eyesPos, vector, false, false, true);
                    if (obj.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
                        final VecRotation currentVec = new VecRotation(posVec, rotation);
                        if (vecRotation == null || getRotationDifference(currentVec.getRotation()) < getRotationDifference(vecRotation.getRotation())) {
                            vecRotation = currentVec;
                        }
                    }
                }
            }
        }
        if (vecRotation != null) {
            setTargetRotation(vecRotation.getRotation());
        }
        return vecRotation;
    }
    
    public static void faceBow(final Entity target, final boolean silent, final boolean predict, final float predictSize) {
        final EntityPlayerSP player = Minecraft.thePlayer;
        final double posX = target.posX + (predict ? ((target.posX - target.prevPosX) * predictSize) : 0.0) - (player.posX + (predict ? (player.posX - player.prevPosX) : 0.0));
        final double posY = target.getEntityBoundingBox().minY + (predict ? ((target.getEntityBoundingBox().minY - target.prevPosY) * predictSize) : 0.0) + target.getEyeHeight() - 0.15 - (player.getEntityBoundingBox().minY + (predict ? (player.posY - player.prevPosY) : 0.0)) - player.getEyeHeight();
        final double posZ = target.posZ + (predict ? ((target.posZ - target.prevPosZ) * predictSize) : 0.0) - (player.posZ + (predict ? (player.posZ - player.prevPosZ) : 0.0));
        final double posSqrt = Math.sqrt(posX * posX + posZ * posZ);
        float velocity = player.getItemInUseDuration() / 20.0f;
        velocity = (velocity * velocity + velocity * 2.0f) / 3.0f;
        if (velocity > 1.0f) {
            velocity = 1.0f;
        }
        final Rotation rotation = new Rotation((float)(Math.atan2(posZ, posX) * 180.0 / 3.141592653589793) - 90.0f, (float)(-Math.toDegrees(Math.atan((velocity * velocity - Math.sqrt(velocity * velocity * velocity * velocity - 0.006000000052154064 * (0.006000000052154064 * (posSqrt * posSqrt) + 2.0 * posY * (velocity * velocity)))) / (0.006000000052154064 * posSqrt)))));
        if (silent) {
            setTargetRotation(rotation);
        }
        else {
            limitAngleChange(new Rotation(player.rotationYaw, player.rotationPitch), rotation, (float)(10 + new Random().nextInt(6))).toPlayer(Minecraft.thePlayer);
        }
    }
    
    public static Rotation toRotation(final Vec3 vec, final boolean predict) {
        final Vec3 eyesPos = new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.getEntityBoundingBox().minY + Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
        if (predict) {
            eyesPos.addVector(Minecraft.thePlayer.motionX, Minecraft.thePlayer.motionY, Minecraft.thePlayer.motionZ);
        }
        final double diffX = vec.xCoord - eyesPos.xCoord;
        final double diffY = vec.yCoord - eyesPos.yCoord;
        final double diffZ = vec.zCoord - eyesPos.zCoord;
        return new Rotation(MathHelper.wrapAngleTo180_float((float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f), MathHelper.wrapAngleTo180_float((float)(-Math.toDegrees(Math.atan2(diffY, Math.sqrt(diffX * diffX + diffZ * diffZ))))));
    }
    
    public static Vec3 getCenter(final AxisAlignedBB bb) {
        return new Vec3(bb.minX + (bb.maxX - bb.minX) * 0.5, bb.minY + (bb.maxY - bb.minY) * 0.5, bb.minZ + (bb.maxZ - bb.minZ) * 0.5);
    }
    
    public static VecRotation searchCenter(final AxisAlignedBB bb, final boolean outborder, final boolean random, final boolean predict, final boolean throughWalls) {
        if (outborder) {
            final Vec3 vec3 = new Vec3(bb.minX + (bb.maxX - bb.minX) * (RotationUtil.x * 0.3 + 1.0), bb.minY + (bb.maxY - bb.minY) * (RotationUtil.y * 0.3 + 1.0), bb.minZ + (bb.maxZ - bb.minZ) * (RotationUtil.z * 0.3 + 1.0));
            return new VecRotation(vec3, toRotation(vec3, predict));
        }
        final Vec3 randomVec = new Vec3(bb.minX + (bb.maxX - bb.minX) * RotationUtil.x * 0.8, bb.minY + (bb.maxY - bb.minY) * RotationUtil.y * 0.8, bb.minZ + (bb.maxZ - bb.minZ) * RotationUtil.z * 0.8);
        final Rotation randomRotation = toRotation(randomVec, predict);
        VecRotation vecRotation = null;
        for (double xSearch = 0.15; xSearch < 0.85; xSearch += 0.1) {
            for (double ySearch = 0.15; ySearch < 1.0; ySearch += 0.1) {
                for (double zSearch = 0.15; zSearch < 0.85; zSearch += 0.1) {
                    final Vec3 vec4 = new Vec3(bb.minX + (bb.maxX - bb.minX) * xSearch, bb.minY + (bb.maxY - bb.minY) * ySearch, bb.minZ + (bb.maxZ - bb.minZ) * zSearch);
                    final Rotation rotation = toRotation(vec4, predict);
                    if (throughWalls || isVisible(vec4)) {
                        final VecRotation currentVec = new VecRotation(vec4, rotation);
                        if (vecRotation != null) {
                            if (random) {
                                if (getRotationDifference(currentVec.getRotation(), randomRotation) >= getRotationDifference(vecRotation.getRotation(), randomRotation)) {
                                    continue;
                                }
                            }
                            else if (getRotationDifference(currentVec.getRotation()) >= getRotationDifference(vecRotation.getRotation())) {
                                continue;
                            }
                        }
                        vecRotation = currentVec;
                    }
                }
            }
        }
        return vecRotation;
    }
    
    public static double getRotationDifference(final Entity entity) {
        final Rotation rotation = toRotation(getCenter(entity.getEntityBoundingBox()), true);
        return getRotationDifference(rotation, new Rotation(Minecraft.thePlayer.rotationYaw, Minecraft.thePlayer.rotationPitch));
    }
    
    public static double getRotationDifference(final Rotation rotation) {
        return (RotationUtil.serverRotation == null) ? 0.0 : getRotationDifference(rotation, RotationUtil.serverRotation);
    }
    
    public static double getRotationDifference(final Rotation a, final Rotation b) {
        return Math.hypot(getAngleDifference(a.getYaw(), b.getYaw()), a.getPitch() - b.getPitch());
    }
    
    public static Rotation limitAngleChange(final Rotation currentRotation, final Rotation targetRotation, final float turnSpeed) {
        final float yawDifference = getAngleDifference(targetRotation.getYaw(), currentRotation.getYaw());
        final float pitchDifference = getAngleDifference(targetRotation.getPitch(), currentRotation.getPitch());
        return new Rotation(currentRotation.getYaw() + ((yawDifference > turnSpeed) ? turnSpeed : Math.max(yawDifference, -turnSpeed)), currentRotation.getPitch() + ((pitchDifference > turnSpeed) ? turnSpeed : Math.max(pitchDifference, -turnSpeed)));
    }
    
    private static float getAngleDifference(final float a, final float b) {
        return ((a - b) % 360.0f + 540.0f) % 360.0f - 180.0f;
    }
    
    public static Vec3 getVectorForRotation(final Rotation rotation) {
        final float yawCos = MathHelper.cos(-rotation.getYaw() * 0.017453292f - 3.1415927f);
        final float yawSin = MathHelper.sin(-rotation.getYaw() * 0.017453292f - 3.1415927f);
        final float pitchCos = -MathHelper.cos(-rotation.getPitch() * 0.017453292f);
        final float pitchSin = MathHelper.sin(-rotation.getPitch() * 0.017453292f);
        return new Vec3(yawSin * pitchCos, pitchSin, yawCos * pitchCos);
    }
    
    public static boolean isVisible(final Vec3 vec3) {
        final Vec3 eyesPos = new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.getEntityBoundingBox().minY + Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
        return Minecraft.theWorld.rayTraceBlocks(eyesPos, vec3) == null;
    }
    
    public static void onTick(final EventTick event) {
        if (RotationUtil.targetRotation != null) {
            --RotationUtil.keepLength;
            if (RotationUtil.keepLength <= 0) {
                reset();
            }
        }
        if (RotationUtil.random.nextGaussian() > 0.8) {
            RotationUtil.x = Math.random();
        }
        if (RotationUtil.random.nextGaussian() > 0.8) {
            RotationUtil.y = Math.random();
        }
        if (RotationUtil.random.nextGaussian() > 0.8) {
            RotationUtil.z = Math.random();
        }
    }
    
    public static void onPacket(final EventPacketSend event) {
        final Packet<?> packet = (Packet<?>)event.getPacket();
        if (packet instanceof C03PacketPlayer) {
            final C03PacketPlayer packetPlayer = (C03PacketPlayer)packet;
            if (RotationUtil.targetRotation != null && !RotationUtil.keepCurrentRotation && (RotationUtil.targetRotation.getYaw() != RotationUtil.serverRotation.getYaw() || RotationUtil.targetRotation.getPitch() != RotationUtil.serverRotation.getPitch())) {
                packetPlayer.yaw = RotationUtil.targetRotation.getYaw();
                packetPlayer.pitch = RotationUtil.targetRotation.getPitch();
                Minecraft.thePlayer.rotationYawHead = RotationUtil.targetRotation.getYaw();
                Minecraft.thePlayer.renderYawOffset = RotationUtil.targetRotation.getYaw();
                packetPlayer.rotating = true;
            }
            if (packetPlayer.rotating) {
                RotationUtil.serverRotation = new Rotation(packetPlayer.yaw, packetPlayer.pitch);
            }
        }
    }
    
    public static void onUpdateA(final EventPreUpdate event) {
        boolean rotating = false;
        if (RotationUtil.targetRotation != null && !RotationUtil.keepCurrentRotation) {
            if (RotationUtil.targetRotation.getYaw() != RotationUtil.serverRotation.getYaw() || RotationUtil.targetRotation.getPitch() != RotationUtil.serverRotation.getPitch()) {
                event.setYaw(RotationUtil.targetRotation.getYaw());
                event.setPitch(RotationUtil.targetRotation.getPitch());
            }
            else {
                event.setYaw(RotationUtil.targetRotation.getYaw() + 1.0f);
                event.setPitch(RotationUtil.targetRotation.getPitch());
            }
            rotating = true;
        }
        if (rotating) {
            RotationUtil.serverRotation = new Rotation(event.getYaw(), event.getPitch());
        }
    }
    
    public static void setTargetRotation(final Rotation rotation) {
        setTargetRotation(rotation, 0);
    }
    
    public static void setTargetRotation(final Rotation rotation, final int keepLength) {
        if (Double.isNaN(rotation.getYaw()) || Double.isNaN(rotation.getPitch()) || rotation.getPitch() > 90.0f || rotation.getPitch() < -90.0f) {
            return;
        }
        rotation.fixedSensitivity(RotationUtil.mc.gameSettings.mouseSensitivity);
        RotationUtil.targetRotation = rotation;
        RotationUtil.keepLength = keepLength;
    }
    
    public static void reset() {
        RotationUtil.keepLength = 0;
        RotationUtil.targetRotation = null;
    }
}
