package Client.Dev.module.modules.movement.scaffoldUtils;

import net.minecraft.util.*;
import Client.Dev.utils.*;

public class PlaceInfo
{
    private BlockPos pos;
    private EnumFacing enumFacing;
    private Vec3 vec3;
    
    public PlaceInfo(final BlockPos pos, final EnumFacing enumFacing) {
        this.pos = pos;
        this.enumFacing = enumFacing;
        this.vec3 = new Vec3(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);
    }
    
    public PlaceInfo(final BlockPos pos, final EnumFacing enumFacing, final Vec3 vec3) {
        this.pos = pos;
        this.enumFacing = enumFacing;
        this.vec3 = vec3;
    }
    
    public Vec3 getVec3() {
        return this.vec3;
    }
    
    public BlockPos getBlockPos() {
        return this.pos;
    }
    
    public EnumFacing getEnumFacing() {
        return this.enumFacing;
    }
    
    public PlaceInfo get(final BlockPos blockpos) {
        if (BlockUtils.canBeClicked(blockpos.add(0, -1, 0))) {
            return new PlaceInfo(blockpos.add(0, -1, 0), EnumFacing.UP);
        }
        if (BlockUtils.canBeClicked(blockpos.add(0, 0, 1))) {
            return new PlaceInfo(blockpos.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (BlockUtils.canBeClicked(blockpos.add(0, 0, -1))) {
            return new PlaceInfo(blockpos.add(0, 0, -1), EnumFacing.SOUTH);
        }
        if (BlockUtils.canBeClicked(blockpos.add(-1, 0, 0))) {
            return new PlaceInfo(blockpos.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (BlockUtils.canBeClicked(blockpos.add(1, 0, 0))) {
            return new PlaceInfo(blockpos.add(1, 0, 0), EnumFacing.WEST);
        }
        return null;
    }
}
