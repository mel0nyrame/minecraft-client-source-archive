package Client.Dev.module.modules.movement;

import Client.Dev.module.*;
import java.awt.*;
import Client.Dev.api.value.*;
import net.minecraft.client.*;
import Client.Dev.utils.*;
import java.util.*;
import net.minecraft.client.entity.*;
import Client.Dev.api.*;
import net.minecraft.block.*;
import net.minecraft.entity.*;
import net.minecraft.client.multiplayer.*;
import net.minecraft.potion.*;
import Client.Dev.api.events.world.*;
import net.minecraft.network.play.client.*;
import Client.Dev.api.events.misc.*;
import net.minecraft.util.*;

public class Jesus extends Module
{
    int stage;
    int water;
    private TimerUtil timer;
    private boolean wasWater;
    private int ticks;
    private Mode<Enum> mode;
    
    public Jesus() {
        super("Jesus", new String[] { "waterwalk", "waterfloat", "liquidwalk", "waterfloat" }, ModuleType.Movement);
        this.timer = new TimerUtil();
        this.wasWater = false;
        this.ticks = 0;
        this.mode = new Mode<Enum>("Mode", "Mode", JMode.values(), JMode.Dolphin);
        this.setColor(new Color(188, 233, 248).getRGB());
        this.addValues(this.mode);
    }
    
    @Override
    public void onEnable() {
        this.wasWater = false;
        super.onEnable();
    }
    
    private boolean canJeboos() {
        final Minecraft mc = Jesus.mc;
        if (Minecraft.thePlayer.fallDistance < 3.0f && !Jesus.mc.gameSettings.keyBindJump.isPressed() && !PlayerUtils.isInLiquid()) {
            final Minecraft mc2 = Jesus.mc;
            if (!Minecraft.thePlayer.isSneaking()) {
                return true;
            }
        }
        return false;
    }
    
    boolean shouldJesus() {
        final Minecraft mc = Jesus.mc;
        final double x = Minecraft.thePlayer.posX;
        final Minecraft mc2 = Jesus.mc;
        final double y = Minecraft.thePlayer.posY;
        final Minecraft mc3 = Jesus.mc;
        final double z = Minecraft.thePlayer.posZ;
        final ArrayList<BlockPos> pos = new ArrayList<BlockPos>(Arrays.asList(new BlockPos(x + 0.3, y, z + 0.3), new BlockPos(x - 0.3, y, z + 0.3), new BlockPos(x + 0.3, y, z - 0.3), new BlockPos(x - 0.3, y, z - 0.3)));
        for (final BlockPos po : pos) {
            final Minecraft mc4 = Jesus.mc;
            if (!(Minecraft.theWorld.getBlockState(po).getBlock() instanceof BlockLiquid)) {
                continue;
            }
            final Minecraft mc5 = Jesus.mc;
            if (!(Minecraft.theWorld.getBlockState(po).getProperties().get((Object)BlockLiquid.LEVEL) instanceof Integer)) {
                continue;
            }
            final Minecraft mc6 = Jesus.mc;
            if ((int)Minecraft.theWorld.getBlockState(po).getProperties().get((Object)BlockLiquid.LEVEL) <= 4) {
                return true;
            }
        }
        return false;
    }
    
    @EventHandler
    public void onPre(final EventPreUpdate e) {
        this.setSuffix(this.mode.getValue());
        if (this.mode.getValue() == JMode.Dolphin) {
            final Minecraft mc = Jesus.mc;
            if (Minecraft.thePlayer.isInWater()) {
                final Minecraft mc2 = Jesus.mc;
                if (!Minecraft.thePlayer.isSneaking() && this.shouldJesus()) {
                    final Minecraft mc3 = Jesus.mc;
                    Minecraft.thePlayer.motionY = 0.09;
                }
            }
            if (e.getType() == 1) {
                return;
            }
            final Minecraft mc4 = Jesus.mc;
            Label_0114: {
                if (!Minecraft.thePlayer.onGround) {
                    final Minecraft mc5 = Jesus.mc;
                    if (!Minecraft.thePlayer.isOnLadder()) {
                        break Label_0114;
                    }
                }
                this.wasWater = false;
            }
            final Minecraft mc6 = Jesus.mc;
            if (Minecraft.thePlayer.motionY > 0.0 && this.wasWater) {
                final Minecraft mc7 = Jesus.mc;
                if (Minecraft.thePlayer.motionY <= 0.11) {
                    final Minecraft mc8 = Jesus.mc;
                    final EntityPlayerSP thePlayer;
                    final EntityPlayerSP player = thePlayer = Minecraft.thePlayer;
                    thePlayer.motionY *= 1.2671;
                }
                final Minecraft mc9 = Jesus.mc;
                final EntityPlayerSP thePlayer2;
                final EntityPlayerSP player2 = thePlayer2 = Minecraft.thePlayer;
                thePlayer2.motionY += 0.05172;
            }
            if (this.isInLiquid()) {
                final Minecraft mc10 = Jesus.mc;
                if (!Minecraft.thePlayer.isSneaking()) {
                    if (this.ticks < 3) {
                        final Minecraft mc11 = Jesus.mc;
                        Minecraft.thePlayer.motionY = 0.13;
                        ++this.ticks;
                        this.wasWater = false;
                    }
                    else {
                        final Minecraft mc12 = Jesus.mc;
                        Minecraft.thePlayer.motionY = 0.5;
                        this.ticks = 0;
                        this.wasWater = true;
                    }
                }
            }
        }
        else if (this.mode.getValue() == JMode.Solid && PlayerUtils.isInLiquid()) {
            final Minecraft mc13 = Jesus.mc;
            if (!Minecraft.thePlayer.isSneaking() && !Jesus.mc.gameSettings.keyBindJump.isPressed()) {
                final Minecraft mc14 = Jesus.mc;
                Minecraft.thePlayer.motionY = 0.05;
                final Minecraft mc15 = Jesus.mc;
                Minecraft.thePlayer.onGround = true;
            }
        }
    }
    
    private boolean isInLiquid() {
        final Minecraft mc = Jesus.mc;
        if (Minecraft.thePlayer == null) {
            return false;
        }
        final Minecraft mc2 = Jesus.mc;
        int x = MathHelper.floor_double(Minecraft.thePlayer.boundingBox.minX);
        while (true) {
            final int n = x;
            final Minecraft mc3 = Jesus.mc;
            if (n >= MathHelper.floor_double(Minecraft.thePlayer.boundingBox.maxX) + 1) {
                return false;
            }
            final Minecraft mc4 = Jesus.mc;
            int z = MathHelper.floor_double(Minecraft.thePlayer.boundingBox.minZ);
            while (true) {
                final int n2 = z;
                final Minecraft mc5 = Jesus.mc;
                if (n2 >= MathHelper.floor_double(Minecraft.thePlayer.boundingBox.maxZ) + 1) {
                    ++x;
                    break;
                }
                final int x2 = x;
                final Minecraft mc6 = Jesus.mc;
                final BlockPos pos = new BlockPos(x2, (int)Minecraft.thePlayer.boundingBox.minY, z);
                final Minecraft mc7 = Jesus.mc;
                final Block block = Minecraft.theWorld.getBlockState(pos).getBlock();
                if (block != null && !(block instanceof BlockAir)) {
                    return block instanceof BlockLiquid;
                }
                ++z;
            }
        }
    }
    
    public double getMotionY(double stage) {
        --stage;
        final double[] motion = { 0.5, 0.484, 0.468, 0.436, 0.404, 0.372, 0.34, 0.308, 0.276, 0.244, 0.212, 0.18, 0.166, 0.166, 0.156, 0.123, 0.135, 0.111, 0.086, 0.098, 0.073, 0.048, 0.06, 0.036, 0.0106, 0.015, 0.004, 0.004, 0.004, 0.004, -0.013, -0.045, -0.077, -0.109 };
        if (stage < motion.length && stage >= 0.0) {
            return motion[(int)stage];
        }
        return -999.0;
    }
    
    public static boolean isOnGround(final double height) {
        final Minecraft mc = Jesus.mc;
        final WorldClient theWorld = Minecraft.theWorld;
        final Minecraft mc2 = Jesus.mc;
        final EntityPlayerSP thePlayer = Minecraft.thePlayer;
        final Minecraft mc3 = Jesus.mc;
        return !theWorld.getCollidingBoundingBoxes(thePlayer, Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, -height, 0.0)).isEmpty();
    }
    
    public static int getSpeedEffect() {
        final Minecraft mc = Jesus.mc;
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            final Minecraft mc2 = Jesus.mc;
            return Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1;
        }
        return 0;
    }
    
    public static void setMotion(final double speed) {
        final Minecraft mc = Jesus.mc;
        final MovementInput movementInput = Minecraft.thePlayer.movementInput;
        double forward = MovementInput.moveForward;
        final Minecraft mc2 = Jesus.mc;
        final MovementInput movementInput2 = Minecraft.thePlayer.movementInput;
        double strafe = MovementInput.moveStrafe;
        final Minecraft mc3 = Jesus.mc;
        float yaw = Minecraft.thePlayer.rotationYaw;
        if (forward == 0.0 && strafe == 0.0) {
            final Minecraft mc4 = Jesus.mc;
            Minecraft.thePlayer.motionX = 0.0;
            final Minecraft mc5 = Jesus.mc;
            Minecraft.thePlayer.motionZ = 0.0;
        }
        else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += ((forward > 0.0) ? -45 : 45);
                }
                else if (strafe < 0.0) {
                    yaw += ((forward > 0.0) ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                }
                else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            final Minecraft mc6 = Jesus.mc;
            Minecraft.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0f)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0f));
            final Minecraft mc7 = Jesus.mc;
            Minecraft.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0f)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0f));
        }
    }
    
    @EventHandler
    public void onPacket(final EventPacketSend e) {
        if (this.mode.getValue() == JMode.Solid && e.getPacket() instanceof C03PacketPlayer && this.canJeboos() && PlayerUtils.isOnLiquid()) {
            final C03PacketPlayer c03PacketPlayer;
            final C03PacketPlayer packet = c03PacketPlayer = (C03PacketPlayer)e.getPacket();
            final Minecraft mc = Jesus.mc;
            c03PacketPlayer.y = ((Minecraft.thePlayer.ticksExisted % 2 == 0) ? (packet.y + 0.01) : (packet.y - 0.01));
        }
    }
    
    @EventHandler
    public void onBB(final EventCollideWithBlock e) {
        if (this.mode.getValue() == JMode.Solid && e.getBlock() instanceof BlockLiquid && this.canJeboos()) {
            e.setBoundingBox(new AxisAlignedBB(e.getPos().getX(), e.getPos().getY(), e.getPos().getZ(), e.getPos().getX() + 1.0, e.getPos().getY() + 1.0, e.getPos().getZ() + 1.0));
        }
    }
    
    enum JMode
    {
        Solid, 
        Dolphin;
    }
}
