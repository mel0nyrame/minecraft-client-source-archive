package Client.Dev.module.modules.movement.ScaffoldModule;

import net.minecraft.util.*;

public class VecRotation
{
    Vec3 vec;
    Rotation rotation;
    
    public VecRotation(final Vec3 vec, final Rotation rotation) {
        this.vec = vec;
        this.rotation = rotation;
    }
    
    public Rotation getRotation() {
        return this.rotation;
    }
}
