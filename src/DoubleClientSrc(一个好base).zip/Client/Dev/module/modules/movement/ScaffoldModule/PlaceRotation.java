package Client.Dev.module.modules.movement.ScaffoldModule;

import Client.Dev.module.modules.movement.ScaffoldModule.blocks.*;

public final class PlaceRotation
{
    private final PlaceInfo placeInfo;
    private final Rotation rotation;
    
    public final PlaceInfo getPlaceInfo() {
        return this.placeInfo;
    }
    
    public final Rotation getRotation() {
        return this.rotation;
    }
    
    public PlaceRotation(final PlaceInfo placeInfo, final Rotation rotation) {
        this.placeInfo = placeInfo;
        this.rotation = rotation;
    }
}
