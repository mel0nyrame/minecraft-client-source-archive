package Client.Dev.module.modules.movement.ScaffoldModule;

import net.minecraft.entity.player.*;
import net.minecraft.client.*;

public class Rotation
{
    float yaw;
    float pitch;
    
    public Rotation(final float yaw, final float pitch) {
        this.yaw = yaw;
        this.pitch = pitch;
    }
    
    public float getYaw() {
        return this.yaw;
    }
    
    public float getPitch() {
        return this.pitch;
    }
    
    public void toPlayer(final EntityPlayer player) {
        if (Float.isNaN(this.yaw) || Float.isNaN(this.pitch)) {
            return;
        }
        this.fixedSensitivity(Minecraft.getMinecraft().gameSettings.mouseSensitivity);
        player.rotationYaw = this.yaw;
        player.rotationPitch = this.pitch;
    }
    
    public void fixedSensitivity(final Float sensitivity) {
        final float f = sensitivity * 0.6f + 0.2f;
        final float gcd = f * f * f * 1.2f;
        this.yaw -= this.yaw % gcd;
        this.pitch -= this.pitch % gcd;
    }
}
