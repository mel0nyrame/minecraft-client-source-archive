/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.module;

public enum ModuleType {
    Combat,
    Render,
    Movement,
    Player,
    World;
}

