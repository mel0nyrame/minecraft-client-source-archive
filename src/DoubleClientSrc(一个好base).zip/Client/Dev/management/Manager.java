/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.management;

public interface Manager {
    public void init();
}

