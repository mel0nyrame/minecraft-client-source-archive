/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.api;

public class Priority {
    public static final byte HIGH = 0;
    public static final byte NORMAL = 1;
    public static final byte LOW = 2;
}

