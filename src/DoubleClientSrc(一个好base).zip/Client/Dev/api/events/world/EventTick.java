/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.api.events.world;

import Client.Dev.api.Event;

public class EventTick
extends Event {
}

