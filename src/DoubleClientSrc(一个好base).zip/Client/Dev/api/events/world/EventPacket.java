package Client.Dev.api.events.world;

import Client.Dev.api.Event;
import net.minecraft.network.Packet;

public class EventPacket extends Event {
	public Packet packet;
    private boolean cancelled;
    public static boolean isOutGoing;
    public EventPacket(Packet p) {
        this.packet = p;
    }
    
    public void set(boolean out) {
    	isOutGoing = out;
    }


    public Packet getPacket() {
        return this.packet;
    }

    public void setCancelled(boolean state) {
        this.cancelled = state;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setPacket(Packet p) {
        this.packet = p;
    }
}
