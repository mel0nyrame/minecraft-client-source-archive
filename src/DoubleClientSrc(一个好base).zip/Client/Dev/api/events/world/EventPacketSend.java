/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.api.events.world;

import Client.Dev.api.Event;
import net.minecraft.network.Packet;

public class EventPacketSend
extends Event {
    public static Packet packet;

    public EventPacketSend(Packet packet) {
        this.packet = packet;
    }

    public static Packet getPacket() {
        return EventPacketSend.packet;
    }

    public void setPacket(Packet packet) {
        this.packet = packet;
    }
}

