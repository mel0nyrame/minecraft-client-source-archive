package Client.Dev.api.events.rendering;

import Client.Dev.api.*;
import net.minecraft.block.*;
import net.minecraft.util.*;

public class EventPreRenderBlock extends Event
{
    private Block block;
    private BlockPos pos;
    
    public EventPreRenderBlock(final Block block, final BlockPos pos) {
        this.block = null;
        this.pos = null;
        this.setBlock(block);
        this.setPos(pos);
    }
    
    public Block getBlock() {
        return this.block;
    }
    
    public void setBlock(final Block block) {
        this.block = block;
    }
    
    public BlockPos getPos() {
        return this.pos;
    }
    
    public void setPos(final BlockPos pos) {
        this.pos = pos;
    }
}
