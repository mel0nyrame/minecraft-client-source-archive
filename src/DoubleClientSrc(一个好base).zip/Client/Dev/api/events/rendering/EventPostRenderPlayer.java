/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.api.events.rendering;

import Client.Dev.api.Event;

public class EventPostRenderPlayer
extends Event {
}

