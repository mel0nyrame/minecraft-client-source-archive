/*
 * Decompiled with CFR 0.150.
 */
package Client.Dev.api.events.misc;

import net.minecraft.block.Block;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;

import Client.Dev.api.Event;

public final class BoundingBoxEvent
extends Event {
    private final Block block;
    private final BlockPos blockPos;
    private AxisAlignedBB boundingBox;
    
    private final int x;
    private final int y;
    private final int z;

    public BoundingBoxEvent(Block block, BlockPos pos, AxisAlignedBB boundingBox) {
    	this.x = pos.getX();
        this.y = pos.getY();
        this.z = pos.getZ();
		this.block = block;
        this.blockPos = pos;
        this.boundingBox = boundingBox;
    }
    

    public final int getX() {
        return this.x;
    }
    
    public final int getY() {
        return this.y;
    }
    
    public final int getZ() {
        return this.z;
    }

    public final Block getBlock() {
        return this.block;
    }

    public final BlockPos getBlockPos() {
        return this.blockPos;
    }

    public final AxisAlignedBB getBoundingBox() {
        return this.boundingBox;
    }

    public final void setBoundingBox(AxisAlignedBB boundingBox) {
        this.boundingBox = boundingBox;
    }
}
