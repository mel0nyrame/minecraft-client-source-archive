package Client.Dev.api.events.misc;

import  Client.Dev.api.*;

public class EventJump extends Event
{
}
