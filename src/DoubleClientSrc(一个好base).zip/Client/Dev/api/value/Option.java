/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.api.value;

import Client.Dev.api.value.Value;

public class Option<V>
extends Value<V> {
    public int anim;

	public Option(String displayName, String name, V enabled) {
        super(displayName, name);
        this.setValue(enabled);
    }
}

