/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev;

import Client.Dev.api.value.Value;
import Client.Dev.management.CommandManager;
import Client.Dev.management.FileManager;
import Client.Dev.management.FriendManager;
import Client.Dev.management.ModuleManager;
import Client.Dev.module.Module;
import Client.Dev.ui.login.AltManager;
import java.io.PrintStream;
import java.time.OffsetDateTime;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

public class Client {
    public static final ResourceLocation CLIENT_CAPE = null;
	public final static String name = "Double";
    public final static String version = "β";
    public static boolean publicMode = false;
    public static Client instance = new Client();
    public static ModuleManager modulemanager;
    private CommandManager commandmanager;
    private AltManager altmanager;
    private FriendManager friendmanager;
    public static Minecraft mc = Minecraft.getMinecraft();
    public void initiate() {
        this.commandmanager = new CommandManager();
        this.commandmanager.init();
        this.friendmanager = new FriendManager();
        this.friendmanager.init();
        this.modulemanager = new ModuleManager();
        this.modulemanager.init();
        this.altmanager = new AltManager();
        AltManager.init();
        AltManager.setupAlts();
        FileManager.init();
    }

    public static ModuleManager getModuleManager() {
        return modulemanager;
    }

    public CommandManager getCommandManager() {
        return this.commandmanager;
    }

    public AltManager getAltManager() {
        return this.altmanager;
    }

    public void shutDown() {
        String values = "";
        instance.getModuleManager();
        for (Module m : ModuleManager.getModules()) {
            for (Value v : m.getValues()) {
                values = String.valueOf(values) + String.format("%s:%s:%s%s", m.getName(), v.getName(), v.getValue(), System.lineSeparator());
            }
        }
        FileManager.save("Values.txt", values, false);
        String enabled = "";
        instance.getModuleManager();
        for (Module m : ModuleManager.getModules()) {
            if (!m.isEnabled()) continue;
            enabled = String.valueOf(enabled) + String.format("%s%s", m.getName(), System.lineSeparator());
        }
        FileManager.save("Enabled.txt", enabled, false);
    }

	public static void sendClientMessage(String string) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void RenderRotate(float f) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}
}

