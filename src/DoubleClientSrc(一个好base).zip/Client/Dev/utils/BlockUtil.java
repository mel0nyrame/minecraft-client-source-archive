/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.utils;

public class BlockUtil {
}

