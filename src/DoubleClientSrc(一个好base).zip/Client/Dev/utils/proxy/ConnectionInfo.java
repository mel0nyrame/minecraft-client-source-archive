/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.utils.proxy;

public class ConnectionInfo {
    public String ip;
    public int port;
}

