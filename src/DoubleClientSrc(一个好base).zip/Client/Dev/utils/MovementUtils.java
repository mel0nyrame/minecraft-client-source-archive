/*
 * Decompiled with CFR 0.150.
 */
package Client.Dev.utils;

import net.minecraft.client.Minecraft;
import net.minecraft.potion.Potion;

import Client.Dev.api.events.world.EventMove;

public final class MovementUtils {
    private static final Minecraft mc = Minecraft.getMinecraft();

    public static void setSpeed(EventMove moveEvent, double moveSpeed) {
        MovementUtils.setSpeed(moveEvent, moveSpeed, MovementUtils.mc.thePlayer.rotationYaw, MovementUtils.mc.thePlayer.movementInput.moveStrafe, MovementUtils.mc.thePlayer.movementInput.moveForward);
    }
    
    public static void setSpeed(double speed) {
        Minecraft.getMinecraft();
        mc.thePlayer.motionX = - Math.sin(PlayerUtils.getDirection()) * speed;
        Minecraft.getMinecraft();
        mc.thePlayer.motionZ = Math.cos(PlayerUtils.getDirection()) * speed;
    }

    public static void setSpeed(EventMove moveEvent, double moveSpeed, float pseudoYaw, double pseudoStrafe, double pseudoForward) {
        double forward = pseudoForward;
        double strafe = pseudoStrafe;
        float yaw = pseudoYaw;
        if (forward != 0.0) {
            if (strafe > 0.0) {
                yaw += (float)(forward > 0.0 ? -45 : 45);
            } else if (strafe < 0.0) {
                yaw += (float)(forward > 0.0 ? 45 : -45);
            }
            strafe = 0.0;
            if (forward > 0.0) {
                forward = 1.0;
            } else if (forward < 0.0) {
                forward = -1.0;
            }
        }
        if (strafe > 0.0) {
            strafe = 1.0;
        } else if (strafe < 0.0) {
            strafe = -1.0;
        }
        double mx = Math.cos(Math.toRadians(yaw + 90.0f));
        double mz = Math.sin(Math.toRadians(yaw + 90.0f));
        moveEvent.x = forward * moveSpeed * mx + strafe * moveSpeed * mz;
        moveEvent.z = forward * moveSpeed * mz - strafe * moveSpeed * mx;
    }

    public static double getBaseMoveSpeed() {
        double baseSpeed = 0.2875;
        if (MovementUtils.mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
            baseSpeed *= 1.0 + 0.2 * (double)(MovementUtils.mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1);
        }
        return baseSpeed;
    }

    public static double getJumpBoostModifier(double baseJumpHeight) {
        if (MovementUtils.mc.thePlayer.isPotionActive(Potion.jump)) {
            int amplifier = MovementUtils.mc.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier();
            baseJumpHeight += (double)((float)(amplifier + 1) * 0.1f);
        }
        return baseJumpHeight;
    }

	public static boolean isMoving() {
		// TODO 自动生成的方法存根
		return false;
	}

	public static boolean isOnGround(double d) {
		// TODO 自动生成的方法存根
		return false;
	}

	public static double getJumpEffect() {
		// TODO 自动生成的方法存根
		return 0;
	}
}

