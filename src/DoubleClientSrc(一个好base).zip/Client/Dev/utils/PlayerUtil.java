package Client.Dev.utils;

import net.minecraft.client.*;
import net.minecraft.block.material.*;
import net.minecraft.client.entity.*;
import net.minecraft.entity.player.*;
import org.lwjgl.util.vector.*;
import net.minecraft.world.*;
import net.minecraft.entity.ai.attributes.*;
import com.google.common.collect.*;
import net.minecraft.entity.*;
import net.minecraft.enchantment.*;
import java.util.*;
import java.util.Map.Entry;

import net.minecraft.util.*;

import net.minecraft.client.multiplayer.*;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.potion.*;

public class PlayerUtil
{
    private static Minecraft mc;
    
    static {
        PlayerUtil.mc = Minecraft.getMinecraft();
    }
    
    public static float[] getRotations(final Entity ent) {
        final double x = ent.posX;
        final double z = ent.posZ;
        final double y = ent.posY + ent.getEyeHeight() / 4.0f;
        return getRotationFromPosition(x, z, y);
    }
    
    private static float[] getRotationFromPosition(final double x, final double z, final double y) {
        Minecraft.getMinecraft();
        final double xDiff = x - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        final double zDiff = z - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        final double yDiff = y - Minecraft.thePlayer.posY - 0.6;
        final double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        final float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / 3.141592653589793) - 90.0f;
        final float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / 3.141592653589793));
        return new float[] { yaw, pitch };
    }
    
    public static boolean isMoving2() {
        return Minecraft.thePlayer.moveForward != 0.0f || Minecraft.thePlayer.moveStrafing != 0.0f;
    }
    
    public static boolean isMoving() {
        if (!Minecraft.thePlayer.isCollidedHorizontally && !Minecraft.thePlayer.isSneaking()) {
            final MovementInput movementInput = Minecraft.thePlayer.movementInput;
            if (MovementInput.moveForward == 0.0f) {
                final MovementInput movementInput2 = Minecraft.thePlayer.movementInput;
                if (MovementInput.moveStrafe == 0.0f) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    
    public static double getBaseMoveSpeed() {
        double baseSpeed = 0.2873;
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            Minecraft.getMinecraft();
            final int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (amplifier + 1);
        }
        return baseSpeed;
    }
    
    public static BlockPos getHypixelBlockpos(final String str) {
        int val = 89;
        if (str != null && str.length() > 1) {
            final char[] chs = str.toCharArray();
            for (int lenght = chs.length, i = 0; i < lenght; ++i) {
                val += chs[i] * str.length() * str.length() + str.charAt(0) + str.charAt(1);
            }
            val /= str.length();
        }
        return new BlockPos(val, -val % 255, val);
    }
    
    public static float getDirection() {
        Minecraft.getMinecraft();
        float yaw = Minecraft.thePlayer.rotationYawHead;
        Minecraft.getMinecraft();
        final float forward = Minecraft.thePlayer.moveForward;
        Minecraft.getMinecraft();
        final float strafe = Minecraft.thePlayer.moveStrafing;
        yaw += ((forward < 0.0f) ? 180 : 0);
        if (strafe < 0.0f) {
            yaw += ((forward < 0.0f) ? -45 : ((forward == 0.0f) ? 90 : 45));
        }
        if (strafe > 0.0f) {
            yaw -= ((forward < 0.0f) ? -45 : ((forward == 0.0f) ? 90 : 45));
        }
        return yaw * 0.017453292f;
    }
    
    public static boolean isInWater() {
        return Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ)).getBlock().getMaterial() == Material.water;
    }
    
    public static void toFwd(final double speed) {
        final float yaw = Minecraft.thePlayer.rotationYaw * 0.017453292f;
        final EntityPlayerSP thePlayer3;
        final EntityPlayerSP thePlayer = thePlayer3 = Minecraft.thePlayer;
        thePlayer3.motionX -= MathHelper.sin(yaw) * speed;
        final EntityPlayerSP thePlayer4;
        final EntityPlayerSP thePlayer2 = thePlayer4 = Minecraft.thePlayer;
        thePlayer4.motionZ += MathHelper.cos(yaw) * speed;
    }
    
    public static void setSpeed(final double speed) {
        Minecraft.thePlayer.motionX = -Math.sin(getDirection()) * speed;
        Minecraft.thePlayer.motionZ = Math.cos(getDirection()) * speed;
    }
    
    public static double getSpeed() {
        Minecraft.getMinecraft();
        final double motionX = Minecraft.thePlayer.motionX;
        Minecraft.getMinecraft();
        final double n = motionX * Minecraft.thePlayer.motionX;
        Minecraft.getMinecraft();
        final double motionZ = Minecraft.thePlayer.motionZ;
        Minecraft.getMinecraft();
        return Math.sqrt(n + motionZ * Minecraft.thePlayer.motionZ);
    }
    
    public static Block getBlockUnderPlayer(final EntityPlayer inPlayer) {
        return getBlock(new BlockPos(inPlayer.posX, inPlayer.posY - 1.0, inPlayer.posZ));
    }
    
    public static Block getBlock(final BlockPos pos) {
        Minecraft.getMinecraft();
        return Minecraft.theWorld.getBlockState(pos).getBlock();
    }
    
    public static Block getBlockAtPosC(final EntityPlayer inPlayer, final double x, final double y, final double z) {
        return getBlock(new BlockPos(inPlayer.posX - x, inPlayer.posY - y, inPlayer.posZ - z));
    }
    
    public static ArrayList<Vector3f> vanillaTeleportPositions(final double tpX, final double tpY, final double tpZ, final double speed) {
        final ArrayList positions = new ArrayList();
        final Minecraft mc = Minecraft.getMinecraft();
        final double posX = tpX - Minecraft.thePlayer.posX;
        final double posY = tpY - (Minecraft.thePlayer.posY + Minecraft.thePlayer.getEyeHeight() + 1.1);
        final double posZ = tpZ - Minecraft.thePlayer.posZ;
        final float yaw = (float)(Math.atan2(posZ, posX) * 180.0 / 3.141592653589793 - 90.0);
        final float pitch = (float)(-Math.atan2(posY, Math.sqrt(posX * posX + posZ * posZ)) * 180.0 / 3.141592653589793);
        double tmpX = Minecraft.thePlayer.posX;
        double tmpY = Minecraft.thePlayer.posY;
        double tmpZ = Minecraft.thePlayer.posZ;
        double steps = 1.0;
        for (double d = speed; d < getDistance(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ, tpX, tpY, tpZ); d += speed) {
            ++steps;
        }
        for (double d = speed; d < getDistance(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ, tpX, tpY, tpZ); d += speed) {
            tmpX = Minecraft.thePlayer.posX - Math.sin(getDirection(yaw)) * d;
            tmpZ = Minecraft.thePlayer.posZ + Math.cos(getDirection(yaw)) * d;
            positions.add(new Vector3f((float)tmpX, (float)(tmpY -= (Minecraft.thePlayer.posY - tpY) / steps), (float)tmpZ));
        }
        positions.add(new Vector3f((float)tpX, (float)tpY, (float)tpZ));
        return (ArrayList<Vector3f>)positions;
    }
    
    public static float getDirection(float yaw) {
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            yaw += 180.0f;
        }
        float forward = 1.0f;
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        }
        else {
            Minecraft.getMinecraft();
            if (Minecraft.thePlayer.moveForward > 0.0f) {
                forward = 0.5f;
            }
        }
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.moveStrafing > 0.0f) {
            yaw -= 90.0f * forward;
        }
        Minecraft.getMinecraft();
        if (Minecraft.thePlayer.moveStrafing < 0.0f) {
            yaw += 90.0f * forward;
        }
        return yaw *= 0.017453292f;
    }
    
    public static double getDistance(final double x1, final double y1, final double z1, final double x2, final double y2, final double z2) {
        final double d0 = x1 - x2;
        final double d2 = y1 - y2;
        final double d3 = z1 - z2;
        return MathHelper.sqrt_double(d0 * d0 + d2 * d2 + d3 * d3);
    }
    
    public static boolean MovementInput() {
        return PlayerUtil.mc.gameSettings.keyBindForward.isKeyDown() || PlayerUtil.mc.gameSettings.keyBindLeft.isKeyDown() || PlayerUtil.mc.gameSettings.keyBindRight.isKeyDown() || PlayerUtil.mc.gameSettings.keyBindBack.isKeyDown();
    }
    
    public static void blockHit(final Entity en, final boolean value) {
        final Minecraft mc = Minecraft.getMinecraft();
        final ItemStack stack = Minecraft.thePlayer.getCurrentEquippedItem();
        if (Minecraft.thePlayer.getCurrentEquippedItem() != null && en != null && value && stack.getItem() instanceof ItemSword && Minecraft.thePlayer.swingProgress > 0.2) {
            Minecraft.thePlayer.getCurrentEquippedItem().useItemRightClick(Minecraft.theWorld, Minecraft.thePlayer);
        }
    }
    
    public static float getItemAtkDamage(final ItemStack itemStack) {
        final Multimap multimap = itemStack.getAttributeModifiers();
        final Iterator iterator;
        if (multimap.isEmpty() || !(iterator = multimap.entries().iterator()).hasNext()) {
            return 1.0f;
        }
        final Map.Entry entry = (Entry) iterator.next();
        final AttributeModifier attributeModifier = (AttributeModifier) entry.getValue();
        final double d;
        final double damage = d = ((attributeModifier.getOperation() != 1 && attributeModifier.getOperation() != 2) ? attributeModifier.getAmount() : (attributeModifier.getAmount() * 100.0));
        if (attributeModifier.getAmount() > 1.0) {
            return 1.0f + (float)damage;
        }
        return 1.0f;
    }
    
    public static int bestWeapon(final Entity target) {
        final Minecraft mc = Minecraft.getMinecraft();
        Minecraft.thePlayer.inventory.currentItem = 0;
        final int firstSlot = 0;
        int bestWeapon = -1;
        int j = 1;
        for (int i = 0; i < 9; i = (byte)(i + 1)) {
            Minecraft.thePlayer.inventory.currentItem = i;
            final ItemStack itemStack = Minecraft.thePlayer.getHeldItem();
            if (itemStack != null) {
                int itemAtkDamage = (int)getItemAtkDamage(itemStack);
                if ((itemAtkDamage += (int)EnchantmentHelper.func_152377_a(itemStack, EnumCreatureAttribute.UNDEFINED)) > j) {
                    j = itemAtkDamage;
                    bestWeapon = i;
                }
            }
        }
        if (bestWeapon != -1) {
            return bestWeapon;
        }
        return firstSlot;
    }
    
    public static void shiftClick(final Item i) {
        for (int i2 = 9; i2 < 37; ++i2) {
            final ItemStack itemstack = Minecraft.thePlayer.inventoryContainer.getSlot(i2).getStack();
            if (itemstack != null && itemstack.getItem() == i) {
                Minecraft.playerController.windowClick(0, i2, 0, 1, Minecraft.thePlayer);
                break;
            }
        }
    }
    
    public static boolean hotbarIsFull() {
        for (int i = 0; i <= 36; ++i) {
            final ItemStack itemstack = Minecraft.thePlayer.inventory.getStackInSlot(i);
            if (itemstack == null) {
                return false;
            }
        }
        return true;
    }
    
    public static Entity raycast(final Entity entiy) {
        final Entity var2 = Minecraft.thePlayer;
        final Vec3 var3 = entiy.getPositionVector().add(new Vec3(0.0, entiy.getEyeHeight(), 0.0));
        final Vec3 var4 = Minecraft.thePlayer.getPositionVector().add(new Vec3(0.0, Minecraft.thePlayer.getEyeHeight(), 0.0));
        Vec3 var5 = null;
        final float var6 = 1.0f;
        final AxisAlignedBB a = Minecraft.thePlayer.getEntityBoundingBox().addCoord(var3.xCoord - var4.xCoord, var3.yCoord - var4.yCoord, var3.zCoord - var4.zCoord).expand(var6, var6, var6);
        final List var7 = Minecraft.theWorld.getEntitiesWithinAABBExcludingEntity(var2, a);
        double var8 = 4.5;
        Entity b = null;
        for (int var9 = 0; var9 < var7.size(); ++var9) {
            final Entity var10 = (Entity) var7.get(var9);
            if (var10.canBeCollidedWith()) {
                final float var11 = var10.getCollisionBorderSize();
                final AxisAlignedBB var12 = var10.getEntityBoundingBox().expand(var11, var11, var11);
                final MovingObjectPosition var13 = var12.calculateIntercept(var4, var3);
                if (var12.isVecInside(var4)) {
                    if (0.0 < var8 || var8 == 0.0) {
                        b = var10;
                        var5 = ((var13 == null) ? var4 : var13.hitVec);
                        var8 = 0.0;
                    }
                }
                else if (var13 != null) {
                    final double var14 = var4.distanceTo(var13.hitVec);
                    if (var14 < var8 || var8 == 0.0) {
                        b = var10;
                        var5 = var13.hitVec;
                        var8 = var14;
                    }
                }
            }
        }
        return b;
    }
    
    public static Vec3 getLook(final float p_174806_1_, final float p_174806_2_) {
        final float var3 = MathHelper.cos(-p_174806_2_ * 0.017453292f - 3.1415927f);
        final float var4 = MathHelper.sin(-p_174806_2_ * 0.017453292f - 3.1415927f);
        final float var5 = -MathHelper.cos(-p_174806_1_ * 0.017453292f);
        final float var6 = MathHelper.sin(-p_174806_1_ * 0.017453292f);
        return new Vec3(var4 * var5, var6, var3 * var5);
    }
    
    public static void tellPlayer(final String string) {
        Minecraft.thePlayer.addChatMessage(new ChatComponentText(string));
    }
    
    public static boolean isOnGround(final double d) {
        return false;
    }
    
    public static double getDistanceToFall() {
        double distance = 0.0;
        for (double i2 = Minecraft.thePlayer.posY; i2 > 0.0; i2 -= 0.1) {
            if (i2 < 0.0) {
                break;
            }
            final Block block = BlockUtils.getBlock(new BlockPos(Minecraft.thePlayer.posX, i2, Minecraft.thePlayer.posZ));
            if (block.getMaterial() != Material.air && block.isCollidable() && (block.isFullBlock() || block instanceof BlockSlab || block instanceof BlockBarrier || block instanceof BlockStairs || block instanceof BlockGlass || block instanceof BlockStainedGlass)) {
                if (block instanceof BlockSlab) {
                    i2 -= 0.5;
                }
                distance = i2;
                break;
            }
        }
        return Minecraft.thePlayer.posY - distance;
    }
    
    public static boolean isBlockUnder() {
        final EntityPlayerSP player = Minecraft.thePlayer;
        final WorldClient world = Minecraft.theWorld;
        final AxisAlignedBB pBb = player.getEntityBoundingBox();
        final double height = player.posY + player.getEyeHeight();
        for (int offset = 0; offset < height; offset += 2) {
            if (!world.getCollidingBoundingBoxes(player, pBb.offset(0.0, -offset, 0.0)).isEmpty()) {
                return true;
            }
        }
        return false;
    }
    
    public static boolean isInsideBlock() {
        final EntityPlayerSP player = Minecraft.thePlayer;
        final WorldClient world = Minecraft.theWorld;
        final AxisAlignedBB bb = player.getEntityBoundingBox();
        for (int x = MathHelper.floor_double(bb.minX); x < MathHelper.floor_double(bb.maxX) + 1; ++x) {
            for (int y = MathHelper.floor_double(bb.minY); y < MathHelper.floor_double(bb.maxY) + 1; ++y) {
                for (int z = MathHelper.floor_double(bb.minZ); z < MathHelper.floor_double(bb.maxZ) + 1; ++z) {
                    final Block block = world.getBlockState(new BlockPos(x, y, z)).getBlock();
                    final AxisAlignedBB boundingBox;
                    if (block != null && !(block instanceof BlockAir) && (boundingBox = block.getCollisionBoundingBox(world, new BlockPos(x, y, z), world.getBlockState(new BlockPos(x, y, z)))) != null && player.getEntityBoundingBox().intersectsWith(boundingBox)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public static boolean isHoldingSword() {
        return Minecraft.thePlayer.getCurrentEquippedItem() != null && Minecraft.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemSword;
    }
    
    public static double defaultSpeed() {
        double baseSpeed = 0.2873;
        final Minecraft mc = PlayerUtil.mc;
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            final Minecraft mc2 = PlayerUtil.mc;
            final int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (amplifier + 1);
        }
        return baseSpeed;
    }
    
    public static boolean isHoldingFood(final Item item) {
        return !(item instanceof ItemSword) && !(item instanceof ItemBow);
    }
    
    public static float getMaxFallDist() {
        final PotionEffect potioneffect = Minecraft.thePlayer.getActivePotionEffect(Potion.jump);
        final int f = (potioneffect != null) ? (potioneffect.getAmplifier() + 1) : 0;
        return (float)(Minecraft.thePlayer.getMaxFallHeight() + f);
    }
    
    public static boolean isOnHypixel() {
        return !PlayerUtil.mc.isSingleplayer() && PlayerUtil.mc.getCurrentServerData().serverIP.contains("hypixel");
    }
}
