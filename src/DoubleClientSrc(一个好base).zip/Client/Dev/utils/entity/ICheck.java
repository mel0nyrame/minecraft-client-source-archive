package Client.Dev.utils.entity;

import net.minecraft.entity.*;

@FunctionalInterface
public interface ICheck
{
    boolean validate(final Entity p0);
}
