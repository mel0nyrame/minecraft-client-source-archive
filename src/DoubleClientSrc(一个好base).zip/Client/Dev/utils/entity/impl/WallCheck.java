package Client.Dev.utils.entity.impl;

import Client.Dev.utils.entity.*;
import net.minecraft.entity.*;
import net.minecraft.client.*;

public final class WallCheck implements ICheck
{
    @Override
    public boolean validate(final Entity entity) {
        Minecraft.getMinecraft();
        return Minecraft.thePlayer.canEntityBeSeen(entity);
    }
}
