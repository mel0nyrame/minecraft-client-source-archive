package Client.Dev.utils.entity.impl;

import Client.Dev.utils.entity.*;
import Client.Dev.api.value.*;
import net.minecraft.entity.*;
import net.minecraft.client.*;

public final class DistanceCheck implements ICheck
{
    private final Numbers<Double> distance;
    
    public DistanceCheck(final Numbers<Double> distance) {
        this.distance = distance;
    }
    
    @Override
    public boolean validate(final Entity entity) {
        Minecraft.getMinecraft();
        return Minecraft.thePlayer.getDistanceToEntity(entity) <= this.distance.getValue();
    }
}
