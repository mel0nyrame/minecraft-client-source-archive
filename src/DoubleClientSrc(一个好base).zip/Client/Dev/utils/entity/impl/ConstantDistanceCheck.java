package Client.Dev.utils.entity.impl;

import Client.Dev.utils.entity.*;
import net.minecraft.entity.*;
import net.minecraft.client.*;

public final class ConstantDistanceCheck implements ICheck
{
    private final float distance;
    
    public ConstantDistanceCheck(final float distance) {
        this.distance = distance;
    }
    
    @Override
    public boolean validate(final Entity entity) {
        Minecraft.getMinecraft();
        return Minecraft.thePlayer.getDistanceToEntity(entity) <= this.distance;
    }
}
