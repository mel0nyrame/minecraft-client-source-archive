package Client.Dev.utils.entity.impl;

import Client.Dev.utils.entity.*;
import Client.Dev.api.value.*;
import net.minecraft.entity.*;
import net.minecraft.client.entity.*;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.player.*;
import Client.Dev.management.*;
import net.minecraft.entity.boss.*;
import net.minecraft.entity.monster.*;

public final class EntityCheck implements ICheck
{
    private final Option<Boolean> players;
    private final Option<Boolean> animals;
    private final Option<Boolean> monsters;
    private final Option<Boolean> invisibles;
    
    public EntityCheck(final Option<Boolean> players, final Option<Boolean> animals, final Option<Boolean> monsters, final Option<Boolean> invisibles) {
        this.players = players;
        this.animals = animals;
        this.monsters = monsters;
        this.invisibles = invisibles;
    }
    
    @Override
    public boolean validate(final Entity entity) {
        if (entity instanceof EntityPlayerSP) {
            return false;
        }
        if (!this.invisibles.getValue() && entity.isInvisible()) {
            return false;
        }
        if (this.animals.getValue() && entity instanceof EntityAnimal) {
            return true;
        }
        if (this.players.getValue() && entity instanceof EntityPlayer) {
            return !FriendManager.isFriend(entity.getName());
        }
        return this.monsters.getValue() && (entity instanceof EntityMob || entity instanceof EntitySlime || entity instanceof EntityDragon || entity instanceof EntityGolem);
    }
}
