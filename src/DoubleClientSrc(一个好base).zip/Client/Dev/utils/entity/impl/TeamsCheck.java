package Client.Dev.utils.entity.impl;

import Client.Dev.utils.entity.*;
import Client.Dev.api.value.*;
import net.minecraft.entity.*;
import net.minecraft.entity.player.*;
import Client.Dev.utils.*;

public final class TeamsCheck implements ICheck
{
    private final Option<Boolean> teams;
    
    public TeamsCheck(final Option<Boolean> teams) {
        this.teams = teams;
    }
    
    @Override
    public boolean validate(final Entity entity) {
        return !(entity instanceof EntityPlayer) || !PlayerUtils.isOnSameTeam((EntityPlayer)entity) || !this.teams.getValue();
    }
}
