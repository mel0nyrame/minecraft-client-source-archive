package Client.Dev.utils.entity.impl;

import Client.Dev.utils.entity.*;
import net.minecraft.entity.*;
import net.minecraft.client.*;
import net.minecraft.util.*;

public final class VoidCheck implements ICheck
{
    @Override
    public boolean validate(final Entity entity) {
        return this.isBlockUnder(entity);
    }
    
    private boolean isBlockUnder(final Entity entity) {
        for (int offset = 0; offset < entity.posY + entity.getEyeHeight(); offset += 2) {
            final AxisAlignedBB boundingBox = entity.getEntityBoundingBox().offset(0.0, -offset, 0.0);
            Minecraft.getMinecraft();
            if (!Minecraft.theWorld.getCollidingBoundingBoxes(entity, boundingBox).isEmpty()) {
                return true;
            }
        }
        return false;
    }
}
