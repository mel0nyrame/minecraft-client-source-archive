package Client.Dev.utils.entity.impl;

import Client.Dev.utils.entity.*;
import net.minecraft.entity.*;
import net.minecraft.client.*;

public final class AliveCheck implements ICheck
{
    @Override
    public boolean validate(final Entity entity) {
        return entity.isEntityAlive() || Minecraft.getMinecraft().getCurrentServerData().serverIP.contains("mineplex");
    }
}
