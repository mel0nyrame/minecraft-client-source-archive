package Client.Dev.utils.entity;

import net.minecraft.entity.*;
import java.util.*;

public final class EntityValidator
{
    private final Set<ICheck> checks;
    
    public EntityValidator() {
        this.checks = new HashSet<ICheck>();
    }
    
    public final boolean validate(final Entity entity) {
        for (final ICheck check : this.checks) {
            if (check.validate(entity)) {
                continue;
            }
            return false;
        }
        return true;
    }
    
    public void add(final ICheck check) {
        this.checks.add(check);
    }
}
