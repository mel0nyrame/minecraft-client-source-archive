package Client.Dev.utils.render;

import Client.Dev.utils.render.gl.GLClientState;
import Client.Dev.utils.math.Vec3f;
import Client.Dev.utils.math.Vec2f;
import java.awt.Color;
import java.io.InputStreamReader;

import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import Client.Dev.utils.Helper;
import Client.Dev.utils.Wrapper;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.List;
import pw.knx.feather.tessellate.Tessellation;

public class RenderUtil
{
    public static final Tessellation tessellator;
    private static final List<Integer> csBuffer;
    private static final Consumer<Integer> ENABLE_CLIENT_STATE;
    private static final Consumer<Integer> DISABLE_CLIENT_STATE;
	public static double delta;
    
    static {
        tessellator = Tessellation.createExpanding(4, 1.0f, 2.0f);
        csBuffer = new ArrayList<Integer>();
        ENABLE_CLIENT_STATE = GL11::glEnableClientState;
        DISABLE_CLIENT_STATE = GL11::glEnableClientState;
    }
    
    public RenderUtil() {
        super();
    }
    
    public static int width() {
        return new ScaledResolution(Minecraft.getMinecraft()).getScaledWidth();
    }
    
    public static int height() {
        return new ScaledResolution(Minecraft.getMinecraft()).getScaledHeight();
    }
    
    public static double interpolation(final double newPos, final double oldPos) {
        return oldPos + (newPos - oldPos) * Helper.mc.timer.renderPartialTicks;
    }
    
    public static int getHexRGB(final int hex) {
        return 0xFF000000 | hex;
    }
    
    public static void drawCustomImage(int x, int y, int width, int height, ResourceLocation image) {
        ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
        GL11.glDisable((int)2929);
        GL11.glEnable((int)3042);
        GL11.glDepthMask((boolean)false);
        OpenGlHelper.glBlendFunc((int)770, (int)771, (int)1, (int)0);
        GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        Minecraft.getMinecraft().getTextureManager().bindTexture(image);
        Gui.drawModalRectWithCustomSizedTexture((int)x, (int)y, (float)0.0f, (float)0.0f, (int)width, (int)height, (float)width, (float)height);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2929);
    }

    
    public static void drawBorderedRect(final float x, final float y, final float x2, final float y2, final float l1, final int col1, final int col2) {
        Gui.drawRect(x, y, x2, y2, col2);
        final float f = (col1 >> 24 & 0xFF) / 255.0f;
        final float f2 = (col1 >> 16 & 0xFF) / 255.0f;
        final float f3 = (col1 >> 8 & 0xFF) / 255.0f;
        final float f4 = (col1 & 0xFF) / 255.0f;
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GL11.glPushMatrix();
        GL11.glColor4f(f2, f3, f4, f);
        GL11.glLineWidth(l1);
        GL11.glBegin(1);
        GL11.glVertex2d((double)x, (double)y);
        GL11.glVertex2d((double)x, (double)y2);
        GL11.glVertex2d((double)x2, (double)y2);
        GL11.glVertex2d((double)x2, (double)y);
        GL11.glVertex2d((double)x, (double)y);
        GL11.glVertex2d((double)x2, (double)y);
        GL11.glVertex2d((double)x, (double)y2);
        GL11.glVertex2d((double)x2, (double)y2);
        GL11.glEnd();
        GL11.glPopMatrix();
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glDisable(2848);
    }
    
    public static void pre() {
        GL11.glDisable(2929);
        GL11.glDisable(3553);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
    }
    
    public static void post() {
        GL11.glDisable(3042);
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glColor3d(1.0, 1.0, 1.0);
    }
    
    public static void startDrawing() {
        GL11.glEnable(3042);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(2848);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        Helper.mc.entityRenderer.setupCameraTransform(Helper.mc.timer.renderPartialTicks, 0);
    }
    
    public static void stopDrawing() {
        GL11.glDisable(3042);
        GL11.glEnable(3553);
        GL11.glDisable(2848);
        GL11.glDisable(3042);
        GL11.glEnable(2929);
    }
    
    public static Color blend(final Color color1, final Color color2, final double ratio) {
        final float r = (float)ratio;
        final float ir = 1.0f - r;
        final float[] rgb1 = new float[3];
        final float[] rgb2 = new float[3];
        color1.getColorComponents(rgb1);
        color2.getColorComponents(rgb2);
        final Color color3 = new Color(rgb1[0] * r + rgb2[0] * ir, rgb1[1] * r + rgb2[1] * ir, rgb1[2] * r + rgb2[2] * ir);
        return color3;
    }
    
    public static void drawLine(final Vec2f start, final Vec2f end, final float width) {
        drawLine(start.getX(), start.getY(), end.getX(), end.getY(), width);
    }
    
    public static void drawLine(final Vec3f start, final Vec3f end, final float width) {
        drawLine((float)start.getX(), (float)start.getY(), (float)start.getZ(), (float)end.getX(), (float)end.getY(), (float)end.getZ(), width);
    }
    
    public static void drawLine(final float x, final float y, final float x1, final float y1, final float width) {
        drawLine(x, y, 0.0f, x1, y1, 0.0f, width);
    }
    
    public static void drawLine(final float x, final float y, final float z, final float x1, final float y1, final float z1, final float width) {
        GL11.glLineWidth(width);
        setupRender(true);
        setupClientState(GLClientState.VERTEX, true);
        RenderUtil.tessellator.addVertex(x, y, z).addVertex(x1, y1, z1).draw(3);
        setupClientState(GLClientState.VERTEX, false);
        setupRender(false);
    }
    
    public static void setupClientState(final GLClientState state, final boolean enabled) {
        RenderUtil.csBuffer.clear();
        if (state.ordinal() > 0) {
            RenderUtil.csBuffer.add(state.getCap());
        }
        RenderUtil.csBuffer.add(32884);
        RenderUtil.csBuffer.forEach(enabled ? RenderUtil.ENABLE_CLIENT_STATE : RenderUtil.DISABLE_CLIENT_STATE);
    }
    
    public static void setupRender(final boolean start) {
        if (start) {
            GlStateManager.enableBlend();
            GL11.glEnable(2848);
            GlStateManager.disableDepth();
            GlStateManager.disableTexture2D();
            GlStateManager.blendFunc(770, 771);
            GL11.glHint(3154, 4354);
        }
        else {
            GlStateManager.disableBlend();
            GlStateManager.enableTexture2D();
            GL11.glDisable(2848);
            GlStateManager.enableDepth();
        }
        GlStateManager.depthMask(!start);
    }

	public static void drawGradientSideways(float x, float f, double d, float g, int color1, int color2) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void drawBorderRect(int i, int j, int k, int l, int rgb, int m) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void rectangleBordered(double d, double e, double f, double g, double h, int color, int color2) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void drawblock(double d, double e, double f, int color, int rgb, float g) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void drawEntityOnScreen(int i, int j, int k, float rotationYaw, float rotationPitch,
			EntityLivingBase target) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void drawBorderedRect(float x, double d, float width, double e, float l1, int rgb, int rgb2) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void drawEntityOnScreen(int p_147046_0_, int p_147046_1_, float targetHeight, float rotationYaw,
			float rotationPitch, EntityLivingBase target) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void rectangle(double d, double e, double f, double g, int color) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void drawBorderedRect(double d, double d2, double e, double e2, float l1, int rgb, int rgb2) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void drawGradientSideways(double d, double e, double d2, double f, int rgb, int rgb2) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static float getAnimationState(float x, float newX, float f) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		return 0;
	}

	public static double getAnimationState(double animationX, float newX, double d) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		return 0;
	}

	public static int reAlpha(int i, float f) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		return 0;
	}

	public static int createShader(String vertexShaderCode, int i) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		return 0;
	}

	public static String getShaderCode(InputStreamReader inputStreamReader) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		return null;
	}

	public static double getAnimationState(double animationX, double d, double d2) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		return 0;
	}

	public static void drawImage(ResourceLocation resourceLocation, int animationX, int i, int scaledWidth,
			int scaledHeight) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void drawWolframEntityESP(EntityLivingBase entity, int rgb, double posX, double posY, double posZ) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void drawEntityESP(double x4, double y4, double z4, double width2, double height2, float red2,
			float green2, float blue2, float f, float lineRed2, float lineGreen2, float lineBlue2, float g, float h) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}

	public static void drawBoundingBox(AxisAlignedBB axisAlignedBB) {
		// TODO 鑷姩鐢熸垚鐨勬柟娉曞瓨鏍�
		
	}
    public static void drawCircle(double x, double y, double radius, int c) {
        float f2 = (float)(c >> 24 & 255) / 255.0f;
        float f22 = (float)(c >> 16 & 255) / 255.0f;
        float f3 = (float)(c >> 8 & 255) / 255.0f;
        float f4 = (float)(c & 255) / 255.0f;
        GlStateManager.alphaFunc(516, 0.001f);
        GlStateManager.color(f22, f3, f4, f2);
        GlStateManager.enableAlpha();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        Tessellator tes = Tessellator.getInstance();
        double i = 0.0;
        while (i < 360.0) {
            double f5 = Math.sin(i * 3.141592653589793 / 180.0) * radius;
            double f6 = Math.cos(i * 3.141592653589793 / 180.0) * radius;
            GL11.glVertex2d((double)((double)f3 + x), (double)((double)f4 + y));
            i += 1.0;
        }
        GlStateManager.disableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.alphaFunc(516, 0.1f);
    }
    public static void drawCircle(float cx, float cy, float r, int num_segments, int c) {
        GL11.glPushMatrix();
        cx *= 2.0F;
        cy *= 2.0F;
        float f = (c >> 24 & 0xFF) / 255.0F;
        float f1 = (c >> 16 & 0xFF) / 255.0F;
        float f2 = (c >> 8 & 0xFF) / 255.0F;
        float f3 = (c & 0xFF) / 255.0F;
        float theta = (float) (6.2831852D / num_segments);
        float p = (float) Math.cos(theta);
        float s = (float) Math.sin(theta);
        float x = r *= 2.0F;
        float y = 0.0F;
        enableGL2D();
        GL11.glScalef(0.5F, 0.5F, 0.5F);
        GL11.glColor4f(f1, f2, f3, f);
        GL11.glBegin(2);
        int ii = 0;
        while (ii < num_segments) {
            GL11.glVertex2f(x + cx, y + cy);
            float t = x;
            x = p * x - s * y;
            y = s * t + p * y;
            ii++;
        }
        GL11.glEnd();
        GL11.glScalef(2.0F, 2.0F, 2.0F);
        disableGL2D();
        GlStateManager.color(1, 1, 1, 1);
        GL11.glPopMatrix();
    }
    public static void enableGL2D() {
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        GL11.glBlendFunc(770, 771);
        GL11.glDepthMask(true);
        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        GL11.glHint(3155, 4354);
    }

    public static void disableGL2D() {
        GL11.glEnable(3553);
        GL11.glDisable(3042);
        GL11.glEnable(2929);
        GL11.glDisable(2848);
        GL11.glHint(3154, 4352);
        GL11.glHint(3155, 4352);
    }
    public void drawCircle(int x, int y, float radius, int color) {
        float alpha = (float) (color >> 24 & 255) / 255.0f;
        float red = (float) (color >> 16 & 255) / 255.0f;
        float green = (float) (color >> 8 & 255) / 255.0f;
        float blue = (float) (color & 255) / 255.0f;
        boolean blend = GL11.glIsEnabled((int) 3042);
        boolean line = GL11.glIsEnabled((int) 2848);
        boolean texture = GL11.glIsEnabled((int) 3553);
        if (!blend) {
            GL11.glEnable((int) 3042);
        }
        if (!line) {
            GL11.glEnable((int) 2848);
        }
        if (texture) {
            GL11.glDisable((int) 3553);
        }
        GL11.glBlendFunc((int) 770, (int) 771);
        GL11.glColor4f((float) red, (float) green, (float) blue, (float) alpha);
        GL11.glBegin((int) 9);
        int i = 0;
        while (i <= 360) {
            GL11.glVertex2d(
                    (double) ((double) x + Math.sin((double) ((double) i * 3.141526 / 180.0)) * (double) radius),
                    (double) ((double) y + Math.cos((double) ((double) i * 3.141526 / 180.0)) * (double) radius));
            ++i;
        }
        GL11.glEnd();
        if (texture) {
            GL11.glEnable((int) 3553);
        }
        if (!line) {
            GL11.glDisable((int) 2848);
        }
        if (!blend) {
            GL11.glDisable((int) 3042);
        }
    }

    public static void drawCircle(float x, float y, float r, float lineWidth, boolean isFull, int color) {
        drawCircle(x, y, r, 10, lineWidth, 360, isFull, color);
      }
    public static void drawCircle(float cx, float cy, double r, int segments, float lineWidth, int part, boolean isFull, int c) {
  	    GL11.glScalef(0.5F, 0.5F, 0.5F);
  	    r *= 2.0D;
  	    cx *= 2.0F;
  	    cy *= 2.0F;
  	    float f2 = (c >> 24 & 0xFF) / 255.0F;
  	    float f3 = (c >> 16 & 0xFF) / 255.0F;
  	    float f4 = (c >> 8 & 0xFF) / 255.0F;
  	    float f5 = (c & 0xFF) / 255.0F;
  	    GL11.glEnable(3042);
  	    GL11.glLineWidth(lineWidth);
  	    GL11.glDisable(3553);
  	    GL11.glEnable(2848);
  	    GL11.glBlendFunc(770, 771);
  	    GL11.glColor4f(f3, f4, f5, f2);
  	    GL11.glBegin(3);
  	    for (int i = segments - part; i <= segments; i++) {
  	      double x = Math.sin(i * Math.PI / 180.0D) * r;
  	      double y = Math.cos(i * Math.PI / 180.0D) * r;
  	      GL11.glVertex2d(cx + x, cy + y);
  	      if (isFull)
  	        GL11.glVertex2d(cx, cy); 
  	    } 
  	    GL11.glEnd();
  	    GL11.glDisable(2848);
  	    GL11.glEnable(3553);
  	    GL11.glDisable(3042);
  	    GL11.glScalef(2.0F, 2.0F, 2.0F);
  	  }
    public static double getEntityRenderX(Entity entity) {
        return entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (Minecraft.getMinecraft()).timer.renderPartialTicks - RenderManager.renderPosX;
      }
    public static double getEntityRenderY(Entity entity) {
        return entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (Minecraft.getMinecraft()).timer.renderPartialTicks - RenderManager.renderPosY;
      }
      
      public static double getEntityRenderZ(Entity entity) {
        return entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (Minecraft.getMinecraft()).timer.renderPartialTicks - RenderManager.renderPosZ;
      }
      public static void drawOutlinedBoundingBox(AxisAlignedBB aa) {

          Tessellator tessellator = Tessellator.getInstance();
          WorldRenderer worldRenderer = tessellator.getWorldRenderer();
          worldRenderer.begin(3, DefaultVertexFormats.POSITION);
          worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
          worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
          worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
          worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
          worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
          tessellator.draw();
          worldRenderer.begin(3, DefaultVertexFormats.POSITION);
          worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
          worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
          worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
          worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
          worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
          tessellator.draw();
          worldRenderer.begin(1, DefaultVertexFormats.POSITION);
          worldRenderer.pos(aa.minX, aa.minY, aa.minZ).endVertex();
          worldRenderer.pos(aa.minX, aa.maxY, aa.minZ).endVertex();
          worldRenderer.pos(aa.maxX, aa.minY, aa.minZ).endVertex();
          worldRenderer.pos(aa.maxX, aa.maxY, aa.minZ).endVertex();
          worldRenderer.pos(aa.maxX, aa.minY, aa.maxZ).endVertex();
          worldRenderer.pos(aa.maxX, aa.maxY, aa.maxZ).endVertex();
          worldRenderer.pos(aa.minX, aa.minY, aa.maxZ).endVertex();
          worldRenderer.pos(aa.minX, aa.maxY, aa.maxZ).endVertex();
          tessellator.draw();
      }
      public static void drawRect(float g, float h, float i, float j, int col1) {
          float f2 = (float)(col1 >> 24 & 255) / 255.0f;
          float f22 = (float)(col1 >> 16 & 255) / 255.0f;
          float f3 = (float)(col1 >> 8 & 255) / 255.0f;
          float f4 = (float)(col1 & 255) / 255.0f;
          GL11.glEnable((int)3042);
          GL11.glDisable((int)3553);
          GL11.glBlendFunc((int)770, (int)771);
          GL11.glEnable((int)2848);
          GL11.glPushMatrix();
          GL11.glColor4f((float)f22, (float)f3, (float)f4, (float)f2);
          GL11.glBegin((int)7);
          GL11.glVertex2d((double)i, (double)h);
          GL11.glVertex2d((double)g, (double)h);
          GL11.glVertex2d((double)g, (double)j);
          GL11.glVertex2d((double)i, (double)j);
          GL11.glEnd();
          GL11.glPopMatrix();
          GL11.glEnable((int)3553);
          GL11.glDisable((int)3042);
          GL11.glDisable((int)2848);
      }
      public static void drawIcon(double d, double e, int sizex, int sizey, ResourceLocation resourceLocation) {
          GL11.glPushMatrix();
          Minecraft.getMinecraft().getTextureManager().bindTexture(resourceLocation);
          GL11.glEnable(3042);
          GL11.glBlendFunc(770, 771);
          GL11.glEnable(2848);
          GlStateManager.enableRescaleNormal();
          GlStateManager.enableAlpha();
          GlStateManager.alphaFunc(516, 0.1f);
          GlStateManager.enableBlend();
          GlStateManager.blendFunc(770, 771);
          GL11.glTranslatef((float)d, (float)e, 0.0f);
          RenderUtil.drawScaledRect(0, 0, 0.0f, 0.0f, sizex, sizey, sizex, sizey, sizex, sizey);
          GlStateManager.disableAlpha();
          GlStateManager.disableRescaleNormal();
          GlStateManager.disableLighting();
          GlStateManager.disableRescaleNormal();
          GL11.glDisable(2848);
          GlStateManager.disableBlend();
          GL11.glPopMatrix();
      }
      public static void drawScaledRect(int x, int y, float u, float v, int uWidth, int vHeight, int width, int height, float tileWidth, float tileHeight) {
          Gui.drawScaledCustomSizeModalRect(x, y, u, v, uWidth, vHeight, width, height, tileWidth, tileHeight);
      }
      public static int getRainbow(int speed, int offset) {
          float hue = (System.currentTimeMillis() + offset) % speed;
          hue /= speed;
          return Color.getHSBColor(hue, 0.75f, 1f).getRGB();
      }
	    public static void drawImage(final ResourceLocation resourceLocation, final float n, final float n2, final float n3, final float n4) {
	        drawImage(resourceLocation, (int)n, (int)n2, (int)n3, (int)n4, 1.0f);
	    }	    public static void drawImage(final ResourceLocation resourceLocation, final int n, final int n2, final int n3, final int n4, final float n5) {
	        final ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
	        GL11.glDisable(2929);
	        GL11.glEnable(3042);
	        GL11.glDepthMask(false);
	        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
	        GL11.glColor4f(1.0f, 1.0f, 1.0f, n5);
	        Minecraft.getMinecraft().getTextureManager().bindTexture(resourceLocation);
	        Gui.drawModalRectWithCustomSizedTexture(n, n2, 0.0f, 0.0f, n3, n4, (float)n3, (float)n4);
	        GL11.glDepthMask(true);
	        GL11.glDisable(3042);
	        GL11.glEnable(2929);
	    }
	    public static  void drawRainbowRect(float x, float y, float x2, float y2) {
	        double width = (x2 - x);
	        for (int i = 0; i <= (width); i++) {
	            Color color = new Color(Color.HSBtoRGB((float)((Wrapper.getPlayer().ticksExisted / width)/2 + (Math.sin(i / width * 0.6))) % 1.0f, 0.5f, 1.0f));
	            drawRect(x+i, y, x+i+1,y2,color.getRGB());
	        }
	    }
}
