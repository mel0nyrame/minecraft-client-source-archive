package Client.Dev.utils;

import net.minecraft.client.*;
import net.minecraft.entity.projectile.*;
import net.minecraft.world.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.network.play.client.*;
import net.minecraft.network.*;
import net.minecraft.client.entity.*;

public class RotationUtils
{
    private static final Minecraft mc;
    
    public static float[] getRotations(final EntityLivingBase ent) {
        final double x = ent.posX;
        final double z = ent.posZ;
        final double y = ent.posY + ent.getEyeHeight() / 2.0f;
        return getRotationFromPositionSlow(x, z, y);
    }
    
    public static float[] getRotationFromPositionSlow(final double x, final double z, final double y) {
        Minecraft.getMinecraft();
        final double xDiff = x - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        final double zDiff = z - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        final double yDiff = y - Minecraft.thePlayer.posY - 1.2;
        final double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        final float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / 3.141592653589793) - 90.0f;
        final float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / 3.141592653589793));
        return new float[] { yaw, pitch };
    }
    
    public static float[] getBlockRotations(final int x2, final int y2, final int z2, final EnumFacing facing) {
        final Minecraft mc2 = Minecraft.getMinecraft();
        final EntitySnowball temp = new EntitySnowball(Minecraft.theWorld);
        temp.posX = x2 + 0.5;
        temp.posY = y2 + 0.5;
        temp.posZ = z2 + 0.5;
        return getAngles(temp);
    }
    
    public static float[] getAngles(final Entity e2) {
        final Minecraft mc2 = Minecraft.getMinecraft();
        return new float[] { getYawChangeToEntity(e2) + Minecraft.thePlayer.rotationYaw, getPitchChangeToEntity(e2) + Minecraft.thePlayer.rotationPitch };
    }
    
    public static float[] getRotations(final Entity entity) {
        if (entity == null) {
            return null;
        }
        Minecraft.getMinecraft();
        final double diffX = entity.posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        final double diffZ = entity.posZ - Minecraft.thePlayer.posZ;
        double diffY;
        if (entity instanceof EntityLivingBase) {
            final EntityLivingBase elb = (EntityLivingBase)entity;
            Minecraft.getMinecraft();
            Minecraft.getMinecraft();
            diffY = elb.posY + (elb.getEyeHeight() - 0.2) - (Minecraft.thePlayer.posY + Minecraft.thePlayer.getEyeHeight());
        }
        else {
            Minecraft.getMinecraft();
            Minecraft.getMinecraft();
            diffY = (entity.boundingBox.minY + entity.boundingBox.maxY) / 2.0 - (Minecraft.thePlayer.posY + Minecraft.thePlayer.getEyeHeight());
        }
        final double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        final float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
        final float pitch = (float)(-Math.atan2(diffY, dist) * 180.0 / 3.141592653589793) - 60.0f;
        return new float[] { yaw, pitch };
    }
    
    public static float getYawChangeToEntity(final Entity entity) {
        final Minecraft mc2 = Minecraft.getMinecraft();
        final double deltaX = entity.posX - Minecraft.thePlayer.posX;
        final double deltaZ = entity.posZ - Minecraft.thePlayer.posZ;
        final double yawToEntity = (deltaZ < 0.0 && deltaX < 0.0) ? (90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX))) : ((deltaZ < 0.0 && deltaX > 0.0) ? (-90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX))) : Math.toDegrees(-Math.atan(deltaX / deltaZ)));
        return MathHelper.wrapAngleTo180_float(-Minecraft.thePlayer.rotationYaw - (float)yawToEntity);
    }
    
    public static float getPitchChangeToEntity(final Entity entity) {
        final Minecraft mc2 = Minecraft.getMinecraft();
        final double deltaX = entity.posX - Minecraft.thePlayer.posX;
        final double deltaZ = entity.posZ - Minecraft.thePlayer.posZ;
        final double deltaY = entity.posY - 1.6 + entity.getEyeHeight() - 0.4 - Minecraft.thePlayer.posY;
        final double distanceXZ = MathHelper.sqrt_double(deltaX * deltaX + deltaZ * deltaZ);
        final double pitchToEntity = -Math.toDegrees(Math.atan(deltaY / distanceXZ));
        return -MathHelper.wrapAngleTo180_float(Minecraft.thePlayer.rotationPitch - (float)pitchToEntity);
    }
    
    public static float[] getRotationFromPosition(final double x2, final double z2, final double y2) {
        Minecraft.getMinecraft();
        final Minecraft mc = RotationUtils.mc;
        final double xDiff = x2 - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        final Minecraft mc2 = RotationUtils.mc;
        final double zDiff = z2 - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        final Minecraft mc3 = RotationUtils.mc;
        final double yDiff = y2 - Minecraft.thePlayer.posY - 1.2;
        final double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        final float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / 3.141592653589793) - 90.0f;
        final float pitch = (float)(-(Math.atan2(yDiff, dist) * 180.0 / 3.141592653589793));
        return new float[] { yaw, pitch };
    }
    
    public static float getDistanceBetweenAngles(final float angle1, final float angle2) {
        float angle3 = Math.abs(angle1 - angle2) % 360.0f;
        if (angle3 > 180.0f) {
            angle3 = 0.0f;
        }
        return angle3;
    }
    
    public static float[] getRotations(final Vec3 position) {
        return getRotations(Minecraft.thePlayer.getPositionVector().addVector(0.0, Minecraft.thePlayer.getEyeHeight(), 0.0), position);
    }
    
    public static float[] getRotations(final Vec3 origin, final Vec3 position) {
        final Vec3 difference = position.subtract(origin);
        final double distance = difference.flat().lengthVector();
        final float yaw = (float)Math.toDegrees(Math.atan2(difference.zCoord, difference.xCoord)) - 90.0f;
        final float pitch = (float)(-Math.toDegrees(Math.atan2(difference.yCoord, distance)));
        return new float[] { yaw, pitch };
    }
    
    public static float[] getRotations(final BlockPos pos) {
        return getRotations(Minecraft.thePlayer.getPositionVector().addVector(0.0, Minecraft.thePlayer.getEyeHeight(), 0.0), new Vec3(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5));
    }
    
    public static float[] getBowAngles(final Entity entity) {
        final double xDelta = entity.posX - entity.lastTickPosX;
        final double zDelta = entity.posZ - entity.lastTickPosZ;
        Minecraft.getMinecraft();
        double d2 = Minecraft.thePlayer.getDistanceToEntity(entity);
        d2 -= d2 % 0.8;
        double xMulti = 1.0;
        double zMulti = 1.0;
        final boolean sprint = entity.isSprinting();
        xMulti = d2 / 0.8 * xDelta * (sprint ? 1.25 : 1.0);
        zMulti = d2 / 0.8 * zDelta * (sprint ? 1.25 : 1.0);
        Minecraft.getMinecraft();
        final double x2 = entity.posX + xMulti - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        final double z2 = entity.posZ + zMulti - Minecraft.thePlayer.posZ;
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        final double y2 = Minecraft.thePlayer.posY + Minecraft.thePlayer.getEyeHeight() - (entity.posY + entity.getEyeHeight());
        Minecraft.getMinecraft();
        final double dist = Minecraft.thePlayer.getDistanceToEntity(entity);
        final float yaw = (float)Math.toDegrees(Math.atan2(z2, x2)) - 90.0f;
        final float pitch = (float)Math.toDegrees(Math.atan2(y2, dist));
        return new float[] { yaw, pitch };
    }
    
    public static float normalizeAngle(final float angle) {
        return (angle + 360.0f) % 360.0f;
    }
    
    public static float getTrajAngleSolutionLow(final float d3, final float d1, final float velocity) {
        final float g2 = 0.006f;
        final float sqrt = velocity * velocity * velocity * velocity - g2 * (g2 * (d3 * d3) + 2.0f * d1 * (velocity * velocity));
        return (float)Math.toDegrees(Math.atan((velocity * velocity - Math.sqrt(sqrt)) / (g2 * d3)));
    }
    
    public static Vec3 getEyesPos() {
        return new Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
    }
    
    public static float[] getRotationsBlock(final BlockPos pos) {
        final Minecraft mc2 = Minecraft.getMinecraft();
        final double d0 = pos.getX() - Minecraft.thePlayer.posX;
        final double d2 = pos.getY() - (Minecraft.thePlayer.posY + Minecraft.thePlayer.getEyeHeight());
        final double d3 = pos.getZ() - Minecraft.thePlayer.posZ;
        final double d4 = MathHelper.sqrt_double(d0 * d0 + d3 * d3);
        final float f2 = (float)(MathHelper.atan2(d3, d0) * 180.0 / 3.141592653589793) - 90.0f;
        final float f3 = (float)(-Math.toDegrees(Math.atan2(d4, d2)));
        return new float[] { f3 };
    }
    
    public static float[] getNeededRotations(final Vec3 vec) {
        final Vec3 eyesPos = getEyesPos();
        final double diffX = vec.xCoord - eyesPos.xCoord + 0.5;
        final double diffY = vec.yCoord - eyesPos.yCoord + 0.5;
        final double diffZ = vec.zCoord - eyesPos.zCoord + 0.5;
        final double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        final float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        final float pitch = (float)(-Math.atan2(diffY, diffXZ) * 180.0 / 3.141592653589793);
        final float[] arrf = { MathHelper.wrapAngleTo180_float(yaw), Minecraft.getMinecraft().gameSettings.keyBindJump.pressed ? 90.0f : MathHelper.wrapAngleTo180_float(pitch) };
        return arrf;
    }
    
    public static void faceVectorPacketInstant(final Vec3 vec) {
        final float[] rotations = getNeededRotations(vec);
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(rotations[0], rotations[1], Minecraft.thePlayer.onGround));
    }
    
    public static float getYawChange(final float yaw, final double posX, final double posZ) {
        Minecraft.getMinecraft();
        final double deltaX = posX - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        final double deltaZ = posZ - Minecraft.thePlayer.posZ;
        double yawToEntity = 0.0;
        if (deltaZ < 0.0 && deltaX < 0.0) {
            if (deltaX != 0.0) {
                yawToEntity = 90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX));
            }
        }
        else if (deltaZ < 0.0 && deltaX > 0.0) {
            if (deltaX != 0.0) {
                yawToEntity = -90.0 + Math.toDegrees(Math.atan(deltaZ / deltaX));
            }
        }
        else if (deltaZ != 0.0) {
            yawToEntity = Math.toDegrees(-Math.atan(deltaX / deltaZ));
        }
        return MathHelper.wrapAngleTo180_float(-(yaw - (float)yawToEntity));
    }
    
    public static float[] getRotations(final double posX, final double posY, final double posZ) {
        final Minecraft mc = RotationUtils.mc;
        final EntityPlayerSP player = Minecraft.thePlayer;
        final double x = posX - player.posX;
        final double y = posY - (player.posY + player.getEyeHeight());
        final double z = posZ - player.posZ;
        final double dist = MathHelper.sqrt_double(x * x + z * z);
        final float yaw = (float)(Math.atan2(z, x) * 180.0 / 3.141592653589793) - 90.0f;
        final float pitch = (float)(-(Math.atan2(y, dist) * 180.0 / 3.141592653589793));
        return new float[] { yaw, pitch };
    }
    
    public static float[] getRotationsEntity(final EntityLivingBase entity) {
        final double posX = entity.posX;
        Minecraft.getMinecraft();
        final double d0 = posX - Minecraft.thePlayer.posX;
        final double posZ = entity.posZ;
        Minecraft.getMinecraft();
        final double d2 = posZ - Minecraft.thePlayer.posZ;
        final double n = entity.posY - entity.getEyeHeight();
        Minecraft.getMinecraft();
        final double minY = Minecraft.thePlayer.getEntityBoundingBox().minY;
        Minecraft.getMinecraft();
        final double maxY = Minecraft.thePlayer.getEntityBoundingBox().maxY;
        Minecraft.getMinecraft();
        final double d3 = n - (minY - (maxY - Minecraft.thePlayer.getEntityBoundingBox().minY));
        final double d4 = MathHelper.sqrt_double(d0 * d0 + d2 * d2);
        final float f = (float)(MathHelper.atan2(d2, d0) * 180.0 / 3.141592653589793) - 90.0f;
        final float f2 = (float)(-(MathHelper.atan2(d3, d4) * 180.0 / 3.141592653589793));
        return new float[] { f, f2 };
    }
    
    static {
        mc = Minecraft.getMinecraft();
    }
}
