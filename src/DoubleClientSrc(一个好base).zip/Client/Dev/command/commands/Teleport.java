/*
 * Decompiled with CFR 0_132.
 */
package Client.Dev.command.commands;

import java.util.logging.Logger;

import org.lwjgl.input.Keyboard;

import Client.Dev.Client;
import Client.Dev.api.EventHandler;
import Client.Dev.api.events.world.EventMove;
import Client.Dev.api.events.world.EventPacketRecieve;
import Client.Dev.api.events.world.EventPacketSend;
import Client.Dev.api.events.world.EventTick;
import Client.Dev.command.Command;
import Client.Dev.management.ModuleManager;
import Client.Dev.module.Module;
import Client.Dev.module.modules.movement.TeleportMod;
import Client.Dev.pathfinding.CustomVec3;
import Client.Dev.pathfinding.PathfindingUtils;
import Client.Dev.utils.Helper;
import Client.Dev.utils.MovementUtils;
import Client.Dev.utils.TimerUtil;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0CPacketInput;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraft.network.play.client.C13PacketPlayerAbilities;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.util.EnumChatFormatting;

public class Teleport
extends Command {
    public Teleport() {
        super("tp", new String[]{"tp", "teleport"}, "", "Teleport to the position you entered");
    }
	

    @Override
    public String execute(final String[] args) {
        if (args.length >= 3) {
            TeleportMod.x = Float.valueOf(args[0]);
            TeleportMod.y = Float.valueOf(args[1]);
            TeleportMod.z = Float.valueOf(args[2]);
            ModuleManager.getModuleByClass(TeleportMod.class).setEnabled(true);
        }
        else if (args.length >= 1) {
            if (Minecraft.theWorld.getPlayerEntityByName(args[0]) != null) {
                TeleportMod.isTPPlayer = true;
                TeleportMod.playername = args[0];
                ModuleManager.getModuleByClass(TeleportMod.class).setEnabled(true);
            }
            else {
                Helper.sendMessageWithoutPrefix("\u00a7bWarning!\u00a77 Player do not exist");
            }
        }
        else {
            Helper.sendMessageWithoutPrefix("\u00a7bCorrect usage:\u00a77 .tp <x> <y> <z> or .tp <name>");
        }
        return null;
    }
}