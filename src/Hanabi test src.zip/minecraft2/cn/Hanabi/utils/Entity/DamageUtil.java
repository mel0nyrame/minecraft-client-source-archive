package cn.Hanabi.utils.Entity;

import java.awt.Color;
import java.text.DecimalFormat;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public class DamageUtil {
	public static final Minecraft mc = Minecraft.getMinecraft();

	public static DecimalFormat format = new DecimalFormat("0.0");
	public static EntityLivingBase lastEnt;
	public static float lastHealth = -1;
	public static float damageDelt = 0;
	public static float lastPlayerHealth = -1;
	public static float damageDeltToPlayer = 0;

	public static String NameDisplay(EntityLivingBase player) {
		return format.format(player.getName());
	}

	public static String DamageInPut(EntityLivingBase player) {
		if (player != lastEnt) {
			lastEnt = player;
			lastHealth = player.getHealth();
			damageDelt = 0;
			damageDeltToPlayer = 0;
		}

		if (lastHealth != player.getHealth() && player.getHealth() - lastHealth < 1) {
			damageDelt = (player.getHealth() - lastHealth);
			lastHealth = player.getHealth();
		}

		if (!mc.thePlayer.isEntityAlive()) {
			lastPlayerHealth = -1;
		}

		if (lastPlayerHealth == -1 && mc.thePlayer.isEntityAlive()) {
			lastPlayerHealth = mc.thePlayer.getHealth();
		}

		if (lastPlayerHealth != mc.thePlayer.getHealth()) {
			damageDeltToPlayer = (mc.thePlayer.getHealth() - lastPlayerHealth);
			lastPlayerHealth = mc.thePlayer.getHealth();
		}

		return format.format(damageDeltToPlayer);
	}

	public static String DamageOutPut(EntityLivingBase player) {
		if (player != lastEnt) {
			lastEnt = player;
			lastHealth = player.getHealth();
			damageDelt = 0;
			damageDeltToPlayer = 0;
		}

		if (lastHealth != player.getHealth() && player.getHealth() - lastHealth < 1) {
			damageDelt = (player.getHealth() - lastHealth);
			lastHealth = player.getHealth();
		}

		if (!mc.thePlayer.isEntityAlive()) {
			lastPlayerHealth = -1;
		}

		if (lastPlayerHealth == -1 && mc.thePlayer.isEntityAlive()) {
			lastPlayerHealth = mc.thePlayer.getHealth();
		}

		if (lastPlayerHealth != mc.thePlayer.getHealth()) {
			damageDeltToPlayer = (mc.thePlayer.getHealth() - lastPlayerHealth);
			lastPlayerHealth = mc.thePlayer.getHealth();
		}

		return format.format(damageDelt);
	}

}
