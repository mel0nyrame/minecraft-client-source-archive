package cn.Hanabi.utils.Rotation;

import cn.Hanabi.Wrapper;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class RayCastUtil {
    public static EntityLivingBase rayTrace(float yaw, float pitch, float range) {
        Entity entity = new EntityOtherPlayerMP(Minecraft.getMinecraft().theWorld, Minecraft.getMinecraft().thePlayer.getGameProfile());

        float wasYaw = Minecraft.getMinecraft().getRenderViewEntity().rotationYaw;
        float wasPitch = Minecraft.getMinecraft().getRenderViewEntity().rotationPitch;

        Minecraft.getMinecraft().getRenderViewEntity().rotationYaw = yaw;
        Minecraft.getMinecraft().getRenderViewEntity().rotationPitch = pitch;

        entity.copyDataFromOld(Minecraft.getMinecraft().getRenderViewEntity());
        entity.copyLocationAndAnglesFrom(Minecraft.getMinecraft().getRenderViewEntity());

        Minecraft.getMinecraft().getRenderViewEntity().rotationPitch = wasPitch;
        Minecraft.getMinecraft().getRenderViewEntity().rotationYaw = wasYaw;

        return entityRaytrace(entity, 1.0f, range);
    }


    private static EntityLivingBase entityRaytrace(Entity entity, float partialTicks, double blockReachDistance) {
        Entity pointedEntity = null;
        Vec3 eyePos = entity.getPositionEyes(partialTicks);
        Vec3 look = entity.getLook(partialTicks);
        Vec3 vec32 = eyePos.addVector(look.xCoord * blockReachDistance, look.yCoord * blockReachDistance, look.zCoord * blockReachDistance);
        float f = 1.0f;
        List list = Minecraft.getMinecraft().theWorld.getEntitiesInAABBexcluding(entity, entity.getEntityBoundingBox().addCoord(look.xCoord * blockReachDistance, look.yCoord * blockReachDistance, look.zCoord * blockReachDistance).expand(f, f, f), Predicates.and(EntitySelectors.NOT_SPECTATING, new Predicate<Entity>() {
            public boolean apply(Entity p_apply_1_) {
                return p_apply_1_.canBeCollidedWith();
            }
        }));
        double d2 = blockReachDistance;

        for (int i = 0; i < list.size(); ++i) {
            Entity entity1 = (Entity) list.get(i);

            if (entity1 == Minecraft.getMinecraft().thePlayer)
                continue;

            float f1 = entity1.getCollisionBorderSize();
            AxisAlignedBB axisalignedbb = entity1.getEntityBoundingBox().expand(f1, f1, f1);
            MovingObjectPosition movingobjectposition = axisalignedbb.calculateIntercept(eyePos, vec32);

            if (axisalignedbb.isVecInside(eyePos)) {
                if (d2 >= 0.0D) {
                    pointedEntity = entity1;
                    d2 = 0.0D;
                }
            } else if (movingobjectposition != null) {
                double d3 = eyePos.distanceTo(movingobjectposition.hitVec);

                if (d3 < d2 || d2 == 0.0D) {
                    if (entity1 == entity.ridingEntity) {
                        if (d2 == 0.0D) {
                            pointedEntity = entity1;
                        }
                    } else {
                        pointedEntity = entity1;
                        d2 = d3;
                    }
                }
            }
        }

        return (EntityLivingBase) pointedEntity;
    }



    public static MovingObjectPosition rayTraceEntity(Entity var0, Vec3 var1, Vec3 var2) {
        MovingObjectPosition var3 = Minecraft.getMinecraft().theWorld.rayTraceBlocks(var1, var2, false, true, true);
        EntityLivingBase var4 = null;
        double var10004 = var1.xCoord - 0.5D;
        double var10005 = var1.yCoord - 0.5D;
        double var10006 = var1.zCoord - 0.5D;
        List var5 = Minecraft.getMinecraft().theWorld.getEntitiesWithinAABB(EntityLivingBase.class, (new AxisAlignedBB(var10004, var10005, var10006, var2.xCoord + 0.5D, var2.yCoord + 0.5D, var2.zCoord + 0.5D)).expand(1.0D, 1.0D, 1.0D));
        double var6 = 0.0D;
        Iterator var8 = var5.iterator();

        while(true) {
            EntityLivingBase var9;
            double var14;
            do {
                MovingObjectPosition var13;
                do {
                    do {
                        do {
                            if(!var8.hasNext()) {
                                return var4 != null?new MovingObjectPosition(var4):var3;
                            }

                            var9 = (EntityLivingBase)var8.next();
                        } while(!var9.canBeCollidedWith());
                    } while(var9 == var0);

                    double var10 = 0.2D;
                    AxisAlignedBB var12 = var9.getEntityBoundingBox().expand(var10, var10, var10);
                    var13 = var12.calculateIntercept(var1, var2);
                } while(var13 == null);

                var14 = var2.squareDistanceTo(var13.hitVec);
            } while(var14 >= var6 && var6 != 0.0D);

            var4 = var9;
            var6 = var14;
        }
    }


    public static MovingObjectPosition rayTraceEntity(Entity var0, double var1, float var3, float var4) {
        Vec3 var5 = var0.getPositionEyes(Wrapper.getTimer().renderPartialTicks);
        Vec3 var6 = ((Entity)var0).getVectorForRotation(var3, var4);
        Vec3 var7 = var5.addVector(var6.xCoord * var1, var6.yCoord * var1, var6.zCoord * var1);
        return rayTraceEntity(var0, var5.addVector(var6.xCoord * 0.25D, var6.yCoord * 0.25D, var6.zCoord * 0.25D), var7);
    }




}
