package cn.Hanabi.gui.mainMenu;

import cn.Hanabi.Client;
import cn.Hanabi.Hanabi;
import cn.Hanabi.altmanager.GuiAltManager;
import cn.Hanabi.hmlProject.HMLHook;
import cn.Hanabi.hmlProject.HMLManager;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.utils.Misc.Colors;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.utils.ParticleUtils;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.utils.fontmanager.FontManager;
import cn.Hanabi.utils.fontmanager.HanabiFonts;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;
import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;

public class GuiCustomMainMenu extends GuiScreen {

	public ArrayList<MenuSlot> slots = new ArrayList<MenuSlot>();
	public ScaledResolution sr;

	public TimeHelper timer = new TimeHelper();

	public boolean coolDown = true;

	private float currentX;
	private float currentY;

	@Override
	public void initGui() {
		sr = new ScaledResolution(Minecraft.getMinecraft());

		this.coolDown = true;

		this.timer.reset();

		this.slots.clear();

		this.slots.add(new MenuSlot("SelectWorld", HanabiFonts.ICON_MAINMENU_SINGLE, new GuiSelectWorld(this)));
		this.slots.add(new MenuSlot("Multiplayer", HanabiFonts.ICON_MAINMENU_MULTI, new GuiMultiplayer(this)));
		this.slots.add(new MenuSlot("AltManager", HanabiFonts.ICON_MAINMENU_ALTMANAGER, new GuiAltManager()));
		this.slots.add(new MenuSlot("Options", HanabiFonts.ICON_MAINMENU_SETTINGS, new GuiOptions(this, this.mc.gameSettings)));
		//this.slots.add(new MenuSlot("鐗堟湰鍒囨崲", HanabiFonts.ICON_MAINMENU_MULTI, new GuiProtocolSelector(this)));

		this.slots.add(new MenuSlot("QUIT", HanabiFonts.ICON_MAINMENU_QUITGAME, null));
	}

	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        sr = new ScaledResolution(Minecraft.getMinecraft());

        if (this.coolDown) {
            if (this.timer.isDelayComplete(500L)) {
                coolDown = false;
                timer.reset();
            }
        }

		int h = new ScaledResolution(this.mc).getScaledHeight();
		int w = new ScaledResolution(this.mc).getScaledWidth();
		ScaledResolution sr = new ScaledResolution(this.mc);
		float xDiff = ((float) (mouseX - h / 2) - this.currentX) / (float) sr.getScaleFactor();
		float yDiff = ((float) (mouseY - w / 2) - this.currentY) / (float) sr.getScaleFactor();
		this.currentX += xDiff * 0.3f;
		this.currentY += yDiff * 0.3f;
		GlStateManager.translate(this.currentX / 30.0f, this.currentY / 15.0f, 0.0f);
        if (!Client.onDebug) {
            RenderUtil.drawImage(new ResourceLocation("Client/mainmenu/mainmenu.png"), -30, -30, sr.getScaledWidth() + 60,
                    sr.getScaledHeight() + 60);
        } else {
            RenderUtil.drawImage(new ResourceLocation("Client/mainmenu/scifi.png"), -30, -30, sr.getScaledWidth() + 60,
                    sr.getScaledHeight() + 60);
        }
		GlStateManager.translate(-this.currentX / 30.0f, -this.currentY / 15.0f, 0.0f);

		ParticleUtils.drawParticles(mouseX, mouseY);

        int defaultX = sr.getScaledWidth() / 2 - 150;
        int defaultY = sr.getScaledHeight() / 2;

        for (MenuSlot slot : this.slots) {
            slot.draw(mouseX, mouseY, defaultX, defaultY);

            if (!this.coolDown && !Hanabi.INSTANCE.loadFont) {
				slot.onClick(mouseX, mouseY, defaultX, defaultY);
			}

			defaultX += 70;
		}

		String t1 = "Wellcome, " + Mod.username;
		Hanabi.INSTANCE.fontManager.wqy18.drawString(t1,
				(float) (sr.getScaledWidth() - 55 - Hanabi.INSTANCE.fontManager.wqy18.getStringWidth(t1)), 20, -1);

		int hmlhits = HMLManager.hooks.size();
		Hanabi.INSTANCE.fontManager.wqy18.drawString("hanabi pro already.", 3, 2, Color.GREEN.getRGB());
        if (hmlhits > 0)
            Hanabi.INSTANCE.fontManager.wqy18.drawString("ALREADY CRACKED ALREADY CRACKED ALREADY CRACKED", 3, 13, Color.RED.getRGB());

        GL11.glPushMatrix();
        GL11.glColor4f(1, 1, 1, 0f);
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glDepthMask(false);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        if (!Client.onDebug) {
            Minecraft.getMinecraft().getRenderManager().renderEngine
                    .bindTexture(new ResourceLocation("Client/mainmenu/avatar.png"));
            this.drawScaledTexturedModalRect(sr.getScaledWidth() - 46, 9, 0, 0, 32, 32, 8.1f);
        } else {
            Minecraft.getMinecraft().getRenderManager().renderEngine
                    .bindTexture(new ResourceLocation("Client/mainmenu/ava.png"));
            this.drawScaledTexturedModalRect(sr.getScaledWidth() - 46, 9, 0, 0, 32, 32, 8.1f);
        }
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glEnable(2929);
        RenderUtil.drawArc(sr.getScaledWidth() - 30, 25, 16, Colors.WHITE.c, 0, 360, 2);
        GL11.glPopMatrix();

        Hanabi.INSTANCE.fontManager.comfortaa17.drawString("Fake Exhibition - Epic Build " + "Pro1.8.999", 2f,
                sr.getScaledHeight() - 20, -1);

        if (Hanabi.INSTANCE.loadFont) {
			Hanabi.INSTANCE.fontManager.wqy18.drawString(
					"姝ｅ湪鍔犺浇鍓╀綑瀛椾綋,璇风◢鍚�... (" + FontManager.fontName + ")", 2f, sr.getScaledHeight() - 10,
					-1);
		} else {
			Hanabi.INSTANCE.fontManager.comfortaa17.drawString(
					Hanabi.CLIENT_NAME + " build " + Hanabi.CLIENT_VERSION + " - Epic VErsion", 2f,
					sr.getScaledHeight() - 10, -1);
		}

		super.drawScreen(mouseX, mouseY, partialTicks);
	}

	public void drawScaledTexturedModalRect(double x, double y, double textureX, double textureY, double width,
			double height, float scale) {
		float f = 0.00390625F * scale;
		float f1 = 0.00390625F * scale;
		Tessellator tessellator = Tessellator.getInstance();
		WorldRenderer worldrenderer = tessellator.getWorldRenderer();
		worldrenderer.begin(7, DefaultVertexFormats.POSITION_TEX);
		worldrenderer.pos(x + 0, y + height, this.zLevel)
				.tex((float) (textureX + 0) * f, (float) (textureY + height) * f1).endVertex();
		worldrenderer.pos(x + width, y + height, this.zLevel)
				.tex((float) (textureX + width) * f, (float) (textureY + height) * f1)
				.endVertex();
		worldrenderer.pos(x + width, y + 0, this.zLevel)
				.tex((float) (textureX + width) * f, (float) (textureY + 0) * f1).endVertex();
		worldrenderer.pos(x + 0, y + 0, this.zLevel)
				.tex((float) (textureX + 0) * f, (float) (textureY + 0) * f1).endVertex();
		tessellator.draw();
	}

	@Override
	public void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
		super.mouseClicked(mouseX, mouseY, mouseButton);
	}

	@Override
	public void updateScreen() {
		super.updateScreen();
	}

	@Override
	public void onGuiClosed() {
		super.onGuiClosed();
	}

}
