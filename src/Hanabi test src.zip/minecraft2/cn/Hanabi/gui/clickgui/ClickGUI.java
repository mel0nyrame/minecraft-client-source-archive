/*
 * Copyright (c) 2018 superblaubeere27
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

package cn.Hanabi.gui.clickgui;

import cn.Hanabi.Hanabi;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.modules.render.HUD;
import cn.Hanabi.utils.GLUtil;
import cn.Hanabi.utils.fontmanager.UnicodeFontRenderer;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;

import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends GuiScreen {
    
    public static Color PANEL_MAIN_COLOR = new Color(0, 0, 0, 200);
    
    public static Color PANEL_SECONDARY_COLOR = new Color(0x4286F4);
    
    private final List<Panel> panels = new ArrayList<>();

    public ClickGUI() {
    }
    
    public void init() {
        int x = 0;
        int width = 100;

        for (final Category moduleCategory : Category.values()) {
            final Panel panel = new Panel(moduleCategory.toString(), x, 50, width);
            Hanabi.INSTANCE.moduleManager.getModules().stream().filter(module -> module.getCategory() == moduleCategory).forEach(module -> panel.addButton(new Button(panel, module)));

            if (panel.getButtons().size() > 0) {
                panels.add(panel);
                x += width * 1.2;
            }

        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
    	UnicodeFontRenderer font = Hanabi.INSTANCE.fontManager.comfortaa16;
    	
        for (final Panel panel : panels) {
            // Draw panel
            Gui.drawRect(panel.getX() - 2, panel.getY() - 2, panel.getX() + panel.getWidth() + 2, panel.getY() + 20, HUD.rainbow(0));


            GL11.glLineWidth(panel.isDrag() ? 2.0f : 1.0f);

            GLUtil.drawRect(GL11.GL_LINE_LOOP, panel.getX() - 2, panel.getY() - 2, panel.getX() + panel.getWidth() + 2, panel.getY() + 20, PANEL_MAIN_COLOR.hashCode());
            font.drawStringWithShadow(panel.getPanelName(), panel.getX() + 2f, panel.getY() + 5f, 0xffffff);

            for (int i = 0; i < panel.getButtons().size(); i++) {
                final Button button = panel.getButtons().get(i);
                Gui.drawRect(panel.getX(), panel.getY() + 20 + (20 * i), panel.getX() + panel.getWidth(), panel.getY() + (20 * i) + 40, PANEL_MAIN_COLOR.getRGB());
                font.drawStringWithShadow(button.getModule().getName(), panel.getX() + 5f, panel.getY() + 20 + (20 * i) + 7, button.getModule().isEnabled() ? 0x00ff00 : 0xffffff);
                button.renderExtended(panel.getX() + panel.getWidth(), panel.getY() + 20 + (20 * i) + 7);
            }

            // Drag panel
            if (panel.isDrag()) {
                panel.setX(mouseX + panel.getDragX());
                panel.setY(mouseY + panel.getDragY());
            }
        }

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        if (mouseButton != 0 && mouseButton != 1) {
            return;
        }


        OuterLoop:
        for (int index = panels.size() - 1; index >= 0; index--) {
            final Panel panel = panels.get(index);


            // Drag panel
            if (panel.isHoverHead(mouseX, mouseY) && mouseButton == 0) {
                panel.setDrag(true);
                panel.setDragX(panel.getX() - mouseX);
                panel.setDragY(panel.getY() - mouseY);
                panels.remove(panel);
                panels.add(panel);
                break;
            }

            //
            for (int buttonIndex = 0; buttonIndex < panel.getButtons().size(); buttonIndex++) {
                final Button button = panel.getButtons().get(buttonIndex);

                if (button.isHover(panel.getX(), panel.getY() + 20 + (20 * buttonIndex), panel.getWidth(), 20, mouseX, mouseY) && mouseButton == 0) {
                    button.getModule().setState(!button.getModule().getState());
                    this.mc.getSoundHandler().playSound(PositionedSoundRecord.create(new ResourceLocation("random.bow"), 1.0f));
                    break OuterLoop;
                }
                if (button.isHover(panel.getX(), panel.getY() + 20 + (20 * buttonIndex), panel.getWidth(), 20, mouseX, mouseY) && mouseButton == 1) {
                    button.setExtended(!button.isExtended());
                    this.mc.getSoundHandler().playSound(PositionedSoundRecord.create(new ResourceLocation("random.bow"), 1.0f));
                    break OuterLoop;
                }

                if (button.onMouseClick(mouseX, mouseY, mouseButton)) break OuterLoop;
            }
        }

        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        for (final Panel panel : panels) {
            panel.setDrag(false);
        }

        super.mouseReleased(mouseX, mouseY, state);
    }
    
    public void onGuiClosed() {
        this.mc.entityRenderer.stopUseShader();
    }
}