package cn.Hanabi.gui.clickgui.hanabi;

import cn.Hanabi.Hanabi;
import cn.Hanabi.gui.clickgui.hanabi.bar.Button;
import cn.Hanabi.gui.clickgui.hanabi.bar.SideBar;
import cn.Hanabi.gui.clickgui.hanabi.window.Window;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.player.ModChecker;
import cn.Hanabi.modules.modules.render.ClickGUIModule;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends GuiScreen {
	SideBar sideBar;
	List<Window> windows = new ArrayList<Window>();
	boolean exiting = false;
	private static final TimeHelper timer = new TimeHelper();
	public ClickGUI() {
		try {
			sideBar = new SideBar();

			for (int i = 0; i < Category.values().length; i++) {
				Window win = new Window(Category.values()[i]);
				windows.add(win);
			}
		} catch (Throwable e) {

		}
	}

	public void initGui() {
		exiting = false;
		animpos = height+sr.getScaledHeight()+10;
		try {
			if (this.mc.theWorld != null && ClickGUIModule.blur.getValueState()) {
				((EntityRenderer) this.mc.entityRenderer).loadShader2(new ResourceLocation("shaders/post/blur.json"));
			}


			// 修復Bug
			for (Mod mod : ModManager.getModList()) {
				mod.modButton = null;
			}

			for (Window win : windows) {
				win.createModUI();
			}

			Window.booleanValueMap.clear();
		} catch (Throwable e) {
			PlayerUtil.tellPlayer("\247b[Hanabi]\247a加载Blur出现异常，建议关闭快速渲染。");
		}
	}
	static ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
	public static float animpos = sr.getScaledHeight()+sr.getScaledHeight() + 10;

	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
//		if (timer.hasReached(12L)) {
			animpos = (int) RenderUtil.getAnimationStateSmooth(0,animpos,0.13f);
//			timer.reset();
//		}
		if (exiting) {
			this.mc.displayGuiScreen((GuiScreen) null);
			this.mc.setIngameFocus();
		}
		GlStateManager.translate(0, animpos, 0);
		if (ModManager.getModule("StaffAnalyzer").isEnabled() && ModChecker.ui != null)
			ModChecker.ui.mouseListener(mouseX, mouseY);
		if (Hanabi.INSTANCE.sbm != null)
			Hanabi.INSTANCE.sbm.moveWindow(mouseX, mouseY);
		try {
			sideBar.draw();
			for (Button but : sideBar.button) {
				if (but.active) {
					for (Window window : windows) {
						if (window.category.toString().equals(but.title)) {
							window.draw(mouseX, mouseY);
							break;
						}
					}
					break;
				}
			}
		} catch (Throwable e) {

		}
	}

	public void mouseReleased(int mouseX, int mouseY, int state) {
	}

	@Override
	public void keyTyped(char typedChar, int keyCode) throws IOException {
		if (keyCode == 1) {
			exiting = true;
		}
	}

	public void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
		try {
			sideBar.onMouseClick(mouseX, mouseY);
			for (Button but : sideBar.button) {
				if (but.active) {
					for (Window window : windows) {
						if (window.category.toString().equals(but.title)) {
							window.onMouseClick(mouseX, mouseY);
							break;
						}
					}
					break;
				}
			}
		} catch (Throwable e) {

		}
	}

	private boolean isHovering(int mouseX, int mouseY, int xLeft, int yUp, int xRight, int yBottom) {
		return mouseX > xLeft && mouseX < xRight && mouseY > yUp && mouseY < yBottom;
	}

	public void onGuiClosed() {
		try {
			this.mc.entityRenderer.stopUseShader();
		} catch (Throwable e) {
			PlayerUtil.tellPlayer("\247b[Hanabi]\247a加载Blur出现异常，建议关闭快速渲染。");
		}
	}
}
