package cn.Hanabi.modules.modules.movement.Speed;

import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.utils.Entity.MoveUtils;
import cn.Hanabi.value.Value;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;

public class Speed_AAC {
    static Value<String> mode = new Value<String>("Speed", "AACMode", 0);
    Minecraft mc = Minecraft.getMinecraft();
    private boolean doJump;
    private int jumps;
    private boolean firstJump;
    private boolean waitForGround;


    public Speed_AAC() {
        mode.addValue("Hive");
        mode.addValue("AAC3.5.0");
        mode.addValue("AAC3.3.13");

    }

    public void onPre(EventPreMotion e) {
        if (mode.isCurrentMode("Hive")) {
            if (MoveUtils.isMoving()) {
                if (mc.thePlayer.hurtTime <= 0) {
                    if (mc.thePlayer.onGround) {
                        waitForGround = false;

                        if (!firstJump)
                            firstJump = true;

                        mc.thePlayer.jump();
                        mc.thePlayer.motionY = 0.41;
                    } else {
                        if (waitForGround)
                            return;

                        if (mc.thePlayer.isCollidedHorizontally)
                            return;

                        firstJump = false;
                        mc.thePlayer.motionY -= 0.0149;
                    }

                    if (!mc.thePlayer.isCollidedHorizontally)
                        MoveUtils.forward(firstJump ? 0.0016 : 0.001799);
                } else {
                    firstJump = true;
                    waitForGround = true;
                }
            } else {
                mc.thePlayer.motionZ = 0;
                mc.thePlayer.motionX = 0;
            }

            final double speed = MoveUtils.getSpeed();
            mc.thePlayer.motionX = -(Math.sin(MoveUtils.getDirection()) * speed);
            mc.thePlayer.motionZ = Math.cos(MoveUtils.getDirection()) * speed;
        }
        if (mode.isCurrentMode("AAC3.5.0")) {
            if (MoveUtils.isMoving() && !mc.thePlayer.isInWater() && !mc.thePlayer.isInLava()) {
                mc.thePlayer.jumpMovementFactor += 0.00208F;

                if (mc.thePlayer.fallDistance <= 1F) {
                    if (mc.thePlayer.onGround) {
                        mc.thePlayer.jump();
                        mc.thePlayer.motionX *= 1.0118F;
                        mc.thePlayer.motionZ *= 1.0118F;
                    } else {
                        mc.thePlayer.motionY -= 0.0147F;

                        mc.thePlayer.motionX *= 1.00138F;
                        mc.thePlayer.motionZ *= 1.00138F;
                    }
                }
            }
        }
        if (mode.isCurrentMode("AAC3.3.13")) {
            if (!MoveUtils.isMoving() || mc.thePlayer.ridingEntity != null || mc.thePlayer.hurtTime > 0)
                return;

            if (mc.thePlayer.onGround) {
                mc.thePlayer.jump();
                mc.thePlayer.motionY = 0.405;
                mc.thePlayer.motionX *= 1.004;
                mc.thePlayer.motionZ *= 1.004;
                return;
            }

            final double speed = MoveUtils.getSpeed() * 1.0072D;
            final double yaw = Math.toRadians(mc.thePlayer.rotationYaw);
            mc.thePlayer.motionX = -Math.sin(yaw) * speed;
            mc.thePlayer.motionZ = Math.cos(yaw) * speed;
        }
    }

    public void onEnable() {
        firstJump = true;

        doJump = true;
        jumps = 0;

    }


    public void onDisable() {
        if (mc.thePlayer == null) return;
        ((EntityPlayer) mc.thePlayer).setSpeedInAir(0.02F);
    }
}
