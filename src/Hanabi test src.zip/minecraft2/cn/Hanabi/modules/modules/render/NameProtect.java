package cn.Hanabi.modules.modules.render;

import com.darkmagician6.eventapi.EventTarget;

import cn.Hanabi.Client;
import cn.Hanabi.events.EventPacket;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.util.ChatComponentText;

public class NameProtect extends Mod {

	public NameProtect() {
		super("NameProtect", Category.RENDER);
		// TODO 自动生成的构造函数存根
	}

	@EventTarget
	public void onPacket(EventPacket ep) {
		if (mc.thePlayer != null && mc.theWorld != null && ep.getPacket() instanceof S02PacketChat) {
			S02PacketChat packet = (S02PacketChat) ep.getPacket();
			S02PacketChat iPacket = (S02PacketChat) packet;

			iPacket.setChatComponent(new ChatComponentText(
					packet.getChatComponent().getFormattedText().replace(mc.thePlayer.getName(), Client.username)));
		}
	}

}
