
package cn.Hanabi.modules.modules.render;

import cn.Hanabi.gui.clickgui.hanabi.ClickGUI;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.value.Value;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;

public class ClickGUIModule extends Mod {
	public static final ClickGUI clickGui = new ClickGUI();
	ScaledResolution sr;
	public static Value<String> theme = new Value<String>("ClickGUI", "Theme", 0);
	public static Value<Boolean> blur = new Value<Boolean>("ClickGUI_Blur", true);


	int lastWidth = 0;
	public ClickGUIModule() {
		super("ClickGUI", Category.RENDER, true, true, Keyboard.KEY_RSHIFT);

		theme.addValue("Dark");
		theme.addValue("Light");

		setState(false);

	}

	public static ClickGUI hanabi;

	@Override
	public void onEnable() {
		if (mc.thePlayer == null)
			return;
		sr = new ScaledResolution(Minecraft.getMinecraft());
		if (hanabi == null || lastWidth != sr.getScaledWidth()) {
			lastWidth = sr.getScaledWidth();
			hanabi = new ClickGUI();
		}

		if(mc.currentScreen instanceof ClickGUI) {
			this.setState(false);
			return;
		}

		mc.displayGuiScreen(hanabi);

		setState(false);
	}
}
