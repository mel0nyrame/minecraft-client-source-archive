package cn.Hanabi.modules.modules.render;

import cn.Hanabi.Wrapper;
import cn.Hanabi.events.EventRender;

import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import com.darkmagician6.eventapi.EventTarget;


public class NoHurtCam extends Mod {

	public NoHurtCam() {
		super("NoHurtCam", Category.RENDER);
	}

}