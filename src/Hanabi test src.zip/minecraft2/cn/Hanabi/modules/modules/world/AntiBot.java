package cn.Hanabi.modules.modules.world;

import cn.Hanabi.events.EventPacket;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.events.EventUpdate;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.combat.KillAura;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.S0BPacketAnimation;
import net.minecraft.network.play.server.S0CPacketSpawnPlayer;
import net.minecraft.network.play.server.S18PacketEntityTeleport;
import net.minecraft.util.MathHelper;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class AntiBot extends Mod {
    private static final Value mode = new Value("AntiBot", "Mode", 0);
    public static List<EntityLivingBase> bots = new ArrayList<>();
    private static final ArrayList<Suspect> invisSus = new ArrayList<Suspect>();
    private static final ArrayList<Suspect> visSus = new ArrayList<Suspect>();
    public Value<Boolean> remove = new Value<Boolean>("AntiBot_Removed", true);
    public int count = 0;
    private static List<Entity> invalid = new CopyOnWriteArrayList<Entity>();
    private final int botsFound = 0;
    private Object EntityArmorStand;
    private final Map<Integer, Double> distanceMap = new HashMap<>();
    private final Set<Integer> swingSet = new HashSet<>();


    public AntiBot() {
        super("AntiBot", Category.COMBAT);
        mode.addValue("Hypixel");
        mode.addValue("Mineplex");
        mode.addValue("Advanced");
        mode.addValue("Test");

        setState(true);
    }

    public static boolean isBot(Entity e) {
        if (!(e instanceof EntityPlayer) || !ModManager.getModule("AntiBot").isEnabled())
            return false;
        EntityPlayer player = (EntityPlayer) e;

        if (mode.isCurrentMode("Hypixel")) {
            return !getTabPlayerList().contains(player) && isHypixelNPC(player);
        }

        if (bots.contains(player))
            return true;

        if (mode.isCurrentMode("Test")) {
            return removeThese.contains(player);
        }

        return mode.isCurrentMode("Mineplex") && !Float.isNaN(player.getHealth());
    }

    public static List<EntityPlayer> getTabPlayerList() {
        NetHandlerPlayClient nhpc = Minecraft.getMinecraft().thePlayer.sendQueue;
        List<EntityPlayer> list = new ArrayList<>();
        List players = ((GuiPlayerTabOverlay) new GuiPlayerTabOverlay(Minecraft.getMinecraft(),
                Minecraft.getMinecraft().ingameGUI)).getField().sortedCopy(nhpc.getPlayerInfoMap());
        for (final Object o : players) {
            final NetworkPlayerInfo info = (NetworkPlayerInfo) o;
            if (info == null) {
                continue;
            }
            list.add(Minecraft.getMinecraft().theWorld.getPlayerEntityByName(info.getGameProfile().getName()));
        }
        return list;
    }

    public static boolean isHypixelNPC(Entity entity) {
        String formattedName = entity.getDisplayName().getFormattedText();
        String customName = entity.getCustomNameTag();

        if (!formattedName.startsWith("\247") && formattedName.endsWith("\247r")) {
            return true;
        }

        return formattedName.contains("[NPC]");
    }

    private boolean isInTablist(EntityLivingBase player) {
        if (mc.isSingleplayer()) {
            return true;
        }
        for (Object o : mc.getNetHandler().getPlayerInfoMap()) {
            NetworkPlayerInfo playerInfo = (NetworkPlayerInfo) o;
            if (playerInfo.getGameProfile().getName().equalsIgnoreCase(player.getName())) {
                return true;
            }
        }
        return false;
    }


    @EventTarget
    public void onReceivePacket(EventPacket event) {
        if (mode.isCurrentMode("Hypixel")) {
            if (event.getPacket() instanceof S18PacketEntityTeleport) {
                S18PacketEntityTeleport packet = (S18PacketEntityTeleport) event.getPacket();
                Entity entity = mc.theWorld.getEntityByID(packet.getEntityId());
                if (entity != null && entity instanceof EntityPlayer) {
                    if (entity.isInvisible()) {
                        bots.add((EntityPlayer) entity);
                    }
                }
            }


        }
        if (mode.isCurrentMode("Advanced") && event.getPacket() instanceof S0CPacketSpawnPlayer) {
            S0CPacketSpawnPlayer packet = (S0CPacketSpawnPlayer) event.getPacket();
            double posX = packet.getX() / 32D;
            double posY = packet.getY() / 32D;
            double posZ = packet.getZ() / 32D;

            double diffX = mc.thePlayer.posX - posX;
            double diffY = mc.thePlayer.posY - posY;
            double diffZ = mc.thePlayer.posZ - posZ;

            double dist = Math.sqrt(diffX * diffX + diffY * diffY + diffZ * diffZ);

            if (dist <= 8 && posX != mc.thePlayer.posX && posY != mc.thePlayer.posY && posZ != mc.thePlayer.posZ)
                bots.add((EntityLivingBase) mc.theWorld.getEntityByID(packet.getEntityID()));


        }
        if (mc.theWorld == null) return;
        if (event.getPacket() instanceof S0CPacketSpawnPlayer) {
            S0CPacketSpawnPlayer packet = (S0CPacketSpawnPlayer) event.getPacket();
            double x = packet.getX();
            double y = packet.getY();
            double z = packet.getZ();
            double d = mc.thePlayer.getDistance(x, y, z);

            distanceMap.put(packet.getEntityID(), d);
        }

        if (event.getPacket() instanceof S0BPacketAnimation) {
            S0BPacketAnimation packet = (S0BPacketAnimation) event.getPacket();

            if (packet.getAnimationType() != 0) return;

            swingSet.add(packet.getEntityID());
        }

    }

    @Override
    public void onEnable() {
        super.onEnable();
        bots.clear();
        invalid.clear();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        bots.clear();
        invalid.clear();
    }


    private boolean isEntityBot(Entity entity) {
        double distance = entity.getDistanceSqToEntity(mc.thePlayer);
        if (!(entity instanceof EntityPlayer)) {
            return false;
        } else if (mc.getCurrentServerData() == null) {
            return false;
        } else {
            return mc.getCurrentServerData().serverIP.toLowerCase().contains("hypixel") && entity.getDisplayName().getFormattedText().startsWith("ยง") || !this.isOnTab(entity) && mc.thePlayer.ticksExisted > 100;
        }
    }


    public static List<Entity> getInvalid() {
        return invalid;
    }

    public static boolean isInInvalidList(Entity e) {
        return invalid.contains(e);
    }

    public boolean isNotHypixelBot(EntityPlayer e) {
        return e == AntiBot.mc.thePlayer || e.isDead || !e.isInvisible() || !this.isInTabList(e) || e.getCustomNameTag().length() < 2;
    }

    public boolean isInTabList(Entity entity) {
        for (NetworkPlayerInfo info : mc.getNetHandler().getPlayerInfoMap()) {
            if (!info.getGameProfile().getName().equals(entity.getName())) continue;
            return true;
        }
        return false;
    }

    public boolean isInvalidID(char c) {
        Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
        return ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B || ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION || ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS || ub == Character.UnicodeBlock.GENERAL_PUNCTUATION;
    }

    @EventTarget
    public void onUpdate(EventUpdate e) {
        if (mode.isCurrentMode("Test")) {
            if (!mc.theWorld.loadedEntityList.isEmpty()) {
                for (Entity ent : AntiBot.mc.theWorld.loadedEntityList) {
                    if (ent instanceof EntityPlayerSP || !(ent instanceof EntityPlayer)) continue;
                    if (ent.getDisplayName().getUnformattedText().startsWith("§8[NPC]")) {
                        invalid.add(ent);
                    }
                    if (ent.getDisplayName().getUnformattedText().startsWith("§") && ent.getDisplayName().getUnformattedText().endsWith("§r")) {
                        invalid.add(ent);
                    }
                    if (!ent.getDisplayName().getUnformattedText().contains("§")) {
                        invalid.add(ent);
                    }
                    if (!ent.isInvisible() || ent.ticksExisted <= 105) continue;
                    if (this.isInTabList(ent)) {
                        if (!ent.isInvisible()) continue;
                        ent.setInvisible(false);
                        continue;
                    }
                    AntiBot.mc.theWorld.removeEntity(ent);
                }
            }
        }

        if (mode.isCurrentMode("Hypixel")) {
            if (mc.isSingleplayer()) return;
            if (mc.theWorld != null) {
                for (Entity entity : mc.theWorld.loadedEntityList) {
                    if (entity instanceof EntityPlayer) {
                        if (entity != mc.thePlayer) {
                            EntityPlayer player = (EntityPlayer) entity;
                            if (player.getName().startsWith("�c") || !isInTablist(player)) {
                                if (player.getName().startsWith("�c") && !isInTablist(player)) {
                                    if (!bots.contains(player)) {
                                        bots.add(player);
                                    }
                                }

                                if (player.isInvisible() && !bots.contains(player)) {
                                    float f = (float) (mc.thePlayer.posX - player.posX);
                                    float f2 = (float) (mc.thePlayer.posZ - player.posZ);
                                    double horizontalReaach = MathHelper.sqrt_float(f * f + f2 * f2);
                                    if (horizontalReaach < 1) {
                                        double vert = mc.thePlayer.posY = -player.posY;
                                        if (vert <= 5) {
                                            if (mc.thePlayer.ticksExisted % 5 == 0) {
                                                bots.add(player);
                                            }
                                        }
                                    }
                                }
                            }

                        }
                    }
                }

                if (!bots.isEmpty()) {
                    for (int i = 0; i < bots.size(); i++) {
                        if (bots.contains(bots.get(i))) {
                            if (!mc.theWorld.playerEntities.contains(bots.get(i))) {
                                bots.remove(bots.get(i));
                            }
                        }
                    }
                    if (remove.getValue()) {
                        for (EntityLivingBase entityPlayer : bots) {
                            if (!entityPlayer.getName().equalsIgnoreCase(mc.thePlayer.getName())) {
                                mc.theWorld.removeEntity(entityPlayer);
                            }
                        }

                    }
                }


            }
            this.setDisplayName("Hypixel");
        }


        if (mode.isCurrentMode("Mineplex")) {
            this.setDisplayName("Mineplex");
        }

    }

    private boolean isBotHypixel(EntityLivingBase entity) {
        return (!entity.onGround && entity.isInvisible() && !entity.isPotionActive(14) && mc.thePlayer.ticksExisted < 40);
    }


    private static final transient List<EntityPlayer> dontRemove = new ArrayList<>();
    private static final transient CopyOnWriteArrayList<EntityPlayer> removeThese = new CopyOnWriteArrayList<EntityPlayer>();

    private void hypixelAntibot() {


    }


    private boolean isOnTab(Entity entity) {
        Iterator var2 = mc.getNetHandler().getPlayerInfoMap().iterator();

        NetworkPlayerInfo info;
        do {
            if (!var2.hasNext()) {
                return false;
            }

            info = (NetworkPlayerInfo) var2.next();
        } while (!info.getGameProfile().getName().equals(entity.getName()));

        return true;
    }

    public Suspect getInvisSuspect(EntityPlayer ep) {
        for (int i = 0; i < invisSus.size(); i++) {
            if (invisSus.get(i).player == ep) {
                return invisSus.get(i);
            }
        }
        return null;
    }

    public Suspect getVisSuspect(EntityPlayer ep) {
        for (int i = 0; i < visSus.size(); i++) {
            if (visSus.get(i).player == ep) {
                return visSus.get(i);
            }
        }
        return null;
    }


}

class Suspect {
    public EntityPlayer player;
    public long TPTime;
}
