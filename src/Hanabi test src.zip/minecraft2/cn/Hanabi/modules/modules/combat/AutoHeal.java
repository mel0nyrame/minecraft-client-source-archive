package cn.Hanabi.modules.modules.combat;

import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Mouse;

import com.darkmagician6.eventapi.EventTarget;

import cn.Hanabi.events.EventPostMotion;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.utils.TimeLocation.DelayTimer;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemSoup;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class AutoHeal extends Mod {
	private boolean jumping;
	private boolean rotated;
	public static Value<Double> health = new Value<Double>("AutoHeal_Health", 13.0, 1.0, 20.0, 1.0);
	public static Value<Double> delay = new Value<Double>("AutoHeal_Delay", 500.0, 100.0, 1500.0, 50.0);
	public Value<Boolean> potions = new Value<Boolean>("AutoHeal_Potion", true);
	public Value<Boolean> jump = new Value<Boolean>("AutoHeal_Jump", false);
	public Value<Boolean> regen = new Value<Boolean>("AutoHeal_RenenPot", false);
	public Value<Boolean> speed = new Value<Boolean>("AutoHeal_SpeedPot", true);
	public Value<Boolean> nofrog = new Value<Boolean>("AutoHeal_FrogPotionDisabled", true);
	public Value<Boolean> head = new Value<Boolean>("AutoHeal_Head", true);
	public Value<Boolean> soup = new Value<Boolean>("AutoHeal_Soup", true);
	public Value<Boolean> apple = new Value<Boolean>("AutoHeal_GoldenApple", true);

	public AutoHeal() {
		super("AutoHeal", Category.COMBAT);
	}

	private final TimeHelper timer = new TimeHelper();
	private final DelayTimer cooldown = new DelayTimer();
	private int slot = -1;
	private int currentslot = -1;
	public static boolean healing = false, doSoup;
	TimeHelper timer3 = new TimeHelper();
	private boolean eatingApple;
	private int switched = -1;
	public static boolean doingStuff = false;
	public static boolean potting;
	public static boolean pitchdown = false;

	private int lastPottedSlot;
	private final TimeHelper timer2 = new TimeHelper();

	@Override
	public void onEnable() {
		this.eatingApple = doingStuff = false;
		pitchdown = false;
		switched = -1;
		timer2.reset();
		super.onEnable();
	}

	@Override
	public void onDisable() {
		currentslot = -1;
		pitchdown = false;
		doSoup = false;
		healing = false;
		doingStuff = false;
		if (eatingApple) {
			repairItemPress();
			repairItemSwitch();
		}
		super.onDisable();
	}

	@EventTarget
	public void onPre(EventPreMotion event) {

		if (ModManager.getModule("Scaffold").isEnabled() && !mc.thePlayer.onGround) {
			return;
		}

		if (soup.getValueState()) {
			int soupSlot = this.getSoupSlot();
			if (timer.isDelayComplete(delay.getValueState().longValue())
					&& mc.thePlayer.getHealth() < health.getValueState() && soupSlot != -1) {
				doSoup = true;
			}
		}

		int eatables = 0;

		if (potions.getValueState()) {
			eatables += getPotionCount();
			if (regen.getValueState())
				eatables += getRegenCount();
		}
		if (eatables > 0) {
			update();
			if (!shouldHeal()) {
				healing = false;
				return;
			}
			if (slot == -1) {
				healing = false;
				return;
			}
			boolean up = jump.getValueState() && mc.thePlayer.onGround;
			if (mc.thePlayer.inventory.mainInventory[slot] != null
					&& mc.thePlayer.inventory.mainInventory[slot].getItem() == Items.potionitem) {
				if (up)
					mc.thePlayer.jump();
				pitchdown = true;
				event.setPitch(up ? -90 : 90);
			}
			healing = true;
		} else {
			pitchdown = false;
			healing = false;
		}
		if (head.getValueState()) {
			if (mc.thePlayer == null)
				return;
			final InventoryPlayer inventory = mc.thePlayer.inventory;
			if (inventory == null)
				return;
			doingStuff = false;
			if (!Mouse.isButtonDown(0) && !Mouse.isButtonDown(1)) {
				final KeyBinding useItem = (KeyBinding) mc.gameSettings.keyBindUseItem;

				if (!this.timer2.isDelayComplete((long) (delay.getValueState() * 50))) {
					eatingApple = false;
					repairItemPress();
					repairItemSwitch();
					return;
				}

				if (mc.thePlayer.capabilities.isCreativeMode || mc.thePlayer.isPotionActive(Potion.regeneration)
						|| mc.thePlayer.getHealth() >= health.getValueState()) {
					this.timer.reset();
					if (eatingApple) {
						eatingApple = false;
						repairItemPress();
						repairItemSwitch();
					}
					return;
				}

				for (int i = 0; i < 2; i++) {
					final boolean doEatHeads = i != 0;

					if (doEatHeads) {
						if (!this.head.getValueState())
							continue;
					} else {
						if (!this.apple.getValueState()) {
							eatingApple = false;
							repairItemPress();
							repairItemSwitch();
							continue;
						}
					}

					int slot;

					if (doEatHeads) {
						slot = this.getItemFromHotbar(397);
					} else {
						slot = this.getItemFromHotbar(322);
					}

					if (slot == -1)
						continue;

					final int tempSlot = inventory.currentItem;

					doingStuff = true;
					if (doEatHeads) {
						mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(slot));
						mc.thePlayer.sendQueue
								.addToSendQueue(new C08PacketPlayerBlockPlacement(inventory.getCurrentItem()));
						mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(tempSlot));
						timer.reset();
					} else {
						inventory.currentItem = slot;
						useItem.setPress(true);
						if (eatingApple)
							continue;
						eatingApple = true;
						this.switched = tempSlot;
					}

				}
			}
		}
	}




	@EventTarget
	public void onPost(EventPostMotion event) {

		if (ModManager.getModule("Scaffold").isEnabled() && !mc.thePlayer.onGround) {
			return;
		}

		int[] pots = {-1, -1, -1};
		if (speed.getValueState())
			pots[1] = 1;
		if (timer.isDelayComplete(200)) {
			if (potting)
				potting = false;
		}
		int spoofSlot = getBestSpoofSlot();
		if (speed.getValueState()) {
			for (int i = 0; i < pots.length; i++) {
				if (pots[i] == -1)
					continue;
				if (pots[i] == 1) {
					if (timer3.isDelayComplete(1000) && !mc.thePlayer.isPotionActive(pots[i])) {
						getBestPot(spoofSlot, pots[i]);
					}
				}
			}
		}
		if (soup.getValueState()) {
			int soupSlot = this.getSoupSlot();
			if (doSoup) {
				doSoup = false;
				// swap(soupSlot, 5);
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(soupSlot - 36));
				mc.thePlayer.sendQueue
						.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));
				mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(
						C07PacketPlayerDigging.Action.DROP_ALL_ITEMS, BlockPos.ORIGIN, EnumFacing.DOWN));
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
			}
		}
		int eatables = 0;
		if (potions.getValueState()) {
			eatables += getPotionCount();
			if (regen.getValueState())
				eatables += getRegenCount();
		}
		if (eatables > 0) {
			if (slot == -1)
				return;
			if (!healing)
				return;
			if (!shouldHeal())
				return;
			if (mc.thePlayer.inventory.mainInventory[slot] == null)
				return;
			int packetSlot = slot;
			if (slot < 9) {
				currentslot = mc.thePlayer.inventory.currentItem;
				highlight(slot);
				mc.getNetHandler().getNetworkManager()
						.sendPacket(new C08PacketPlayerBlockPlacement(mc.thePlayer.getHeldItem()));
				highlight(mc.thePlayer.inventory.currentItem);
				highlight(currentslot);
			} else {
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(8));
				mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot, 8, 2, mc.thePlayer);
				mc.thePlayer.sendQueue
						.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.mainInventory[slot]));
				mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, packetSlot, 8, 2,
						mc.thePlayer);
				mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
			}
			timer.reset();
		}
	}

	int getBestSpoofSlot() {
		int spoofSlot = 5;
		for (int i = 36; i < 45; i++) {
			if (!mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
				spoofSlot = i - 36;
				break;
			} else if (mc.thePlayer.inventoryContainer.getSlot(i).getStack().getItem() instanceof ItemPotion) {
				spoofSlot = i - 36;
				break;
			}
		}
		return spoofSlot;
	}

	void getBestPot(int hotbarSlot, int potID) {
		for (int i = 9; i < 45; i++) {
			if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()
					&& (mc.currentScreen == null || mc.currentScreen instanceof GuiInventory)) {
				ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
				if (is.getItem() instanceof ItemPotion) {
					ItemPotion pot = (ItemPotion) is.getItem();
					if (pot.getEffects(is).isEmpty())
						return;
					PotionEffect effect = pot.getEffects(is).get(0);
					int potionID = effect.getPotionID();
					if (potionID == potID)
						if (ItemPotion.isSplash(is.getItemDamage()) && isBestPot(pot, is)) {
							if (36 + hotbarSlot != i)
								swap(i, hotbarSlot);
							timer3.reset();
							boolean canpot = true;
							int oldSlot = mc.thePlayer.inventory.currentItem;
							mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(hotbarSlot));
							boolean up = jump.getValueState() && mc.thePlayer.onGround;
							if (up)
								mc.thePlayer.jump();
							mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(
									mc.thePlayer.rotationYaw, up ? -90 : 90, mc.thePlayer.onGround));
							mc.thePlayer.sendQueue.addToSendQueue(
									new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));
							mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(oldSlot));
							potting = true;
							break;
						}
				}
			}
		}
	}

	boolean isBestPot(ItemPotion potion, ItemStack stack) {
		if (potion.getEffects(stack) == null || potion.getEffects(stack).size() != 1)
			return false;
		PotionEffect effect = potion.getEffects(stack).get(0);
		int potionID = effect.getPotionID();
		int amplifier = effect.getAmplifier();
		int duration = effect.getDuration();
		for (int i = 9; i < 45; i++) {
			if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
				ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
				if (is.getItem() instanceof ItemPotion) {
					ItemPotion pot = (ItemPotion) is.getItem();
					if (pot.getEffects(is) != null) {
						for (Object o : pot.getEffects(is)) {
							PotionEffect effects = (PotionEffect) o;
							int id = effects.getPotionID();
							int ampl = effects.getAmplifier();
							int dur = effects.getDuration();
							if (id == potionID && ItemPotion.isSplash(is.getItemDamage())) {
								if (ampl > amplifier) {
									return false;
								} else if (ampl == amplifier && dur > duration) {
									return false;
								}
							}
						}
					}
				}
			}
		}
		return true;
	}

	private void update() {
		for (int i = 0; i < 36; ++i) {
			if (mc.thePlayer != null && mc.theWorld != null && mc.thePlayer.inventory.mainInventory[i] != null) {
				final ItemStack is = mc.thePlayer.inventory.mainInventory[i];
				final Item item = is.getItem();
				if (item instanceof ItemPotion && potions.getValueState()) {
					final ItemPotion potion = (ItemPotion) item;
					if (potion.getEffects(is) != null) {
						for (final Object o : potion.getEffects(is)) {
							final PotionEffect effect = (PotionEffect) o;
							if (effect.getPotionID() == Potion.heal.id
									|| (effect.getPotionID() == Potion.regeneration.id && regen.getValueState()
											&& !mc.thePlayer.isPotionActive(Potion.regeneration))
											&& ItemPotion.isSplash(is.getItemDamage())) {
								slot = i;
							}
						}
					}
				}
			}
		}
	}

	private void swap(int slot, int hotbarSlot) {
		mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot, hotbarSlot, 2, mc.thePlayer);
	}

	private int getCount() {
		int counter = 0;

		for (int i = 9; i < 45; ++i) {
			if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
				ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
				Item item = is.getItem();
				if (item instanceof ItemSoup) {
					++counter;
				}
			}
		}

		return counter;
	}

	private int getSoupSlot() {
		int itemSlot = -1;

		for (int i = 36; i < 45; ++i) {
			if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
				ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
				Item item = is.getItem();
				if (item instanceof ItemSoup) {
					itemSlot = i;
				}
			}
		}

		return itemSlot;
	}

	private int getPotionCount() {
		int count = 0;
		for (Slot s : mc.thePlayer.inventoryContainer.inventorySlots)
			if (s.getHasStack()) {

				ItemStack is = s.getStack();
				if ((is.getItem() instanceof ItemPotion)) {

					ItemPotion ip = (ItemPotion) is.getItem();
					if (ItemPotion.isSplash(is.getMetadata())) {

						boolean hasHealing = false;
						for (PotionEffect pe : ip.getEffects(is))
							if (pe.getPotionID() == Potion.heal.getId()) {

								hasHealing = true;
								break;
							}
						if (hasHealing) {
							count++;
						}
					}
				}
			}
		return count;
	}

	private int getRegenCount() {
		int count = 0;
		for (Slot s : mc.thePlayer.inventoryContainer.inventorySlots)
			if (s.getHasStack()) {

				ItemStack is = s.getStack();
				if ((is.getItem() instanceof ItemPotion)) {

					ItemPotion ip = (ItemPotion) is.getItem();
					if (ItemPotion.isSplash(is.getMetadata())) {

						boolean hasHealing = false;
						for (PotionEffect pe : ip.getEffects(is))
							if (pe.getPotionID() == Potion.regeneration.getId()) {

								hasHealing = true;
								break;
							}
						if (hasHealing) {
							count++;
						}
					}
				}
			}
		return count;
	}

	private void highlight(int slot) {
		mc.thePlayer.inventory.currentItem = slot;
		mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(slot));
	}

	private boolean shouldHeal() {
		return mc.thePlayer.getHealth() <= health.getValueState()
				&& timer.isDelayComplete((long) (delay.getValueState() * 50));
	}

	private void repairItemPress() {
		if (mc.gameSettings != null) {
			final KeyBinding keyBindUseItem = (KeyBinding) mc.gameSettings.keyBindUseItem;
			if (keyBindUseItem != null)
				keyBindUseItem.setPress(false);
		}
	}

	private void repairItemSwitch() {
		final EntityPlayerSP p = mc.thePlayer;
		if (p == null)
			return;
		final InventoryPlayer inventory = p.inventory;
		if (inventory == null)
			return;
		int switched = this.switched;
		if (switched == -1)
			return;
		inventory.currentItem = switched;
		switched = -1;
		this.switched = switched;
	}

	private int getItemFromHotbar(final int id) {
		for (int i = 0; i < 9; i++) {
			if (mc.thePlayer.inventory.mainInventory[i] != null) {
				final ItemStack is = mc.thePlayer.inventory.mainInventory[i];
				final Item item = is.getItem();
				if (Item.getIdFromItem(item) == id) {
					return i;
				}
			}
		}
		return -1;
	}
}
