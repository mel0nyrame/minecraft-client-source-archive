package cn.Hanabi.modules.modules.player;

import cn.Hanabi.events.EventPostMotion;
import cn.Hanabi.events.EventPreMotion;
import cn.Hanabi.events.EventWorldChange;
import cn.Hanabi.modules.Category;
import cn.Hanabi.modules.Mod;
import cn.Hanabi.modules.ModManager;
import cn.Hanabi.modules.modules.combat.KillAura;
import cn.Hanabi.utils.Entity.PlayerUtil;
import cn.Hanabi.utils.Misc.BlockUtils;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.value.Value;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.*;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import net.minecraft.util.Vec3i;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;


public class ChestAura extends Mod {
    public static final List<BlockPos> openedBlocks = new CopyOnWriteArrayList();
    private final TimeHelper time = new TimeHelper();
    private final Value<Double> range = new Value("ChestAura_Range", 4.0D, 1.0D, 10.0D, 0.5d);
    private final Value<Double> delay = new Value("ChestAura_Delay", 1000D, 0.0D,
            5000.0D, 100.0D);
    BlockPos globalPos;
    private boolean shouldBreak = false;

    public ChestAura() {
        super("ChestAura", Category.PLAYER);
    }


    @EventTarget
    private void onCHangewolrd(EventWorldChange e){
        openedBlocks.clear();
    }

    @EventTarget
    public void onPre(EventPreMotion e) {
        if (mc.currentScreen instanceof GuiContainer) {
            this.time.reset();
        }
        if(ModManager.getModule(KillAura.class).isEnabled() && KillAura.target != null) return;
        int radius = range.getValueState().intValue();
        Iterator<BlockPos> positions = BlockPos.getAllInBox(this.mc.thePlayer.getPosition().subtract(new Vec3i(radius, radius, radius)), this.mc.thePlayer.getPosition().add(new Vec3i(radius, radius, radius))).iterator();
        BlockPos chestPos = null;
        while (positions.hasNext()) {
            chestPos = positions.next();
            BlockPos corner;
            if (!(this.mc.theWorld.getBlockState(chestPos.add(0, 1, 0)).getBlock() instanceof BlockAir) || !(this.mc.theWorld.getBlockState(chestPos).getBlock() instanceof BlockChest) || openedBlocks.contains(chestPos)) continue;
            corner = getBlockCorner(new BlockPos(this.mc.thePlayer.posX, this.mc.thePlayer.posY + (double)this.mc.thePlayer.getEyeHeight(), this.mc.thePlayer.posZ), chestPos);
            if (corner == null) continue;
            this.shouldBreak = true;
            float[] rotations = BlockUtils.getBlockRotations((double) corner.getX(), (double) corner.getY(), (double) corner.getZ());
            e.setYaw(rotations[0]);
            e.setPitch(rotations[1]);
            mc.thePlayer.rotationYawHead = rotations[0];
            mc.thePlayer.renderYawOffset = rotations[0];
            this.globalPos = corner;
        }

        if (this.globalPos != null && !(mc.currentScreen instanceof GuiContainer) && !openedBlocks.contains(this.globalPos) && this.shouldBreak && time.isDelayComplete(delay.getValueState().longValue())) {
//            EnumFacing direction = this.getFacingDirection(this.globalPos);
//            if (direction != null) {
                mc.thePlayer.swingItem();
                mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem(), this.globalPos, EnumFacing.DOWN, new Vec3((double) this.globalPos.getX(), (double) this.globalPos.getY(), (double) this.globalPos.getZ()));
                openedBlocks.add(this.globalPos);
                this.time.reset();
//            }
        }
//        for (int y = radius; y >= -radius; --y) {
//            for (int x = -radius; x <= radius; ++x) {
//                for (int z = -radius; z <= radius; ++z) {
//                    BlockPos pos = new BlockPos(mc.thePlayer.posX - 0.5D + (double) x, mc.thePlayer.posY - 0.5D + (double) y, mc.thePlayer.posZ - 0.5D + (double) z);
//                    Block block = Minecraft.getMinecraft().theWorld.getBlockState(pos).getBlock();
//                    if (this.getFacingDirection(pos) != null && pos != null && !(mc.currentScreen instanceof GuiContainer) && mc.thePlayer.getDistance(mc.thePlayer.posX + (double) x, mc.thePlayer.posY + (double) y, mc.thePlayer.posZ + (double) z) < (double) mc.playerController.getBlockReachDistance() - 0.5D && block instanceof BlockChest) {
//                        this.shouldBreak = true;
//                        PlayerUtil.tellPlayer("Find Chest");
//                        float[] rotations = BlockUtils.getBlockRotations((double) pos.getX(), (double) pos.getY(), (double) pos.getZ());
//                        e.setYaw(rotations[0]);
//                        e.setPitch(rotations[1]);
//                        this.globalPos = pos;
//                        return;
//                    }
//                }
//            }
//        }
    }


    @EventTarget
    public void onPost(EventPostMotion event) {


    }


    @Override
    public void onEnable() {
        if (mc.theWorld != null) {
            openedBlocks.clear();
        }
        super.onEnable();

    }


    @Override
    public void onDisable() {
        if (mc.theWorld != null) {
            openedBlocks.clear();
        }
        super.onDisable();

    }

    private EnumFacing getFacingDirection(BlockPos pos) {
        EnumFacing direction = null;
        if (!mc.theWorld.getBlockState(pos.add(0, 1, 0)).getBlock().isFullCube()) {
            direction = EnumFacing.UP;
        } else if (!mc.theWorld.getBlockState(pos.add(0, -1, 0)).getBlock().isFullCube()) {
            direction = EnumFacing.DOWN;
        } else if (!mc.theWorld.getBlockState(pos.add(1, 0, 0)).getBlock().isFullCube()) {
            direction = EnumFacing.EAST;
        } else if (!mc.theWorld.getBlockState(pos.add(-1, 0, 0)).getBlock().isFullCube()) {
            direction = EnumFacing.WEST;
        } else if (!mc.theWorld.getBlockState(pos.add(0, 0, 1)).getBlock().isFullCube()) {
            direction = EnumFacing.SOUTH;
        } else if (!mc.theWorld.getBlockState(pos.add(0, 0, 1)).getBlock().isFullCube()) {
            direction = EnumFacing.NORTH;
        }

        return direction;
    }

    public static BlockPos getBlockCorner(BlockPos start, BlockPos end) {
        for (int x = 0; x <= 1; ++x) {
            for (int y = 0; y <= 1; ++y) {
                for (int z = 0; z <= 1; ++z) {
                    BlockPos pos = new BlockPos(end.getX() + x, end.getY() + y, end.getZ() + z);
                    if (!isBlockBetween(start, pos)) {
                        return pos;
                    }
                }
            }
        }
        return null;
    }
    public static boolean isBlockBetween(BlockPos start, BlockPos end) {
        int startX = start.getX();
        int startY = start.getY();
        int startZ = start.getZ();
        int endX = end.getX();
        int endY = end.getY();
        int endZ = end.getZ();
        double diffX = endX - startX;
        double diffY = endY - startY;
        double diffZ = endZ - startZ;
        double x = startX;
        double y = startY;
        double z = startZ;
        int STEPS = (int) Math.max(Math.abs(diffX), Math.max(Math.abs(diffY), Math.abs(diffZ))) * 4;
        for (int i = 0; i < STEPS - 1; ++i) {
            x += diffX / (double) STEPS;
            y += diffY / (double) STEPS;
            z += diffZ / (double) STEPS;
            if (x != (double) endX || y != (double) endY || z != (double) endZ) {
                BlockPos pos = new BlockPos(x, y, z);
                Block block = mc.theWorld.getBlockState(pos).getBlock();
                if (block.getMaterial() != Material.air && block.getMaterial() != Material.water
                        && !(block instanceof BlockVine) && !(block instanceof BlockLadder)) {
                    return true;
                }
            }
        }
        return false;
    }
}




