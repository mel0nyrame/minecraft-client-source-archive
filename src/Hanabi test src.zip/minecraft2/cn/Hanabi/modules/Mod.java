package cn.Hanabi.modules;

import cn.Hanabi.Client;
import cn.Hanabi.Hanabi;
import cn.Hanabi.gui.clickgui.hanabi.window.Button;
import cn.Hanabi.gui.notifications.Notification;
import cn.Hanabi.modules.modules.render.ClickGUIModule;
import cn.Hanabi.utils.Misc.ClientUtil;
import cn.Hanabi.utils.Misc.RenderUtil;
import cn.Hanabi.utils.TimeLocation.TimeHelper;
import cn.Hanabi.utils.Translate;
import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.Random;

public abstract class Mod {
    public static final Minecraft mc = Minecraft.getMinecraft();

    public static String username = Client.username;
    public static String password;
    static TimeHelper saveTimer = new TimeHelper();
    private final String name;
    private final Category category;
    private final boolean canBeEnabled;
    private final boolean hidden;
    public String displayName;
    public float displaywidth;
    public float namewidth;
    public int valueSize = 0;
    public Button modButton;
    public Translate translate = new Translate(0.0F, 0.0F);
    public boolean keepReg = false;
    public boolean isReg = false;
    public boolean state;
    private int keybind;
    public boolean arraylistremove = true;
    public float animx = 0;
    private CheckboxMenuItem checkboxMenuItem;
    public static final Random RANDOM = new Random();


    public Mod(String name, Category Category) {
        this(name, Category, true, false, Keyboard.KEY_NONE);
    }

    public Mod(String name, Category Category, boolean canBeEnabled, boolean hidden, int keybind) {
        this.name = name;
        this.category = Category;
        this.canBeEnabled = canBeEnabled;
        this.hidden = hidden;
        this.keybind = keybind;

    }

    public boolean wasArrayRemoved() {
        return this.arraylistremove;
    }

    public void setArrayRemoved(boolean arraylistremove) {
        this.arraylistremove = arraylistremove;
    }

    public void setAnimx(float aanimx) {
        this.animx = aanimx;
    }

    public float getAnimx() {
        return this.animx;
    }

    public String getName() {
        return name;
    }

    public Category getCategory() {
        return category;
    }

    public boolean isCanBeEnabled() {
        return canBeEnabled;
    }

    public boolean isHidden() {
        return hidden;
    }

    public int getKeybind() {
        return keybind;
    }

    public void setKeybind(int keybind) {
        this.keybind = keybind;
    }

    public boolean getState() {
        return state;
    }

    public void setState(boolean state) {
        setState(state, true);
    }

    public boolean isEnabled() {
        return state;
    }

    public void set(boolean state) {
        this.setState(state);
    }

    public double getAnimationState(double animation, double finalState, double speed) {
        float add = (float) (RenderUtil.delta * speed);
        if (animation < finalState) {
            if (animation + add < finalState)
                animation += add;
            else
                animation = finalState;
        } else {
            if (animation - add > finalState)
                animation -= add;
            else
                animation = finalState;
        }
        return animation;
    }

    public void toggleModule() {
        if (this.checkboxMenuItem != null) {
            this.checkboxMenuItem.setState(!this.checkboxMenuItem.getState());
        }
        this.setState(!this.isEnabled());
    }

    public void setCheckboxMenuItem(CheckboxMenuItem checkboxMenuItem) {
        this.checkboxMenuItem = checkboxMenuItem;
    }

    public void setState(boolean state, boolean save) {
        try {
            if (save && mc.thePlayer != null && saveTimer.isDelayComplete(10000)) {
                Hanabi.INSTANCE.fileManager.save();
                saveTimer.reset();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (state) {
            this.state = true;

            if (mc.thePlayer != null)
                onEnable();

            if (!this.getName().equals("ClickGUI") && !this.getName().equals("HUD")) {
                if (mc.thePlayer != null)
                    mc.thePlayer.playSound("random.click", 0.2F, 0.6F);
                ClientUtil.sendClientMessage(name + " Enabled", Notification.Type.SUCCESS);
            }
            if (!isReg) {
                isReg = true;
                EventManager.register(this);
            }
        } else {
            this.state = false;

            if (mc.thePlayer != null)
                onDisable();

            if (!this.getName().equals("ClickGUI") && !this.getName().equals("HUD")) {
                if (mc.thePlayer != null)
                    mc.thePlayer.playSound("random.click", 0.2F, 0.5F);
                ClientUtil.sendClientMessage(name + " Disabled", Notification.Type.ERROR);
            }

            if (!keepReg && isReg) {
                isReg = false;
                EventManager.unregister(this);
            }
        }
    }

    public void onEnable() {

    }

    public void onDisable() {

    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        if (mc.currentScreen == ClickGUIModule.clickGui)
            return;
        this.displayName = displayName;
    }


}
