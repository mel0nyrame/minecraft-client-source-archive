package cn.Hanabi.modules;

import cn.Hanabi.Hanabi;
import cn.Hanabi.events.EventKey;
import cn.Hanabi.hmlProject.HMLUtils;
import cn.Hanabi.modules.modules.combat.*;
import cn.Hanabi.modules.modules.ghost.AutoClicker;
import cn.Hanabi.modules.modules.ghost.LegitVelocity;
import cn.Hanabi.modules.modules.movement.*;
import cn.Hanabi.modules.modules.movement.Fly.Fly;
import cn.Hanabi.modules.modules.movement.LongJump.LongJump;
import cn.Hanabi.modules.modules.movement.Speed.Speed;
import cn.Hanabi.modules.modules.player.*;
import cn.Hanabi.modules.modules.render.*;
import cn.Hanabi.modules.modules.world.*;
import cn.Hanabi.modules.modules.world.Scaffold.Scaffold;
import cn.Hanabi.utils.fontmanager.UnicodeFontRenderer;
import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;


import java.util.ArrayList;
import java.util.List;

public class ModManager {

	
	public static List<Mod> modules = new ArrayList<>();
	public static boolean needsort = true;
	public static ArrayList<Mod> sortedModList = new ArrayList();
	private static ArrayList<Mod> enabledModList;

	public ModManager() {
		EventManager.register(this);
	}

	public void addModules() {
		// Register your modules here

		// COMBAT
		addModule(new Hitbox());
		addModule(new KeepSprint());
		addModule(new Velocity());
		addModule(new KillAura());

		addModule(new Criticals());
		addModule(new AutoSword());
		addModule(new Reach());
		addModule(new TargetStrafe());
		addModule(new AutoHeal());

		// MOVEMENT
		addModule(new Sprint());
		addModule(new Speed());
		addModule(new Fly());
		addModule(new Strafe());
		addModule(new LongJump());
		addModule(new NoSlow());
		addModule(new FakeLag());
		addModule(new Step());
		addModule(new HighJump());
		//addModule(new LadderJump());

        //addModule(new TargetRace());


        // PLAYER
        addModule(new AutoArmor());
        addModule(new InvCleaner());
        addModule(new InvMove());
        addModule(new NoFall());
        addModule(new ChatBypass());
		addModule(new Desync());
        addModule(new ModChecker());
        addModule(new ChestStealer());
		addModule(new ChestAura());
		addModule(new Nuker());
		addModule(new FastUse());
		addModule(new Blink());
        addModule(new FastPlace());
        addModule(new AutoTools());
        addModule(new AutoGG());

		addModule(new Mod("AutoPlay", Category.PLAYER) {
		});
		addModule(new Mod("NoCommand", Category.PLAYER) {
		});

		// RENDER
		addModule(new ClickGUIModule());
        addModule(new Nametags());
        addModule(new Fullbright());
		addModule(new ESP());
		addModule(new Projectiles());
        addModule(new BedESP());
        addModule(new ChestESP());
        addModule(new HitAnimation());
        addModule(new CaveFinder());
        addModule(new Chams());
        addModule(new OreTarget());
        addModule(new NoFov());
        addModule(new NameProtect());
        addModule(new TabGUI());
        addModule(new NoHurtCam());
        addModule(new ViewClip());
        addModule(new EveryThingBlock());
        addModule(new Phase());
        addModule(new Rader());
		addModule(new Freecam());
		addModule(new EnvyHUD());
        //addModule(new Zoot());
        // HANABI_VERIFY
        /*
		 * try { if
		 * (!Hanabi.AES_UTILS.decrypt(Hanabi.HWID_VERIFY).contains(Wrapper.getHWID())) {
		 * FMLCommonHandler.instance().exitJava(0, true); Client.sleep = true; } } catch
		 * (Exception e) { FMLCommonHandler.instance().exitJava(0, true); Client.sleep =
		 * true; }
		 */

		// WORLD
		//addModule(new AAVPN());
		addModule(new AntiBot());
		addModule(new Teams());
		addModule(new AntiFall());
		addModule(new AutoL());
		addModule(new HideAndSeek());
		addModule(new Eagle());
		addModule(new HUD());
		addModule(new SpeedMine());
		addModule(new UhcHelper());
		addModule(new AntiSpammer());
		addModule(new Jesus());
		addModule(new Scaffold());
		addModule(new Debug());


		// GHOST
		addModule(new AutoClicker());
		addModule(new LegitVelocity());

		HMLUtils.onModManagerLoad(this);
	}



	public void addModule( Mod module) {
		modules.add(module);
	}

	
	public static List<Mod> getModules() {
		return modules;
	}

	
	public static List<Mod> getModules(Category category) {
		ArrayList<Mod> mods = new ArrayList<Mod>();
		for (Mod mod : ModManager.getModList()) {
			if (mod.getCategory() == category) {
				mods.add(mod);
			}
		}
		return mods;
	}

	
	public static <T extends Mod> T getModule(Class<T> clazz) {
		return (T) modules.stream().filter(mod -> mod.getClass() == clazz).findFirst().orElse(null);
	}

	public static Mod getModule( String name) {
		try {
			return getModule(name, false);
		} catch (Exception e) {
			return new Mod("NMSL", Category.COMBAT) {
			};
		}
	}

	public static Mod getModule( String name, boolean caseSensitive) {
		return modules.stream()
				.filter(mod -> !caseSensitive && name.equalsIgnoreCase(mod.getName()) || name.equals(mod.getName()))
				.findFirst().orElse(null);
	}

	@EventTarget
	private void onKey( EventKey event) {
		for (Mod module : modules)
			if (module.getKeybind() == event.getKey())
				module.setState(!module.getState());
	}

	public static List<Mod> getModList() {
		return modules;
	}

	public static ArrayList<Mod> getEnabledModList() {
		ArrayList<Mod> enabledModList = new ArrayList();
		for (Mod m : modules) {
			if (m.isEnabled()) {
				enabledModList.add(m);
			}
		}
		return enabledModList;
	}
}
