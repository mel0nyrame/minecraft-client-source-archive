package cn.Hanabi;

import cn.Hanabi.events.EventWorldChange;
import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;

import java.io.*;
import java.lang.management.ManagementFactory;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

public class Client {
    public static boolean active = true;
    public static boolean onDebug = false;
    public static WorldClient worldChange;
    public static int Level = -1;
    public static boolean isGameInit = false;

    public static float pitch;
    static boolean checked = false;
	public static String username = "hh";

    public static void onGameLoop() {
        isGameInit = true;
        WorldClient world = Minecraft.getMinecraft().theWorld;
        if (worldChange == null) {
            worldChange = world;
            return;
        }

        if (world == null) {
            worldChange = null;
            return;
        }


        if (worldChange != world) {
            worldChange = world;
            EventManager.call(new EventWorldChange());
        }
    }


   
}

