package me.guichaguri.betterfps.clones.block;

import me.guichaguri.betterfps.clones.tileentity.HopperLogic;
import net.minecraft.block.Block;
import net.minecraft.block.BlockHopper;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

/**
 * @author Guilherme Chaguri
 */
public class HopperBlock extends BlockHopper {

    public HopperBlock() { }

    @Override
    public void onNeighborBlockChange(World worldIn, BlockPos pos, IBlockState state, Block neighborBlock) {
        TileEntity te = worldIn.getTileEntity(pos);
        if(te != null) {
            TileEntityHopper hopper = (TileEntityHopper)te;
            ((HopperLogic)hopper).checkBlockOnTop();
            // This is casted to HopperLogic just to make this class compilable. It will be removed by the ASM
        }
    }

}
