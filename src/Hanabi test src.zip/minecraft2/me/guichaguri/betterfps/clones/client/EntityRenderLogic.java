package me.guichaguri.betterfps.clones.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.resources.IResourceManager;

/**
 * @author Guilherme Chaguri
 */
public class EntityRenderLogic extends EntityRenderer {

    public EntityRenderLogic(Minecraft mcIn, IResourceManager manager) {
        super(mcIn, manager);
    }

    public void setupFog(int p1, float partialTicks) {
        if(p1 != -1) return;
        super.setupFog(p1, partialTicks);
    }

}
