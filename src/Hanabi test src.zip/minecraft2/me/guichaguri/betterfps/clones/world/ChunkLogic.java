package me.guichaguri.betterfps.clones.world;

import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;

/**
 * @author Guilherme Chaguri
 */
public class ChunkLogic extends Chunk {

    private ChunkLogic(World worldIn, int x, int z) {
        super(worldIn, x, z);
    }

    public boolean shouldTick = true;

}
