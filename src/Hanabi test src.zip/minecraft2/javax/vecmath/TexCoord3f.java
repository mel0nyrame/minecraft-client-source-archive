package javax.vecmath;

import java.io.Serializable;

public class TexCoord3f extends Tuple3f implements Serializable {

    /**
      * Constructs and initializes a TexCoord3f from the specified xy coordinates.
      * @param x the x coordinate
      * @param y the y coordinate
      * @param z the z coordinate
      */
    public TexCoord3f(float x, float y, float z) {
	super(x, y, z);
    }

    /**
      * Constructs and initializes a TexCoord3f from the specified array.
      * @param p the array of length 3 containing xyz in order
      */
    public TexCoord3f(float v[]) {
	super(v);
    }

    /**
      * Constructs and initializes a TexCoord3f from the specified TexCoord3f.
      * @param v1 the TexCoord3f containing the initialization x y z data
      */
    public TexCoord3f(TexCoord3f v1) {
	super(v1);
    }

    /**
      * Constructs and initializes a TexCoord3f to (0,0,0).
      */
    public TexCoord3f() {
	super();
    }

}
