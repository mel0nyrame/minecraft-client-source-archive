package javax.vecmath;

import java.io.Serializable;

public class Color4b extends Tuple4b implements Serializable {

    /**
      * Constructs and initializes a Color4b from the specified four values.
      * @param c1 the first value
      * @param c2 the second value
      * @param c3 the third value
      * @param c4 the fourth value
      */
    public Color4b(byte c1, byte c2, byte c3, byte c4) {
	super(c1, c2, c3, c4);
    }

    /**
      * Constructs and initializes a Color4b from input array of length 4.
      * @param c the array of length 4 containing c1 c2 c3 c4 in order
      */
    public Color4b(byte c[]) {
	// ArrayIndexOutOfBounds is thrown if t.length < 4
	super(c);
    }

    /**
      * Constructs and initializes a Color4b from the specified Color4b.
      * @param c the Color4b containing the initialization x y z w data
      */
    public Color4b(Color4b c1) {
	super(c1);
    }

    /**
      * Constructs and initializes a Color4b from the specified Tuple4b.
      * @param t1 the Tuple4b containing the initialization x y z w data
      */
    public Color4b(Tuple4b t1) {
	super(t1);
    }

    /**
      * Constructs and initializes a Color4b to (0,0,0,0).
      */
    public Color4b() {
	// super(); called implicitly.
    }

    /**
     * Constructs color from awt.Color.
     *
     * @param color awt color
     */
    public Color4b(java.awt.Color color) {
        x = (byte)color.getRed();
        y = (byte)color.getGreen();
        z = (byte)color.getBlue();
        w = (byte)color.getAlpha();
    }

    /**
     * Sets color from awt.Color.
     * @param color awt color
     */
    public final void set(java.awt.Color color) {
        x = (byte)color.getRed();
        y = (byte)color.getGreen();
        z = (byte)color.getBlue();
        w = (byte)color.getAlpha();
    }
     
    /**
     * Gets awt.Color.
     *
     * @return color awt color
     */
    public final java.awt.Color get() {
        return new java.awt.Color(x, y, z, w);
    }
}
