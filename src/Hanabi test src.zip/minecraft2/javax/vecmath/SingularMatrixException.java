package javax.vecmath;

public class SingularMatrixException extends RuntimeException {
    /**
      * Creates the exception object with default values.
      */
    public SingularMatrixException() {
    }

    /**
      * Creates the exception object that outputs a message.
      * @param str the message string to output
      */
    public SingularMatrixException(String str) {
        super(str);
    }
}
