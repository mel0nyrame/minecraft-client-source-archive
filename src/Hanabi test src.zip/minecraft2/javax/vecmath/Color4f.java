package javax.vecmath;

import java.io.Serializable;

public class Color4f extends Tuple4f implements Serializable {

    /**
      * Constructs and initializes a Color4f from the specified xyzw
      * @param x the x coordinate
      * @param y the y coordinate
      * @param z the z coordinate
      * @param w the w coordinate
      */
    public Color4f(float x, float y, float z, float w) {
	super(x, y, z, w);
    }

    /**
      * Constructs and initializes a Color4f from input array of length 4.
      * @param c the array of length 4 containing xyzw in order
      */
    public Color4f(float c[]) {
	// ArrayIndexOutOfBounds is thrown if t.length < 4
	super(c);
    }

    /**
      * Constructs and initializes a Color4f from the specified Color4f.
      * @param c the Color4f containing the initialization x y z w data
      */
    public Color4f(Color4f c1) {
	super(c1);
    }

    /**
      * Constructs and initializes a Color4f from the specified Tuple4d.
      * @param t1 the Tuple4d containing the initialization x y z w data
      */
    public Color4f(Tuple4d t1) {
	super(t1);
    }

    /**
      * Constructs and initializes a Color4f from the specified Tuple4f.
      * @param t1 the Tuple4f containing the initialization x y z w data
      */
    public Color4f(Tuple4f t1) {
	super(t1);
    }

    /**
      * Constructs and initializes a Color4f to (0,0,0,0).
      */
    public Color4f() {
	// super(); called implicitly.
    }

    /**
     * Constructs color from awt.Color.
     *
     * @param color awt color
     */
    public Color4f(java.awt.Color color) {
        x = ((float)color.getRed())/255;
        y = ((float)color.getGreen())/255;
        z = ((float)color.getBlue())/255;
        w = ((float)color.getAlpha())/255;
    }

    /**
     * Sets color from awt.Color.
     * @param color awt color
     */
    public final void set(java.awt.Color color) {
        x = ((float)color.getRed())/255;
        y = ((float)color.getGreen())/255;
        z = ((float)color.getBlue())/255;
        w = ((float)color.getAlpha())/255;
    }
     
    /**
     * Gets awt.Color.
     *
     * @return color awt color
     */
    public final java.awt.Color get() {
        return new java.awt.Color(x, y, z, w);
    }
}
