package javax.vecmath;

import java.io.Serializable;

public class Color3f extends Tuple3f implements Serializable {

    /**
      * Constructs and initializes a Color3f from the specified xyz
      * @param x the x coordinate
      * @param y the y coordinate
      * @param z the z coordinate
      */
    public Color3f(float x, float y, float z) {
	super(x, y, z);
    }

    /**
      * Constructs and initializes a Color3f from input array of length 3.
      * @param c the array of length 3 containing xyz in order
      */
    public Color3f(float c[]) {
	// ArrayIndexOutOfBounds is thrown if t.length < 3
	super(c);
    }

    /**
      * Constructs and initializes a Color3f from the specified Color3f.
      * @param c the Color3f containing the initialization x y z data
      */
    public Color3f(Color3f c1) {
	super(c1);
    }

    /**
      * Constructs and initializes a Color3f from the specified Tuple3d.
      * @param t1 the Tuple3d containing the initialization x y z data
      */
    public Color3f(Tuple3d t1) {
	super(t1);
    }

    /**
      * Constructs and initializes a Color3f from the specified Tuple3f.
      * @param t1 the Tuple3f containing the initialization x y z data
      */
    public Color3f(Tuple3f t1) {
	super(t1);
    }

    /**
      * Constructs and initializes a Color3f to (0,0,0).
      */
    public Color3f() {
	// super(); called implicitly.
    }

    /**
     * Constructs color from awt.Color.
     *
     * @param color awt color
     */
    public Color3f(java.awt.Color color) {
        x = ((float)color.getRed())/255;
        y = ((float)color.getGreen())/255;
        z = ((float)color.getBlue())/255;
    }

    /**
     * Sets color from awt.Color.
     * @param color awt color
     */
    public final void set(java.awt.Color color) {
        x = ((float)color.getRed())/255;
        y = ((float)color.getGreen())/255;
        z = ((float)color.getBlue())/255;
    }
     
    /**
     * Gets awt.Color.
     *
     * @return color awt color
     */
    public final java.awt.Color get() {
        return new java.awt.Color(x, y, z);
    }
}
