package javax.vecmath;

import java.io.Serializable;

public class Point3i extends Tuple3i implements Serializable {

    /**
      * Constructs and initializes a Point3i from the specified xyz coordinates.
      * @param x the x coordinate
      * @param y the y coordinate
      * @param z the z coordinate
      */
    public Point3i(int x, int y, int z) {
	super(x, y, z);
    }

    /**
      * Constructs and initializes a Point3i from the specified array.
      * @param t the array of length 3 containing xyz in order
      */
    public Point3i(int t[]) {
	super(t);
    }

    /**
      * Constructs and initializes a Point3i from the specified Point3i.
      * @param t1 the Point3i containing the initialization x y z data
      */
    public Point3i(Point3i t1) {
	super(t1);
    }

    /**
      * Constructs and initializes a Point3i to (0,0,0).
      */
    public Point3i() {
	// super(); called implicitly.
    }
}
