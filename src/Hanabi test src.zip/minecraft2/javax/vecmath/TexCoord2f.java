package javax.vecmath;

import java.io.Serializable;

public class TexCoord2f extends Tuple2f implements Serializable {

    /**
      * Constructs and initializes a TexCoord2f from the specified xy coordinates.
      * @param x the x coordinate
      * @param y the y coordinate
      */
    public TexCoord2f(float x, float y) {
	super(x, y);
    }

    /**
      * Constructs and initializes a TexCoord2f from the specified array.
      * @param p the array of length 2 containing xy in order
      */
    public TexCoord2f(float v[]) {
	super(v);
    }

    /**
      * Constructs and initializes a TexCoord2f from the specified TexCoord2f.
      * @param v1 the TexCoord2f containing the initialization x y data
      */
    public TexCoord2f(TexCoord2f v1) {
	super(v1);
    }

    /**
      * Constructs and initializes a TexCoord2f from the specified Tuple2f.
      * @param t1 the Tuple2f containing the initialization x y data
      */
    public TexCoord2f(Tuple2f t1) {
	super(t1);
    }

    /**
      * Constructs and initializes a TexCoord2f to (0,0).
      */
    public TexCoord2f() {
	// super(); called implicitly
    }

}
