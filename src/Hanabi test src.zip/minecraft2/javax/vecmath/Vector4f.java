package javax.vecmath;

import java.io.Serializable;

public class Vector4f extends Tuple4f implements Serializable {

    /**
      * Constructs and initializes a Vector4f from the specified xyzw coordinates.
      * @param x the x coordinate
      * @param y the y coordinate
      * @param z the z coordinate
      * @param w the w coordinate
      */
    public Vector4f(float x, float y, float z, float w) {
	super(x, y, z, w);
    }

    /**
      * Constructs and initializes a Vector4f from the specified array of length 4.
      * @param v the array of length 4 containing xyzw in order
      */
    public Vector4f(float v[]) {
	super(v);
    }

    /**
      * Constructs and initializes a Vector4f from the specified Vector4f.
      * @param v1 the Vector4f containing the initialization x y z w data
      */
    public Vector4f(Vector4f v1) {
	super(v1);
    }

    /**
      * Constructs and initializes a Vector4f from the specified Vector4d.
      * @param v1 the Vector4d containing the initialization x y z w data
      */
    public Vector4f(Vector4d v1) {
	super(v1);
    }

    /**
      * Constructs and initializes a Vector4f from the specified Tuple4d.
      * @param t1 the Tuple4d containing the initialization x y z w data
      */
    public Vector4f(Tuple4d t1) {
	super(t1);
    }

    /**
      * Constructs and initializes a Vector4f from the specified Tuple4f.
      * @param t1 the Tuple4f containing the initialization x y z w data
      */
    public Vector4f(Tuple4f t1) {
	super(t1);
    }

    /**
      * Constructs and initializes a Vector4f to (0,0,0,0).
      */
    public Vector4f() {
	// super(); called implicitly
    }

    /**
     * Constructs and initializes a Vector4f from the specified Tuple3f.
     * The x,y,z  components of this point are set to the corresponding
     * components
     * of tuple t1. The w component of this point is set to 0.
     *
     * @param t1 the tuple to be copied
     * @since Java3D 1.2
     */
    public Vector4f(Tuple3f t1) {
        super(t1.x, t1.y, t1.z, 0);
    }

    /**
     * Sets the x,y,z components of this point to the corresponding
     * components of tuple t1. The w component of this point is set to 1.
     *
     * @param t1 the tuple to be copied
     * @since Java3D 1.2
     */
    public final void set(Tuple3f t1) {
        set(t1.x, t1.y, t1.z, 0);
    }

    /**
      * Returns the squared length of this vector.
      * @return the squared length of this vectoras a float
      */
    public final float lengthSquared() {
	return x*x + y*y + z*z + w*w;
    }

    /**
      * Returns the length of this vector.
      * @return the length of this vector as a float
      */
      public final float length() {
	  return (float)Math.sqrt(lengthSquared());
      }

    /**
      * Computes the dot product of the this vector and vector v1.
      * @param  v1 the other vector
      * @return the dot product of this vector and v1
      */
    public final float dot(Vector4f v1) {
	return x*v1.x + y*v1.y + z*v1.z + w*v1.w;
    }

    /**
      * Sets the value of this vector to the normalization of vector v1.
      * @param v1 the un-normalized vector
      */
    public final void normalize(Vector4d v1) {
	set(v1);
	normalize();
    }

    /**
      * Normalizes this vector in place.
      */
    public final void normalize() {
	double d = length();

	// zero-div may occur.
	x /= d;
	y /= d;
	z /= d;
	w /= d;
    }

    /**
      * Returns the (4-space) angle in radians between this vector and
      * the vector parameter; the return value is constrained to the
      * range [0,PI].
      * @param v1  the other vector
      * @return the angle in radians in the range [0,PI]
      */
    public final float angle(Vector4f v1) {
	// zero div may occur.
	double d = dot(v1);
	double v1_length = v1.length();
	double v_length = length();

	// numerically, domain error may occur
	return (float)Math.acos(d/v1_length/v_length);
    }
}
