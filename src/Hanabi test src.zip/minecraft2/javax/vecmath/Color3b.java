package javax.vecmath;

import java.io.Serializable;

public class Color3b extends Tuple3b implements Serializable {

    /**
      * Constructs and initializes a Color3b from the specified three values.
      * @param c1 the first value
      * @param c2 the second value
      * @param c3 the third value
      */
    public Color3b(byte c1, byte c2, byte c3) {
	super(c1, c2, c3);
    }

    /**
      * Constructs and initializes a Color3b from input array of length 3.
      * @param t the array of length 3 containing c1 c2 c3 in order
      */
    public Color3b(byte c[]) {
	// ArrayIndexOutOfBounds is thrown if t.length < 3
	super(c);
    }

    /**
      * Constructs and initializes a Color3b from the specified Color3b.
      * @param c the Color3b containing the initialization x y z data
      */
    public Color3b(Color3b c1) {
	super(c1);
    }

    /**
      * Constructs and initializes a Color3b from the specified Tuple3b.
      * @param t1 the Tuple3b containing the initialization x y z data
      */
    public Color3b(Tuple3b t1) {
	super(t1);
    }

    /**
      * Constructs and initializes a Color3b to (0,0,0).
      */
    public Color3b() {
	// super(); called implicitly
    }

    /**
     * Constructs color from awt.Color.
     *
     * @param color awt color
     */
    public Color3b(java.awt.Color color) {
        x = (byte)color.getRed();
        y = (byte)color.getGreen();
        z = (byte)color.getBlue();
    }

    /**
     * Sets color from awt.Color.
     * @param color awt color
     */
    public final void set(java.awt.Color color) {
        x = (byte)color.getRed();
        y = (byte)color.getGreen();
        z = (byte)color.getBlue();
    }
     
    /**
     * Gets awt.Color.
     *
     * @return color awt color
     */
    public final java.awt.Color get() {
        return new java.awt.Color(x, y, z);
    }
}
