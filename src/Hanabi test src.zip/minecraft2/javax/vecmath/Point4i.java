package javax.vecmath;

import java.io.Serializable;

public class Point4i extends Tuple4i implements Serializable {

    /**
      * Constructs and initializes a Point4i from the specified xyzw coordinates.
      * @param x the x coordinate
      * @param y the y coordinate
      * @param z the z coordinate
      * @param w the w coordinate
      */
    public Point4i(int x, int y, int z, int w) {
	super(x, y, z, w);
    }

    /**
      * Constructs and initializes a Point4i from the specified array.
      * @param t the array of length 4 containing xyzw in order
      */
    public Point4i(int t[]) {
	super(t);
    }

    /**
      * Constructs and initializes a Point4i from the specified Point4i.
      * @param t1 the Point4i containing the initialization x y z w data
      */
    public Point4i(Point4i t1) {
	super(t1);
    }

    /**
      * Constructs and initializes a Point4i to (0,0,0,0).
      */
    public Point4i() {
	// super(); called implicitly.
    }
}
