package Core.Import.libraries.slick.tests;

import Core.Import.libraries.slick.AppGameContainer;
import Core.Import.libraries.slick.BasicGame;
import Core.Import.libraries.slick.Color;
import Core.Import.libraries.slick.GameContainer;
import Core.Import.libraries.slick.Graphics;
import Core.Import.libraries.slick.Image;
import Core.Import.libraries.slick.SlickException;

/**
 * A test for transparent colour specification
 *
 * @author kevin
 */
public class TransparentColorTest extends BasicGame {
	/** The image we're currently displaying */
	private Image image;
	/** The image we're currently displaying */
	private Image timage;
	
	/**
	 * Create a new image rendering test
	 */
	public TransparentColorTest() {
		super("Transparent Color Test");
	}
	
	/**
	 * @see Core.Import.libraries.slick.BasicGame#init(Core.Import.libraries.slick.GameContainer)
	 */
	public void init(GameContainer container) throws SlickException {
		image = new Image("testdata/transtest.png");
		timage = new Image("testdata/transtest.png",new Color(94,66,41,255));
	}

	/**
	 * @see Core.Import.libraries.slick.BasicGame#render(Core.Import.libraries.slick.GameContainer, Core.Import.libraries.slick.Graphics)
	 */
	public void render(GameContainer container, Graphics g) {
		g.setBackground(Color.red);
		image.draw(10,10);
		timage.draw(10,310);
	}

	/**
	 * @see Core.Import.libraries.slick.BasicGame#update(Core.Import.libraries.slick.GameContainer, int)
	 */
	public void update(GameContainer container, int delta) {
	}

	/**
	 * Entry point to our test
	 * 
	 * @param argv The arguments to pass into the test
	 */
	public static void main(String[] argv) {
		try {
			AppGameContainer container = new AppGameContainer(new TransparentColorTest());
			container.setDisplayMode(800,600,false);
			container.start();
		} catch (SlickException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see Core.Import.libraries.slick.BasicGame#keyPressed(int, char)
	 */
	public void keyPressed(int key, char c) {
	}
}
