package Core.Import.libraries.slick.svg.inkscape;

import Core.Import.libraries.slick.geom.Transform;
import Core.Import.libraries.slick.svg.Diagram;
import Core.Import.libraries.slick.svg.Loader;
import Core.Import.libraries.slick.svg.ParsingException;
import org.w3c.dom.Element;

/**
 * TODO: Document this class
 *
 * @author kevin
 */
public class GroupProcessor implements ElementProcessor {

	/**
	 * @see Core.Import.libraries.slick.svg.inkscape.ElementProcessor#handles(Element)
	 */
	public boolean handles(Element element) {
		if (element.getNodeName().equals("g")) {
			return true;
		}
		return false;
	}

	/**O
	 * @see Core.Import.libraries.slick.svg.inkscape.ElementProcessor#process(Core.Import.libraries.slick.svg.Loader, Element, Core.Import.libraries.slick.svg.Diagram, Core.Import.libraries.slick.geom.Transform)
	 */
	public void process(Loader loader, Element element, Diagram diagram, Transform t) throws ParsingException {
		Transform transform = Util.getTransform(element);
		transform = new Transform(t, transform);
		
		loader.loadChildren(element, transform);
	}

}
