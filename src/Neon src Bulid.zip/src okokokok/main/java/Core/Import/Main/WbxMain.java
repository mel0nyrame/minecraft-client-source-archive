package Core.Import.Main;


import Core.Import.HWID.HWIDUtils;
import Core.Import.HWID.WebUtils;
import Core.Import.utils.SystemUtils.SystemUtils;
import org.lwjgl.opengl.Display;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class WbxMain {
    public static String Name = "Neon";

    public static void Main() {
        Display.setTitle(Name + " Loading......");
    }

    public static void Liquid() {
        Display.setTitle(Name + " " + version);
    }

    public static String Cracked = "Neon-Cracked-I Love you";
    public static String version = "Build 210911";
    public static String username;
    public static boolean isStarting;

    public static void sendWindowsMessageLogin() throws AWTException, IOException {
        //  FakeSenseMain.Cracked();
        Liquid();
        SystemUtils.displayTray("请输入用户名", "Login", TrayIcon.MessageType.WARNING);
        String AT = JOptionPane.showInputDialog("请输入用户名");
        final int R = 0;
        WbxMain.username = AT;
        WbxMain.isStarting = true;

        try {
            if (username == null) {
                JOptionPane.showMessageDialog(null, "用户名不能为空!", "验证", 0);
                System.exit(0);
            } else {
                if (WebUtils.get("https://gitee.com/Loneliness2908331301/hwid/blob/master/HWID.txt")
                        .contains(HWIDUtils.getHWID())) {
                    JOptionPane.showMessageDialog(null, "登陆成功", "Checker", 1);
                    SystemUtils.displayTray("登陆成功", "正在启动", TrayIcon.MessageType.WARNING);
                } else {
                    JOptionPane.showMessageDialog(null, "登陆失败", "Checker", 0);
                    JOptionPane.showInputDialog(null, "您还未绑定HWID,请绑定后重试！", HWIDUtils.getHWID());
                    SystemUtils.displayTray("草你妈没上绑定玩你🐎呢", "草你妈没上绑定玩你🐎呢", TrayIcon.MessageType.WARNING);
                    System.exit(0);
                }
            }
        } catch (NoSuchAlgorithmException | IOException e) {
            JOptionPane.showMessageDialog(null, "不连网络玩你🐎呢");
            SystemUtils.displayTray("不连网络玩你🐎呢", "不连网络玩你🐎呢", TrayIcon.MessageType.WARNING);
            System.exit(0);
        }
    }
}