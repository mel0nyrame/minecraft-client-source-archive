package Core.Import.Main;

import Core.Import.HWID.WebUtils;

import javax.swing.*;
import java.io.IOException;

public class FakeSenseMain {

    public static void Cracked() throws IOException {
        final String version1 = null;
        if (WbxMain.version.equals(version1)) {
        } else
            JOptionPane.showMessageDialog(null, "你的版本已经过时请更新");
        System.exit(0);
        if (version1 == null) {
        }else{
            if (WebUtils.get("https://gitee.com/liang-konglong/client-hwid/blob/master/version").contains(version1)){
            }
        }
    }
}