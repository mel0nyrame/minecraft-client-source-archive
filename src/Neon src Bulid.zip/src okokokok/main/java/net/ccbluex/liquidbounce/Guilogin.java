package net.ccbluex.liquidbounce;

import Core.Import.Main.WbxMain;
import net.ccbluex.liquidbounce.ui.client.GuiMainMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Guilogin extends GuiScreen {


    public static GuiTextField password;
    public static GuiTextField username;
    public static String Name = "Noteless";
    public static String version = "build 210821";
    public GuiButton loginButton;
    public GuiButton freeButton;
    public String UserName = null;
    public String Password = null;
    public static boolean isload = false;
    public String HWID = null;
    public static int LOVEU = 1;
    public static boolean Passed = false;
    public static String process = "[Waiting For Login]";
    public static String Now = "Neon-Login";


    @Override
    protected void actionPerformed(GuiButton button) {
        System.out.println(button.id);
        switch (button.id) {
            case 1:
                try {
                    LOVEU = LOVEU*10;//10
                    HWID =getHWID();
                    if (!username.getText().isEmpty() && !password.getText().isEmpty() && !HWID.isEmpty()) {
                        LOVEU = LOVEU*10;//1000
                        UserName = username.getText();
                        Password = password.getText();


                        String Verify = "["+UserName+"]"+HWID+":"+Password;
                        if (get("https://gitee.com/Loneliness2908331301/hwid/blob/master/HWID.txt").contains(Verify)){
                            LOVEU = LOVEU*10;//10000
                            isload = true;
                            Minecraft.getMinecraft().displayGuiScreen(new GuiMainMenu());
                        }else{
                            isload = false;

                        }


                    }
                } catch (Throwable var4) {
                    var4.printStackTrace();
                }
                break;
            case 3:
                Toolkit.getDefaultToolkit().getSystemClipboard().setContents(new StringSelection(getHWID()),null);
break;
        }
    }

    @Override
    public void drawScreen(int var1, int var2, float var3) {
        WbxMain.Liquid();
        FontRenderer var = this.mc.fontRendererObj;

        int color = new Color(245, 245, 245, 255).getRGB();
        final ScaledResolution s1 = new ScaledResolution(this.mc);
        ScaledResolution res = new ScaledResolution(this.mc);

        drawImage(new ResourceLocation("liquidbounce/bg.png"), (int) 0, 0, res.getScaledWidth(), res.getScaledHeight());

        username.drawTextBox();
        password.drawTextBox();
        var.drawStringWithShadow("User :", this.width / 2 - 100, this.height / 2 - 63, color);
        var.drawStringWithShadow("PassWord :", this.width / 2 - 100, this.height / 2 - 23, color);

        var.drawStringWithShadow(Now, this.width / 2 - var.getStringWidth(Now) / 2, this.height / 2 - 95, color);
        super.drawScreen(var1, var2, var3);
        var.drawStringWithShadow("Login", this.width / 2 - 52 - var.getStringWidth("Login") / 2, this.height / 2 + 55, color);
        var.drawStringWithShadow("Copy HWID", this.width / 2 + 52 - var.getStringWidth("Exit") / 2, this.height / 2 + 55, color);
    }

    @Override
    public void initGui() {
        FontRenderer var1 = this.mc.fontRendererObj;
        int var2 = this.height / 2;
        super.initGui();
        this.loginButton = new GuiButton(1, this.width / 2 - 102, var2 + 50, 100, 20, " ");
        this.freeButton = new GuiButton(3, this.width / 2 + 2, var2 + 50, 100, 20, " ");
        this.buttonList.add(this.loginButton);
        this.buttonList.add(this.freeButton);
        username = new GuiTextField(var2, var1, this.width / 2 - 100, this.height / 2 - 50, 200, 20);
        password = new GuiTextField(var2, var1, this.width / 2 - 100, this.height / 2 - 10, 200, 20);
        username.setFocused(true);
        Keyboard.enableRepeatEvents(true);
    }

    @Override
    protected void keyTyped(char var1, int var2) {
        try {
            super.keyTyped(var1, var2);
        } catch (IOException var4) {
            var4.printStackTrace();
        }

        if (var1 == 9) {
            if (!username.isFocused()) {
                username.setFocused(true);
            } else {
                username.setFocused(username.isFocused());
                password.setFocused(!username.isFocused());
            }
        }

        if (var1 == 13) {
            this.actionPerformed((GuiButton) this.buttonList.get(0));
        }

        if (var1 == 27) {

        }

        this.username.textboxKeyTyped(var1, var2);
        this.password.textboxKeyTyped(var1, var2);
    }

    @Override
    protected void mouseClicked(int var1, int var2, int var3) {
        try {
            super.mouseClicked(var1, var2, var3);
        } catch (IOException FontRenderer) {
            FontRenderer.printStackTrace();
        }

        this.username.mouseClicked(var1, var2, var3);
        this.password.mouseClicked(var1, var2, var3);
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
    }

    @Override
    public void updateScreen() {
        this.username.updateCursorCounter();
        this.password.updateCursorCounter();
    }

    public static void drawImage(final ResourceLocation image, final int x, final int y, final int width,
                                 final int height) {
        final ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glDepthMask(false);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        Minecraft.getMinecraft().getTextureManager().bindTexture(image);
        Gui.drawModalRectWithCustomSizedTexture(x, y, 0.0f, 0.0f, width, height, (float) width, (float) height);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glEnable(2929);
    }

    public static String get(String url) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();

        con.setRequestMethod("GET");
        con.setRequestProperty("User-Agent", "Mozilla/5.0");

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuilder response = new StringBuilder();

        while((inputLine = in.readLine())!= null) {
            response.append(inputLine);
            response.append("\n");
        }

        in.close();

        return response.toString();
    }

    public static String getHWID() {
        try {
            StringBuilder s = new StringBuilder();
            String main = System.getenv("PROCESS_IDENTIFIER") + System.getenv("COMPUTERNAME");
            byte[] bytes = main.getBytes("UTF-8");
            MessageDigest messageDigest = MessageDigest.getInstance("MD5");
            byte[] md5 = messageDigest.digest(bytes);
            int i = 0;
            for (byte b : md5) {
                s.append(Integer.toHexString((b & 0xFF) | 0x300), 0, 3);
                if (i != md5.length - 1) {
                    s.append("-");
                }
                i++;
            }
            LOVEU = LOVEU*10;//100
            return s.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }


}