package Lonelines.modules.render;

import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.Render3DEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.utils.render.ColorUtils;
import net.ccbluex.liquidbounce.value.IntegerValue;
import net.ccbluex.liquidbounce.value.ListValue;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;

import java.awt.*;

@ModuleInfo(name = "ChinaHat", description = "hell no.", category = ModuleCategory.RENDER)
public class ChinaHat extends Module {

	private static final ListValue colorModeValue = new ListValue("Colormode", new String[] { "Custom",  "Rainbow"}, "Custom");
	private static final IntegerValue sideValue = new IntegerValue("Cylinder-Side", 45, 40, 50);
	private static final IntegerValue stackValue = new IntegerValue("Cylinder-Stacks", 200, 200, 500);
	private static final IntegerValue colorRedValue = new IntegerValue("Cylinder-Red", 255, 0, 255);
	private static final IntegerValue colorGreenValue = new IntegerValue("Cylinder-Green", 255, 0, 255);
	private static final IntegerValue colorBlueValue = new IntegerValue("Cylinder-Blue", 255, 0, 255);
	private static final IntegerValue colorAlphaValue = new IntegerValue("Cylinder-Alpha", 20, 0, 255);

	public static Color generateColor() {
		int[] counter = new int[]{0};
		counter[0] = counter[0] + 1;
		Color color = new Color(255, 255, 255, 255);

		switch ((colorModeValue.get()).toLowerCase()) {
			case "custom":
				color = new Color(colorRedValue.get(), colorGreenValue.get(), colorBlueValue.get(), colorAlphaValue.get());
				break;
			case "rainbow":
				color = ColorUtils.rainbow();
				break;
		}
		return color;
	}

	@EventTarget
	public void onRender3D(Render3DEvent event) {
		mc.getRenderManager();
		if (Minecraft.getMinecraft().gameSettings.thirdPersonView == 0)
			return;
		drawCircle(Minecraft.getMinecraft().thePlayer, generateColor().getRGB(), event);
	}

	public static void drawCircle(EntityLivingBase entity, int color, Render3DEvent e) {
		double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * e.getPartialTicks() - Minecraft.getMinecraft().getRenderManager().renderPosX;
		double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * e.getPartialTicks() - Minecraft.getMinecraft().getRenderManager().renderPosY;
		double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * e.getPartialTicks() - Minecraft.getMinecraft().getRenderManager().renderPosZ;
		float radius = 0.8F;
		int side = sideValue.get();
		float base = 0;
		float height = 0.4F;
		int stack = stackValue.get();

		GL11.glPushMatrix();
		GL11.glTranslated(x, y + 2.2D, z);
		GL11.glRotatef(-entity.width, 0.0F, 1.0F, 0.0F);
		glColor(color);
		enableSmoothLine(1.0F);
		Cylinder c = new Cylinder();
		GL11.glRotatef(90F, 1.0F, 0F, 0F);
		c.setDrawStyle(100011);
		c.draw(base, radius, height, side, stack);

		disableSmoothLine();
		GL11.glPopMatrix();
	}

	public static void glColor(int hex) {
		float alpha = (hex >> 24 & 0xFF) / 255.0F;
		float red = (hex >> 16 & 0xFF) / 255.0F;
		float green = (hex >> 8 & 0xFF) / 255.0F;
		float blue = (hex & 0xFF) / 255.0F;
		GL11.glColor4f(red, green, blue, (alpha == 0.0F) ? 1.0F : alpha);
	}

	public static void enableSmoothLine(float width) {
		GL11.glDisable(3008);
		GL11.glEnable(3042);
		GL11.glBlendFunc(770, 771);
		GL11.glDisable(3553);
		GL11.glDisable(2929);
		GL11.glDepthMask(false);
		GL11.glEnable(2884);
		GL11.glEnable(2848);
		GL11.glHint(3154, 4354);
		GL11.glHint(3155, 4354);
		GL11.glLineWidth(width);
	}

	public static void disableSmoothLine() {
		GL11.glEnable(3553);
		GL11.glEnable(2929);
		GL11.glDisable(3042);
		GL11.glEnable(3008);
		GL11.glDepthMask(true);
		GL11.glCullFace(1029);
		GL11.glDisable(2848);
		GL11.glHint(3154, 4352);
		GL11.glHint(3155, 4352);
	}
}
