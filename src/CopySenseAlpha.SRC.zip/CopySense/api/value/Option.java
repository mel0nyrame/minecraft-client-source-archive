
package CopySense.api.value;

import CopySense.api.value.Value;

public class Option<V>
extends Value<V> {
    public Option(String displayName, String name, V enabled) {
        super(displayName, name);
        this.setValue(enabled);
    }

	public Boolean getValueState() {
		// TODO �Զ����ɵķ������
		return null;
	}
}

