/*
 * Decompiled with CFR 0_132.
 */
package CopySense.api.events.world;

import CopySense.api.Event;

public class EventPreUpdate extends Event {
	   public float yaw;
	   public float pitch;
	   public double y;
	   private boolean ground;
	   private boolean isPre;
	   public EventPreUpdate(float yaw, float pitch, double y, boolean ground) {
		  this.isPre = true;
	      this.yaw = yaw;
	      this.pitch = pitch;
	      this.y = y;
	      this.ground = ground;
	   }
	   @Override
	   public void fire() {
	       this.isPre = false;
	       super.fire();
	   }

	   public float getYaw() {
	      return this.yaw;
	   }

	   public void setYaw(float yaw) {
	      this.yaw = yaw;
	   }

	   public float getPitch() {
	      return this.pitch;
	   }

	   public void setPitch(float pitch) {
	      this.pitch = pitch;
	   }

	   public double getY() {
	      return this.y;
	   }

	   public void setY(double y) {
	      this.y = y;
	   }

	   public boolean isOnground() {
	      return this.ground;
	   }

	   public void setOnground(boolean ground) {
	      this.ground = ground;
	   }

	public boolean isPre() {
		        return this.isPre;
		    }
	public float getYaw2() {
	    return this.yaw;
	}

	public boolean isPost() {
	    return !this.isPre;
	}
	}
