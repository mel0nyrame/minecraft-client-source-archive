package CopySense.api.events.world;

import CopySense.api.Event;

public class EventRespawn extends Event
{
}
