/*
 * Decompiled with CFR 0_132.
 */
package CopySense.api.events.world;

import CopySense.api.Event;

public class EventTick
extends Event {
}

