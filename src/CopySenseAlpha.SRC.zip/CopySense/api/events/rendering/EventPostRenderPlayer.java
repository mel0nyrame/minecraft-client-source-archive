/*
 * Decompiled with CFR 0_132.
 */
package CopySense.api.events.rendering;

import CopySense.api.Event;

public class EventPostRenderPlayer
extends Event {
}

