package CopySense.api.events.misc;

import net.minecraft.entity.*;
import CopySense.api.*;

public class EventLivingUpdate implements Event
{
    public Entity entity;
    
    public EventLivingUpdate(final Entity targetEntity) {
        this.entity = targetEntity;
    }
    
    public Entity getEntity() {
        return this.entity;
    }
}
