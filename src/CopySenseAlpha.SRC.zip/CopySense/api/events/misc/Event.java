package CopySense.api.events.misc;

public interface Event {
}
