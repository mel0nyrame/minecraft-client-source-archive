/*
 * Decompiled with CFR 0_132.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package CopySense.command.commands;

import CopySense.Client;
import CopySense.command.Command;
import CopySense.module.Module;
import CopySense.utils.Helper;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;

public class Title
extends Command {
    public Title() {
        super("Title", new String[]{"t"}, "", "");
    }
    @Override
    public String execute(String[] tle) {
        if (tle.length >= 1) {
            if(tle[1] != "") {
                Display.setTitle(tle[0] + " " + "[CopySense]");
                Helper.sendMessageWithoutPrefix("\u00a7F[Copy\u00a7bSense\u00a7F] Fix you title For < \u00a7a"+tle[0]+"\u00a7f >");
            }
        } else {
            Helper.sendMessageWithoutPrefix("\u00a7F[Copy\u00a7bSense\u00a7F] .title <ClientTitle>");
        }
        return null;
    }
}

