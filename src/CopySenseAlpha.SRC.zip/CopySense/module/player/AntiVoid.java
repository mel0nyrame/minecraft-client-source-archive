/*
 * Decompiled with CFR 0_132.
 */
package CopySense.module.player;

import java.awt.Color;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventMove;
import CopySense.api.events.world.EventPacketRecieve;
import CopySense.api.events.world.EventPacketSend;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Numbers;
import CopySense.api.value.Option;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import net.minecraft.block.BlockAir;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;

public class AntiVoid
extends Module {
    boolean AAAA;
    double mario;
    private Option<Boolean> VoidOnly = new Option<Boolean>("VoidOnly", "VoidOnly", true);
    public Numbers<Double> MinFallenBlocks = new Numbers<Double>("Delay","Delay", 10.0, 5.0, 30.0, 1.0);
    public AntiVoid() {
        super("AntiVoid", new String[]{"novoid", "antifall"}, ModuleType.Player);
        this.setColor(new Color(223, 233, 233).getRGB());
        this.addValues(this.VoidOnly,this.MinFallenBlocks);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        AAAA = false;
        mario = 0;
    }

    @Override
    public void onDisable() {
        super.onDisable();
        mario = 0;
        AAAA = false;
    }

    @EventHandler
    private void onPacket(EventPacketSend event) {
        Packet packet = event.getPacket();
        if (packet instanceof C03PacketPlayer && mc.thePlayer.fallDistance >= MinFallenBlocks.getValue()){
        if (VoidOnly.getValue() && mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.getEntityBoundingBox().offset(0, 0, 0).expand(0, 0, 0)).isEmpty() && mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.getEntityBoundingBox().offset(0, -10002.25, 0).expand(0, -10003.75, 0)).isEmpty()) {
            ((C03PacketPlayer) packet).y += 11;
        } else {
            if (!VoidOnly.getValue()) {
                ((C03PacketPlayer) packet).y += 11;
            }
            }
        }
    }

    @EventHandler
    private void onMove(EventMove event){
        if (!VoidOnly.getValue() && mc.thePlayer.fallDistance >= MinFallenBlocks.getValue() && mc.thePlayer.motionY <= 0 && (AAAA == false || mc.thePlayer.posY <= mario)){
            mc.thePlayer.motionY = 1.85;
            mc.thePlayer.motionX = 0;
            mc.thePlayer.motionZ = 0;
            event.setX(0);
            event.setZ(0);
            mario = mc.thePlayer.posY;
            AAAA = true;
        }
        if (mc.thePlayer.onGround){
            mario = 0;
            AAAA = false;
        }
    }
}
