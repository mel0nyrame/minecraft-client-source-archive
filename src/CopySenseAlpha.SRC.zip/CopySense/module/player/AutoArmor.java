package CopySense.module.player;

import CopySense.api.EventHandler;
import CopySense.api.events.misc.EventUpdate;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.management.ModuleManager;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.utils.Timer;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.network.play.client.C16PacketClientStatus.EnumState;

import java.awt.*;
import java.util.stream.IntStream;

public class AutoArmor
		extends Module {
	public static final String DELAY = "DELAY";
	public static final String MODE = "MODE";
	private Timer timer = new Timer();
	public Numbers<Double> dacdac = new Numbers<Double>("Delay","Delay", 1.0, 0.0, 10.0, 1.0);
	public Mode<Enum> modmod = new Mode("Mode", "Mode", (Enum[]) SBMODE.values(), (Enum)SBMODE.Basic);
	public AutoArmor() {
		super("AutoArmor", new String[]{"autoarmor","autor","armor"}, ModuleType.Player);
		this.setColor(Color.BLUE.getRGB());
		this.addValues(this.dacdac, this.modmod);
	}
	@EventHandler
	public void onPre(EventPreUpdate event) {
		this.setSuffix(this.modmod.getValue()+" D:"+this.dacdac.getValue());
    	if(ModuleManager.getModuleByClass(InventoryManager.class).isEnabled())
    		return;
    	long delay = ((Number)this.dacdac.getValue()).longValue()*50;
		if(this.modmod.getValue()==SBMODE.OpenInv&&!(mc.currentScreen instanceof GuiInventory)){
			return;
		}
			if (mc.currentScreen == null || mc.currentScreen instanceof GuiInventory || mc.currentScreen instanceof GuiChat) {
				if (timer.check(delay)) {
					getBestArmor();
			}
		}
    }
    
    public void getBestArmor(){
    	for(int type = 1; type < 5; type++){
    		if(mc.thePlayer.inventoryContainer.getSlot(4 + type).getHasStack()){
    			ItemStack is = mc.thePlayer.inventoryContainer.getSlot(4 + type).getStack();
    			if(isBestArmor(is, type)){
    				continue;
    			}else{
    				if (this.modmod.getValue()==SBMODE.FakeInv) {
        				C16PacketClientStatus p = new C16PacketClientStatus(EnumState.OPEN_INVENTORY_ACHIEVEMENT);
        				mc.thePlayer.sendQueue.addToSendQueue(p);
    				}
    				drop(4 + type);
    			}
    		}
    		for (int i = 9; i < 45; i++) {
    			if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
    				ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
    				if(isBestArmor(is, type) && getProtection(is) > 0){
    					shiftClick(i);
    					timer.reset();
    					if(((Number)this.dacdac.getValue()).longValue() > 0)
    						return;
    				}
    			}
            }
        }
    }
    public static boolean isBestArmor(ItemStack stack, int type){
    	float prot = getProtection(stack);
    	String strType = "";
    	if(type == 1){
    		strType = "helmet";
    	}else if(type == 2){
    		strType = "chestplate";
    	}else if(type == 3){
    		strType = "leggings";
    	}else if(type == 4){
    		strType = "boots";
    	}
    	if(!stack.getUnlocalizedName().contains(strType)){
    		return false;
    	}
    	for (int i = 5; i < 45; i++) {
            if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                if(getProtection(is) > prot && is.getUnlocalizedName().contains(strType))
                	return false;
            }
        }
    	return true;
    }
    public void shiftClick(int slot){
    	mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot, 0, 1, mc.thePlayer);
    }

    public void drop(int slot){
    	mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot, 1, 4, mc.thePlayer);
    }
    public static float getProtection(ItemStack stack){
    	float prot = 0;
    	if ((stack.getItem() instanceof ItemArmor)) {
    		ItemArmor armor = (ItemArmor)stack.getItem();
    		prot += armor.damageReduceAmount + (100 - armor.damageReduceAmount) * EnchantmentHelper.getEnchantmentLevel(Enchantment.protection.effectId, stack) * 0.0075D;
    		prot += EnchantmentHelper.getEnchantmentLevel(Enchantment.blastProtection.effectId, stack)/100d;
    		prot += EnchantmentHelper.getEnchantmentLevel(Enchantment.fireProtection.effectId, stack)/100d;
    		prot += EnchantmentHelper.getEnchantmentLevel(Enchantment.thorns.effectId, stack)/100d;
    		prot += EnchantmentHelper.getEnchantmentLevel(Enchantment.unbreaking.effectId, stack)/50d;   	
    		prot += EnchantmentHelper.getEnchantmentLevel(Enchantment.featherFalling.effectId, stack)/100d;   	
    	}
	    return prot;
    }
    enum SBMODE {
		Basic, OpenInv, FakeInv
	}
}
