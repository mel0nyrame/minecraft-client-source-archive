package CopySense.module.player;

import java.awt.*;
import net.minecraft.inventory.Slot;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Optional;

import CopySense.api.EventHandler;
import CopySense.api.events.misc.EventUpdate;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.api.value.Option;
import CopySense.management.ModuleManager;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.world.Scaffold;
import CopySense.utils.InventoryUtils;
import CopySense.utils.TimeHelper;
import CopySense.utils.Timer;
import CopySense.utils.TimerUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemGlassBottle;
import net.minecraft.item.ItemHoe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemTool;
import net.minecraft.potion.Potion;
import java.util.Objects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.entity.ai.attributes.AttributeModifier;

/*
 * Made by LeakedPvP
 */
public class InventoryManager
		extends Module {
	private Numbers<Double> BLOCKCAP = new Numbers<Double>("BlockCap","BlockCap", 8.0, -1.0, 256.0, 1.0);
	private Numbers<Double> DELAY = new Numbers<Double>("Delay","Delay", 1.0, 0.0, 10.0, 1.0);
	private Option<Boolean> ARCHERY = new Option<Boolean>("Archery","Archery", false);
	private Option<Boolean> FOOD = new Option<Boolean>("Food","Food", false);
	private Option<Boolean> SWORD = new Option<Boolean>("AutoSword","AutoSword", false);
	private Option<Boolean> INVCLEANER = new Option<Boolean>("InvCleaner","InvCleaner", true);
	public Mode<Enum> MODE = new Mode("Mode", "Mode", (Enum[]) InventoryManager.SBMODE.values(), (Enum) InventoryManager.SBMODE.Basic);
    public static int weaponSlot = 36, pickaxeSlot = 37, axeSlot = 38, shovelSlot = 39;
    Timer timer = new Timer();
    public TimerUtil timer2 = new TimerUtil();
    private ItemStack bestSword;
    private ItemStack prevBestSword;
	TimeHelper time = new TimeHelper();
    private boolean shouldSwitch = false;
    ArrayList<Integer>whitelistedItems = new ArrayList<>();
	public InventoryManager() {
		super("InventoryManager", new String[]{"InventoryManager", "inventoryCleaner", "invManager", "invM"}, ModuleType.Player);
		this.setColor(Color.BLUE.getRGB());
		this.addValues(MODE,BLOCKCAP,DELAY,ARCHERY,FOOD,SWORD,INVCLEANER);
	}
	
    private ItemStack getBestItem(Class<? extends Item> itemType, Comparator comparator) {
        Optional<ItemStack> bestItem = this.mc.thePlayer.inventoryContainer.inventorySlots.stream().map(Slot::getStack).filter(Objects::nonNull).filter(itemStack -> itemStack.getItem().getClass().equals((Object)itemType)).max(comparator);
        return bestItem.orElse(null);
    }
    
	private float getSharpnessLevel(ItemStack stack) {
		float damage = ((ItemSword)stack.getItem()).getDamageVsEntity();
		damage += (float)EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId, stack) * 1.25f;
		return damage += (float)EnchantmentHelper.getEnchantmentLevel(Enchantment.fireAspect.effectId, stack) * 0.01f;
	}

    private double getSwordDamage(ItemStack itemStack) {
        double damage = 0.0;
        Optional attributeModifier = itemStack.getAttributeModifiers().values().stream().findFirst();
        if (attributeModifier.isPresent()) {
            damage = ((AttributeModifier)attributeModifier.get()).getAmount();
        }
        return damage += (double)EnchantmentHelper.func_152377_a(itemStack, EnumCreatureAttribute.UNDEFINED);
    }
    
	@EventHandler
	public void onPre(EventPreUpdate event) {
        setSuffix(this.MODE.getValue());
        if(SWORD.getValue()){
            if (this.mc.thePlayer.ticksExisted % 7 == 0) {
                if (this.mc.thePlayer.capabilities.isCreativeMode || this.mc.thePlayer.openContainer != null && this.mc.thePlayer.openContainer.windowId != 0) {
                    return;
                }
                this.bestSword = this.getBestItem(ItemSword.class, Comparator.comparingDouble(this::getSwordDamage));
                if (this.bestSword == null) {
                    return;
                }
                boolean isInHBSlot = InventoryUtils.hotbarHas(this.bestSword.getItem(), 0);
                if (isInHBSlot) {
                    if (InventoryUtils.getItemBySlotID(0) != null) {
                        if (InventoryUtils.getItemBySlotID(0).getItem() instanceof ItemSword) {
                            isInHBSlot = this.getSwordDamage(InventoryUtils.getItemBySlotID(0)) >= this.getSwordDamage(this.bestSword);
                        }
                    } else {
                        isInHBSlot = false;
                    }
                }
                if (this.prevBestSword == null || !this.prevBestSword.equals(this.bestSword) || !isInHBSlot) {
                    this.shouldSwitch = true;
                    this.prevBestSword = this.bestSword;
                } else {
                    this.shouldSwitch = false;
                }
                if (this.shouldSwitch && this.timer2.hasReached(1.0)) {
                    int slotHB = InventoryUtils.getBestSwordSlotID(this.bestSword, this.getSwordDamage(this.bestSword));
                    switch (slotHB) {
                        case 0: {
                            slotHB = 36;
                            break;
                        }
                        case 1: {
                            slotHB = 37;
                            break;
                        }
                        case 2: {
                            slotHB = 38;
                            break;
                        }
                        case 3: {
                            slotHB = 39;
                            break;
                        }
                        case 4: {
                            slotHB = 40;
                            break;
                        }
                        case 5: {
                            slotHB = 41;
                            break;
                        }
                        case 6: {
                            slotHB = 42;
                            break;
                        }
                        case 7: {
                            slotHB = 43;
                            break;
                        }
                        case 8: {
                            slotHB = 44;
                            break;
                        }
                    }
                    this.mc.playerController.windowClick(0, slotHB, 0, 2, this.mc.thePlayer);
                    this.timer.reset();
                }
            }
		}
        long delay = ((Number)this.DELAY.getValue()).longValue()*50;
            Module armor = ModuleManager.getModuleByClass(AutoArmor.class);
            long Adelay = ((Number)this.DELAY.getValue()).longValue()*50;
            if(!event.isPre())
            	return;
            if(timer.check(Adelay) && armor.isEnabled()){
            	 if(this.MODE.getValue()==SBMODE.Basic|| mc.currentScreen instanceof GuiInventory){
                     if(mc.currentScreen == null || mc.currentScreen instanceof GuiInventory || mc.currentScreen instanceof GuiChat){
                    	 getBestArmor();
                     }
                 }
            }
            if( armor.isEnabled())
            for(int type = 1; type < 5; type++){
        		if(mc.thePlayer.inventoryContainer.getSlot(4 + type).getHasStack()){
        			ItemStack is = mc.thePlayer.inventoryContainer.getSlot(4 + type).getStack();
        			if(!AutoArmor.isBestArmor(is, type)){
        				return;
        			}
        		}else if(invContainsType(type-1)){
        			return;
        		}
            }
            if(this.MODE.getValue()==SBMODE.OpenInv && !(mc.currentScreen instanceof GuiInventory)){
            	return;
            }
            
            if(mc.currentScreen == null || mc.currentScreen instanceof GuiInventory || mc.currentScreen instanceof GuiChat){
            	if(timer.check(delay) && weaponSlot >= 36){         

            		if (!mc.thePlayer.inventoryContainer.getSlot(weaponSlot).getHasStack()){
            			getBestWeapon(weaponSlot);
                	
            		}else{
            			if(!isBestWeapon(mc.thePlayer.inventoryContainer.getSlot(weaponSlot).getStack())){           			
                			getBestWeapon(weaponSlot);
                		}
            		}
            	}
            	if(timer.check(delay) && pickaxeSlot >= 36){
            		getBestPickaxe(pickaxeSlot);
            	}
            	if(timer.check(delay) && shovelSlot >= 36){
            		getBestShovel(shovelSlot);
            	}
            	if(timer.check(delay) && axeSlot >= 36){
            		getBestAxe(axeSlot);
            	}
            	if(timer.check(delay) && this.INVCLEANER.getValue())
                for (int i = 9; i < 45; i++) {
                    if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                        ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                        if(shouldDrop(is, i)){
                        	drop(i);
                        	timer.reset();
                        	if(delay > 0)
                        	break;
                    }
                }              
            }
    	}
    }
    public void shiftClick(int slot){
    	mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot, 0, 1, mc.thePlayer);
    }
    public void swap(int slot1, int hotbarSlot){
    	mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot1, hotbarSlot, 2, mc.thePlayer);
    }
    public void drop(int slot){
    	mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot, 1, 4, mc.thePlayer);
    }

	public boolean isBestWeapon(ItemStack stack) {
		float damage = this.getDamage(stack);
		int i = 9;
		while (i < 45) {
			ItemStack is;
			if (Minecraft.getMinecraft().thePlayer.inventoryContainer.getSlot(i).getHasStack() && this.getDamage(is = Minecraft.getMinecraft().thePlayer.inventoryContainer.getSlot(i).getStack()) > damage && is.getItem() instanceof ItemSword) {
				return false;
			}
			++i;
		}
		if (stack.getItem() instanceof ItemSword) {
			return true;
		}
		return false;
	}


	public void getBestWeapon(int slot) {
		int i = 9;
		while (i < 45) {
			ItemStack is;
			if (Minecraft.getMinecraft().thePlayer.inventoryContainer.getSlot(i).getHasStack() && this.isBestWeapon(is = Minecraft.getMinecraft().thePlayer.inventoryContainer.getSlot(i).getStack()) && this.getDamage(is) > 0.0f && is.getItem() instanceof ItemSword) {
				this.swap(i, slot - 36);
				this.timer.reset();
				break;
			}
			++i;
		}
	}

    private float getDamage(ItemStack stack) {
    	float damage = 0;
    	Item item = stack.getItem();
    	if(item instanceof ItemTool){
    		ItemTool tool = (ItemTool)item;
    		damage += tool.getDamage();
    	}
    	if(item instanceof ItemSword){
    		ItemSword sword = (ItemSword)item;
    		damage += sword.getDamageVsEntity();
    	}
    	damage += EnchantmentHelper.getEnchantmentLevel(Enchantment.sharpness.effectId, stack) * 1.25f + 
    			EnchantmentHelper.getEnchantmentLevel(Enchantment.fireAspect.effectId, stack) * 0.01f;
        return damage;
    }
    public boolean shouldDrop(ItemStack stack, int slot){
    	if(stack.getDisplayName().toLowerCase().contains("(right click)")){
    		return false;
    	}
    	if(stack.getDisplayName().toLowerCase().contains("§k||")){
    		return false;
    	}
    	if((slot == weaponSlot && isBestWeapon(mc.thePlayer.inventoryContainer.getSlot(weaponSlot).getStack())) ||
    			(slot == pickaxeSlot && isBestPickaxe(mc.thePlayer.inventoryContainer.getSlot(pickaxeSlot).getStack()) && pickaxeSlot >= 0) ||
    			(slot == axeSlot && isBestAxe(mc.thePlayer.inventoryContainer.getSlot(axeSlot).getStack()) && axeSlot >= 0) ||
    			(slot == shovelSlot && isBestShovel(mc.thePlayer.inventoryContainer.getSlot(shovelSlot).getStack()) && shovelSlot >= 0) ){
    		return false;
    	}
    	if(stack.getItem() instanceof ItemArmor){
    		for(int type = 1; type < 5; type++){
    			if(mc.thePlayer.inventoryContainer.getSlot(4 + type).getHasStack()){
        			ItemStack is = mc.thePlayer.inventoryContainer.getSlot(4 + type).getStack();
        			if(AutoArmor.isBestArmor(is, type)){
        				continue;
        			}
        		}
    			if(AutoArmor.isBestArmor(stack, type)){
    				return false;
    			}
    		}
    	}
    	if (stack.getItem() instanceof ItemBlock &&
    			(getBlockCount() > this.BLOCKCAP.getValue() ||
    					Scaffold.getBlacklistedBlocks().contains(((ItemBlock)stack.getItem()).getBlock()))){
    		return true;
    	}
    	if(stack.getItem() instanceof ItemPotion){
    		if(isBadPotion(stack)){
    			return true;
    		}
    	}
    	if(stack.getItem() instanceof ItemFood && this.FOOD.getValue() && !(stack.getItem() instanceof ItemAppleGold)){
    		return true;
    	}
    	if(stack.getItem() instanceof ItemHoe || stack.getItem() instanceof ItemTool || stack.getItem() instanceof ItemSword || stack.getItem() instanceof ItemArmor){
    		return true;
    	}
    	if((stack.getItem() instanceof ItemBow || stack.getItem().getUnlocalizedName().contains("arrow")) && this.ARCHERY.getValue()){
    		return true;
    	}
    	
    	if(((stack.getItem().getUnlocalizedName().contains("tnt")) ||
                        (stack.getItem().getUnlocalizedName().contains("stick")) ||
                        (stack.getItem().getUnlocalizedName().contains("egg")) ||
                        (stack.getItem().getUnlocalizedName().contains("string")) ||
                        (stack.getItem().getUnlocalizedName().contains("cake")) ||
                        (stack.getItem().getUnlocalizedName().contains("mushroom")) ||
                        (stack.getItem().getUnlocalizedName().contains("flint")) ||
                        (stack.getItem().getUnlocalizedName().contains("compass")) ||
                        (stack.getItem().getUnlocalizedName().contains("dyePowder")) ||
                        (stack.getItem().getUnlocalizedName().contains("feather")) ||
                        (stack.getItem().getUnlocalizedName().contains("bucket")) ||
                        (stack.getItem().getUnlocalizedName().contains("chest") && !stack.getDisplayName().toLowerCase().contains("collect")) ||
                        (stack.getItem().getUnlocalizedName().contains("snow")) ||
                        (stack.getItem().getUnlocalizedName().contains("fish")) ||
                        (stack.getItem().getUnlocalizedName().contains("enchant")) ||
                        (stack.getItem().getUnlocalizedName().contains("exp")) ||
                        (stack.getItem().getUnlocalizedName().contains("shears")) ||
                        (stack.getItem().getUnlocalizedName().contains("anvil")) ||
                        (stack.getItem().getUnlocalizedName().contains("torch")) ||
                        (stack.getItem().getUnlocalizedName().contains("seeds")) ||
                        (stack.getItem().getUnlocalizedName().contains("leather")) ||
                        (stack.getItem().getUnlocalizedName().contains("reeds")) ||
                        (stack.getItem().getUnlocalizedName().contains("skull")) ||
                        (stack.getItem().getUnlocalizedName().contains("record")) ||
                        (stack.getItem().getUnlocalizedName().contains("snowball")) ||
                        (stack.getItem() instanceof ItemGlassBottle) ||
                        (stack.getItem().getUnlocalizedName().contains("piston")))){
    		return true;
    	}            
    	
    	return false;
    }
    public ArrayList<Integer>getWhitelistedItem(){
    	return whitelistedItems;
    }
    private int getBlockCount() {
        int blockCount = 0;
        for (int i = 0; i < 45; i++) {
            if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                Item item = is.getItem();
                if (is.getItem() instanceof ItemBlock && ! Scaffold.getBlacklistedBlocks().contains(((ItemBlock) item).getBlock())) {
                    blockCount += is.stackSize;
                }
            }
        }
        return blockCount;
    }
    
    private void getBestPickaxe(int slot){
    	for (int i = 9; i < 45; i++) {
			if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
				ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
				
				if(isBestPickaxe(is) && pickaxeSlot != i){
					if(!isBestWeapon(is))
					if(!mc.thePlayer.inventoryContainer.getSlot(pickaxeSlot).getHasStack()){	
						swap(i, pickaxeSlot - 36);
						timer.reset();
    					if(((Number)this.DELAY.getValue()).longValue() > 0)
    						return;
					}else if(!isBestPickaxe(mc.thePlayer.inventoryContainer.getSlot(pickaxeSlot).getStack())){
						swap(i, pickaxeSlot - 36);
						timer.reset();
    					if(((Number)this.DELAY.getValue()).longValue() > 0)
    						return;
					}
				
				}
			}
    	}
    }
    private void getBestShovel(int slot){
    	for (int i = 9; i < 45; i++) {
			if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
				ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
				
				if(isBestShovel(is) && shovelSlot != i){
					if(!isBestWeapon(is))
					if(!mc.thePlayer.inventoryContainer.getSlot(shovelSlot).getHasStack()){
						swap(i, shovelSlot - 36);
						timer.reset();
    					if(((Number)this.DELAY.getValue()).longValue() > 0)
    						return;
					}else if(!isBestShovel(mc.thePlayer.inventoryContainer.getSlot(shovelSlot).getStack())){	
						swap(i, shovelSlot - 36);
						timer.reset();
    					if(((Number)this.DELAY.getValue()).longValue() > 0)
    						return;
					}
				
				}
			}
    	}
    }
    private void getBestAxe(int slot){

    	for (int i = 9; i < 45; i++) {
			if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
				ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
				
				if(isBestAxe(is) && axeSlot != i){
					if(!isBestWeapon(is))
					if(!mc.thePlayer.inventoryContainer.getSlot(axeSlot).getHasStack()){
						swap(i, axeSlot - 36);
						timer.reset();
    					if(((Number)this.DELAY.getValue()).longValue() > 0)
    						return;
					}else if(!isBestAxe(mc.thePlayer.inventoryContainer.getSlot(axeSlot).getStack())){
						swap(i, axeSlot - 36);
						timer.reset();
    					if(((Number)this.DELAY.getValue()).longValue() > 0)
    						return;
					}
				
				}
			}
    	}
    }
    private boolean isBestPickaxe(ItemStack stack){
     	Item item = stack.getItem();
    	if(!(item instanceof ItemPickaxe))
    		return false;
    	float value = getToolEffect(stack);
    	for (int i = 9; i < 45; i++) {
            if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                if(getToolEffect(is) > value && is.getItem() instanceof ItemPickaxe){                	
                	return false;
                }
                	
            }
        }
    	return true;
    }
    private boolean isBestShovel(ItemStack stack){
    	Item item = stack.getItem();
    	if(!(item instanceof ItemSpade))
    		return false;
    	float value = getToolEffect(stack);
    	for (int i = 9; i < 45; i++) {
            if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                if(getToolEffect(is) > value && is.getItem() instanceof ItemSpade){                	
                	return false;
                }
                	
            }
        }
    	return true;
    }
    private boolean isBestAxe(ItemStack stack){
    	Item item = stack.getItem();
    	if(!(item instanceof ItemAxe))
    		return false;
    	float value = getToolEffect(stack);
    	for (int i = 9; i < 45; i++) {
            if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                if(getToolEffect(is) > value && is.getItem() instanceof ItemAxe && !isBestWeapon(stack)){                
                	return false;
                }
                	
            }
        }
    	return true;
    }
    private float getToolEffect(ItemStack stack){
    	Item item = stack.getItem();
    	if(!(item instanceof ItemTool))
    		return 0;
    	String name = item.getUnlocalizedName();
    	ItemTool tool = (ItemTool)item;
    	float value = 1;
    	if(item instanceof ItemPickaxe){
    		value = tool.getStrVsBlock(stack, Blocks.stone);
    		if(name.toLowerCase().contains("gold")){
    			value -= 5;
    		}
    	}else if(item instanceof ItemSpade){
    		value = tool.getStrVsBlock(stack, Blocks.dirt);
    		if(name.toLowerCase().contains("gold")){
    			value -= 5;
    		}
    	}else if(item instanceof ItemAxe){
    		value = tool.getStrVsBlock(stack, Blocks.log);
    		if(name.toLowerCase().contains("gold")){
    			value -= 5;
    		}
    	}else
    		return 1f;
		value += EnchantmentHelper.getEnchantmentLevel(Enchantment.efficiency.effectId, stack) * 0.0075D;
		value += EnchantmentHelper.getEnchantmentLevel(Enchantment.unbreaking.effectId, stack)/100d;
    	return value;
    }
    private boolean isBadPotion(ItemStack stack) {
        if (stack != null && stack.getItem() instanceof ItemPotion) {
            final ItemPotion potion = (ItemPotion) stack.getItem();
            if(potion.getEffects(stack) == null)
            	return true;
            for (final Object o : potion.getEffects(stack)) {
                final PotionEffect effect = (PotionEffect) o;
                if (effect.getPotionID() == Potion.poison.getId() || effect.getPotionID() == Potion.harm.getId() || effect.getPotionID() == Potion.moveSlowdown.getId() || effect.getPotionID() == Potion.weakness.getId()) {
                	return true;
                }
            }
        }
        return false;
    }
    boolean invContainsType(int type){
    	
    	for(int i = 9; i < 45; i++){
    		if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
				ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
				Item item = is.getItem();
				if(item instanceof ItemArmor){
					ItemArmor armor = (ItemArmor)item;
					if(type == armor.armorType){
						return true;
					}	
				}
    		}
    	}
    	return false;
    }
    public void getBestArmor(){
    	for(int type = 1; type < 5; type++){
    		if(mc.thePlayer.inventoryContainer.getSlot(4 + type).getHasStack()){
    			ItemStack is = mc.thePlayer.inventoryContainer.getSlot(4 + type).getStack();
    			if(AutoArmor.isBestArmor(is, type)){
    				continue;
    			}else{
    				drop(4 + type);
    			}
    		}
    		for (int i = 9; i < 45; i++) {
    			if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
    				ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
    				if(AutoArmor.isBestArmor(is, type) && AutoArmor.getProtection(is) > 0){
    					shiftClick(i);
    					timer.reset();
    					if(((Number)this.DELAY.getValue()).longValue() > 0)
    						return;
    				}
    			}
            }
        }
    }
    enum SBMODE {
		Basic, OpenInv
	}
}
