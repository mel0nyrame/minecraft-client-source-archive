/*
 * Decompiled with CFR 0_132.
 */
package CopySense.module.player;

import java.awt.Color;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.api.value.Option;
import CopySense.api.value.Value;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.ui.Notification.Notification;
import CopySense.ui.Notification.NotificationManager;
import CopySense.ui.Notification.NotificationType;
import CopySense.utils.Helper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.EnumChatFormatting;



public class NoFall
extends Module {
    public Mode nofallmode;
    private int hypixel;
    float lastFall;
    int times;
    boolean showed;
    
    public NoFall() {
        super("NoFall", new String[] { "NoFall" }, ModuleType.Player);
        this.nofallmode = new Mode("Mode", "Mode", NoFallMode.values(), NoFallMode.NCP);
        this.setColor(new Color(242, 137, 73).getRGB());
        super.addValues(this.nofallmode);
    }
    @EventHandler
    private void onPreUpdate(final EventPreUpdate e) {
    }
    
    @EventHandler
    private void onUpdate(final EventPreUpdate e) {
        super.setSuffix(this.nofallmode.getValue());
        final Minecraft mc = NoFall.mc;
        final NetworkManager var1 = Minecraft.thePlayer.sendQueue.getNetworkManager();
        final Minecraft mc2 = NoFall.mc;
        final Double curX = Minecraft.thePlayer.posX;
        final Minecraft mc3 = NoFall.mc;
        final Double curY = Minecraft.thePlayer.posY;
        final Minecraft mc4 = NoFall.mc;
        final Double curZ = Minecraft.thePlayer.posZ;
        if (this.nofallmode.getValue() == NoFallMode.NCP) {
            if (this.times < 5) {
                final Minecraft mc24 = NoFall.mc;
                if (Minecraft.thePlayer.fallDistance - this.lastFall >= 3.0f && isBlockUnder()) {
                    final Minecraft mc25 = NoFall.mc;
                    this.lastFall = Minecraft.thePlayer.fallDistance;
                    final NetworkManager networkManager = var1;
                    final double doubleValue = curX;
                    final double doubleValue2 = curY;
                    final double doubleValue3 = curZ;
                    final Minecraft mc26 = NoFall.mc;
                    final float rotationYaw = Minecraft.thePlayer.rotationYaw;
                    final Minecraft mc27 = NoFall.mc;
                    networkManager.sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(doubleValue, doubleValue2, doubleValue3, rotationYaw, Minecraft.thePlayer.rotationPitch, true));
                    ++this.times;
                }
                else {
                    final Minecraft mc28 = NoFall.mc;
                    if (Minecraft.thePlayer.isCollidedVertically) {
                        this.lastFall = 0.0f;
                        this.times = 0;
                        this.showed = false;
                    }
                }
            }
            else if (!this.showed) {
                NotificationManager.show(new Notification(NotificationType.DISABLE,"Caveat:To prevent being banned by the server, NoFall has stopped working!","Nofall",1)); 
                this.showed = true;
            }
        }
        else if (this.nofallmode.getValue() == NoFallMode.SpoofGround) {
            e.setOnground(true);
        }
    }
    
    public static boolean isBlockUnder() {
        final Minecraft mc = NoFall.mc;
        if (Minecraft.thePlayer.posY < 0.0) {
            return false;
        }
        int off = 0;
        while (true) {
            final int n = off;
            final Minecraft mc2 = NoFall.mc;
            if (n >= (int)Minecraft.thePlayer.posY + 2) {
                return false;
            }
            final Minecraft mc3 = NoFall.mc;
            final AxisAlignedBB bb = Minecraft.thePlayer.boundingBox.offset(0.0, -off, 0.0);
            final Minecraft mc4 = NoFall.mc;
            final WorldClient theWorld = Minecraft.theWorld;
            final Minecraft mc5 = NoFall.mc;
            if (!theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, bb).isEmpty()) {
                return true;
            }
            off += 2;
        }
    }
    
    public enum NoFallMode
    {
        NCP, 
        SpoofGround
    }
}

