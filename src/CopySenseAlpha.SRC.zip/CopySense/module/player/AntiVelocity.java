/*
 * Decompiled with CFR 0_132.
 */
package CopySense.module.player;

import CopySense.Client;
import CopySense.api.EventHandler;
import CopySense.api.events.world.EventPacketRecieve;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.movement.Fly;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S27PacketExplosion;




public class AntiVelocity extends Module {
    public Mode<Enum> mode = new Mode("Mode", "mode", (Enum[])AvMode.values(), (Enum)AvMode.Basic );
    private Numbers<Double> HORIZONTAL = new Numbers<Double>("Horizontal", "Horizontal", 0.0, 0.0, 100.0, 5.0);
    private Numbers<Double> VERTICAL = new Numbers<Double>("Vertical", "Vertical", 0.0, 0.0, 100.0, 5.0);

    public AntiVelocity() {
        super("Velocity", new String[] { "antivelocity", "antiknockback", "antikb" }, ModuleType.Move);
        this.addValues(this.VERTICAL, this.mode, this.HORIZONTAL);
    }
    double count = 0;
    @Override
    public void onEnable() {
        super.onEnable();
        count = 0;
    }

    @EventHandler
    private void onPacket(EventPacketRecieve e) {
        this.setSuffix("H:"+this.HORIZONTAL.getValue() + " V:"+this.VERTICAL.getValue());
        if (e.getPacket() instanceof S12PacketEntityVelocity || e.getPacket() instanceof S27PacketExplosion) {
            if (this.HORIZONTAL.getValue() != (0.0) && this.VERTICAL.getValue() != (0.0) ) {
                e.setCancelled(true);
            } else {
                EventPacketRecieve ep = (EventPacketRecieve) e;
                Packet p = ep.getPacket();
                S12PacketEntityVelocity packet1 = (S12PacketEntityVelocity) p;
                int entId = packet1.getEntityID();
                Fly Fly = (Fly) Client.instance.getModuleManager().getModuleByClass(Fly.class);
                if (entId == mc.thePlayer.getEntityId()  && Fly.isEnabled() == false) {
                    double x = this.VERTICAL.getValue();
                    double z = this.HORIZONTAL.getValue();
                    if(this.mode.getValue() ==AvMode.AACPush) {
                        if(x != 0.0 && z != 0.0){
                            count = 10;
                            packet1.motionX = (int)(this.HORIZONTAL.getValue() /1000);
                            packet1.motionZ = (int)(this.HORIZONTAL.getValue() /1000);

                        }
                    }else if(this.mode.getValue() == AvMode.Basic) {
                        Double vertical = this.HORIZONTAL.getValue();
                        Double horizontal =  this.VERTICAL.getValue();
                        if (vertical != 0.0 || horizontal != 0.0) {
                            packet1.setMotX((int) (horizontal * packet1.getMotionX() / 100));
                            packet1.setMotY((int) (vertical * packet1.getMotionY() / 100));
                            packet1.setMotZ((int) (horizontal * packet1.getMotionZ() / 100));
                        } else {
                            ep.setCancelled(true);
                        }
                    }else if(this.mode.getValue() == AvMode.AACFlag) {
                        if(x != 0 && z != 0){

                            C04PacketPlayerPosition pack = new C04PacketPlayerPosition(mc.thePlayer.posX, Double.NaN, mc.thePlayer.posZ, true);
                            mc.thePlayer.sendQueue.addToSendQueue(pack);
                            ep.setCancelled(true);

                        }
                    }else{
                        S12PacketEntityVelocity packet = (S12PacketEntityVelocity)e.getPacket();
                        packet1.motionX = (int)(this.HORIZONTAL.getValue() + this.VERTICAL.getValue() / 100.0);
                        packet1.motionY = (int)(this.HORIZONTAL.getValue() + this.VERTICAL.getValue() / 100.0);
                        packet1.motionZ = (int)(this.HORIZONTAL.getValue() + this.VERTICAL.getValue() / 100.0);

                    }
                }else {
                    S12PacketEntityVelocity packet = (S12PacketEntityVelocity)e.getPacket();
                    packet1.motionX = (int)(this.HORIZONTAL.getValue() + this.VERTICAL.getValue() / 100.0);
                    packet1.motionY = (int)(this.HORIZONTAL.getValue() + this.VERTICAL.getValue() / 100.0);
                    packet1.motionZ = (int)(this.HORIZONTAL.getValue() + this.VERTICAL.getValue() / 100.0);
                }
            }
        }
    }
    public static enum AvMode {
        Basic,
        AACPush,
        AACFlag,

    }
}




