package CopySense.module.player;

import CopySense.api.EventHandler;
import CopySense.api.events.misc.EventChat;
import CopySense.api.value.Mode;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.render.TargetHUD;
import net.minecraft.client.Minecraft;

public class PlayerChat
extends Module {
    private Mode<Enum> mode = new Mode("GGMode", "GGMode", (Enum[]) PlayerChat.GGMode.values(), (Enum) PlayerChat.GGMode.None);
    public PlayerChat() {
        super("PlayerChat", new String[]{"player","chat","playerchat"}, ModuleType.Player);
        this.addValues(this.mode);
    }

@EventHandler
private void onChat(EventChat e) {
  if (e.getMessage().contains("胜利") || e.getMessage().contains("获胜") || e.getMessage().contains("Victory")) {
      if(this.mode.getValue()==GGMode.None){
      }
      if(this.mode.getValue()==GGMode.GG) {
          Minecraft.thePlayer.sendChatMessage("gg");
      }
      if(this.mode.getValue()==GGMode.GoodGame){
          Minecraft.thePlayer.sendChatMessage("Good Game");
      }
      if(this.mode.getValue()==GGMode.Ban){
          Minecraft.thePlayer.sendChatMessage("Fire Speed Ban Me");
      }
    }
}
enum GGMode {
       None, GG, GoodGame, Ban
}
  }


