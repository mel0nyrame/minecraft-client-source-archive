package CopySense.module.world;

import java.util.Random;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.utils.TimeHelper;
import CopySense.utils.TimerUtil;

public class Spammer extends Module{
	TimeHelper delay = new TimeHelper();
	private TimerUtil time = new TimerUtil();
	private Numbers<Double> spammerdelay = new Numbers<Double>("spammerdelay", "spammerdelay", 1.0, 0.0, 20.0, 0.5);
	private Mode<Enum> mode = new Mode("Mode", "mode", (Enum[])SpammerMode.values(), (Enum)SpammerMode.cxkEra);
	public Spammer() {
		super("Spammer", new String[]{"Spammer", "Spammer"}, ModuleType.World);
		this.addValues(this.spammerdelay , this.mode);
	}
	Random r = new Random();
	@EventHandler
	public void onUpdate(EventPreUpdate event) {
		Random r = new Random();
	      if(this.delay.isDelayComplete(((Double)this.spammerdelay.getValue()).longValue() * 1000L)) {
	    	  if(this.mode.getValue() == SpammerMode.Era){
	    	  mc.thePlayer.sendChatMessage("�㻹��Ϊ�����Ʈ���������㻹��Ϊ����Ҵ���������ŭ�Ҽ�������Ҫ���龪����Ȥ�Ŀյ�����Ҫ����ӵ���Ȥ�ļ���������EraWorld��������û����ң�û����ң���Ⱥ���ɽ���878565245"+"    >" + r.nextInt(346262) + "<");
	    	  }
	      else
		  	  if(this.mode.getValue() == SpammerMode.cxkEra){
		  		 mc.thePlayer.sendChatMessage("CopySense Hack Client , Buy Leain at Leain.maikama.cn");
		  		 mc.thePlayer.sendChatMessage("/pc CopySense Hack Client ,  at Leain.maikama.cn");
		  		mc.thePlayer.sendChatMessage("/gc CopySense Hack Client is code By MC_xiafeng_233 , Buy Leain at Leain.maikama.cn");
		  	  }
	    	  delay.reset();
	      }

	   }
	@Override
    public void onDisable() {
        super.onDisable();
       
    }
    public void onEnable() {
    	super.isEnabled();

    }
    private enum SpammerMode{
    	Era,
    	cxkEra,
    }
}
//
