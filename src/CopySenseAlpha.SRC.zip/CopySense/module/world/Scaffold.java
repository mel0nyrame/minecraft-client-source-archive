package CopySense.module.world;

import CopySense.api.EventHandler;
import CopySense.api.events.rendering.EventRender2D;
import CopySense.api.events.rendering.EventRender3D;
import CopySense.api.events.world.EventPostUpdate;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Option;
import CopySense.management.ModuleManager;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.movement.Speed;
import CopySense.ui.font.CFontRenderer;
import CopySense.ui.font.FontLoaders;
import CopySense.utils.BlockUtil;
import CopySense.utils.InventoryUtils;
import CopySense.utils.RenderUtils;
import CopySense.utils.RotationUtils;
import CopySense.utils.math.RotationUtil;
import CopySense.utils.render.Colors;
import CopySense.utils.render.RenderUtil;

import java.awt.Color;
import java.util.Arrays;
import java.util.List;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockCarpet;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.BlockSkull;
import net.minecraft.block.BlockSnow;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class Scaffold extends Module {
    private float[] rotations;
   public static Option silent = new Option("Silent", "Silent", Boolean.valueOf(true));
   private Option<Boolean> swing = new Option<Boolean>("Swing","Swing",false);
   public static Option shake = new Option("AutoShake", "AutoShake", Boolean.valueOf(false));
    public Option<Boolean> pick = new Option<Boolean>("pick", "pick", true);
   public Option<Boolean> sprint = new Option<Boolean>("KeepSprint", "KeepSprint", false);
    public Option<Boolean> counter = new Option<Boolean>("Counter", "Counter", false);
   public static Mode<Enum> espmode = new Mode("BoxMode", "BoxMode", (Enum[])espMode.values(), (Enum)espMode.none);
    public static Mode<Enum> rotmode = new Mode("RotMode", "RotMode", (Enum[])ScMode.values(), (Enum)ScMode.Basic);
    public static List<Block> blacklistedBlocks = Arrays.asList(Blocks.air, Blocks.water, Blocks.flowing_water, Blocks.lava, Blocks.flowing_lava, Blocks.ender_chest, Blocks.enchanting_table, Blocks.stone_button, Blocks.wooden_button, Blocks.crafting_table, Blocks.beacon);
    private static List invalid;
   private List<Block> blacklist;
   public static BlockCache blockCache;
   private int currentItem;
    private BlockData blockData;
   private int width=0;
    private static  List<Block> blacklistedBlocks2 = Arrays.asList(
    Blocks.air, Blocks.water, Blocks.flowing_water, Blocks.lava, Blocks.flowing_lava,
    Blocks.enchanting_table, Blocks.carpet, Blocks.glass_pane, Blocks.stained_glass_pane, Blocks.iron_bars,
    Blocks.snow_layer, Blocks.ice, Blocks.packed_ice, Blocks.coal_ore, Blocks.diamond_ore, Blocks.emerald_ore,
    Blocks.chest, Blocks.trapped_chest, Blocks.torch, Blocks.anvil, Blocks.trapped_chest, Blocks.noteblock, Blocks.jukebox, Blocks.tnt,
    Blocks.gold_ore, Blocks.iron_ore, Blocks.lapis_ore, Blocks.lit_redstone_ore, Blocks.quartz_ore, Blocks.redstone_ore,
    Blocks.wooden_pressure_plate, Blocks.stone_pressure_plate, Blocks.light_weighted_pressure_plate, Blocks.heavy_weighted_pressure_plate,
    Blocks.stone_button, Blocks.wooden_button, Blocks.lever, Blocks.tallgrass, Blocks.tripwire, Blocks.tripwire_hook, Blocks.rail, Blocks.waterlily,
    Blocks.red_flower, Blocks.red_mushroom, Blocks.brown_mushroom, Blocks.vine, Blocks.trapdoor, Blocks.yellow_flower, Blocks.ladder, Blocks.furnace,
    Blocks.sand, Blocks.cactus, Blocks.dispenser, Blocks.noteblock, Blocks.dropper, Blocks.crafting_table, Blocks.web, Blocks.pumpkin, Blocks.sapling, Blocks.cobblestone_wall, Blocks.oak_fence);

    float keepYawRender,keepPitchRender;

    public Scaffold() {
      super("Scaffold", new String[]{"magiccarpet", "blockplacer", "airwalk"}, ModuleType.World);
      this.blacklist = Arrays.asList(Blocks.air, Blocks.water, Blocks.torch, Blocks.redstone_torch, Blocks.ladder, Blocks.flowing_water, Blocks.lava, Blocks.flowing_lava, Blocks.enchanting_table, Blocks.carpet, Blocks.glass_pane, Blocks.stained_glass_pane, Blocks.iron_bars, Blocks.chest, Blocks.torch, Blocks.anvil, Blocks.web, Blocks.redstone_torch, Blocks.brewing_stand, Blocks.waterlily, Blocks.farmland, Blocks.sand, Blocks.beacon);
      this.invalid = Arrays.asList(new Block[]{Blocks.air, Blocks.water, Blocks.fire, Blocks.flowing_water, Blocks.lava, Blocks.flowing_lava, Blocks.chest, Blocks.enchanting_table, Blocks.tnt});
      this.addValues(this.rotmode,this.espmode,this.shake, this.silent ,this.swing,this.sprint,this.pick, this.counter);
      this.currentItem = 0;
   }

   public void onEnable() {
      this.currentItem = this.mc.thePlayer.inventory.currentItem;
      super.onEnable();
       keepYawRender = mc.thePlayer.rotationYaw;
       keepPitchRender = mc.thePlayer.rotationPitch;
   }

    public static List<Block> getBlacklistedBlocks() {
        return blacklistedBlocks2;
    }

   public void onDisable() {
      this.mc.thePlayer.inventory.currentItem = this.currentItem;
      KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
      super.onDisable();
   }
   @EventHandler
   private void render(EventRender2D e) {
       ItemStack stack = mc.thePlayer.inventory.getStackInSlot(InventoryUtils.findAutoBlockBlock() - 36);
       if (this.counter.getValue()) {
           CFontRenderer font = FontLoaders.kiona18;
           ScaledResolution res = new ScaledResolution(mc);
           int color = Colors.getColor(255, 0, 0);
           if (this.getBlockCount() > 64 && 256 > this.getBlockCount()) {
               color = Colors.getColor(255, 255, 0);
           } else if (this.getBlockCount() > 256) {
               color = Colors.getColor(0, 255, 0);
           }
           if (this.getBlockCount() >= 100 && this.getBlockCount() < 1000) {
               this.width = 7;
           }
           if (this.getBlockCount() >= 10 && this.getBlockCount() < 100) {
               this.width = 5;
           }
           if (this.getBlockCount() >= 0 && this.getBlockCount() < 10) {
               this.width = 3;
           }
           font.drawStringWithShadow(""+this.getBlockCount(),(res.getScaledWidth() / 2 - font.getStringWidth(""+this.getBlockCount()) / 2),(res.getScaledHeight() / 2 - font.getHeight() / 2)+20, color);
          if(this.getBlockCount()!=0) {
              GlStateManager.pushMatrix();
              RenderHelper.enableGUIStandardItemLighting();
              Minecraft.getMinecraft().getRenderItem().renderItemIntoGUI(stack, res.getScaledWidth() / 2 - 30, (res.getScaledHeight() / 2) + 12);
              RenderHelper.disableStandardItemLighting();
              GlStateManager.popMatrix();
          }
       }
   }
@EventHandler
private void render(EventRender3D e) {
	if(this.espmode.getValue()==espMode.none) {
		
	}
	if(this.espmode.getValue()==espMode.Zeroday) {
        Color color = new Color(Colors.BLACK.c);
        Color color2 = new Color(Colors.ORANGE.c);
        double x = mc.thePlayer.lastTickPosX + (mc.thePlayer.posX - mc.thePlayer.lastTickPosX) * this.mc.timer.renderPartialTicks - RenderManager.renderPosX;
        double y = mc.thePlayer.lastTickPosY + (mc.thePlayer.posY - mc.thePlayer.lastTickPosY) * this.mc.timer.renderPartialTicks - RenderManager.renderPosY;
        double z = mc.thePlayer.lastTickPosZ + (mc.thePlayer.posZ - mc.thePlayer.lastTickPosZ) * this.mc.timer.renderPartialTicks - RenderManager.renderPosZ;
        double x2 = mc.thePlayer.lastTickPosX + (mc.thePlayer.posX - mc.thePlayer.lastTickPosX) * this.mc.timer.renderPartialTicks - RenderManager.renderPosX;
        double y2 = mc.thePlayer.lastTickPosY + (mc.thePlayer.posY - mc.thePlayer.lastTickPosY) * this.mc.timer.renderPartialTicks - RenderManager.renderPosY;
        double z2 = mc.thePlayer.lastTickPosZ + (mc.thePlayer.posZ - mc.thePlayer.lastTickPosZ) * this.mc.timer.renderPartialTicks - RenderManager.renderPosZ;
        x -= 0.65;
        z -= 0.65;
        x2 -= 0.5;
        z2 -= 0.5;
        y += mc.thePlayer.getEyeHeight() + 0.35 - (mc.thePlayer.isSneaking() ? 0.25 : 0.0);
        GL11.glPushMatrix();
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        final double rotAdd = -0.25 * (Math.abs(mc.thePlayer.rotationPitch) / 90.0f);
        GL11.glDisable(3553);
        GL11.glEnable(2848);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glColor4f(color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, 1.0f);
        GL11.glLineWidth(2.0f);
        RenderUtil.drawOutlinedBoundingBox(new AxisAlignedBB(x, y - 2, z, x + 1.3, y - 2, z + 1.3));
        RenderUtil.drawOutlinedBoundingBox(new AxisAlignedBB(x2, y - 2, z2, x2 + 1, y - 2, z2 + 1));
        if (this.mc.gameSettings.keyBindJump.pressed || ModuleManager.getModuleByClass(Speed.class).isEnabled() && Minecraft.getMinecraft().thePlayer.moveForward != 0) {
            GL11.glColor4f(color2.getRed() / 255.0f, color2.getGreen() / 255.0f, color2.getBlue() / 255.0f, 1.0f);
            RenderUtil.drawOutlinedBoundingBox(new AxisAlignedBB(x, y - 2, z, x + 1.3, y - 2, z + 1.3));
        }
        GL11.glDisable(2848);
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glPopMatrix();
    }
	if(this.espmode.getValue()==espMode.Sigma) {
            mc.entityRenderer.setupCameraTransform(mc.timer.renderPartialTicks, 10);
        	BlockPos place = BlockCache.position;
        	EnumFacing face = BlockCache.facing;
        	double x1 = place.getX() - RenderManager.renderPosX;
        	double x2 = place.getX() - RenderManager.renderPosX + 1;
        	double y1 = place.getY() - RenderManager.renderPosY ;
        	double y2 = place.getY() - RenderManager.renderPosY + 1;
        	double z1 = place.getZ() - RenderManager.renderPosZ;
        	double z2 = place.getZ() - RenderManager.renderPosZ + 1;
        	y1 += face.getFrontOffsetY();
        	if(face.getFrontOffsetX() < 0){
        		x2 += face.getFrontOffsetX();
        	}else{
        		x1 += face.getFrontOffsetX();
        	}
        	if(face.getFrontOffsetZ() < 0){
            	z2 += face.getFrontOffsetZ();
        	}else{
            	z1 += face.getFrontOffsetZ();
        	}
        	if(place!=null||face!=null||place!=null&&face!=null) {
            GL11.glPushMatrix();
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            GL11.glShadeModel(GL11.GL_SMOOTH);
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glEnable(GL11.GL_LINE_SMOOTH);
            GL11.glDisable(GL11.GL_DEPTH_TEST);
            GL11.glDisable(GL11.GL_LIGHTING);
            GL11.glDepthMask(false);
            GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
            RenderUtil.drawBoundingBox(new AxisAlignedBB(x1, y1, z1, x2, y2, z2));
            GL11.glDepthMask(true);
            GL11.glEnable(GL11.GL_DEPTH_TEST);
            GL11.glDisable(GL11.GL_LINE_SMOOTH);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
            GL11.glDisable(GL11.GL_BLEND);
            GL11.glPopMatrix();
            GL11.glColor4f(1, 1, 1, 1);
            }
    }
        }
	public Block getBlockUnderPlayer(EntityPlayer player) {
		return getBlock(new BlockPos(player.posX , player.posY - 1.0d, player.posZ));
	}
	public Block getBlock(BlockPos pos) {
		return mc.theWorld.getBlockState(pos).getBlock();
	}

   @EventHandler
   private void onUpdate(EventPreUpdate event) {
        this.setSuffix(this.rotmode.getValue());
	   if(((Boolean) this.shake.getValue()).booleanValue()) {
	   if(getBlockUnderPlayer(mc.thePlayer) instanceof BlockAir) {
			if(mc.thePlayer.onGround) {
				KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), true);
			}
		} else {
			if(mc.thePlayer.onGround) {
				KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
			}
		}
	   }
	   this.setSuffix(this.rotmode.getValue());
      if(((Boolean)this.sprint.getValue()).booleanValue()) {
         this.mc.thePlayer.setSprinting(true);
      } else {
          Minecraft.getMinecraft().thePlayer.setSprinting(false);
      }
      double x = mc.thePlayer.posX;
      double y = mc.thePlayer.posY - 1;
      double z = mc.thePlayer.posZ;
      if(this.rotmode.getValue()==ScMode.Basic){
      if(this.grabBlockSlot() != -1) {
          this.setRotation(this.getRotationFromPosition(BlockData.position.getX(), BlockData.position.getZ(), BlockData.position.getY())[0], RotationUtil.getRotationFromPosition(BlockData.position.getX(), BlockData.position.getY(), BlockData.position.getZ())[1]);
          this.blockCache = this.grab();
          if (this.blockCache != null) {
              Minecraft.getMinecraft().thePlayer.rotationYawHead = BlockData.position.getZ();
              Minecraft.getMinecraft().thePlayer.renderYawOffset = BlockData.position.getY();
          }
      }
      }
      if(this.rotmode.getValue()==ScMode.FastLagger){
      if(this.grabBlockSlot() != -1) {
          this.blockCache = this.grab();
          if (this.blockCache != null) {
              final float[] rotations = RotationUtil.getRotationBlock(BlockData.position);
              event.setYaw(rotations[0]);
              event.setPitch(rotations[1]);
              final Minecraft mc9 = Scaffold.mc;
              Minecraft.thePlayer.rotationYawHead = rotations[0];
              final Minecraft mc10 = Scaffold.mc;
              Minecraft.thePlayer.rotationPitchHead = rotations[1];
         }
      }
      }
      if (this.invCheck()) { 
          int i = 9;
          while (i < 36) {
              Item item;
              if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack() && (item = mc.thePlayer.inventoryContainer.getSlot(i).getStack().getItem()) instanceof ItemBlock && !invalid.contains(((ItemBlock)item).getBlock()) && !((ItemBlock)item).getBlock().getLocalizedName().toLowerCase().contains("chest")) {
                  this.swap(i, 7);
                  break;
              }
              ++i;
          }
        }
      if (this.invCheck()) {
      	return;
      }

      BlockPos underPos = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ);
      Block underBlock = mc.theWorld.getBlockState(underPos).getBlock();
      BlockData data = getBlockData(underPos,blacklistedBlocks);
       BlockPos blockBelow = new BlockPos(x, y, z);
       if (Minecraft.thePlayer != null) {
           this.blockData = this.getBlockData(blockBelow, blacklistedBlocks);
           if (this.blockData == null) {
               this.blockData = this.getBlockData(blockBelow.offset(EnumFacing.DOWN), blacklistedBlocks);
           }
           if (Minecraft.theWorld.getBlockState(blockBelow = new BlockPos(x, y, z)).getBlock() == Blocks.air) {
               if (this.blockData != null) {
                   event.setPitch(87.0f);
               }
           }
       }
   }

    public static float[] getRotationFromPosition(double x, double z, double y) {
        double xDiff = x - Minecraft.getMinecraft().thePlayer.posX;
        double zDiff = z - Minecraft.getMinecraft().thePlayer.posZ;
        double yDiff = y - Minecraft.getMinecraft().thePlayer.posY - 1.2;

        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float) (Math.atan2(zDiff, xDiff) * 180.0D / 3.141592653589793D) - 90.0F;
        float pitch = (float) -(Math.atan2(yDiff, dist) * 180.0D / 3.141592653589793D);
        return new float[]{yaw, pitch};
    }

    public static void setRotation(final float yaw, final float pitch) {
        Minecraft.getMinecraft();
        Minecraft.thePlayer.rotationYawHead = yaw;
        Minecraft.getMinecraft();
        final EntityPlayerSP thePlayer = Minecraft.thePlayer;
        Minecraft.thePlayer.rotationPitchHead = pitch;
        Minecraft.getMinecraft();
        Minecraft.thePlayer.renderYawOffset = yaw;
    }

    private static class BlockData {
        public static BlockPos position;
        public static EnumFacing face;

        public BlockData(BlockPos position, EnumFacing face, BlockData blockData) {
            BlockData.position = position;
            BlockData.face = face;
        }

        private BlockPos getPosition() {
            return position;
        }

        private EnumFacing getFacing() {
            return face;
        }

        static BlockPos access$0(BlockData var0) {
            return var0.getPosition();
        }

        static EnumFacing access$1(BlockData var0) {
            return var0.getFacing();
        }

        static BlockPos access$2(BlockData var0) {
            return position;
        }

        static EnumFacing access$3(BlockData var0) {
            return face;
        }
    }

   private boolean isPosSolid(BlockPos pos) {
       Block block = mc.theWorld.getBlockState(pos).getBlock();
       if ((block.getMaterial().isSolid() || !block.isTranslucent() || block.isSolidFullCube() || block instanceof BlockLadder || block instanceof BlockCarpet
               || block instanceof BlockSnow || block instanceof BlockSkull)
               && !block.getMaterial().isLiquid() && !(block instanceof BlockContainer)) {
           return true;
       }
       return false;
   }
   public boolean isAirBlock(Block block) {
       if (block.getMaterial().isReplaceable()) {
           if (block instanceof BlockSnow && block.getBlockBoundsMaxY() > 0.125) {
               return false;
           }
           return true;
       }

       return false;
   }
   @EventHandler
   private void onPostUpdate(EventPostUpdate event) {
       BlockPos underPos = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1, mc.thePlayer.posZ);
       BlockData data = getBlockData(underPos,blacklistedBlocks);
       Block underBlock = mc.theWorld.getBlockState(underPos).getBlock();
	   if(this.blockCache != null) {
         int currentSlot = this.mc.thePlayer.inventory.currentItem;
         int slot = this.grabBlockSlot();
         this.mc.thePlayer.inventory.currentItem = slot;
         if(this.placeBlock(BlockCache.access$2(this.blockCache), BlockCache.access$3(this.blockCache))) {
            if(((Boolean)this.silent.getValue()).booleanValue()) {
               this.mc.thePlayer.inventory.currentItem = currentSlot;
               this.mc.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(currentSlot));
            }
            getBestBlocks();
            this.blockCache = null;
         }

      }
   }
   public void getBestBlocks(){
   	
	 	if(getBlockCount() == 0)
   		return;
	 	if(pick.getValue()){
	 		ItemStack is = new ItemStack(Item.getItemById(261));
	    	int bestInvSlot = getBiggestBlockSlotInv();
	    	int bestHotbarSlot = getBiggestBlockSlotHotbar();
	    	int bestSlot = getBiggestBlockSlotHotbar() > 0 ? getBiggestBlockSlotHotbar() : getBiggestBlockSlotInv();
	    	int spoofSlot = 42;
	    	if(bestHotbarSlot > 0 && bestInvSlot > 0){
	    		if (mc.thePlayer.inventoryContainer.getSlot(bestInvSlot).getHasStack() && mc.thePlayer.inventoryContainer.getSlot(bestHotbarSlot).getHasStack() ) {
	    			if(mc.thePlayer.inventoryContainer.getSlot(bestHotbarSlot).getStack().stackSize < mc.thePlayer.inventoryContainer.getSlot(bestInvSlot).getStack().stackSize){
	    				bestSlot = bestInvSlot;
	    			}
	    		}
	    	}
	    	if(hotbarContainBlock()){
	    		for (int a = 36; a < 45; a++) {       		
	        		if (mc.thePlayer.inventoryContainer.getSlot(a).getHasStack()) {
	        			Item item = mc.thePlayer.inventoryContainer.getSlot(a).getStack().getItem();
	                    if(item instanceof ItemBlock && isValid(item)){
	                    	spoofSlot = a;
	                        break;
	                    }
	                }
	            }
	    	}else{
	    		for (int a = 36; a < 45; a++) {       		
	        		if (!mc.thePlayer.inventoryContainer.getSlot(a).getHasStack()) {
	        			spoofSlot = a;
	                    break;
	                }
	            }
	    	}
	    	
	    	if (mc.thePlayer.inventoryContainer.getSlot(spoofSlot).slotNumber != bestSlot) {
	    	   	
	    		swap(bestSlot, spoofSlot - 36);
	    		mc.playerController.updateController();
	    		
	    	
	    	}
	 	}else{
	 		if (invCheck()) {

               ItemStack is = new ItemStack(Item.getItemById(261));
               for (int i = 9; i < 36; i++) {

                   if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                       Item item = mc.thePlayer.inventoryContainer.getSlot(i).getStack().getItem();
                       int count = 0;
                       if (item instanceof ItemBlock && isValid(item)) {
                           for (int a = 36; a < 45; a++) {
                               if (mc.thePlayer.inventoryContainer.canAddItemToSlot(mc.thePlayer.inventoryContainer.getSlot(a), is, true)) {
                               	
                               	swap(i, a - 36);
                                   count++;
                                   break;
                               }
                           }

                           if (count == 0) {
                           	
                               swap(i, 7);
                           }
                           break;

                       }
                   }
               }
           }
	 	}     
   }

   private boolean invCheck() {
       for (int i = 36; i < 45; i++) {
           if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
               Item item = mc.thePlayer.inventoryContainer.getSlot(i).getStack().getItem();
               if (item instanceof ItemBlock && isValid(item)) {
                   return false;
               }
           }
       }
       return true;
   }

protected void swap(int slot, int hotbarNum) {
       mc.playerController.windowClick(mc.thePlayer.inventoryContainer.windowId, slot, hotbarNum,2, mc.thePlayer);
   }

private static boolean isValid(Item item) {
       if (!(item instanceof ItemBlock)) {
           return false;
       } else {
           ItemBlock iBlock = (ItemBlock) item;
           Block block = iBlock.getBlock();
           if (invalid.contains(block)) {
               return false;
           }
       }
       return true;
   }

private boolean hotbarContainBlock() {
       int i = 36;

       while (i < 45) {
           try {
               ItemStack stack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
               if ((stack == null) || (stack.getItem() == null) || !(stack.getItem() instanceof ItemBlock) || !isValid(stack.getItem())) {
                   i++;
                   continue;
               }
               return true;
           } catch (Exception e) {

           }
       }

       return false;
   }

public int getBiggestBlockSlotHotbar(){
   	int slot = -1;
   	int size = 0;
   	if(getBlockCount() == 0)
   		return - 1;
   	   for (int i = 36; i < 45; i++) {
              if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                  Item item = mc.thePlayer.inventoryContainer.getSlot(i).getStack().getItem();
                  ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                  if (item instanceof ItemBlock && isValid(item)) {             	 
               	   if(is.stackSize > size){
               		   size = is.stackSize;
               		   slot = i;
               	   }
                  }
              }
          }
   	return slot;
   }

public int getBiggestBlockSlotInv(){
   	int slot = -1;
   	int size = 0;
   	if(getBlockCount() == 0)
   		return - 1;
   	   for (int i = 9; i < 36; i++) {
              if (mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) {
                  Item item = mc.thePlayer.inventoryContainer.getSlot(i).getStack().getItem();
                  ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
                  if (item instanceof ItemBlock && isValid(item)) {             	 
               	   if(is.stackSize > size){
               		   size = is.stackSize;
               		   slot = i;
               	   }
                  }
              }
          }
   	return slot;
   }

public void tower( EventPostUpdate event) {

   }
   private boolean placeBlock(BlockPos pos, EnumFacing facing) {
      new Vec3(this.mc.thePlayer.posX, this.mc.thePlayer.posY + (double)this.mc.thePlayer.getEyeHeight(), this.mc.thePlayer.posZ);
      if(this.mc.playerController.onPlayerRightClick(this.mc.thePlayer, this.mc.theWorld, this.mc.thePlayer.getHeldItem(), pos, facing, (new Vec3(BlockCache.access$2(this.blockCache))).addVector(0.5D, 0.5D, 0.5D).add((new Vec3(BlockCache.access$3(this.blockCache).getDirectionVec())).scale(0.5D)))) {
         this.mc.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
         if(!this.swing.getValue().booleanValue()) {
         	   mc.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
            } else {
         	   this.mc.thePlayer.swingItem();
            }
         return true;
      } else {
         return false;
      }

   }

   private Vec3 grabPosition(BlockPos position, EnumFacing facing) {
      Vec3 offset = new Vec3((double)facing.getDirectionVec().getX() / 2.0D, (double)facing.getDirectionVec().getY() / 2.0D, (double)facing.getDirectionVec().getZ() / 2.0D);
      Vec3 point = new Vec3((double)position.getX() + 0.5D, (double)position.getY() + 0.5D, (double)position.getZ() + 0.5D);
      return point.add(offset);
   }
   public static float[] getRotations(BlockPos block, EnumFacing face) {
       double x = (double)block.getX() + 0.5 - Minecraft.thePlayer.posX + (double)face.getFrontOffsetX() / 2.0;
       double z = (double)block.getZ() + 0.5 - Minecraft.thePlayer.posZ + (double)face.getFrontOffsetZ() / 2.0;
       double y = (double)block.getY() + 0.5;
       double d1 = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight() - y;
       double d3 = MathHelper.sqrt_double(x * x + z * z);
       float yaw = (float)(Math.atan2(z, x) * 180.0 / 3.141592653589793) - 90.0f;
       float pitch = (float)(Math.atan2(d1, d3) * 180.0 / 3.141592653589793);
       if (yaw < 0.0f) {
           yaw += 360.0f;
       }
       return new float[]{yaw, pitch};
   }
   private BlockCache grab() {
      EnumFacing[] invert = new EnumFacing[]{EnumFacing.UP, EnumFacing.DOWN, EnumFacing.SOUTH, EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.WEST};
      BlockPos position = (new BlockPos(this.mc.thePlayer.getPositionVector())).offset(EnumFacing.DOWN);
      if(!(this.mc.theWorld.getBlockState(position).getBlock() instanceof BlockAir)) {
         return null;
      } else {
         EnumFacing[] var6;
         int var5 = (var6 = EnumFacing.values()).length;

         for(int offset = 0; offset < var5; ++offset) {
            EnumFacing offsets = var6[offset];
            BlockPos offset1 = position.offset(offsets);
            this.mc.theWorld.getBlockState(offset1);
            if(!(this.mc.theWorld.getBlockState(offset1).getBlock() instanceof BlockAir)) {
               return new BlockCache(this, offset1, invert[offsets.ordinal()], (BlockCache)null);
            }
         }

         BlockPos[] var16;
         BlockPos[] var19 = var16 = new BlockPos[]{new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1), new BlockPos(1, 0, 0)};
         int var18 = var16.length;
         var5 = 0;
         while (var5 < var18) {
             BlockPos var17 = var19[var5];
             BlockPos offsetPos = position.add(var17.getX(), 0, var17.getZ());
             if (Minecraft.theWorld.getBlockState(offsetPos).getBlock() instanceof BlockAir) {
                 EnumFacing[] var13 = EnumFacing.values();
                 int var12 = var13.length;
                 int var11 = 0;
                 while (var11 < var12) {
                     EnumFacing facing2 = var13[var11];
                     BlockPos offset2 = offsetPos.offset(facing2);
                     Minecraft.theWorld.getBlockState(offset2);
                     if (!(Minecraft.theWorld.getBlockState(offset2).getBlock() instanceof BlockAir)) {
                         return new BlockCache(this, offset2, invert[facing2.ordinal()], null);
                     }
                     ++var11;
                 }
             }
             ++var5;
         }

         return null;
      }
   }
    /*
     * Enabled aggressive block sorting
     */
    private BlockData getBlockData(BlockPos pos, List list) {
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(pos.add(0, -1, 0)).getBlock())) {
            return new BlockData(pos.add(0, -1, 0), EnumFacing.UP, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(pos.add(-1, 0, 0)).getBlock())) {
            EnumFacing enumFacing;
            BlockPos blockPos = pos.add(-1, 0, 0);
            if (Keyboard.isKeyDown((int)29)) {
                if (Minecraft.thePlayer.onGround) {
                    if (Minecraft.thePlayer.fallDistance == 0.0f) {
                        if (Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ)).getBlock() == Blocks.air) {
                            enumFacing = EnumFacing.DOWN;
                            return new BlockData(blockPos, enumFacing, this.blockData);
                        }
                    }
                }
            }
            enumFacing = EnumFacing.EAST;
            return new BlockData(blockPos, enumFacing, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(pos.add(1, 0, 0)).getBlock())) {
            EnumFacing enumFacing;
            BlockPos blockPos = pos.add(1, 0, 0);
            if (Keyboard.isKeyDown((int)29)) {
                if (Minecraft.thePlayer.onGround) {
                    if (Minecraft.thePlayer.fallDistance == 0.0f) {
                        if (Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ)).getBlock() == Blocks.air) {
                            enumFacing = EnumFacing.DOWN;
                            return new BlockData(blockPos, enumFacing, this.blockData);
                        }
                    }
                }
            }
            enumFacing = EnumFacing.WEST;
            return new BlockData(blockPos, enumFacing, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(pos.add(0, 0, -1)).getBlock())) {
            EnumFacing enumFacing;
            BlockPos blockPos = pos.add(0, 0, -1);
            if (Keyboard.isKeyDown((int)29)) {
                if (Minecraft.thePlayer.onGround) {
                    if (Minecraft.thePlayer.fallDistance == 0.0f) {
                        if (Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ)).getBlock() == Blocks.air) {
                            enumFacing = EnumFacing.DOWN;
                            return new BlockData(blockPos, enumFacing, this.blockData);
                        }
                    }
                }
            }
            enumFacing = EnumFacing.SOUTH;
            return new BlockData(blockPos, enumFacing, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(pos.add(0, 0, 1)).getBlock())) {
            EnumFacing enumFacing;
            BlockPos blockPos = pos.add(0, 0, 1);
            if (Keyboard.isKeyDown((int)29)) {
                if (Minecraft.thePlayer.onGround) {
                    if (Minecraft.thePlayer.fallDistance == 0.0f) {
                        if (Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ)).getBlock() == Blocks.air) {
                            enumFacing = EnumFacing.DOWN;
                            return new BlockData(blockPos, enumFacing, this.blockData);
                        }
                    }
                }
            }
            enumFacing = EnumFacing.NORTH;
            return new BlockData(blockPos, enumFacing, this.blockData);
        }
        BlockPos add = pos.add(-1, 0, 0);

        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add.add(-1, 0, 0)).getBlock())) {
            return new BlockData(add.add(-1, 0, 0), EnumFacing.EAST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add.add(1, 0, 0)).getBlock())) {
            return new BlockData(add.add(1, 0, 0), EnumFacing.WEST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add.add(0, 0, -1)).getBlock())) {
            return new BlockData(add.add(0, 0, -1), EnumFacing.SOUTH, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add.add(0, 0, 1)).getBlock())) {
            return new BlockData(add.add(0, 0, 1), EnumFacing.NORTH, this.blockData);
        }
        BlockPos add2 = pos.add(1, 0, 0);
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add2.add(-1, 0, 0)).getBlock())) {
            return new BlockData(add2.add(-1, 0, 0), EnumFacing.EAST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add2.add(1, 0, 0)).getBlock())) {
            return new BlockData(add2.add(1, 0, 0), EnumFacing.WEST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add2.add(0, 0, -1)).getBlock())) {
            return new BlockData(add2.add(0, 0, -1), EnumFacing.SOUTH, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add2.add(0, 0, 1)).getBlock())) {
            return new BlockData(add2.add(0, 0, 1), EnumFacing.NORTH, this.blockData);
        }
        BlockPos add3 = pos.add(0, 0, -1);
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add3.add(-1, 0, 0)).getBlock())) {
            return new BlockData(add3.add(-1, 0, 0), EnumFacing.EAST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add3.add(1, 0, 0)).getBlock())) {
            return new BlockData(add3.add(1, 0, 0), EnumFacing.WEST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add3.add(0, 0, -1)).getBlock())) {
            return new BlockData(add3.add(0, 0, -1), EnumFacing.SOUTH, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add3.add(0, 0, 1)).getBlock())) {
            return new BlockData(add3.add(0, 0, 1), EnumFacing.NORTH, this.blockData);
        }
        BlockPos add4 = pos.add(0, 0, 1);
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add4.add(-1, 0, 0)).getBlock())) {
            return new BlockData(add4.add(-1, 0, 0), EnumFacing.EAST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add4.add(1, 0, 0)).getBlock())) {
            return new BlockData(add4.add(1, 0, 0), EnumFacing.WEST, this.blockData);
        }
        if (!blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add4.add(0, 0, -1)).getBlock())) {
            return new BlockData(add4.add(0, 0, -1), EnumFacing.SOUTH, this.blockData);
        }
        if (blacklistedBlocks.contains(Minecraft.theWorld.getBlockState(add4.add(0, 0, 1)).getBlock())) return null;
        return new BlockData(add4.add(0, 0, 1), EnumFacing.NORTH, this.blockData);
    }

   private int grabBlockSlot() {
      for(int i = 0; i < 9; ++i) {
         ItemStack itemStack = this.mc.thePlayer.inventory.mainInventory[i];
         if(itemStack != null && itemStack.getItem() instanceof ItemBlock) {
            return i;
         }
      }

      return -1;
   }
   public int getBlockCount() {
	    int blockCount = 0;
	    for (int i = 0; i < 45; ++i) {
	        if (!Scaffold.mc.thePlayer.inventoryContainer.getSlot(i).getHasStack()) continue;
	        ItemStack is = Scaffold.mc.thePlayer.inventoryContainer.getSlot(i).getStack();
	        Item item = is.getItem();
	        if (!(is.getItem() instanceof ItemBlock) || this.blacklist.contains(((ItemBlock)item).getBlock())) continue;
	        blockCount += is.stackSize;
	    }
	    return blockCount;
	}
}

enum espMode{
	   none,
	   Zeroday,
	   Sigma
}
enum ScMode{
    Basic, FastLagger
}
class BlockCache {
	   static BlockPos position;
	   static EnumFacing facing;
	   final Scaffold this$0;

	   private BlockCache(Scaffold var1, BlockPos position, EnumFacing facing) {
	      this.this$0 = var1;
	      this.position = position;
	      this.facing = facing;
	   }

	   private BlockPos getPosition() {
	      return this.position;
	   }

	   private EnumFacing getFacing() {
	      return this.facing;
	   }

	   static BlockPos access$0(BlockCache var0) {
	      return var0.getPosition();
	   }

	   static EnumFacing access$1(BlockCache var0) {
	      return var0.getFacing();
	   }

	   static BlockPos access$2(BlockCache var0) {
	      return var0.position;
	   }

	   static EnumFacing access$3(BlockCache var0) {
	      return var0.facing;
	   }

	   BlockCache(Scaffold var1, BlockPos var2, EnumFacing var3, BlockCache var4) {
	      this(var1, var2, var3);
	   }
	}
