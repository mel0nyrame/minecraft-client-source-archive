/*
 * Decompiled with CFR 0_132.
 */
package CopySense.module.world;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventTick;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import java.awt.Color;
import net.minecraft.client.Minecraft;

public class FastPlace
extends Module {
    public FastPlace() {
        super("FastPlace", new String[]{"fplace", "fc"}, ModuleType.World);
        this.setColor(new Color(226, 197, 78).getRGB());
    }

    @EventHandler
    private void onTick(EventTick e) {
        this.mc.rightClickDelayTimer = 0;
    }
}

