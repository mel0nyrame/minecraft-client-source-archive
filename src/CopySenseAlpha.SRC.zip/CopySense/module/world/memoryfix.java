package CopySense.module.world;

import CopySense.module.Module;
import CopySense.module.ModuleType;

public class memoryfix extends Module{

	public memoryfix() {
		super("MemoryFix", new String[] {"memoryfix"}, ModuleType.World);
	}
	@Override
	public void onEnable() {
		Runtime.getRuntime().gc();
		super.onEnable();
	}

}
