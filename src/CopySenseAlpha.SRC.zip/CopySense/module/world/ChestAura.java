
package CopySense.module.world;

import CopySense.Client;
import CopySense.api.EventHandler;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Numbers;
import CopySense.api.value.Option;
import CopySense.api.value.Value;
import CopySense.management.ModuleManager;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.combat.KillAura;
import CopySense.utils.CombatUtil;
import CopySense.utils.TimerUtil;
import java.util.ArrayList;
import java.util.Iterator;

import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockChest;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import net.minecraft.util.Vec3i;

public class ChestAura
extends Module {
    private ArrayList<BlockPos> pos = new ArrayList();
    private TimerUtil timer = new TimerUtil();
    public static BlockPos lastBlock;
    private BlockPos blockCorner;
    private Numbers<Double> delay = new Numbers<Double>("Delay", "delay", 100.0, 0.0, 1000.0, 10.0);
    private Numbers<Double> reach = new Numbers<Double>("Reach", "Reach", 4.0, 1.0, 7.0, 0.1);
    private Option<Boolean> raytrace = new Option<Boolean>("rayTrace", "rayTrace", true);
    public ChestAura() {
        super("ChestAura", new String[]{"ChestAura"}, ModuleType.World);
        this.addValues(this.delay,this.reach,this.raytrace);
    }

    @EventHandler
    private void onUpdate(EventPreUpdate event) {
    	getNextChest();
    	if (lastBlock != null) {
            if (this.mc.thePlayer.getDistance(lastBlock.getX(), lastBlock.getY(), lastBlock.getZ()) > this.reach.getValue()) {
                lastBlock = null;
            }
            if (this.mc.currentScreen instanceof GuiChest) {
                this.pos.add(lastBlock);
                lastBlock = null;
            }
        }
        if (lastBlock == null) {
            this.blockCorner = null;
        }
        if (this.mc.currentScreen == null && this.isAllowed()) {
            BlockPos chest;
            BlockPos blockPos = chest = lastBlock != null ? lastBlock : this.getNextChest();
            if (chest != null && this.blockCorner != null) {
                float[] rot = CombatUtil.getRotationsNeededBlock(chest.getX(), chest.getY(), chest.getZ());
                event.yaw = rot[0];
                event.pitch = rot[1];
                if (this.timer.isDelayComplete(this.delay.getValue().intValue())) {
                    this.mc.thePlayer.swingItem();
                    this.mc.playerController.onPlayerRightClick(this.mc.thePlayer, this.mc.theWorld, this.mc.thePlayer.getHeldItem(), chest, EnumFacing.DOWN, new Vec3(this.mc.thePlayer.posX, this.mc.thePlayer.posY, this.mc.thePlayer.posZ));
                    this.timer.reset();
                    lastBlock = chest;
                }
            }
        }
    }

    private boolean isAllowed() {
        return !ModuleManager.getModuleByName("KillKillAura").isEnabled() || KillAura.curTarget == null;
    }

    private BlockPos getNextChest() {
        Iterator<BlockPos> positions = BlockPos.getAllInBox(this.mc.thePlayer.getPosition().subtract(new Vec3i(this.reach.getValue(), this.reach.getValue(), this.reach.getValue())), this.mc.thePlayer.getPosition().add(new Vec3i(this.reach.getValue(), this.reach.getValue(), this.reach.getValue()))).iterator();
        BlockPos chestPos = null;
        while ((chestPos = positions.next()) != null) {
            BlockPos corner;
            if (!(this.mc.theWorld.getBlockState(chestPos.add(0, 1, 0)).getBlock() instanceof BlockAir) || !(this.mc.theWorld.getBlockState(chestPos).getBlock() instanceof BlockChest) || this.pos.contains(chestPos)) continue;
            BlockPos blockPos = corner = this.raytrace.getValue() == false ? chestPos : Client.getBlockCorner(new BlockPos(this.mc.thePlayer.posX, this.mc.thePlayer.posY + (double)this.mc.thePlayer.getEyeHeight(), this.mc.thePlayer.posZ), chestPos);
            if (corner == null) continue;
            this.blockCorner = corner;
            return chestPos;
        }
        return null;
    }
}

