/*
 * Decompiled with CFR 0_132.
 */
package CopySense.module.world;

import java.awt.Color;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventTick;
import CopySense.api.value.Numbers;
import CopySense.api.value.Option;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.utils.TimerUtil;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.item.ItemStack;

public class ChestStealer
		extends Module {
	private Numbers<Double> delay = new Numbers<Double>("Delay", "delay", 50.0, 0.0, 1000.0, 10.0);
	public static Option<Boolean> chestText = new Option<Boolean>("ChestText","ChestText",false);
	private TimerUtil timer = new TimerUtil();

	public ChestStealer() {
		super("ChestStealer", new String[]{"cheststeal", "chests", "stealer"}, ModuleType.World);
		this.addValues(this.delay,this.chestText);
		this.setColor(new Color(218, 97, 127).getRGB());
	}

	@EventHandler
	private void onUpdate(EventTick event) {
		if (this.mc.thePlayer.openContainer != null && this.mc.thePlayer.openContainer instanceof ContainerChest) {
			ContainerChest container = (ContainerChest)this.mc.thePlayer.openContainer;
			int i = 0;
			while (i < container.getLowerChestInventory().getSizeInventory()) {
				if (container.getLowerChestInventory().getStackInSlot(i) != null && this.timer.hasReached(this.delay.getValue())) {
					this.mc.playerController.windowClick(container.windowId, i, 0, 1, this.mc.thePlayer);
					this.timer.reset();
				}
				++i;
			}
			if (this.isEmpty()) {
				this.mc.thePlayer.closeScreen();
			}
		}
	}

	private boolean isEmpty() {
		if (this.mc.thePlayer.openContainer != null && this.mc.thePlayer.openContainer instanceof ContainerChest) {
			ContainerChest container = (ContainerChest)this.mc.thePlayer.openContainer;
			int i = 0;
			while (i < container.getLowerChestInventory().getSizeInventory()) {
				ItemStack itemStack = container.getLowerChestInventory().getStackInSlot(i);
				if (itemStack != null && itemStack.getItem() != null) {
					return false;
				}
				++i;
			}
		}
		return true;
	}
}

