/*
 * Decompiled with CFR 0_132.
 */
package CopySense.module.combat;

import CopySense.Client;
import CopySense.api.EventHandler;
import CopySense.api.events.rendering.EventPostRenderPlayer;
import CopySense.api.events.world.EventPacketRecieve;
import CopySense.api.events.world.EventPacketSend;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.movement.Speed;
import CopySense.utils.TimerUtil;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;

public class Criticals
extends Module {
    public static Mode mode = new Mode("Mode", "Mode", (Enum[])CritMode.values(), (Enum)CritMode.Hypixel);
    private TimerUtil timer = new TimerUtil();
    TimerUtil timer2 = new TimerUtil();
    private static List<EntityPlayer> invalid = new ArrayList();
    private static List<EntityPlayer> removed = new ArrayList();
    public Criticals() {
        super("Criticals", new String[]{"crits", "crit"}, ModuleType.Combat);
        this.setColor(new Color(235, 194, 138).getRGB());       
        this.addValues(this.mode);
    }

    public void onEnable() {
        invalid.clear();
    }

    public void onDisable() {
        invalid.clear();
    }

    @EventHandler
    private void onUpdate(EventPreUpdate e10) {
        this.setSuffix(this.mode.getValue());
    }

    private boolean canCrit() {
        return Minecraft.thePlayer.onGround && !Minecraft.thePlayer.isInWater() && !Client.getModuleManager().getModuleByClass(Speed.class).isEnabled();
    }

    void doPacket() {
            if (this.timer.hasTimeElapsed(50.0D, true) && mc.thePlayer.isSwingInProgress) {
                double offsets[] = { 0.04114514, 0.02114514, 0.0114514, 0.000114514 };
                Arrays.stream(offsets).forEach(offset -> mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + offset, mc.thePlayer.posZ, false)));
                this.timer.reset();
        }
    }

    @EventHandler
    private void onPacket(EventPacketSend e10) {
        double x = mc.thePlayer.posX;
        double y = mc.thePlayer.posY;
        double z = mc.thePlayer.posZ;
        if (e10.getPacket() instanceof C02PacketUseEntity && this.canCrit() && this.mode.getValue() == CritMode.Minijumps) {
            Minecraft.thePlayer.motionY = 0.5;
        }
    }

    @EventHandler
    public void onSendPacket(Entity e) {
        if(this.mode.getValue()==CritMode.Hypixel)
            mc.thePlayer.onCriticalHit(KillAura.curTarget);
    }
    void RemixCrits() {
    	if(mode.getValue() == CritMode.Vanilla && canCrit()) {
   	     if (this.timer.hasTimeElapsed(50.0D, true) && mc.thePlayer.isSwingInProgress && mc.thePlayer.onGround) {
  	       double[] offsets = { 0.0625D, 0.0D, 1.0E-4D, 0.0D };
  	       Arrays.stream(offsets).forEach(offset -> mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + offset, mc.thePlayer.posZ, false)));
  	       this.timer.reset();
  	     }
    	}
	   }
	   
    public static enum CritMode {
    	Hypixel,
        Minijumps,
        Vanilla,    
    }

}