package CopySense.module.combat;

import java.awt.Color;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import javax.vecmath.Vector2f;


import CopySense.AngleVector.Angle;
import CopySense.AngleVector.AngleUtility;
import CopySense.AngleVector.Vector3;
import CopySense.Client;
import CopySense.api.EventHandler;
import CopySense.api.events.rendering.EventRender3D;
import CopySense.api.events.world.EventMove;
import CopySense.api.events.world.EventPostUpdate;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.api.value.Option;
import CopySense.management.FriendManager;
import CopySense.management.ModuleManager;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.movement.Sprint;
import CopySense.module.render.HUD;
import CopySense.module.world.Scaffold;
import CopySense.utils.RotationUtils;
import CopySense.utils.Stopwatch;
import CopySense.utils.TimerUtil;
import CopySense.utils.math.MathUtil;
import CopySense.utils.render.RenderUtil;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.util.*;
import net.minecraft.world.WorldSettings;
import optifine.MathUtils;
import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;

public class KillAura
		extends Module {
	public static float yaw;
	public static float pitch;
	private boolean changeTarget;
	public static float rotationPitch;
	public ArrayList<EntityLivingBase> targets = new ArrayList();
	public static EntityLivingBase curTarget;
	public static EntityLivingBase lastTarget;
	private Mode<Enum> priority = new Mode("Priority", "Priority", (Enum[])Priority.values(), (Enum)Priority.Angle);
	public Mode<Enum> mode = new Mode("Mode", "Mode", (Enum[])AuraMode.values(), (Enum)AuraMode.Single);
	private Mode<Enum> espmode = new Mode("TargetESP", "TargetESP", (Enum[]) EMode.values(), (Enum) EMode.Box);
	private Mode<Enum> rotmode = new Mode("Rotation", "Rotation", (Enum[]) RMode.values(), (Enum) RMode.Basic);
	private Numbers<Double> switchdelay = new Numbers<Double>("switchdelay", "switchdelay", 10.0, 1.0, 1000.0, 25.0);
	private Numbers<Double> aps = new Numbers<Double>("MinCPS", "MinCPS", 12.0, 1.0, 20.0, 1.0);
	private Numbers<Double> maxaps = new Numbers<Double>("MaxCPS", "MaxCPS", 12.0, 1.0, 20.0, 1.0);
	public static Numbers<Double> reach;
	public Numbers<Double> blockreach = new Numbers<Double>("BlockReach", "BlockReach", 4.6, 1.0, 10.0, 0.1);
	public static Option<Boolean> blocking;
	public static Option<Boolean> Rot = new Option<Boolean>("Rotation", "Rotation", true);
	public Option<Boolean> players = new Option<Boolean>("Players", "Players", true);
	public Option<Boolean> animals = new Option<Boolean>("Animals", "Animals", false);
	public Option<Boolean> mobs = new Option<Boolean>("Mobs", "Mobs", false);
	private Option<Boolean> invis = new Option<Boolean>("Invisibles", "Invisibles", false);
	private static long lastMS;
	private final Stopwatch attackStopwatch = new Stopwatch();
	private TimerUtil timer = new TimerUtil();
	private TimerUtil switchTimer = new TimerUtil();
	private int targetIndex;
	public static float[] facing;
	public static boolean isSetup;
	private boolean changecurTarget;
	public boolean isBlock;
	float[] rot;
	static {
		curTarget = null;
		lastTarget = null;
		reach = new Numbers<Double>("Reach", "Reach", 4.6, 1.0, 6.0, 0.1);
		blocking = new Option<Boolean>("Autoblock", "Autoblock", true);
		isSetup = false;
	}


	public KillAura() {
		super("KillAura", new String[]{"ka", "KillAura", "killa"}, ModuleType.Combat);
		this.addValues(this.rotmode, this.priority, this.mode, this.espmode, this.maxaps, this.aps, this.switchdelay, reach, this.blockreach, Rot, blocking, this.players, this.animals, this.mobs, this.invis);
	}

	public KillAura(String name, String[] alias, ModuleType type) {
		super(name, alias, type);
	}

	public static boolean isSetupTick() {
		return isSetup;
	}

	public static double random(double min, double max) {
		Random random = new Random();
		return min + (double)((int)(random.nextDouble() * (max - min)));
	}

	private boolean canBlock() {
		if (Minecraft.thePlayer.getCurrentEquippedItem() != null) {
			if (Minecraft.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemSword && ((Boolean)blocking.getValue()).booleanValue()) {
				return true;
			}
		}
		return false;
	}

	public void drawESP(Entity entity, int color) {
		double x = entity.lastTickPosX
				+ (entity.posX - entity.lastTickPosX) * mc.timer.renderPartialTicks;

		double y = entity.lastTickPosY
				+ (entity.posY - entity.lastTickPosY) * mc.timer.renderPartialTicks + entity.getEyeHeight()*1.2;

		double z = entity.lastTickPosZ
				+ (entity.posZ - entity.lastTickPosZ) * mc.timer.renderPartialTicks;
		double width = Math.abs(entity.boundingBox.maxX - entity.boundingBox.minX) + 0.2;
		double height = 0.1;
		Vec3 vec = new Vec3(x - width/2, y, z - width/2);
		Vec3 vec2 = new Vec3(x + width/2, y + height, z + width/2);
		RenderUtil.pre3D();
		mc.entityRenderer.setupCameraTransform(mc.timer.renderPartialTicks, 2);
		this.glColor(color);
		RenderUtil.drawBoundingBox(new AxisAlignedBB(
				vec.xCoord - RenderManager.renderPosX, vec.yCoord - RenderManager.renderPosY, vec.zCoord - RenderManager.renderPosZ,
				vec2.xCoord - RenderManager.renderPosX, vec2.yCoord - RenderManager.renderPosY, vec2.zCoord - RenderManager.renderPosZ));
		GL11.glColor4f(0.0f, 0.0f, 0.0f, 1.0f);
		RenderUtil.post3D();
	}

	public static void glColor(int hex) {
		float alpha = (hex >> 24 & 0xFF) / 255.0F;
		float red = (hex >> 16 & 0xFF) / 255.0F;
		float green = (hex >> 8 & 0xFF) / 255.0F;
		float blue = (hex & 0xFF) / 255.0F;
		GL11.glColor4f(red, green, blue, alpha);
	}

	@EventHandler
	public void onRender(EventRender3D render) {
		if (KillAura.curTarget == null || this.espmode.getValue() == EMode.None) {
		}
		if (KillAura.curTarget != null && this.espmode.getValue() == EMode.Box) {
			this.mc.getRenderManager();
			double x = KillAura.curTarget.lastTickPosX
					+ (KillAura.curTarget.posX - KillAura.curTarget.lastTickPosX) * this.mc.timer.renderPartialTicks
					- RenderManager.renderPosX;
			this.mc.getRenderManager();
			double y = KillAura.curTarget.lastTickPosY
					+ (KillAura.curTarget.posY - KillAura.curTarget.lastTickPosY) * this.mc.timer.renderPartialTicks
					- RenderManager.renderPosY;
			this.mc.getRenderManager();
			double z = KillAura.curTarget.lastTickPosZ
					+ (KillAura.curTarget.posZ - KillAura.curTarget.lastTickPosZ) * this.mc.timer.renderPartialTicks
					- RenderManager.renderPosZ;
			if (KillAura.curTarget instanceof EntityPlayer) {
				final double width = KillAura.curTarget.getEntityBoundingBox().maxX
						- KillAura.curTarget.getEntityBoundingBox().minX;
				final double height = KillAura.curTarget.getEntityBoundingBox().maxY
						- KillAura.curTarget.getEntityBoundingBox().minY;
				final float red = 0;
				final float green = 111;
				final float blue = 255;
				final float alpha = 0.2f;
				this.drawEntityESP(x, y, z, width, height, red, green, blue, alpha);
			} else {
				final double width = KillAura.curTarget.getEntityBoundingBox().maxX
						- KillAura.curTarget.getEntityBoundingBox().minX;
				final double height = KillAura.curTarget.getEntityBoundingBox().maxY
						- KillAura.curTarget.getEntityBoundingBox().minY;
				final float red = 0;
				final float green = 111;
				final float blue = 255;
				final float alpha = 0.2f;
				this.drawEntityESP(x, y, z, width, height, red, green, blue, alpha);
			}
		}
		if (KillAura.curTarget != null && this.espmode.getValue() == EMode.HeightBox) {
			drawESP(curTarget,new Color(11,111,255).getRGB());
		}
		if (KillAura.curTarget != null && this.espmode.getValue() == EMode.Box2) {
			mc.getRenderManager();
			double x1 = curTarget.lastTickPosX
					+ (curTarget.posX - curTarget.lastTickPosX) * (double) mc.timer.renderPartialTicks
					- RenderManager.renderPosX;
			mc.getRenderManager();
			double y1 = curTarget.lastTickPosY
					+ (curTarget.posY - curTarget.lastTickPosY) * (double) mc.timer.renderPartialTicks
					- RenderManager.renderPosY;
			mc.getRenderManager();
			double z1 = curTarget.lastTickPosZ
					+ (curTarget.posZ - curTarget.lastTickPosZ) * (double) mc.timer.renderPartialTicks
					- RenderManager.renderPosZ;
			double width1;
			double height1;
			float red1;
			float green1;
			float blue1;
			float lineRed1;
			float lineGreen1;
			float lineBlue1;
			if (curTarget instanceof EntityPlayer) {
				width1 = curTarget.getEntityBoundingBox().maxX - curTarget.getEntityBoundingBox().minX - 0.35D;
				height1 = curTarget.getEntityBoundingBox().maxY - curTarget.getEntityBoundingBox().minY;
				red1 = curTarget.hurtTime > 0 ? 1.0F : 0.0F;
				green1 = curTarget.hurtTime > 0 ? 0.2F : 1.0F;
				blue1 = curTarget.hurtTime > 0 ? 0.0F : 0.2F;
				lineRed1 = curTarget.hurtTime > 0 ? 1.0F : 0.0F;
				lineGreen1 = curTarget.hurtTime > 0 ? 0.2F : 1.0F;
				lineBlue1 = curTarget.hurtTime > 0 ? 0.0F : 0.2F;
				RenderUtil.drawEntityESP(x1, y1, z1, width1, height1, red1, green1, blue1, 0.2F, lineRed1,
						lineGreen1, lineBlue1, 0.2F, 2.0F);
			} else {
				width1 = curTarget.getEntityBoundingBox().maxX - curTarget.getEntityBoundingBox().minX - 0.35D;
				height1 = curTarget.getEntityBoundingBox().maxY - curTarget.getEntityBoundingBox().minY;
				red1 = curTarget.hurtTime > 0 ? 1.0F : 0.0F;
				green1 = curTarget.hurtTime > 0 ? 0.2F : 1.0F;
				blue1 = curTarget.hurtTime > 0 ? 0.0F : 0.2F;
				lineRed1 = curTarget.hurtTime > 0 ? 1.0F : 0.0F;
				lineGreen1 = curTarget.hurtTime > 0 ? 0.2F : 1.0F;
				lineBlue1 = curTarget.hurtTime > 0 ? 0.0F : 0.2F;
				RenderUtil.drawEntityESP(x1, y1, z1, width1, height1, red1, green1, blue1, 0.2F, lineRed1,
						lineGreen1, lineBlue1, 0.2F, 2.0F);
			}
		}
	}

	public static void drawEntityESP(double x, double y, double z, double width, double height, float red, float green, float blue, float alpha) {
		GL11.glPushMatrix();
		GL11.glEnable((int)3042);
		GL11.glBlendFunc((int)770, (int)771);
		GL11.glDisable((int)3553);
		GL11.glEnable((int)2848);
		GL11.glDisable((int)2929);
		GL11.glDepthMask((boolean)false);
		GL11.glColor4f((float)red, (float)green, (float)blue, (float)alpha);
		RenderUtil.drawBoundingBox(new AxisAlignedBB(x - width, y, z - width, x + width, y + height, z + width));
		RenderUtil.drawOutlinedBoundingBox(new AxisAlignedBB(x - width, y, z - width, x + width, y + height, z + width));
		GL11.glDisable((int)2848);
		GL11.glEnable((int)3553);
		GL11.glEnable((int)2929);
		GL11.glDepthMask((boolean)true);
		GL11.glDisable((int)3042);
		GL11.glPopMatrix();
	}

	public final EntityLivingBase getcurTarget() {
		if (this.targets.isEmpty()) {
			return null;
		}
		if (this.mode.getValue() == AuraMode.Single) {
			return this.targets.get(0);
		}
		int size = this.targets.size();
		if (size >= this.targetIndex && this.changecurTarget) {
			++this.targetIndex;
			this.changecurTarget = false;
		}
		if (size <= this.targetIndex) {
			this.targetIndex = 0;
		}
		return this.targets.get(this.targetIndex);
	}

	public static long getCurrentMS() {
		return System.nanoTime() / 1000000L;
	}

	public static boolean hit(long milliseconds) {
		return KillAura.getCurrentMS() - lastMS >= milliseconds;
	}

	public static void revert() {
		lastMS = KillAura.getCurrentMS();
	}

	private void collectTargets() {
		this.targets.clear();
		for (Entity entity : Minecraft.thePlayer.getEntityWorld().loadedEntityList) {
			EntityLivingBase entityLivingBase;
			if (!(entity instanceof EntityLivingBase) || !this.isValidEntity(entityLivingBase = (EntityLivingBase)entity, true)) continue;
			this.targets.add(entityLivingBase);
		}
	}

	@EventHandler
	private void onUpdate(EventPreUpdate event) {
		this.setSuffix(this.mode.getValue());
		this.collectTargets();
		this.sortList(this.targets);
		if (this.switchTimer.hasReached((Double)this.switchdelay.getValue()) && this.mode.getValue() == AuraMode.Switch
				&& this.mc.thePlayer.ticksExisted % 10 == 0) {
			++this.targetIndex;
			this.switchTimer.reset();
		}
		if (this.targetIndex >= this.targets.size()) {
			this.targetIndex = 0;
		}
		EntityLivingBase entityLivingBase = curTarget = !this.targets.isEmpty() && this.targetIndex < this.targets.size() ? this.targets.get(this.targetIndex) : null;
		if (!this.canBlock()) {
			this.isBlock = false;
		}
		if (curTarget != null) {
			if (this.targetIndex >= this.targets.size()) {
				this.targetIndex = 0;
			}
			KillAura.curTarget = this.targets.get(this.targetIndex);
			if(this.rotmode.getValue()==RMode.Basic) {
				final float[] rotations = this.getRotationFormEntity(KillAura.curTarget);
				event.setYaw(rotations[0]);
				event.setPitch(rotations[1]);
				if (KillAura.Rot.getValue()) {
					this.setRotation(event.getYaw(), event.getPitch());
				}
			} if(this.rotmode.getValue()==RMode.Slowly) {
				float[] rotations = this.getSlowlyTarget(KillAura.curTarget);
				event.setYaw(rotations[0]);
				event.setPitch(rotations[1]);
				if(KillAura.Rot.getValue()){
					Minecraft.getMinecraft().thePlayer.rotationYawHead = rotations[0];
					Minecraft.getMinecraft().thePlayer.renderYawOffset = rotations[0];
				}
			}
			if (this.attackStopwatch.elapsed((long) (1000 / MathUtils.randomNumber(maxaps.getValue(), aps.getValue()))) && this.canBlock()) {
				this.unblock();
			}
		} else if (this.canBlock()) {
			this.unblock();
		}
	}

	public float[] getSlowlyTarget(Entity target) {
		double xDiff = target.posX - Minecraft.thePlayer.posX;
		double yDiff = target.posY - Minecraft.thePlayer.posY;
		double zDiff = target.posZ - Minecraft.thePlayer.posZ;
		float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / 3.141592653589793) - 90.0f;
		float pitch = (float)((- Math.atan2(target.posY + (double)target.getEyeHeight() / 0.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff))) * 180.0 / 3.141592653589793);
		if (yDiff > -0.2 && yDiff < 0.2) {
			pitch = (float)((- Math.atan2(target.posY + (double)target.getEyeHeight() / HitLocation.CHEST.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff))) * 180.0 / 3.141592653589793);
		} else if (yDiff > -0.2) {
			pitch = (float)((- Math.atan2(target.posY + (double)target.getEyeHeight() / HitLocation.FEET.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff))) * 180.0 / 3.141592653589793);
		} else if (yDiff < 0.3) {
			pitch = (float)((- Math.atan2(target.posY + (double)target.getEyeHeight() / HitLocation.HEAD.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff))) * 180.0 / 3.141592653589793);
		}
		return new float[]{yaw, pitch};
	}

	public static void setRotation(final float yaw, final float pitch) {
		Minecraft.getMinecraft();
		Minecraft.thePlayer.rotationYawHead = yaw;
		Minecraft.getMinecraft();
		final EntityPlayerSP thePlayer = Minecraft.thePlayer;
		Minecraft.thePlayer.rotationPitchHead = pitch;
		Minecraft.getMinecraft();
		Minecraft.thePlayer.renderYawOffset = yaw;
	}

	public float[] getRotationFormEntity(final EntityLivingBase target) {
		final AngleUtility angleUtility = new AngleUtility(6.0f, 60.0f, 3.0f, 30.0f);
		final Vector3<Double> enemyCoords = new Vector3<Double>(target.posX, target.posY, target.posZ);
		final Minecraft mc = KillAura.mc;
		final Double val = Minecraft.thePlayer.posX;
		final Minecraft mc2 = KillAura.mc;
		final Double val2 = Minecraft.thePlayer.posY;
		final Minecraft mc3 = KillAura.mc;
		final Vector3<Double> myCoords = new Vector3<Double>(val, val2, Minecraft.thePlayer.posZ);
		final Angle dstAngle = angleUtility.calculateAngle(enemyCoords, myCoords);
		final Angle smoothedAngle = angleUtility.smoothAngle(dstAngle, dstAngle);
		return new float[] { smoothedAngle.getYaw(), smoothedAngle.getPitch() };
	}

	public final EntityLivingBase getTarget() {
		if (this.targets.isEmpty()) {
			return null;
		}
		if (this.mode.getValue() == AuraMode.Single) {
			return this.targets.get(0);
		}
		int size = this.targets.size();
		if (size >= this.targetIndex && this.changeTarget) {
			++this.targetIndex;
			this.changeTarget = false;
		}
		if (size <= this.targetIndex) {
			this.targetIndex = 0;
		}
		return this.targets.get(this.targetIndex);
	}

	@EventHandler
	public void onPost(EventPostUpdate event) {
		if (curTarget != null && this.attackStopwatch.elapsed((long) (1000 / MathUtils.randomNumber(maxaps.getValue(), aps.getValue())))) {
			if (this.isValidEntity(curTarget, false)) {
				this.attack(curTarget);
			}
			this.attackStopwatch.reset();
		}
		if (curTarget != null && this.canBlock()) {
			this.block();
		}
		if (lastTarget == null && curTarget != null || lastTarget != null && curTarget != null && lastTarget != curTarget) {
			lastTarget = curTarget;
			if (this.canBlock()) {
				this.unblock();
			}
		} else if (curTarget == null) {
			lastTarget = null;
		}
	}

	private void block() {
		if (((Boolean)blocking.getValue()).booleanValue() && !KillAura.mc.gameSettings.keyBindUseItem.isPressed() && !this.isBlock) {
			Minecraft.thePlayer.itemInUseCount = Minecraft.thePlayer.getHeldItem().getMaxItemUseDuration();
			mc.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, Minecraft.thePlayer.inventory.getCurrentItem(), 0.0f, 0.0f, 0.0f));
			this.isBlock = true;
		}
	}

	private void unblock() {
		if (((Boolean)blocking.getValue()).booleanValue() && this.isBlock) {
			Minecraft.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
			Minecraft.thePlayer.clearItemInUse();
			this.isBlock = false;
		}
	}

	public float[] getEntityRotations(Entity target) {
		double xDiff = target.posX - Minecraft.thePlayer.posX;
		double yDiff = target.posY - Minecraft.thePlayer.posY;
		double zDiff = target.posZ - Minecraft.thePlayer.posZ;
		float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
		float pitch = (float)(-Math.atan2(target.posY + (double)target.getEyeHeight() / 0.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
		if (yDiff > -0.2 && yDiff < 0.2) {
			pitch = (float)(-Math.atan2(target.posY + (double)target.getEyeHeight() / HitLocation.CHEST.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
		} else if (yDiff > -0.2) {
			pitch = (float)(-Math.atan2(target.posY + (double)target.getEyeHeight() / HitLocation.FEET.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
		} else if (yDiff < 0.3) {
			pitch = (float)(-Math.atan2(target.posY + (double)target.getEyeHeight() / HitLocation.HEAD.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
		}
		return new float[]{yaw, pitch};
	}

	private static int randomNumber(double min, double max) {
		Random random = new Random();
		return (int)(min + random.nextDouble() * (max - min));
	}

	public static float[] getRotations(Entity entity) {
		Minecraft.getMinecraft();
		double xDiff = entity.posX - Minecraft.thePlayer.posX;
		double yDiff = entity.posY - Minecraft.thePlayer.posY;
		double zDiff = entity.posZ - Minecraft.thePlayer.posZ;
		MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
		float newYaw = (float)Math.toDegrees(-Math.atan(xDiff / zDiff));
		if (zDiff < 0.0 && xDiff < 0.0) {
			newYaw = (float)(90.0 + Math.toDegrees(Math.atan(zDiff / xDiff)));
		} else if (zDiff < 0.0 && xDiff > 0.0) {
			newYaw = (float)(-90.0 + Math.toDegrees(Math.atan(zDiff / xDiff)));
		}
		float newPitch = (float)(-Math.atan2(entity.posY + (double)entity.getEyeHeight() / 0.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
		if (yDiff >= -0.2 && yDiff <= 0.2) {
			newPitch = (float)(-Math.atan2(entity.posY + (double)entity.getEyeHeight() / HitLocation.CHEST.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
		} else if (yDiff > -0.2) {
			newPitch = (float)(-Math.atan2(entity.posY + (double)entity.getEyeHeight() / HitLocation.FEET.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
		} else if (yDiff < 0.2) {
			newPitch = (float)(-Math.atan2(entity.posY + (double)entity.getEyeHeight() / HitLocation.HEAD.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
		}
		return new float[]{newYaw, newPitch};
	}

	private void attack(final EntityLivingBase entity) {
		final Minecraft mc6 = KillAura.mc;
		Minecraft.thePlayer.swingItem();
		KillAura.mc.getNetHandler().addToSendQueue(new C02PacketUseEntity(entity, C02PacketUseEntity.Action.ATTACK));
		if(Criticals.mode.getValue()==Criticals.CritMode.Hypixel && ModuleManager.getModuleByClass(Criticals.class).isEnabled()) {
			double x = mc.thePlayer.posX;
			double y = mc.thePlayer.posY;
			double z = mc.thePlayer.posZ;
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.04132332, z, false));
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.023243243674, z, false));
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.01, z, false));
            mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.0011, z, false));
		}
	}

	private boolean isValidEntity(Entity ent, boolean blocking) {
		Client.instance.getModuleManager();
		AntiBot ab = (AntiBot)ModuleManager.getModuleByClass(AntiBot.class);
		if (ent == null) {
			return false;
		}
		if (ent == Minecraft.thePlayer) {
			return false;
		}
		if (ent instanceof EntityPlayer && !((Boolean)this.players.getValue()).booleanValue()) {
			return false;
		}
		if ((ent instanceof EntityAnimal || ent instanceof EntitySquid) && !((Boolean)this.animals.getValue()).booleanValue()) {
			return false;
		}
		if ((ent instanceof EntityMob || ent instanceof EntityVillager || ent instanceof EntityBat) && !((Boolean)this.mobs.getValue()).booleanValue()) {
			return false;
		}
		double d = Minecraft.thePlayer.getDistanceToEntity(ent);
		Double d2 = blocking ? (Double)this.blockreach.getValue() : (Double)reach.getValue();
		if (d > d2) {
			return false;
		}
		if (ent instanceof EntityPlayer && FriendManager.isFriend(ent.getName())) {
			return false;
		}
		if (ent.isDead) return false;
		if (!(((EntityLivingBase)ent).getHealth() > 0.0f)) return false;
		if (ent.isInvisible() && !((Boolean)this.invis.getValue()).booleanValue()) {
			return false;
		}
		if (AntiBot.isEntityBot(ent)) {
			return false;
		}
		if (Minecraft.thePlayer.isDead) return false;
		Client.instance.getModuleManager();
		return true;
	}

	public static boolean isOnSameTeam(Entity entity) {
		Client.instance.getModuleManager();
		if (!ModuleManager.getModuleByClass(KillAura.class).isEnabled()) {
			return false;
		}
		Minecraft.getMinecraft();
		if (Minecraft.thePlayer.getDisplayName().getUnformattedText().startsWith("\u00a7")) {
			Minecraft.getMinecraft();
			if (Minecraft.thePlayer.getDisplayName().getUnformattedText().length() <= 2 || entity.getDisplayName().getUnformattedText().length() <= 2) {
				return false;
			}
			Minecraft.getMinecraft();
			if (Minecraft.thePlayer.getDisplayName().getUnformattedText().substring(0, 2).equals(entity.getDisplayName().getUnformattedText().substring(0, 2))) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void onEnable() {
		curTarget = null;
		lastTarget = null;
		this.targetIndex = 0;
	}

	@Override
	public void onDisable() {
		if (this.canBlock()) {
			this.unblock();
		}
		curTarget = null;
		lastTarget = null;
	}

	public static float[] getRotationToEntity(Entity target) {
		Minecraft.getMinecraft();
		double xDiff = target.posX - Minecraft.thePlayer.posX;
		Minecraft.getMinecraft();
		double yDiff = target.posY - Minecraft.thePlayer.posY;
		Minecraft.getMinecraft();
		double zDiff = target.posZ - Minecraft.thePlayer.posZ;
		float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / Math.PI) - 90.0f;
		Minecraft.getMinecraft();
		Minecraft.getMinecraft();
		float pitch = (float)(-Math.atan2(target.posY + (double)target.getEyeHeight() / 0.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
		if (yDiff > -0.2 && yDiff < 0.2) {
			Minecraft.getMinecraft();
			Minecraft.getMinecraft();
			pitch = (float)(-Math.atan2(target.posY + (double)target.getEyeHeight() / HitLocation.CHEST.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
		} else if (yDiff > -0.2) {
			Minecraft.getMinecraft();
			Minecraft.getMinecraft();
			pitch = (float)(-Math.atan2(target.posY + (double)target.getEyeHeight() / HitLocation.FEET.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
		} else if (yDiff < 0.3) {
			Minecraft.getMinecraft();
			Minecraft.getMinecraft();
			pitch = (float)(-Math.atan2(target.posY + (double)target.getEyeHeight() / HitLocation.HEAD.getOffset() - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff)) * 180.0 / Math.PI);
		}
		return new float[]{yaw, pitch};
	}

	private void sortList(List<EntityLivingBase> weed) {
		if (this.priority.getValue() == Priority.Armor) {
			weed.sort(Comparator.comparingInt(o -> o instanceof EntityPlayer ? ((EntityPlayer)o).inventory.getTotalArmorValue() : (int)o.getHealth()));
		}
		if (this.priority.getValue() == Priority.Range) {
			weed.sort((o1, o2) -> (int)(o1.getDistanceToEntity(Minecraft.thePlayer) - o2.getDistanceToEntity(Minecraft.thePlayer)));
		}
		if (this.priority.getValue() == Priority.Fov) {
			weed.sort(Comparator.comparingDouble(o -> RotationUtils.getDistanceBetweenAngles(Minecraft.thePlayer.rotationPitch, KillAura.getRotationToEntity(o)[0])));
		}
		if (this.priority.getValue() == Priority.Angle) {
			weed.sort((o1, o2) -> {
				float[] rot1 = KillAura.getRotationToEntity(o1);
				float[] rot2 = KillAura.getRotationToEntity(o2);
				return (int)(Minecraft.thePlayer.rotationYaw - rot1[0] - (Minecraft.thePlayer.rotationYaw - rot2[0]));
			});
		}
		if (this.priority.getValue() == Priority.Health) {
			weed.sort((o1, o2) -> (int)(o1.getHealth() - o2.getHealth()));
		}
	}

	public static float getYawDifference(float current, float target) {
		float f = 0;
		float rot;
		float f2 = rot = 0.0f;
		rot = (target + 180.0f - current) % 360.0f;
		return f2 + (f > 0.0f ? -180.0f : 180.0f);
	}

	public static int[] getFractionIndicies(float[] fractions, float progress) {
		int startPoint;
		int[] range = new int[2];
		for (startPoint = 0; startPoint < fractions.length && fractions[startPoint] <= progress; ++startPoint) {
		}
		if (startPoint >= fractions.length) {
			startPoint = fractions.length - 1;
		}
		range[0] = startPoint - 1;
		range[1] = startPoint;
		return range;
	}

	public static Color blendColors(float[] fractions, Color[] colors, float progress) {
		Color color = null;
		if (fractions == null) {
			throw new IllegalArgumentException("Fractions can't be null");
		}
		if (colors == null) {
			throw new IllegalArgumentException("Colours can't be null");
		}
		if (fractions.length == colors.length) {
			int[] indicies = KillAura.getFractionIndicies(fractions, progress);
			float[] range = new float[]{fractions[indicies[0]], fractions[indicies[1]]};
			Color[] colorRange = new Color[]{colors[indicies[0]], colors[indicies[1]]};
			float max = range[1] - range[0];
			float value = progress - range[0];
			float weight = value / max;
			color = KillAura.blend(colorRange[0], colorRange[1], 1.0f - weight);
			return color;
		}
		throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
	}

	public static Color blend(Color color1, Color color2, double ratio) {
		float r = (float)ratio;
		float ir = 1.0f - r;
		float[] rgb1 = new float[3];
		float[] rgb2 = new float[3];
		color1.getColorComponents(rgb1);
		color2.getColorComponents(rgb2);
		float red = rgb1[0] * r + rgb2[0] * ir;
		float green = rgb1[1] * r + rgb2[1] * ir;
		float blue = rgb1[2] * r + rgb2[2] * ir;
		if (red < 0.0f) {
			red = 0.0f;
		} else if (red > 255.0f) {
			red = 255.0f;
		}
		if (green < 0.0f) {
			green = 0.0f;
		} else if (green > 255.0f) {
			green = 255.0f;
		}
		if (blue < 0.0f) {
			blue = 0.0f;
		} else if (blue > 255.0f) {
			blue = 255.0f;
		}
		Color color3 = null;
		try {
			color3 = new Color(red, green, blue);
		}
		catch (IllegalArgumentException exp) {
			NumberFormat nf = NumberFormat.getNumberInstance();
			System.out.println(String.valueOf(String.valueOf(nf.format(red))) + "; " + nf.format(green) + "; " + nf.format(blue));
			exp.printStackTrace();
		}
		return color3;
	}

	private double getIncremental(double val, double inc) {
		double one = 1.0 / inc;
		return (double)Math.round(val * one) / one;
	}

	static enum AuraMode {
		Switch,
		Single;
	}

	static enum HitLocation {
		AUTO(0.0),
		HEAD(1.0),
		CHEST(1.5),
		FEET(3.5);

		private double offset;

		private HitLocation(double offset) {
			this.offset = offset;
		}

		public double getOffset() {
			return this.offset;
		}
	}

	enum EMode{
		None, Box, Box2, HeightBox
	}
	enum RMode {
		Basic, Slowly
	}

	enum Priority {
		Range,
		Fov,
		Angle,
		Health,
		Armor;

	}
}

