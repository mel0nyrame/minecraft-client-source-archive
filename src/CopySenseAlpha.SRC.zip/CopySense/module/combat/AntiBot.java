package CopySense.module.combat;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventPacketRecieve;
import CopySense.api.events.world.EventTick;
import CopySense.api.value.Mode;
import CopySense.management.ModuleManager;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.utils.Helper;
import CopySense.utils.TimeHelper;
import CopySense.utils.TimerUtil;
import net.minecraft.entity.player.*;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S14PacketEntity;
import net.minecraft.client.*;
import net.minecraft.entity.*;

import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

import net.minecraft.client.network.*;
import net.minecraft.util.ClassInheritanceMultiMap;

public class AntiBot extends Module
{
    public static Mode option;
    public static ArrayList Bots = new ArrayList();
    public static ClassInheritanceMultiMap<Object> invalid;
    private TimerUtil timer;
    int bots;
    private List<Packet> packetList = new CopyOnWriteArrayList();
    public static ArrayList bot = new ArrayList();
    private static List removed = new ArrayList();
    public TimeHelper lastRemoved = new TimeHelper();

    public static List onAirInvalid = new ArrayList();

    public AntiBot() {
        super("AntiBot", new String[] { "nobot" }, ModuleType.Combat);
        this.values.add(option = new Mode("Mode", "Mode", AntiMode.values(), AntiMode.Hypixel));
        this.bots = 0;
        this.timer = new TimerUtil();
    }

    public boolean isServerBot(Entity entity) {
        if (this.isEnabled()) {
            if (Helper.onServer("hypixel")) {
                if (entity.getDisplayName().getFormattedText().startsWith("\u00a7") && !entity.isInvisible() && !entity.getDisplayName().getFormattedText().toLowerCase().contains("npc")) {
                    return false;
                }
                return true;
            }
            if (Helper.onServer("mineplex")) {
                for (Object object : this.mc.theWorld.playerEntities) {
                    EntityPlayer entityPlayer = (EntityPlayer)object;
                    if (entityPlayer == null || entityPlayer == this.mc.thePlayer || !entityPlayer.getName().startsWith("Body #") && entityPlayer.getMaxHealth() != 20.0f) continue;
                    return true;
                }
            }
        }
        return false;
    }

    @EventHandler
    public void onUpdate(EventTick event) {
        this.setSuffix(this.option.getValue());
        if (this.option.getValue() == AntiMode.Hypixel && mc.theWorld != null) {
            Minecraft mc2 = AntiBot.mc;
            Iterator var4 = mc.theWorld.loadedEntityList.iterator();
            label63: while (true) {
                Object entity2;
                EntityPlayer entityPlayer;
                EntityPlayer ent;
                do {
                    if (!var4.hasNext()) {
                        this.bots = 0;
                        var4 = mc.theWorld.getLoadedEntityList().iterator();

                        while (var4.hasNext()) {
                            Entity entity21 = (Entity) var4.next();
                            if (entity21 instanceof EntityPlayer) {
                                ent = entityPlayer = (EntityPlayer) entity21;
                                if (entityPlayer != mc.thePlayer && ent.isInvisible() && ent.ticksExisted > 105) {
                                    if (getPlayerList().contains(ent)) {
                                        if (ent.isInvisible()) {
                                            ent.setInvisible(false);
                                        }
                                    } else {
                                        ent.setInvisible(false);
                                        ++this.bots;
                                        mc.theWorld.removeEntity(ent);
                                    }
                                }
                            }
                        }
                        break label63;
                    }

                    entity2 = var4.next();
                } while (!(entity2 instanceof EntityPlayer));

                ent = entityPlayer = (EntityPlayer) entity2;
                if (entityPlayer != mc.thePlayer) {
                    Minecraft mc4 = AntiBot.mc;
                    if (mc.thePlayer.getDistanceToEntity(ent) < 10.0F
                            && (!ent.getDisplayName().getFormattedText().contains("§") || ent.isInvisible()
                            || ent.getDisplayName().getFormattedText().toLowerCase().contains("npc")
                            || ent.getDisplayName().getFormattedText().toLowerCase().contains("§r"))) {
                        Bots.add(ent);
                    }
                }

                if (Bots.contains(ent)) {
                    Bots.remove(ent);
                }
            }
        }
    }

    @EventHandler
    public void onReceivePacket(EventPacketRecieve event) {
        if (event.getPacket() instanceof S14PacketEntity) {
            S14PacketEntity packet = (S14PacketEntity) event.getPacket();
            Entity entity;
            if ((entity = packet.getEntity(mc.theWorld)) instanceof EntityPlayer && !packet.getOnGround()
                    && !onAirInvalid.contains(entity.getEntityId())) {
                onAirInvalid.add(entity.getEntityId());
            }
        }

    }

    public boolean isInGodMode(Entity entity) {
        return this.isEnabled() && this.option.getValue() == AntiMode.Hypixel && entity.ticksExisted <= 25;
    }

    public static boolean isEntityBot(Entity entity) {
        if (ModuleManager.getModuleByName("AntiBot").isEnabled()) {
            if (option.getValue() == AntiMode.Hypixel && Helper.onServer("hypixel")) {
                if (ModuleManager.getModuleByName("AntiBot").isEnabled() && option.getValue() == AntiMode.Hypixel) {
                    if (entity.getDisplayName().getFormattedText().startsWith("\u00a7")
                            && !entity.getDisplayName().getFormattedText().toLowerCase().contains("[npc")) {
                        return false;
                    }
                    return true;
                }
                return false;
            }

            if (option.getValue() == AntiMode.Mineplex) {
                Minecraft mc = AntiBot.mc;
                Iterator var4 = mc.theWorld.playerEntities.iterator();

                while (var4.hasNext()) {
                    Object object = var4.next();
                    EntityPlayer entityPlayer = (EntityPlayer) object;
                    if (entityPlayer != null) {
                        Minecraft mc2 = AntiBot.mc;
                        if (entityPlayer != mc.thePlayer && (entityPlayer.getName().startsWith("Body #")
                                || entityPlayer.getMaxHealth() == 20.0F)) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    public void onEnable() {
        Bots.clear();
    }

    public void onDisable() {
        Bots.clear();
    }

    public static boolean isInTablist(EntityPlayer player) {
        if (Minecraft.getMinecraft().isSingleplayer()) {
            return true;
        }
        for (NetworkPlayerInfo o : Minecraft.getMinecraft().getNetHandler().getPlayerInfoMap()) {
            NetworkPlayerInfo playerInfo = o;
            if (!playerInfo.getGameProfile().getName().equalsIgnoreCase(player.getName()))
                continue;
            return true;
        }
        return false;
    }

    public List<EntityPlayer> getPlayerList() {
        Minecraft.getMinecraft();
        Collection<NetworkPlayerInfo> playerInfoMap = mc.thePlayer.sendQueue.getPlayerInfoMap();
        ArrayList<EntityPlayer> list = new ArrayList<EntityPlayer>();
        for (NetworkPlayerInfo networkPlayerInfo : playerInfoMap) {
            list.add(Minecraft.getMinecraft().theWorld
                    .getPlayerEntityByName(networkPlayerInfo.getGameProfile().getName()));
        }
        return list;
    }

    enum AntiMode {
        Hypixel, Mineplex;
    }
}
