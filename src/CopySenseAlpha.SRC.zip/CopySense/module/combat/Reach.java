/*
 * Decompiled with CFR 0.136.
 */
package CopySense.module.combat;

import java.awt.Color;

import CopySense.api.value.Numbers;
import CopySense.module.Module;
import CopySense.module.ModuleType;

public class Reach
extends Module {
    public static boolean Reach;
    public static Numbers<Double> range;

    static {
        range = new Numbers<Double>("Range", "reach", 4.2, 0.1, 8.0, 0.1);
    }

    public Reach() {
        super("Reach", new String[]{"Reach", "Reach"}, ModuleType.Combat);
        this.setColor(new Color(217, 149, 251).getRGB());
        this.addValues(range);
    }
}

