package CopySense.module.combat;

import java.util.Random;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventTick;
import CopySense.api.value.Numbers;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.utils.Wrapper;
import CopySense.utils.math.Timer2;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import optifine.MathUtils;

public class AutoClicker extends Module{

	private Timer2 timer;
    private float delay;
	public AutoClicker() {
		super("AutoClicker" , new String[] {"AutoClicker"} , ModuleType.Combat);
		addValues(randomize,clickspersecond);
	}
	private Numbers<Double> randomize = new Numbers<Double>("randomize", "randomize",  1.2, 0.0, 5.0, 0.1);
	private Numbers<Double> clickspersecond = new Numbers<Double>("Cps", "Cps", 9.5,0.0,16.0,0.1);
	
	
	
	@EventHandler
    public void onUpdate(EventTick event) {
        if (Wrapper.mc.gameSettings.keyBindAttack.isKeyDown()) {
            Random random = new Random();
            if (Timer2.delay((long)(800.0 / this.clickspersecond.getValue() + MathUtils.randomDouble(0.0, 2.0 * this.randomize.getValue() )))) {
                if (Minecraft.thePlayer.isBlocking()) {
                    Wrapper.mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(0, 0, 0), EnumFacing.UP));
                    Minecraft.thePlayer.swingItem();
                    if (Minecraft.getMinecraft().objectMouseOver.entityHit instanceof EntityLivingBase) {
                        Minecraft.playerController.attackEntity(Minecraft.thePlayer, Minecraft.getMinecraft().objectMouseOver.entityHit);
                    }
                } else {
                    Minecraft.thePlayer.swingItem();
                    if (Minecraft.getMinecraft().objectMouseOver.entityHit instanceof EntityLivingBase) {
                        Minecraft.thePlayer.swingItem();
                        Minecraft.playerController.attackEntity(Minecraft.thePlayer, Minecraft.getMinecraft().objectMouseOver.entityHit);
                    }
                }
                Timer2.reset();
            }
        }
    }

}
