/*
 * Decompiled with CFR 0.136.
 */
package CopySense.module.combat;

import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Numbers;
import CopySense.api.value.Value;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.ui.ClientNotification.Type;
import CopySense.utils.ClientUtil;

import net.minecraft.entity.player.EntityPlayer;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class Hitbox
extends Module {
    public static Numbers<Double> size = new Numbers<Double>("size", "size", 0.5, 0.5, 1.0, 0.05);


    public Hitbox() {
        super("Hitbox", new String[]{"ka", "aura", "killa"}, ModuleType.Combat);
        this.setColor(new Color(226, 54, 30).getRGB());
        this.addValues(size);
    }

    private void onUpdate(EventPreUpdate event) {
        this.setSuffix(size.getValue());
    }
}

