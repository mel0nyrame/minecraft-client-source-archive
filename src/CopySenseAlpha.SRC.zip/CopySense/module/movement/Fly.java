package CopySense.module.movement;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.awt.Color;

import CopySense.Client;
import CopySense.api.EventHandler;
import CopySense.api.events.world.EventMove;
import CopySense.api.events.world.EventPacketRecieve;
import CopySense.api.events.world.EventPostUpdate;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.api.value.Option;
import CopySense.api.value.Value;
import CopySense.management.ModuleManager;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.ui.Notification.Notification;
import CopySense.ui.Notification.NotificationManager;
import CopySense.ui.Notification.NotificationType;
import CopySense.utils.TimerUtil;
import CopySense.utils.math.MathUtil;

import io.netty.util.Timeout;
import io.netty.util.TimerTask;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;
import net.minecraft.util.Timer;

public class Fly extends Module
{
    public static Mode mode = new Mode("Mode", "Mode", (Enum[])Fly.FlightMode.values(), (Enum)Fly.FlightMode.HypixelZoom);;
    private TimerUtil timer = new TimerUtil();;
    private double movementSpeed;
    private int hypixelCounter;
    private int hypixelCounter2;
    private Option<Boolean> par = new Option<Boolean>("Particle", "Particle", false);
   public static Numbers<Number> VanillaSpeed = new Numbers<Number>("Speed", "Speed",  2.0, 0.25, 5.0, 0.25);
    int counter;
    int level;
    boolean GG;
    double moveSpeed;
    double lastDist;
    boolean b2;
    
    public int V() {
        if (Minecraft.thePlayer.isPotionActive(Potion.jump)) {
            return Minecraft.thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1;
        }
        return 0;
    }
    
    public Fly() {
        super("Fly", new String[] { "fly", "angel" }, ModuleType.Move); 
        this.setColor(new Color(158, 114, 243).getRGB());
        this.addValues(new Value[] { (Value)this.mode , VanillaSpeed,this.par});
    }
    
    public void damagePlayer(int damage) {
        if (damage < 1) {
            damage = 1;
        }
        if (damage > MathHelper.floor_double((double)Minecraft.thePlayer.getMaxHealth())) {
            damage = MathHelper.floor_double((double)Minecraft.thePlayer.getMaxHealth());
        }
        final double offset = 0.0625;
        if (Minecraft.thePlayer != null && this.mc.getNetHandler() != null && Minecraft.thePlayer.onGround) {
            for (int i = 0; i <= (3 + damage) / offset; ++i) {
                this.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + offset, Minecraft.thePlayer.posZ, false));
                this.mc.getNetHandler().addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ, i == (3 + damage) / offset));
            }
        }
    }
    
    public void onEnable() {
        if (this.mode.getValue() == Fly.FlightMode.Hypixel || this.mode.getValue() == Fly.FlightMode.HypixelZoom || this.mode.getValue() == Fly.FlightMode.ZoomFly2 ) {
            if (this.mode.getValue() == Fly.FlightMode.HypixelZoom ||this.mode.getValue() == Fly.FlightMode.ZoomFly2 ) {
                this.damagePlayer(1);
                GG = true;
                if (mc.thePlayer.onGround) {
					Minecraft.getMinecraft().thePlayer.motionY = 0.42f;
				}
            }
            this.hypixelCounter = 0;
            this.hypixelCounter2 = 1000;
            Minecraft.thePlayer.motionY = 0.41999999999875 + this.V() * 0.1;
        }
        if(ModuleManager.getModuleByName("Scaffold").isEnabled()){
        	ModuleManager.getModuleByName("Scaffold").setEnabled(false);
        }
        this.level = 1;
        this.moveSpeed = 0.1;
        this.b2 = true;
        this.lastDist = 0.0;
        super.onEnable();
    }
    
    public void onDisable() {
        if (this.mode.getValue() == Fly.FlightMode.Area51) {
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
        }
        this.hypixelCounter = 0;
        this.hypixelCounter2 = 100;
        final Timer timer = this.mc.timer;
        Timer.timerSpeed = 1.0f;
        this.level = 1;
        this.moveSpeed = 0.1;
        this.b2 = false;
        this.lastDist = 0.0;
        super.onDisable();
    }
    
    @EventHandler
    private void onUpdate(final EventPreUpdate e) {
    	if (this.par.getValue().booleanValue()) {
			final double posX4 = mc.thePlayer.posX;
			final double posX = posX4 - MathHelper.cos(mc.thePlayer.rotationYaw / 180.0f * 3.1415927f) * 0.16f;
			final double posY = mc.thePlayer.posY;
			final double posZ2 = mc.thePlayer.posZ;
			final double posZ = posZ2 - MathHelper.sin(mc.thePlayer.rotationYaw / 180.0f * 3.1415927f) * 0.16f;
			final float f = 0.4f;
			final float n2 = -MathHelper.sin(mc.thePlayer.rotationYaw / 180.0f * 3.1415927f);
			final double motionX = n2 * MathHelper.cos(mc.thePlayer.rotationPitch / 180.0f * 3.1415927f) * f;
			final float cos = MathHelper.cos(mc.thePlayer.rotationYaw / 180.0f * 3.1415927f);
			final double motionZ = cos * MathHelper.cos(mc.thePlayer.rotationPitch / 180.0f * 3.1415927f) * f;
			final double motionY = -MathHelper.sin((mc.thePlayer.rotationPitch + 2.0f) / 180.0f * 3.1415927f) * f;
			for (int i = 0; i < 90; ++i) {
				final WorldClient theWorld = this.mc.theWorld;
				final EnumParticleTypes particleType = (i % 4 == 0) ? (EnumParticleTypes.CRIT_MAGIC)
						: (new Random().nextBoolean() ? EnumParticleTypes.HEART : EnumParticleTypes.ENCHANTMENT_TABLE);
				final double xCoord = posX + motionX;
				final double yCoord = posY + motionY;
				final double zCoord = posZ + motionZ;
				final double motionX2 = mc.thePlayer.motionX;
				final double motionY2 = mc.thePlayer.motionY;
				theWorld.spawnParticle(particleType, xCoord, yCoord, zCoord, motionX2, motionY2, mc.thePlayer.motionZ,
						new int[0]);
			}
		}
        this.setSuffix(this.mode.getValue());
        if (this.mode.getValue() == Fly.FlightMode.Guardian) {
            final Timer timer = this.mc.timer;
            Timer.timerSpeed = 1.7f;
            if (!Minecraft.thePlayer.onGround && Minecraft.thePlayer.ticksExisted % 2 == 0) {
                Minecraft.thePlayer.motionY = 0.04;
            }
            if (this.mc.gameSettings.keyBindJump.pressed) {
                final EntityPlayerSP thePlayer = Minecraft.thePlayer;
                ++thePlayer.motionY;
            }
            if (this.mc.gameSettings.keyBindSneak.pressed) {
                final EntityPlayerSP thePlayer2 = Minecraft.thePlayer;
                ++thePlayer2.motionY;
            }
        }
        else if (this.mode.getValue() == FlightMode.Vanilla) {
            
            final EntityPlayerSP thePlayer8 = Minecraft.thePlayer;
            
            double motionY;
            if (Minecraft.thePlayer.movementInput.jump) {
                motionY = 1.0;
            }
            else {
                
                motionY = (Minecraft.thePlayer.movementInput.sneak ? -1.0 : 0.0);
            }
            thePlayer8.motionY = motionY;
           
            if (Minecraft.thePlayer.moving()) {
               
                Minecraft.thePlayer.setSpeed((double)this.VanillaSpeed.getValue());
            }
            else {
                final Minecraft mc12 = mc;
                Minecraft.thePlayer.setSpeed(0.0);
            }
        }
        
        else if (this.mode.getValue() == Fly.FlightMode.Area51) {
            Minecraft.thePlayer.motionY = (Minecraft.thePlayer.movementInput.jump ? 1.0 : (Minecraft.thePlayer.movementInput.sneak ? -1.0 : 0.0));
        }
        else if (this.mode.getValue() == Fly.FlightMode.Hypixel || this.mode.getValue() == Fly.FlightMode.HypixelZoom) {
            ++this.counter;
            
            if (Minecraft.thePlayer.moveForward == 0.0f) {
                
                if (Minecraft.thePlayer.moveStrafing == 0.0f) {
                    
                    final EntityPlayerSP thePlayer4 = Minecraft.thePlayer;
                    
                    final double n = Minecraft.thePlayer.posX + 1.0;
                    
                    final double n2 = Minecraft.thePlayer.posY + 1.0;
                    
                    thePlayer4.setPosition(n, n2, Minecraft.thePlayer.posZ + 1.0);
                    
                    final EntityPlayerSP thePlayer5 = Minecraft.thePlayer;
                    
                    final double prevPosX = Minecraft.thePlayer.prevPosX;
                    
                    final double prevPosY = Minecraft.thePlayer.prevPosY;
                    
                    thePlayer5.setPosition(prevPosX, prevPosY, Minecraft.thePlayer.prevPosZ);
                    
                    Minecraft.thePlayer.motionX = 0.0;
                    
                    Minecraft.thePlayer.motionZ = 0.0;
                }
            }
            
            Minecraft.thePlayer.motionY = 0.0;
            if (Minecraft.getMinecraft().gameSettings.keyBindJump.pressed) {
                
                final EntityPlayerSP thePlayer6 = Minecraft.thePlayer;
                thePlayer6.motionY += 0.5;
            }
            if (Minecraft.getMinecraft().gameSettings.keyBindSneak.pressed) {
                
                final EntityPlayerSP thePlayer7 = Minecraft.thePlayer;
                thePlayer7.motionY -= 0.5;
            }
            if (this.counter != 1 && this.counter == 2) {
                
                final EntityPlayerSP thePlayer8 = Minecraft.thePlayer;
                
                final double posX = Minecraft.thePlayer.posX;
                
                final double n3 = Minecraft.thePlayer.posY + 1.0E-10;
                
                thePlayer8.setPosition(posX, n3, Minecraft.thePlayer.posZ);
                this.counter = 0;
            }
        }
        else if (this.mode.getValue() == Fly.FlightMode.ZoomFly2 && Minecraft.thePlayer.moving()) {
        	final double xDist = this.mc.thePlayer.posX - this.mc.thePlayer.prevPosX;
            final double zDist = this.mc.thePlayer.posZ - this.mc.thePlayer.prevPosZ;
            this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
            if (Minecraft.getMinecraft().thePlayer.onGround) {
                Minecraft.getMinecraft().thePlayer.motionY = 0.42f;
           
       	   }
         
            
            ++counter;
   			if (Minecraft.getMinecraft().thePlayer.moveForward == 0
   					&& Minecraft.getMinecraft().thePlayer.moveStrafing == 0) {
   				
   				Minecraft.getMinecraft().thePlayer.setPosition(
   				
   						Minecraft.getMinecraft().thePlayer.posX + 1.0D,
   						Minecraft.getMinecraft().thePlayer.posY + 1.0D,
   						Minecraft.getMinecraft().thePlayer.posZ + 1.0D);
   				Minecraft.getMinecraft().thePlayer.setPosition(Minecraft.getMinecraft().thePlayer.prevPosX,
   						Minecraft.getMinecraft().thePlayer.prevPosY,
   						Minecraft.getMinecraft().thePlayer.prevPosZ);
   				Minecraft.getMinecraft().thePlayer.motionX = 0.0D;
   				Minecraft.getMinecraft().thePlayer.motionZ = 0.0D;
   		   		
   			}
   			Minecraft.getMinecraft().thePlayer.motionY = 0.0D;
   			if (Minecraft.getMinecraft().gameSettings.keyBindJump.pressed)
   				Minecraft.getMinecraft().thePlayer.motionY += 0.5f;
   			if (Minecraft.getMinecraft().gameSettings.keyBindSneak.pressed)
   				Minecraft.getMinecraft().thePlayer.motionY -= 0.5f;
   			
   			if (counter != 1 && counter == 2) {
   				
   				Minecraft.getMinecraft().thePlayer.setPosition(Minecraft.getMinecraft().thePlayer.posX,
   						Minecraft.getMinecraft().thePlayer.posY + 1.0E-10D,
   						Minecraft.getMinecraft().thePlayer.posZ);
   				counter = 0;
   				
   			}
        }
         
        else if (this.mode.getValue() == Fly.FlightMode.OldGuardianLongJumpFly && Minecraft.thePlayer.moving()) {
            final Client instance = Client.instance;
            if (!Client.getModuleManager().getModuleByClass((Class)Speed.class).isEnabled()) {
                if (Minecraft.thePlayer.isAirBorne) {
                    if (Minecraft.thePlayer.ticksExisted % 12 == 0 && Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ)).getBlock() instanceof BlockAir) {
                        Minecraft.thePlayer.setSpeed(6.5);
                        Minecraft.thePlayer.sendQueue.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + 1.0E-9, Minecraft.thePlayer.posZ, Minecraft.thePlayer.onGround));
                        Minecraft.thePlayer.motionY = 0.455;
                    }
                    else {
                        Minecraft.thePlayer.setSpeed((double)(float)Math.sqrt(Minecraft.thePlayer.motionX * Minecraft.thePlayer.motionX + Minecraft.thePlayer.motionZ * Minecraft.thePlayer.motionZ));
                    }
                }
                else {
                    Minecraft.thePlayer.motionX = 0.0;
                    Minecraft.thePlayer.motionZ = 0.0;
                }
                if (Minecraft.thePlayer.movementInput.jump) {
                    Minecraft.thePlayer.motionY = 0.85;
                }
                else if (Minecraft.thePlayer.movementInput.sneak) {
                    Minecraft.thePlayer.motionY = -0.85;
                }
            }
        }
    }
    
    @EventHandler
    public void onPost(final EventPostUpdate e) {
        if (this.mode.getValue() == Fly.FlightMode.Hypixel || this.mode.getValue() == Fly.FlightMode.HypixelZoom) {
            
            final double posX = Minecraft.thePlayer.posX;
            
            final double xDist = posX - Minecraft.thePlayer.prevPosX;
            
            final double posZ = Minecraft.thePlayer.posZ;
            
            final double zDist = posZ - Minecraft.thePlayer.prevPosZ;
            this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
        }
    }
    
    
    
    // code LAngʲô�ģ��Ǹ�Zoomfly
    @EventHandler
    private void onMove(final EventMove e) {
    	
    	if (this.mode.getValue() == Fly.FlightMode.ZoomFly2){
    		double speed = 0;
    	    double forward = mc.thePlayer.movementInput.moveForward;
    	    double strafe = mc.thePlayer.movementInput.moveStrafe;
    	    float yaw = mc.thePlayer.rotationYaw;
        	  if(GG) {
        		  Minecraft.getMinecraft().thePlayer.cameraYaw = 0.1f;
        	           
        	  
           
    			if (b2) {
    				if (level != 1 || Minecraft.getMinecraft().thePlayer.moveForward == 0.0F
    						&& Minecraft.getMinecraft().thePlayer.moveStrafing == 0.0F) {
    					if (level == 2) {
    						level = 3;
    						e.setY(mc.thePlayer.motionY = 0.42);
    						moveSpeed *= 2.14519999D;
    						} else if (level == 3) {
    						level = 4;
    						double difference = (Minecraft.getMinecraft().thePlayer.ticksExisted % 2 == 0 ? 0.004D : 0.0083D)
    								* (lastDist - getBaseMoveSpeed());
    						moveSpeed = lastDist - difference;
    						
    					} else {
    						if (Minecraft.getMinecraft().theWorld
    								.getCollidingBoundingBoxes(Minecraft.getMinecraft().thePlayer,
    										Minecraft.getMinecraft().thePlayer.boundingBox.offset(0.0D,
    												Minecraft.getMinecraft().thePlayer.motionY, 0.0D))
    								.size() > 0 || Minecraft.getMinecraft().thePlayer.isCollidedVertically) {
    							level = 1;
    						   		
    						}
    						moveSpeed = lastDist - lastDist / 158.0D;
    					}
    				} else {
    					level = 2;
    					int amplifier = Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.moveSpeed)
    							? Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.moveSpeed)
    									.getAmplifier() + 2
    							: 1;
    				 		
    					double boost = Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.moveSpeed) ? 1.76
    							: this.VanillaSpeed.getValue().floatValue();
    					  mc.thePlayer.motionX *= 0.0D;
    				      mc.thePlayer.motionZ *= 0.0D;      
    					moveSpeed = boost * getBaseMoveSpeed();
    				
    					
    				}
    				speed = Math.max(moveSpeed,getBaseMoveSpeed());
    				
    			
    				
          e.setX(forward * speed * Math.cos(Math.toRadians(yaw + 90.0F)) + strafe * speed * 
                  Math.sin(Math.toRadians(yaw + 90.0F)));
          e.setZ(forward * speed * Math.sin(Math.toRadians(yaw + 90.0F)) - strafe * speed * 
                  Math.cos(Math.toRadians(yaw + 90.0F)));
        }
        	  }
      }
    	
        if (this.mode.getValue() == Fly.FlightMode.Hypixel || this.mode.getValue() == Fly.FlightMode.HypixelZoom) {
            final float forward = MovementInput.moveForward;
            final float strafe = MovementInput.moveStrafe;
            final float yaw = Minecraft.thePlayer.rotationYaw;
            final double mx = Math.cos(Math.toRadians(yaw + 90.0f));
            final double mz = Math.sin(Math.toRadians(yaw + 90.0f));
            if (forward == 0.0f && strafe == 0.0f) {
                EventMove.x = 0.0;
                EventMove.z = 0.0;
            }
            if (this.b2) {
                Label_0393: {
                    Label_0137: {
                        if (this.level == 1) {
                            
                            if (Minecraft.thePlayer.moveForward == 0.0f) {
                                
                                if (Minecraft.thePlayer.moveStrafing == 0.0f) {
                                    break Label_0137;
                                }
                            }
                            this.level = 2;
                            
                            int n;
                            if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
                                
                                n = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1;
                            }
                            else {
                                n = 0;
                            }
                            final int amplifier = n;
                            
                            final double boost = Minecraft.thePlayer.isPotionActive(Potion.moveSpeed) ? 1.56 : 2.034;
                            this.moveSpeed = boost * MathUtil.getBaseMovementSpeed();
                            break Label_0393;
                        }
                    }
                    if (this.level == 2) {
                        this.level = 3;
                        this.moveSpeed *= 2.1399;
                    }
                    else if (this.level == 3) {
                        this.level = 4;
                        final double difference = ((Minecraft.thePlayer.ticksExisted % 2 == 0) ? 0.0103 : 0.0123) * (this.lastDist - MathUtil.getBaseMovementSpeed());
                        this.moveSpeed = this.lastDist - difference;
                    }
                    else {
                        
                        final WorldClient theWorld = Minecraft.theWorld;
                        
                        final EntityPlayerSP thePlayer = Minecraft.thePlayer;
                        
                        final AxisAlignedBB boundingBox = Minecraft.thePlayer.boundingBox;
                        final double n2 = 0.0;
                        
                        Label_0291: {
                            if (theWorld.getCollidingBoundingBoxes((Entity)thePlayer, boundingBox.offset(n2, Minecraft.thePlayer.motionY, 0.0)).size() <= 0) {
                                
                                if (!Minecraft.thePlayer.isCollidedVertically) {
                                    break Label_0291;
                                }
                            }
                            this.level = 1;
                        }
                        this.moveSpeed = this.lastDist - this.lastDist / 159.0;
                    }
                }
                final double moveSpeed = (this.mode.getValue() == Fly.FlightMode.HypixelZoom) ? Math.max(this.moveSpeed, MathUtil.getBaseMovementSpeed()) : MathUtil.getBaseMovementSpeed();
                this.moveSpeed = moveSpeed;
                final double d = moveSpeed;
                if (strafe == 0.0f) {
                    EventMove.x = forward * this.moveSpeed * mx + strafe * this.moveSpeed * mz;
                    EventMove.z = forward * this.moveSpeed * mz - strafe * this.moveSpeed * mx;
                }
                else if (strafe != 0.0f) {
                    Minecraft.thePlayer.setMoveSpeed(e, this.moveSpeed);
                }
                if (forward == 0.0f && strafe == 0.0f) {
                    EventMove.x = 0.0;
                    EventMove.z = 0.0;
                }
            }
        }
        else if (this.mode.getValue() == FlightMode.Motion) {
			float forward = MovementInput.moveForward;
			float strafe = MovementInput.moveStrafe;
			float yaw = mc.thePlayer.rotationYaw;
			if (forward == 0.0F && strafe == 0.0F) {
				e.x = 0.0D;
				e.z = 0.0D;
			} else if (forward != 0.0F) {
				if (strafe >= 1.0F) {
					yaw += (float) (forward > 0.0F ? -45 : 45);
					strafe = 0.0F;
				} else if (strafe <= -1.0F) {
					yaw += (float) (forward > 0.0F ? 45 : -45);
					strafe = 0.0F;
				}

				if (forward > 0.0F) {
					forward = 1.0F;
				} else if (forward < 0.0F) {
					forward = -1.0F;
				}
			}
			mc.thePlayer.onGround= false;
            {
            	moveSpeed = 0.0D;
            }
            moveSpeed = Math.max(moveSpeed, MathUtil.getBaseMovementSpeed());
            this.mc.thePlayer.setMoveSpeed(e, moveSpeed);
		}
    }
    
    double getBaseMoveSpeed() {
        double baseSpeed = 0.275;
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            final int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (amplifier + 1);
        }
        return baseSpeed;
    }
    public static enum FlightMode{
		HypixelZoom, Hypixel, OldGuardianLongJumpFly, Area51, Vanilla, Guardian, Motion, ZoomFly2
    	
    }
}