/*
 * Decompiled with CFR 0_132.
 */
package CopySense.module.movement;

import java.awt.Color;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.combat.KillAura;
import CopySense.utils.MoveUtils;
import CopySense.utils.PlayerUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class NoSlow
		extends Module {
	private Mode<Enum> mode = new Mode("Mode", "Mode", (Enum[]) SlowMode.values(), (Enum) SlowMode.NCP);
	public NoSlow() {
		super("NoSlowDown", new String[]{"noslowdown"}, ModuleType.Move);
		this.setColor(new Color(216, 253, 100).getRGB());
		this.addValues(this.mode);
	}


	@EventHandler
	public void onPre(EventPreUpdate event) {
		setSuffix(this.mode.getValue());
	}
	@EventHandler
	private void onUpdate(EventPreUpdate e) {
			if (this.mode.getValue() == SlowMode.NCP) {
				if(mc.thePlayer.isBlocking() && PlayerUtil.isMoving() && MoveUtils.isOnGround(0.42)){
					double x = mc.thePlayer.posX; double y = mc.thePlayer.posY; double z = mc.thePlayer.posZ;
					if (e.isPre()) {
						mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
					} else if (e.isPost()) {
						mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));
					}
				}
			}
			if (this.mode.getValue() == SlowMode.AAC) {
				if (mc.thePlayer.ticksExisted % 3 == 0) {
					sendPacket(e, true, false, false, false, false);
				} else {
					sendPacket(e, false, true, false, false, false);
				}
			}
			if (this.mode.getValue() == SlowMode.AntiCheats) {
				this.sendPacket(e, true, false, false, false, false);
				if (mc.thePlayer.ticksExisted % 2 == 0) {
					this.sendPacket(e, false, true, false, false, false);
				}
			}
	}

	private void sendPacket(EventPreUpdate event,Boolean sendC07,Boolean sendC08,Boolean delay,Boolean delayValue,Boolean onGround) {
		boolean watchDog = false;
		Object digging = new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, new BlockPos(-1, -1, -1), EnumFacing.DOWN);
		Object blockPlace = new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem());
		Object blockMent = new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, mc.thePlayer.inventory.getCurrentItem(), 0f, 0f, 0f);
		if(onGround && !mc.thePlayer.onGround) {
			return;
		}
		if(sendC07 && event.isPre()) {
			if(delay) {
				mc.getNetHandler().addToSendQueue((Packet)digging);
			} else if(!delay) {
				mc.getNetHandler().addToSendQueue((Packet)digging);
			}
		}
		if(sendC08 && !event.isPre()) {
			if(delay && !watchDog) {
				mc.getNetHandler().addToSendQueue((Packet)blockPlace);
			} else if(!delay && !watchDog) {
				mc.getNetHandler().addToSendQueue((Packet)blockPlace);
			} else if(watchDog) {
				mc.getNetHandler().addToSendQueue((Packet)blockMent);
			}
		}
	}


	enum SlowMode {
		NCP, AAC, AntiCheats
	}
}

