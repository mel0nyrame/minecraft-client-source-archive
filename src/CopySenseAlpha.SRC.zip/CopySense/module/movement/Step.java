/*
 * Decompiled with CFR 0_132.
 */
package CopySense.module.movement;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.api.value.Option;
import CopySense.api.value.Value;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.movement.Speed.SpeedMode;

import java.awt.Color;
import java.util.Arrays;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.Timer;

public class Step
extends Module {
    private Numbers<Double> height = new Numbers<Double>("Height", "height", 1.0, 1.0, 10.0, 0.5);
    private Mode<Enum> mode = new Mode("Mode", "mode", (Enum[])StepMode.values(), (Enum)StepMode.NCP);

    public Step() {
        super("Step", new String[]{"autojump"}, ModuleType.Move);
        this.setColor(new Color(165, 238, 65).getRGB());
        this.addValues(this.height,this.mode);
    }

    @Override
    public void onDisable() {
        this.mc.thePlayer.stepHeight = 0.6f;
    }

    @EventHandler
    private void onUpdate(EventPreUpdate e) {
        if (this.mode.getValue()==StepMode.NCP) {
        	double rheight = mc.thePlayer.getEntityBoundingBox().minY - mc.thePlayer.posY;
        	boolean canStep = rheight >= 0.625;
			if(canStep){
				mc.timer.timerSpeed = (float) (0.37 - (rheight >= 1 ? Math.abs(1-(float)rheight)*((float)37*0.55f) : 0));
				if(mc.timer.timerSpeed <= 0.05f){
					mc.timer.timerSpeed = 0.05f;
				}
    			ncpStep(rheight);	
			}	
        }if(this.mode.getValue()==StepMode.Vanlia){
            this.mc.thePlayer.stepHeight = 1.0f;
        }
    }
    void ncpStep(double height){
    	List<Double>offset = Arrays.asList(0.42,0.333,0.248,0.083,-0.078);
    	double posX = mc.thePlayer.posX; double posZ = mc.thePlayer.posZ;
    	double y = mc.thePlayer.posY;
    	if(height < 1.1){
    		double first = 0.42;
    		double second = 0.75;
    		if(height != 1){
    			first *= height;
    			second *= height;
        		if(first > 0.425){
        			first = 0.425;
        		}
        		if(second > 0.78){
        			second = 0.78;
        		}
        		if(second < 0.49){
        			second = 0.49;
        		}
    		}
    		if(first == 0.42)
    			first = 0.41999998688698;
    		mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, y + first, posZ, false));
    		if(y+second < y + height)
    		mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, y + second, posZ, false));
    		return;
    	}else if(height <1.6){
    		for(int i = 0; i < offset.size(); i++){
        		double off = offset.get(i);
        		y += off;
        		mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, y, posZ, false));
        	}
    	}else if(height < 2.1){
    		double[] heights = {0.425,0.821,0.699,0.599,1.022,1.372,1.652,1.869};
			for(double off : heights){
        		mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, y + off, posZ, false));
        	}
    	}else{
        	double[] heights = {0.425,0.821,0.699,0.599,1.022,1.372,1.652,1.869,2.019,1.907};
        	for(double off : heights){
        		mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, y + off, posZ, false));
        	}
    	}
    	
    }
    enum StepMode{
    	NCP,
    	Vanlia;
    }
}

