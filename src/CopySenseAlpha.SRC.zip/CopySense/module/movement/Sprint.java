/*
 * Decompiled with CFR 0_132.
 */
package CopySense.module.movement;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Option;
import CopySense.management.ModuleManager;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.combat.KillAura;
import CopySense.utils.MoveUtils;

import java.awt.*;

public class Sprint
		extends Module {
	private Option<Boolean> omni = new Option<Boolean>("Omni-Directional", "omni", true);

	public Sprint() {
		super("Sprint", new String[]{"run"}, ModuleType.Move);
		this.setColor(new Color(158, 205, 125).getRGB());
		this.addValues(this.omni);
	}

	@EventHandler
	private void onUpdate(EventPreUpdate event) {
		if (this.mc.thePlayer.getFoodStats().getFoodLevel() > 6 && !mc.thePlayer.isSneaking() && this.omni.getValue() != false ? MoveUtils.isMoving() : this.mc.thePlayer.moveForward > 0.0f) {
			this.mc.thePlayer.setSprinting(true);
		}
	}
}

