package CopySense.module.movement;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventMove;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;

import CopySense.api.value.Option;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.utils.*;
import CopySense.utils.math.MathUtil;

import java.util.List;

import net.minecraft.block.*;
import net.minecraft.client.Minecraft;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;

public class Speed
extends Module {
	public static Mode<Enum> mode = new Mode("Mode", "Mode", (Enum[])SpeedMode.values(), (Enum)SpeedMode.Hypixel);
	public static Option watercheck = new Option("WaterCheck" ,"WaterCheck",false);
	private Option<Boolean> disabled = new Option<Boolean>("DiedDisabled", "DiedDisabled", true);
	
    private int stage;
    private double movementSpeed;
    double moveSpeed;
    private double distance;
    private double speed, speedvalue;
    public boolean shouldslow = false;
    double count = 0;
    int jumps;
    boolean collided = false, lessSlow;
    int spoofSlot = 0;
    double less, stair;
    Timer lastFall = new Timer();
    public static int aacCount;
    private TimerUtil timer = new TimerUtil();
    Timer lastCheck = new Timer();
    private int end;
    private long start;
    private int lqqz;
    public Speed() {
        super("Speed", new String[]{"zoom"}, ModuleType.Move);
        this.addValues(this.mode,this.watercheck);
    }
    @Override
    public void onDisable() {
        this.mc.timer.timerSpeed = 1.0f;
        super.onDisable();
        aacCount = 0;
    }

    private boolean canZoom() {
        if (this.mc.thePlayer.moving() && this.mc.thePlayer.onGround) {
            return true;
        }
        return false;
    }

    @EventHandler
    private void onUpdate(EventPreUpdate e) {
    	if (!mc.thePlayer.isEntityAlive() && disabled.getValue()) {
	    	  this.setEnabled(false);
	    }
    	if( ((Boolean) this.watercheck.getValue()).booleanValue()) {
    		if(mc.thePlayer.isInWater()) {
    			this.setEnabled(false);
    			Helper.sendMessage("You in the Water!");
    		}
    	}

        this.setSuffix(this.mode.getValue());
        if (this.mode.getValue() == SpeedMode.Onground && this.canZoom()) {
            switch (this.stage) {
                case 1: {
                    e.setY(e.getY() + 0.4);
                    e.setOnground(false);
                    ++this.stage;
                    break;
                }
                case 2: {
                    e.setY(e.getY() + 0.4);
                    e.setOnground(false);
                    ++this.stage;
                    break;
                }
                default: {
                    this.stage = 1;
                    break;
                }
            }
        } 
    }

    @EventHandler
    private void onMove(EventMove e) {
    	block34 : {
        block33 : {
            block36 : {
                block39 : {
                    block38 : {
                        block37 : {
                            block35 : {
                                if (this.isInLiquid()) break block34;
                                if (this.canZoom()) {
                                    this.moveSpeed = this.getBaseMoveSpeed();
                                }
                                if (stage == 1) {
                                    if (Minecraft.thePlayer.isCollidedVertically && this.canZoom()) {
                                        this.moveSpeed = 1.5 + this.getBaseMoveSpeed() - 0.01;
                                    }
                                }
                                if (!this.canZoom() || stage != 2) break block35;
                                double jump = 0.418;
                                Minecraft.thePlayer.motionY = jump;
                                EventMove.setY(Minecraft.thePlayer.motionY);
                                this.moveSpeed *= 1.89;
                                break block36;
                            }
                            if (stage != 3) break block37;
                            double diff = 0.66 * (this.distance - this.getBaseMoveSpeed());
                            this.moveSpeed = this.distance - diff;
                            break block36;
                        }
                        List<AxisAlignedBB> collidingList = Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.boundingBox.offset(0.0, Minecraft.thePlayer.motionY, 0.0));
                        if (collidingList.size() > 0) break block38;
                        if (!Minecraft.thePlayer.isCollidedVertically) break block39;
                    }
                    if (stage > 0) {
                        stage = Minecraft.thePlayer.moving() ? 1 : 0;
                    }
                }
                this.moveSpeed = this.getBaseMoveSpeed() * 1.00000011920929;
                this.moveSpeed = this.distance - this.distance / 159.0;
            }
            this.moveSpeed = Math.max(this.moveSpeed, this.getBaseMoveSpeed());
            Minecraft.thePlayer.setMoveSpeed(e, this.moveSpeed);
            if (stage > 0) {
                this.setMotion(e, this.moveSpeed);
            }
            float forward = MovementInput.moveForward;
            float strafe = MovementInput.moveStrafe;
            float yaw = Minecraft.thePlayer.rotationYaw;
            if (forward == 0.0f && strafe == 0.0f) {
                Minecraft.thePlayer.motionX *= (Minecraft.thePlayer.motionZ *= 0.0);
                EventMove.x = 0.0;
                EventMove.z = 0.0;
            } else if (forward != 0.0f) {
                if (strafe >= 1.0f) {
                    yaw += forward > 0.0f ? -45.0f : 45.0f;
                    strafe = 0.0f;
                } else if (strafe <= -1.0f) {
                    yaw += forward > 0.0f ? 45.0f : -45.0f;
                    strafe = 0.0f;
                }
                if (forward > 0.0f) {
                    forward = 1.0f;
                } else if (forward < 0.0f) {
                    forward = -1.0f;
                }
            }
            if (forward == 0.0f && strafe == 0.0f) {
                EventMove.x = 0.0;
                EventMove.z = 0.0;
                Minecraft.thePlayer.motionX *= (Minecraft.thePlayer.motionZ *= 0.0);
            } else if (forward != 0.0f) {
                if (strafe >= 1.0f) {
                    float var10000 = yaw + (forward > 0.0f ? -45.0f : 45.0f);
                    strafe = 0.0f;
                } else if (strafe <= -1.0f) {
                    float var10000 = yaw + (forward > 0.0f ? 45.0f : -45.0f);
                    strafe = 0.0f;
                }
                if (forward > 0.0f) {
                    forward = 1.0f;
                } else if (forward < 0.0f) {
                    forward = -1.0f;
                }
            }
            ++stage;
            break block34;
        }
    }
    
    if (this.mode.getValue() == SpeedMode.JumpHop) {
		if (mc.thePlayer.isCollidedHorizontally) {
            collided = true;
        }
        if (collided) {
            mc.timer.timerSpeed = 1;
            stage = -1;
        }
        if (stair > 0)
            stair -= 0.25;
        less -= less > 1 ? 0.12 : 0.11;
        if (less < 0)
            less = 0;
        if (!BlockUtils.isInLiquid() && MoveUtils.isOnGround(0.01) && (PlayerUtil.isMoving2())) {
            collided = mc.thePlayer.isCollidedHorizontally;
            if (stage >= 0 || collided) {
                stage = 0;

                double motY = 0.4086666 + MoveUtils.getJumpEffect() * 0.1;
                if (stair == 0) {
                    mc.thePlayer.jump();
                    e.setY(mc.thePlayer.motionY = motY);
                } else {

                }

                less++;
                if (less > 1 && !lessSlow)
                    lessSlow = true;
                else
                    lessSlow = false;
                if (less > 1.12)
                    less = 1.12;
            }
        }
        speed = getHypixelSpeed(stage) + 0.0331;
        speed *= 0.91;
        if (stair > 0) {
            speed *= 0.66 - MoveUtils.getSpeedEffect() * 0.1;
        }

        if (stage < 0)
            speed = MoveUtils.defaultSpeed();
        if (lessSlow) {
            speed *= 0.96;
        }


        if (BlockUtils.isInLiquid()) {
            speed = 0.12;
        }

        if ((mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f)) {
            setMotion(e, speed);
            ++stage;
        }
    }
    List i2;
    double var11;
    	if (this.mode.getValue() == SpeedMode.LowHop) {
            if (Speed.mc.thePlayer.isCollidedHorizontally) {
                this.collided = true;
            }
            if (this.collided) {
                this.stage = -1;
            }
            if (this.stair > 0.0) {
                this.stair -= 0.24;
            }
            this.less -= ((this.less > 1.0) ? 0.12 : 0.11);
            if (this.less < 0.0) {
                this.less = 0.0;
            }
            if (!BlockUtils.isInLiquid() && MoveUtils.isOnGround(0.01) && PlayerUtil.isMoving2()) {
                this.collided = Speed.mc.thePlayer.isCollidedHorizontally;
                if (this.stage >= 0 || this.collided) {
                    this.stage = 0;
                    final double motY;
                    if(mc.thePlayer.isCollidedHorizontally && !isInsideBlock()) {
                        motY = Minecraft.thePlayer.motionY = 0.40;
                    }else {
                        motY = 0.3200;
                    }
                    if (this.stair == 0.0) {
                        Speed.mc.thePlayer.jump();
                        EventMove.setY(Speed.mc.thePlayer.motionY = motY);
                    }
                    ++this.less;
                    if (this.less > 1.0 && !this.lessSlow) {
                        this.lessSlow = true;
                    } else {
                        this.lessSlow = false;
                    }
                    if (this.less > 1.12) {
                        this.less = 1.12;
                    }
                }
            }
            this.speed = this.getHypixelSpeed(this.stage) + 0.0331;
            this.speed *= 0.8777777;
            if (this.stair > 0.0) {
                this.speed *= 0.789 - MoveUtils.getSpeedEffect() * 0.1;
            }
            if (this.stage < 0) {
                this.speed = MoveUtils.defaultSpeed();
            }
            if (this.lessSlow) {
                this.speed *= 0.82554524;
            }
            if (BlockUtils.isInLiquid()) {
                this.speed = 0.135;
            }
            if (Speed.mc.thePlayer.moveForward != 0.0f || Speed.mc.thePlayer.moveStrafing != 0.0f) {
                ++this.stage;
            }
        }
        if (this.mode.getValue() == SpeedMode.Onground && this.canZoom()) {
            switch (this.stage) {
                case 1: {
                    this.mc.timer.timerSpeed = 1.22f;
                    this.movementSpeed = 1.89 * MathUtil.getBaseMovementSpeed() - 0.01;
                    this.distance += 1.0;
                    if (this.distance == 1.0) {
                        e.setY(e.getY() + 8.0E-6);
                        break;
                    }
                    if (this.distance != 2.0) break;
                    e.setY(e.getY() - 8.0E-6);
                    this.distance = 0.0;
                    break;
                }
                case 2: {
                    this.movementSpeed = 1.2 * MathUtil.getBaseMovementSpeed() - 0.01;
                    break;
                }
                default: {
                    this.movementSpeed = (float)MathUtil.getBaseMovementSpeed();
                }
            }
            this.movementSpeed = Math.max(this.movementSpeed, MathUtil.getBaseMovementSpeed());
            this.mc.thePlayer.setMoveSpeed(e, this.movementSpeed);
            ++this.stage;
        }
    }

    private boolean isInLiquid() {
		if (mc.thePlayer == null) {
			return false;
		}
		for (int x = MathHelper.floor_double(mc.thePlayer.boundingBox.minX); x < MathHelper
				.floor_double(mc.thePlayer.boundingBox.maxX) + 1; x++) {
			for (int z = MathHelper.floor_double(mc.thePlayer.boundingBox.minZ); z < MathHelper
					.floor_double(mc.thePlayer.boundingBox.maxZ) + 1; z++) {
				BlockPos pos = new BlockPos(x, (int) mc.thePlayer.boundingBox.minY, z);
				Block block = mc.theWorld.getBlockState(pos).getBlock();
				if ((block != null) && (!(block instanceof BlockAir))) {
					return block instanceof BlockLiquid;
				}
			}
		}
		return false;
	}
	double getBaseMoveSpeed() {
		double baseSpeed = 0.2873;
		if (this.mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
			int amplifier = this.mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
			baseSpeed *= 1.0 + 0.2 * (double) (amplifier + 1);
		}
		return baseSpeed;
	}
	private void setMotion(EventMove em, double speed) {
        double forward = mc.thePlayer.movementInput.moveForward;
        double strafe = mc.thePlayer.movementInput.moveStrafe;
        float yaw = mc.thePlayer.rotationYaw;
        if ((forward == 0.0D) && (strafe == 0.0D)) {
            em.setX(0.0D);
            em.setZ(0.0D);
        } else {
            if (forward != 0.0D) {
                if (strafe > 0.0D) {
                    yaw += (forward > 0.0D ? -45 : 45);
                } else if (strafe < 0.0D) {
                    yaw += (forward > 0.0D ? 45 : -45);
                }
                strafe = 0.0D;
                if (forward > 0.0D) {
                    forward = 1;
                } else if (forward < 0.0D) {
                    forward = -1;
                }
            }
            em.setX(forward * speed * Math.cos(Math.toRadians(yaw + 90.0F)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0F)));
            em.setZ(forward * speed * Math.sin(Math.toRadians(yaw + 90.0F)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0F)));
        }
        if(mc.thePlayer.isCollidedHorizontally && !isInsideBlock()){
            end = 700;
            start = System.currentTimeMillis();
            lqqz = 1;
        }else {
            lqqz = 0;
        }
    }

    public static boolean isInsideBlock() {
        for (int x = MathHelper.floor_double(mc.thePlayer.boundingBox.minX); x < MathHelper.floor_double(mc.thePlayer.boundingBox.maxX) + 1; x++) {
            for (int y = MathHelper.floor_double(mc.thePlayer.boundingBox.minY); y < MathHelper.floor_double(mc.thePlayer.boundingBox.maxY) + 1; y++) {
                for (int z = MathHelper.floor_double(mc.thePlayer.boundingBox.minZ); z < MathHelper.floor_double(mc.thePlayer.boundingBox.maxZ) + 1; z++) {
                    Block block = mc.theWorld.getBlockState(new BlockPos(x, y, z)).getBlock();
                    if ((block != null) && (!(block instanceof BlockAir))) {
                        AxisAlignedBB boundingBox = block.getCollisionBoundingBox(mc.theWorld, new BlockPos(x, y, z), mc.theWorld.getBlockState(new BlockPos(x, y, z)));
                        if ((block instanceof BlockHopper)) {
                            boundingBox = new AxisAlignedBB(x, y, z, x + 1, y + 1, z + 1);
                        }
                        if (boundingBox != null) {
                            if (mc.thePlayer.boundingBox.intersectsWith(boundingBox)) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    private double getHypixelSpeed(final int stage) {
        double value = MoveUtils.defaultSpeed() + 0.028 * MoveUtils.getSpeedEffect()
                + MoveUtils.getSpeedEffect() / 15.0;
        final double firstvalue = 0.4145 + MoveUtils.getSpeedEffect() / 12.5;
        final double decr = stage / 500.0 * 2.0;
        if (stage == 0) {
            if (this.timer.delay(300.0)) {
                this.timer.reset();
            }
            if (!this.lastCheck.delay(500.0)) {
                if (!this.shouldslow) {
                    this.shouldslow = true;
                }
            } else if (this.shouldslow) {
                this.shouldslow = false;
            }
            value = 0.64 + (MoveUtils.getSpeedEffect() + 0.028 * MoveUtils.getSpeedEffect()) * 0.134;
        } else if (stage == 1) {
            value = firstvalue;
        } else if (stage >= 2) {
            value = firstvalue - decr;
        }
        if (this.shouldslow || !this.lastCheck.delay(500.0) || this.collided) {
            value = 0.2;
            if (stage == 0) {
                value = 0.0;
            }
        }
        return Math.max(value,
                this.shouldslow ? value : (MoveUtils.defaultSpeed() + 0.028 * MoveUtils.getSpeedEffect()));
    }

    private double getAACSpeed(int stage, int jumps) {
        double value = 0.29;
        double firstvalue = 0.3019;
        double thirdvalue = 0.0286 - (double) stage / 1000;
        if (stage == 0) {
            value = 0.497;
            if (jumps >= 2) {
                value += 0.1069;
            }
            if (jumps >= 3) {
                value += 0.046;
            }
            Block block = MoveUtils.getBlockUnderPlayer(mc.thePlayer, 0.01);
            if (block instanceof BlockIce || block instanceof BlockPackedIce) {
                value = 0.59;
            }
        } else if (stage == 1) {
            value = 0.3031;
            if (jumps >= 2) {
                value += 0.0642;
            }
            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 2) {
            value = 0.302;
            if (jumps >= 2) {
                value += 0.0629;
            }
            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 3) {
            value = firstvalue;
            if (jumps >= 2) {
                value += 0.0607;
            }
            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 4) {
            value = firstvalue;
            if (jumps >= 2) {
                value += 0.0584;
            }
            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 5) {
            value = firstvalue;
            if (jumps >= 2) {
                value += 0.0561;
            }
            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 6) {
            value = firstvalue;
            if (jumps >= 2) {
                value += 0.0539;
            }
            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 7) {
            value = firstvalue;
            if (jumps >= 2) {
                value += 0.0517;
            }
            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 8) {
            value = firstvalue;
            if (MoveUtils.isOnGround(0.05))
                value -= 0.002;

            if (jumps >= 2) {
                value += 0.0496;
            }
            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 9) {
            value = firstvalue;
            if (jumps >= 2) {
                value += 0.0475;
            }
            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 10) {

            value = firstvalue;
            if (jumps >= 2) {
                value += 0.0455;
            }
            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 11) {

            value = 0.3;
            if (jumps >= 2) {
                value += 0.045;
            }
            if (jumps >= 3) {
                value += 0.018;
            }

        } else if (stage == 12) {
            value = 0.301;
            if (jumps <= 2)
                aacCount = 0;
            if (jumps >= 2) {
                value += 0.042;
            }
            if (jumps >= 3) {
                value += thirdvalue + 0.001;
            }
        } else if (stage == 13) {
            value = 0.298;
            if (jumps >= 2) {
                value += 0.042;
            }
            if (jumps >= 3) {
                value += thirdvalue + 0.001;
            }
        } else if (stage == 14) {

            value = 0.297;
            if (jumps >= 2) {
                value += 0.042;
            }
            if (jumps >= 3) {
                value += thirdvalue + 0.001;
            }
        }
        if (mc.thePlayer.moveForward <= 0) {
            value -= 0.06;
        }

        if (mc.thePlayer.isCollidedHorizontally) {
            value -= 0.1;
            aacCount = 0;
        }
        return value;
    }

	static enum SpeedMode {
        Hypixel,
        LowHop,
        Onground,
        JumpHop,
    }
}
