package CopySense.module.render;

import java.util.ArrayList;
import java.util.List;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Option;
import CopySense.module.Module;
import CopySense.module.ModuleType;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class Animation 
extends Module{

	public static Mode<Enum> mode = new Mode("Mode", "Mode", (Enum[])renderMode.values(), (Enum)renderMode.Leain);
    public static Option<Boolean> smooth = new Option<Boolean>("Smooth", "Smooth", false);
    ArrayList<Entity> entities = new ArrayList();
    private static List<EntityPlayer> invalid = new ArrayList();
    private static List<EntityPlayer> removed = new ArrayList();
	public Animation() {
		super("Animations", new String[] {"BlockHitanimations"}, ModuleType.Render);
		this.addValues(this.mode,this.smooth);

	}
    @EventHandler
    private void onUpdate(EventPreUpdate e10) {
        this.setSuffix(this.mode.getValue());
    }

	public static enum renderMode {
		ETB,
		Exhibition,
		Avatar,
		Jello,
		Sigma,
		Swang,
		Swank, 
		Cross,
		Leain,
		Slide,
		External,
	}
}
