package CopySense.module.render;

import java.awt.Color;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.*;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;

import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;

import CopySense.Client;
import CopySense.api.EventHandler;
import CopySense.api.events.rendering.EventRender3D;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Option;
import CopySense.management.FriendManager;
import CopySense.management.ModuleManager;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.combat.AntiBot;
import CopySense.module.combat.KillAura;
import CopySense.utils.math.Vec3f;
import CopySense.utils.render.Colors;
import CopySense.utils.render.RenderUtil;
import CopySense.utils.render.gl.GLUtils;

public class NewESP
extends Module {
    private ArrayList<Vec3f> points = new ArrayList();
    public static Mode<Enum> mode = new Mode("Mode", "Mode", (Enum[])ESPMode.values(), (Enum)ESPMode.Flat);
    private Option<Boolean> animals = new Option<Boolean>("Animals", "Animals", false);
    private Option<Boolean> mobs = new Option<Boolean>("Mobs", "Mobs", false);
    public static Map<EntityLivingBase, double[]> entityPositionstop = new HashMap();
    public static Map<EntityLivingBase, double[]> entityPositionsbottom = new HashMap();

    public NewESP() {
        super("ESP", new String[]{"outline", "wallhack"}, ModuleType.Render);
        this.addValues(this.mode, this.animals, this.mobs);
        for (int i2 = 0; i2 < 8; ++i2) {
            this.points.add(new Vec3f());

        }
        this.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)).getRGB());
    }
    @EventHandler
    private void onUpdate(EventPreUpdate e10) {
        this.setSuffix(this.mode.getValue());
    }

    @EventHandler
    public void onRender(EventRender3D event) {
    	 if (this.mode.getValue() == ESPMode.LineBox) {
             this.doBoxESP(event);
         }
    	 if (this.mode.getValue() == ESPMode.TwoD) {
    		this.doOther2DESP();
         }
    	 if (this.mode.getValue() == ESPMode.Flat) {
    			this.doFlat();
    		}
    }

	private void doFlat() {
			/*  78 */       Iterator var2 = Minecraft.theWorld.playerEntities.iterator();
			/*  79 */       while (var2.hasNext()) {
			/*  80 */         EntityPlayer entity = (EntityPlayer)var2.next();
			/*  81 */         if (entity != Minecraft.thePlayer) {
			/*  82 */           if (!isValid(entity)) {
			/*     */             return;
			/*     */           }
			/*  85 */           GL11.glPushMatrix();
			/*  86 */           GL11.glEnable(3042);
			/*  87 */           GL11.glDisable(2929);
			/*  88 */           GL11.glNormal3f(0.0F, 1.0F, 0.0F);
			/*  89 */           GlStateManager.enableBlend();
			/*  90 */           GL11.glBlendFunc(770, 771);
			/*  91 */           GL11.glDisable(3553);
			/*  92 */           float partialTicks = this.mc.timer.renderPartialTicks;
			/*     */           
			/*  94 */           this.mc.getRenderManager(); double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - RenderManager.renderPosX;
			/*     */           
			/*  96 */           this.mc.getRenderManager(); double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - RenderManager.renderPosY;
			/*     */           
			/*  98 */           this.mc.getRenderManager(); double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - RenderManager.renderPosZ;
			/*  99 */           float DISTANCE = Minecraft.thePlayer.getDistanceToEntity(entity);
			/* 100 */           float SCALE = 0.035F;
			/* 101 */           SCALE /= 2.0F;
			/* 102 */           GlStateManager.translate((float)x, 
			/* 103 */               (float)y + entity.height + 0.5F - (entity.isChild() ? (entity.height / 2.0F) : 0.0F), (float)z);
			/* 104 */           GL11.glNormal3f(0.0F, 1.0F, 0.0F);
			/* 105 */           GlStateManager.rotate(-(this.mc.getRenderManager()).playerViewY, 0.0F, 1.0F, 0.0F);
			/* 106 */           GL11.glScalef(-SCALE, -SCALE, -SCALE);
			/* 107 */           Tessellator tesselator = Tessellator.getInstance();
			/* 108 */           WorldRenderer worldRenderer = tesselator.getWorldRenderer();
			/* 109 */           Color color = new Color(0, 210, 100);
			/* 110 */           Color gray = new Color(-13710223);
			/* 111 */           double thickness = (0.9F + DISTANCE * 0.1F);
			/* 112 */           double xLeft = -35.0D;
			/* 113 */           double xRight = 35.0D;
			/* 114 */           double yUp = 10.0D;
			/* 115 */           double yDown = 150.0D;
			/* 116 */           double size = 40.0D;
			/* 117 */           drawVerticalLine(xLeft + size / 2.0D + 1.0D, yUp + 1.0D, size / 2.0D, thickness, gray);
			/* 118 */           drawHorizontalLine(xLeft + 1.0D, yUp + size + 1.0D, size, thickness, gray);
			/* 119 */           drawVerticalLine(xRight - size / 2.0D + 1.0D, yUp + 1.0D, size / 2.0D, thickness, gray);
			/* 120 */           drawHorizontalLine(xRight + 1.0D, yUp + size + 1.0D, size, thickness, gray);
			/* 121 */           drawVerticalLine(xLeft + size / 2.0D + 1.0D, yDown + 1.0D, size / 2.0D, thickness, gray);
			/* 122 */           drawHorizontalLine(xLeft + 1.0D, yDown + 1.0D - size, size, thickness, gray);
			/* 123 */           drawVerticalLine(xRight - size / 2.0D + 1.0D, yDown + 1.0D, size / 2.0D, thickness, gray);
			/* 124 */           drawHorizontalLine(xRight + 1.0D, yDown - size + 1.0D, size, thickness, gray);
			/* 125 */           GL11.glEnable(3553);
			/* 126 */           GL11.glEnable(2929);
			/* 127 */           GlStateManager.disableBlend();
			/* 128 */           GL11.glDisable(3042);
			/* 129 */           GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
			/* 130 */           GL11.glNormal3f(1.0F, 1.0F, 1.0F);
			/* 131 */           GL11.glPopMatrix();
			/*     */          
			/*     */       }
			/*     */     } 
        }
	
	private void doOther2DESP() {
        for (EntityPlayer entity : this.mc.theWorld.playerEntities) {
            if (isValid(entity)) {
                GL11.glPushMatrix();
                GL11.glEnable(3042);
                GL11.glDisable(2929);
                GL11.glNormal3f(0.0f, 1.0f, 0.0f);
                GlStateManager.enableBlend();
                GL11.glBlendFunc(770, 771);
                GL11.glDisable(3553);
                float partialTicks = mc.timer.renderPartialTicks;
                this.mc.getRenderManager();
                double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * partialTicks - RenderManager.renderPosX;
                this.mc.getRenderManager();
                double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * partialTicks - RenderManager.renderPosY;
                this.mc.getRenderManager();
                double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * partialTicks - RenderManager.renderPosZ;
                float DISTANCE = this.mc.thePlayer.getDistanceToEntity(entity);
                float DISTANCE_SCALE = Math.min(DISTANCE * 0.15f, 0.15f);
                float SCALE = 0.035f;
                SCALE /= 2.0f;
                float xMid = (float)x;
                float yMid = (float)y + entity.height + 0.5f - (entity.isChild() ? (entity.height / 2.0f) : 0.0f);
                float zMid = (float)z;
                GlStateManager.translate((float)x, (float)y + entity.height + 0.5f - (entity.isChild() ? (entity.height / 2.0f) : 0.0f), (float)z);
                GL11.glNormal3f(0.0f, 1.0f, 0.0f);
                GlStateManager.rotate(-this.mc.getRenderManager().playerViewY, 0.0f, 1.0f, 0.0f);
                GL11.glScalef(-SCALE, -SCALE, -SCALE);
                Tessellator tesselator = Tessellator.getInstance();
                WorldRenderer worldRenderer = tesselator.getWorldRenderer();
                float HEALTH = entity.getHealth();
                int COLOR = -1;
                if (HEALTH > 20.0) {
                    COLOR = -65292;
                }
                else if (HEALTH >= 10.0) {
                    COLOR = -16711936;
                }
                else if (HEALTH >= 3.0) {
                    COLOR = -23296;
                }
                else {
                    COLOR = -65536;
                }
                Color gray = new Color(0, 0, 0);
                double thickness = 1.5f + DISTANCE * 0.01f;
                double xLeft = -20.0;
                double xRight = 20.0;
                double yUp = 27.0;
                double yDown = 130.0;
                double size = 10.0;
                Color color = new Color(255, 255, 255);
                if (entity.hurtTime > 0) {
                    color = new Color(255, 0, 0);
                } else if(entity.isInvisible()) {
                }
                drawBorderedRect((float)xLeft, (float)yUp, (float)xRight, (float)yDown, (float)thickness + 0.5f, Colors.BLACK.c, 0);
                drawBorderedRect((float)xLeft, (float)yUp, (float)xRight, (float)yDown, (float)thickness, color.getRGB(), 0);
                drawBorderedRect((float)xLeft - 3.0f - DISTANCE * 0.2f, (float)yDown - (float)(yDown - yUp), (float)xLeft - 2.0f, (float)yDown, 0.15f, Colors.BLACK.c, new Color(100, 100, 100).getRGB());
                drawBorderedRect((float)xLeft - 3.0f - DISTANCE * 0.2f, (float)yDown - (float)(yDown - yUp) * Math.min(1.0f, entity.getHealth() / 20.0f), (float)xLeft - 2.0f, (float)yDown, 0.15f, Colors.BLACK.c, COLOR);
                GL11.glEnable(3553);
                GL11.glEnable(2929);
                GlStateManager.disableBlend();
                GL11.glDisable(3042);
                GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
                GL11.glNormal3f(1.0f, 1.0f, 1.0f);
                GL11.glPopMatrix();
            }
        }
        }
	
    private double[] convertTo2D(double x, double y, double z, Entity ent) {
        return convertTo2D(x, y, z);
    }
    private double[] convertTo2D(double x, double y, double z) {
        FloatBuffer screenCoords = BufferUtils.createFloatBuffer(3);
        IntBuffer viewport = BufferUtils.createIntBuffer(16);
        FloatBuffer modelView = BufferUtils.createFloatBuffer(16);
        FloatBuffer projection = BufferUtils.createFloatBuffer(16);
        GL11.glGetFloat(2982, modelView);
        GL11.glGetFloat(2983, projection);
        GL11.glGetInteger(2978, viewport);
        boolean result = GLU.gluProject((float) x, (float) y, (float) z, modelView, projection, viewport, screenCoords);
        if (result) {
            return new double[]{screenCoords.get(0), Display.getHeight() - screenCoords.get(1), screenCoords.get(2)};
        }
        return null;
    }

	public static void rectangleBordered(final double x, final double y, final double x1, final double y1, final double width, final int internalColor, final int borderColor) {
        rectangle(x + width, y + width, x1 - width, y1 - width, internalColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        rectangle(x + width, y, x1 - width, y + width, borderColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        rectangle(x, y, x + width, y1, borderColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        rectangle(x1 - width, y, x1, y1, borderColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        rectangle(x + width, y1 - width, x1 - width, y1, borderColor);
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
    }
	public static void rectangle(double left, double top, double right, double bottom, int color)
	  {
	    if (left < right)
	    {
	      double var5 = left;
	      left = right;
	      right = var5;
	    }
	    if (top < bottom)
	    {
	      double var5 = top;
	      top = bottom;
	      bottom = var5;
	    }
	    float var11 = (color >> 24 & 0xFF) / 255.0F;
	    float var6 = (color >> 16 & 0xFF) / 255.0F;
	    float var7 = (color >> 8 & 0xFF) / 255.0F;
	    float var8 = (color & 0xFF) / 255.0F;
	    Tessellator tessellator = Tessellator.getInstance();
	    WorldRenderer worldRenderer = tessellator.getWorldRenderer();
	    GlStateManager.enableBlend();
	    GlStateManager.disableTexture2D();
	    GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
	    GlStateManager.color(var6, var7, var8, var11);
	    worldRenderer.begin(7, DefaultVertexFormats.POSITION);
	    worldRenderer.pos(left, bottom, 0.0D).endVertex();
	    worldRenderer.pos(right, bottom, 0.0D).endVertex();
	    worldRenderer.pos(right, top, 0.0D).endVertex();
	    worldRenderer.pos(left, top, 0.0D).endVertex();
	    tessellator.draw();
	    GlStateManager.enableTexture2D();
	    GlStateManager.disableBlend();
	    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
	  }


    public static void drawBorderedRect(float x, float y, float x2, float y2, float l1, int col1, int col2) {
	      drawRect(x, y, x2, y2, col2);
	      float f = (float)(col1 >> 24 & 255) / 255.0F;
	      float f1 = (float)(col1 >> 16 & 255) / 255.0F;
	      float f2 = (float)(col1 >> 8 & 255) / 255.0F;
	      float f3 = (float)(col1 & 255) / 255.0F;
	      GL11.glEnable(3042);
	      GL11.glDisable(3553);
	      GL11.glBlendFunc(770, 771);
	      GL11.glEnable(2848);
	      GL11.glPushMatrix();
	      GL11.glColor4f(f1, f2, f3, f);
	      GL11.glLineWidth(l1);
	      GL11.glBegin(1);
	      GL11.glVertex2d((double)x, (double)y);
	      GL11.glVertex2d((double)x, (double)y2);
	      GL11.glVertex2d((double)x2, (double)y2);
	      GL11.glVertex2d((double)x2, (double)y);
	      GL11.glVertex2d((double)x, (double)y);
	      GL11.glVertex2d((double)x2, (double)y);
	      GL11.glVertex2d((double)x, (double)y2);
	      GL11.glVertex2d((double)x2, (double)y2);
	      GL11.glEnd();
	      GL11.glPopMatrix();
	      GL11.glEnable(3553);
	      GL11.glDisable(3042);
	      GL11.glDisable(2848);
	   }

    public static void drawRect(float g, float h, float i, float j, int col1) {
	      float f = (float)(col1 >> 24 & 255) / 255.0F;
	      float f1 = (float)(col1 >> 16 & 255) / 255.0F;
	      float f2 = (float)(col1 >> 8 & 255) / 255.0F;
	      float f3 = (float)(col1 & 255) / 255.0F;
	      GL11.glEnable(3042);
	      GL11.glDisable(3553);
	      GL11.glBlendFunc(770, 771);
	      GL11.glEnable(2848);
	      GL11.glPushMatrix();
	      GL11.glColor4f(f1, f2, f3, f);
	      GL11.glBegin(7);
	      GL11.glVertex2d((double)i, (double)h);
	      GL11.glVertex2d((double)g, (double)h);
	      GL11.glVertex2d((double)g, (double)j);
	      GL11.glVertex2d((double)i, (double)j);
	      GL11.glEnd();
	      GL11.glPopMatrix();
	      GL11.glEnable(3553);
	      GL11.glDisable(3042);
	      GL11.glDisable(2848);
	}

	private void doCornerESP() {
        Iterator var2 = Minecraft.theWorld.playerEntities.iterator();

        while(var2.hasNext()) {
           EntityPlayer entity = (EntityPlayer)var2.next();
           Minecraft var10001 = mc;
           if(entity != Minecraft.thePlayer) {
              if(!this.isValid(entity)) {
                 return;
              }

              GL11.glPushMatrix();
              GL11.glEnable(3042);
              GL11.glDisable(2929);
              GL11.glNormal3f(0.0F, 1.0F, 0.0F);
              GlStateManager.enableBlend();
              GL11.glBlendFunc(770, 771);
              GL11.glDisable(3553);
              float partialTicks = mc.timer.renderPartialTicks;
              double var29 = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)partialTicks;
              mc.getRenderManager();
              double x = var29 - RenderManager.renderPosX;
              var29 = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)partialTicks;
              mc.getRenderManager();
              double y = var29 - RenderManager.renderPosY;
              var29 = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)partialTicks;
              mc.getRenderManager();
              double z = var29 - RenderManager.renderPosZ;
              float DISTANCE = Minecraft.thePlayer.getDistanceToEntity(entity);
              float DISTANCE_SCALE = Math.min(DISTANCE * 0.15F, 2.5F);
              float SCALE = 0.035F;
              SCALE /= 2.0F;
              GlStateManager.translate((float)x, (float)y + entity.height + 0.5F - (entity.isChild()?entity.height / 2.0F:0.0F), (float)z);
              GL11.glNormal3f(0.0F, 1.0F, 0.0F);
              GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
              GL11.glScalef(-SCALE, -SCALE, -SCALE);
              Tessellator tesselator = Tessellator.getInstance();
              WorldRenderer worldRenderer = tesselator.getWorldRenderer();
              Color color = new Color(Colors.WHITE.c);
              if(entity.hurtTime > 0) {
                 color = new Color(Colors.BLUE.c);
              } else if(entity == KillAura.curTarget && ModuleManager.getModuleByName("KillKillAura").isEnabled()) {
                 color = new Color(Colors.RED.c);
              }

              Color gray = new Color(0, 0, 0);
              double thickness = (double)(2.0F + DISTANCE * 0.08F);
              double xLeft = -30.0D;
              double xRight = 30.0D;
              double yUp = 20.0D;
              double yDown = 130.0D;
              double size = 10.0D;
              this.drawVerticalLine(xLeft + size / 2.0D - 1.0D, yUp + 1.0D, size / 2.0D, thickness, gray);
              this.drawHorizontalLine(xLeft + 1.0D, yUp + size, size, thickness, gray);
              this.drawVerticalLine(xLeft + size / 2.0D - 1.0D, yUp, size / 2.0D, thickness, color);
              this.drawHorizontalLine(xLeft, yUp + size, size, thickness, color);
              this.drawVerticalLine(xRight - size / 2.0D + 1.0D, yUp + 1.0D, size / 2.0D, thickness, gray);
              this.drawHorizontalLine(xRight - 1.0D, yUp + size, size, thickness, gray);
              this.drawVerticalLine(xRight - size / 2.0D + 1.0D, yUp, size / 2.0D, thickness, color);
              this.drawHorizontalLine(xRight, yUp + size, size, thickness, color);
              this.drawVerticalLine(xLeft + size / 2.0D - 1.0D, yDown - 1.0D, size / 2.0D, thickness, gray);
              this.drawHorizontalLine(xLeft + 1.0D, yDown - size, size, thickness, gray);
              this.drawVerticalLine(xLeft + size / 2.0D - 1.0D, yDown, size / 2.0D, thickness, color);
              this.drawHorizontalLine(xLeft, yDown - size, size, thickness, color);
              this.drawVerticalLine(xRight - size / 2.0D + 1.0D, yDown - 1.0D, size / 2.0D, thickness, gray);
              this.drawHorizontalLine(xRight - 1.0D, yDown - size, size, thickness, gray);
              this.drawVerticalLine(xRight - size / 2.0D + 1.0D, yDown, size / 2.0D, thickness, color);
              this.drawHorizontalLine(xRight, yDown - size, size, thickness, color);
              GL11.glEnable(3553);
              GL11.glEnable(2929);
              GlStateManager.disableBlend();
              GL11.glDisable(3042);
              GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
              GL11.glNormal3f(1.0F, 1.0F, 1.0F);
              GL11.glPopMatrix();
           }
        }

     }


	private void doBoxESP(EventRender3D event) {
        GL11.glBlendFunc(770, 771);
        GL11.glEnable(3042);
        GL11.glEnable(2848);
        GL11.glLineWidth(2.0f);
        GL11.glDisable(3553);
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        for (Object o2 : this.mc.theWorld.loadedEntityList) {
            if (!(o2 instanceof EntityPlayer) || o2 == Minecraft.thePlayer) continue;
            EntityPlayer ent = (EntityPlayer)o2;
            if (ent.hurtTime > 0) {
                RenderUtil.entityESPBox(ent, new Color(255, 0, 0), event);
                continue;
            }
            if (ent.isInvisible()) {
                continue;
            }
            AntiBot ab2 = (AntiBot)Client.getModuleManager().getModuleByClass(AntiBot.class);
            RenderUtil.entityESPBox(ent, new Color(255, 255, 255), event);
        }
        GL11.glDisable(2848);
        GL11.glEnable(3553);
        GL11.glEnable(2929);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
    }
	
    public static void glColor(int hex) {
        float alpha = (hex >> 24 & 0xFF) / 255.0F;
        float red = (hex >> 16 & 0xFF) / 255.0F;
        float green = (hex >> 8 & 0xFF) / 255.0F;
        float blue = (hex & 0xFF) / 255.0F;
        GL11.glColor4f(red, green, blue, alpha);
    }

    public void renderBox(Entity entity, double r, double g, double b)
    {
      double x = RenderUtil.interpolation(entity.posX, entity.lastTickPosX);
      double y = RenderUtil.interpolation(entity.posY, entity.lastTickPosY);
      double z = RenderUtil.interpolation(entity.posZ, entity.lastTickPosZ);
      GL11.glPushMatrix();
      RenderUtil.pre();
      GL11.glLineWidth(1.0F);
      GL11.glEnable(2848);
      GL11.glColor3d(r, g, b);
      Minecraft.getMinecraft().getRenderManager();
      Minecraft.getMinecraft().getRenderManager();
      Minecraft.getMinecraft().getRenderManager();
      



      this.mc.getRenderManager();
      this.mc.getRenderManager();
      this.mc.getRenderManager();
      this.mc.getRenderManager();
      this.mc.getRenderManager();
      this.mc.getRenderManager();
      RenderGlobal.drawSelectionBoundingBox(new AxisAlignedBB(entity.boundingBox.minX - 0.05D - entity.posX + (entity.posX - RenderManager.renderPosX), entity.boundingBox.minY - entity.posY + (entity.posY - RenderManager.renderPosY), entity.boundingBox.minZ - 0.05D - entity.posZ + (entity.posZ - RenderManager.renderPosZ), entity.boundingBox.maxX + 0.05D - entity.posX + (entity.posX - RenderManager.renderPosX), entity.boundingBox.maxY + 0.1D - entity.posY + (entity.posY - RenderManager.renderPosY), entity.boundingBox.maxZ + 0.05D - entity.posZ + (entity.posZ - RenderManager.renderPosZ)));
      GL11.glDisable(2848);
      RenderUtil.post();
      GL11.glPopMatrix();
    }

	private void render(Entity entity) {
        RenderManager renderManager = this.mc.getRenderManager();
        Vec3f offset = entity.interpolate(this.mc.timer.renderPartialTicks).sub(entity.getPos()).add(0.0, 0.1, 0.0);
        if (!entity.isInvisible()) {
            AxisAlignedBB bb2 = entity.getEntityBoundingBox().offset(offset.getX() - RenderManager.renderPosX, offset.getY() - RenderManager.renderPosY, offset.getZ() - RenderManager.renderPosZ);
            this.points.get(0).setX(bb2.minX).setY(bb2.minY).setZ(bb2.minZ);
            this.points.get(1).setX(bb2.maxX).setY(bb2.minY).setZ(bb2.minZ);
            this.points.get(2).setX(bb2.maxX).setY(bb2.minY).setZ(bb2.maxZ);
            this.points.get(3).setX(bb2.minX).setY(bb2.minY).setZ(bb2.maxZ);
            this.points.get(4).setX(bb2.minX).setY(bb2.maxY).setZ(bb2.minZ);
            this.points.get(5).setX(bb2.maxX).setY(bb2.maxY).setZ(bb2.minZ);
            this.points.get(6).setX(bb2.maxX).setY(bb2.maxY).setZ(bb2.maxZ);
            this.points.get(7).setX(bb2.minX).setY(bb2.maxY).setZ(bb2.maxZ);
            float left = Float.MAX_VALUE;
            float right = 0.0f;
            float top = Float.MAX_VALUE;
            float bottom = 0.0f;
            for (Vec3f living : this.points) {
                Vec3f screen = living.toScreen();
                if (!(screen.getZ() >= 0.0) || !(screen.getZ() < 1.0)) continue;
                if (screen.getX() < (double)left) {
                    left = (float)screen.getX();
                }
                if (screen.getY() < (double)top) {
                    top = (float)screen.getY();
                }
                if (screen.getX() > (double)right) {
                    right = (float)screen.getX();
                }
                if (!(screen.getY() > (double)bottom)) continue;
                bottom = (float)screen.getY();
            }
            if (bottom > 1.0f || right > 1.0f) {
                this.box(left, top, right, bottom);
                this.name(entity, left, top, right, bottom);
                if (entity instanceof EntityLivingBase) {
                    EntityLivingBase living1 = (EntityLivingBase)entity;
                    this.health(living1, left, top, right, bottom);
                }
            }
        }
    }

    private static void drawVerticalLine(double xPos, double yPos, double xSize, double thickness, Color color) {
        Tessellator tesselator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tesselator.getWorldRenderer();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        worldRenderer.pos(xPos - xSize, yPos - thickness / 2.0, 0.0).color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f).endVertex();
        worldRenderer.pos(xPos - xSize, yPos + thickness / 2.0, 0.0).color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f).endVertex();
        worldRenderer.pos(xPos + xSize, yPos + thickness / 2.0, 0.0).color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f).endVertex();
        worldRenderer.pos(xPos + xSize, yPos - thickness / 2.0, 0.0).color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f).endVertex();
        tesselator.draw();
    }

    private void drawHorizontalLine(double xPos, double yPos, double ySize, double thickness, Color color) {
        Tessellator tesselator = Tessellator.getInstance();
        WorldRenderer worldRenderer = tesselator.getWorldRenderer();
        worldRenderer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        worldRenderer.pos(xPos - thickness / 2.0, yPos - ySize, 0.0).color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f).endVertex();
        worldRenderer.pos(xPos - thickness / 2.0, yPos + ySize, 0.0).color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f).endVertex();
        worldRenderer.pos(xPos + thickness / 2.0, yPos + ySize, 0.0).color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f).endVertex();
        worldRenderer.pos(xPos + thickness / 2.0, yPos - ySize, 0.0).color((float)color.getRed() / 255.0f, (float)color.getGreen() / 255.0f, (float)color.getBlue() / 255.0f, (float)color.getAlpha() / 255.0f).endVertex();
        tesselator.draw();
    }

    private void box(float left, float top, float right, float bottom) {
        GL11.glColor4d(1.0, 1.0, 1.0, 0.5);
        RenderUtil.drawLine(left, top, right, top, 2.0f);
        RenderUtil.drawLine(left, bottom, right, bottom, 2.0f);
        RenderUtil.drawLine(left, top, left, bottom, 2.0f);
        RenderUtil.drawLine(right, top, right, bottom, 2.0f);
        RenderUtil.drawLine(left + 1.0f, top + 1.0f, right - 1.0f, top + 1.0f, 1.0f);
        RenderUtil.drawLine(left + 1.0f, bottom - 1.0f, right - 1.0f, bottom - 1.0f, 1.0f);
        RenderUtil.drawLine(left + 1.0f, top + 1.0f, left + 1.0f, bottom - 1.0f, 1.0f);
        RenderUtil.drawLine(right - 1.0f, top + 1.0f, right - 1.0f, bottom - 1.0f, 1.0f);
        RenderUtil.drawLine(left - 1.0f, top - 1.0f, right + 1.0f, top - 1.0f, 1.0f);
        RenderUtil.drawLine(left - 1.0f, bottom + 1.0f, right + 1.0f, bottom + 1.0f, 1.0f);
        RenderUtil.drawLine(left - 1.0f, top + 1.0f, left - 1.0f, bottom + 1.0f, 1.0f);
        RenderUtil.drawLine(right + 1.0f, top - 1.0f, right + 1.0f, bottom + 1.0f, 1.0f);
    }

    private void name(Entity entity, float left, float top, float right, float bottom) {
        this.mc.fontRendererObj.drawCenteredString(FriendManager.isFriend(entity.getName()) ? "\u00a7b" + FriendManager.getAlias(entity.getName()) : entity.getName(), (int)(left + right) / 2, (int)(top - (float)this.mc.fontRendererObj.FONT_HEIGHT - 2.0f + 1.0f), -1);
        if (((EntityPlayer)entity).getCurrentEquippedItem() != null) {
            String stack = ((EntityPlayer)entity).getCurrentEquippedItem().getDisplayName();
            this.mc.fontRendererObj.drawCenteredString(stack, (int)(left + right) / 2, (int)bottom, -1);
        }
    }

    private void health(EntityLivingBase entity, float left, float top, float right, float bottom) {
        float height = bottom - top;
        float currentHealth = entity.getHealth();
        float maxHealth = entity.getMaxHealth();
        float healthPercent = currentHealth / maxHealth;
        GLUtils.glColor(this.getHealthColor(entity));
        RenderUtil.drawLine(left - 5.0f, top + height * (1.0f - healthPercent) + 1.0f, left - 5.0f, bottom, 2.0f);
    }

    private int getHealthColor(EntityLivingBase player) {
        float f2 = player.getHealth();
        float f1 = player.getMaxHealth();
        float f22 = Math.max(0.0f, Math.min(f2, f1) / f1);
        return Color.HSBtoRGB(f22 / 3.0f, 1.0f, 1.0f) | -16777216;
    }

    private boolean isValid(EntityLivingBase entity) {
        if (entity == Minecraft.thePlayer) {
            return false;
        }
        if (entity.getHealth() <= 0.0f) {
            return false;
        }
        if (entity instanceof EntityPlayer) {
            return true;
        }
        if (entity instanceof EntityAnimal && ((Boolean)this.animals.getValue()).booleanValue()) {
            return true;
        }
        return entity instanceof EntityMob && (Boolean)this.mobs.getValue() != false;
    }

    public static enum ESPMode {
        Outline,
        TwoD,
        Flat,
        LineBox
    }
        


}

