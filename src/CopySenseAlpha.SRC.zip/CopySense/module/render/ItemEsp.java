package CopySense.module.render;

import org.lwjgl.opengl.GL11;


import CopySense.api.EventHandler;
import CopySense.api.events.rendering.EventRender3D;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.utils.render.RenderUtil;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.util.AxisAlignedBB;

public class ItemEsp extends Module {

	public ItemEsp() {
		super("ItemESP", new String[]{"ItemESP"}, ModuleType.Render);
        this.setRemoved(true);
	}
	
	@EventHandler
	public void onRender(EventRender3D event) {
		for (Object o : mc.theWorld.loadedEntityList) {
    		if (!(o instanceof EntityItem)) continue;
    		EntityItem item = (EntityItem)o;
 		   	double var10000 = item.posX;
 		   	Minecraft.getMinecraft().getRenderManager();
 		   	double x = var10000 - RenderManager.renderPosX;
 		   	var10000 = item.posY + 0.5D;
 		   	Minecraft.getMinecraft().getRenderManager();
 		   	double y = var10000 - RenderManager.renderPosY;
 		   	var10000 = item.posZ;
 		   	Minecraft.getMinecraft().getRenderManager();
 		   	double z = var10000 - RenderManager.renderPosZ;
 		   	GL11.glEnable(3042);
 		   	GL11.glLineWidth(2.0F);
 		   	GL11.glColor4f(1, 1, 1, .75F);
 		   	GL11.glDisable(3553);
 		   	GL11.glDisable(2929);
 		   	GL11.glDepthMask(false);
 	   		RenderUtil.drawOutlinedBoundingBox(new AxisAlignedBB(x - .2D, y - 0.3d, z - .2D, x + .2D, y - 0.4d, z + .2D));
 	   		GL11.glColor4f(1, 1, 1, 0.15f);
 	   		RenderUtil.drawBoundingBox(new AxisAlignedBB(x - .2D, y - 0.3d, z - .2D, x + .2D, y - 0.4d, z + .2D));
 	   		GL11.glEnable(3553);
 	   		GL11.glEnable(2929);
 	   		GL11.glDepthMask(true);
 	   		GL11.glDisable(3042);
    	}
	}
}
