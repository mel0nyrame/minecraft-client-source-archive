package CopySense.module.render;

import java.awt.Color;

import CopySense.api.EventHandler;
import CopySense.api.events.world.EventTick;
import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.ui.ClickGUI2.ClickyUI;
import CopySense.ui.ClickGui.NewClickGui;
import net.minecraft.client.Minecraft;

public class ClickGUI
        extends Module {
    public static boolean rainbow;
    public static int rainbowcolor;
    public static Mode<Enum> sbb = new Mode("BoxMode", "BoxMode", (Enum[])SBMode.values(), (Enum)SBMode.Novoline);
   
    public ClickGUI() {
        super("ClickGUI", new String[]{"clickui"}, ModuleType.Render);
        this.addValues(this.sbb);
    }

    @Override
    public void onEnable() {
    	if(sbb.getValue()==SBMode.Novoline) {
       mc.displayGuiScreen(new NewClickGui());
    	} if(sbb.getValue()==SBMode.LGG) {
    	       mc.displayGuiScreen(new ClickyUI());
    	    	}
        this.setEnabled(false);
        super.onEnable();
    }

    @EventHandler
    public void onTick(EventTick e) {
        int rainbowTick = 0;
        Color rainbow = new Color(Color.HSBtoRGB((float)((double)Minecraft.getMinecraft().thePlayer.ticksExisted / 50.0 + Math.sin((double)rainbowTick / 50.0 * 1.6)) % 1.0f, 0.5f, 1.0f));
    }

    public void onDisable() {
        super.onDisable();
    }
    
    enum SBMode {
    	Novoline, LGG
    }
}