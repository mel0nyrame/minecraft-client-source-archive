package CopySense.module.render;

import CopySense.Client;
import CopySense.api.EventHandler;
import CopySense.api.events.rendering.EventRender2D;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.combat.KillAura;
import CopySense.ui.font.CFontRenderer;
import CopySense.ui.font.FontLoaders;
import CopySense.utils.R3DUtil;
import CopySense.utils.render.Colors;
import CopySense.utils.render.RenderUtil;

import java.awt.Color;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class TargetHUD
extends Module {
    public static boolean shouldMove;
    public static boolean useFont;
    private Mode<Enum> mode = new Mode("Mode", "mode", (Enum[])rendermode.values(), (Enum)rendermode.Basic);
	private Numbers<Double> posx = new Numbers<Double>("BasicX","BasicX", 0.0, 1.0, 500.0, 2.0);
	private Numbers<Double> posy = new Numbers<Double>("BasicY","BasicY", 00.0, 1.0, 500.0, 2.0);
	private double x;
	double anima1 = 0.0;
	double anima2 = 0.0;
	public TargetHUD() {
		super("TargetHUD", new String[] { "targethud" }, ModuleType.Render);
        this.addValues(this.mode,this.posx,this.posy);
	}
    @EventHandler
    private void onUpdate(EventPreUpdate e10) {
        this.setSuffix(this.mode.getValue());
    }

	@EventHandler
	public void onRender(EventRender2D event) {
		if(this.mode.getValue() == rendermode.Basic) {
			if (KillAura.curTarget != null) {
				final EntityLivingBase player = (EntityLivingBase) KillAura.curTarget;
				ScaledResolution sr = new ScaledResolution(mc);
				float height = new ScaledResolution(mc).getScaledHeight();
				float width = new ScaledResolution(mc).getScaledWidth();
				float PosX = (posx.getValue()).floatValue();
				float PosY = (posy.getValue()).floatValue();
				DecimalFormat df = new DecimalFormat("#0.0");
				String ong;
				if(KillAura.curTarget.onGround){
					ong = "On";
				} else {
					ong = "Off";
				}
				final String str = String.format("HP: %s Armor: %s",df.format(KillAura.curTarget.getHealth()),KillAura.curTarget.getTotalArmorValue());
				final String str1 = String.format("Ground: %s Hurt: %s ",ong,df.format(player.hurtTime));
				CFontRenderer font = FontLoaders.kiona18;
				GlStateManager.pushMatrix();
				Gui.drawRect((width / 2) + PosX, (height / 2) + PosY, (width / 2) +120 + PosX, (height / 2) + 65 + PosY, new Color(50, 50, 50).getRGB());
				Gui.drawRect((width / 2) - 2+ PosX, (height / 2)  - 2 + PosY, (width / 2) + 122 + PosX, (height / 2) + 68 + PosY, new Color(50, 50, 50).getRGB());
				Gui.drawRect((width / 2) - 1 + PosX, (height / 2) + PosY, (width / 2) + 121 + PosX, (height / 2) - 1.5  + PosY, new Color(30,30,30).getRGB());
				Gui.drawRect((width / 2) - 1 + PosX, (height / 2) + 65 + PosY, (width / 2) + 121 + PosX, (height / 2) + 66.5 + PosY, new Color(30,30,30).getRGB());
				Gui.drawRect((width / 2) - 1 + PosX, (height / 2) - 1 + PosY, (width / 2)  + PosX, (height / 2) + 66  + PosY, new Color(30,30,30).getRGB());
				Gui.drawRect((width / 2) + 120 + PosX, (height / 2) - 1 + PosY, (width / 2)  + 121 + PosX, (height / 2) + 66  + PosY, new Color(30,30,30).getRGB());
				Gui.drawRect((width / 2) + 0.9F + PosX, (height / 2) + 1 + PosY, (width / 2)  + 119 + PosX, (height / 2) + 2 + PosY, new Color(66,255,66).getRGB());
				if (this.anima1 <= (double)(KillAura.curTarget.getHealth() * 5.95f)) {
					this.anima1 += 2.5;
				}
				if (this.anima1 > (double)(KillAura.curTarget.getHealth() * 5.95f)) {
					this.anima1 -= 2.5;
				}
				if (this.anima2 <= (double)(KillAura.curTarget.getHealth() * 5.95f)) {
					this.anima2 += 1.0;
				}
				if (this.anima2 > (double)(KillAura.curTarget.getHealth() * 5.95f)) {
					this.anima2 -= 1.0;
				}
				Gui.drawRect((width / 2) + 0.5F + PosX, (height / 2) + 64 + PosY, (width / 2) + 119 + PosX , (height / 2) + 62.5F + PosY,new Color(25,25,25).getRGB());
				Gui.drawRect((width / 2) + 0.5F + PosX, (height / 2) + 64 + PosY, ((width/2)+PosX) + (int)this.anima2, (height / 2) + 62.5F + PosY, new Color(200,88,11).getRGB());
				RenderUtil.drawRainbowRect((width / 2) + 0.5F + PosX, (height / 2) + 64 + PosY, ((width/2)+PosX) + (int)this.anima1, (height / 2) + 62.5F + PosY);
				float abab = KillAura.curTarget.getHealth();
				if(abab>14) {
					font.drawStringWithShadow(KillAura.curTarget.getName(), (width / 2) + PosX + 28, (height / 2) + PosY + 6, new Color(0, 225, 21).getRGB());
				} if(abab<14&&abab>7) {
					font.drawStringWithShadow(KillAura.curTarget.getName(), (width / 2) + PosX + 28, (height / 2) + PosY + 6, new Color(225, 111, 22).getRGB());
				} if(abab<7&&abab>0) {
					font.drawStringWithShadow(KillAura.curTarget.getName(), (width / 2) + PosX + 28, (height / 2) + PosY + 6, new Color(225, 0, 19).getRGB());
				}
				FontLoaders.kiona16.drawStringWithShadow("[Loxi]",(width / 2)+PosX+font.getStringWidth(KillAura.curTarget.getName())+29,(height / 2)+PosY+6,new Color(6, 224, 225).getRGB());
				FontLoaders.kiona16.drawStringWithShadow(str,(width / 2)+PosX+28,(height / 2)+PosY+17,new Color(255,255,255).getRGB());
				FontLoaders.kiona16.drawStringWithShadow(str1,(width / 2)+PosX+29,(height / 2)+PosY+27,new Color(255,255,255).getRGB());
				RenderHelper.enableGUIStandardItemLighting();
				R3DUtil.drawEntityOnScreen((int)((width/2)+15)+(int)PosX, (int)((height/2) + 60)+(int)PosY, (int)22, (float) KillAura.curTarget.getRotationYawHead(), (float)KillAura.curTarget.getYOffset(), (EntityLivingBase)((EntityLivingBase)KillAura.curTarget));
					if(KillAura.curTarget.getHeldItem() != null) {
              		Minecraft.getMinecraft().getRenderItem().renderItemAndEffectIntoGUI(KillAura.curTarget.getHeldItem(), (int) ((width / 2) + PosX) + 30, (int) ((height / 2) + PosY) + 40);
				}
				RenderHelper.disableStandardItemLighting();
				GlStateManager.popMatrix();
				final List<ItemStack> stuff = new ArrayList<ItemStack>();
				for (int index = 3; index >= 0; --index) {
					final ItemStack armer = KillAura.curTarget.getCurrentArmor(index);
					if (armer != null) {
						stuff.add(armer);
					}
				}
				int split = 0;
				int split1 = 0;
				for (final ItemStack errything : stuff) {
					if (mc.theWorld != null) {
						RenderHelper.enableGUIStandardItemLighting();
						split -= 16;
						split1 -= 6;
					}
					GL11.glPushMatrix();
					RenderHelper.enableGUIStandardItemLighting();
					if(errything != null) {
						Minecraft.getMinecraft().getRenderItem().renderItemAndEffectIntoGUI(errything, (int) ((width / 2) + PosX) + 114 + split, (int) ((height / 2) + PosY) + 40);
					}
					RenderHelper.disableStandardItemLighting();
					if(KillAura.curTarget.getHeldItem() != null) {
						if (errything != null) {
							Gui.drawRect((width / 2) + 28 + PosX, (height / 2) + 37 + PosY, (width / 2) + 117 + PosX, (height / 2) + 59 + PosY, new Color(0, 0, 0).getRGB());
							Gui.drawRect((width / 2) + 29 + PosX, (height / 2) + 38 + PosY, (width / 2) + 116 + PosX, (height / 2) + 58 + PosY, new Color(39, 37, 38).getRGB());
							Gui.drawRect((width / 2) + 48 + PosX, (height / 2) + 40 + PosY, (width / 2) + 48.5F + PosX, (height / 2) + 56 + PosY, new Color(0, 0, 0).getRGB());
					}
					}
					GL11.glPopMatrix();
				}
			}
		}

	if(this.mode.getValue() == rendermode.Debug){
		ScaledResolution sr = new ScaledResolution(mc);
		final FontRenderer font2 = mc.fontRendererObj;
		if (KillAura.curTarget != null && Client.instance.getModuleManager().getModuleByClass(TargetHUD.class).isEnabled()
				& Client.instance.getModuleManager().getModuleByClass(KillAura.class).isEnabled()) {
			final String name = KillAura.curTarget.getName();
			font2.drawStringWithShadow(name, (float) (sr.getScaledWidth() / 2) - (font2.getStringWidth(name) / 2),
					(float) (sr.getScaledHeight() / 2 - 30), -1);
			Minecraft.getMinecraft().getTextureManager().bindTexture(new ResourceLocation("textures/gui/icons.png"));
			int i = 0;
			while ((float) i < KillAura.curTarget.getMaxHealth() / 2.0f) {
				Minecraft.getMinecraft().ingameGUI.drawTexturedModalRect((float) (sr.getScaledWidth() / 2)
						- KillAura.curTarget.getMaxHealth() / 2.0f * 10.0f / 2.0f + (float) (i * 10),
						(float) (sr.getScaledHeight() / 2 - 16), 16, 0, 9, 9);
				++i;
			}
			i = 0;
			while ((float) i < KillAura.curTarget.getHealth() / 2.0f) {
				Minecraft.getMinecraft().ingameGUI.drawTexturedModalRect((float) (sr.getScaledWidth() / 2)
						- KillAura.curTarget.getMaxHealth() / 2.0f * 10.0f / 2.0f + (float) (i * 10),
						(float) (sr.getScaledHeight() / 2 - 16), 52, 0, 9, 9);
				++i;
			}
		}
	
	}
      }
	   public static int[] getFractionIndicies(final float[] fractions, final float progress) {
	        final int[] range = new int[2];
	        int startPoint;
	        for (startPoint = 0; startPoint < fractions.length && fractions[startPoint] <= progress; ++startPoint) {}
	        if (startPoint >= fractions.length) {
	            startPoint = fractions.length - 1;
	        }
	        range[0] = startPoint - 1;
	        range[1] = startPoint;
	        return range;
	    }
	 public static Color blendColors(final float[] fractions, final Color[] colors, final float progress) {
	        Color color = null;
	        if (fractions == null) {
	            throw new IllegalArgumentException("Fractions can't be null");
	        }
	        if (colors == null) {
	            throw new IllegalArgumentException("Colours can't be null");
	        }
	        if (fractions.length == colors.length) {
	            final int[] indicies = getFractionIndicies(fractions, progress);
	            final float[] range = { fractions[indicies[0]], fractions[indicies[1]] };
	            final Color[] colorRange = { colors[indicies[0]], colors[indicies[1]] };
	            final float max = range[1] - range[0];
	            final float value = progress - range[0];
	            final float weight = value / max;
	            color = blend(colorRange[0], colorRange[1], 1.0f - weight);
	            return color;
	        }
	        throw new IllegalArgumentException("Fractions and colours must have equal number of elements");
	    }
	 public static Color blend(final Color color1, final Color color2, final double ratio) {
	        final float r = (float)ratio;
	        final float ir = 1.0f - r;
	        final float[] rgb1 = new float[3];
	        final float[] rgb2 = new float[3];
	        color1.getColorComponents(rgb1);
	        color2.getColorComponents(rgb2);
	        float red = rgb1[0] * r + rgb2[0] * ir;
	        float green = rgb1[1] * r + rgb2[1] * ir;
	        float blue = rgb1[2] * r + rgb2[2] * ir;
	        if (red < 0.0f) {
	            red = 0.0f;
	        }
	        else if (red > 255.0f) {
	            red = 255.0f;
	        }
	        if (green < 0.0f) {
	            green = 0.0f;
	        }
	        else if (green > 255.0f) {
	            green = 255.0f;
	        }
	        if (blue < 0.0f) {
	            blue = 0.0f;
	        }
	        else if (blue > 255.0f) {
	            blue = 255.0f;
	        }
	        Color color3 = null;
	        try {
	            color3 = new Color(red, green, blue);
	        }
	        catch (IllegalArgumentException exp) {
	            final NumberFormat nf = NumberFormat.getNumberInstance();
	            System.out.println(nf.format((double)red) + "; " + nf.format((double)green) + "; " + nf.format((double)blue));
	            exp.printStackTrace();
	        }
	        return color3;
	    }
	 @EventHandler
		public void onScreenDraw(EventRender2D er) {
			if(this.mode.getValue() == rendermode.Exhibition){
			ScaledResolution res = new ScaledResolution(this.mc);	 
			int x = res.getScaledWidth() /2 + 10;
			int y = res.getScaledHeight() - 90;
	        final EntityLivingBase player = (EntityLivingBase) KillAura.curTarget;
	         if (player != null) {

	            GlStateManager.pushMatrix();
	            Gui.drawRect(x+0.0, y+0.0, x+113.0, y+36.0, Colors.getColor(0, 150));
	            
	            mc.fontRendererObj.drawStringWithShadow(player.getName(), x+38.0f, y+2.0f, -1);
	       
	            BigDecimal bigDecimal = new BigDecimal((double)player.getHealth());
	    		bigDecimal = bigDecimal.setScale(1, RoundingMode.HALF_UP);
	    		double HEALTH = bigDecimal.doubleValue();
	    		
	            BigDecimal DT = new BigDecimal((double)mc.thePlayer.getDistanceToEntity(player));
	    		DT = DT.setScale(1, RoundingMode.HALF_UP);
	    		double Dis = DT.doubleValue();
	    		
	            final float health = player.getHealth();
	            final float[] fractions = { 0.0f, 0.5f, 1.0f };
	            final Color[] colors = { Color.RED, Color.YELLOW, Color.GREEN };
	            final float progress = health / player.getMaxHealth();
	            final Color customColor = (health >= 0.0f) ? blendColors(fractions, colors, progress).brighter() : Color.RED;
	            double width = (double)mc.fontRendererObj.getStringWidth(player.getName());
	            width = getIncremental(width, 10.0);
	            if (width < 50.0) {
	                width = 50.0;
	            }
	            final double healthLocation = width * progress;
	            Gui.drawRect(x+37.5, y+11.5, x+38.0 + healthLocation + 0.5, y+14.5, customColor.getRGB());
	            RenderUtil.rectangleBordered(x+37.0, y+11.0, x+39.0 + width, y+15.0, 0.5, Colors.getColor(0, 0), Colors.getColor(0));
	            for (int i = 1; i < 10; ++i) {
	                final double dThing = width / 10.0 * i;
	                Gui.drawRect(x+38.0 + dThing, y+11.0, x+38.0 + dThing + 0.5, y+15.0, Colors.getColor(0));
	            }
	            String COLOR1;
	            if (health > 20.0D) {
	               COLOR1 = " \2479";
	            } else if (health >= 10.0D) {
	               COLOR1 = " \247a";
	            } else if (health >= 3.0D) {
	               COLOR1 = " \247e";
	            } else {
	               COLOR1 = " \2474";
	            }
	            RenderUtil.rectangleBordered(x+1.0, y+1.0, x+35.0, y+35.0, 0.5, Colors.getColor(0, 0), Colors.getColor(255));
	            
	            GlStateManager.scale(0.5, 0.5, 0.5);
	            final String str = "HP: "+ HEALTH + " Dist: " + Dis;
	            mc.fontRendererObj.drawStringWithShadow(str, x*2+76.0f, y*2+35.0f, -1);
	            final String str2 = String.format("Yaw: %s Pitch: %s ", (int)player.rotationYaw, (int)player.rotationPitch);
	            mc.fontRendererObj.drawStringWithShadow(str2, x*2+76.0f, y*2+47.0f, -1);
	            final String str3 = String.format("G: %s HURT: %s TE: %s", player.onGround, player.hurtTime, player.ticksExisted);
	            mc.fontRendererObj.drawStringWithShadow(str3, x*2+76.0f, y*2+59.0f, -1);

	            GlStateManager.scale(2.0f, 2.0f, 2.0f);
	            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
	            GlStateManager.enableAlpha();
	            GlStateManager.enableBlend();
	            GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
	       
	            if(player instanceof EntityPlayer) {
	            final List var5 = GuiPlayerTabOverlay.field_175252_a.sortedCopy((Iterable)mc.thePlayer.sendQueue.getPlayerInfoMap());
	            for (final Object aVar5 : var5) {
	                final NetworkPlayerInfo var6 = (NetworkPlayerInfo)aVar5;
	                if (mc.theWorld.getPlayerEntityByUUID(var6.getGameProfile().getId()) == player) {
	                    mc.getTextureManager().bindTexture(var6.getLocationSkin());
	                    Gui.drawScaledCustomSizeModalRect(x+2, y+2, 8.0f, 8.0f, 8, 8, 32, 32, 64.0f, 64.0f);
	                    if (((EntityPlayer)player).isWearing(EnumPlayerModelParts.HAT)) {
	                        Gui.drawScaledCustomSizeModalRect(x+2, y+2, 40.0f, 8.0f, 8, 8, 32, 32, 64.0f, 64.0f);
	                    }
	                    GlStateManager.bindTexture(0);
	                    break;
	                }
	            }
	            }
	            
	            GlStateManager.popMatrix();
	         }
			}
		}
		private  double getIncremental(final double val, final double inc) {
	        final double one = 1.0 / inc;
	        return Math.round(val * one) / one;
	    }
	

@EventHandler
public void Mikovke(EventRender2D event) {
	if(this.mode.getValue() == rendermode.Mikov){
    FontRenderer font2 = this.mc.fontRendererObj;
    ScaledResolution res = new ScaledResolution(this.mc);
    ScaledResolution sr2 = new ScaledResolution(this.mc);
    int y2 = 2;
    boolean count = false;
    Color color = new Color(1.0f, 0.75f, 0.0f, 0.45f);
    int x1 = 600;
    int y1 = 355;
    int x2 = 750;
    int y22 = sr2.getScaledHeight() - 50;
    int nametag = y1 + 12;
    double thickness = 0.014999999664723873;
    double xLeft = -20.0;
    double xRight = 20.0;
    double yUp = 27.0;
    double yDown = 130.0;
    double size = 10.0;
    int right = new ScaledResolution(this.mc).getScaledWidth() - new ScaledResolution(this.mc).getScaledWidth() / 2;
    int right2 = new ScaledResolution(this.mc).getScaledWidth() - new ScaledResolution(this.mc).getScaledWidth() / 2 + 30;
    int height = new ScaledResolution(this.mc).getScaledHeight();
    if (KillAura.curTarget != null) {
        Gui.drawRect((double)right, (double)(height - 50), (double)(right + 130), (double)(height - 90), (int)new Color(0, 0, 0, 130).getRGB());
        font2.drawString(KillAura.curTarget.getName(), right + 30, height - 87, 16777215);
        font2.drawString("HP:" + (int)((EntityLivingBase)KillAura.curTarget).getHealth() + "/" + (int)((EntityLivingBase)KillAura.curTarget).getMaxHealth() + " " + "Hurt:" + (KillAura.curTarget.hurtResistantTime > 0), right + 30, height - 70, new Color(255, 255, 255).getRGB());
        font2.drawString("Coords: " + (int)KillAura.curTarget.posX + " " + (int)KillAura.curTarget.posY + " " + (int)KillAura.curTarget.posZ, right + 30, height - 60, new Color(255, 255, 255).getRGB());
         
        R3DUtil.drawEntityOnScreen((int)(right + 14), (int)(height - 54), (int)15, (float)2.0f, (float)15.0f, (EntityLivingBase)((EntityLivingBase)KillAura.curTarget));           
        Gui.drawRainbowRectVertical((int)right2, (int)(height - 77), (int)((float)right2 + 95.0f * Math.min((int)right2, (int)(((EntityLivingBase)KillAura.curTarget).getHealth() / (int)((int)((EntityLivingBase)KillAura.curTarget).getMaxHealth())))), (int)(height - 73),3, 1);
  
    }

}
}

enum rendermode {
	Basic,
	Debug,
	Exhibition,
	Mikov,
  }	
}


