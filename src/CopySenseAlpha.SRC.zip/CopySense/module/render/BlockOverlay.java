package CopySense.module.render;

import java.awt.Color;

import org.lwjgl.opengl.GL11;

import CopySense.api.EventHandler;
import CopySense.api.events.rendering.EventRender2D;
import CopySense.api.events.rendering.EventRender3D;
import CopySense.api.value.Option;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.ui.font.CFontRenderer;
import CopySense.ui.font.FontLoaders;
import CopySense.utils.render.Colors;
import CopySense.utils.render.RenderUtil;

import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import net.minecraft.block.Block;
import net.minecraft.block.BlockStairs;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;

public class BlockOverlay extends Module{

	 private Option<Boolean> renderString = new Option<Boolean>("renderString", "renderString", true);

	public BlockOverlay() {
		 super("BlockOverlay", new String[]{"BlockOverlay","Overlay"}, ModuleType.Render);
	        this.setColor(new Color(226, 54, 30).getRGB());
	        
	}
	
	@EventHandler
	  public void onRender(EventRender2D event)
	  {
	    
	    if ((this.mc.objectMouseOver != null) && (this.mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) && (((Boolean)this.renderString.getValue()).booleanValue()))
	    {
	    	BlockPos pos = this.mc.objectMouseOver.getBlockPos();
		    Block block = this.mc.theWorld.getBlockState(pos).getBlock();
		    int id = Block.getIdFromBlock(block);
		    String s = String.valueOf(block.getLocalizedName()) + " ID: " + id;
		    String s1 = block.getLocalizedName();
		    String s2 = " ID: " + id;
	    	CFontRenderer font = FontLoaders.kiona16;
	      ScaledResolution res = new ScaledResolution(this.mc);
	      int x = res.getScaledWidth() / 2 + 7;
	      int y = res.getScaledHeight() / 2;
	      RenderUtil.drawRoundedRect(x, y-1, x + font.getStringWidth(s) + 3, y + font.FONT_HEIGHT +5.5F, 8.0F,Colors.WHITE.c);
	      font.drawString(s1, x + 1, y, Colors.BLACK.c);
	      font.drawString(s2, x + font.getStringWidth(s1) + 1, y, Colors.GREY.c);
	    }
	  }
	  
	@EventHandler
	  public void render(EventRender3D event)
	  {
	    if ((this.mc.objectMouseOver != null) && (this.mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK))
	    {
	      BlockPos pos = this.mc.objectMouseOver.getBlockPos();
	      Block block = this.mc.theWorld.getBlockState(pos).getBlock();
	      String s = block.getLocalizedName();
	      this.mc.getRenderManager();
	      double x = pos.getX() - RenderManager.renderPosX;
	      this.mc.getRenderManager();
	      double y = pos.getY() - RenderManager.renderPosY;
	      this.mc.getRenderManager();
	      double z = pos.getZ() - RenderManager.renderPosZ;
	      GL11.glPushMatrix();
	      GL11.glEnable(3042);
	      GL11.glBlendFunc(770, 771);
	      GL11.glDisable(3553);
	      GL11.glEnable(2848);
	      GL11.glDisable(2929);
	      GL11.glDepthMask(false);
	      GL11.glColor4f(0.0F, 0.5F, 1.0F, 0.25F);
	      double minX = ((block instanceof BlockStairs)) || (Block.getIdFromBlock(block) == 134) ? 0.0D : block.getBlockBoundsMinX();
	      double minY = ((block instanceof BlockStairs)) || (Block.getIdFromBlock(block) == 134) ? 0.0D : block.getBlockBoundsMinY();
	      double minZ = ((block instanceof BlockStairs)) || (Block.getIdFromBlock(block) == 134) ? 0.0D : block.getBlockBoundsMinZ();
	      RenderUtil.drawBoundingBox(new AxisAlignedBB(x + minX, y + minY, z + minZ, x + block.getBlockBoundsMaxX(), y + block.getBlockBoundsMaxY(), z + block.getBlockBoundsMaxZ()));
	      GL11.glColor4f(0.0F, 0.5F, 1.0F, 1.0F);
	      GL11.glLineWidth(0.5F);
	      RenderUtil.drawOutlinedBoundingBox(new AxisAlignedBB(x + minX, y + minY, z + minZ, x + block.getBlockBoundsMaxX(), y + block.getBlockBoundsMaxY(), z + block.getBlockBoundsMaxZ()));
	      GL11.glDisable(2848);
	      GL11.glEnable(3553);
	      GL11.glEnable(2929);
	      GL11.glDepthMask(true);
	      GL11.glDisable(3042);
	      GL11.glPopMatrix();
	    }
	    else {
	    	return;
	    }
	  }

}
