/*
 * Decompiled with CFR 0_132.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package CopySense.module.render;

import CopySense.api.EventHandler;
import CopySense.api.events.rendering.EventPostRenderPlayer;
import CopySense.api.events.rendering.EventPreRenderPlayer;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.value.Mode;
import CopySense.api.value.Value;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import java.awt.Color;
import org.lwjgl.opengl.GL11;

public class Chams
extends Module {
    public static Mode<Enum> mode = new Mode("Mode", "Mode", (Enum[])ChamsMode.values(), (Enum)ChamsMode.Textured);

    public Chams() {
        super("Chams", new String[]{"seethru", "cham"}, ModuleType.Render);
        this.addValues(this.mode);

        this.setColor(new Color(159, 190, 192).getRGB());
    }
    @EventHandler
    private void onUpdate(EventPreUpdate e10) {
        this.setSuffix(this.mode.getValue());
    }


    @EventHandler
    private void preRenderPlayer(EventPreRenderPlayer e) {
        GL11.glEnable((int)32823);
        GL11.glPolygonOffset((float)1.0f, (float)-1100000.0f);
    }

    @EventHandler
    private void postRenderPlayer(EventPostRenderPlayer e) {
        GL11.glDisable((int)32823);
        GL11.glPolygonOffset((float)1.0f, (float)1100000.0f);
    }

    public static enum ChamsMode {
        Textured,
        Normal;
    }

}

