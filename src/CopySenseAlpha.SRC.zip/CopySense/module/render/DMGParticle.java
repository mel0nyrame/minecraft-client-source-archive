package CopySense.module.render;

import java.util.concurrent.*;
import java.util.function.*;
import net.minecraft.client.*;
import net.minecraft.entity.*;
import java.math.*;

import net.minecraft.client.renderer.entity.*;
import net.minecraft.client.renderer.*;
import org.lwjgl.opengl.*;

import CopySense.api.EventHandler;
import CopySense.api.events.misc.EventLivingUpdate;
import CopySense.api.events.rendering.EventRender3D;
import CopySense.api.events.world.EventPreUpdate;
import CopySense.api.events.world.EventRespawn;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.utils.Location;
import CopySense.utils.Particles;
import CopySense.utils.render.RenderUtil;

import java.util.*;

public class DMGParticle extends Module {
    private HashMap<EntityLivingBase, Float> healthMap;
    private CopyOnWriteArrayList<Particles> particles;
    
    public DMGParticle() {
        super("DMGParticle", new String[] { "Damage Particle" }, ModuleType.Render);
        this.healthMap = new HashMap<EntityLivingBase, Float>();
        this.particles = new CopyOnWriteArrayList<Particles>();
    }
    
    @EventHandler
    public void onRespawn(final EventRespawn class1785) {
        this.particles.clear();
        this.healthMap.clear();
    }
    
    @EventHandler
    public void onUpdate(final EventPreUpdate eventUpdate) {
        this.particles.forEach(this::lambda$onUpdate$0);
    }
    
    @EventHandler
    public void onLivingUpdate(final EventLivingUpdate class2165) {
        final Entity entity = class2165.getEntity();
        if (entity == Minecraft.thePlayer) {
            return;
        }
        if (!this.healthMap.containsKey(entity)) {
            this.healthMap.put((EntityLivingBase)entity, Float.valueOf(((EntityLivingBase)entity).getHealth()));
        }
        final float floatValue;
        final float health;
        if ((floatValue = Float.valueOf(this.healthMap.get((Object)entity))) != (health = ((EntityLivingBase)entity).getHealth())) {
            final String p_i1238_2_ = (floatValue - health < 0.0f) ? ("§a" + roundToPlace((double)((floatValue - health) * -1.0f), 1)) : ("§e" + roundToPlace((double)(floatValue - health), 1));
            final Location p_i1238_1_ = new Location((EntityLivingBase)entity);
            p_i1238_1_.setY(entity.getEntityBoundingBox().minY + (entity.getEntityBoundingBox().maxY - entity.getEntityBoundingBox().minY) / 2.0);
            p_i1238_1_.setX(p_i1238_1_.getX() - 0.5 + new Random(System.currentTimeMillis()).nextInt(5) * 0.1);
            p_i1238_1_.setZ(p_i1238_1_.getZ() - 0.5 + new Random(System.currentTimeMillis() + 1L).nextInt(5) * 0.1);
            this.particles.add(new Particles(p_i1238_1_, p_i1238_2_));
            this.healthMap.remove(entity);
            this.healthMap.put((EntityLivingBase)entity, Float.valueOf(((EntityLivingBase)entity).getHealth()));
        }
    }
    
    public static double roundToPlace(final double p_roundToPlace_0_, final int p_roundToPlace_2_) {
        if (p_roundToPlace_2_ < 0) {
            throw new IllegalArgumentException();
        }
        return new BigDecimal(p_roundToPlace_0_).setScale(p_roundToPlace_2_, RoundingMode.HALF_UP).doubleValue();
    }
    
    @EventHandler
    public void onRender(final EventRender3D class1170) {
        for (final Particles class1171 : this.particles) {
            final double x = class1171.location.getX();
            final double n = x - RenderManager.renderPosX;
            final double y = class1171.location.getY();
            final double n2 = y - RenderManager.renderPosY;
            final double z = class1171.location.getZ();
            final double n3 = z - RenderManager.renderPosZ;
            GlStateManager.pushMatrix();
            GlStateManager.enablePolygonOffset();
            GlStateManager.doPolygonOffset(1.0f, -1500000.0f);
            GlStateManager.translate((float)n, (float)n2, (float)n3);
            DMGParticle.mc.getRenderManager();
            GlStateManager.rotate(-RenderManager.playerViewY, 0.0f, 1.0f, 0.0f);
            final float p_rotate_1_ = (DMGParticle.mc.gameSettings.thirdPersonView == 2) ? -1.0f : 1.0f;
            GlStateManager.rotate(RenderManager.playerViewX, p_rotate_1_, 0.0f, 0.0f);
            final double p_scale_4_ = 0.03;
            GlStateManager.scale(-p_scale_4_, -p_scale_4_, p_scale_4_);
            RenderUtil.enableGL2D();
            RenderUtil.disableGL2D();
            GL11.glDepthMask(false);
            Minecraft.fontRendererObj.drawStringWithShadow(class1171.text, (float)(-(Minecraft.fontRendererObj.getStringWidth(class1171.text) / 2)), (float)(-(Minecraft.fontRendererObj.FONT_HEIGHT - 1)), 0);
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            GL11.glDepthMask(true);
            GlStateManager.doPolygonOffset(1.0f, 1500000.0f);
            GlStateManager.disablePolygonOffset();
            GlStateManager.popMatrix();
        }
    }
    
    private void lambda$onUpdate$0(final Particles update) {
        ++update.ticks;
        if (update.ticks <= 10) {
            update.location.setY(update.location.getY() + update.ticks * 0.005);
        }
        if (update.ticks > 20) {
            this.particles.remove(update);
        }
    }
}
