/*
 * Decompiled with CFR 0_132.
 */
package CopySense.module.render;

import java.awt.Color;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import CopySense.Client;
import CopySense.api.EventHandler;
import CopySense.api.events.rendering.EventRender2D;
import CopySense.api.events.rendering.EventRenderCape;
import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.api.value.Option;
import CopySense.management.FriendManager;
import CopySense.management.ModuleManager;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.ui.ClickGui.NewClickGui;
import CopySense.ui.ClickGui.Opacity;
import CopySense.ui.font.CFontRenderer;
import CopySense.ui.font.FontLoaders;
import CopySense.utils.Translate;
import CopySense.utils.render.RenderUtil;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class HUD
		extends Module {
	public static Option<Boolean> hotbar = new Option<Boolean>("Hotbar", "hotbar", true);
	public Mode<Enum> colormode = new Mode("ArrayListColor", "coloerMode", (Enum[])CMode.values(), (Enum)CMode.Simple);
	public Mode<Enum> titlemode = new Mode("TitleColor", "title", (Enum[])TMode.values(), (Enum)TMode.Simple);
	public Mode<Enum> fot = new Mode("Font", "font", (Enum[])FMode.values(), (Enum)FMode.Basic);
	public static Mode<Enum> cape = new Mode("Cape", "Cape", (Enum[])CPMode.values(), (Enum)CPMode.None);
	private Option<Boolean> info = new Option<Boolean>("Information", "information", true);
	private Option<Boolean> line = new Option<Boolean>("Line", "backline", true);
	private Option<Boolean> armor = new Option<Boolean>("Armor", "armor", true);
	public static Option<Boolean> OpenSound = new Option<Boolean>("ModuleSound","ModuleSound",true);
	private Numbers<Double> background = new Numbers<Double>("BackGroundAlpha", "background",0.2, 0.0, 1.0,0.05);
	DecimalFormat sb = new DecimalFormat("0.00");
	private Opacity hue = new Opacity(0);
	CFontRenderer font;
	Color None;
	public HUD() {
		super("HUD", new String[]{"gui"}, ModuleType.Render);
		this.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)).getRGB());
		this.setEnabled(true);
		this.setRemoved(true);
		this.addValues(this.info, this.OpenSound, this.hotbar, this.armor, this.line, this.background, this.fot, this.titlemode, this.colormode, this.cape);

	}
	@EventHandler
	private void renderHud(EventRender2D event) {
		if (armor.getValue().booleanValue()) {
			GL11.glPushMatrix();
			final List<ItemStack> stuff = new ArrayList<ItemStack>();
			int split = -3;
			for (int index = 3; index >= 0; --index) {
				final ItemStack armer = mc.thePlayer.inventory.armorInventory[index];
				if (armer != null) {
					stuff.add(armer);
				}
			}
			for (final ItemStack errything : stuff) {
				if (mc.theWorld != null) {
					RenderHelper.enableGUIStandardItemLighting();
					split += 16;
				}
				mc.getRenderItem().zLevel = -150.0f;
				mc.getRenderItem().fuckyou(errything, 342 + split, 382);
				mc.getRenderItem().renderItemOverlays(mc.fontRendererObj, errything, 342 + split, 383);
				mc.getRenderItem().zLevel = 0.0f;
				errything.getEnchantmentTagList();
			}
			GlStateManager.enableAlpha();
			GlStateManager.disableBlend();
			GlStateManager.disableLighting();
			GlStateManager.disableCull();
			GL11.glPopMatrix();
		}
		if(this.fot.getValue()== FMode.Basic) {
			this.font = FontLoaders.kiona18;
		} 	if(this.fot.getValue()== FMode.LiquidBounce) {
			this.font = FontLoaders.regular18;
		}
		if (!this.mc.gameSettings.showDebugInfo) {
			String name;
			ArrayList<Module> sorted = new ArrayList<Module>();
			List<Module> modules = new ArrayList<>();
			Client.instance.getModuleManager();
			for (Module m : ModuleManager.getModules()) {
				if (!m.isEnabled() || m.wasRemoved())
					continue;
				sorted.add(m);
			}
				sorted.sort((o1,
							 o2) -> font.getStringWidth(
						o2.getSuffix().isEmpty() ? o2.getName() : String.format("%s %s", o2.getName(), o2.getSuffix()))
						- font.getStringWidth(o1.getSuffix().isEmpty() ? o1.getName()
						: String.format("%s %s", o1.getName(), o1.getSuffix())));
			int y = 0;
			int rainbowTick = 0;
			for (Module m : sorted) {
				name = m.getSuffix().isEmpty() ? m.getName() : String.format("%s %s", m.getName(), m.getSuffix());
				Module module = m;
				float x = RenderUtil.width() - font.getStringWidth(name);
                ScaledResolution res = new ScaledResolution(this.mc);
				if(this.colormode.getValue() == CMode.Rainbow) {
					this.None = new Color(Color.HSBtoRGB((float) ((double) this.mc.thePlayer.ticksExisted / 50.0 + Math.sin((double) rainbowTick / 50.0 * 1.6)) % 1.0f, 0.5f, 1.0f));
				} if(this.colormode.getValue() == CMode.Simple) {
					this.None = new Color(11,111,255);
				} if(this.colormode.getValue() == CMode.Rainbow2) {
					this.None = new Color(Color.HSBtoRGB((float) ((double) this.mc.thePlayer.ticksExisted / 100.0 + Math.sin((double) rainbowTick / 50.0 * 1.2)) % 4.0f, 2.0f, 1.0f));
				} if(this.colormode.getValue() == CMode.Rainbow3) {
					this.None  = new Color(Color.HSBtoRGB((float) ((double) this.mc.thePlayer.ticksExisted / 100 + Math.sin((double) rainbowTick / 90.0 * 1.0)) % 5.0f, 1.0f, 1.0f));
				}
				float translationFactor = 300 / (float) Minecraft.getDebugFPS();
				hue.interp(257,(int)0.00001);
				if (hue.getOpacity() > 255) {
					hue.setOpacity(0);
				}
				float h = hue.getOpacity();
				if (h > 255) {
					h = 0;
				}
				Gui.drawRect(new ScaledResolution(this.mc).getScaledWidth(),y,x-4,y+9,
				new Color(20,20,20,(int) (255.0f * background.getValue())).getRGB());
					if(line.getValue()) {
				Gui.drawRect(new ScaledResolution(this.mc).getScaledWidth(),y,new ScaledResolution(this.mc).getScaledWidth()-2,y+9,this.None.getRGB());
					}
				font.drawStringWithShadow(name, x - 3.0f, y+2,this.None.getRGB());
				if (++rainbowTick > 50) {
					rainbowTick = 0;
				}
				y += 9;
			}
				if (this.info.getValue().booleanValue()) {
					int xyxyyy = 0;
					int xtxxxx = 0;
					if (this.mc.ingameGUI.getChatGUI().getChatOpen()) {
						xyxyyy = 10;
					}
					if (!mc.isSingleplayer()) { xtxxxx = 36; }
					String fps = String.format("\u00a7fFPS:\u00a77 %d", Minecraft.getDebugFPS());
					String xyz = String.format("\u00a7fXYZ:\u00a77 %d, %d, %d", mc.thePlayer.getPosition().getX(),
							mc.thePlayer.getPosition().getY(), mc.thePlayer.getPosition().getZ());
					String BPS = " \u00a7fBPS:\u00a77 " + (sb.format(mc.thePlayer.getSpeed())) + "\u00a7f/s";
					int fontHeight = 9;
					int ychat;
					int n = ychat = this.mc.ingameGUI.getChatGUI().getChatOpen() ? 24 : 10;
					font.drawStringWithShadow(xyz, 10, new ScaledResolution(this.mc).getScaledHeight() - fontHeight - 4 - xyxyyy, new Color(255, 255, 255).getRGB());
					font.drawStringWithShadow(fps + BPS, 12 + font.getStringWidth(xyz), new ScaledResolution(this.mc).getScaledHeight() - fontHeight - 4 - xyxyyy,new Color(255, 255, 255).getRGB());
					if (!this.mc.ingameGUI.getChatGUI().getChatOpen()) {
						Gui.drawRect(5, new ScaledResolution(this.mc).getScaledHeight() - 3, 6, new ScaledResolution(this.mc).getScaledHeight() - 19, new Color(255, 255, 255).getRGB());
						Gui.drawRect(5, new ScaledResolution(this.mc).getScaledHeight() - 3, 15, new ScaledResolution(this.mc).getScaledHeight() - 4, new Color(255, 255, 255).getRGB());
						Gui.drawRect(5, new ScaledResolution(this.mc).getScaledHeight() - 19, 15, new ScaledResolution(this.mc).getScaledHeight() - 20, new Color(255, 255, 255).getRGB());
						Gui.drawRect(9, new ScaledResolution(this.mc).getScaledHeight() - 16, 175 + xtxxxx, new ScaledResolution(this.mc).getScaledHeight() - 17, new Color(11, 99, 255).getRGB());
					}
					if (!mc.isSingleplayer()) {
						String ping = String.format("\u00a7fPing:\u00a77 %d", Minecraft.getMinecraft().getCurrentServerData().pingToServer);
						font.drawStringWithShadow(ping, 14 + font.getStringWidth(xyz + fps + BPS), new ScaledResolution(this.mc).getScaledHeight() - fontHeight - 4 - xyxyyy,
								new Color(255, 255, 255).getRGB());
					}
					this.drawPotionStatus(new ScaledResolution(this.mc));
					Client.instance.getClass();
				}
			if(this.titlemode.getValue()==TMode.Simple) {
				String time = new SimpleDateFormat("HH:mm").format(new Date());
					font.drawStringWithShadow("Copy",3,3,new Color(255, 255, 251).getRGB());
					font.drawStringWithShadow("Sense",font.getStringWidth("Copy")+3,3,new Color(31,255, 16).getRGB());
					font.drawStringWithShadow("("+time+")",3+font.getStringWidth("CopySenseH"), 3, new Color(255,255,255).getRGB());
			}
			if(this.titlemode.getValue()==TMode.Rainbow) {
				String title = "CopySense";
				String time = new SimpleDateFormat("HH:mm").format(new Date());
					Color rainbow = new Color(Color.HSBtoRGB((float)((double)this.mc.thePlayer.ticksExisted / 50.0 + Math.sin((double)rainbowTick / 50.0 * 1.6)) % 1.0f, 0.5f, 1.0f));
					font.drawStringWithShadow(title,3,3,rainbow.getRGB());
					font.drawStringWithShadow("("+time+")",3+font.getStringWidth(title+"H"), 3, new Color(255,255,255).getRGB());
					if (++rainbowTick > 50) {
						rainbowTick = 0;
					}
			}
		}
	}


	private void drawPotionStatus(ScaledResolution sr) {
		CFontRenderer font = FontLoaders.kiona18;
		int y = 0;
		for (PotionEffect effect : this.mc.thePlayer.getActivePotionEffects()) {
			int ychat;
			Potion potion = Potion.potionTypes[effect.getPotionID()];
			String PType = I18n.format(potion.getName(), new Object[0]);
			switch (effect.getAmplifier()) {
				case 1: {
					PType = String.valueOf(PType) + " II";
					break;
				}
				case 2: {
					PType = String.valueOf(PType) + " III";
					break;
				}
				case 3: {
					PType = String.valueOf(PType) + " IV";
					break;
				}
			}
			if (effect.getDuration() < 600 && effect.getDuration() > 300) {
				PType = String.valueOf(PType) + "\u00a77:\u00a76 " + Potion.getDurationString(effect);
			} else if (effect.getDuration() < 300) {
				PType = String.valueOf(PType) + "\u00a77:\u00a7c " + Potion.getDurationString(effect);
			} else if (effect.getDuration() > 600) {
				PType = String.valueOf(PType) + "\u00a77:\u00a77 " + Potion.getDurationString(effect);
			}
			int n = ychat = this.mc.ingameGUI.getChatGUI().getChatOpen() ? 5 : -10;
				font.drawStringWithShadow(PType, sr.getScaledWidth() - font.getStringWidth(PType) - 2, sr.getScaledHeight() - font.getHeight() + y - 12 - ychat, potion.getLiquidColor());
			y -= 10;
		}
	}

	@EventHandler
	public void onRender(EventRenderCape event) {
		if (this.mc.theWorld != null && FriendManager.isFriend(event.getPlayer().getName())) {
			event.setCancelled(true);
		}
	}

	enum CMode{
		Simple, Rainbow, Rainbow2, Rainbow3
	}

	public static enum HMode {
		None, FDP, Plant
	}

	enum TMode {
		Simple, Rainbow
	}

	enum FMode {
		Basic, LiquidBounce
	}

	public static enum CPMode {
		None, Leain, FDP, FDP2, ETB
	}
}

