package CopySense.module.render;

import CopySense.api.EventHandler;
import CopySense.api.events.rendering.EventRender2D;
import CopySense.api.events.rendering.EventRender3D;
import CopySense.api.value.Numbers;
import CopySense.api.value.Option;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.utils.render.Colors;
import CopySense.utils.render.RenderUtil;
import net.minecraft.client.gui.ScaledResolution;

import java.awt.*;

public class Crosshair
        extends Module {
    private Option<Boolean> DYNAMIC = new Option<Boolean>("Dyanmic", "Dyanmic", true);
    private Numbers<Double> R = new Numbers<Double>("R", "R",1.0, 0.0, 255.0,1.0);
    private Numbers<Double> G = new Numbers<Double>("G", "G",1.0, 0.0, 255.0,1.0);
    private Numbers<Double> B = new Numbers<Double>("B", "B",1.0, 0.0, 255.0,1.0);
    private Numbers<Double> GAP = new Numbers<Double>("Gap", "Gap",0.25, 0.25, 15.0,0.05);
    private Numbers<Double> WIDTH = new Numbers<Double>("Width", "Width",0.25, 0.25, 10.0,0.05);
    private Numbers<Double> SIZE = new Numbers<Double>("Size", "Size",0.25, 0.25, 15.0,0.05);
    public Crosshair() {
        super("Crosshair", new String[]{"Crosshair", "cross","crs"}, ModuleType.Render);
        this.addValues(R,G,B,this.DYNAMIC,this.GAP, this.WIDTH, this.SIZE);
    }

    @EventHandler
    private void onRender(EventRender2D event) {
        int alph = 255;
        int red = ((Number)this.R.getValue()).intValue();
        int green = ((Number)this.G.getValue()).intValue();
        int blue = ((Number)this.B.getValue()).intValue();
        double gap = ((Number)this.GAP.getValue()).doubleValue();
        double width = ((Number)this.WIDTH.getValue()).doubleValue();
        double size = ((Number)this.SIZE.getValue()).doubleValue();
        ScaledResolution scaledRes = new ScaledResolution(this.mc);
        RenderUtil.rectangleBordered(
                scaledRes.getScaledWidth() / 2 - width,
                scaledRes.getScaledHeight() / 2 - gap - size - (isMoving() ? 2 : 0),
                scaledRes.getScaledWidth() / 2 + 1.0f + width,
                scaledRes.getScaledHeight() / 2 - gap - (isMoving() ? 2 : 0),
                0.5f, Colors.getColor(red, green, blue, alph),
                new Color(0, 0, 0, alph).getRGB());
        RenderUtil.rectangleBordered(
                scaledRes.getScaledWidth() / 2 - width,
                scaledRes.getScaledHeight() / 2 + gap + 1 + (isMoving() ? 2 : 0) - 0.15,
                scaledRes.getScaledWidth() / 2 + 1.0f + width,
                scaledRes.getScaledHeight() / 2 + 1 + gap + size + (isMoving() ? 2 : 0) - 0.15, 0.5f, Colors.getColor(red, green, blue, alph),
                new Color(0, 0, 0, alph).getRGB());
        RenderUtil.rectangleBordered(
                scaledRes.getScaledWidth() / 2 - gap - size - (isMoving() ? 2 : 0) + 0.15,
                scaledRes.getScaledHeight() / 2 - width,
                scaledRes.getScaledWidth() / 2 - gap - (isMoving() ? 2 : 0) + 0.15,
                scaledRes.getScaledHeight() / 2 + 1.0f + width, 0.5f, Colors.getColor(red, green, blue, alph),
                new Color(0, 0, 0, alph).getRGB());
        RenderUtil.rectangleBordered(
                scaledRes.getScaledWidth() / 2 + 1 + gap + (isMoving() ? 2 : 0),
                scaledRes.getScaledHeight() / 2 - width,
                scaledRes.getScaledWidth() / 2 + size + gap + 1 + (isMoving() ? 2 : 0),
                scaledRes.getScaledHeight() / 2 + 1.0f + width, 0.5f, Colors.getColor(red, green, blue, alph),
                new Color(0, 0, 0, alph).getRGB());
    }

    public boolean isMoving() {
        return (Boolean) this.DYNAMIC.getValue() && (!mc.thePlayer.isCollidedHorizontally) && (!mc.thePlayer.isSneaking()) && ((mc.thePlayer.movementInput.moveForward != 0.0F) || (mc.thePlayer.movementInput.moveStrafe != 0.0F));
    }

}
