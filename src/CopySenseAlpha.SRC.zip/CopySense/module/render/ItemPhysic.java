/*
 * Decompiled with CFR 0_132.
 */
package CopySense.module.render;

import CopySense.module.Module;
import CopySense.module.ModuleType;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class ItemPhysic
extends Module {
    public ItemPhysic() {
        super("ItemPhysic", new String[]{"ItemPhysic", "itemp"}, ModuleType.Render);
    }
}

