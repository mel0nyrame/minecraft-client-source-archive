/*
 * Decompiled with CFR 0_132.
 */
package CopySense.module;

public enum ModuleType {
    Combat,
    Render,
    Move,
    Player,
    World;
}

