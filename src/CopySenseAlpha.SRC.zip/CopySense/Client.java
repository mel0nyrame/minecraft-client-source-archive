
package CopySense;

import CopySense.api.value.Value;
import CopySense.management.CommandManager;
import CopySense.management.FileManager;
import CopySense.management.FriendManager;
import CopySense.management.ModuleManager;
import CopySense.module.Module;
import CopySense.ui.ClientNotification.Type;
import CopySense.ui.font.FontManager;
import CopySense.ui.login.AltManager;

import net.minecraft.block.Block;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.BlockVine;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.Display;

public class Client {
    public static final ResourceLocation CLIENT_CAPE = null;
	public final static String name = "CopySense";
    public final static String version = "Alpha";
    public static boolean publicMode = false;
    public static Client instance = new Client();
    private static ModuleManager modulemanager;
    private CommandManager commandmanager;

    private AltManager altmanager;
    private FriendManager friendmanager;
	public FontManager fontMgr;
	public GuiScreen clickGUI;
	public String build;
	public static FontManager fontManager;

    public static Minecraft mc = Minecraft.getMinecraft();
	public static boolean paiduser;
    public void initiate() {
		fontManager = fontMgr = new FontManager();
        this.commandmanager = new CommandManager();
        this.commandmanager.init();
        this.friendmanager = new FriendManager();
        this.friendmanager.init();

        this.modulemanager = new ModuleManager();
        this.modulemanager.init();
        this.altmanager = new AltManager();
        AltManager.init();
        AltManager.setupAlts();
        FileManager.init();
    }

    public static ModuleManager getModuleManager() {
        return modulemanager;
    }

    public CommandManager getCommandManager() {
        return this.commandmanager;
    }

    public AltManager getAltManager() {
        return this.altmanager;
    }

    public void shutDown() {
        String values = "";
        instance.getModuleManager();
        for (Module m : ModuleManager.getModules()) {
            for (Value v : m.getValues()) {
                values = String.valueOf(values) + String.format("%s:%s:%s%s", m.getName(), v.getName(), v.getValue(), System.lineSeparator());
            }
        }
        FileManager.save("Values.txt", values, false);
        String enabled = "";
        instance.getModuleManager();
        for (Module m : ModuleManager.getModules()) {
            if (!m.isEnabled()) continue;
            enabled = String.valueOf(enabled) + String.format("%s%s", m.getName(), System.lineSeparator());
        }
        FileManager.save("Enabled.txt", enabled, false);
    }

    public static BlockPos getBlockCorner(BlockPos start, BlockPos end) {
        for(int x = 0; x <= 1; ++x) {
           for(int y = 0; y <= 1; ++y) {
              for(int z = 0; z <= 1; ++z) {
                 BlockPos pos = new BlockPos(end.getX() + x, end.getY() + y, end.getZ() + z);
                 if (!isBlockBetween(start, pos)) {
                    return pos;
                 }
              }
           }
        }

        return null;
     }
    public static boolean isBlockBetween(BlockPos start, BlockPos end) {
        int startX = start.getX();
        int startY = start.getY();
        int startZ = start.getZ();
        int endX = end.getX();
        int endY = end.getY();
        int endZ = end.getZ();
        double diffX = (double)(endX - startX);
        double diffY = (double)(endY - startY);
        double diffZ = (double)(endZ - startZ);
        double x = (double)startX;
        double y = (double)startY;
        double z = (double)startZ;
        double STEP = 0.1D;
        int STEPS = (int)Math.max(Math.abs(diffX), Math.max(Math.abs(diffY), Math.abs(diffZ))) * 4;

        for(int i = 0; i < STEPS - 1; ++i) {
           x += diffX / (double)STEPS;
           y += diffY / (double)STEPS;
           z += diffZ / (double)STEPS;
           if (x != (double)endX || y != (double)endY || z != (double)endZ) {
              BlockPos pos = new BlockPos(x, y, z);
              Block block = mc.theWorld.getBlockState(pos).getBlock();
              if (block.getMaterial() != Material.air && block.getMaterial() != Material.water && !(block instanceof BlockVine) && !(block instanceof BlockLadder)) {
                 return true;
              }
           }
        }

        return false;
     }

	public static void sendClientMessage(String string, Type error) {
		// TODO �Զ����ɵķ������
		
	}

	public static String sendGet(String string) {
		// TODO �Զ����ɵķ������
		return null;
	}
}

