package CopySense.ui.fontRenderer;

import java.awt.Font;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import net.minecraft.client.Minecraft;

public class FontManager {
	private HashMap<String, HashMap<Float, UnicodeFontRenderer>> fonts = new HashMap();
	public static UnicodeFontRenderer verdana12;
	public UnicodeFontRenderer verdana14;
	public UnicodeFontRenderer verdana16;
	public UnicodeFontRenderer verdana20;
	public static UnicodeFontRenderer sigmaarr;
	public UnicodeFontRenderer zeroarr;
	public UnicodeFontRenderer comfortaa216;
	public UnicodeFontRenderer comfortaa14;
	public static UnicodeFontRenderer comfortaa20;
	public UnicodeFontRenderer comfortaa34;

    
	
	public FontManager() {
		verdana12 = this.getFont("verdana", 12f);
		verdana14 = this.getFont("verdana", 14f);
		verdana16 = this.getFont("verdana", 16f);
		verdana20 = this.getFont("verdana", 20f);
		sigmaarr = this.getFont("sigma", 8f);
		zeroarr = this.getFont("comfortaa", 15f);
		comfortaa216 = this.getFont("comfortaa2", 17f);
		comfortaa14 = this.getFont("comfortaa", 14f);
		comfortaa20 = this.getFont("comfortaa", 20f);
		comfortaa34 = this.getFont("comfortaa", 34f);
	}
	
	public UnicodeFontRenderer getFont(String name, float size) {
        UnicodeFontRenderer unicodeFont = null;
        try {
            if (this.fonts.containsKey(name) && this.fonts.get(name).containsKey(Float.valueOf(size))) {
                return this.fonts.get(name).get(Float.valueOf(size));
            }
            InputStream inputStream = this.getClass().getResourceAsStream("fonts/" + name + ".ttf");
            Font font = null;
            font = Font.createFont(0, inputStream);
            unicodeFont = new UnicodeFontRenderer(font.deriveFont(size));
            unicodeFont.setUnicodeFlag(true);
            unicodeFont.setBidiFlag(Minecraft.getMinecraft().mcLanguageManager.isCurrentLanguageBidirectional());
            HashMap<Float, UnicodeFontRenderer> map = new HashMap<Float, UnicodeFontRenderer>();
            if (this.fonts.containsKey(name)) {
                map.putAll((Map)this.fonts.get(name));
            }
            map.put(Float.valueOf(size), unicodeFont);
            this.fonts.put(name, map);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return unicodeFont;
    }

    public UnicodeFontRenderer getFont(String name, float size, boolean b) {
        UnicodeFontRenderer unicodeFont = null;
        try {
            if (this.fonts.containsKey(name) && this.fonts.get(name).containsKey(Float.valueOf(size))) {
                return this.fonts.get(name).get(Float.valueOf(size));
            }
            InputStream inputStream = this.getClass().getResourceAsStream("fonts/" + name + ".otf");
            Font font = null;
            font = Font.createFont(0, inputStream);
            unicodeFont = new UnicodeFontRenderer(font.deriveFont(size));
            unicodeFont.setUnicodeFlag(true);
            unicodeFont.setBidiFlag(Minecraft.getMinecraft().mcLanguageManager.isCurrentLanguageBidirectional());
            HashMap<Float, UnicodeFontRenderer> map = new HashMap<Float, UnicodeFontRenderer>();
            if (this.fonts.containsKey(name)) {
                map.putAll((Map)this.fonts.get(name));
            }
            map.put(Float.valueOf(size), unicodeFont);
            this.fonts.put(name, map);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return unicodeFont;
    }
}
