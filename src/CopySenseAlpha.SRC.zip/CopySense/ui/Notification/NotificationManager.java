package CopySense.ui.Notification;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

public class NotificationManager {
	private static LinkedBlockingQueue<Notification> pendingNotifications = new LinkedBlockingQueue<>();
	private static Notification currentNotification = null;

	public static void show(Notification notification) {
		pendingNotifications.addAll((Collection<? extends Notification>) notification);
	}

	public static void update() {
		if (currentNotification != null && !currentNotification.isShown()) {
			currentNotification = null;
		}

		if (currentNotification == null && !pendingNotifications.isEmpty()) {
			currentNotification = pendingNotifications.poll();
			currentNotification.show();
		}

	}

	public static void render() {
		update();

		if (currentNotification != null)
			currentNotification.render();
	}
}
