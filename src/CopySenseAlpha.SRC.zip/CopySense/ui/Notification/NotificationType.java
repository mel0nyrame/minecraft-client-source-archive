package CopySense.ui.Notification;

public enum NotificationType {
	INFO, WARNING, ERROR, ENABLE, DISABLE;
}
