
package CopySense.ui.ClickGUI2;

import CopySense.Client;
import CopySense.api.value.Value;
import CopySense.management.ModuleManager;
import CopySense.module.Module;
import CopySense.module.render.HUD;
import CopySense.ui.font.CFontFonts;
import CopySense.ui.font.CFontRenderer;
import CopySense.ui.font.FontLoaders;
import com.google.common.collect.Lists;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import net.minecraft.client.gui.Gui;

public class Button {
    public Module cheat;
    public Window parent;
    public int x;
    public int y;
    public int index;
    public int remander;
    public double opacity = 0.0;
    public ArrayList<ValueButton> buttons = Lists.newArrayList();
    public boolean expand;

    public Button(Module cheat, int x, int y) {
        CFontRenderer font = FontLoaders.kiona16;
        CFontRenderer mfont = FontLoaders.kiona16;
        CFontRenderer bigfont = FontLoaders.kiona24;
        this.cheat = cheat;
        this.x = x;
        this.y = y;
        int y2 = y + 14;
        Client.getModuleManager();
        if (cheat == ModuleManager.getModuleByName("HUD")) {
            this.buttons.add((ValueButton)new ColorValueButton(x + 15, y2));
        }
        for (Value v : cheat.getValues()) {
            this.buttons.add((ValueButton)new ValueButton(v, x + 5, y2));
            y2 += 15;
        }
        this.buttons.add((ValueButton)new KeyBindButton(cheat, x + 5, y2));
    }

    public void render(int mouseX, int mouseY) {
        CFontRenderer font = FontLoaders.kiona16;
        CFontRenderer mfont = FontLoaders.kiona16;
        CFontRenderer bigfont = FontLoaders.kiona24;
        Client.getModuleManager();
        if (this.cheat.getValues().size() + (this.cheat == ModuleManager.getModuleByName("HUD") ? 2 : 1) != this.buttons.size()) {
            this.buttons.clear();
            int y2 = this.y + 14;
            Client.getModuleManager();
            if (this.cheat == ModuleManager.getModuleByName("HUD")) {
                this.buttons.add((ValueButton)new ColorValueButton(this.x + 15, y2));
            }
            for (Value v : this.cheat.getValues()) {
                this.buttons.add((ValueButton)new ValueButton(v, this.x + 5, y2));
                y2 += 15;
            }
            this.buttons.add((ValueButton)new KeyBindButton(this.cheat, this.x + 5, y2));
        }
        if (this.index != 0) {
            Button b2 = (Button)this.parent.buttons.get(this.index - 1);
            this.y = b2.y + 15 + (b2.expand ? 15 * b2.buttons.size() : 0);
        }
        for (int i = 0; i < this.buttons.size(); ++i) {
            ((ValueButton)this.buttons.get((int)i)).y = this.y + 14 + 15 * i;
            ((ValueButton)this.buttons.get((int)i)).x = this.x + 5;
        }
        double d = mouseX > this.x - 7 && mouseX < this.x + 85 && mouseY > this.y - 6 && mouseY < this.y + mfont.getStringHeight(this.cheat.getName()) + 4 ? (this.opacity + 10.0 < 200.0 ? (this.opacity = this.opacity + 10.0) : 200.0) : (this.opacity - 6.0 > 0.0 ? (this.opacity = this.opacity - 6.0) : 0.0);
        this.opacity = d;
        Gui.drawRect((double)(this.x - 5), (double)(this.y - 5), (double)(this.x + 85), (double)((double)(this.y + font.getStringHeight(this.cheat.getName())) + 3.8), (int)new Color(25, 25, 25, (int)this.opacity).getRGB());
        if (this.cheat.isEnabled()) {
            Gui.drawRect((double)(this.x - 5), (double)(this.y - 5), (double)(this.x + 85), (double)((double)(this.y + font.getStringHeight(this.cheat.getName())) + 3.8), (int)new Color(156, 156, 156).getRGB());
            font.drawString(this.cheat.getName(), (float)this.x, (float)(this.y + 1), new Color(255, 255, 255).getRGB());
        } else {
            font.drawString(this.cheat.getName(), (float)this.x, (float)(this.y + 1), new Color(190, 190, 190).getRGB());
        }
        if (!this.expand && this.buttons.size() > 1) {
        	FontLoaders.kiona20.drawString("+", (float)(this.x + 76), (float)this.y, new Color(80,160, 80).getRGB());
        }
        if (this.expand) {
            this.buttons.forEach(b -> b.render(mouseX, mouseY));
            FontLoaders.kiona20.drawString("-", (float)(this.x + 76), (float)(this.y - 1), new Color(160, 80, 80).getRGB());
        }
    }

    public void key(char typedChar, int keyCode) {
        this.buttons.forEach(b -> b.key(typedChar, keyCode));
    }

    public void click(int mouseX, int mouseY, int button) {
        if (mouseX > this.x - 7 && mouseX < this.x + 85 && mouseY > this.y - 6 && mouseY < this.y + CFontFonts.instance.tahomaSM.getStringHeight(this.cheat.getName()) + 4) {
            if (button == 0) {
                this.cheat.setEnabled(!this.cheat.isEnabled());
            }
            if (button == 1 && !this.buttons.isEmpty()) {
                this.expand = !this.expand;
                boolean bl = this.expand;
            }
        }
        if (this.expand) {
            this.buttons.forEach(b -> b.click(mouseX, mouseY, button));
        }
    }

    public void setParent(Window parent) {
        this.parent = parent;
        for (int i = 0; i < this.parent.buttons.size(); ++i) {
            if (this.parent.buttons.get(i) != this) continue;
            this.index = i;
            this.remander = this.parent.buttons.size() - i;
            break;
        }
    }
}
