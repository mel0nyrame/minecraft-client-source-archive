package CopySense.ui.ClickGUI2;

import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.api.value.Option;
import CopySense.api.value.Value;
import CopySense.ui.font.CFontFonts;
import CopySense.ui.font.CFontRenderer;
import CopySense.ui.font.FontLoaders;
import CopySense.utils.RenderUtils;
import java.awt.Color;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Mouse;

public class ValueButton {
   public Value value;
   public String name;
   public boolean custom = false;
   public boolean change;
   public int x;
   public int y;
   public double opacity = 0.0D;

   public ValueButton(Value value, int x, int y) {
      this.value = value;
      this.x = x;
      this.y = y;
      this.name = "";
      if(this.value instanceof Option) {
         this.change = ((Boolean)((Option)this.value).getValue()).booleanValue();
      } else if(this.value instanceof Mode) {
         this.name = "" + ((Mode)this.value).getValue();
      } else if(value instanceof Numbers) {
         Numbers v = (Numbers)value;
         this.name = String.valueOf(this.name) + (v.isInteger()?(double)((Number)v.getValue()).intValue():((Number)v.getValue()).doubleValue());
      }

      this.opacity = 0.0D;
   }

   public void render(int mouseX, int mouseY) {
       CFontRenderer font = FontLoaders.kiona18;
       CFontRenderer mfont = FontLoaders.kiona16;
       CFontRenderer bigfont = FontLoaders.kiona28;
       if (!this.custom) {
           Numbers v;
           this.opacity = mouseX > this.x - 7 && mouseX < this.x + 85 && mouseY > this.y - 6 && mouseY < this.y + CFontFonts.instance.tahomaSM.getStringHeight(this.value.getName()) + 5 ? (this.opacity + 10.0 < 200.0 ? (this.opacity += 10.0) : 200.0) : (this.opacity - 6.0 > 0.0 ? (this.opacity -= 6.0) : 0.0);
           Gui.drawRect((double)(this.x - 9), (double)(this.y - 4), (double)(this.x - 9 + 88), (double)(this.y + mfont.getStringHeight(this.value.getName()) + 5), (int)new Color(120, 120, 120, (int)this.opacity).getRGB());
           if (this.change) {
               Color color = new Color(new Color(0, 100, 255).getRGB());
               Gui.drawRect((double)(this.x - 10), (double)(this.y - 5), (double)(this.x + 80), (double)(this.y + mfont.getStringHeight(this.value.getName()) + 5), (int)new Color(160, 160, 160).getRGB());
           }
           if (this.value instanceof Option) {
               this.change = (Boolean)((Option)this.value).getValue();
           } else if (this.value instanceof Mode) {
               this.name = "" + ((Mode)this.value).getValue();
           } else if (this.value instanceof Numbers) {
               v = (Numbers)this.value;
               this.name = "" + (v.isInteger() ? (double)((Number)v.getValue()).intValue() : ((Number)v.getValue()).doubleValue());
               if (mouseX > this.x - 7 && mouseX < this.x + 85 && mouseY > this.y - 6 && mouseY < this.y + mfont.getStringHeight(this.value.getName()) + 5 && Mouse.isButtonDown((int)0)) {
                   double min = v.getMinimum().doubleValue();
                   double max = v.getMaximum().doubleValue();
                   double inc = v.getIncrement().doubleValue();
                   double valAbs = (double)mouseX - ((double)this.x + 1.0);
                   double perc = valAbs / 68.0;
                   perc = Math.min((double)Math.max((double)0.0, (double)perc), (double)1.0);
                   double valRel = (max - min) * perc;
                   double val = min + valRel;
                   val = (double)Math.round((double)(val * (1.0 / inc))) / (1.0 / inc);
                   v.setValue((Object)val);
               }
           }
           if (this.value instanceof Numbers) {
               v = (Numbers)this.value;
               double render = 68.0f * (((Number)v.getValue()).floatValue() - v.getMinimum().floatValue()) / (v.getMaximum().floatValue() - v.getMinimum().floatValue());
               RenderUtils.drawRect((float)this.x, (float)(this.y + mfont.getStringHeight(this.value.getName()) + 2), (float)((float)((double)this.x + render + 1.0)), (float)(this.y + mfont.getStringHeight(this.value.getName()) + 3), (int)new Color(60,60,60).getRGB());
           }
           Gui.drawRect((double)0.0, (double)0.0, (double)0.0, (double)0.0, (int)0);
           mfont.drawString(this.value.getName(), (float)(this.x - 5), (float)(this.y + 1), new Color(255, 255, 255).getRGB());
           mfont.drawString(this.name, (float)(this.x + 76 - mfont.getStringWidth(this.name)), (float)(this.y + 1), new Color(255, 255, 255).getRGB());
       }
   }
   public void key(char typedChar, int keyCode) {
   }

   public void click(int mouseX, int mouseY, int button) {
      if(!this.custom && mouseX > this.x - 7 && mouseX < this.x + 85 && mouseY > this.y - 6 && mouseY < this.y + CFontFonts.instance.tahomaSM.getStringHeight(this.value.getName()) + 5) {
         if(this.value instanceof Option) {
            Option m1 = (Option)this.value;
            m1.setValue(Boolean.valueOf(!((Boolean)m1.getValue()).booleanValue()));
            return;
         }

         if(this.value instanceof Mode) {
            Mode m = (Mode)this.value;
            Enum current = (Enum)m.getValue();
            int next = current.ordinal() + 1 >= m.getModes().length?0:current.ordinal() + 1;
            this.value.setValue(m.getModes()[next]);
         }
      }

   }
}
