/*
 * Decompiled with CFR 0.136.
 */
package CopySense.ui.ClickGUI2;

import CopySense.api.value.Value;
import CopySense.module.Module;
import CopySense.ui.font.CFontFonts;
import CopySense.ui.font.CFontRenderer;
import CopySense.ui.font.FontLoaders;

import java.awt.Color;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Keyboard;

public class KeyBindButton
extends ValueButton {
    public Module cheat;
    public double opacity = 0.0;
    public boolean bind;

    public KeyBindButton(Module cheat, int x2, int y2) {
        super(null, x2, y2);
        this.custom = true;
        this.bind = false;
        this.cheat = cheat;
    }

    @Override
    public void render(int mouseX, int mouseY) {
        CFontRenderer font = FontLoaders.kiona12;
        double d2 = mouseX > this.x - 7 && mouseX < this.x + 85 && mouseY > this.y - 6 && mouseY < this.y + CFontFonts.instance.tahomaSM.getStringHeight(this.cheat.getName()) + 5 ? (this.opacity + 10.0 < 200.0 ? (this.opacity = this.opacity + 10.0) : 200.0) : (this.opacity - 6.0 > 0.0 ? (this.opacity = this.opacity - 6.0) : 0.0);
        this.opacity = d2;
        Gui.drawRect(this.x - 9, this.y - 5, this.x - 9 + 88, this.y + font.getStringHeight(this.cheat.getName()) + 5, new Color(120, 120, 120, (int)this.opacity).getRGB());
        font.drawStringWithShadow("Bind", this.x, this.y, -1);
        font.drawStringWithShadow(String.valueOf(String.valueOf(this.bind ? "" : "")) + Keyboard.getKeyName(this.cheat.getKey()), this.x + 75 - font.getStringWidth(Keyboard.getKeyName(this.cheat.getKey())), this.y, -1);
    }

    @Override
    public void key(char typedChar, int keyCode) {
        if (this.bind) {
            this.cheat.setKey(keyCode);
            if (keyCode == 1) {
                this.cheat.setKey(0);
            }
            ClickyUI.binding = false;
            this.bind = false;
        }
        super.key(typedChar, keyCode);
    }

    @Override
    public void click(int mouseX, int mouseY, int button) {
        if (mouseX > this.x - 7 && mouseX < this.x + 85 && mouseY > this.y - 6 && mouseY < this.y + CFontFonts.instance.tahomaSM.getStringHeight(this.cheat.getName()) + 5 && button == 0) {
            this.bind = !this.bind;
            ClickyUI.binding = this.bind;
        }
        super.click(mouseX, mouseY, button);
    }
}

