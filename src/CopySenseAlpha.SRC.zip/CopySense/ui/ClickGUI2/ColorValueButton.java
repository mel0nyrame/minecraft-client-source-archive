/*
 * Decompiled with CFR 0.136.
 */
package CopySense.ui.ClickGUI2;

import CopySense.api.value.Value;
import java.awt.Color;
import net.minecraft.client.gui.Gui;
import org.lwjgl.input.Mouse;

public class ColorValueButton
extends ValueButton {
    private float[] hue = new float[]{0.0f};
    private int position;

    public ColorValueButton(int x, int y) {
        super(null, x, y);
        this.custom = true;
        this.position = -1111;
    }

    public void render(int mouseX, int mouseY) {
        float[] huee = new float[]{this.hue[0]};
        for (int i = this.x - 7; i < this.x - 7 + 85; ++i) {
            if (mouseX > i - 1 && mouseX < i + 1 && mouseY > this.y - 6 && mouseY < this.y + 12) {
                Mouse.isButtonDown((int)0);
            }
            Gui.drawRect((double)(i - 1), (double)(this.y - 2), (double)i, (double)(this.y - 2 + 12), (int)new Color(255, 255, 255).getRGB());
            float[] arrf = huee;
            arrf[0] = arrf[0] + 4.0f;
            if (!(huee[0] > 255.0f)) continue;
            huee[0] = huee[0] - 255.0f;
        }
        Gui.drawRect((double)this.position, (double)(this.y - 2), (double)(this.position + 1), (double)(this.y - 2 + 12), (int)new Color(255, 255, 255).getRGB());
        if (this.hue[0] > 255.0f) {
            this.hue[0] = this.hue[0] - 255.0f;
        }
    }

    public void key(char typedChar, int keyCode) {
    }

    public void click(int mouseX, int mouseY, int button) {
    }
}
