/*
s * Decompiled with CFR 0.136.
 */
package CopySense.ui.font;

import CopySense.ui.font.CFontRenderer;
import CopySense.ui.font.PureFontRenderer;
import java.awt.Font;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.UnicodeFontRenderer;
import net.minecraft.client.resources.IResource;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.util.ResourceLocation;

public class FontManager {
	private HashMap<String, HashMap<Float, UnicodeFontRenderer>> fonts = new HashMap();
    private static FontManager instance;
    private Map<String, CFontRenderer> fontMap = new HashMap<String, CFontRenderer>();
	public Object comfortaa20;
	public Object verdana12;
	public Object sigmaarr;
	public PureFontRenderer zeroarr;
	public UnicodeFontRenderer verdana16;
    public static final PureFontRenderer fontRendererGUI;
    public static final PureFontRenderer fontRendererScale;

    static {
        fontRendererGUI = new PureFontRenderer(FontManager.getFont(40), true, 8);
        fontRendererScale = new PureFontRenderer(FontManager.getFont(36), true, 8);
    }

    public FontManager() {
        this.registerFonts();
    }

    public static FontManager getInstance() {
        if (instance == null) {
            instance = new FontManager();
        }
        return instance;
    }

    public Map<String, CFontRenderer> getFontMap() {
        return this.fontMap;
    }

    public CFontRenderer getFont(String font) {
        return this.fontMap.get(font);
    }

    private void registerFonts() {
        this.fontMap.put("tabui", new CFontRenderer(new Font("Comfortaa", 0, 18), true, false));
        this.fontMap.put("bariol", new CFontRenderer(new Font("Bariol-Regular", 0, 18), true, false));
        this.fontMap.put("40", new CFontRenderer(new Font("Comfortaa", 0, 40), true, false));
        this.fontMap.put("title", new CFontRenderer(new Font("Comfortaa", 0, 62), true, false));
        this.fontMap.put("10", new CFontRenderer(new Font("Comfortaa", 0, 20), true, false));
        this.fontMap.put("BAROND", new CFontRenderer(new Font("Baron-Neue-Bold", 0, 45), true, false));
    }

    private static Font getFont(int size) {
        Font font = null;
        try {
            InputStream is2 = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("Leain/fonts/comfortaa.ttf")).getInputStream();
            font = Font.createFont(0, is2);
            font = font.deriveFont(0, size);
        }
        catch (Exception ex2) {
            ex2.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        System.out.println("Fonts loading?");
        return font;
    }

	public Object getModules() {
		// TODO �Զ����ɵķ������
		return null;
	}

    public UnicodeFontRenderer getFont(String name, float size, boolean b) {
        UnicodeFontRenderer unicodeFont = null;
        try {
            if (this.fonts.containsKey(name) && this.fonts.get(name).containsKey(Float.valueOf(size))) {
                return this.fonts.get(name).get(Float.valueOf(size));
            }
            InputStream inputStream = this.getClass().getResourceAsStream("fonts/" + name + ".otf");
            Font font = null;
            font = Font.createFont(0, inputStream);
            unicodeFont = new UnicodeFontRenderer(font.deriveFont(size));
            unicodeFont.setUnicodeFlag(true);
            unicodeFont.setBidiFlag(Minecraft.getMinecraft().mcLanguageManager.isCurrentLanguageBidirectional());
            HashMap<Float, UnicodeFontRenderer> map = new HashMap<Float, UnicodeFontRenderer>();
            if (this.fonts.containsKey(name)) {
                map.putAll((Map)this.fonts.get(name));
            }
            map.put(Float.valueOf(size), unicodeFont);
            this.fonts.put(name, map);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return unicodeFont;
    }
}

