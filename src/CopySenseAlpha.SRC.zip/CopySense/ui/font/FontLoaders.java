/*
 * Decompiled with CFR 0_132.
 */
package CopySense.ui.font;

import CopySense.ui.font.CFontRenderer;
import java.awt.Font;
import java.io.InputStream;
import java.io.PrintStream;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.UnicodeFontRenderer;
import net.minecraft.client.resources.IResource;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.util.ResourceLocation;

public abstract class FontLoaders {
    public static final CFontRenderer GoogleSans18 = null;
	public static final CFontRenderer GoogleSans26 = null;
	public static final CFontRenderer Comfortaa18 = null;
	public static final CFontRenderer GoogleSans20 = null;
	public static final CFontRenderer GoogleSans28 = null;
	public static final CFontRenderer GoogleSans16 = null;
	public static final CFontRenderer GoogleSans32 = null;
	public static CFontRenderer kiona12 = new CFontRenderer(FontLoaders.getKiona(12), true, true);
    public static CFontRenderer kiona14 = new CFontRenderer(FontLoaders.getKiona(14), true, true);
    public static CFontRenderer kiona16 = new CFontRenderer(FontLoaders.getKiona(16), true, true);
    public static CFontRenderer kiona18 = new CFontRenderer(FontLoaders.getKiona(18), true, true);
    public static CFontRenderer kiona20 = new CFontRenderer(FontLoaders.getKiona(20), true, true);
    public static CFontRenderer kiona22 = new CFontRenderer(FontLoaders.getKiona(22), true, true);
    public static CFontRenderer kiona24 = new CFontRenderer(FontLoaders.getKiona(24), true, true);
    public static CFontRenderer kiona26 = new CFontRenderer(FontLoaders.getKiona(26), true, true);
    public static CFontRenderer kiona28 = new CFontRenderer(FontLoaders.getKiona(28), true, true);
    public static CFontRenderer kiona32 = new CFontRenderer(FontLoaders.getKiona(32), true, true);
	public static CFontRenderer kiona40 = new CFontRenderer(FontLoaders.getKiona(40), true, true);

    public static CFontRenderer regular18 = new CFontRenderer(FontLoaders.getregular(18), true, true);

    private static Font getKiona(int size) {
        Font font;
        try {
            InputStream is = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("Leain/fonts/comfortaa.ttf")).getInputStream();
            font = Font.createFont(0, is);
            font = font.deriveFont(0, size);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        return font;
    }

    private static Font getregular(int size) {
        Font font;
        try {
            InputStream is = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation("Leain/fonts/regular.ttf")).getInputStream();
            font = Font.createFont(0, is);
            font = font.deriveFont(0, size);
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Error loading font");
            font = new Font("default", 0, size);
        }
        return font;
    }


	private static Font getyahei(int i) {
		// TODO �Զ����ɵķ������
		return null;
	}
}



