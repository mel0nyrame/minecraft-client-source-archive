package CopySense.utils.particles.particle;

import org.lwjgl.util.vector.*;

public class Particle
{
    public Vector2f vector;
    
    public Particle() {
        this.vector = new Vector2f();
    }
    
    public void draw(final int xAdd) {
    }
    
}
