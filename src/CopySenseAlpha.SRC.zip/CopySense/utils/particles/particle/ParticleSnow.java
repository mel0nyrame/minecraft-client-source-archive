package CopySense.utils.particles.particle;

import java.util.*;
import net.minecraft.client.*;
import net.minecraft.client.gui.*;
import org.lwjgl.util.vector.*;
import CopySense.utils.*;

import CopySense.utils.SuperLib.Colors;

public class ParticleSnow extends Particle
{
    private final Random random;
    private ScaledResolution res;
    
    public ParticleSnow() {
        this.random = new Random();
    }
    
    @Override
    public void draw(final int xAdd) {
        this.prepare();
        this.move();
        this.drawPixel(xAdd);
        this.resetPos();
    }
    
    private void prepare() {
        this.res = new ScaledResolution(Minecraft.getMinecraft());
    }
    
    private void drawPixel(final int xAdd) {
        final float size = 10.0f;
        for (int i = 0; i < 10; ++i) {
            final int alpha = Math.min(0, 1 - i / 10);
            Gui.drawFilledCircle(this.vector.x, this.vector.y, size + 1.0f + i * 0.2f, SuperLib.reAlpha(Colors.WHITE.c, (float)alpha), 5);
        }
        Gui.drawFilledCircle(this.vector.x + xAdd, this.vector.y, 1.100000023841858, SuperLib.reAlpha(-1, 0.2f), 5);
        Gui.drawFilledCircle(this.vector.x + xAdd, this.vector.y, 0.800000011920929, SuperLib.reAlpha(-1, 0.4f), 5);
        Gui.drawFilledCircle(this.vector.x + xAdd, this.vector.y, 0.5, SuperLib.reAlpha(-1, 0.6f), 5);
        Gui.drawFilledCircle(this.vector.x + xAdd, this.vector.y, 0.30000001192092896, SuperLib.reAlpha(Colors.WHITE.c, 1.0f), 5);
    }
    
    private void move() {
        final float speed = 100.0f;
        final Vector2f vector = this.vector;
        vector.y += this.random.nextFloat() * 0.25f;
        final Vector2f vector2 = this.vector;
        vector2.x -= this.random.nextFloat();
    }
    
    private void resetPos() {
        if (this.vector.x < 0.0f) {
            this.vector.x = (float)this.res.getScaledWidth();
        }
        if (this.vector.y > this.res.getScaledHeight()) {
            this.vector.y = 0.0f;
        }
    }
}
