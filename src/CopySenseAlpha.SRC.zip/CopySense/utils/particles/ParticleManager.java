package CopySense.utils.particles;

import net.minecraft.client.*;
import net.minecraft.client.gui.*;
import java.util.*;

import CopySense.utils.particles.particle.Particle;
import CopySense.utils.particles.particle.ParticleSnow;

public class ParticleManager
{
    private final Particle particle;
    private final int amount;
    public ArrayList particles;
    private final Random random;
    
    public ParticleManager(final Particle particle, final int amount) {
        this.particles = new ArrayList();
        this.random = new Random();
        this.particle = particle;
        this.amount = amount;
        this.init();
    }
    
    private void init() {
        this.particles.clear();
        final ScaledResolution res = new ScaledResolution(Minecraft.getMinecraft());
        for (int i = 0; i < this.amount; ++i) {
            ParticleSnow particle = new ParticleSnow();
            if (particle instanceof ParticleSnow) {
                particle = new ParticleSnow();
            }
            particle.vector.x = (float)this.random.nextInt(res.getScaledWidth() + 1);
            particle.vector.y = (float)this.random.nextInt(res.getScaledHeight() + 1);
            this.particles.add(particle);
        }
    }
}
