package CopySense.utils;

import net.minecraft.client.*;
import java.awt.*;
import net.minecraft.util.*;
import org.lwjgl.opengl.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.gui.*;

public class SuperLib
{
    private static final Minecraft mc;
    
    static {
        mc = Minecraft.getMinecraft();
    }
    
    public static String removeColorCode(final String text) {
        String finalText = text;
        if (text.contains("§")) {
            for (int i = 0; i < finalText.length(); ++i) {
                if (Character.toString(finalText.charAt(i)).equals("§")) {
                    try {
                        final String part1 = finalText.substring(0, i);
                        final String part2 = finalText.substring(Math.min(i + 2, finalText.length()));
                        finalText = String.valueOf(part1) + part2;
                    }
                    catch (Exception ex) {}
                }
            }
        }
        return finalText;
    }
    
    public static int reAlpha(final int color, final float alpha) {
        final Color c = new Color(color);
        final float r = 0.003921569f * c.getRed();
        final float g = 0.003921569f * c.getGreen();
        final float b = 0.003921569f * c.getBlue();
        return new Color(r, g, b, alpha).getRGB();
    }
    
    public static void drawImage(final ResourceLocation image, final int x, final int y, final int width, final int height) {
        final ScaledResolution scaledResolution = new ScaledResolution(Minecraft.getMinecraft());
        GL11.glDisable(2929);
        GL11.glEnable(3042);
        GL11.glDepthMask(false);
        OpenGlHelper.glBlendFunc(770, 771, 1, 0);
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        Minecraft.getMinecraft();
        Minecraft.getTextureManager().bindTexture(image);
        Gui.drawModalRectWithCustomSizedTexture(x, y, 0.0f, 0.0f, width, height, (float)width, (float)height);
        GL11.glDepthMask(true);
        GL11.glDisable(3042);
        GL11.glEnable(2929);
    }
    
    public static double getAnimationState(double animation, final double finalState, final double speed) {
        final float add = (float)(0.01 * speed);
        if (animation < finalState) {
            if (animation + add < finalState) {
                animation += add;
            }
            else {
                animation = finalState;
            }
        }
        else if (animation - add > finalState) {
            animation -= add;
        }
        else {
            animation = finalState;
        }
        return animation;
    }
    
    public static double getAnimationState2(double animation, final double finalState, final double speed) {
        final float add = (float)(0.01 * speed);
        if (animation < finalState) {
            animation = finalState;
        }
        else if (animation - add > finalState) {
            animation -= add;
        }
        else {
            animation = finalState;
        }
        return animation;
    }
    
    public static void setSpeed(final double speed) {
        Minecraft.thePlayer.motionX = -Math.sin(PlayerUtil.getDirection()) * speed;
        Minecraft.thePlayer.motionZ = Math.cos(PlayerUtil.getDirection()) * speed;
    }
    
    public static double getSpeed() {
        Minecraft.getMinecraft();
        final double motionX = Minecraft.thePlayer.motionX;
        Minecraft.getMinecraft();
        final double n = motionX * Minecraft.thePlayer.motionX;
        Minecraft.getMinecraft();
        final double motionZ = Minecraft.thePlayer.motionZ;
        Minecraft.getMinecraft();
        return Math.sqrt(n + motionZ * Minecraft.thePlayer.motionZ);
    }
    
    public enum Colors
    {
        BLACK("BLACK", 0, -16711423), 
        BLUE("BLUE", 1, -12028161), 
        DARKBLUE("DARKBLUE", 2, -12621684), 
        GREEN("GREEN", 3, -9830551), 
        DARKGREEN("DARKGREEN", 4, -9320847), 
        WHITE("WHITE", 5, -65794), 
        AQUA("AQUA", 6, -7820064), 
        DARKAQUA("DARKAQUA", 7, -12621684), 
        GREY("GREY", 8, -9868951), 
        DARKGREY("DARKGREY", 9, -14342875), 
        RED("RED", 10, -65536), 
        DARKRED("DARKRED", 11, -8388608), 
        ORANGE("ORANGE", 12, -29696), 
        DARKORANGE("DARKORANGE", 13, -2263808), 
        YELLOW("YELLOW", 14, -256), 
        DARKYELLOW("DARKYELLOW", 15, -2702025), 
        MAGENTA("MAGENTA", 16, -18751), 
        DARKMAGENTA("DARKMAGENTA", 17, -2252579);
        
        public int c;
        
        private Colors(final String s, final int n, final int co) {
            this.c = co;
        }
    }
}
