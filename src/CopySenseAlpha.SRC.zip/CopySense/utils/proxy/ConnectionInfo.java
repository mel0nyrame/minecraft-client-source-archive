/*
 * Decompiled with CFR 0_132.
 */
package CopySense.utils.proxy;

public class ConnectionInfo {
    public String ip;
    public int port;
}

