package CopySense.utils;

import java.awt.Color;
import java.awt.Font;
import java.io.InputStream;
import java.util.ArrayList;

import CopySense.Client;
import CopySense.ui.ClientNotification;
import CopySense.ui.ClientNotification.Type;
import CopySense.ui.font.CFontRenderer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.UnicodeFontRenderer;
import net.minecraft.util.ChatComponentText;

public enum ClientUtil {
	
	INSTANCE;
	
	private static ArrayList<ClientNotification> notifications = new ArrayList<>();
	public CFontRenderer sansation19 = new CFontRenderer(this.getSansation(19), true, true);
	public CFontRenderer tahoma19 = new CFontRenderer(this.getTahoma(19), true, true);
	
	public Font getTahoma(float size) {
		Font f;
		try {
			InputStream is = UnicodeFontRenderer.class.getResourceAsStream("fonts/tahoma.ttf");
			f = Font.createFont(0, is);
            f = f.deriveFont(0, size);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Error loading font");
			f = new Font("Arial", 0, (int)size);
        }
		return f;
	}
	
	public Font getSansation(float size) {
		Font f;
		try {
			InputStream is = UnicodeFontRenderer.class.getResourceAsStream("fonts/sansation.ttf");
			f = Font.createFont(0, is);
            f = f.deriveFont(0, size);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("Error loading font");
			f = new Font("Arial", 0, (int)size);
        }
		return f;
	}
	
	public void drawNotifications() {
		ScaledResolution res = new ScaledResolution(Minecraft.getMinecraft());
		double startY = res.getScaledHeight() - 25;
		final double lastY = startY;
		for (int i = 0; i < notifications.size(); i++) {
			ClientNotification not = notifications.get(i);
			if (not.shouldDelete())
				notifications.remove(i);
			not.draw(startY, lastY);
			startY -= not.getHeight() + 1;
			if(notifications.size() > 10) {
				notifications.clear();
				sendClientMessage("All Notifications is be Clean",Type.INFO);
			}
		}
	}
	
	public static void sendClientMessage(String message, Type type) {
		notifications.add(new ClientNotification(message, type));
	}
	
	public static int reAlpha(int color, float alpha) {
		Color c = new Color(color);
		float r = ((float) 1 / 255) * c.getRed();
		float g = ((float) 1 / 255) * c.getGreen();
		float b = ((float) 1 / 255) * c.getBlue();
		return new Color(r, g, b, alpha).getRGB();
	}
	
}
