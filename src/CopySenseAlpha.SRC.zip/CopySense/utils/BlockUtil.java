package CopySense.utils;

import net.minecraft.client.*;
import net.minecraft.entity.projectile.*;
import net.minecraft.entity.*;
import net.minecraft.util.*;
import net.minecraft.entity.player.*;

public class BlockUtil
{
    private static Minecraft mc;

    static {
        BlockUtil.mc = Minecraft.getMinecraft();
    }

    public static float[] getDirectionToBlock(final int var0, final int var1, final int var2, final EnumFacing var3) {
        final EntityEgg var4 = new EntityEgg(BlockUtil.mc.theWorld);
        var4.posX = var0 + 0.5;
        var4.posY = var1 + 0.5;
        var4.posZ = var2 + 0.5;
        final EntityEgg entityEgg = var4;
        entityEgg.posX += var3.getDirectionVec().getX() * 0.25;
        final EntityEgg entityEgg2 = var4;
        entityEgg2.posY += var3.getDirectionVec().getY() * 0.25;
        final EntityEgg entityEgg3 = var4;
        entityEgg3.posZ += var3.getDirectionVec().getZ() * 0.25;
        return getDirectionToEntity(var4);
    }

    public static float[] getDirectionToBlock2(final BlockPos pos, final EnumFacing facing, final float yaw, final float pitch) {
        final float[] needed = getRotations(pos, facing);
        return getDirectionToEntity2(yaw, pitch, needed[0], needed[1], pos.getX(), pos.getZ());
    }

    public static float[] getRotations(final BlockPos block, final EnumFacing face) {
        final double x = block.getX() + 0.5 - BlockUtil.mc.thePlayer.posX + face.getFrontOffsetX() / 2.0;
        final double z = block.getZ() + 0.5 - BlockUtil.mc.thePlayer.posZ + face.getFrontOffsetZ() / 2.0;
        final double y = block.getY() + 0.5 + face.getFrontOffsetZ() / 2;
        final double d1 = BlockUtil.mc.thePlayer.posY + BlockUtil.mc.thePlayer.getEyeHeight() - y;
        final double d2 = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float)(Math.atan2(z, x) * 180.0 / 3.141592653589793) - 90.0f;
        final float pitch = (float)(Math.atan2(d1, d2) * 180.0 / 3.141592653589793);
        if (yaw < 0.0f) {
            yaw += 360.0f;
        }
        return new float[] { yaw, pitch };
    }

    private static float[] getDirectionToEntity(final Entity var0) {
        return new float[] { getYaw(var0) + BlockUtil.mc.thePlayer.rotationYaw, getPitch(var0) + BlockUtil.mc.thePlayer.rotationPitch };
    }

    private static float[] getDirectionToEntity2(final float yaw, final float pitch, final float needYaw, final float needPitch, final double x, final double z) {
        return new float[] { getYawChange(yaw, needYaw, x, z), getPitchChange(pitch, needPitch) };
    }

    public static float[] getRotationNeededForBlock(final EntityPlayer paramEntityPlayer, final BlockPos pos) {
        final double d1 = pos.getX() - paramEntityPlayer.posX;
        final double d2 = pos.getY() + 0.5 - (paramEntityPlayer.posY + paramEntityPlayer.getEyeHeight());
        final double d3 = pos.getZ() - paramEntityPlayer.posZ;
        final double d4 = Math.sqrt(d1 * d1 + d3 * d3);
        final float f1 = (float)(Math.atan2(d3, d1) * 180.0 / 3.141592653589793) - 90.0f;
        final float f2 = (float)(-(Math.atan2(d2, d4) * 180.0 / 3.141592653589793));
        return new float[] { f1, f2 };
    }

    public static float getYaw(final Entity var0) {
        final double var = var0.posX - BlockUtil.mc.thePlayer.posX;
        final double var2 = var0.posZ - BlockUtil.mc.thePlayer.posZ;
        double var3;
        if (var2 < 0.0 && var < 0.0) {
            var3 = 90.0 + Math.toDegrees(Math.atan(var2 / var));
        }
        else if (var2 < 0.0 && var > 0.0) {
            var3 = -90.0 + Math.toDegrees(Math.atan(var2 / var));
        }
        else {
            var3 = Math.toDegrees(-Math.atan(var / var2));
        }
        return MathHelper.wrapAngleTo180_float(-(BlockUtil.mc.thePlayer.rotationYaw - (float)var3));
    }

    public static float getYawChange(final float yaw, final float yawToEntity, final double x, final double z) {
        final double var1 = x;
        final double var2 = z;
        double var3;
        if (var2 < 0.0 && var1 < 0.0) {
            var3 = 90.0 + Math.toDegrees(Math.atan(var2 / var1));
        }
        else if (var2 < 0.0 && var1 > 0.0) {
            var3 = -90.0 + Math.toDegrees(Math.atan(var2 / var1));
        }
        else {
            var3 = Math.toDegrees(-Math.atan(var1 / var2));
        }
        return MathHelper.wrapAngleTo180_float(-(yaw - (float)var3));
    }

    public static float getPitch(final Entity var0) {
        final double var = var0.posX - BlockUtil.mc.thePlayer.posX;
        final double var2 = var0.posZ - BlockUtil.mc.thePlayer.posZ;
        final double var3 = var0.posY - 1.6 + var0.getEyeHeight() - BlockUtil.mc.thePlayer.posY;
        final double var4 = MathHelper.sqrt_double(var * var + var2 * var2);
        final double var5 = -Math.toDegrees(Math.atan(var3 / var4));
        return -MathHelper.wrapAngleTo180_float(BlockUtil.mc.thePlayer.rotationPitch - (float)var5);
    }

    public static float getPitchChange(final float pitch, final float pitchToEntity) {
        return -MathHelper.wrapAngleTo180_float(pitch - pitchToEntity);
    }
}
