/*
 * Decompiled with CFR 0_132.
 */
package CopySense.utils.render.gl;

public interface GLenum {
    public String getName();

    public int getCap();
}

