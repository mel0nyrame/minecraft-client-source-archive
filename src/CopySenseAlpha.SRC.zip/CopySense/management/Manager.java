/*
 * Decompiled with CFR 0_132.
 */
package CopySense.management;

public interface Manager {
    public void init();
}

