/*
 * Decompiled with CFR 0_132.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package CopySense.management;

import CopySense.api.EventBus;
import CopySense.api.EventHandler;
import CopySense.api.events.misc.EventKey;
import CopySense.api.events.rendering.EventRender2D;
import CopySense.api.events.rendering.EventRender3D;
import CopySense.api.value.Mode;
import CopySense.api.value.Numbers;
import CopySense.api.value.Option;
import CopySense.api.value.Value;
import CopySense.module.Module;
import CopySense.module.ModuleType;
import CopySense.module.combat.*;
import CopySense.module.movement.*;
import CopySense.module.player.*;
import CopySense.module.render.*;
import CopySense.module.world.*;
import CopySense.utils.render.gl.GLUtils;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;

public class ModuleManager
implements Manager {
    public static List<Module> modules = new ArrayList<Module>();
    public static ArrayList<Module> sortedModList = new ArrayList();
    private boolean enabledNeededMod = true;
    public boolean nicetry = true;
    @Override
    public void init() {
    	//combat
        this.modules.add(new AntiBot());
        this.modules.add(new AutoHeal());
        this.modules.add(new AutoClicker());        
        this.modules.add(new BowAimBot());
        this.modules.add(new Criticals());
        this.modules.add(new KillAura());  
        this.modules.add(new Reach());  
        this.modules.add(new TPAura());
        this.modules.add(new Hitbox());      
        //move
        this.modules.add(new Fly());
        this.modules.add(new Jesus());
        this.modules.add(new Longjump());
        this.modules.add(new NoSlow());
        this.modules.add(new Scaffold());
        this.modules.add(new Speed());
        this.modules.add(new Sprint());
        this.modules.add(new Step());
        //player
        this.modules.add(new AntiVelocity());
        this.modules.add(new InventoryManager());
        this.modules.add(new AutoArmor());
        this.modules.add(new PlayerChat());
        this.modules.add(new AntiVoid());
        this.modules.add(new FastUse());
        this.modules.add(new MCF());
        this.modules.add(new NoFall());
        //render
        this.modules.add(new Animation());
        this.modules.add(new FullBright());
        this.modules.add(new Crosshair());
        this.modules.add(new DMGParticle());
        this.modules.add(new BlockOverlay());
        this.modules.add(new Nametags());
        this.modules.add(new ChestESP());
        this.modules.add(new ItemPhysic());
        this.modules.add(new Freecam());
        this.modules.add(new NewESP());
        this.modules.add(new ItemEsp());
        this.modules.add(new Chams());
        this.modules.add(new ClickGUI());
        this.modules.add(new HUD());
        this.modules.add(new TargetHUD());
        this.modules.add(new Tracers());
        this.modules.add(new Xray());    
        //world
        this.modules.add(new Blink());
        this.modules.add(new ChestAura());
        this.modules.add(new ChestStealer());
        this.modules.add(new FastPlace());
        this.modules.add(new NoRotate());
        this.modules.add(new Phase());
        this.modules.add(new Spammer());
        this.modules.add(new memoryfix());       
        this.modules.add(new PingSpoof());

        this.readSettings();
        for (Module m : modules) {
            m.makeCommand();
        }
        EventBus.getInstance().register(this);
    }

    public static List<Module> getModules() {
        return modules;
    }

    public static Module getModuleByClass(Class<? extends Module> cls) {
        for (Module m : modules) {
            if (m.getClass() != cls) continue;
            return m;
        }
        return null;
    }

    public static Module getModuleByName(String name) {
        for (Module m : modules) {
            if (!m.getName().equalsIgnoreCase(name)) continue;
            return m;
        }
        return null;
    }

    public Module getAlias(String name) {
        for (Module f : modules) {
            if (f.getName().equalsIgnoreCase(name)) {
                return f;
            }
            String[] alias = f.getAlias();
            int length = alias.length;
            int i = 0;
            while (i < length) {
                String s = alias[i];
                if (s.equalsIgnoreCase(name)) {
                    return f;
                }
                ++i;
            }
        }
        return null;
    }

    public static List<Module> getModulesInType(ModuleType t) {
        ArrayList<Module> output = new ArrayList<Module>();
        for (Module m : modules) {
            if (m.getType() != t) continue;
            output.add(m);
        }
        return output;
    }

    @EventHandler
    private void onKeyPress(EventKey e) {
        for (Module m : modules) {
            if (m.getKey() != e.getKey()) continue;
            m.setEnabled(!m.isEnabled());
        }
    }

    @EventHandler
    private void onGLHack(EventRender3D e) {
        GlStateManager.getFloat(2982, (FloatBuffer)GLUtils.MODELVIEW.clear());
        GlStateManager.getFloat(2983, (FloatBuffer)GLUtils.PROJECTION.clear());
        GlStateManager.glGetInteger(2978, (IntBuffer)GLUtils.VIEWPORT.clear());
    }

    @EventHandler
    private void on2DRender(EventRender2D e) {
        if (this.enabledNeededMod) {
            this.enabledNeededMod = false;
            for (Module m : modules) {
                if (!m.enabledOnStartup) continue;
                m.setEnabled(true);
            }
        }
    }

    private void readSettings() {
        List<String> binds = FileManager.read("Binds.txt");
        for (String v : binds) {
            String name = v.split(":")[0];
            String bind = v.split(":")[1];
            Module m = ModuleManager.getModuleByName(name);
            if (m == null) continue;
            m.setKey(Keyboard.getKeyIndex((String)bind.toUpperCase()));
        }
        List<String> enabled = FileManager.read("Enabled.txt");
        for (String v : enabled) {
            Module m = ModuleManager.getModuleByName(v);
            if (m == null) continue;
            m.enabledOnStartup = true;
        }
        List<String> vals = FileManager.read("Values.txt");
        for (String v : vals) {
            String name = v.split(":")[0];
            String values = v.split(":")[1];
            Module m = ModuleManager.getModuleByName(name);
            if (m == null) continue;
            for (Value value : m.getValues()) {
                if (!value.getName().equalsIgnoreCase(values)) continue;
                if (value instanceof Option) {
                    value.setValue(Boolean.parseBoolean(v.split(":")[2]));
                    continue;
                }
                if (value instanceof Numbers) {
                    value.setValue(Double.parseDouble(v.split(":")[2]));
                    continue;
                }
                ((Mode)value).setMode(v.split(":")[2]);
            }
        }
    }
}

