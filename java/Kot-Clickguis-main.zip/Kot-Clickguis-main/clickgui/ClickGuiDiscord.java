package Kot.kotsystem.clickgui;

import Kot.CatSense;
import Kot.Module.Module;
import Kot.Module.modules.render.HUD;
import Kot.Module.settings.*;
import Kot.kotsystem.fontsystem.CFontRenderer;
import Kot.ui.kotUIsystems.KotUI;
import Kot.util.GuiUtils;
import Kot.util.R2DUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.awt.*;
import java.io.IOException;
import java.util.List;

public class ClickGuiDiscord extends GuiScreen {
    public static ClickGuiDiscord instance;

    public ClickGuiDiscord() {
        instance = this;
    }

    private Module inModule;
    private Setting SliderSetting;
    private boolean sliding = false;
    private Module.Category category;
    private boolean dragging = false;
    private float draggingx = 0;
    private float draggingy = 0;

    private float x = 200;
    private float y = 200;
    private final float yScroll = 0;

    int scrollvl = 0;
    int scrollvlSettings = 0;
    int categoryColor = 0;

    boolean waitingForKeyBind = false;

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {

        CFontRenderer fr = CatSense.getFontManager().Comforta;
        if (dragging) {
            x = mouseX - draggingx;
            y = mouseY - draggingy;
        }

        boolean CustomColor = ((HUD) CatSense.getModbyName("HUD")).getCustomColor().isEnabled();
        double red = ((HUD) CatSense.getModbyName("HUD")).getRed().getValue();
        double green = ((HUD) CatSense.getModbyName("HUD")).getGreen().getValue();
        double blue = ((HUD) CatSense.getModbyName("HUD")).getBlue().getValue();
        //CustomColor ? HUD.fade(new Color((int)red, (int)green, (int)blue, 255), 3, 1).getRGB()

        Gui.drawRect(x, y, x + 345, y + 8, new Color(32, 33, 36, 255).getRGB());
        if(((ClickGui) CatSense.getModbyName("ClickGui")).getRainbow().isEnabled()) {
            GuiUtils.drawSmoothRainbow(x + 1, y + 1, x + 345 - 1, y + 2, 25, 0.88f, 0.45f);
        }
        Gui.drawRect(x, y + 8, x + 345, y + 250, new Color(44, 46, 51, 255).getRGB());
        Gui.drawRect(x, y + 8, x + 30, y + 250, new Color(32, 33, 36, 255).getRGB());
        int categoryCount = 0;
        for (Module.Category c : Module.Category.values()) {
            boolean over = mouseX >= x + 3 && mouseX < x + 26 && mouseY >= y + 25 + (categoryCount * 27) - 11 && mouseY < y + 25 + (categoryCount * 27) + 11;
            R2DUtils.drawFullCircle((int) x + 15, (int) y + 25 + (categoryCount * 27), 11, over ? new Color(48, 50, 55, 255).getRGB() : new Color(42, 44, 49, 255).getRGB());
            if (category == c)
                R2DUtils.drawFullCircle((int) x + 15, (int) y + 25 + (categoryCount * 27), 11, new Color(104, 125, 198, categoryColor).getRGB());
            categoryCount++;
        }


        int categoryCount2 = 0;
        for (Module.Category c : Module.Category.values()) {
            String catName = "";
            boolean syf = false;
            for (char c2 : c.name.toCharArray()) {
                if (!syf) {
                    catName = c2 + "";
                    syf = true;
                }
            }
            if (catName.equals("P") || catName.equals("R")) {
                fr.drawString(catName, x + 12, (int) y + 25 + (categoryCount2 * 27) - 2, -1);
            } else {
                fr.drawString(catName, x + 11, (int) y + 25 + (categoryCount2 * 27) - 2, -1);
            }
            categoryCount2++;
        }
        if (category != null) {
            Gui.drawRect(x + 30, y + 8, x + 125, y + 250, new Color(40, 42, 47, 255).getRGB());
        } else {
            Gui.drawRect(x + 30, y + 8, x + 345, y + 250, new Color(40, 42, 47, 255).getRGB());
            fr.drawCenteredString("Hey,", x + 174, y + 100, new Color(114 - 10, 125 - 10, 130 - 10, 255).getRGB());
            fr.drawCenteredString("Cat wants to have some fun destroying", x + 174, y + 110, new Color(114 - 10, 125 - 10, 130 - 10, 255).getRGB());
            fr.drawCenteredString("Servers with shit anticheat or hypixel!", x + 174, y + 120, new Color(114 - 10, 125 - 10, 130 - 10, 255).getRGB());
        }
        int mod = 0;
        if (category != null) {
            List<Module> modules = CatSense.getModuleManager().getModulesByCategory(category);
            for (Module m : modules) {
                mod++;
            }
        }
        if (Mouse.hasWheel() && mod > 15 && mouseX >= x + 30 && mouseX < x + 125 && mouseY >= y + 10 && mouseY < y + 250) {
            if (scrollvl > 0) {
                scrollvl = 0;
            }
            scrollvl = scrollvl + (Mouse.getDWheel() / 5);
        }
        if (inModule != null && !inModule.settings.isEmpty()) {
            if (Mouse.hasWheel() && inModule.settings.size() > 16 && mouseX >= x + 125 && mouseX < x + 345 && mouseY >= y + 10 && mouseY < y + 250) {
                scrollvlSettings = scrollvlSettings + (Mouse.getDWheel() / 5);
            }
            if (scrollvlSettings > 0) {
                scrollvlSettings = 0;
            }
        }
        if (categoryColor < 255) {
            categoryColor++;
            categoryColor++;
            categoryColor++;
        }
        int count = 0;
        if (category != null) {
            List<Module> modules = CatSense.getModuleManager().getModulesByCategory(category);
            for (Module m : modules) {
                if (y + 13 + (count * 14) + scrollvl + fr.getHeight() < y + 250 && y + 13 + (count * 14) + scrollvl + fr.getHeight() > y + 16) {
                    fr.drawString(m.getName(), x + 40, y + 13 + (count * 14) + scrollvl, m.isToggled() ? new Color(114 + 60, 125 + 60, 130 + 60, 255).getRGB() : new Color(114, 125, 130, 255).getRGB());
                    fr.drawString("#", x + 32, y + 13 + (count * 14) + scrollvl, new Color(114 + 60, 125 + 60, 130 + 60, 255).getRGB());

                }
                count++;
            }
        }
        //  GL11.glDisable(GL11.GL_SCISSOR_TEST);
        //  GlStateManager.popMatrix();

        if (inModule != null) {
            int Settingscount = 0;
            for (Setting s : inModule.settings) {
                if (y + 13 + (Settingscount * 14) + scrollvlSettings + fr.getHeight() < y + 250 && y + 13 + (Settingscount * 14) + scrollvlSettings + fr.getHeight() > y + 16) {
                    if (s instanceof NumberSetting) {
                        NumberSetting number = (NumberSetting) s;
                        fr.drawString(s.name + ": " + number.getValue(), x + 128, y + 13 + (Settingscount * 14) + scrollvlSettings, new Color(114, 125, 130, 255).getRGB());
                        GuiUtils.drawBarWithMinMax((float) number.getValue(), (float) number.getMinimum(), (float) number.getMaximum(), x + 125, y + 22 + (Settingscount * 14) + scrollvlSettings, x + 345, 1, new Color(114, 125, 130, 255).getRGB());
                        if (sliding && SliderSetting == s) {
                            number.setValue(number.getMinimum() + ((mouseX - (x + 125)) / 220) * (number.getMaximum() - number.getMinimum()));
                        }
                    }
                    if (s instanceof ModeSetting) {
                        ModeSetting mode = (ModeSetting) s;
                        fr.drawString(s.name + ": " + mode.getMode(), x + 128, y + 13 + (Settingscount * 14) + scrollvlSettings, new Color(114, 125, 130, 255).getRGB());

                    }
                    if (s instanceof KeybindSetting) {
                        KeybindSetting keyBind = (KeybindSetting) s;
                        fr.drawString(s.name + ": " + (waitingForKeyBind ? "Press any key" : Keyboard.getKeyName(keyBind.code)), x + 128, y + 13 + (Settingscount * 14) + scrollvlSettings, new Color(114, 125, 130, 255).getRGB());
                    }
                    if (s instanceof BooleanSetting) {
                        BooleanSetting bool = (BooleanSetting) s;
                        fr.drawString(s.name + ": " + (bool.enabled ? "Enabled" : "Disabled"), x + 128, y + 13 + (Settingscount * 14) + scrollvlSettings, new Color(114, 125, 130, 255).getRGB());
                    }
                }
                Settingscount++;
            }
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int button) {
        CFontRenderer fr = CatSense.getFontManager().Comforta;
        int count = 0;
        if (category != null) {
            List<Module> modules = CatSense.getModuleManager().getModulesByCategory(category);
            for (Module m : modules) {
                if (y + 13 + (count * 14) + scrollvl + fr.getHeight() < y + 250) {
                    //fr.drawString("#" + m.getName(), x + 32, y + 13 + (count * 14) + scrollvl, new Color(114, 125, 130, 255).getRGB());
                    boolean toggleOrNot = mouseX >= x + 32 && mouseX < x + 125 && mouseY >= y + 13 + (count * 14) + scrollvl - 2 && mouseY < y + 13 + (count * 14) + scrollvl + fr.getHeight() + 4;
                    if (toggleOrNot && button == 0) {
                        m.toggle();
                    }
                    if (toggleOrNot && button == 1) {
                        inModule = m;
                        scrollvlSettings = 0;
                    }
                }
                count++;
            }
        }
        int categoryCount = 0;
        for (Module.Category c : Module.Category.values()) {
            boolean over = mouseX >= x + 3 && mouseX < x + 26 && mouseY >= y + 25 + (categoryCount * 27) - 11 && mouseY < y + 25 + (categoryCount * 27) + 11;
            if (over && button == 0) {
                category = c;
                scrollvl = 0;
                scrollvlSettings = 0;
                inModule = null;
                categoryColor = 0;
            }
            categoryCount++;
        }
        if (mouseX >= x && mouseX < x + 325 && mouseY >= y && mouseY < y + 8 && button == 0) {
            dragging = true;
            draggingx = mouseX - x;
            draggingy = mouseY - y;
        }
        if (inModule != null) {
            int Settingscount = 0;
            for (Setting s : inModule.settings) {
                if (y + 13 + (Settingscount * 14) + scrollvlSettings + fr.getHeight() < y + 250 && y + 13 + (Settingscount * 14) + scrollvlSettings + fr.getHeight() > y + 16 && mouseX >= x + 125 && mouseX < x + 345 && mouseY >= y + 13 + (Settingscount * 14) + scrollvlSettings - 2 && mouseY < y + 13 + (Settingscount * 14) + scrollvlSettings + 9) {
                    if (s instanceof NumberSetting && button == 0) {
                        NumberSetting number = (NumberSetting) s;
                        SliderSetting = s;
                        sliding = true;
                    }
                    if (s instanceof ModeSetting) {
                        ModeSetting mode = (ModeSetting) s;
                        if (button == 0) {
                            mode.cycle();
                        }
                        if (button == 1) {
                            mode.cycleminus();
                        }
                    }
                    if (s instanceof KeybindSetting) {
                        KeybindSetting keyBind = (KeybindSetting) s;
                        waitingForKeyBind = true;
                    }
                    if (s instanceof BooleanSetting) {
                        BooleanSetting bool = (BooleanSetting) s;
                        bool.toggle();
                    }
                }
                Settingscount++;
            }
        }
    }

    protected void mouseReleased(int mouseX, int mouseY, int state) {
        dragging = false;
        sliding = false;
        super.mouseReleased(mouseX, mouseY, state);
    }

    @Override
    public void initGui() {
        setInvMove();
    }

    protected void keyTyped(char typedChar, int keyCode) {
        if (waitingForKeyBind) {
            if (keyCode != Keyboard.KEY_RETURN && keyCode != Keyboard.KEY_UP && keyCode != Keyboard.KEY_RIGHT
                    && keyCode != Keyboard.KEY_DOWN && keyCode != Keyboard.KEY_LEFT && keyCode != Keyboard.KEY_ESCAPE && keyCode != Keyboard.KEY_W && keyCode != Keyboard.KEY_A && keyCode != Keyboard.KEY_D && keyCode != Keyboard.KEY_S && keyCode != Keyboard.KEY_DELETE) {
                inModule.keyCode.code = keyCode;
            }
            if (keyCode == Keyboard.KEY_DELETE) {
                inModule.keyCode.code = 0;
            }
            waitingForKeyBind = false;
        }

        try {
            super.keyTyped(typedChar, keyCode);
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    public static void setInvMove() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen instanceof GuiChat) {
            return;
        }
        KeyBinding[] moveKeys = new KeyBinding[]{mc.gameSettings.keyBindForward, mc.gameSettings.keyBindBack,
                mc.gameSettings.keyBindLeft, mc.gameSettings.keyBindRight, mc.gameSettings.keyBindJump};
        KeyBinding[] arrayofKeybinding = moveKeys;
        int i;
        int j;
        KeyBinding bind = null;
        arrayofKeybinding = moveKeys;
        j = moveKeys.length;
        for (i = 0; i < j; ++i) {
            bind = arrayofKeybinding[i];
            bind.pressed = Keyboard.isKeyDown(bind.getKeyCode());
        }
    }
}
