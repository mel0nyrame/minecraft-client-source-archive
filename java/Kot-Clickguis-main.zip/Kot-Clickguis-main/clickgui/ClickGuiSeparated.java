package Kot.kotsystem.clickgui;


import Kot.CatSense;
import Kot.Module.Module;
import Kot.Module.modules.render.HUD;
import Kot.Module.settings.*;
import Kot.kotsystem.fontsystem.CFontRenderer;
import Kot.util.GuiUtils;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.io.IOException;
import java.util.List;

public class ClickGuiSeparated extends GuiScreen {
    public boolean fastRender, showDebugInfo;
    public Kot.util.Timer timer = new Kot.util.Timer();
    private boolean draggingSlider = false;
    Module.Category inCat;
    Module inSet;
    Setting SliderSet;
    Module.Category draggedCategory;
    int dragging = 0;
    float xOffset = 0;
    float yOffset = 0;

    ClickGuiState state = ClickGuiState.Zero;

    private boolean waitingForKeyBind = false;
    float scale = 0;

    /**
     * @author GayKtntKot
     * @version nike non skid b69
     */

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {

        CFontRenderer def = CatSense.fontManager.TEST;
        boolean customcolor = ((HUD) CatSense.getModbyName("HUD")).getCustomColor().isEnabled();
        double red = ((HUD) CatSense.getModbyName("HUD")).getRed().getValue();
        double green = ((HUD) CatSense.getModbyName("HUD")).getGreen().getValue();
        double blue = ((HUD) CatSense.getModbyName("HUD")).getBlue().getValue();


        int colorText = -1;
        int colorEnabledText = new Color(85, 140, 255, 255).getRGB();
        int categoryBackground = new Color(25, 25, 25, 255).getRGB();
        int background = new Color(35, 35, 35, 255).getRGB();
        int splitBackground = new Color(45, 45, 45, 255).getRGB();
        int SliderColor = new Color(85, 140, 255, 255).getRGB();

        String theme = ((ClickGui) CatSense.getModbyName("ClickGui")).getTheme().getMode();

        if (theme.equals("White")) {
            categoryBackground = new Color(85, 140, 255, 255).getRGB();
            background = -1;
            splitBackground = new Color(250, 250, 250, 255).getRGB();
            colorText = new Color(164, 181, 255, 255).getRGB();
            colorEnabledText = new Color(57, 117, 255, 255).getRGB();
        } else if (theme.equals("Green")) {
            colorText = -1;
            colorEnabledText = new Color(46, 204, 113, 255).getRGB();
            categoryBackground = new Color(46, 204, 113, 255).getRGB();
            background = new Color(35, 35, 35, 255).getRGB();
            splitBackground = new Color(45, 45, 45, 255).getRGB();
            SliderColor = new Color(46, 204, 113, 255).getRGB();
        }


        ScaledResolution sr = new ScaledResolution(mc);
        //Gui.drawRect(sr.getScaledWidth() - 50, sr.getScaledHeight() - 20, sr.getScaledWidth() - 10, sr.getScaledHeight() - 5, new Color(35, 35, 35, 255).getRGB());
        //def.drawString("Reset", sr.getScaledWidth() - 48, sr.getScaledHeight() - 15, new Color(35, 35, 35, 255).getRGB());


        int categoryValue = 0;
        for (Module.Category c : Module.Category.values()) {
            Module.Category category = Module.Category.values()[categoryValue];
            List<Module> modules = CatSense.getModuleManager().getModulesByCategory(category);
            if (c.x == 0) {
                reset(c);
            }

            GlStateManager.pushMatrix();


            if (scale < 1) {
                if (scale == 0)
                    scale = 0.01f;
                if (timer.hasTimeElapsed(10, true)) {
                    scale *= 1.3;
                }
            } else {
                scale = 1;
            }
            GL11.glScalef(scale, scale, scale);


            if (waitingForKeyBind) {
                Gui.drawRect(sr.getScaledWidth() / 2 - 50, sr.getScaledHeight() - 40, sr.getScaledWidth() / 2 + 50, sr.getScaledHeight() - 65, new Color(0, 0, 0, 50).getRGB());
                def.drawCenteredString("Waiting for keybind", sr.getScaledWidth() / 2, sr.getScaledHeight() - 60, -1);
                def.drawCenteredString("Click Del to set NONE", sr.getScaledWidth() / 2, sr.getScaledHeight() - 49, -1);

            }

            if (c == draggedCategory && dragging == 1) {
                c.x = mouseX - xOffset + 4;
                c.y = mouseY - yOffset + 20;
            }
            Gui.drawRect(c.x - 3 - 1, c.y - 20, c.x + 75 + 1, c.y + 16 - 20, categoryBackground);
            def.drawString(c.name, c.x, c.y - 16, -1);


            if (!c.hidden) {
                int count = 0;
                for (Module m : modules) {
                    float offset = 16 * count;
                    if (mouseX >= c.x - 3 && mouseX < c.x + 75 && mouseY >= c.y - 4 + offset && mouseY < c.y + offset + 16 - 4 && m.AnimationX < 3) {
                        //m.AnimationX = m.AnimationX + 0.05f;
                    } else if (!(mouseX >= c.x - 3 && mouseX < c.x + 75 && mouseY >= c.y - 4 + offset && mouseY < c.y + offset + 16 - 4) && m.AnimationX > 0) {
                        //m.AnimationX = m.AnimationX-0.05f;
                    }
                    Gui.drawRect(c.x - 3, c.y - 4 + offset, c.x + 75, c.y + offset + 16 - 4, background);
                    def.drawString(m.getName(), c.x + m.AnimationX, c.y + offset, m.isToggled() ? colorEnabledText : colorText);
                    count++;
                }
            }
            if (state == ClickGuiState.InSettings && !inSet.settings.isEmpty() && inCat == category) {
                int settingsindex = 0;
                for (Setting setting : inSet.settings) {
                    float offset = 16 * settingsindex;
                    float newX = c.x + 78;
                    Gui.drawRect(newX - 3, c.y - 4 + offset, newX + 75 + 50, c.y + offset + 16 - 4, background);
                    Gui.drawRect(newX - 3, c.y - 4 + offset, newX - 2, c.y + offset + 16 - 4, splitBackground);

                    if (setting instanceof BooleanSetting) {
                        BooleanSetting bool = (BooleanSetting) setting;
                        def.drawString(setting.name + ": " + (bool.enabled ? "Enabled" : "Disabled"),
                                newX, c.y + offset, colorText);
                    }
                    if (setting instanceof NumberSetting) {
                        NumberSetting number = (NumberSetting) setting;
                        def.drawString(setting.name + ": " + number.getValue(), newX,
                                c.y + offset, colorText);

                        if (((ClickGui) CatSense.getModbyName("ClickGui")).getUseSliders().isEnabled()) {
                            GuiUtils.drawBarWithMinMax((float) number.getValue(), (float) number.getMinimum(), (float) number.getMaximum(), newX - 2, c.y + offset + 16 - 5, newX + 75 + 50, 1, SliderColor);
                            if (draggingSlider && setting == SliderSet) {
                                //thx you guibuttonslider very cool
                                number.setValue(number.getMinimum() + ((mouseX - (newX - 2)) / 122) * (number.getMaximum() - number.getMinimum()));
                            }
                        }
                    }
                    if (setting instanceof ModeSetting) {
                        ModeSetting mode = (ModeSetting) setting;
                        def.drawString(setting.name + ": " + mode.getMode(), newX, c.y + offset,
                                colorText);
                    }
                    if (setting instanceof KeybindSetting) {
                        KeybindSetting keyBind = (KeybindSetting) setting;
                        def.drawString(setting.name + ": " + Keyboard.getKeyName(keyBind.code), newX,
                                c.y + offset, colorText);
                    }
                    settingsindex++;
                }
            }
            GlStateManager.popMatrix();
            categoryValue++;
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int button) {
        CFontRenderer def = CatSense.fontManager.TEST;
        ScaledResolution sr = new ScaledResolution(mc);
        int categoryValue = 0;
        for (Module.Category c : Module.Category.values()) {
            Module.Category category = Module.Category.values()[categoryValue];
            List<Module> modules = CatSense.getModuleManager().getModulesByCategory(category);
            if (mouseX >= sr.getScaledWidth() - 50 && mouseX < sr.getScaledWidth() - 10 && mouseY >= sr.getScaledHeight() - 20 && mouseY < sr.getScaledHeight() - 5 && button == 0) {
                reset(c);
            }
            if (mouseX >= c.x - 3 - 1 && mouseX < c.x + 75 && mouseY >= c.y - 20 && mouseY < c.y - 20 + 16 && button == 1) {
                c.hidden = !c.hidden;
                if (inCat == c) {
                    state = ClickGuiState.Zero;
                    inCat = null;
                    inSet = null;
                }
            }
            if (mouseX >= c.x - 3 - 1 && mouseX < c.x + 75 && mouseY >= c.y - 20 && mouseY < c.y - 20 + 16 && button == 0) {
                dragging = 1;
                draggedCategory = c;
                xOffset = mouseX - (c.x - 3 - 1);
                yOffset = mouseY - (c.y - 20);
            }
            if (!c.hidden) {
                int count = 0;
                for (Module m : modules) {
                    float offset = 16 * count;

                    long systemcurrenttime = 0;
                    if (mouseX >= c.x - 3 && mouseX < c.x + 75 && mouseY >= c.y - 4 + offset && mouseY < c.y + offset + 16 - 4 && button == 0) {
                        m.toggle();
                    }
                    if (state == ClickGuiState.Zero) {
                        if (mouseX >= c.x - 3 && mouseX < c.x + 75 && mouseY >= c.y - 4 + offset && mouseY < c.y + offset + 16 - 4 && button == 1 && !m.settings.isEmpty()) {
                            inSet = m;
                            inCat = c;
                            state = ClickGuiState.InSettings;
                            systemcurrenttime = System.currentTimeMillis();
                        }
                    }
                    if (state == ClickGuiState.InSettings) {
                        if (mouseX >= c.x - 3 && mouseX < c.x + 75 && mouseY >= c.y - 4 + offset && mouseY < c.y + offset + 16 - 4 && button == 1 && systemcurrenttime != System.currentTimeMillis() && inSet != m) {
                            inSet = m;
                            inCat = c;
                            state = ClickGuiState.InSettings;
                            systemcurrenttime = System.currentTimeMillis();
                        }
                        if (mouseX >= c.x - 3 && mouseX < c.x + 75 && mouseY >= c.y - 4 + offset && mouseY < c.y + offset + 16 - 4 && button == 1 && systemcurrenttime != System.currentTimeMillis() && inSet == m) {
                            state = ClickGuiState.Zero;
                            inCat = null;
                            inSet = null;
                        }
                    }
                    count++;
                }
            }
            if (state == ClickGuiState.InSettings && !inSet.settings.isEmpty() && inCat == category) {
                int settingsindex = 0;
                for (Setting setting : inSet.settings) {
                    float offset = 16 * settingsindex;
                    float newX = c.x + 78;
                    Gui.drawRect(newX - 3, c.y - 4 + offset, newX + 75 + 50, c.y + offset + 16 - 4, new Color(35, 35, 35, 255).getRGB());
                    if (mouseX >= newX - 3 && mouseX < newX + 75 + 50 && mouseY >= c.y - 4 + offset && mouseY < c.y + offset + 16 - 4) {
                        if (setting instanceof BooleanSetting) {
                            ((BooleanSetting) setting).toggle();
                        }
                        if (setting instanceof NumberSetting) {
                            if (button == 1) {
                                if (setting instanceof NumberSetting) {
                                    if (!((ClickGui) CatSense.getModbyName("ClickGui")).getUseSliders().isEnabled()) {
                                        ((NumberSetting) setting).increment(false);
                                    }
                                }
                            }
                            if (button == 0) {
                                if (setting instanceof NumberSetting) {
                                    if (((ClickGui) CatSense.getModbyName("ClickGui")).getUseSliders().isEnabled()) {
                                        SliderSet = setting;
                                        draggingSlider = true;
                                    } else {
                                        ((NumberSetting) setting).increment(true);
                                    }
                                }
                            }
                        }
                        if (setting instanceof ModeSetting) {
                            if (button == 0) {
                                if (setting instanceof ModeSetting) {
                                    ((ModeSetting) setting).cycle();
                                }
                            }
                            if (button == 1) {
                                if (setting instanceof ModeSetting) {
                                    ((ModeSetting) setting).cycleminus();
                                }
                            }
                        }
                        if (setting instanceof KeybindSetting) {
                            waitingForKeyBind = true;
                        }
                    }
                    settingsindex++;
                }
            }
            categoryValue++;
        }
    }

    protected void mouseReleased(int mouseX, int mouseY, int state) {
        dragging = 0;
        draggedCategory = null;
        draggingSlider = false;
        super.mouseReleased(mouseX, mouseY, state);
    }

    private void reset(Module.Category c) {
        switch (c) {
            case COMBAT:
                c.x = 50;
                c.y = 50;
                c.hidden = false;
                break;
            case MOVEMENT:
                c.x = 150;
                c.y = 50;
                c.hidden = false;
                break;
            case PLAYER:
                c.x = 250;
                c.y = 50;
                c.hidden = false;
                break;
            case RENDER:
                c.x = 350;
                c.y = 50;
                c.hidden = false;
                break;
            case WORLD:
                c.x = 450;
                c.y = 50;
                c.hidden = false;
                break;
            case MISC:
                c.x = 550;
                c.y = 50;
                c.hidden = false;
                break;
        }
    }

    @Override
    public void initGui() {
        ClickGuiDiscord.setInvMove();
        if (ClickGui.Blur.isEnabled()) {
            if (fastRender = mc.gameSettings.ofFastRender)
                mc.gameSettings.setOptionValue(GameSettings.Options.FAST_RENDER, 1);
            showDebugInfo = mc.gameSettings.showDebugInfo;
            mc.gameSettings.showDebugInfo = false;
            if (!(mc.gameSettings.ofFastRender) && OpenGlHelper.shadersSupported
                    && mc.getRenderViewEntity() instanceof EntityPlayer) {
                if (mc.entityRenderer.theShaderGroup != null)
                    mc.entityRenderer.theShaderGroup.deleteShaderGroup();
                mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
            }
        }

    }

    protected void keyTyped(char typedChar, int keyCode) {
        if (waitingForKeyBind) {
            if (keyCode != Keyboard.KEY_RETURN && keyCode != Keyboard.KEY_UP && keyCode != Keyboard.KEY_RIGHT
                    && keyCode != Keyboard.KEY_DOWN && keyCode != Keyboard.KEY_LEFT && keyCode != Keyboard.KEY_ESCAPE && keyCode != Keyboard.KEY_W && keyCode != Keyboard.KEY_A && keyCode != Keyboard.KEY_D && keyCode != Keyboard.KEY_S && keyCode != Keyboard.KEY_DELETE) {
                inSet.keyCode.code = keyCode;
            }
            if (keyCode == Keyboard.KEY_DELETE) {
                inSet.keyCode.code = 0;
            }
            waitingForKeyBind = false;
        }
        try {
            super.keyTyped(typedChar, keyCode);
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

     @Override
     public void onGuiClosed() {
         if (!(mc.gameSettings.ofFastRender) && mc.entityRenderer.theShaderGroup != null) {
             mc.entityRenderer.theShaderGroup.deleteShaderGroup();
             mc.entityRenderer.theShaderGroup = null;
         }
         if (fastRender)
             mc.gameSettings.setOptionValue(GameSettings.Options.FAST_RENDER, 1);
         mc.gameSettings.showDebugInfo = showDebugInfo;

     }
    private enum ClickGuiState {
        Zero("In nothing"), InSettings("Settings"), InKeyBind("");
        private final String type;

        ClickGuiState(String type) {
            this.type = type;
        }

        public String getType() {
            return this.type;
        }
    }
}