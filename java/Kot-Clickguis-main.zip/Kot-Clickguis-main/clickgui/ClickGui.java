package Kot.kotsystem.clickgui;

import Kot.Module.Module;
import Kot.Module.settings.BooleanSetting;
import Kot.Module.settings.ModeSetting;
import Kot.kotsystem.clickgui.Astolfo.AstolfoClickGui;
import org.lwjgl.input.Keyboard;

public class ClickGui extends Module {
    public static BooleanSetting Gradient = new BooleanSetting("Gradient", false);
    public static BooleanSetting Blur = new BooleanSetting("Blur", false);
    public final ModeSetting mode = new ModeSetting("Mode", "Discord", "Separated", "Discord", "Astolfo");
    private final ModeSetting Theme = new ModeSetting("Theme", "Black", "Black", "White", "Green");
    private final BooleanSetting UseSliders = new BooleanSetting("Sliders", true);
    private final BooleanSetting Rainbow = new BooleanSetting("Rainbow", true);

    public BooleanSetting getRainbow() {
        return Rainbow;
    }

    public ClickGui() {
        super("ClickGui", Keyboard.KEY_RSHIFT, Category.RENDER, "ClickGui");
        this.addSettings(Gradient, Blur, mode, Theme, UseSliders, Rainbow);
    }

    public void onEnable() {
        if (mode.getMode().equals("Separated")) {
            mc.displayGuiScreen(new ClickGuiSeparated());
        } else if (mode.getMode().equals("Discord")) {
            mc.displayGuiScreen(ClickGuiDiscord.instance);
        } else if (mode.getMode().equals("Astolfo")){
            mc.displayGuiScreen(AstolfoClickGui.instance);
        }
        this.toggle();
    }

    public ModeSetting getTheme() {
        return Theme;
    }

    public BooleanSetting getUseSliders() {
        return UseSliders;
    }
}