package Kot.kotsystem.clickgui.Astolfo;

import Kot.CatSense;
import Kot.Module.Module;
import Kot.Module.modules.render.HUD;
import Kot.Module.settings.*;
import Kot.kotsystem.clickgui.ClickGui;
import Kot.kotsystem.fontsystem.CFontRenderer;
import Kot.util.GuiUtils;
import Kot.util.R2DUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.awt.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AstolfoClickGui extends GuiScreen {
    public static AstolfoClickGui instance;
    ArrayList<AstolfoCategory> categories = new ArrayList<>();
    public AstolfoClickGui() {
        for(Module.Category c : Module.Category.values()){
            switch (c) {
                case COMBAT:
                    categories.add(new AstolfoCategory(c, 120, 18, 0xffE64D3A));
                    break;
                case MOVEMENT:
                    categories.add(new AstolfoCategory(c, 120, 18, 0xff2ECD6F));
                    break;
                case PLAYER:
                    categories.add(new AstolfoCategory(c, 120, 18, 0xff8E45AE));
                    break;
                case RENDER:
                    categories.add(new AstolfoCategory(c, 120, 18, 0xff3601CE));
                    break;
                case WORLD:
                    categories.add(new AstolfoCategory(c, 120, 18, 0xffE65F00));
                    break;
                case MISC:
                    categories.add(new AstolfoCategory(c, 120, 18, 0xffF29D11));
                    break;
            }
        }
        instance = this;
    }


    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        for(AstolfoCategory c : categories){
            c.draw(mouseX, mouseY);
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int button) {
        for(AstolfoCategory c : categories){
            c.mouseClicked(mouseX, mouseY, button);
        }
    }

    protected void mouseReleased(int mouseX, int mouseY, int state) {
        for(AstolfoCategory c : categories){
            c.mouseReleased(mouseX, mouseY);
        }
        super.mouseReleased(mouseX, mouseY, state);
    }

    @Override
    public void initGui() {
        setInvMove();
    }

    protected void keyTyped(char typedChar, int keyCode) {


        try {
            super.keyTyped(typedChar, keyCode);
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    public static void setInvMove() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen instanceof GuiChat) {
            return;
        }
        KeyBinding[] moveKeys = new KeyBinding[]{mc.gameSettings.keyBindForward, mc.gameSettings.keyBindBack,
                mc.gameSettings.keyBindLeft, mc.gameSettings.keyBindRight, mc.gameSettings.keyBindJump};
        KeyBinding[] arrayofKeybinding = moveKeys;
        int i;
        int j;
        KeyBinding bind = null;
        arrayofKeybinding = moveKeys;
        j = moveKeys.length;
        for (i = 0; i < j; ++i) {
            bind = arrayofKeybinding[i];
            bind.pressed = Keyboard.isKeyDown(bind.getKeyCode());
        }
    }
}
