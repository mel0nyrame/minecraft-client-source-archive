package Kot.kotsystem.clickgui.Astolfo;

import Kot.CatSense;
import Kot.Module.Module;
import Kot.Module.settings.*;
import Kot.kotsystem.fontsystem.CFontRenderer;
import Kot.util.GuiUtils;
import net.minecraft.client.gui.Gui;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.List;

public class AstolfoCategory {

    private int x;
    private int y;
    private int dragX;
    private int dragY;
    private final int width;
    private final int height;
    private final int color;
    Module.Category c;
    private Setting slidedSetting = null;
    private boolean isSliding = false;

    private boolean dragging = false;

    public AstolfoCategory(Module.Category c, int width, int height, int color){
        this.c = c;
        x = (int) c.x;
        y = (int) c.y;
        this.width = width;
        this.height = height;
        this.color = color;
    }
    public void draw(int mouseX, int mouseY){
        CFontRenderer fr = CatSense.getFontManager().TEST;
        CFontRenderer frS = CatSense.getFontManager().ArrayListFluxSmall;
        CFontRenderer frSN = CatSense.getFontManager().TESTSmall;

        if(dragging){
            c.x = mouseX - dragX;
            c.y = mouseY - dragY;
            //x = mouseX - dragX;
            //y = mouseY - dragY;
        }
        x = (int) c.x;
        y = (int) c.y;

        Gui.drawRect(x-1, y-1, x+width+1, y+height, color);
        Gui.drawRect(x, y, x+width, y+17, 0xff181A17);
        fr.drawString(c.name.toLowerCase() ,x+3, y+5, -1);
        List<Module> modules = CatSense.getModuleManager().getModulesByCategory(c);
        if(!c.hidden) {
            double count = 0;
            for (Module m : modules) {
                float multiplyer = 16;
                Gui.drawRect(x - 1, y + 17 + ((float)(float)count * multiplyer), x + width + 1, y + 17 + ((float)(float)count * multiplyer) + multiplyer + 3, color);
                Gui.drawRect(x, y + 17 + ((float)count * multiplyer), x + width, y + 17 + ((float)count * multiplyer) + multiplyer + 2, 0xff181A17);
                Gui.drawRect(x + 2, y + 17 + ((float)count * multiplyer), x + width - 2, y + 17 + ((float)count * multiplyer) + multiplyer, m.isToggled() ? color : new Color(40, 40, 40).getRGB());
                fr.drawString(m.name.toLowerCase(), x + width - fr.getStringWidth(m.name.toLowerCase()) - 3.5f, y + 17 + ((float)count * multiplyer) + 4.5f, new Color(230, 230, 230).getRGB());
                count++;

                if(m.extended && m.settings.size() > 1){
                    count = count + 0.1;
                    for (Setting s : m.settings) {
                        Gui.drawRect(x - 1, y + 17 + ((float)count * multiplyer), x + width + 1, y + 17 + ((float)count * multiplyer) + multiplyer + 3, color);
                        Gui.drawRect(x, y + 17 + ((float)count * multiplyer), x + width, y + 17 + ((float)count * multiplyer) + multiplyer + 2, 0xff181A17);

                        int val = 3;
                        if (s instanceof NumberSetting) {
                            NumberSetting number = (NumberSetting) s;



                            GuiUtils.drawBarWithMinMax((float)number.getValue(),(float) number.getMinimum(), (float) number.getMaximum(), x+2, y + 17 + ((float)count * multiplyer), x + width-2, 14,color);
                            frS.drawString(s.name, x +val, y + 17 + ((float)count * multiplyer) + 4.5f, new Color(230, 230, 230).getRGB());
                            frSN.drawString(number.getValue()+"", x +width-frSN.getStringWidth(number.getValue()+"")-3, y + 17 + ((float)count * multiplyer) + 4.5f, new Color(230, 230, 230).getRGB());
                            if(isSliding && s == slidedSetting){


                                number.setValue(number.getMinimum() + ((mouseX - ((float)x+2)) / ((float) width-4) * (number.getMaximum() - number.getMinimum())));
                            }
                        }
                        if (s instanceof ModeSetting) {
                            ModeSetting mode = (ModeSetting) s;
                            frS.drawString(s.name, x +val, y + 17 + ((float)count * multiplyer) + 4.5f, new Color(230, 230, 230).getRGB());
                            frSN.drawString(mode.getMode().toUpperCase(), x +width-frSN.getStringWidth(mode.getMode().toUpperCase())-3, y + 17 + ((float)count * multiplyer) + 4.5f, new Color(230, 230, 230).getRGB());
                        }
                        if (s instanceof BooleanSetting) {
                            BooleanSetting bool = (BooleanSetting) s;
                            if(bool.isEnabled()){
                                Gui.drawRect(x+2, y + 17 + ((float)count * multiplyer)-0.5f, x + width-2, y + 15 + ((float)count * multiplyer) + multiplyer, color);
                            }
                            frS.drawString(s.name, x +val, y + 17 + ((float)count * multiplyer) + 4.5f, new Color(230, 230, 230).getRGB());
                        }
                        if(!(s instanceof KeybindSetting)) {
                            count = count + 0.85;
                        }
                    }
                    count = count + 0.1;
                }
            }
        }
    }
    public void mouseClicked(int mouseX, int mouseY, int button){
        boolean drag = mouseX >= x && mouseX < x+width && mouseY >= y && mouseY < y+17;
        if(drag && button == 0){
            dragX = mouseX - x;
            dragY = mouseY - y;
            dragging = true;
        }
        if(drag && button == 1){
            c.hidden = !c.hidden;
        }

        List<Module> modules = CatSense.getModuleManager().getModulesByCategory(c);
        double count = 0;
        for(Module m : modules){
            float multiplyer = 16;
            boolean toggleOrNot = mouseX >= x-1 && mouseX < x+width+1 && mouseY >= y+17+((float)count*multiplyer) && mouseY < y+17+((float)count*multiplyer)+16;
            if(toggleOrNot){
                if(button == 0) {
                    m.toggle();
                }
                if(button == 1){
                    m.extended = !m.extended;
                }

            }
            count++;
            if(m.extended && m.settings.size() > 1){
                count = count + 0.1;
                for (Setting s : m.settings) {
                    boolean clicked = mouseX >= x-1 && mouseX < x+width+1 && mouseY > y + 17 + ((float)count * multiplyer) && mouseY < y + 17 + ((float)count * multiplyer) + multiplyer -2.5;
                    if(clicked) {
                        int val = 3;
                        if (s instanceof NumberSetting) {
                            NumberSetting number = (NumberSetting) s;
                            isSliding = true;
                            slidedSetting = s;
                        }
                        if (s instanceof ModeSetting) {
                            ModeSetting mode = (ModeSetting) s;
                            if(button == 0){
                                mode.cycle();
                            }
                            if(button == 1){
                                mode.cycleminus();
                            }
                        }
                        if (s instanceof BooleanSetting) {
                            BooleanSetting bool = (BooleanSetting) s;
                            bool.toggle();
                        }
                    }
                    if(!(s instanceof KeybindSetting)) {
                        count = count + 0.85;
                    }

                }
                count = count + 0.1;
            }
        }
    }
    public void mouseReleased(int mouseX, int mouseY){
        dragging = false;
        isSliding = false;
    }

}
