# Kot's ClickGUI

Kot's clickgui pack
- Discord ClickGUI
- Separate/dropdown ClickGUI
- Astolfo ClickGUI
- Soon Flux type ClickGUI

For new Astolfo clickgui you need to make 3 variables in Category class(meowsense src haram)/enum (intent/all).
```java
public float x = 0;
public float y = 0;
public boolean hidden = false;
public boolean extended = false;

//startup
new AstolfoClickGui();
```
Astolfo clickgui: ![](https://i.imgur.com/I5WSNaq.png)

For new dropdown clickgui you need to make 3 variables in Category class(meowsense src haram)/enum (intent/all).
```java
public float x = 0;
public float y = 0;
public boolean hidden = false;
```
Dropdown clickgui: ![](https://i.imgur.com/Q1WPG7f.png)

To set-up discord clickgui you need to make a instance of it on startup
```java
new ClickGuiDiscord();
```
Discord ClickGui: 
![](https://i.imgur.com/AO56bqx.png)

If you open the clickgui it may "unpress" the keybind. Because in one tick you are not setting it. if you do this on initGUI then it will not stop you.

ClickGUI Discord is easiest to implement, because of 0 references (not including refernce to categories, and main class). 

**FONT**
Font is easy to change in all of them just change [this](https://i.imgur.com/JmzxqPH.png)
